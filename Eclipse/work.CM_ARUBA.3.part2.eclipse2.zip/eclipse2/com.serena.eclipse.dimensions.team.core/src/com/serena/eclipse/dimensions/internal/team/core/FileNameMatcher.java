/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 * Contributors:
 * IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.List;

import com.serena.dmfile.FilePlatforms;

/**
 * A FileNameMatcher associates a String with a String pattern.
 */
public class FileNameMatcher {
    /** matches nothing */
    public static final FileNameMatcher NULL_MATCHER = new FileNameMatcher() {
        @Override
        public void register(String pattern, String result) {
        } // ignore changes
    };

    private static final boolean ignoreCase = (FilePlatforms.getPlatform() == FilePlatforms.WINDOWS);
    private List matchers_a = new ArrayList();
    private List matchersRecursive_a = new ArrayList();
    
    private List matchersClearRecursive_a = new ArrayList();
    
    private List results_a = new ArrayList();
    private List resultsRecursive_a = new ArrayList();
    
    private static final String TRUE = "true"; //$NON-NLS-1$

    private boolean stopRecursive = false;

    public FileNameMatcher() {
    }

    public FileNameMatcher(String[] patterns) {
        register(patterns);
    }

    void register(String[] patterns) {
        for (int i = 0; i < patterns.length; i++) {
            register(patterns[i], TRUE);
        }
    }

    public void register(String pattern, String result) {
        assert matchers_a.size() == results_a.size();

        pattern = pattern.trim();

        // The empty pattern matches everything, but we want to match
        // nothing with it, so we just do not register anything
        if (pattern.length() == 0) {
            return;
        }

        if (pattern.startsWith(DMWorkspace.RECURSIVE_MASK_PREFIX)) {
            String str = pattern.substring(DMWorkspace.RECURSIVE_MASK_PREFIX.length());
            
            str = str.trim();
            
            matchersRecursive_a.add(new StringMatcher(str, ignoreCase, false));
            resultsRecursive_a.add(result);
        } else if (pattern.startsWith(DMWorkspace.CLEAR_RECURSIVE_MASK_PREFIX)) {
            String str = pattern.substring(DMWorkspace.CLEAR_RECURSIVE_MASK_PREFIX.length());
            
            str = str.trim();
            
            if(str.isEmpty())
            	stopRecursive = true;
            else
            	matchersClearRecursive_a.add(new StringMatcher(str, ignoreCase, false));
            
        } else if (pattern.startsWith(DMWorkspace.COMMENT_MASK_PREFIX)) {
            return;
        } else {
        matchers_a.add(new StringMatcher(pattern, ignoreCase, false));
        results_a.add(result);
        }


    }

    public String getMatch(String name, boolean parent) {
        StringMatcher stringMatcher;
 
		if (!parent) {
			for (int i = 0; i < matchers_a.size(); i++) {
				stringMatcher = (StringMatcher) matchers_a.get(i);
				if (stringMatcher.match(name)) {
					return (String) results_a.get(i);
				}
			}
		}
        // Check recursive paths
        StringMatcher stringMatcherRecursivePatterns;
        for (int i = 0; i < matchersRecursive_a.size(); i++) {
            stringMatcherRecursivePatterns = (StringMatcher) matchersRecursive_a.get(i);
            if (stringMatcherRecursivePatterns.match(name)) {
                return (String) resultsRecursive_a.get(i);
        }
        }

    	if(stopRecursive)
    		return null;
    	
        // Check clear recursive paths
        StringMatcher stringMatcherClearRecursivePatterns;
        for (int i = 0; i < matchersClearRecursive_a.size(); i++) {
        	stringMatcherClearRecursivePatterns = (StringMatcher) matchersClearRecursive_a.get(i);
            if (stringMatcherClearRecursivePatterns.match(name)) {
            	stopRecursive = true;
                return null;
            }
        }
    	
        return null;
    }

    public boolean IsStopRecursive(){
		return stopRecursive;
    }
    
    public boolean match(String name, boolean parent) {
        return getMatch(name, parent) != null;
    }
}

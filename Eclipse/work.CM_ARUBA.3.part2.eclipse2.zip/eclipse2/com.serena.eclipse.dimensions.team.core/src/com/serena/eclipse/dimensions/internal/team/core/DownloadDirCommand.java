package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.DownloadCommandDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

public class DownloadDirCommand extends DownloadCommand { 

    public DownloadDirCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        this(dmProject, requests, false, false);
    }

    public DownloadDirCommand(DMProject dmProject, WorkspaceResourceRequest[] requests, boolean overwrite,
            boolean deleteUnmanaged) {
        super(dmProject, requests, overwrite, deleteUnmanaged);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        IContainer projRoot = dmProject.getRoot();// (IContainer)resources[0];
        TeamUtils.ensureContainerExists(projRoot);
        TeamUtils.ensureReacheable(projRoot, true);
        // explicitly precreate metadata folders where we expect them to be,
        // the intention here is to mark them *team private* as early as possible
        // to avoid resource change listeners to see them as non-team private, e.g.
        // they may show up in the Navigator which is undesirable...
        monitor.subTask(Messages.DownloadCommand_createMetaFolders);
        boolean debug = DMTeamPlugin.getDefault().isDebugging();
        long start = 0l;
        if (debug) {
            System.out.println("+ create folders"); //$NON-NLS-1$
            start = System.currentTimeMillis();
        }
        List<IFolder> emptyFolders = new ArrayList<IFolder>();
        RepositoryFolder projFolder = dmProject.getRemoteRoot();

        if (projRoot != null && projFolder != null) {
            MetadataProvider metadataProvider = MetadataProviderFactory.providerFor(projRoot);
            try {
                @SuppressWarnings("unchecked")
                List<RepositoryFolder> childFolders = projFolder.getAllChildFolders();

                for (Iterator<RepositoryFolder> iter = childFolders.iterator(); iter.hasNext();) {
                    RepositoryFolder aFolder = iter.next();
                    IPath remoteDir = dmProject.getRemoteOffset();
                    IPath path = TeamUtils.getFolderPath(aFolder);
                    if (remoteDir != null && !remoteDir.isEmpty()) {
                        path = path.removeFirstSegments(remoteDir.segmentCount());
                    }
                    IFolder folder = projRoot.getFolder(path);
                    WorkspaceMetadataManager.ensureHasMetadata(folder, metadataProvider);
                    if (!TeamUtils.hasFolderGotFileInItOrItsSubfolders(folder)) {
                        emptyFolders.add(folder);
                    }
                }
            } finally {
                if (metadataProvider != null) {
                    metadataProvider.close();
                }
            }
        }

        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- create folders done, took " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        int dlWrkUnits = 900;
        int refreshUnits = 100;
        monitor.beginTask(null, dlWrkUnits + refreshUnits);
        try {
            runDownload(Utils.subMonitorFor(monitor, dlWrkUnits));
            if (!emptyFolders.isEmpty()) {
                for (Iterator<IFolder> iterEmpFolders = emptyFolders.iterator(); iterEmpFolders.hasNext();) {
                    TeamUtils.ensureReacheable(iterEmpFolders.next(), true);// Write metadata for empty folder
                }
            }
            // refresh only local files - assume no remote changes happened
            projRoot.getProject().refreshLocal(IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, refreshUnits));
        } finally {
            monitor.done();
        }

        if (projRoot != null) {
            // Hide project marker file along with its metadata
            IPath path = projRoot.getFullPath().addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);
            IFile eclFile = projRoot.getFile(path);
            if (eclFile != null && eclFile.exists()) { // we found it
                eclFile.setTeamPrivateMember(true);
                ResourceAttributes resourceAttributes = eclFile.getResourceAttributes();
                if (resourceAttributes != null) {
                    resourceAttributes.setHidden(true);
                    eclFile.setResourceAttributes(resourceAttributes);
                }
            }

            // Set hidden attribute for project root .metadata/.dm directory (as this directory was created in darius stack)
            IProject project = dmProject.getProject();
            MetadataProvider mdProvider = MetadataProviderFactory.providerFor(project);

            try {
                if (dmProject.isFullWorkArea()) {
                    MetadataHelper.hideMetadataHierarchy(project.getLocation(), dmProject.getWorkAreaPath(), mdProvider);
                } else {
                    IFolder mdFolder = null;
                    mdFolder = projRoot.getFolder(new Path(mdProvider.metadataDirname()));

                    if (mdFolder != null && mdFolder.exists()) {
                        ResourceAttributes resAttributes = mdFolder.getResourceAttributes();
                        if (resAttributes != null) {
                            resAttributes.setHidden(true);
                            mdFolder.setResourceAttributes(resAttributes);
                        }
                    }
                }
            } finally {
                if (mdProvider != null) {
                    mdProvider.close();
                }
            }
        }
    }

    private void runDownload(IProgressMonitor monitor) throws CoreException {
        String msg = NLS.bind(Messages.DownloadCommand_downloadDir, dmProject.getRemoteOffset().toOSString());
        monitor.subTask(msg);

        monitor.beginTask(null, 1010);
        try {
            // 10 of 1000
            Session session = dmProject.getConnection().openSession(Utils.subMonitorFor(monitor, 10));

            // 910 of 1000
            final StateTransferMonitor tm = new StateTransferMonitor(Utils.subMonitorFor(monitor, 900),
                    TransferMonitor.DOWN);
            session.run(new APIOperation(msg) {
                @Override
                protected DimensionsResult doRun() throws Exception {
                    IPath userDir = dmProject.getUserDirectory();
                    IPath remoteDir = dmProject.getRemoteOffset();
                    IPath relativeLocation = dmProject.getRelativeLocation();

                    DownloadCommandDetails dcd = new DownloadCommandDetails();
                    dcd.setRelativeLocation(relativeLocation != null ? relativeLocation.toOSString() : null);
                    if (dmProject.isFullWorkArea()) {
                        dcd.setDirectory(remoteDir.toOSString());
                    }
                    dcd.setUserDirectory(userDir.toOSString());
                    dcd.setTouch(Boolean.FALSE);
                    dcd.setOverwrite(Boolean.valueOf(true));
                    dcd.setCheckConflict(Boolean.FALSE);
                    dcd.setCancelMonitor(tm);
                    dcd.setListener(tm);
                    dcd.setExpand(TeamUtils.isExpandSubstitution());

                    DimensionsResult downloadResult;
                    if (dmProject.isWorkset()) {
                        Project project = (Project) dmProject.getDimensionsObject();
                        downloadResult = project.download(dcd);
                    } else {
                        Baseline baseline = (Baseline) dmProject.getDimensionsObject();
                        downloadResult = baseline.download(dcd);
                    }
                    return downloadResult;
                }
            }, monitor);

        } finally {
            monitor.done();
        }
    }

}
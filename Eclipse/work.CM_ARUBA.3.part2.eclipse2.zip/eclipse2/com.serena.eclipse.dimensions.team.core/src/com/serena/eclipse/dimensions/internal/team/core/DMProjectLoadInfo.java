/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

/**
 * Data for project set import.
 *
 * @author V.Grishchenko
 */
public class DMProjectLoadInfo {
    IProject localProject;
    IPath localPath = Path.EMPTY;
    String server;
    String dbName;
    String dbConnection;
    String remoteProjectId;
    int remoteProjectType;
    IPath remotePath = Path.EMPTY;

    public DMProjectLoadInfo() {
    }

    /**
     * @return local project for load
     */
    public IProject getLocalProject() {
        return localProject;
    }

    /**
     * @return local mount point
     */
    public IPath getLocalPath() {
        return localPath;
    }

    /**
     * @return Dimensions server hostname
     */
    public String getServer() {
        return server;
    }

    /**
     * @return database connection name
     */
    public String getDbConnection() {
        return dbConnection;
    }

    /**
     * @return Dimensions database name, e.g. "intermediate"
     */
    public String getDbName() {
        return dbName;
    }

    /**
     * @return Dimensions project or baseline id
     */
    public String getRemoteProjectId() {
        return remoteProjectId;
    }

    /**
     * @return project or baseline
     * @see IDMProject#WORKSET
     * @see IDMProject#BASELINE
     */
    public int getRemoteProjectType() {
        return remoteProjectType;
    }

    /**
     * @return remote offset
     */
    public IPath getRemotePath() {
        return remotePath;
    }

}

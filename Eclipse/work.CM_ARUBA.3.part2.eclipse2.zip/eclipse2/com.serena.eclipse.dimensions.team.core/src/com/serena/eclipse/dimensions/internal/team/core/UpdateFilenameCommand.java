/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
class UpdateFilenameCommand extends DMWorkspaceCommand1 {

    /**
     * @param dmProject
     * @param requests
     */
    public UpdateFilenameCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, requests.length * 100);
        try {
            for (int i = 0; i < requests.length; i++) {
                UpdateFilenameRequest request = (UpdateFilenameRequest) requests[i];
                request.setProject(dmProject);
                request.process(Utils.subMonitorFor(monitor, 100));
                Utils.checkCanceled(monitor);
            }
        } finally {
            monitor.done();
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.Session;

/**
 * @author V.Grishchenko
 */
public class MoveItemRequest extends ItemRevisionRequest implements IMoveRequest {
    private MoveRequest impl;
    private String comment;

    public MoveItemRequest(IFile file, ItemType itemType, ItemRevision revision, boolean requestMandatory) throws CoreException {
        super(file, itemType, revision, true, requestMandatory);
        this.impl = new MoveRequest(file);
    }

    @Override
    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
        return impl.execute(_session, monitor);
    }

    @Override
    public int getKind() {
        return impl.getKind();
    }

    @Override
    public boolean isUnmanage() {
        return impl.isUnmanage();
    }

    @Override
    public void setUnmanage(boolean b) {
        impl.setUnmanage(b);
    }

    @Override
    public void addChangeRequest(String id) {
        impl.addChangeRequest(id);
    }

    @Override
    public void clearChangeRequests() {
        impl.clearChangeRequests();
    }

    @Override
    public List<String> getChangeRequests() {
        return impl.getChangeRequests();
    }

    @Override
    public void removeChangeRequest(String id) {
        impl.removeChangeRequest(id);
    }

    @Override
    public void setChangeRequests(List<String> reqs) {
        impl.setChangeRequests(reqs);
    }

    MoveRequest getImpl() {
        return impl;
    }

    @Override
    public IResource getDestination() throws CoreException {
        return impl.getDestination();
    }

    @Override
    public IResource getSource() throws CoreException {
        return impl.getSource();
    }

    public List<String> getSourceRequests() {
        return impl.getSourceRequests();
    }

    @Override
    public boolean isCrossProject() throws CoreException {
        return impl.isCrossProject();
    }

    @Override
    public boolean isSource() {
        return impl.isSource();
    }

    @Override
    public void setSourceRequests(List<String> requests) {
        impl.setSourceRequests(requests);
    }

    @Override
    public String getComment() {
        return comment;
    }

    @Override
    public void setComment(String comment) {
        this.comment = comment;
    }

    @Override
    public IDMProject getSourceProject() throws CoreException {
        return impl.getSourceProject();
    }

    @Override
    public IDMProject getDestinationProject() throws CoreException {
        return impl.getDestinationProject();
    }

}

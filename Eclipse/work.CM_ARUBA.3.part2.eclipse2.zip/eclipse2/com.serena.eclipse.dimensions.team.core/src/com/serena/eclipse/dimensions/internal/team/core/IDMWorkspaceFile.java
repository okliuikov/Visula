/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.team.core.TeamException;

/**
 * @author V.Grishchenko
 */
public interface IDMWorkspaceFile extends IDMWorkspaceResource, IDMFile {
    IDMRemoteFile getBaseFile() throws TeamException;

    IDMRemoteFile getRemoteFile() throws TeamException;

    boolean isRemoteModified() throws TeamException;

    /**
     * @return <code>true</code> if this file is extracted locally
     */
    boolean isExtracted() throws TeamException;

    /**
     * @return <code>true</code> if any revision of remote file is extracted to
     *         other users
     */
    boolean isExtractedOther() throws TeamException;

    boolean isExtractedExclusive() throws TeamException;

    /**
     * @return <code>true</code> if any revision of remote file is extracted
     */
    boolean isAnyExtracted() throws TeamException;

    /**
     * @return <code>true</code> if more than one revision of remote file are
     *         extracted
     */
    boolean isMultiExtracted() throws TeamException;

    /**
     * Resource is in optimistic mode ("optimistically locked"), when it is
     * managed, not extracted and writable at the same time
     *
     * @return <code>true</code> of this resource is optimistically locked, returns <code>false</code> otherwise
     */
    boolean isOptimistic() throws TeamException;

    boolean isPessimistic() throws TeamException;

    /**
     * @return <code>true</code> if item revision is currently
     *         locked, returns <code>false</code> otherwise
     */
    boolean isLocked() throws TeamException;

    /**
     * @return <code>true</code> if item revision is locked by user other than the current user,
     *         returns <code>false</code> otherwise
     */
    boolean isLockedOther() throws TeamException;

}

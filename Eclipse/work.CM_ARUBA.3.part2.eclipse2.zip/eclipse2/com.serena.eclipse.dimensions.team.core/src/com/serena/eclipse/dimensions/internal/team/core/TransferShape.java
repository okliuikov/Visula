package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Collections;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;

import com.serena.dmfile.sync.Shape;
import com.serena.eclipse.dimensions.core.util.Assert;

public interface TransferShape {

    public Shape getShape();

    public List<IResource> getScopes();

    public boolean isMergePointsAware();

    static class MultiselectShape implements TransferShape {
        Shape shape = Shape.MULTISELECT;
        List<IResource> scopes;

        public MultiselectShape(List<IResource> scopes) {
            Assert.isNotNull(scopes);
            this.scopes = scopes;
        }

        @Override
        public Shape getShape() {
            return shape;
        }

        @Override
        public List<IResource> getScopes() {
            return scopes;
        }

        @Override
        public boolean isMergePointsAware() {
            return true;
        }

    }

    static class TreeShape implements TransferShape {
        Shape shape = Shape.TREE;
        List<IResource> scopes;

        public TreeShape(IResource scope) {
            Assert.isNotNull(scope);
            Assert.isLegal(!(scope instanceof IFile));
            this.scopes = Collections.singletonList(scope);
        }

        @Override
        public Shape getShape() {
            return shape;
        }

        @Override
        public List<IResource> getScopes() {
            return scopes;
        }

        @Override
        public boolean isMergePointsAware() {
            return true;
        }

    }

    static class ListShape implements TransferShape {
        Shape shape = Shape.LIST;

        @Override
        public Shape getShape() {
            return shape;
        }

        @Override
        public List<IResource> getScopes() {
            return Collections.emptyList();
        }

        @Override
        public boolean isMergePointsAware() {
            return false;
        }

    }

}

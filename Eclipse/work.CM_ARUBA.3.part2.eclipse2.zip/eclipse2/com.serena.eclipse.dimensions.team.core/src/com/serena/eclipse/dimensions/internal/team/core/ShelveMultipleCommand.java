package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ShelveMultipleIdeProjectsCommandDetails;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.FavouriteProjectsList;
import com.serena.eclipse.dimensions.core.IFavouriteObject;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.core.sbm.ActionDetails;
import com.serena.eclipse.dimensions.core.sbm.AssociateInput;
import com.serena.eclipse.dimensions.core.sbm.ISBMConnection;
import com.serena.eclipse.dimensions.core.sbm.ISBMManager;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

public class ShelveMultipleCommand extends DMWorkspaceMultipleCommand1 implements DeliverResults {
    private static boolean debug = DMTeamPlugin.getDefault().isDebugging();

    // inputs
    private ShelfDetails shelfDetails;
    private String shelfName;
    private TransferToStreamMultipleCommandData transferData;
    private List<IdeProjectShelveBucket> buckets = new ArrayList<IdeProjectShelveBucket>();
    private ShelveMultipleIdeProjectsCommandDetails multiDetails = new ShelveMultipleIdeProjectsCommandDetails();

    // results
    private Map<String, ObjectToTransfer> statusMap = new HashMap<String, ObjectToTransfer>();

    // sbm integration
    private ISBMConnection sbmc = null;
    private Map<IResource, ActionDetails> actionDetails = null;

    public ShelveMultipleCommand(TransferToStreamMultipleCommandData transferData) {
        super(transferData.getRequests());
        this.transferData = transferData;
    }

    @Override
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        DeliverHelper.addDeliverSchedulingRule(rules, request);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            beforeShelve(Utils.subMonitorFor(monitor, 5));
            shelve(Utils.subMonitorFor(monitor, 950));
            afterShelve(Utils.subMonitorFor(monitor, 45));
        } finally {
            monitor.done();
        }
    }

    /**
     * Creates multiple shelve details, init command data, creates personal stream for shelving
     * @throws DMException
     */
    @SuppressWarnings("unchecked")
    private void beforeShelve(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        try {
            // create shelving buckets
            Map<IDMProject, TransferToStreamOperationData> deliverOperations = transferData.getDeliverOpeartions();
            multiDetails.setAll(false); // state depends on the contents only, should be initialized before processing

            List<String> allIncludes = new ArrayList<String>();

            for (Map.Entry<IDMProject, TransferToStreamOperationData> entry : deliverOperations.entrySet()) {
                IDMProject dmProject = entry.getKey();
                if (sbmc == null) {
                    this.sbmc = dmProject.getConnection().getSBMConnection();
                    if (sbmc != null) {
                        this.actionDetails = new HashMap<IResource, ActionDetails>();
                    }
                }

                TransferToStreamOperationData commandData = entry.getValue();
                List<WorkspaceResourceRequest> shelveList = commandData.getRequests();

                IdeProjectShelveBucket shelveBucket = new IdeProjectShelveBucket(shelveList, commandData);
                multiDetails.addProjectToTransfer(shelveBucket);
                buckets.add(shelveBucket);

                if (StringPath.isNullorEmpty(multiDetails.getUserDirectory())) {
                    multiDetails.setUserDirectory(dmProject.getUserDirectory().toOSString());
                }

                if (StringPath.isNullorEmpty(multiDetails.getComment())) {
                    multiDetails.setComment(shelveBucket.getComment());
                }

                if (!multiDetails.getAll()) {
                    // all true for all buckets if any child bucket should send all items
                    multiDetails.setAll(shelveBucket.isAll());
                }

                multiDetails.getAttributeMap().putAll(shelveBucket.getAttributeMap());

                String includes = shelveBucket.getShelveIncludes();
                if (includes.length() > 0) {
                    allIncludes.add(includes);
                }
            }

            if (allIncludes.size() > 0) {
                multiDetails.setShelveIncludes(StringPath.join(allIncludes, ","));//$NON-NLS-1$
            }

            multiDetails.setWorkareaType(transferData.getWorkareaType());
            multiDetails.setVerbose(true);
            multiDetails.setXmlMode(true);
            multiDetails.setXmlExecute(true);
            Assert.isLegal(shelfDetails != null);
            this.shelfName = shelfDetails.getProductName() + ':' + shelfDetails.getName();
            multiDetails.setShelfName(shelfName);
            multiDetails.setShelfDescription(shelfDetails.getDescription());
            multiDetails.setDefaultBranch(shelfDetails.getDefaultBranch());
        } finally {
            monitor.done();
        }
    }

    private void shelve(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            Session session = transferData.getAnyProject().getConnection().openSession(Utils.subMonitorFor(monitor, 50));
            TransferMonitor tMonitor = new TransferMonitor(Utils.subMonitorFor(monitor, 950), TransferMonitor.UP);
            multiDetails.setListener(tMonitor);
            multiDetails.setCancelMonitor(tMonitor);

            int requestsSize = transferData.getRequestsSize();
            String msg = requestsSize == 1 ? NLS.bind(Messages.ShelveBucket_1, String.valueOf(requestsSize)) : NLS.bind(
                    Messages.ShelveBucket_0, requestsSize);

            if (debug) {
                System.out.println("+ Shelving over " + buckets.size() + " buckets"); //$NON-NLS-1$ //$NON-NLS-2$
                System.out.println(buckets);
            }

            final Project project = (Project) transferData.getAnyProject().getDimensionsObject();
            session.run(new APIOperation(msg) {
                @Override
                protected DimensionsResult doRun() throws Exception {
                    project.shelve(multiDetails);
                    return assembleResult(buckets);
                }

                private DimensionsResult assembleResult(List<IdeProjectShelveBucket> buckets) {
                    StringBuilder sb = new StringBuilder();
                    for (IdeProjectShelveBucket ideProject : buckets) {
                        sb.append(ideProject.assembleResult());
                        List<ObjectToTransfer> transferResults = ideProject.getTransferResults();
                        fillStatusMap(transferResults, statusMap);
                    }
                    return new DimensionsResult(sb.toString());
                }
            }, monitor);

            if (debug) {
                System.out.println("- done"); //$NON-NLS-1$
            }
        } finally {
            monitor.done();
        }
    }

    private void afterShelve(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 250);
        try {
            DimensionsConnectionDetailsEx connection = transferData.getAnyProject().getConnection();
            final Session session = connection.openSession(Utils.subMonitorFor(monitor, 50));

            if (shelfDetails.isFavourite()) {
                final Unit<Project> dto = new Unit<Project>();
                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        Project project = session.getObjectFactory().getProject(shelfName);
                        project.queryAttribute(WorksetList.DEFAULT_ATTRIBUTES);
                        dto.setValue(project);
                    }
                }, Utils.subMonitorFor(monitor, 100));
                IFavouriteObject adapter = new WorksetAdapter(dto.getValue(), connection);

                List<IFavouriteObject> adding = Collections.singletonList(adapter);
                FavouriteProjectsList list = WorksetList.getFavouriteProjectsList(connection, connection.isOnlyStreamsActive(),
                        connection.isOnlyProjectsActive());
                list.addFavourites(adding, Utils.subMonitorFor(monitor, 100));
            }

            if (sbmc != null && actionDetails != null) {
                for (IdeProjectShelveBucket bucket : buckets) {
                    List<WorkspaceResourceRequest> contents = bucket.getContents();
                    for (WorkspaceResourceRequest request : contents) {
                        if (request instanceof UploadRequest) {
                            processSbmActionDetails(request);
                        }
                    }
                }

                // associate in SBM, if necessary
                if (!actionDetails.isEmpty()) {
                    ActionDetails[] actions = actionDetails.values().toArray(new ActionDetails[actionDetails.size()]);
                    AssociateInput ai = new AssociateInput(actions, null);
                    ISBMManager sbmManager = sbmc.getSBMManager();
                    sbmManager.associate(ai, null);
                }
            }
        } finally {
            monitor.done();
        }
    }

    private void processSbmActionDetails(WorkspaceResourceRequest request) throws CoreException {
        IFile file = ((UploadRequest) request).getFile();
        ObjectToTransfer status = DeliverHelper.getTransferObjectFromStatusMap(statusMap, file);
        if (status == null || !status.getCmdStatus()) {
            actionDetails.remove(file);
        }
        if (ObjectToTransfer.STATUS_UNRESOLVED.equals(status.getStatus())) {
            actionDetails.remove(file);
        }
        if (ObjectToTransfer.STATUS_ERROR.equals(status.getStatus())) {
            actionDetails.remove(file);
        }

        // obtain resulting revision if need to send to SBM
        if (actionDetails != null) {
            ActionDetails aDetails = actionDetails.get(request.getResource());
            if (aDetails != null) {
                BaseMetadata bm = WorkspaceMetadataManager.getInstance().getMetadata(file);
                if (bm instanceof ItemMetadata) {
                    String itemSpec = ((ItemMetadata) bm).getItemSpec();
                    if (itemSpec != null) {
                        aDetails.setPath(TeamUtils.getFullSbmFilename(aDetails.getPath(), itemSpec, false));
                        aDetails.setNewRevision(TeamUtils.extractRevisionFromSpec(itemSpec));
                    }
                }
            }
        }

    }

    void fillStatusMap(List<ObjectToTransfer> transferResults, Map<String, ObjectToTransfer> statusMap) {
        for (ObjectToTransfer fileDetails : transferResults) {
            statusMap.put(fileDetails.getFileName(), fileDetails);
            addError(fileDetails);
        }
    }

    @Override
    public boolean modifiesRemote() {
        return false;
    }

    @Override
    protected String getErrorMessage(IStatus[] errors) {
        return Messages.UploadCommand_0;
    }

    @Override
    public IResource[] getChanges() {
        return new IResource[0];
    }

    @Override
    public void setChanges(IResource[] changes) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<String, ObjectToTransfer> getStatusMap() {
        return statusMap;
    }

    @Override
    public Map<IResource, ActionDetails> getActionDetails() {
        return actionDetails;
    }

    public void setShelfDetails(ShelfDetails shelfDetails) {
        this.shelfDetails = shelfDetails;
    }
}

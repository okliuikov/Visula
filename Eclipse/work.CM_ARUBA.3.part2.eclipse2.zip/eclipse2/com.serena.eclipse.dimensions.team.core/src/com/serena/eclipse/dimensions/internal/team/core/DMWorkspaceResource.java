/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.PlatformObject;
import org.eclipse.team.core.TeamException;

import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
abstract class DMWorkspaceResource extends PlatformObject implements IDMWorkspaceResource { 
    private IResource resource;
    private IResource virtualResource;
    private IDMProject project;
    private IDMRemoteResource base;
    private IDMRemoteResource remote;
    private boolean baseCached;
    private boolean remoteCached;
    private boolean cacheVariants;

    /**
     * @param resource
     *            the resource from workspace project
     * @param project
     *            the dimensions project which is mapped to the workspace project
     * @param virtualResource
     *            the original resource that is relative to the {@link VirtualIdmProject} or null
     */
    public DMWorkspaceResource(IResource resource, IDMProject project, IResource virtualResource) {
        Assert.isNotNull(resource);
        Assert.isNotNull(project);
        this.resource = resource;
        this.project = project;
        if (!virtualResource.equals(resource)) {
            this.virtualResource = virtualResource;
        }
    }

    @Override
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Object getAdapter(Class adapter) {
        if (adapter == IResource.class) {
            return resource;
        }
        return super.getAdapter(adapter);
    }

    @Override
    public IDMProject getProject() {
        return project;
    }

    @Override
    public void setProject(IDMProject project) {
        if (this.project == null) {
            this.project = project;
        }
    }

    @Override
    public IResource getLocalResource() {
        return resource;
    }

    @Override
    public String getName() {
        return resource.getName();
    }

    @Override
    public IDMRemoteResource getBaseResource() throws TeamException {
        if (cacheVariants) {
            if (!baseCached) {
                base = DMTeamPlugin.getWorkspace().getBaseResource(resource);
                baseCached = true;
            }
            return base;
        }
        return DMTeamPlugin.getWorkspace().getBaseResource(resource);
    }

    @Override
    public IDMRemoteResource getRemoteResource() throws TeamException {
        if (cacheVariants) {
            if (!remoteCached) {
                remote = DMTeamPlugin.getWorkspace().getRemoteResource(resource);
                remoteCached = true;
            }
            return remote;
        }
        return DMTeamPlugin.getWorkspace().getRemoteResource(resource);
    }

    @Override
    public void flushCachedVariants() {
        baseCached = remoteCached = false;
        base = remote = null;
    }

    @Override
    public void setCacheVariants(boolean b) {
        this.cacheVariants = b;
        if (!b) {
            flushCachedVariants();
        }
    }

    @Override
    public boolean isIgnored() throws TeamException {
        return DMTeamPlugin.getWorkspace().isIgnored(getLocalResource());
    }

    @Override
    public boolean isIgnored(MetadataProvider provider) throws TeamException {
        return DMTeamPlugin.getWorkspace().isIgnored(getLocalResource(), provider);
    }

    @Override
    public boolean isMoved() throws CoreException {
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).isMoved(getLocalResource());
    }

    @Override
    public IResource getMovedFrom() throws CoreException {
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).getMovedFrom(resource);
    }

    @Override
    public IResource getMovedTo() throws CoreException {
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).getMovedTo(resource);
    }

    @Override
    public boolean isManaged() throws TeamException {
        return DMTeamPlugin.getWorkspace().isManaged(getLocalResource());
    }

    @Override
    public boolean hasRemote() throws TeamException {
        return DMTeamPlugin.getWorkspace().hasRemote(getLocalResource());
    }

    @Override
    public boolean exists() {
        return getLocalResource().exists();
    }

    @Override
    public void unmanage(IProgressMonitor progress) throws CoreException {
        DMTeamPlugin.getWorkspace().unmanage(getLocalResource(), progress);
    }

    @Override
    public void makeIncoming() throws CoreException {
        DMTeamPlugin.getWorkspace().makeIncoming(getLocalResource());
    }

    @Override
    public IDMProject getMovedFromProject() throws CoreException {
        IResource source = getMovedFrom();
        if (source == null) {
            return null;
        }
        IDMProject srcProject = DMTeamPlugin.getWorkspace().getProject(source);
        if (srcProject != null && project.remoteEquals(srcProject, false)) {
            return null;
        }
        return srcProject;
    }

    @Override
    public boolean isMovedCrossProject() throws CoreException {
        return getMovedFromProject() != null;
    }

    @Override
    public IResource getMovedInRepositoryFrom() throws CoreException {
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).getMovedInRepositoryFrom(resource);
    }

    @Override
    public IResource getMovedInRepositoryTo() throws CoreException {
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).getMovedInRepositoryTo(resource);
    }

    @Override
    public boolean isMovedInRepository() throws CoreException {
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).isMovedInRepository(getLocalResource());
    }

    @Override
    public IResource geVirtualResource() throws TeamException {
        return virtualResource;
    }

}

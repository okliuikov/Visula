package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmfile.progress.StateProgressListener;

public class StateRehomeMonitor extends TransferMonitor implements StateProgressListener {

    private int stateStep = total / 10;
    protected String stageName = "";

    public StateRehomeMonitor(IProgressMonitor monitor) {
        super(null, monitor, DOWN);
    }

    @Override
    public void start(long totalWorkUnits) {
        super.start(totalWorkUnits);
    }

    @Override
    public void end() {
    	//do nothing. we don't call parent method
    }

    @Override
    public void processed(long workUnits) {
        mainProgress.worked((int)workUnits);
    }

    @Override
    public void startFile(String filename) {
        mainProgress.setTaskName(stageName + ": " + filename);
    }

    @Override
    public void endFile(String filename, int status) {
        mainProgress.setTaskName(stageName);
    }

    @Override
    public void startStateUnit(int id) {
        worked += stateStep;
        mainProgress.worked(stateStep);
        switch (id) {
            case 1: 
                stageName = Messages.StateTransferMonitor_1;
                break;
            case 2: 
                stageName = Messages.StateTransferMonitor_2;
                break;
            case 3: 
                stageName = Messages.StateTransferMonitor_3;
                break;
            case 4: 
                stageName = Messages.StateTransferMonitor_4;
                break;
            default:
                stageName = Messages.RehomeMonitor_1;
        }
        mainProgress.setTaskName(stageName);
    }

    @Override
    public void endStateUnit(int id, int status) {
    }

    @Override
    public void startStateProgress(long totalStatusUnits) {
        if (!mainProgressStarted) {
            mainProgress.beginTask(task, total);
            mainProgressStarted = true;
            mainProgress.setTaskName(Messages.RehomeMonitor_1);
        }
    }

    //This is called when we pass 4 stages. 
    //Server don't send messages about next one's so we can think we are on applying stage. 
    @Override
    public void endStateProgress() {
        stageName = Messages.RehomeMonitor_2;
        mainProgress.setTaskName(stageName);
    }
}
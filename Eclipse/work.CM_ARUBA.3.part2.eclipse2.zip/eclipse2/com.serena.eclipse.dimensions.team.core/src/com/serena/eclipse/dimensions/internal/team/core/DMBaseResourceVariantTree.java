/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.variants.IResourceVariant;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Variant tree for workspace base resources, tracks DM metadata.
 *
 * @author V.Grishchenko
 */
class DMBaseResourceVariantTree extends DMResourceVariantTree { 

    private static boolean debugResources = DMTeamPlugin.getDefault().isDebuggingResources();

    public DMBaseResourceVariantTree(PersistentByteStore store, Subscriber subscriber) {
        super(store, subscriber);
    }

    @Override
    protected boolean setVariant(IResource local, IResourceVariant remote) throws TeamException {
        return super.setVariant(local, remote);
    }

    @Override
    public void dispose() {
        super.dispose();
    }

    /**
     * Tells this tree that it is ok to release any information for this
     * Resource during refresh.
     */
    public void prepareForDeletion(IResource resource) throws CoreException {
        if (debugResources) {
            System.out.println("DBRVT prepare deletion " + resource.toString());
        }
        PersistentByteStore byteStore = (PersistentByteStore) getByteStore();
        IResource[] members = byteStore.members(resource);
        for (int i = 0; i < members.length; i++) {
            prepareForDeletion(members[i]);
        }
        byteStore.prepareForDeletion(resource);
    }

    @Override
    public List<IDMRemoteResource> fetchFolderMembers(IDMRemoteFolder folder, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        monitor.subTask(Messages.BaseTree_readingMetadata);

        try {
            WorkspaceMetadataManager manager = WorkspaceMetadataManager.getInstance();
            IResource[] members = WorkspaceMetadataManager.getMembers((IContainer) folder.getLocalResource(), false);
            monitor.worked(300);
            List<IDMRemoteResource> result = new ArrayList<IDMRemoteResource>();
            if (members.length == 0) {
                return result;
            }
            IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 700);
            subMonitor.beginTask(null, members.length);
            for (int i = 0; i < members.length; i++) {
                // optimize to avoid reading of unchanged metadata
                IDMRemoteResource currentResource = (IDMRemoteResource) getResourceVariant(members[i]);
                if (currentResource != null && !currentResource.isStale()) {
                    if (debugResources) {
                        System.out.println(TeamUtils.myThread() + " dmbrvt fFM !stale " + members[i].getLocation().toOSString());
                    }
                    result.add(currentResource);
                } else {
                    if (debugResources) {
                        System.out
                                .println(TeamUtils.myThread() + " dmbrvt fFM stale reread" + members[i].getLocation().toOSString());
                    }
                    BaseMetadata metadata = manager.getMetadata(members[i]);
                    IPath memberPath = folder.getPath().append(members[i].getName());
                    if (metadata instanceof ItemMetadata) {
                        DMRemoteFile remoteFile = new DMRemoteFile((DMRemoteFolder) folder, memberPath, folder.getProject(), this,
                                (ItemMetadata) metadata, 0L);
                        result.add(remoteFile);
                    } else if (metadata instanceof DirectoryMetadata) {
                        DMRemoteFolder remoteFolder = new DMRemoteFolder((DMRemoteFolder) folder, memberPath, folder.getProject(),
                                this, (DirectoryMetadata) metadata, 0L);
                        result.add(remoteFolder);
                    }
                }
                subMonitor.worked(1);
            }
            subMonitor.done();
            return result;
        } finally {
            monitor.done();
        }
    }

    @Override
    protected IResourceVariant fetchVariant(IResource resource, int depth, IProgressMonitor monitor) throws TeamException {
        if (resource == null) {
            return null;
        }

        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        monitor.subTask(Messages.BaseTree_readingMetadata);
        if (debugResources) {
            System.out.println(TeamUtils.myThread() + " DBRVT fV " + resource.getLocation().toOSString());
        }
        try {
            IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(resource);// provider.getDMProject();
            if (dmProject == null) {
                return null;
            }
            IPath remoteRelativePath = dmProject.getRemotePathForLocalResource(resource);
            if (resource.getType() == IResource.PROJECT) {
                return new DMRemoteFolder(null, remoteRelativePath, dmProject, this);
            }
            // replace file check with provider check
            MetadataProvider mdp = MetadataProviderFactory.providerFor(resource);
            if (mdp != null) {
                try {
                    if (!mdp.metadataExists(resource.getType() == IResource.FILE ? MetadataTypes.MT_ITEM : MetadataTypes.MT_DIR,
                            resource.getLocation().toOSString())) {
                        return null;
                    }
                } finally {
                    mdp.close();
                }
            }

            // optimize to avoid reading of unchanged metadata
            IDMRemoteResource currentResource = (IDMRemoteResource) getResourceVariant(resource);

            if (currentResource != null && !currentResource.isStale()) {
                if (debugResources) {
                    System.out.println(TeamUtils.myThread() + "DBRVT fV !stale " + currentResource.getPath().toOSString());
                }
                return currentResource;
            }

            WorkspaceMetadataManager manager = WorkspaceMetadataManager.getInstance();
            BaseMetadata metadata = manager.getMetadata(resource);
            if (debugResources) {
                System.out.println(TeamUtils.myThread() + " DBRVT fV stale reread " + resource.getLocation().toOSString());
            }
            if (metadata instanceof ItemMetadata) {
                DMRemoteFile remoteFile = new DMRemoteFile(null, remoteRelativePath, dmProject, this, (ItemMetadata) metadata, 0L);
                return remoteFile;
            }

            if (metadata instanceof DirectoryMetadata) {
                DMRemoteFolder remoteFolder = new DMRemoteFolder(null, remoteRelativePath, dmProject, this,
                        (DirectoryMetadata) metadata, 0L);
                return remoteFolder;
            }
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        } finally {
            monitor.done();
        }

        return null;
    }
}
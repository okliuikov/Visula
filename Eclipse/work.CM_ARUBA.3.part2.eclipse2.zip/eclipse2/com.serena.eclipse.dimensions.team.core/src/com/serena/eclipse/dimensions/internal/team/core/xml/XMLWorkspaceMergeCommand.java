/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsCancellationException;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Filter.Criterion;
import com.serena.dmclient.api.MergeCommandDetails;
import com.serena.dmclient.api.MergeCommonCommandDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.UpdateLocalCommandDetails;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.IResourceFilter;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.sync.SyncConstants.ObjectClass;
import com.serena.dmfile.sync.SyncMode;
import com.serena.dmfile.xml.Action;
import com.serena.dmfile.xml.DetectedResolutions;
import com.serena.dmfile.xml.DetectedResolutionsContainer;
import com.serena.dmfile.xml.ExecutedResolutions;
import com.serena.dmfile.xml.Resolution;
import com.serena.dmfile.xml.WorkareaScanContainer;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.ContainmentComparator;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspaceBaseCommand1;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.Messages;
import com.serena.eclipse.dimensions.internal.team.core.StateTransferMonitor;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.TransferMonitor;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandOptions.MergeRequestsOptions;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandOptions.MergeWorksetOptions;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer.MergeType;

/**
 * Merge command that invokes merge using merge descriptor Applicable for NON_INTERACTIVE,
 * DETECT_RESOLUTIONS and EXECUTE_RESOLUTIONS modes
 */
public class XMLWorkspaceMergeCommand extends DMWorkspaceBaseCommand1 {
    private MergeExecutable exec;
    private XMLMergeDescriptor descriptor;
    private IPath workarea;
    private String commandMsg;
    private boolean silentFailed = false;
    private boolean wasDownloadCancelled = false;

    public XMLWorkspaceMergeCommand(XMLMergeDescriptor descriptor) {
        this.descriptor = descriptor;
        MergeType type = descriptor.getMergeType();
        if (type == MergeType.PROJECT) {
            this.exec = new WorksetMergeExecutable();
        } else if (type == MergeType.REQUEST) {
            this.exec = new RequestMergeExecutable();
        } else if (type == MergeType.BASELINE) {
            this.exec = new BaselineMergeExecutable();
        }

        SyncMode currentMergeMode = descriptor.getCurrentMergeMode();
        if (currentMergeMode == SyncMode.EXECUTE_RESOLUTIONS || currentMergeMode == SyncMode.NON_INTERACTIVE) {
            this.commandMsg = NLS.bind(Messages.DMXMLMergeCommand_task_execution_mode_subtask, descriptor.getTarget()
                    .getProject()
                    .getName());
        } else {
            this.commandMsg = NLS.bind(Messages.DMXMLMergeCommand_task_detection_mode_subtask, descriptor.getTarget()
                    .getProject()
                    .getName());
        }

        IDMProject target = descriptor.getTarget();
        if (target.isContainedEclipseProject() && target.isFullWorkArea()) {
            workarea = target.getWorkAreaPath();
        } else {
            workarea = target.getUserDirectory();
        }
    }

    /**
     * Executable that must perform real API operation
     */
    interface MergeExecutable {
        void execute(MergeCommonCommandDetails details, IProgressMonitor monitor) throws CoreException;
    }

    /**
     * Operation that performs merge execution and returns readable output status
     */
    private abstract class MergeAPIOperation extends APIOperation {
        protected MergeCommandOptions wopts;
        protected DimensionsResult result;
        private IProgressMonitor monitor;
        protected Session session;
        protected MergeCommonCommandDetails details;

        MergeAPIOperation(String message, IProgressMonitor monitor, MergeCommandOptions wopts, Session session,
                MergeCommonCommandDetails details) {
            super(message);
            this.monitor = monitor;
            this.wopts = wopts;
            this.session = session;
            this.details = details;
        }

        @Override
        @SuppressWarnings("unchecked")
        public IStatus getStatus() {
            if (result == null || result.getResultList() == null) {
                return super.getStatus();
            }

            List<String> resultList = result.getResultList();
            StringBuilder sb = new StringBuilder();
            for (String msg : resultList) {
                sb.append(msg).append("\n");
            }

            return new Status(IStatus.OK, DMTeamPlugin.ID, sb.toString());
        }

        @Override
        public void run() throws Exception {
            try {
                DimensionsResult dimensionsResult = doRun();
                status = new Status(IStatus.OK, getPluginId(), 0, dimensionsResult.getMessage(), null);
            } catch (DimensionsCancellationException e) {
                status = new Status(IStatus.WARNING, getPluginId(), 0, e.getMessage(), e);
            } finally {
                if (monitor != null && monitor.isCanceled()) {
                    setDownloadCancelled(true);
                }
            }
        }
    }

    private class ProjectMergeAPIOperation extends MergeAPIOperation {
        public ProjectMergeAPIOperation(String commandMsg, IProgressMonitor monitor, MergeCommandOptions wopts, Session session,
                MergeCommonCommandDetails details) {
            super(commandMsg, monitor, wopts, session, details);
        }

        @Override
        protected DimensionsResult doRun() throws Exception {
            DimensionsConnectionDetailsEx conn = session.getConnectionDetails();
            VersionManagementProject sourceWorkset = wopts.getSourceWorkset();
            Assert.isNotNull(sourceWorkset);
            Object cached = wopts.getSourceWorkset().getAPIObject();
            boolean exists = false;
            if (cached instanceof Project) {
                // query source project because cached information can be out of date
                Project project = session.getObjectFactory().getProject(sourceWorkset.getObjectSpec());
                if (project != null) {
                    project.queryAttribute(SystemAttributes.WSET_IS_STREAM);
                    wopts.setSourceWorkset(new WorksetAdapter(project, conn));
                    this.result = project.download(details);
                    exists = true;
                }
            }

            if (result == null || !exists) {
                throw new CoreException(new Status(IStatus.WARNING, DMTeamPlugin.ID, NLS.bind(
                        Messages.DMXMLMergeCommand_project_source_not_found, wopts.getSourceWorksetSpec())));
            }
            return result;
        }
    }

    private class BaselineMergeAPIOperation extends MergeAPIOperation {
        public BaselineMergeAPIOperation(String commandMsg, IProgressMonitor monitor, MergeWorksetOptions wopts, Session session,
                MergeCommonCommandDetails details) {
            super(commandMsg, monitor, wopts, session, details);
        }

        @Override
        @SuppressWarnings("unchecked")
        protected DimensionsResult doRun() throws Exception {
            DimensionsConnectionDetailsEx conn = session.getConnectionDetails();
            VersionManagementProject sourceWorkset = wopts.getSourceWorkset();
            Assert.isNotNull(sourceWorkset);
            Object cached = wopts.getSourceWorkset().getAPIObject();
            boolean exists = false;
            if (cached instanceof Baseline) {
                // query source baseline because cached information can be out of date
                Filter filter = new Filter();
                Criterion criterion = new Filter.Criterion(SystemAttributes.OBJECT_SPEC, sourceWorkset.getObjectSpec(),
                        Filter.Criterion.EQUALS);
                filter.criteria().add(criterion);

                List<?> baselines = session.getObjectFactory().getBaselines(filter);
                if (!baselines.isEmpty() && baselines.get(0) != null) {
                    Baseline baseline = (Baseline) baselines.get(0);
                    wopts.setSourceWorkset(new BaselineAdapter(baseline, conn));
                    this.result = baseline.download(details);
                    exists = true;
                }
            }

            if (result == null || !exists) {
                throw new CoreException(new Status(IStatus.WARNING, DMTeamPlugin.ID, NLS.bind(
                        Messages.DMXMLMergeCommand_baseline_source_not_found, wopts.getSourceWorksetSpec())));
            }
            return result;
        }
    }

    /**
     * Executes merge using remote project
     */
    private class WorksetMergeExecutable implements MergeExecutable {

        @Override
        public void execute(final MergeCommonCommandDetails details, IProgressMonitor monitor) throws CoreException {
            final MergeWorksetOptions wopts = (MergeWorksetOptions) descriptor.getMergeOptions();
            if (wopts.getChangeSet() != null) {
                details.setTreeVersion((int) wopts.getChangeSet().getRepositoryVersion().getTreeVersion());
            }

            if (wopts.isDoUpdate() && details instanceof UpdateLocalCommandDetails) {
                UpdateLocalCommandDetails uDet = (UpdateLocalCommandDetails) details;
                uDet.setReset(wopts.isReset());
                uDet.setClean(wopts.isClean());
            }

            final Session session = descriptor.getTarget().getConnection().openSession(monitor);
            monitor.subTask(commandMsg);
            session.run(new ProjectMergeAPIOperation(commandMsg, monitor, wopts, session, details), monitor);
        }

    }

    /**
     * Executes merge using remote baseline
     */
    private class BaselineMergeExecutable implements MergeExecutable {
        @Override
        public void execute(final MergeCommonCommandDetails details, IProgressMonitor monitor) throws CoreException {
            final MergeWorksetOptions wopts = (MergeWorksetOptions) descriptor.getMergeOptions();
            final Session session = descriptor.getTarget().getConnection().openSession(monitor);

            monitor.subTask(commandMsg);
            session.run(new BaselineMergeAPIOperation(commandMsg, monitor, wopts, session, details), monitor);
        }
    }

    /**
     * Executes merge using request
     */
    private class RequestMergeExecutable implements MergeExecutable {
        @Override
        public void execute(final MergeCommonCommandDetails details, IProgressMonitor monitor) throws CoreException {
            final MergeRequestsOptions wopts = (MergeRequestsOptions) descriptor.getMergeOptions();
            final Session session = descriptor.getTarget().getConnection().openSession(monitor);

            if (wopts.getSourceRequests() == null || wopts.getSourceRequests().size() == 0) {
                throw new CoreException(new Status(IStatus.WARNING, DMTeamPlugin.ID,
                        Messages.DMXMLMergeCommand_request_source_is_empty));
            }

            details.setRequests(wopts.getSourceRequests());
            details.setCancelTraverse(!wopts.isIncludeRealtedItems());
            if (!wopts.isDoUpdate()) {
                details.setCherrypick(wopts.isCherrypick());
            } else {
                details.setCherrypick(false);
            }

            monitor.subTask(commandMsg);
            session.run(new ProjectMergeAPIOperation(commandMsg, monitor, wopts, session, details), monitor);
        }
    }

    @Override
    protected void execute(final IProgressMonitor monitor) throws CoreException {
        MergeCommonCommandDetails det = descriptor.getCommandDetails();
        try {
            int total = 1000;
            int worked = 0;
            monitor.beginTask(null, total);
            if (det != null) {
                Assert.isLegal(descriptor.getCurrentMergeMode() == SyncMode.EXECUTE_RESOLUTIONS
                        || descriptor.getCurrentMergeMode() == SyncMode.DETECT_RESOLUTIONS);
            } else {
                // first execution of merge for current descriptor
                Assert.isLegal(descriptor.getCurrentMergeMode() == SyncMode.NON_INTERACTIVE
                        || descriptor.getCurrentMergeMode() == SyncMode.DETECT_RESOLUTIONS);
                if (descriptor.getMergeOptions().isDoUpdate()) {
                    det = new UpdateLocalCommandDetails();
                    MergeCommandOptions mergeCommandOptions = descriptor.getMergeOptions();
                    if (mergeCommandOptions instanceof MergeWorksetOptions) {
                        MergeWorksetOptions mergeWorksetOptions = (MergeWorksetOptions) mergeCommandOptions;
                        ((UpdateLocalCommandDetails) det).setUndo(mergeWorksetOptions.isUndo());
                    }
                } else {
                    det = new MergeCommandDetails();
                }
                det.setXmlMode(Boolean.TRUE);
                det.setMergeMode(descriptor.getCurrentMergeMode());

                if (descriptor.getMergeOptions().isLoggingEnabled()) {
                    IPath logPath = descriptor.getMergeOptions().getLoggingPath();
                    det.setLogDir(logPath.toFile());
                }

                descriptor.setCommandDetails(det);
            }

            if (workarea != null) {
                fillDetailsPathInfo(det);
            }

            if (descriptor.getCurrentMergeMode() != SyncMode.DETECT_RESOLUTIONS) {
                if (descriptor.getMergeOptions().isDoUpdate()) {
                    det.setExpand(descriptor.getMergeOptions().isExpandSubstitution());
                } else {
                    det.setExpand(false);
                }
            } else {
                det.setExpand(false);
            }

            det.setPerms(null);

            if (descriptor.getCurrentMergeMode() != SyncMode.DETECT_RESOLUTIONS) {
                det.setTouch(!descriptor.getMergeOptions().isApplyRepositoryDateTime());
            } else {
                det.setTouch(null);
            }

            if (descriptor.getCurrentMergeMode() != SyncMode.EXECUTE_RESOLUTIONS) {
                det.setAutoMerge(descriptor.getMergeOptions().isAutoMerge());
            } else {
                det.setAutoMerge(false);
            }

            if (workarea == null) {
                if (det != null && det.getDetectedResolutions() != null) {
                    det.getDetectedResolutions().setResolutions(null);
                }
                return;
            }

            if (descriptor.getCurrentMergeMode() != SyncMode.EXECUTE_RESOLUTIONS) {
                monitor.subTask(commandMsg + ": " + Messages.DMXMLMergeCommand_task_scan_mode_subtask);//$NON-NLS-1$
                WorkareaScanContainer scan = performScan(Utils.subMonitorFor(monitor, worked += 100));
                det.setWorkAreaScan(scan);
                if (scan == null && det.getDetectedResolutions() != null) {
                    // nothing was scanned, nothing to resolve
                    det.getDetectedResolutions().setResolutions(null);
                    return;
                }
            }

            StateTransferMonitor tm = new StateTransferMonitor(Utils.subMonitorFor(monitor, Math.abs(total - worked)),
                    TransferMonitor.DOWN);
            det.setCancelMonitor(tm);
            det.setListener(tm);

            exec.execute(det, monitor);

            if (descriptor.getCurrentMergeMode() == SyncMode.EXECUTE_RESOLUTIONS) {
                descriptor.setExecuted(true);
            }

            DetectedResolutionsContainer container = det.getDetectedResolutionsContainer();
            DetectedResolutions detected = det.getDetectedResolutions();
            ExecutedResolutions executed = det.getExecutedResolutions();

            if (descriptor.getCurrentMergeMode() == SyncMode.NON_INTERACTIVE && !wasDownloadCancelled()) {
                if (((executed == null && detected != null) || (container != null && container.hasFailedExecutions()))) {
                    // if execution is empty but detected was not empty or failed executions were
                    // detected we should switch context to DETECT mode
                    descriptor.setCurrentMode(SyncMode.DETECT_RESOLUTIONS);
                    this.silentFailed = true;
                }
            }
            Set<IProject> projectsToDelete = new HashSet<IProject>();
            if (descriptor.getCurrentMergeMode() == SyncMode.NON_INTERACTIVE) {
                List<Resolution> resolutions = detected.getResolutions();
                for (Resolution currentResolution : resolutions) {
                    ResourceResolutionWrapper resourceResolutionWrapper = new ResourceResolutionWrapper(currentResolution,
                            descriptor);
                    addProjectsToDelete(resourceResolutionWrapper, projectsToDelete);
                }
            }
            for (IProject currentProject : projectsToDelete) {
                currentProject.delete(false, true, null);
            }
        } finally {
            monitor.done();
        }

    }

    private static void addProjectsToDelete(IResourceResolutionWrapper resourceResolutionWrapper, Set<IProject> projectsToDelete) {
        if (resourceResolutionWrapper.isIncomingDeletion()) {
            IResource currentResource = resourceResolutionWrapper.getResource();
            if (currentResource != null) {
                if (currentResource.getType() != IResource.FILE) {
                    projectsToDelete.addAll(TeamUtils.getAllProjectsForLocation(currentResource));
                } else if (".project".equals(currentResource.getName())) {
                    IContainer projectCandidate = TeamUtils.getProject(currentResource.getParent());
                    if (projectCandidate.getType() == IResource.PROJECT) {
                        projectsToDelete.add((IProject) projectCandidate);
                    }
                }
            }
        }
    }

    public static void addProjectsToDelete(XMLSyncInfo info, Set<IProject> projectsToDelete) {
        SyncInfoResourceResolutionWrapper wrapper = new SyncInfoResourceResolutionWrapper(info);
        addProjectsToDelete(wrapper, projectsToDelete);
    }

    public static void addProjectsToDelete(IResource resource, Set<IProject> projectsToDelete) {
        ResourceResolutionWrapperForIncomingDeletion wrapper = new ResourceResolutionWrapperForIncomingDeletion(resource);
        addProjectsToDelete(wrapper, projectsToDelete);
    }

    /**
     * @return scan results for any sharing type
     */
    private WorkareaScanContainer performScan(IProgressMonitor monitor) {
        WorkareaScanContainer result = null;

        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        IResourceFilter resourceFilter = new DerivedResourceFilter(TeamUtils.isDerivedResourcesIgnored());
        try {
            if (descriptor.hasScope()) {
                List<IResource> baseScopes = descriptor.getScope();
                if (baseScopes.size() == 1 && baseScopes.get(0) instanceof IFolder) {
                    if (!baseScopes.get(0).exists()) {
                        return null;
                    }
                    // one nested folder selected
                    result = ObjectToTransfer.scanWorkArea(workarea.toOSString(), createFullPath(baseScopes.get(0)).toOSString(),
                            resourceFilter);
                } else {
                    // list of resources was selected
                    List<String> correctedScopes = new ArrayList<String>();
                    for (IResource res : baseScopes) {
                        if (res.exists()) {
                            correctedScopes.add(createFullPath(res).toOSString());
                        }
                    }
                    if (correctedScopes.size() > 0) {
                        result = ObjectToTransfer.scanWorkArea(workarea.toOSString(), correctedScopes, resourceFilter);
                    }
                }
            } else {
                // root project node was selected
                result = ObjectToTransfer.scanWorkArea(workarea.toOSString(), createFullPath(null).toOSString(), resourceFilter);
            }
        } finally {
            monitor.done();
        }

        return result;
    }

    /**
     * @return full absolute path for resource
     */
    private IPath createFullPath(IResource resource) {
        IDMProject target = descriptor.getTarget();
        if (target.isContainedEclipseProject() && target.isFullWorkArea()) {
            return workarea.append(target.getRemoteOffset()).append(resource != null ? resource.getProjectRelativePath() : null);
        } else {
            return workarea.append(resource != null ? resource.getProjectRelativePath() : null);
        }

    }

    /**
     * Fills the command parameters: directory, workarea location, relative location
     */
    private void fillDetailsPathInfo(MergeCommonCommandDetails det) {
        IDMProject target = descriptor.getTarget();
        det.setUserDirectory(workarea.toOSString());

        IPath dirScope = null;
        if (descriptor.hasScope()) {
            if (descriptor.getScope().size() == 1 && descriptor.getScope().get(0) instanceof IFolder) {
                dirScope = createFullPath(descriptor.getScope().get(0));
            }
        }

        if (dirScope == null && target.isContainedEclipseProject() && target.isFullWorkArea()) {
            dirScope = workarea.append(target.getRemoteOffset());
        }

        if (dirScope != null) {
            det.setDirectory(dirScope.toOSString());
        } else {
            det.setDirectory(null);
        }

        if (target.isContainedEclipseProject() && !target.isFullWorkArea()) {
            det.setRelativeLocation(target.getRemoteOffset().toOSString());
        } else {
            det.setRelativeLocation(null);
        }

    }

    @Override
    public ISchedulingRule getSchedulingRule() throws CoreException {
        List<IResource> rulesList = new ArrayList<IResource>();

        rulesList.add(descriptor.getTarget().getProject());

        if (descriptor.hasScope()) {
            for (IResource resource : descriptor.getScope()) {
                rulesList.add(resource);
            }
        }

        return new MultiRule(rulesList.toArray(new IResource[rulesList.size()]));
    }

    @Override
    public boolean isValidSharing() throws CoreException {
        IDMProject target = descriptor.getTarget();
        return target.equals(getWorkspace().getProject(target.getProject()));
    }

    @Override
    public boolean modifiesBase() {
        if (descriptor.getCurrentMergeMode() != SyncMode.DETECT_RESOLUTIONS || silentFailed) {
            ExecutedResolutions executed = descriptor.getExecutedResolutions();
            if (executed != null && executed.getActionMap() != null && executed.getActionMap().size() > 0) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean modifiesRemote() {
        return modifiesBase();
    }

    @Override
    public IResource[] getBaseResourcesToRefresh() throws CoreException {
        Set<IResource> result = new HashSet<IResource>();
        final IDMProject target = descriptor.getTarget();

        ExecutedResolutions executedResolutions = descriptor.getExecutedResolutions();
        if (executedResolutions == null) {
            return new IResource[0];
        }

        Collection<Action> actions = executedResolutions.getActionMap().values();

        SortedSet<IResource> rawToRefresh = new TreeSet<IResource>(new ContainmentComparator());
        SortedSet<IResource> metadataChanges = new TreeSet<IResource>(new ContainmentComparator());

        for (Action action : actions) {

            if (action.getStatus() == null || !action.getStatus()) {
                continue;
            }

            boolean isFile = action.getObjClass() != ObjectClass.PCMS_DIRECTORY;
            IResource resource = TeamUtils.constructRelativeResource(action.getRelPath(), isFile, target);

            IResource fromMD = null;
            IResource fromXML = null;
            String movedFrom = action.getMovedFrom();
            if (!Utils.isNullEmpty(movedFrom)) {
                // construct resource from actions 'moved-from' field
                fromXML = TeamUtils.constructRelativeResource(movedFrom, isFile, target);

                // moved-from metadata entry
                String movedFromMD = getMovedFromMetadata(resource);

                // TODO: When server will be able to detect cross project moves
                // target project must be changed to correct source. In that case
                // registering from the root needs to be adjusted deeper regarding to the source
                // project
                if (!Utils.isNullEmpty(movedFromMD)) {
                    // construct resource from metadata 'moved-from' field
                    fromMD = TeamUtils.constructRelativeResource(movedFromMD, isFile, target);
                }
            }

            result.add(resource);

            if (fromMD != null) {
                // push 'dest' resource to the refresh list for re-registering moves
                rawToRefresh.add(resource);
                // push 'from' resource to the refresh list
                rawToRefresh.add(fromMD);

                IResource oldDest = getWorkspace().getMovedTo(fromMD);
                if (oldDest != null) {
                    // push old 'dest' resource to the refresh list
                    rawToRefresh.add(oldDest);
                }

                IResource oldFrom = getWorkspace().getMovedFrom(resource);
                if (oldFrom != null && !oldFrom.equals(fromMD)) {
                    // push old 'from' resource to the refresh list
                    rawToRefresh.add(oldFrom);
                }
            }

            if (fromXML != null && fromMD == null) {
                // push 'from' resource to the refresh list if it was received only from action
                rawToRefresh.add(fromXML);
            }
        }

        IResource[] toRefresh = TeamUtils.getNonOverlapping(rawToRefresh);

        for (int i = 0; i < toRefresh.length; i++) {
            IResource res = toRefresh[i];
            TeamUtils.refreshLocal(res, IResource.DEPTH_INFINITE, new NullProgressMonitor());

            // add resource to the result list for future remote refresh
            if (res.isAccessible()) {
                result.add(res);
            }

            // register cascade and non-cascade file/folder moves.
            if (res.isAccessible() && !res.isTeamPrivateMember()) {
                res.accept(new RegisterMovesVisitor(target, metadataChanges));
            }
        }

        getWorkspace().metadataChanged(TeamUtils.getNonOverlapping(metadataChanges), null);
        return result.toArray(new IResource[result.size()]);
    }

    private class RegisterMovesVisitor implements IResourceVisitor {
        private IDMProject project;
        // additional metadata changes that were found during tree traverse
        private SortedSet<IResource> metadataChanges = null;
        // private destination -> source cache to adjust cascade move resolutions
        private Map<IResource, IResource> movedDstSrc = new HashMap<IResource, IResource>();

        private RegisterMovesVisitor(IDMProject project, SortedSet<IResource> metadataChanges) {
            this.metadataChanges = metadataChanges;
            this.project = project;
        }

        public IResource getMovedFrom(IResource resource) throws CoreException {
            return movedDstSrc.get(resource);
        }

        @Override
        public boolean visit(IResource target) throws CoreException {
            if (target.isTeamPrivateMember()) {
                return false;
            }

            if (target instanceof IContainer) {
                IContainer metadataContainer = WorkspaceMetadataManager.getMetadataContainer((IContainer) target);
                try {
                    if (metadataContainer != null && !metadataContainer.isTeamPrivateMember()) {
                        metadataContainer.setTeamPrivateMember(true);
                    }
                } catch (CoreException e) {
                    DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING,
                            NLS.bind(Messages.MetaFilesDetected_TeamPrivate_Error, target.getFullPath()), e));
                }
            }

            String movedFrom = getMovedFromMetadata(target);
            String offset = project.getRemoteOffset().toOSString();
            boolean isFile = target.getType() == IResource.FILE;
            if (!Utils.isNullEmpty(movedFrom)) {
                // direct move case
                movedFrom = new Path(movedFrom).toOSString();
                movedFrom = project.isFullWorkArea() ? movedFrom : offset + File.separator + movedFrom;
            } else {
                // cascade move case
                IResource parentFrom = getMovedFrom(target.getParent());
                if (parentFrom != null) {
                    // cascade move is valid iff parent container was moved previously
                    String relPath = getRelPathFromMetadata(target);
                    relPath = new Path(relPath).toOSString();
                    relPath = project.isFullWorkArea() ? relPath : offset + File.separator + relPath;
                    IResource fromRelPath = TeamUtils.constructRelativeResource(relPath, isFile, project);

                    if (parentFrom.equals(fromRelPath.getParent())) {
                        movedFrom = relPath;
                    } else {
                        StringBuilder sb = new StringBuilder();
                        if (!Utils.isNullEmpty(offset)) {
                            sb.append(offset)
                                    .append(File.separator)
                                    .append(parentFrom.getFullPath().removeFirstSegments(1).toOSString())
                                    .append(File.separator)
                                    .append(fromRelPath.getName());
                        } else {
                            sb.append(parentFrom.getFullPath().removeFirstSegments(1).toOSString())
                                    .append(File.separator)
                                    .append(fromRelPath.getName());
                        }
                        movedFrom = sb.toString();
                    }
                }
            }

            if (movedFrom != null) {
                IResource from = TeamUtils.constructRelativeResource(movedFrom, isFile, project);

                IResource oldDest = getWorkspace().getMovedTo(from);
                if (oldDest != null && !hasMetadata(oldDest)) {
                    // if old dest resource doesn't have metadata remove fake record from base tree
                    // case: merge for rename&rename with use repository resolution
                    ((DMWorkspace) DMTeamPlugin.getWorkspace()).releaseBase(oldDest);
                    metadataChanges.add(oldDest);
                }

                IResource oldFrom = getWorkspace().getMovedFrom(target);
                if (oldFrom != null && !oldFrom.equals(from) && !hasMetadata(oldFrom)) {
                    // if old src resource doesn't have metadata remove fake record from base tree
                    // case: update for rename&rename conflict with use local resolution
                    ((DMWorkspace) DMTeamPlugin.getWorkspace()).releaseBase(oldFrom);
                    metadataChanges.add(oldFrom);
                }

                // cache current move locally
                movedDstSrc.put(target, from);

                if (!from.equals(target)) {
                    // put result to system cache
                    getWorkspace().registerMove(target, movedFrom, null, IDMProject.WORKSET, project.getConnection());
                }
            }

            if (isDirectory(target)) {
                return true;
            } else {
                return false;
            }
        }
    }

    private String getMovedFromMetadata(IResource resource) throws CoreException {
        WorkspaceMetadataManager m = WorkspaceMetadataManager.getInstance();
        BaseMetadata metadata = m.getMetadata(resource);

        String movedFrom = null;
        if (metadata != null) {
            if (metadata instanceof ItemMetadata) {
                ItemMetadata im = (ItemMetadata) metadata;
                movedFrom = im.getMovedFrom();
            } else if (metadata instanceof DirectoryMetadata) {
                DirectoryMetadata dm = (DirectoryMetadata) metadata;
                movedFrom = dm.getMovedFrom();
            }
        }
        return movedFrom;
    }

    private String getRelPathFromMetadata(IResource resource) throws CoreException {
        WorkspaceMetadataManager m = WorkspaceMetadataManager.getInstance();
        BaseMetadata metadata = m.getMetadata(resource);

        String relPath = null;
        if (metadata != null) {
            if (metadata instanceof ItemMetadata) {
                ItemMetadata im = (ItemMetadata) metadata;
                relPath = im.getRelPath();
            } else if (metadata instanceof DirectoryMetadata) {
                DirectoryMetadata dm = (DirectoryMetadata) metadata;
                relPath = dm.getRelPath();
            }
        }
        return relPath;
    }

    private boolean hasMetadata(IResource resource) throws CoreException {
        WorkspaceMetadataManager m = WorkspaceMetadataManager.getInstance();
        BaseMetadata metadata = m.getMetadata(resource);
        if (metadata != null) {
            return true;
        }
        return false;
    }

    private boolean isDirectory(IResource resource) throws CoreException {
        WorkspaceMetadataManager m = WorkspaceMetadataManager.getInstance();
        BaseMetadata metadata = m.getMetadata(resource);

        boolean result = false;
        if (metadata != null) {
            if (metadata instanceof DirectoryMetadata) {
                return true;
            }
        }
        return result;
    }

    @Override
    public IResource[] getChanges() {
        // stub value
        return new IResource[0];
    }

    @Override
    public void setChanges(IResource[] changes) {
    }

    @Override
    public IResource[] getResourcesToRefresh() {
        // stub value
        return new IResource[0];
    }

    public boolean isUpdateMode() {
        if (descriptor != null && descriptor.getMergeOptions() != null) {
            return descriptor.getMergeOptions().isDoUpdate();
        }

        return false;
    }

    /**
     * @return the wasDownloadCancelled - true if operation was cancelled by API layer
     */
    public boolean wasDownloadCancelled() {
        return wasDownloadCancelled;
    }

    /**
     * @param wasDownloadCancelled the wasDownloadCancelled to set
     */
    private void setDownloadCancelled(boolean wasDownloadCancelled) {
        this.wasDownloadCancelled = wasDownloadCancelled;
    }

}

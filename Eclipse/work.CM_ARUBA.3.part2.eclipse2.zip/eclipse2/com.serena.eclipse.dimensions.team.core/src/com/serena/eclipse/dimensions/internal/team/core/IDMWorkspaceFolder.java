/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.TeamException;

/**
 * A folder in dimensions workspace.
 * @author V.Grishchenko
 */
public interface IDMWorkspaceFolder extends IDMWorkspaceResource, IDMFolder {

    /**
     * @return <code>true</code> if this folder contains dimensions metadata
     */
    boolean isDMFolder();

    /**
     * Convenience method for getting a local container corresponding to this
     * remote folder.
     */
    IContainer getLocalFolder();

    /**
     * Convenience method for getting base folder.
     * @return base folder or <code>null</code> if none
     */
    IDMRemoteFolder getBaseFolder() throws TeamException;

    /**
     * @return <code></code>
     */
    boolean hasAddedOrDeletedMembers();

    /**
     * Convenience method for getting remote folder.
     * @return remote folder or <code>null</code> if none
     */
    IDMRemoteFolder getRemoteFolder() throws TeamException;

    /**
     * @return members filtered according to the supplied filter
     */
    IDMWorkspaceResource[] getMembers(IDMWorkspaceResourceFilter filter) throws TeamException;

    /**
     * Accepts a visitor for traversal of filtered resources.
     */
    void accept(IDMResourceVisitor visitor, IDMWorkspaceResourceFilter filter) throws CoreException;

    /**
     * @return <code>true</code> if this folder contains modified files,
     *         returns <code>false</code> otherwise
     */
    boolean containsModified(boolean deep);

    /**
     * @return <code>true</code> if this folder contains remotely modified files
     *         (a.k.a. incoming changes), returns <code>false</code> otherwise
     */
    boolean containsRemotelyModified(boolean deep);

    /**
     * @return <code>true</code> if this folder contains managed files,
     *         returns <code>false</code> otherwise
     */
    boolean containsManaged(boolean deep);

    /**
     * @return <code>true</code> if this folder contains unmanaged files,
     *         returns <code>false</code> otherwise
     */
    boolean containsUnmanaged(boolean deep);

    /**
     * @return <code>true</code> if this folder contains optimistically locked
     *         files, returns <code>false</code> otherwise
     */
    boolean containsOptimistic(boolean deep);

    /**
     * @return <code>true</code> if this folder contains pessimistically locked
     *         files (managed, not checked out, and read-only).
     */
    boolean containsPessimistic(boolean deep);

    /**
     * @return <code>true</code> if this folder contains extracted files,
     *         returns <code>false</code> otherwise
     */
    boolean containsExtracted(boolean deep);

    /**
     * @return <code>true</code> if this folder contains files whose remote
     *         revisions are extracted, returns <code>false</code> otherwise
     */
    boolean isRemoteExtracted(boolean deep);

    /**
     * @return <code>true</code> if this folder contains non-extracted managed
     *         files, returns <code>false</code> otherwise
     */
    boolean containsNotExtracted(boolean deep);

    /**
     * @return <code>true</code> if this folder contains moved resources,
     *         returns <code>false</code> otherwise
     */
    boolean containsMoved(boolean deep);

    /**
     * @return <code>true</code> if this folder contains locked resources,
     *         returns <code>false</code> otherwise
     */
    boolean containsLocked(boolean deep);
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.RepositoryProvider;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.WorkAreaMetadata;
import com.serena.dmfile.dto.Pair;
import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataException;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.SccProjectList;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.WaRootInfo;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

public class AutoShareJob extends Job { 
    private static DimensionsConnectionDetailsEx con = null;

    private boolean wereErrors = false;
    private List<IProject> projectsToShare = new ArrayList<IProject>();
    private volatile boolean shouldSort = true;

    AutoShareJob() {
        super(Messages.DMTeamProviderAutoshareJob);
    }

    public static void setConnection(DimensionsConnectionDetailsEx con) {
        AutoShareJob.con = con;
    }

    public boolean wereErrors() {
        return wereErrors;
    }

    public boolean isQueueEmpty() {
        return projectsToShare.isEmpty();
    }

    @Override
    public boolean shouldSchedule() {
        return !isQueueEmpty();
    }

    @Override
    public boolean shouldRun() {
        synchronized (projectsToShare) {
            for (Iterator<IProject> iter = projectsToShare.iterator(); iter.hasNext();) {
                IProject project = iter.next();
                if (RepositoryProvider.isShared(project)) {
                    iter.remove();
                }
            }
            return !projectsToShare.isEmpty();
        }
    }

    public void share(IProject project) {
        if (!RepositoryProvider.isShared(project)) {
            synchronized (projectsToShare) {
                if (!projectsToShare.contains(project)) {
                    projectsToShare.add(project);
                    this.shouldSort = true;
                }
            }
            if (getState() == Job.NONE && !isQueueEmpty()) {
                schedule();
            }
        }
    }

    public void clearErrors() {
        wereErrors = false;
    }

    @Override
    protected IStatus run(final IProgressMonitor monitor) {
        IProject next = null;
        next = getNextProject(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        while (next != null) {
            if (!RepositoryProvider.isShared(next)) {
                autoconnectDMProject(next, Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
            }
            next = getNextProject(monitor);
        }
        this.shouldSort = true;
        monitor.done();
        return Status.OK_STATUS;
    }

    private IProject getNextProject(IProgressMonitor monitor) {
        IProject next = null;
        synchronized (projectsToShare) {
            if (!projectsToShare.isEmpty()) {
                if (shouldSort) {
                    Collections.sort(projectsToShare, new SharingProjectsComparator(monitor));
                    this.shouldSort = false;
                }
                next = projectsToShare.remove(0);
            }
        }
        return next;
    }

    private void deleteAllMetadata(IProject proj) {
        WorkspaceMetadataManager mman = WorkspaceMetadataManager.getInstance();
        try {
            mman.deleteMetadataFolders(proj);
        } catch (CoreException e) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                    NLS.bind(Messages.AutoShare_Error_Deleting_Metadata, proj.getName()), e));
        }
    }

    private void deleteProject(IProject proj) {
        try {
            // don't delete project contents
            proj.delete(IResource.NEVER_DELETE_PROJECT_CONTENT, null);
        } catch (CoreException e) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                    NLS.bind(Messages.AutoShare_Error_Deleting_Project, proj.getName()), e));
        }
    }

    /**
     * Auto-connect to the repository using .dm or .metadata directories
     */
    private boolean autoconnectDMProject(final IProject project, IProgressMonitor monitor) {
        // share to dimensions
        // look for marker file projectName.ecl or projectFolder.ecl
        boolean deleteMetadata = false;
        boolean deleteProject = false;
        IResource markerFile = null;
        MetadataProvider mdp = null;
        boolean isWorkarea = false;
        boolean isSccProject = false;

        try {
            Pair<Boolean, Boolean> result = null;

            mdp = MetadataProviderFactory.providerFor(project);
            if (mdp.metadataExists(MetadataTypes.MT_WORKAREACONFIG, project.getLocation().toOSString())) {
                isWorkarea = true;
            }

            String markerFileName = project.getName() + "." + IDMConstants.SCC_ECLIPSE_PROJECT_MARKER; //$NON-NLS-1$
            markerFile = project.findMember(markerFileName);
            if (markerFile == null) {
                if (isWorkarea) {
                    WorkAreaMetadata workAreaMetadata = mdp.getWorkAreaMetadata(project.getLocation().toOSString());
                    String relPath = workAreaMetadata.getRelPath();
                    if (!StringPath.isNullorEmpty(relPath)) {
                        markerFileName = new Path(relPath).lastSegment() + "." + IDMConstants.SCC_ECLIPSE_PROJECT_MARKER; //$NON-NLS-1$
                        markerFile = project.findMember(markerFileName);
                    }
                } else {
                    // try folder
                    markerFileName = project.getLocation().lastSegment() + "." + IDMConstants.SCC_ECLIPSE_PROJECT_MARKER; //$NON-NLS-1$
                    markerFile = project.findMember(markerFileName);
                }
            }

            if (markerFile != null && markerFile.getType() == IResource.FILE) {
                isSccProject = true;
            }

            if (!isWorkarea) {
                if (!canShareFolder(project, mdp)) {
                    // unable to share
                    return false;
                }
            }

            boolean shareVirtual = false;
            IProject rootMavenProject = null;
            if (!isSccProject && !isWorkarea) {
                IMavenProjectStructureHelper mavenHelper = DMTeamPlugin.getDefault().getMavenProjectStructureHelper();
                if (mavenHelper != null) {
                    if (!mavenHelper.hasParentPomInTree(project, monitor)) {
                        DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING,
                                NLS.bind(Messages.AutoShare_MavenProjectNotResolvedParent, project.getName())));
                        return false;
                    }

                    rootMavenProject = mavenHelper.getRootMavenProject(project, monitor);
                    if (rootMavenProject == null) {
                        DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING,
                                NLS.bind(Messages.AutoShare_MavenProjectNotResolvedParent, project.getName())));
                        return false;
                    }

                    if (!RepositoryProvider.isShared(rootMavenProject)) {
                        DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING,
                                NLS.bind(Messages.AutoShare_MavenProjectNotSharedParent, project.getName())));
                        return false;
                    }

                    shareVirtual = true;
                }

                // unable to share
                if (!shareVirtual) {
                    if (mavenHelper.hasMavenNature(project) && !mavenHelper.isMavenProjectResolvedByWorkspace(project)) {
                        DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING,
                                NLS.bind(Messages.AutoShare_MavenProjectNotResolved, project.getName())));
                    }

                    return false;
                }
            }

            if (shareVirtual) {
                result = autoConnectVirtualProject(project, monitor, mdp, rootMavenProject);
            } else if (isSccProject) {
                result = autoConnectSccProject(project, monitor, mdp, markerFile, isWorkarea);
            } else {
                result = autoConnectProject(project, monitor, mdp, isWorkarea);
            }

            DMTeamPlugin.getWorkspace().cleanTimestamps(new IResource[] { project }, IResource.DEPTH_INFINITE, monitor);

            deleteMetadata = result.getFirst();
            deleteProject = result.getSecond();

            // now here do any cleanup that is necessary
            if (deleteMetadata) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.INFO,
                        NLS.bind(Messages.AutoShare_Deleting_All_Metadata, project.getName())));
                deleteAllMetadata(project);
            }

            if (deleteProject) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.INFO,
                        NLS.bind(Messages.AutoShare_Deleting_Project, project.getName())));
                deleteProject(project);
            }

            if (!deleteMetadata && !deleteProject) {
                return true;
            }
        } catch (MetadataException e) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.INFO,
                    NLS.bind(Messages.AutoShare_Deleting_All_Metadata, project.getName())));
            deleteAllMetadata(project);
        } catch (CoreException e) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.INFO,
                    NLS.bind(Messages.AutoShare_Deleting_Project, project.getName())));
            deleteProject(project);
        } finally {
            if (mdp != null) {
                mdp.close();
            }
        }

        return false;
    }

    private boolean canShareFolder(final IProject project, MetadataProvider mdp) throws MetadataException {
        if (!mdp.metadataExists(MetadataTypes.MT_DIR, project.getLocation().toOSString())) {
            // Folder metadata doesn't exist, but this folder contains existing metadata folders and
            // this folder is located in the existing workarea.
            // This situation shows that workarea was corrupted and project can't be imported
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING, NLS.bind(
                    Messages.AutoShare_Warning_Project_Orphaned, project.getName(), project.getLocation().toOSString())));
            Display.getDefault().asyncExec(new Runnable() {
                @Override
                public void run() {
                    MessageDialog.openWarning(null, Messages.Dialog_title,
                            NLS.bind(Messages.AutoShare_Warning_Project_Orphaned, project.getName(),
                                    project.getLocation().toOSString()));
                }
            });
            return false;
        } else {
            DirectoryMetadata dirMetadata = mdp.getDirectoryMetadata(project.getLocation().toOSString());
            String movedFrom = dirMetadata.getMovedFrom();
            if (!StringPath.isNullorEmpty(movedFrom)) {
                // Folder metadata exist, but this folder was renamed.
                // This situation shows that user should deliver rename before importing it to the Eclipse
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING, NLS.bind(
                        Messages.AutoShare_Warning_Project_Renamed, project.getName(), project.getLocation().toOSString())));
                Display.getDefault().asyncExec(new Runnable() {

                    @Override
                    public void run() {
                        MessageDialog.openWarning(null, Messages.Dialog_title,
                                NLS.bind(Messages.AutoShare_Warning_Project_Renamed, project.getName(),
                                        project.getLocation().toOSString()));
                    }

                });
                return false;
            }
        }
        return true;
    }

    private Pair<Boolean, Boolean> autoConnectVirtualProject(IProject project, IProgressMonitor monitor,
            MetadataProvider mdp, IProject rootMavenProject) {
        try {
            DMTeamPlugin.getWorkspace().manageVirtual(project, rootMavenProject);
        } catch (CoreException e) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING,
                    NLS.bind(Messages.AutoShare_FailedToShareVirtual, project.getName()), e));
            wereErrors = true;
        }

        return new Pair<Boolean, Boolean>(false, false);
    }

    private Pair<Boolean, Boolean> autoConnectSccProject(IProject project, IProgressMonitor monitor, MetadataProvider mdp,
            IResource markerFile, boolean isWorkareaRoot) {
        boolean deleteMetadata = false;
        boolean deleteProject = false;

        do {
            boolean isBaseline = false;
            String projectName = ""; //$NON-NLS-1$
            ItemMetadata markerMetadata = null;
            try {
                markerMetadata = mdp.getItemMetadata(markerFile.getLocation().toOSString());
            } catch (MetadataException e) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_ErrorReading_Metadata, markerFile.getLocation().toOSString()), e));
                deleteMetadata = true;
                wereErrors = true;
                break;
            }
            if (markerMetadata == null) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_No_Metadata, markerFile.getLocation().toOSString())));
                deleteMetadata = true;
                wereErrors = true;
                break;
            }
            projectName = markerMetadata.getProject();
            if (projectName == null) {
                projectName = markerMetadata.getBaseline();
                isBaseline = true;
            }

            IPath compat = checkWorkArea(project, projectName, isBaseline);
            if (compat == null) {
                wereErrors = true;
                break;
            }

            if (!initConnection(project)) {
                break;
            }

            DimensionsLcObject remoteObject = getRemoteObject(projectName, isBaseline, monitor);
            if (remoteObject == null) {
                deleteProject = true;
                break;
            }

            String ide = (String) remoteObject.getAttribute(SystemAttributes.IDE_TAG);

            // we now have a Project we need to create the correct type
            APIObjectAdapter container = null;
            if (!isBaseline) {
                container = new SccProjectContainerWorkset((Project) remoteObject, con, ide);
            } else {
                container = new SccBaselineContainer((Baseline) remoteObject, con, ide);
            }

            // now get the marker
            SccProjectList list = SccProjectList.getProjectList(container);
            try {
                list.fetch(Utils.monitorFor(monitor));
            } catch (DMException e1) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_ErrorFetchingProject, projectName), e1));
                deleteMetadata = true;
                wereErrors = true;
                break;
            }

            SccProject sccProject = null;
            if (!isWorkareaRoot) {
                // compatible scc project
                sccProject = list.findProject(new Path(markerMetadata.getRelPath()).removeLastSegments(1));
            } else {
                // relative scc project
                try {
                    WorkAreaMetadata workAreaMetadata = mdp.getWorkAreaMetadata(project.getLocation().toOSString());
                    sccProject = list.findProject(new Path(workAreaMetadata.getRelPath()));
                } catch (MetadataException e) {
                    DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                            NLS.bind(Messages.AutoShare_ErrorReading_Metadata, project.getLocation().toOSString()), e));
                    deleteMetadata = true;
                    wereErrors = true;
                    break;
                }
            }

            APIObjectAdapter remoteProjectToManage = sccProject;
            // now manage it
            try {
                if (!isWorkareaRoot) {
                    // compatible scc project
                    DMTeamPlugin.getWorkspace().manage(project, null, remoteProjectToManage, compat, true);
                } else {
                    // relative scc project
                    DMTeamPlugin.getWorkspace().manage(project, null, remoteProjectToManage, null, true);
                }

                // hide marker
                if (markerFile != null && markerFile.exists()) {
                    markerFile.setTeamPrivateMember(true);
                    ResourceAttributes resourceAttributes = markerFile.getResourceAttributes();
                    if (resourceAttributes != null) {
                        resourceAttributes.setHidden(true);
                        markerFile.setResourceAttributes(resourceAttributes);
                    }
                }
            } catch (CoreException e) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_FailedToShare, project.getName()), e));
                wereErrors = true;
                deleteMetadata = true;
                break;
            }
        } while (false);

        return new Pair<Boolean, Boolean>(deleteMetadata, deleteProject);
    }

    private Pair<Boolean, Boolean> autoConnectProject(IProject project, IProgressMonitor monitor, MetadataProvider mdp,
            boolean isWorkarea) {
        boolean deleteMetadata = false;
        boolean deleteProject = false;

        do {
            boolean isBaseline = false;
            String projectName = ""; //$NON-NLS-1$
            WorkAreaMetadata workAreaMetadata = null;
            try {
                workAreaMetadata = mdp.getWorkAreaMetadata(project.getLocation().toOSString());
            } catch (MetadataException e) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_ErrorReading_Metadata, project.getLocation().toOSString()), e));
                deleteMetadata = true;
                wereErrors = true;
                break;
            }
            if (workAreaMetadata == null) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_No_Metadata, project.getLocation().toOSString())));
                deleteMetadata = true;
                wereErrors = true;
                break;
            }

            projectName = workAreaMetadata.getProject();
            if (projectName == null) {
                projectName = workAreaMetadata.getBaseline();
                isBaseline = true;
            }

            IPath compat = checkWorkArea(project, projectName, isBaseline);
            if (compat == null) {
                wereErrors = true;
                break;
            }

            if (!initConnection(project)) {
                break;
            }

            DimensionsLcObject remoteObject = getRemoteObject(projectName, isBaseline, monitor);
            if (remoteObject == null) {
                deleteProject = true;
                break;
            }

            APIObjectAdapter projectAdapter = null;
            if (!isBaseline) {
                projectAdapter = new WorksetAdapter((Project) remoteObject, con);
            } else {
                projectAdapter = new BaselineAdapter((Baseline) remoteObject, con);
            }

            try {
                DMTeamPlugin.getWorkspace().manage(project, null, projectAdapter, null, true);
            } catch (CoreException e) {
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_FailedToShare, project.getName()), e));
                wereErrors = true;
                deleteMetadata = true;
                break;
            }
        } while (false);

        return new Pair<Boolean, Boolean>(deleteMetadata, deleteProject);
    }

    /**
     * Check that the project is under a compatible work area
     *
     * @param project
     * @param remoteName
     * @param isBaseline
     * @return workarea path or null if workarea is invalid
     */
    private IPath checkWorkArea(IProject project, String remoteName, boolean isBaseline) {
        // lets check that the project is under a compatible work area
        List<WaRootInfo> compats = new ArrayList<WaRootInfo>();
        IPath compat = TeamUtils.queryCompatibleWorkAreaRoot(project.getLocation(), remoteName, isBaseline, compats);
        if (compat == null) {
            // null means incompatible or multiple
            if (compats.size() == 1) {
                // incompatible
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_Incompatible_Metadata, new Object[] { project.getName(),
                                compats.get(0).path.toOSString(), compats.get(0).project, remoteName })));
                wereErrors = true;
                return null;
            } else if (compats.size() > 1) {
                // multiple
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_Multiple_WorkArea_Metadata, project.getName())));
                wereErrors = true;
                return null;
            } else {
                // catch all
                DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                        NLS.bind(Messages.AutoShare_Incompatible_Metadata1, project.getName())));
                wereErrors = true;
                return null;
            }
        }
        // empty means no work area root so can't share
        if (compat.isEmpty()) {
            // no Work Area Root
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                    NLS.bind(Messages.AutoShare_No_WorkAreaMetadata, project.getName())));
            wereErrors = true;
            return null;
        }

        return compat;
    }

    private boolean initConnection(IProject project) {
        // now find the connection to use
        // connection is sticky for a set of imports until job finishes and the queue is empty
        if (con == null) {
            DimensionsConnectionDetailsEx[] inp = DMPlugin.getDefault().getKnownLocations();
            if (inp == null || inp.length == 0) {
                Display.getDefault().syncExec(new Runnable() {
                    @Override
                    public void run() {
                        MessageDialog.openError(null, Messages.Dialog_title, Messages.Autoshare_No_Connections);
                    }
                });
                // could explicitly share when connection setup so just delete marker;
                // now delete project so can retry import
                return false;

            }
            con = DMRepositoryProviderType.getConnectionFromList(inp);
        }
        if (con == null) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING,
                    NLS.bind(Messages.AutoShare_No_Connection, project.getName())));
            return false;
        }

        return true;
    }

    private DimensionsLcObject getRemoteObject(final String name, final boolean isBaseline, IProgressMonitor monitor) {
        final DimensionsLcObject[] projectHolder = new DimensionsLcObject[1];

        final Session[] sess = new Session[1];
        try {
            sess[0] = con.openSession(null);
        } catch (DMException e2) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                    NLS.bind(Messages.AutoShare_connectionError, con.getConnName()), e2));
            wereErrors = true;
            return null;
        }
        try {
            sess[0].run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    if (!isBaseline) {
                        projectHolder[0] = sess[0].getObjectFactory().getProject(name);
                    } else {
                        Filter filter = new Filter();
                        filter.criteria()
                                .add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, name, Filter.Criterion.EQUALS));
                        List<Baseline> bl = sess[0].getObjectFactory().getBaselines(filter);
                        if (bl.size() == 1) {
                            projectHolder[0] = bl.get(0);
                        }
                    }
                    if (projectHolder[0] != null) {
                        projectHolder[0].queryAttribute(new int[] { SystemAttributes.IDE_TAG,
                                SystemAttributes.IDE_PROJECT_NAME, SystemAttributes.IDE_DM_UID });
                    }
                }
            }, monitor);
        } catch (DMException e) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                    NLS.bind(Messages.AutoShare_InvalidProject, name), e));
            wereErrors = true;
            return null;
        }

        if (projectHolder[0] == null) {
            DMTeamPlugin
                    .log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR, NLS.bind(Messages.AutoShare_NoProject, name)));
            wereErrors = true;
            return null;
        }
        return projectHolder[0];
    }

}
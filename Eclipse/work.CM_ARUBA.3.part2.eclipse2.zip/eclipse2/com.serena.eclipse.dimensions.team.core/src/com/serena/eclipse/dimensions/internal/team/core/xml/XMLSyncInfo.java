/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;

import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.dmfile.xml.ObjectAttributes;
import com.serena.dmfile.xml.Resolution;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMSyncInfo;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;

/**
 * Special sync info that generates sync kind using resolutions after execution of merge command
 */
public class XMLSyncInfo extends DMSyncInfo {
    private int derivedKind;
    protected Resolution resolution;
    private List<Integer> actions;
    private int currentAction;
    private int defaultAction;
    private int oldAction;
    protected XMLMergeDescriptor descriptor;
    private boolean stale = false;

    XMLSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote, IResourceVariantComparator comparator,
            Subscriber subscriber, DimensionsConnectionDetailsEx connecion) {
        super(local, base, remote, comparator, subscriber, connecion);
    }

    /**
     * simply returns derived sync kind without internal calculation
     */
    @Override
    protected int calculateKind() throws TeamException {
        return derivedKind;
    }

    /**
     * @return kind that based on the server side xml results
     */
    public int getDerivedKind() {
        return derivedKind;
    }

    /**
     * @param kind
     *            the sync kind that obtained from server side xml results
     */
    public void setDerivedKind(int kind) {
        this.derivedKind = kind;
    }

    /**
     * @return resolution as a representation of server side merge result
     */
    public Resolution getResolution() {
        return resolution;
    }

    /**
     * @param resolution
     *            the resolution as a representation of server side merge result
     */
    public void setResolution(Resolution resolution) {
        this.resolution = resolution;
    }

    /**
     * @return current bitmask of user resolution aka action
     */
    public int getCurrentAction() {
        return currentAction;
    }

    /**
     * @return previous bitmask of user resolution aka action
     */
    public int getOldAction() {
        return oldAction;
    }

    /**
     * @return bitmask of resolution that is a default for current resolution type
     */
    public int getDefaultAction() {
        return defaultAction;
    }

    /**
     * Set default action and try to change current action if possible
     * 
     * @param defaultAction
     * @throws CoreException
     */
    protected void setDefaultAction(Integer defaultAction) throws CoreException {
        this.defaultAction = defaultAction;

        if (hasMergeOption(defaultAction)) {
            String mstr = getMergedFilePath();

            if (mstr == null) {
                setCurrentAction(XSyncUserAction.SUAL_UNRESOLVED.value());
                return;
            }

            File file = new File(mstr);

            if (!file.exists()) {
                setCurrentAction(XSyncUserAction.SUAL_UNRESOLVED.value());
                return;
            }

            IFileStore store = EFS.getStore(file.toURI());
            getDescriptor().addTempStore(this, store);

        }

        setCurrentAction(defaultAction);
    }

    protected String getMergedFilePath() {
        return getResolution().getMergedFile();
    }

    /**
     * Set current user action bitmask. Re-init direction of conflicting changes
     */
    public void setCurrentAction(int newAction) {
        if (currentAction == newAction) {
            return;
        }

        this.oldAction = this.currentAction;
        this.currentAction = newAction;

        int kind = getKind();
        if ((kind & SyncInfo.CONFLICTING) != SyncInfo.CONFLICTING) {
            return;
        }

        if (!hasMoveInResolution()) {
            if (XMLConflictTypeResolver.isChangeConflict(resolution.getConflictType())) {
                return;
            }
        }

        XSyncUserAction direction = getActionDirection(newAction);
        int baseType = XMLConflictTypeResolver.resolveConflictType(resolution);
        if (baseType == (SyncInfo.CONFLICTING | SyncInfo.ADDITION) || baseType == (SyncInfo.CONFLICTING | SyncInfo.CHANGE)) {
            if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
                kind &= ~SyncInfo.ADDITION;
                kind |= SyncInfo.CHANGE;
            } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
                kind &= ~SyncInfo.CHANGE;
                kind |= SyncInfo.ADDITION;
            } else {
                kind = baseType;
            }
        } else if (baseType == (SyncInfo.CONFLICTING | SyncInfo.DELETION)) {
            if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
                kind &= ~SyncInfo.DELETION;
                kind |= SyncInfo.CHANGE;
            } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
                kind &= ~SyncInfo.CHANGE;
                kind |= SyncInfo.DELETION;
            } else {
                kind = baseType;
            }
        }

        setDerivedKind(kind);
        try {
            init();
        } catch (TeamException e) {
            DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, e.getMessage()));
        }

    }

    /**
     * @return currant parent descriptor
     */
    public XMLMergeDescriptor getDescriptor() {
        return descriptor;
    }

    /**
     * @param descriptor
     *            is a parent container that contains this sync info
     */
    public void setDescriptor(XMLMergeDescriptor descriptor) {
        this.descriptor = descriptor;
    }

    /**
     * @return list of bitmasks that represent possible user resolutions
     */
    public List<Integer> getActions() {
        return actions;
    }

    /**
     * @param actions
     *            possible user resolutions
     */
    public void setActions(List<Integer> actions) {
        this.actions = actions;
    }

    /**
     * @return true if resolution contains path change
     */
    public boolean hasMoveInResolution() {
        String movedFrom = getResolution().getMovedFrom();
        if (movedFrom != null && !movedFrom.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * @return true if info has any action with merge option
     */
    public boolean hasMergeOptions() {
        for (Integer action : actions) {
            if (XMLSyncInfo.hasMergeOption(action)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return true if current action has merge option
     */
    public boolean hasMergeOption() {
        return hasMergeOption(getCurrentAction());
    }

    /**
     * @return true if specified action has merge option
     */
    public static boolean hasMergeOption(int action) {
        XSyncUserAction source = getActionContentSource(action);
        if (source == XSyncUserAction.SUAO_MERGE_3WAY || source == XSyncUserAction.SUAO_MERGE_2WAY) {
            return true;
        }
        return false;
    }

    public boolean hasAcceptAction() {
        return hasAcceptAction(actions);
    }

    public static boolean hasAcceptAction(Collection<Integer> actions) {
        return getAcceptAction(actions) != null;
    }

    public boolean hasIgnoreAction() {
        return hasIgnoreAction(actions);
    }

    public static boolean hasIgnoreAction(Collection<Integer> actions) {
        return getIgnoreAction(actions) != null;
    }

    public boolean hasMergeActions() {
        return hasMergeActions(actions);
    }

    public static boolean hasMergeActions(Collection<Integer> actions) {
        return getMergeActions(actions).size() > 0;
    }

    public boolean hasUseLocalActions() {
        return hasUseLocalActions(actions);
    }

    public static boolean hasUseLocalActions(Collection<Integer> actions) {
        return getUseLocalActions(actions).size() > 0;
    }

    public boolean hasUseRepositoryActions() {
        return hasUseRepositoryActions(actions);
    }

    public static boolean hasUseRepositoryActions(Collection<Integer> actions) {
        return getUseRepositoryActions(actions).size() > 0;
    }

    public boolean hasConflictingItemsActions() {
        boolean result = false;
        for (Integer action : this.actions) {
            if (isConflictingItemsAction(action)) {
                result = true;
                break;
            }
        }
        return result;
    }

    public boolean hasAction(Integer action) {
        if (this.actions == null) {
            return false;
        }
        if (action == null) {
            return false;
        }
        return actions.contains(action);
    }

    /**
     * @return is sync info is out-of-date
     */
    public boolean isStale() {
        return stale;
    }

    /**
     * mark sync info as out-of-date
     */
    void markStale() {
        this.stale = true;
    }

    /**
     * @see #getActionLabel(int)
     */
    public XSyncUserAction getCurrentActionLabel() {
        return getActionLabel(getCurrentAction());
    }

    /**
     * @param mask
     * @return label resolution from {@link XSyncUserAction} enum for given user action
     */
    public static XSyncUserAction getActionLabel(int mask) {
        XSyncUserAction result = XSyncUserAction.SUAL_UNRESOLVED;

        if ((mask & XSyncUserAction.SUAL_ACCEPT.value()) == XSyncUserAction.SUAL_ACCEPT.value()) {
            result = XSyncUserAction.SUAL_ACCEPT;
        } else if ((mask & XSyncUserAction.SUAL_IGNORE.value()) == XSyncUserAction.SUAL_IGNORE.value()) {
            result = XSyncUserAction.SUAL_IGNORE;
        } else if ((mask & XSyncUserAction.SUAL_MERGE.value()) == XSyncUserAction.SUAL_MERGE.value()) {
            result = XSyncUserAction.SUAL_MERGE;
        } else if ((mask & XSyncUserAction.SUAL_USE_LOCAL.value()) == XSyncUserAction.SUAL_USE_LOCAL.value()) {
            result = XSyncUserAction.SUAL_USE_LOCAL;
        } else if ((mask & XSyncUserAction.SUAL_USE_REPOSITORY.value()) == XSyncUserAction.SUAL_USE_REPOSITORY.value()) {
            result = XSyncUserAction.SUAL_USE_REPOSITORY;
        }

        return result;
    }

    /**
     * @see #getActionDirection(int)
     */
    public XSyncUserAction getCurrentActionDirection() {
        return getActionDirection(getCurrentAction());
    }

    /**
     * @param mask
     * @return path resolution from {@link XSyncUserAction} enum for given user action
     */
    public static XSyncUserAction getActionDirection(int mask) {
        XSyncUserAction result = XSyncUserAction.SUAL_UNRESOLVED;

        if (getActionLabel(mask) == XSyncUserAction.SUAL_ACCEPT || getActionLabel(mask) == XSyncUserAction.SUAL_IGNORE) {
            return result;
        }

        if ((mask & XSyncUserAction.SUAO_USE_LOCAL_PATH.value()) == XSyncUserAction.SUAO_USE_LOCAL_PATH.value()) {
            result = XSyncUserAction.SUAO_USE_LOCAL_PATH;
        } else if ((mask & XSyncUserAction.SUAO_USE_REPOSITORY_PATH.value()) == XSyncUserAction.SUAO_USE_REPOSITORY_PATH.value()) {
            result = XSyncUserAction.SUAO_USE_REPOSITORY_PATH;
        } else if ((mask & XSyncUserAction.SUAL_USE_LOCAL.value()) == XSyncUserAction.SUAL_USE_LOCAL.value()) {
            result = XSyncUserAction.SUAO_USE_LOCAL_PATH;
        } else if ((mask & XSyncUserAction.SUAL_USE_REPOSITORY.value()) == XSyncUserAction.SUAL_USE_REPOSITORY.value()) {
            result = XSyncUserAction.SUAO_USE_REPOSITORY_PATH;
        }

        return result;
    }

    /***
     * @param mask
     *            action
     * @return true if passed action contains XSyncUserAction.SUAO_REPLACE_TARGET_ITEM
     */
    public static boolean isConflictingItemsAction(int mask) {
        return (mask & XSyncUserAction.SUAO_REPLACE_TARGET_ITEM.value()) == XSyncUserAction.SUAO_REPLACE_TARGET_ITEM.value();
    }

    /***
     * @param mask
     *            action
     * @return true if passed action is XSyncUserAction.SUAL_UNRESOLVED
     */
    public static boolean isUnresolved(int mask) {
        return mask == XSyncUserAction.SUAL_UNRESOLVED.value();
    }

    /**
     * @see #getActionContentSource(int)
     */
    public XSyncUserAction getCurrentActionContentSource() {
        return getActionContentSource(getCurrentAction());
    }

    /**
     * @param mask
     * @return content resolution from {@link XSyncUserAction} enum for given user action
     */
    public static XSyncUserAction getActionContentSource(int mask) {
        XSyncUserAction result = XSyncUserAction.SUAL_UNRESOLVED;

        if (getActionLabel(mask) == XSyncUserAction.SUAL_ACCEPT || getActionLabel(mask) == XSyncUserAction.SUAL_IGNORE) {
            return result;
        }

        if ((mask & XSyncUserAction.SUAO_USE_LOCAL_FILE.value()) == XSyncUserAction.SUAO_USE_LOCAL_FILE.value()) {
            result = XSyncUserAction.SUAO_USE_LOCAL_FILE;
        } else if ((mask & XSyncUserAction.SUAO_USE_REPOSITORY_FILE.value()) == XSyncUserAction.SUAO_USE_REPOSITORY_FILE.value()) {
            result = XSyncUserAction.SUAO_USE_REPOSITORY_FILE;
        } else if ((mask & XSyncUserAction.SUAO_MERGE_2WAY.value()) == XSyncUserAction.SUAO_MERGE_2WAY.value()) {
            result = XSyncUserAction.SUAO_MERGE_2WAY;
        } else if ((mask & XSyncUserAction.SUAO_MERGE_3WAY.value()) == XSyncUserAction.SUAO_MERGE_3WAY.value()) {
            result = XSyncUserAction.SUAO_MERGE_3WAY;
        } else if ((mask & XSyncUserAction.SUAL_USE_LOCAL.value()) == XSyncUserAction.SUAL_USE_LOCAL.value()) {
            result = XSyncUserAction.SUAO_USE_LOCAL_FILE;
        } else if ((mask & XSyncUserAction.SUAL_USE_REPOSITORY.value()) == XSyncUserAction.SUAL_USE_REPOSITORY.value()) {
            result = XSyncUserAction.SUAO_USE_REPOSITORY_FILE;
        }

        return result;
    }

    /**
     * @see #getMergeActions(Collection)
     */
    public List<Integer> getMergeActions() {
        return getMergeActions(actions);
    }

    /**
     * @param actions
     * @return list of merge actions if exists in given actions
     */
    public static List<Integer> getMergeActions(Collection<Integer> actions) {
        List<Integer> result = new ArrayList<Integer>();
        for (Integer action : actions) {
            if ((action & XSyncUserAction.SUAL_MERGE.value()) == XSyncUserAction.SUAL_MERGE.value()) {
                result.add(action);
            }
        }
        return result;
    }

    /**
     * @see #getUseLocalActions(Collection)
     */
    public List<Integer> getUseLocalActions() {
        return getUseLocalActions(actions);
    }

    /**
     * @param actions
     * @return list of use local actions if exists in given actions
     */
    public static List<Integer> getUseLocalActions(Collection<Integer> actions) {
        List<Integer> result = new ArrayList<Integer>();
        for (Integer action : actions) {
            if ((action & XSyncUserAction.SUAL_USE_LOCAL.value()) == XSyncUserAction.SUAL_USE_LOCAL.value()) {
                result.add(action);
            }
        }
        return result;
    }

    /**
     * @see #getUseRepositoryActions(Collection)
     */
    public List<Integer> getUseRepositoryActions() {
        return getUseRepositoryActions(actions);
    }

    /**
     * @param actions
     * @return list of use repository actions if exists in given actions
     */
    public static List<Integer> getUseRepositoryActions(Collection<Integer> actions) {
        List<Integer> result = new ArrayList<Integer>();
        for (Integer action : actions) {
            if ((action & XSyncUserAction.SUAL_USE_REPOSITORY.value()) == XSyncUserAction.SUAL_USE_REPOSITORY.value()) {
                result.add(action);
            }
        }
        return result;
    }

    /**
     * @see #getIgnoreAction(Collection)
     */
    public Integer getIgnoreAction() {
        return getIgnoreAction(actions);
    }

    /**
     * @param actions
     * @return list of ignore actions if exists in given actions
     */
    public static Integer getIgnoreAction(Collection<Integer> actions) {
        for (Integer action : actions) {
            if ((action & XSyncUserAction.SUAL_IGNORE.value()) == XSyncUserAction.SUAL_IGNORE.value()) {
                return action;
            }
        }
        return null;
    }

    /**
     * @see #getAcceptAction(Collection)
     */
    public Integer getAcceptAction() {
        return getAcceptAction(actions);
    }

    /**
     * @param actions
     * @return list of accept actions if exists in given actions
     */
    public static Integer getAcceptAction(Collection<Integer> actions) {
        for (Integer action : actions) {
            if ((action & XSyncUserAction.SUAL_ACCEPT.value()) == XSyncUserAction.SUAL_ACCEPT.value()) {
                return action;
            }
        }
        return null;
    }

    /**
     * @see #getLocalResource(Resolution, XMLMergeDescriptor)
     */
    public IResource getLocalResource() {
        return getLocalResource(getResolution(), descriptor);
    }

    /**
     * Returns an eclipse resource that can be mapped to current workspace. May not exists
     * 
     * @param resolution
     * @param descriptor
     * @return local resource
     */
    public static IResource getLocalResource(Resolution resolution, XMLMergeDescriptor descriptor) {
        IResource resource = null;
        ObjectAttributes tgt = resolution.getTgt();
        if (tgt != null) {
            String origPath = tgt.getOrigRelPath();
            String relPath = tgt.getRelPath();
            if (origPath != null && !origPath.isEmpty()) {
                resource = TeamUtils.constructRelativeResource(origPath, tgt.isFileAttributes(), descriptor.getTarget());
            } else if (relPath != null && !relPath.isEmpty()) {
                resource = TeamUtils.constructRelativeResource(relPath, tgt.isFileAttributes(), descriptor.getTarget());
            }
        }

        return resource;
    }

    /**
     * @return temporary store that contains merge content
     */
    public IFileStore getTempStore() {
        return getDescriptor().getTempStore(this);
    }
    
    protected void initActions() throws CoreException {
        Integer defaultAction = resolution.getDefaultAction();

        List<Integer> actions = new ArrayList<Integer>();

        if (defaultAction != null) {
            setDefaultAction(defaultAction);
            actions.add(defaultAction);
        } else {
            setCurrentAction(XSyncUserAction.SUAL_UNRESOLVED.value());
            String mstr = resolution.getMergedFile();
            File mergedFile = null;
            if (mstr != null && (mergedFile = new File(mstr)).exists()) {
                IFileStore store = EFS.getStore(mergedFile.toURI());
                descriptor.addTempStore(this, store);
            }
        }

        if (resolution.getActions() != null) {
            actions.addAll(resolution.getActions());
        }

        setActions(actions);
    }

}
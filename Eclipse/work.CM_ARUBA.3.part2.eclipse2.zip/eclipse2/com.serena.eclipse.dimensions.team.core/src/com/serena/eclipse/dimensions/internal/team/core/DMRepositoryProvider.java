/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFileModificationValidator;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceRuleFactory;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.resources.team.IMoveDeleteHook;
import org.eclipse.core.resources.team.ResourceRuleFactory;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.RepositoryProvider;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.SessionResourceVariantByteStore;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Dimensions team provider.
 *
 * @author V.Grishchenko
 */
public class DMRepositoryProvider extends RepositoryProvider implements IFileModificationValidator {
    public static final String ID = "com.serena.eclipse.dimensions.team.dmprovider";//$NON-NLS-1$

    static final String QUALIFIER = "dimensions.teamprovider"; //$NON-NLS-1$

    private static final QualifiedName DM_PROJECT_PROP = new QualifiedName(QUALIFIER, "dm-proj"); //$NON-NLS-1$
    private static final QualifiedName LOCAL_ROOT_PROP = new QualifiedName(QUALIFIER, "local-root"); //$NON-NLS-1$
    private static final QualifiedName WORK_AREA_ROOT = new QualifiedName(QUALIFIER, "work-area-root"); //$NON-NLS-1$
    private static final QualifiedName REMOTE_PROJECT_ID_PROP = new QualifiedName(QUALIFIER, "rp-id"); //$NON-NLS-1$
    private static final QualifiedName REMOTE_PROJECT_TYPE_PROP = new QualifiedName(QUALIFIER, "rp-type"); //$NON-NLS-1$
    private static final QualifiedName CONNECTION_NAME_PROP = new QualifiedName(QUALIFIER, "connection"); //$NON-NLS-1$
    private static final QualifiedName IDE_TAG_PROP = new QualifiedName(QUALIFIER, "ide-tag"); //$NON-NLS-1$
    private static final QualifiedName IDE_PROJECT_UID_PROP = new QualifiedName(QUALIFIER, "ide-project-uid"); //$NON-NLS-1$
    private static final QualifiedName IDE_PROJECT_MAIN_UID_PROP = new QualifiedName(QUALIFIER, "ide-project-main-uid"); //$NON-NLS-1$
    private static final QualifiedName IDE_PROJECT_INITIAL_PROP = new QualifiedName(QUALIFIER, "ide-project-initial"); //$NON-NLS-1$
    private static final QualifiedName IDE_PROJECT_GROUP_PROP = new QualifiedName(QUALIFIER, "ide-project-group"); //$NON-NLS-1$
    private static final QualifiedName DEFAULT_REQUEST_PROP = new QualifiedName(QUALIFIER, "default-request"); //$NON-NLS-1$
    private static final QualifiedName IS_STREAM_PROP = new QualifiedName(QUALIFIER, "stream"); //$NON-NLS-1$
    private static final QualifiedName IS_ECLIPSE_PROJECT_A_STREAM = new QualifiedName(QUALIFIER, "is_eclipse_project_a_stream"); //$NON-NLS-1$
    private static final QualifiedName DM_PROJECT_UID_PROP = new QualifiedName(QUALIFIER, "dm-project-uid"); //$NON-NLS-1$

    private static final ResourceRuleFactory RESOURCE_RULE_FACTORY = new ResourceRuleFactory() {
    };

    public static final QualifiedName IDE_PROJECT_NAME_PROP = new QualifiedName(QUALIFIER, "ide-project-name"); //$NON-NLS-1$
    public static final QualifiedName REMOTE_OFFSET = new QualifiedName(QUALIFIER, "remote-offset"); //$NON-NLS-1$
    // SCC project moved-from remote folder
    public static final QualifiedName DM_PROJECT_MOVED_PROP = new QualifiedName(QUALIFIER, "dmproj-moved-from"); //$NON-NLS-1$
    public static final QualifiedName IS_PULSE_CONFIGURED = new QualifiedName(QUALIFIER, "is_pulse_configured"); //$NON-NLS-1$

    private static IDMFileModificationValidator modificationValidator;
    private static final IMoveDeleteHook moveDeleteHook = new MoveDeleteHook();

    private static final QualifiedName DM_VIRTUAL_PARENT = new QualifiedName(QUALIFIER, "dm_virtual_parent"); //$NON-NLS-1$ ;
    private static final QualifiedName DM_IS_VIRTUAL = new QualifiedName(QUALIFIER, "dm_is_virtual"); //$NON-NLS-1$ ;
    private String newProject;

    public DMRepositoryProvider() {
    }

    /**
     * An aborted offline merge by DM command line client (SVN like client) could leave files in the workspace which should not be
     * shown to the user.
     * If the "conflict-file" tag in the metadata of these files has any value other than -- merged-uid-xxxx , accepted-repository
     * ,
     * accepted-local -- then
     * these files should not be shown to the user.
     */
    public static void ignoreFilesLeftByDMCommandLineClient() throws CoreException {
        IDMWorkspace dmWorkspace = DMTeamPlugin.getWorkspace();
        IDMProject[] projects = dmWorkspace.getProjects();
        for (int i = 0; i < projects.length; i++) {
            IProject iProject = projects[i].getProject();
            iProject.refreshLocal(IResource.DEPTH_INFINITE, null);
            IResource[] members = iProject.members(false);
            markFilesLeftByDMCommandLineClientAsPrivate(members);
        }
    }

    private static void markFilesLeftByDMCommandLineClientAsPrivate(IResource[] resources) throws CoreException {
        for (int i = 0; i < resources.length; i++) {
            if (resources[i].getType() == IResource.FILE) {
                if (TeamUtils.ignoreResourceLeftByDMCommandLineClient(resources[i])) {
                    resources[i].setTeamPrivateMember(true);
                }
            } else if (resources[i].getType() == IResource.FOLDER) {
                IResource[] members = ((IContainer) resources[i]).members();
                markFilesLeftByDMCommandLineClientAsPrivate(members);
            }
        }

    }

    /**
     * @return configured DM provider for the specified resource, or <code>null</code> if none
     */
    public static DMRepositoryProvider getDMProvider(IResource resource) {
        if (resource == null) {
            return null;
        }
        return (DMRepositoryProvider) RepositoryProvider.getProvider(resource.getProject(), ID);
    }

    public static IDMProject createProject(APIObjectAdapter projectWrapper, IProject project, IPath localOffset)
            throws CoreException {
        return DMProject.createProject(projectWrapper, project, localOffset, null,
                new RemoteProjectTree(new SessionResourceVariantByteStore(), null));
    }

    public static IDMProject createProject(String id, int type, DimensionsConnectionDetailsEx connection, IProject project,
            IPath localOffset, IPath remoteOffset) {
        return DMProject.createProject(id, type, connection, project, localOffset, remoteOffset, null,
                new RemoteProjectTree(new SessionResourceVariantByteStore(), null));
    }

    /**
     * Maps local project to a workset or a baseline.
     *
     * @param project
     *            local workbench project
     * @param path
     *            path to the managed root, can be <code>null</code>
     * @param remoteObject
     *            workset or baseline adapter
     * @param workAreaPath
     *            work area root, can be <code>null</code>
     * @throws CoreException
     */
    static void map(IProject project, IContainer root, APIObjectAdapter remoteObject, IPath workAreaPath) throws CoreException {
        preConfigureProject(project, root, remoteObject, workAreaPath);
        try {
            RepositoryProvider.map(project, ID);
        } catch (TeamException e) {
            dePreConfigureProject(project);
            throw e;
        }
    }

    static void mapVirtual(IProject project, IProject toProject) throws CoreException {
        DMRepositoryProvider provider = getDMProvider(toProject);
        if (provider == null) {
            throw new CoreException(new Status(IStatus.ERROR, DMTeamPlugin.ID, Messages.DMRepositoryProvider_0));
        }

        IDMProject dmProject = provider.getIdmProject();
        project.setSessionProperty(DM_VIRTUAL_PARENT, dmProject);
        try {
            RepositoryProvider.map(project, ID);
        } catch (TeamException e) {
            project.setPersistentProperty(DM_VIRTUAL_PARENT, null);
            throw e;
        }
    }

    private static void preConfigureProject(IProject project, IContainer root, APIObjectAdapter remoteProject, IPath workAreaPath)
            throws CoreException {
        assert project.getSessionProperty(DM_PROJECT_PROP) == null;
        if (root == null) {
            root = project;
        }
        if (!project.getFullPath().isPrefixOf(root.getFullPath())) {
            throw new DMException(
                    DMTeamStatus.createErrorStatus(DMTeamStatus.INVALID_LOCAL_ROOT, Messages.DMRepositoryProvider_1));
        }
        IDMProject dmProject = DMProject.createProject(remoteProject, project, root.getProjectRelativePath(), workAreaPath,
                getWorkspaceRemoteTree());
        project.setSessionProperty(DM_PROJECT_PROP, dmProject);
    }

    private static void dePreConfigureProject(IProject project) throws CoreException {
        project.setSessionProperty(DM_PROJECT_PROP, null);
    }

    private static IDMRemoteTree getWorkspaceRemoteTree() {
        return (IDMRemoteTree) ((DMWorkspace) DMTeamPlugin.getWorkspace()).getRemoteTree();
    }

    @Override
    public void configureProject() throws CoreException {
        IProject project = getProject();
        DMProject dmProject = (DMProject) project.getSessionProperty(DM_PROJECT_PROP);
        if (dmProject == null) {
            DMProject dmParent = (DMProject) project.getSessionProperty(DM_VIRTUAL_PARENT);
            Assert.isNotNull(dmParent);
            IProject rootProject = dmParent.getProject();
            project.setPersistentProperty(DM_VIRTUAL_PARENT, rootProject.getName());
            project.setPersistentProperty(DM_IS_VIRTUAL, "true"); //$NON-NLS-1$

            dmParent.addVirtualChildProject(project);

            setIsEclipseProjectAStreamProperty(dmParent, project);
        } else {
            project.setPersistentProperty(REMOTE_PROJECT_ID_PROP, dmProject.getId());
            project.setPersistentProperty(REMOTE_PROJECT_TYPE_PROP, String.valueOf(dmProject.getType()));
            project.setPersistentProperty(CONNECTION_NAME_PROP, dmProject.getConnection().getConnName());
            if (!dmProject.getProjectRelativePath().isEmpty()) {
                project.setPersistentProperty(LOCAL_ROOT_PROP, dmProject.getProjectRelativePath().toString());
            }
            if (!dmProject.getRemoteOffset().isEmpty()) {
                project.setPersistentProperty(REMOTE_OFFSET, dmProject.getRemoteOffset().toString());
            }
            // if a full work area
            if (dmProject.isFullWorkArea()) {
                project.setPersistentProperty(WORK_AREA_ROOT, dmProject.getWorkAreaPath().toString());
            }
            project.setPersistentProperty(IDE_TAG_PROP, dmProject.getIdeTag());
            project.setPersistentProperty(IDE_PROJECT_UID_PROP, String.valueOf(dmProject.getIdeProjectUid()));
            project.setPersistentProperty(IDE_PROJECT_MAIN_UID_PROP, String.valueOf(dmProject.getMainUid()));
            project.setPersistentProperty(DM_PROJECT_UID_PROP, String.valueOf(dmProject.getDmUid()));
            project.setPersistentProperty(IDE_PROJECT_NAME_PROP, dmProject.getIdeProjectName());
            project.setPersistentProperty(IDE_PROJECT_INITIAL_PROP, Boolean.valueOf(dmProject.isInitial()).toString());
            project.setPersistentProperty(IDE_PROJECT_GROUP_PROP, dmProject.getProjectGroup());
            project.setPersistentProperty(DEFAULT_REQUEST_PROP, dmProject.getDefaultRequest());
            project.setPersistentProperty(IS_STREAM_PROP, Boolean.valueOf(dmProject.getIsStream()).toString());
            project.setPersistentProperty(DM_IS_VIRTUAL, "false"); //$NON-NLS-1$
            setIsEclipseProjectAStreamProperty(dmProject, project);
        }
    }

    private static void setIsEclipseProjectAStreamProperty(IDMProject dmProject, IProject project) throws CoreException {
        if (dmProject.getIsStream() || (TeamUtils.isLocalWorksetAStream(project) != null)) {
            project.setPersistentProperty(IS_ECLIPSE_PROJECT_A_STREAM, "true"); //$NON-NLS-1$
        } else {
            project.setPersistentProperty(IS_ECLIPSE_PROJECT_A_STREAM, "false"); //$NON-NLS-1$
        }
    }

    @Override
    public void deconfigure() throws CoreException {
        IProject project = getProject();
        project.setPersistentProperty(REMOTE_PROJECT_ID_PROP, null);
        project.setPersistentProperty(REMOTE_PROJECT_TYPE_PROP, null);
        project.setPersistentProperty(CONNECTION_NAME_PROP, null);
        project.setPersistentProperty(LOCAL_ROOT_PROP, null);
        project.setPersistentProperty(REMOTE_OFFSET, null);
        project.setPersistentProperty(WORK_AREA_ROOT, null);
        project.setPersistentProperty(IDE_TAG_PROP, null);
        project.setPersistentProperty(IDE_PROJECT_UID_PROP, null);
        project.setPersistentProperty(DM_PROJECT_UID_PROP, null);
        project.setPersistentProperty(IDE_PROJECT_MAIN_UID_PROP, null);
        project.setPersistentProperty(IDE_PROJECT_NAME_PROP, null);
        project.setPersistentProperty(IDE_PROJECT_INITIAL_PROP, null);
        project.setPersistentProperty(IDE_PROJECT_GROUP_PROP, null);
        project.setPersistentProperty(DEFAULT_REQUEST_PROP, null);
        project.setPersistentProperty(IS_STREAM_PROP, null);
        project.setPersistentProperty(IS_ECLIPSE_PROJECT_A_STREAM, null);
        project.setPersistentProperty(DM_PROJECT_MOVED_PROP, null);
        project.setPersistentProperty(DM_IS_VIRTUAL, null);
        project.setPersistentProperty(DM_VIRTUAL_PARENT, null);
        dePreConfigureProject(project);
    }

    @Override
    public String getID() {
        return ID;
    }

    @Override
    public boolean canHandleLinkedResources() {
        return true;
    }

    @Override
    public boolean canHandleLinkedResourceURI() {
        // 3.2 linked resource support, answer yes as we ignore them
        return true;
    }

    @Override
    public IResourceRuleFactory getRuleFactory() {
        return RESOURCE_RULE_FACTORY;
    }

    public synchronized IDMProject getIdmProject() throws CoreException {
        IProject project = getProject();
        DMProject dmProject = (DMProject) project.getSessionProperty(DM_PROJECT_PROP);
        if (dmProject == null) {
            String parentName = project.getPersistentProperty(DM_VIRTUAL_PARENT);
            if (parentName != null) {
                IProject parent = ResourcesPlugin.getWorkspace().getRoot().getProject(parentName);
                DMRepositoryProvider dmProvider = DMRepositoryProvider.getDMProvider(parent);
                if (dmProvider != null) {
                    IDMProject dmParent = dmProvider.getIdmProject();
                    if (dmParent instanceof WorksetProject) {
                        return new VirtualWorkset((WorksetProject) dmParent, project);
                    } else if (dmParent instanceof BaselineProject) {
                        return new VirtualBaseline((BaselineProject) dmParent, project);
                    }
                }
            } else {
                // 1. read persisted properties
                String id = project.getPersistentProperty(REMOTE_PROJECT_ID_PROP);
                int type = 0;
                try {
                    String sType = project.getPersistentProperty(REMOTE_PROJECT_TYPE_PROP);
                    type = Integer.parseInt(sType);
                } catch (Exception e) {
                    throw new DMException(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, "Bad remote project type", e)); //$NON-NLS-1$
                }
                String connName = project.getPersistentProperty(CONNECTION_NAME_PROP);
                if (connName == null) {
                    DMTeamPlugin.getWorkspace().unmanage(project, false, null);
                    throw new DMException(
                            DMTeamStatus.createErrorStatus(DMTeamStatus.MISSING_CONNECTION, Messages.DMRepositoryProvider_2));
                }
                DimensionsConnectionDetailsEx connection = DMPlugin.getDefault().getConnection(connName);
                if (connection == null) {
                    DMTeamPlugin.getWorkspace().unmanage(project, false, null);
                    throw new DMException(DMTeamStatus.createErrorStatus(DMTeamStatus.MISSING_CONNECTION,
                            "Connection " + connName + " is unknown")); //$NON-NLS-1$ //$NON-NLS-2$
                }

                String localRootRelPath = project.getPersistentProperty(LOCAL_ROOT_PROP);
                String remoteOffsetValue = project.getPersistentProperty(REMOTE_OFFSET);
                String workAreaPathValue = project.getPersistentProperty(WORK_AREA_ROOT);

                // 2. create project instance and cache as session prop
                dmProject = DMProject.createProject(id, type, connection, project, getOffset(localRootRelPath),
                        getOffset(remoteOffsetValue), getOffset(workAreaPathValue), getWorkspaceRemoteTree());
                dmProject.setIdeTag(project.getPersistentProperty(IDE_TAG_PROP));
                dmProject.setIdeProjectName(project.getPersistentProperty(IDE_PROJECT_NAME_PROP));
                String s1 = project.getPersistentProperty(IDE_PROJECT_UID_PROP);
                dmProject.setIdeProjectUid(s1 == null ? 0L : Long.parseLong(s1));
                String s2 = project.getPersistentProperty(IDE_PROJECT_MAIN_UID_PROP);
                dmProject.setMainUid(s2 == null ? 0L : Long.parseLong(s2));
                String s3 = project.getPersistentProperty(DM_PROJECT_UID_PROP);
                dmProject.setDmUid(s3 == null ? 0L : Long.parseLong(s3));
                dmProject.setInitial(Boolean.valueOf(project.getPersistentProperty(IDE_PROJECT_INITIAL_PROP)).booleanValue());
                dmProject.setProjectGroup(project.getPersistentProperty(IDE_PROJECT_GROUP_PROP));
                dmProject.setDefaultRequest(project.getPersistentProperty(DEFAULT_REQUEST_PROP), false);
                project.setSessionProperty(DM_PROJECT_PROP, dmProject);
                dmProject.setIsStream(Boolean.valueOf(project.getPersistentProperty(IS_STREAM_PROP)).booleanValue());
            }
        }

        if (dmProject == null) {
            throw new DMException(new Status(IStatus.WARNING, DMTeamPlugin.ID,
                    NLS.bind(Messages.DMRepositoryProvider_BrokenMapping3, project.getName())));
        }

        return dmProject;
    }

    private IPath getOffset(String offset) {
        if (Utils.isNullEmpty(offset)) {
            return null;
        }
        return new Path(offset);
    }

    void projectMoved(String newName) {
        newProject = newName;
        try {
            // reset the cached copy so it is recreated with the new project next time it is accessed
            super.getProject().setSessionProperty(DM_PROJECT_PROP, null);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
    }

    @Override
    public IProject getProject() {
        IProject result = super.getProject();
        if (!result.exists() && newProject != null) {
            result = ResourcesPlugin.getWorkspace().getRoot().getProject(newProject);
            setProject(result);
        }
        return result;
    }

    @Override
    public void setProject(IProject project) {
        super.setProject(project);
        newProject = null;
    }

    static void persistDefaultRequest(DMProject project, String request) throws CoreException {
        project.getProject().setPersistentProperty(DEFAULT_REQUEST_PROP, request);
    }

    @Override
    public IMoveDeleteHook getMoveDeleteHook() {
        return moveDeleteHook;
    }

    @Override
    public IFileModificationValidator getFileModificationValidator() {
        if (DMRepositoryProvider.modificationValidator == null) {
            DMRepositoryProvider.modificationValidator = DMTeamPlugin.getDefault().getPluggedInValidator();
            if (DMRepositoryProvider.modificationValidator == null) {
                return super.getFileModificationValidator();
            }
        }
        return this;
    }

    @Override
    public IStatus validateEdit(IFile[] files, Object context) {
        // delegate to plugged validator
        return modificationValidator.validateEdit(this, files, context);
    }

    @Override
    public IStatus validateSave(IFile file) {
        // delegate to plugged validator
        return modificationValidator.validateSave(this, file);
    }

}

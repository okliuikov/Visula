/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;

import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Marks .metadata folders as private, notifies workspace about
 * resources with changed metadata and containers with ignore file changes.
 *
 * @author V.Grishchenko
 */
class MetadataChangeListener implements IResourceChangeListener, IResourceDeltaVisitor { 

    // consider the following changes types and ignore the others (e.g. marker and description changes are ignored)
    private static final int INTERESTING_CHANGES = IResourceDelta.CONTENT | IResourceDelta.MOVED_FROM
            | IResourceDelta.MOVED_TO | IResourceDelta.OPEN | IResourceDelta.REPLACED | IResourceDelta.TYPE;

    protected boolean isProjectOpening = false;

    private static boolean debugListeners = DMTeamPlugin.getDefault().isDebuggingListeners();

    // use linked lists because ArrayList does not guarantee to shrink its
    // internal array when cleared plus it may be faster to grow a LL as
    // no need to copy elements to a bigger array
    private static final ThreadLocal<LinkedList<IResource>> metadataChanges = new ThreadLocal<LinkedList<IResource>>() {
        @Override
        protected LinkedList<IResource> initialValue() {
            return new LinkedList<IResource>();
        }
    };
    private static final ThreadLocal<LinkedList<IResource>> unmanaged = new ThreadLocal<LinkedList<IResource>>() {
        @Override
        protected LinkedList<IResource> initialValue() {
            return new LinkedList<IResource>();
        }
    };
    private static final ThreadLocal<LinkedList<IContainer>> ignoreChanges = new ThreadLocal<LinkedList<IContainer>>() {
        @Override
        protected LinkedList<IContainer> initialValue() {
            return new LinkedList<IContainer>();
        }
    };
    // use a set to avoid duplicates
    private static final ThreadLocal<HashSet<IContainer>> folderWith3rdPartyFolderMetadataChanges = new ThreadLocal<HashSet<IContainer>>() {
        @Override
        protected HashSet<IContainer> initialValue() {
            return new HashSet<IContainer>();
        }
    };

    private static final ThreadLocal<HashSet<IContainer>> folderWith3rdPartyFileMetadataChanges = new ThreadLocal<HashSet<IContainer>>() {
        @Override
        protected HashSet<IContainer> initialValue() {
            return new HashSet<IContainer>();
        }
    };

    private static final ThreadLocal<HashSet<IResource>> movedResourcesChangesUnderUncontrolledFolder = new ThreadLocal<HashSet<IResource>>() {
        @Override
        protected HashSet<IResource> initialValue() {
            return new HashSet<IResource>();
        }
    };

    public MetadataChangeListener() {
    }

    @Override
    public void resourceChanged(IResourceChangeEvent event) {
        setProjectOpening(false);
        Collection<IResource> stateChanges = metadataChanges.get();
        Collection<IResource> unmanagedChanges = unmanaged.get();
        Collection<IContainer> foldersWithChangedIgnore = ignoreChanges.get();
        Collection<IContainer> thirdPartyFolderMetadataChanges = folderWith3rdPartyFolderMetadataChanges.get();
        Collection<IContainer> thirdPartyFileMetadataChanges = folderWith3rdPartyFileMetadataChanges.get();
        Collection<IResource> changesUnderUncontrolledFolder = movedResourcesChangesUnderUncontrolledFolder.get();
        try {
            event.getDelta().accept(this, IContainer.INCLUDE_TEAM_PRIVATE_MEMBERS);
            if (!unmanagedChanges.isEmpty()) {
                IResource[] unmanagedResources = unmanagedChanges.toArray(new IResource[unmanagedChanges.size()]);
                for (int i = 0; i < unmanagedResources.length; i++) {
                    ((DMWorkspace) DMTeamPlugin.getWorkspace()).releaseBase(unmanagedResources[i]);
                }
            }
            if (!stateChanges.isEmpty()) {
                IResource[] changedResources = stateChanges.toArray(new IResource[stateChanges.size()]);
                changedResources = TeamUtils.getNonOverlapping(changedResources);
                ((DMWorkspace) DMTeamPlugin.getWorkspace()).metadataChanged(changedResources, null);
            }
            if (!foldersWithChangedIgnore.isEmpty()) {
                IContainer[] changedFolders = foldersWithChangedIgnore
                        .toArray(new IContainer[foldersWithChangedIgnore.size()]);
                ((DMWorkspace) DMTeamPlugin.getWorkspace()).ignoreChanged(changedFolders);
            }

            // do markStaleAndProcess for files / folders separately
            // but not for work area rehome check
            Collection<IContainer> bothFilesAndFolders = null;

            if (!thirdPartyFileMetadataChanges.isEmpty()) {
                // run in a workspace method that holds base tree lock
                DMTeamPlugin.getWorkspace().markStaleAndProcess(thirdPartyFileMetadataChanges, true);
                bothFilesAndFolders = new HashSet<IContainer>(thirdPartyFileMetadataChanges);
            }
            if (!thirdPartyFolderMetadataChanges.isEmpty()) {
                // run in a workspace method that holds base tree lock
                DMTeamPlugin.getWorkspace().markStaleAndProcess(thirdPartyFolderMetadataChanges, false);
                if (bothFilesAndFolders == null) {
                    bothFilesAndFolders = new HashSet<IContainer>(thirdPartyFolderMetadataChanges);
                }
                bothFilesAndFolders.addAll(thirdPartyFolderMetadataChanges);
            }
            if (bothFilesAndFolders != null && bothFilesAndFolders.size() > 0) {
                DMTeamPlugin.getWorkspace().handlePossibleWorkAreaRehome(thirdPartyFolderMetadataChanges);
            }
            if (!changesUnderUncontrolledFolder.isEmpty()) {
                ((DMWorkspace) DMTeamPlugin.getWorkspace())
                        .updateBaseResourcesUnderUncontrolledFolders(changesUnderUncontrolledFolder);
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        } finally {
            stateChanges.clear();
            unmanagedChanges.clear();
            foldersWithChangedIgnore.clear();
            thirdPartyFileMetadataChanges.clear();
            thirdPartyFolderMetadataChanges.clear();
            changesUnderUncontrolledFolder.clear();
        }
    }

    @Override
    public boolean visit(IResourceDelta delta) throws CoreException {
        IResource resource = delta.getResource();

        if (resource.getType() == IResource.ROOT) {
            return true;
        }

        if (resource.getType() == IResource.PROJECT) {
            if (!resource.isAccessible()) {
                return false; // If the project is not accessible, don't process it
            }
            if (DMRepositoryProvider.getDMProvider(resource) == null) {
                return false; // ignore changes in unmanaged projects
            }
            setProjectOpening((delta.getFlags() & IResourceDelta.OPEN) != 0);
            if (isProjectOpening()) { // if opening the project sync up with local metadata for the whole project
                Collection<IResource> collection = metadataChanges.get();
                collection.add(resource);
                return true;
            }
        }

        int kind = delta.getKind();

        if (resource.getType() == IResource.FOLDER) {
            String name = resource.getName();
            MetadataProvider mdp = MetadataProviderFactory.providerFor(resource);
            try {
                if (mdp.isMetadataDir(name)) {
                    handleMetadataContainer((IFolder) resource, kind);
                } else {
                    handleControlledUnderUncontrolled(resource);
                }
            } finally {
                if (mdp != null) {
                    mdp.close();
                }
            }
            return true;
        }

        // if the file has changed but not in a way that we care
        // then ignore the change (e.g. marker changes to files).
        if (kind == IResourceDelta.CHANGED && (delta.getFlags() & INTERESTING_CHANGES) == 0) {
            return true;
        }
        MetadataTypes[] mta = new MetadataTypes[1];
        if (isMetadataFile(resource, mta)) {
            if (debugListeners) {
                System.out.println(TeamUtils.myThread() + "ismf " + resource.getLocation() + " mt " + mta[0] + " mstmp "
                        + resource.getModificationStamp());
            }

            if (mta[0] == MetadataTypes.MT_ITEM ||
            	mta[0] == MetadataTypes.MT_DIR)
            {
            	Collection<IContainer> collection = mta[0] == MetadataTypes.MT_ITEM ?
            									folderWith3rdPartyFileMetadataChanges.get():
            									folderWith3rdPartyFolderMetadataChanges.get();

                if (isModifiedBy3rdParty(resource)) {
                    IContainer thirdPartyChange = resource.getParent().getParent();
                    if (debugListeners) {
                        System.out.println(" adding " + thirdPartyChange.getLocation().toString());
                    }
                    collection.add(thirdPartyChange);
                }
            }
        } else if (isIgnoreFile(resource) && TeamUtils.isExternallyModified(resource)) {
            ((Collection<IContainer>) ignoreChanges.get()).add(resource.getParent());
        } else {
            handleControlledUnderUncontrolled(resource);
        }
        return true;
    }

    /**
     * Detect situation when controlled resource placed under uncontrolled folder that has controlled moved parent
     *
     * @param resource
     * @throws CoreException
     */
    private void handleControlledUnderUncontrolled(IResource resource) throws CoreException {
        // process only controlled files/folders that have uncontrolled parent
        IResource parent = resource.getParent();
        if (parent != null && parent.getType() == IResource.FOLDER
                && WorkspaceMetadataManager.getInstance().hasMetadataRecord(resource)) {

            boolean hasNoMdParent = false;
            Set<IResource> resultList = (movedResourcesChangesUnderUncontrolledFolder.get());
            Set<IResource> processedParents = new HashSet<IResource>();
            do {
                if (!WorkspaceMetadataManager.getInstance().hasMetadataRecord(parent)) {
                    hasNoMdParent = true;
                    break;
                }

                processedParents.add(parent);
                parent = TeamUtils.parent(parent);
            } while (parent.getType() != IResource.PROJECT);

            if (hasNoMdParent) {
                // going up in parent folders hierarchy from first folder without md
                // and check if we have any directly moved parent controlled folder
                IResource directlyMovedParent = TeamUtils.getParentWithMovedFromMetadata(parent);
                if (directlyMovedParent != null) {
                    // resource in this case always controlled and moved
                    Assert.isTrue(DMTeamPlugin.getWorkspace().isMoved(resource),
                            "Controlled resource is in not controlled folders must be moved");
                    resultList.add(resource);
                    resultList.addAll(processedParents);
                }
            }
        }
    }

    private void handleMetadataContainer(IFolder metadataContainer, int kind) throws CoreException {
        if ((kind == IResourceDelta.ADDED || kind == IResourceDelta.CHANGED) && !metadataContainer.isTeamPrivateMember()) {
            metadataContainer.setTeamPrivateMember(true); // mark dm metadata container as team private
        }
    }

    boolean isProjectOpening() {
        return isProjectOpening;
    }

    void setProjectOpening(boolean isProjectOpening) {
        this.isProjectOpening = isProjectOpening;
    }

    boolean isMetadataFile(IResource resource, MetadataTypes[] mdTypeHolder) {
        if (resource == null || resource.getType() != IResource.FILE) {
            return false;
        }
        IContainer parent = resource.getParent();
        if (parent == null) {
            return false;
        }
        MetadataProvider mdp = MetadataProviderFactory.providerFor(resource);
        try {
            // use classify on resource could also use
            MetadataTypes mt = mdp.classify(resource.getLocation().toOSString());
            mdTypeHolder[0] = mt;
            return ((mt != MetadataTypes.MT_UNKNOWN && mt != MetadataTypes.MT_UNCONTROLLED)
                    && (parent.isTeamPrivateMember() || !parent.exists()));
        } finally {
            if (mdp != null) {
                mdp.close();
            }
        }

    }

    boolean isIgnoreFile(IResource resource) {
        return resource.getType() == IResource.FILE && DMWorkspace.DM_IGNORE.equals(resource.getName());
    }

    /*
     * Consider non-existing resources as being recently deleted and thus modified, and resources
     * with modification stamps that differ from when we saw it
     */
    protected boolean isModifiedBy3rdParty(IResource resource) {
        if (!resource.exists()) {
            return true;
        }

        long modStamp = resource.getModificationStamp();
        Long whenWeWrote;
        try {
            whenWeWrote = (Long) resource.getSessionProperty(WorkspaceMetadataManager.MODSTAMP_KEY);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
            whenWeWrote = null;
        }
        if (debugListeners) {
            System.out.println(TeamUtils.myThread() + "3rd " + resource.getName() + " ms = " + modStamp + " www = "
                    + (whenWeWrote != null ? whenWeWrote.longValue() : "null"));
        }
        return (whenWeWrote == null || whenWeWrote.longValue() != modStamp);

    }

}

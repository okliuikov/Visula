/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * @author V.Grishchenko
 */
abstract class DMRemoteResource extends DMResourceVariant implements IDMRemoteResource {
    static final int MOVED_FROM_BASELINE = 0x80000000; // this resource was moved from baseline project

    protected String name;
    protected IPath path;
    private IDMProject project;
    private IDMRemoteTree remoteTree;

    protected int flags;
    protected String movedFromPath;
    protected String movedFromProject;
    protected long timestamp;

    // returns IResource type for the bytes stored
    static int getResourceType(byte[] bytes) {
        // resource type is in stored in the second byte
        if (bytes[1] == IDMRemoteResource.FILE) {
            return IResource.FILE;
        }
        return IResource.FOLDER;
    }

    public DMRemoteResource(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree remoteTree) {
        this(parent, path, project, remoteTree, 0L);
    }

    public DMRemoteResource(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree remoteTree, long timestamp) {
        super(project.getConnection());
        this.name = path.isEmpty() ? Utils.EMPTY_STRING : path.lastSegment();
        this.path = path;
        // this.parent = parent;
        this.project = project;
        this.remoteTree = remoteTree;
        if (parent != null) {
            parent.addMember(this);
        }
        this.timestamp = timestamp;
    }

    public DMRemoteResource(IPath path, DimensionsConnectionDetailsEx connection) {
        super(connection);
        this.name = path.isEmpty() ? Utils.EMPTY_STRING : path.lastSegment();
        this.path = path;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public IPath getPath() {
        return path;
    }

    @Override
    public IDMProject getProject() {
        return project;
    }

    @Override
    public void setProject(IDMProject project) {
        if (this.project == null) {
            this.project = project;
        }
    }

    @Override
    public IDMRemoteTree getRemoteTree() {
        return remoteTree;
    }

    @Override
    public IResource getLocalResource() {
        IPath localRelativePath = project.getLocalPathForRemotePath(path);
        if (localRelativePath.isEmpty()) {
            return project.getProject();
        }
        if (isContainer()) {
            return project.getProject().getFolder(localRelativePath);
        }
        return project.getProject().getFile(localRelativePath);
    }

    @Override
    public void delete(IProgressMonitor monitor) throws CoreException {
        // do nothing for now
    }

    @Override
    public boolean exists() {
        return true; // assume exists
    }

    @Override
    public String getMovedFromPath() {
        return movedFromPath;
    }

    @Override
    public String getMovedFromProject() {
        return movedFromProject;
    }

    @Override
    public boolean isMoved() {
        return movedFromPath != null;
    }

    @Override
    public int getMovedFromProjectType() {
        if (Utils.isNullEmpty(movedFromProject)) {
            return 0;
        }
        if (isFlagSet(MOVED_FROM_BASELINE)) {
            return IDMProject.BASELINE;
        }
        return IDMProject.WORKSET;
    }

    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public boolean isStale() {
        return timestamp != 0;
    }

    @Override
    public void markStale() {
        timestamp = -1;
    }

    protected boolean isBaseResource() {
        return remoteTree instanceof DMBaseResourceVariantTree;
    }

    protected boolean isFlagSet(int flag) {
        return (flags & flag) == flag;
    }

    protected void updateFlag(int flag, boolean set) {
        if (set) {
            flags |= flag;
        } else {
            flags &= ~flag;
        }
    }

    protected void initMovedState(BaseMetadata metadata) {
        String movedFrom = metadata instanceof ItemMetadata
                ? ((ItemMetadata) metadata).getMovedFrom() : ((DirectoryMetadata) metadata).getMovedFrom();
        if (!Utils.isNullEmpty(movedFrom)) {
            movedFromPath = movedFrom;
            movedFrom = metadata.get(WorkspaceMetadataManager.FROM_PROJECT);
            if (!Utils.isNullEmpty(movedFrom)) {
                movedFromProject = movedFrom;
            } else {
                movedFrom = metadata.get(WorkspaceMetadataManager.FROM_BASELINE);
                if (!Utils.isNullEmpty(movedFrom)) {
                    movedFromProject = movedFrom;
                    updateFlag(MOVED_FROM_BASELINE, true);
                }
            }
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;

import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
class DMRemoteFolder extends DMRemoteResource implements IDMRemoteFolder {
    private static final byte VERSION_2 = 2; // timestamp aka stale written as byte
    private static final byte VERSION_3 = 3; // project/baseline uid, project version, base project version and dir-uid

    private static final byte BYTES_VERSION = VERSION_3; // ensure we have a way to know what's stored

    private List<IDMRemoteResource> members;
    private RepositoryFolder repositoryFolder;
    private String mdRelPath = Utils.EMPTY_STRING;
    private long mdProjectUid = IDMConstants.INVALID_UID;
    private long mdBaselineUid = IDMConstants.INVALID_UID;
    private long mdProjectVer = IDMConstants.INVALID_UID;
    private long mdBaseProjectVer = IDMConstants.INVALID_UID;
    private long mdDirUid = IDMConstants.INVALID_UID;
    private DirectoryMetadata metadata;

    public DMRemoteFolder(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree tree) {
        this(parent, path, project, tree, (RepositoryFolder) null);
    }

    public DMRemoteFolder(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree tree,
            RepositoryFolder repositoryFolder) {
        super(parent, path, project, tree);
        this.repositoryFolder = repositoryFolder;
    }

    public DMRemoteFolder(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree tree, byte[] bytes)
            throws IOException {
        super(parent, path, project, tree);
        fromBytes(bytes);
    }

    public DMRemoteFolder(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree tree, DirectoryMetadata metadata,
            long timestamp) {
        super(parent, path, project, tree, timestamp);
        fromMetadata(metadata);
    }

    @Override
    public byte getType() {
        return FOLDER;
    }

    @Override
    public RepositoryFolder getRepositoryFolder() throws DMException {
        if (repositoryFolder == null) {
            repositoryFolder = getProject().getRepositoryFolderProxy(getPath());
        }
        return repositoryFolder;
    }

    public void setRepositoryFolder(RepositoryFolder repositoryFolder) {
        this.repositoryFolder = repositoryFolder;
    }

    public synchronized IDMResource[] fetchMembers(IProgressMonitor monitor) throws CoreException {
        members = ((DMResourceVariantTree) getRemoteTree()).fetchFolderMembers(this, monitor);
        return members.toArray(new IDMRemoteResource[members.size()]);
    }

    IDMResource[] getCachedMembers() {
        if (members == null) {
            return null;
        }
        return members.toArray(new IDMRemoteResource[members.size()]);
    }

    @Override
    public void accept(IDMResourceVisitor visitor) throws CoreException {
        Assert.isNotNull(visitor);
        if (visitor.visit(this) && members != null) {
            for (Iterator<IDMRemoteResource> memberIter = members.iterator(); memberIter.hasNext();) {
                IDMRemoteResource aMember = memberIter.next();
                aMember.accept(visitor);
            }
        }
    }

    void resetMembers() {
        members = null;
    }

    void initMembers() {
        if (members == null) {
            members = new ArrayList<IDMRemoteResource>(5);
        }
    }

    void addMember(IDMRemoteResource r) {
        initMembers();
        members.add(r);
    }

    @Override
    public IDMResource[] getMembers() throws CoreException {
        IResource[] members1 = getRemoteTree().members(getLocalResource());
        IDMRemoteResource[] result = new IDMRemoteResource[members1.length];
        for (int i = 0; i < result.length; i++) {
            result[i] = (IDMRemoteResource) getRemoteTree().getResourceVariant(members1[i]);
        }
        return result;
    }

    @Override
    protected void fetchContents(IProgressMonitor monitor) throws TeamException {
        // shouldn't be called as folders have no contents
    }

    @Override
    public String getContentIdentifier() {
        return String.valueOf(getProject().getType()) + '/' + getProject().getId() + '/' + getPath().toString();
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof IDMRemoteFolder) {
            IDMRemoteFolder otherRemote = (IDMRemoteFolder) object;
            if (getProject().getConnection() == otherRemote.getProject().getConnection()) {
                return getPath().equals(otherRemote.getPath());
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return getProject().hashCode() ^ getPath().hashCode();
    }

    /*
     * 1. bytes version
     * 2. resource type
     * 3. flags
     * 4. movedFrom
     * 5. movedFromProject
     * 6. timestamp
     */
    @Override
    protected byte[] toBytes() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DataOutputStream dataOut = new DataOutputStream(out);
        try {
            dataOut.writeByte(BYTES_VERSION);
            dataOut.writeByte(FOLDER);
            dataOut.writeInt(flags);
            dataOut.writeUTF(movedFromPath != null ? movedFromPath : Utils.EMPTY_STRING);
            dataOut.writeUTF(movedFromProject != null ? movedFromProject : Utils.EMPTY_STRING);
            // write a byte
            dataOut.writeByte((int) timestamp);

            // since 14.1
            dataOut.writeUTF(mdRelPath == null ? Utils.EMPTY_STRING : mdRelPath);
            dataOut.writeLong(mdProjectUid);
            dataOut.writeLong(mdBaselineUid);
            dataOut.writeLong(mdProjectVer);
            dataOut.writeLong(mdBaseProjectVer);
            dataOut.writeLong(mdDirUid);

            dataOut.flush();
        } catch (IOException e) {
            DMTeamPlugin.getDefault()
                    .getLog()
                    .log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, "Failed create bytes for folder", e)); //$NON-NLS-1$
        }
        return out.toByteArray();
    }

    void fromBytes(byte[] bytes) throws IOException {
        assert bytes != null;
        DataInputStream dataIn = new DataInputStream(new ByteArrayInputStream(bytes));
        byte bytesVersion = dataIn.readByte();
        byte resourceType = dataIn.readByte();
        assert resourceType == FOLDER;
        flags = dataIn.readInt();
        String movedFrom = dataIn.readUTF();
        if (movedFrom.length() > 0) {
            movedFromPath = movedFrom;
        }
        movedFrom = dataIn.readUTF();
        if (movedFrom.length() > 0) {
            movedFromProject = movedFrom;
        }
        if (bytesVersion < VERSION_2) {
            // was a long
            timestamp = dataIn.readLong();
        } else {
            timestamp = dataIn.readByte();
        }

        // since 14.1
        if (bytesVersion >= VERSION_3) {
            mdRelPath = dataIn.readUTF();
            mdProjectUid = dataIn.readLong();
            mdBaselineUid = dataIn.readLong();
            mdProjectVer = dataIn.readLong();
            mdBaseProjectVer = dataIn.readLong();
            mdDirUid = dataIn.readLong();
        }
    }

    private void fromMetadata(DirectoryMetadata metadata) {
        assert metadata != null;
        initMovedState(metadata);
        this.mdProjectUid = metadata.getProjectUid();
        this.mdBaselineUid = metadata.getBaselineUid();
        this.mdProjectVer = metadata.getProjectVer();
        this.mdBaseProjectVer = metadata.getBaseProjectVer();
        this.mdDirUid = metadata.getDirUid();
        this.mdRelPath = metadata.getRelPath();
        this.metadata = metadata;
    }

    static DMRemoteFolder fromBytes(IPath path, IDMProject dmProject, IDMRemoteTree tree, byte[] bytes) throws IOException {
        return new DMRemoteFolder(null, path, dmProject, tree, bytes);
    }

    public DirectoryMetadata getMetadata() {
        DirectoryMetadata result = this.metadata; // use md if already have it
        if (result == null) {
            result = new DirectoryMetadata();
            result.setMovedFrom(movedFromPath);
            result.setRelPath(mdRelPath);
            result.setProjectUid(mdProjectUid);
            result.setBaselineUid(mdBaselineUid);
            result.setProjectVer(mdProjectVer);
            result.setBaseProjectVer(mdBaseProjectVer);
            result.setDirUid(mdDirUid);
        }
        return result;
    }

}

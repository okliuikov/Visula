/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;

import com.serena.dmclient.objects.ItemType;
import com.serena.dmclient.objects.ItemTypeCMRules;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public abstract class CMRulesSensitiveRequest extends ItemRequest {
    /** require change requests for new items */
    public static final int NEW_ITEM = 1;
    /** require change requests on checkout at or beyond a particular state */
    public static final int CHECKOUT = 2;
    /** require change requests on action at or beyond a particular state */
    public static final int ACTION = 3;

    private boolean anyRequest;
    private int cmRuleDetails;
    private String currentState;

    protected boolean rulesEnabled;

    public CMRulesSensitiveRequest(IFile file, ItemType itemType, int cmRuleDetails, boolean enforceRequest, boolean anyRequest)
            throws CoreException {
        super(file, itemType, true, enforceRequest);
        Assert.isLegal(cmRuleDetails == NEW_ITEM || cmRuleDetails == CHECKOUT || cmRuleDetails == ACTION);
        this.cmRuleDetails = cmRuleDetails;
        this.anyRequest = anyRequest;
        IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(getFile());
        assert dmProject != null;
        DimensionsConnectionDetailsEx connection = dmProject.getConnection();
        initialize(connection.openSession(null));
    }

    protected void initialize(final Session session) throws DMException {
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                ItemTypeCMRules cmRules = getType().getCmRules();
                rulesEnabled = cmRules.getEnabled();
            }
        }, new NullProgressMonitor());
    }

    /**
     * @return the operation category in CM rules context (new, checkout,
     *         action).
     */
    public int getCMRulesDetails() {
        return cmRuleDetails;
    }

    /**
     * @return Returns the currentState.
     */
    public String getCurrentState() {
        return currentState;
    }

    public boolean isRulesEnabled() {
        return rulesEnabled;
    }

    /**
     * @return <code>true</code> if any restrictions for request selection
     *         imposed by cm rules do not apply, returns <code>false</code> otherwise
     */
    public boolean isAnyRequest() {
        return anyRequest;
    }

}

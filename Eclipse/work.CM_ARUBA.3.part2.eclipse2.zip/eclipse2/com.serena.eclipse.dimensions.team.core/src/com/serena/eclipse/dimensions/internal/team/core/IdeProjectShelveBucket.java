package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.TreeSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

import com.serena.dmfile.FilePlatforms;
import com.serena.dmfile.FileToTransfer;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.sync.Shape;
import com.serena.dmfile.xml.OutgoingMergePoint;
import com.serena.dmfile.xml.Workarea;
import com.serena.dmfile.xml.ide.OutgoingIdeProject;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Bucket represents one ide project for delivery operation
 */
public class IdeProjectShelveBucket extends OutgoingIdeProject {
    private List<WorkspaceResourceRequest> contents = new ArrayList<WorkspaceResourceRequest>();
    private boolean sawCreate;
    private boolean sawUpdate;
    private boolean all;
    private TransferToStreamOperationData opData;
    private WorksetProject project;
    private List<IResource> scopes;
    private String comment;
    private Map<Integer, Object> amap = Collections.<Integer, Object>emptyMap();
    private Map<String, String> encMap = Collections.<String, String>emptyMap();

    private SortedSet<String> shelveIncludes = new TreeSet<String>(new Comparator<String>() {

        @Override
        public int compare(String o1, String o2) {
            return StringPath.pathCompare(o1, o2, false);
        }
    });

    public IdeProjectShelveBucket(List<WorkspaceResourceRequest> resourceRequests, TransferToStreamOperationData opData) {
        Assert.isLegal(opData.getProject() instanceof WorksetProject);
        TransferShape transferShape = opData.getTransferShape();
        Assert.isNotNull(transferShape);
        setShape(transferShape.getShape());
        Assert.isLegal(getShape() != Shape.LIST); // list shape not supported by shelve command
        this.scopes = transferShape.getScopes();
        this.opData = opData;
        this.project = (WorksetProject) opData.getProject();

        internalAddRequests(resourceRequests);
        initGeneralCommandParams();
        createObjectsToTransfer();
    }

    /**
     * @return the all
     */
    public boolean isAll() {
        return all;
    }

    /**
     * @param all the all to set
     */
    public void setAll(boolean all) {
        this.all = all;
    }

    /**
     * @return requests for delivery
     */
    public List<WorkspaceResourceRequest> getContents() {
        return contents;
    }

    /**
     * @return the attribute map
     */
    public Map<Integer, Object> getAttributeMap() {
        return amap;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @return set the comment
     */
    @Override
    public void setComment(String comment) {
        super.setComment(comment);
        this.comment = comment;
    }

    /**
     * Adds requests to shelve bucket, collects necessary information like encoding, attributes, etc.
     * @param resourceRequests to process
     */
    private void internalAddRequests(List<WorkspaceResourceRequest> resourceRequests) {
        for (WorkspaceResourceRequest request : resourceRequests) {
            contents.add(request);
            initCommandParamsFromRequest(request);

            if (request.getResource() instanceof IFile && request instanceof UploadRequest) {
                UploadRequest uploadRequest = (UploadRequest) request;
                IUploadRequestParameters parameters = uploadRequest.getParameters();
                if (parameters != null) {
                    String charset = parameters.getCharset();
                    if (charset != null) {
                        encMap.put(request.getResource().getLocation().toOSString(), charset);
                    }
                }
            }

            String foreignStream = DeliverBucketHelper.getStream(request.getResource());
            // Check for Global workset is added in the below if clause because when you do a "Mark as merged" the project in the
            // metadata file is set as $GLOBAL:$GENERAL and not the actual project of the item being marked as merged
            // So we need to exclude $GLOBAL:$GENERAL from the list of foreign streams

            // KB> DEF211040 fix - enable delivering baseline contents by using /ALL instead of /CONTRIB=()
            // KB> We use /ALL as a shortcut to deliver resources from all the streams except those deselected on
            // RunAndProcessStreamSelectDialog and all the baselines.
            if (!isAll() && foreignStream != null && !foreignStream.equals(project.getId())) {
                setAll(true);
            } else if (!isAll() && DeliverBucketHelper.isBaseline(request.getResource())) {
                setAll(true);
            }
        }
    }

    /**
     * Init command parameters from transfer request
     * @param request to set parameters from
     */
    private void initCommandParamsFromRequest(WorkspaceResourceRequest request) {
        if (request instanceof UploadRequest) {
            UploadRequest uploadRequest = (UploadRequest) request;
            IUploadRequestParameters parameters = uploadRequest.getParameters();
            setComment(Utils.getString(parameters.getComment()));

            if (!(sawCreate || sawUpdate) && (uploadRequest.isCreateItem() || uploadRequest.isUpdate())) {
                setDescription(parameters.getDescription());
                setRelatedRequests(parameters.getRelatedRequests());
            }

            if (!sawCreate && uploadRequest.isCreateItem()) {
                setPart(DeliverBucketHelper.getOwningPart(uploadRequest));
            }

            if (amap.isEmpty()) {
                int[] attrs = parameters.getAttributes();
                if (attrs != null && attrs.length == 0) {
                    this.amap = new HashMap<Integer, Object>(attrs.length);
                    for (int i = 0; i < attrs.length; i++) {
                        amap.put(new Integer(attrs[i]), parameters.getAttribute(attrs[i]));
                    }
                }
            }

            sawCreate |= uploadRequest.isCreateItem();
            sawUpdate |= uploadRequest.isUpdate();
        } else if (request instanceof FolderRequest || request instanceof ItemRevisionRequest) {
            if (request.isRequestSupported()) {
                setRelatedRequests(request.getChangeRequests());
            }
            if (request instanceof IMoveRequest) {
                setComment(Utils.getString(((IMoveRequest) request).getComment()));
            }
        }
    }

    /**
     * Init general parameters
     */
    private void initGeneralCommandParams() {
        setLabel(project.getProject().getName());
        setOffset(project.getRemoteOffset().isEmpty() ? "" : project.getRemoteOffset().toOSString());
        setWorkareaRoot(project.getUserDirectory().toOSString());
        setUploadRuleset(project.getUploadRuleId() + ':' + String.valueOf(project.getIdeProjectUid()));

        Workarea workarea = ObjectToTransfer.scanWorkAreaMetadata(project.getUserDirectory().toOSString());
        List<OutgoingMergePoint> mergePoints = ObjectToTransfer.scanMergePointsMetadata(project.getUserDirectory().toOSString());
        DeliverBucketHelper.addIgnoredContributors(mergePoints, opData);

        setWorkarea(workarea);
        setMergePoints(mergePoints);
    }

    /**
     * Creates transfer list
     */
    private void createObjectsToTransfer() {
        // scan each scope
        List<ObjectToTransfer> filesToTransfer = new ArrayList<ObjectToTransfer>();
        for (Iterator<IResource> iterator = scopes.iterator(); iterator.hasNext();) {
            IResource scope = iterator.next();

            if (scope instanceof IContainer) {
                List<FileToTransfer> dirScan = createDirectoryScan((IContainer) scope);
                if (getShape() == Shape.MULTISELECT && !dirScan.isEmpty()) {
                    dirScan.get(0).setStartPath(true);
                }

                Collections.sort(dirScan, new Comparator<FileToTransfer>() {

                    @Override
                    public int compare(FileToTransfer o1, FileToTransfer o2) {
                        return StringPath.pathCompare(o1.getFileName(), o2.getFileName(), false);
                    }
                });

                filesToTransfer.addAll(dirScan);
            } else {
                String osPath = scope.getLocation().toOSString();
                FileToTransfer fileEx = ObjectToTransfer.scanSingleFileEx(osPath);
                if (fileEx != null) {
                    filesToTransfer.add(fileEx);
                    if (getShape() == Shape.MULTISELECT) {
                        fileEx.setStartPath(true);
                    }
                }
            }
        }

        addEncoding(filesToTransfer);
        initShelveIncludesFilter(filesToTransfer);

        setFilesToTransfer(filesToTransfer);
    }

    /**
     * Add encoding to transfer objects if needed
     * @param filesToUpload transfer list
     */
    private void addEncoding(List<ObjectToTransfer> filesToUpload) {
        for (ObjectToTransfer transferObject : filesToUpload) {
            String scannedPath = transferObject.getFileName();
            String charset = encMap.get(scannedPath);
            if (charset != null) {
                transferObject.setFileEncoding(charset);
            }
        }
    }

    /**
     * Creates shelve includes filter from list of transfer objects. List of transfer objects is a result of recursive scan of
     * workarea.
     * @param filesToUpload is a list of transfer objects
     */
    private void initShelveIncludesFilter(List<ObjectToTransfer> filesToUpload) {
        // set includes to filter all other resources which were scanned by recursive scanner
        for (ObjectToTransfer transferObject : filesToUpload) {
            String scannedPath = transferObject.getFileName();
            for (WorkspaceResourceRequest request : contents) {
                String resourcePath = request.getResource().getLocation().toOSString();

                if (request instanceof DeleteItemRevisionRequest) {
                    // check if container folder was moved (renamed)
                    // if so, path will be a new renamed folder for deleted item
                    IResource parentRes = request.getResource().getParent();
                    try {
                        IResource movedToRes = DMTeamPlugin.getWorkspace().getMovedTo(parentRes);
                        if (movedToRes != null) {
                            resourcePath = movedToRes.getLocation().append(request.getResource().getName()).toOSString();
                        }
                    } catch (CoreException e) {
                        DMTeamPlugin.log(e.getStatus());
                    }
                }

                if (!StringPath.isNullorEmpty(resourcePath) && resourcePath.equals(scannedPath)) {
                    addIncludedPath(transferObject, project.getUserDirectory());
                }
            }
        }
    }

    private void addIncludedPath(ObjectToTransfer transferObject, IPath workareaPath) {
        String fileName = transferObject.getFileName();
        IPath fileNamePath = new Path(fileName);
        IPath relative = fileNamePath.makeRelativeTo(workareaPath);

        String path;
        if (project.isContainedEclipseProject() && !project.isFullWorkArea()) {
            String remoteOffset = project.getRemoteOffset().toString();
            if (!StringPath.isTerminated(remoteOffset)) {
                remoteOffset = StringPath.terminateWith(remoteOffset, FilePlatforms.REPOSITORY);
            }
            path = remoteOffset + relative.toString();
        } else {
            path = relative.toString();
        }

        if (transferObject.isFolder()) {
            if (!StringPath.isTerminated(path)) {
                path = StringPath.terminateWith(path, FilePlatforms.REPOSITORY);
            }
        }

        shelveIncludes.add(path);
        addPathParentsToFilter(path);
    }

    /**
     * Adds all parent paths of <code>path</code>to shelf-includes filter. This is required by server implementation
     * @param path to get parents
     */
    private void addPathParentsToFilter(String path) {
        StringPath sPath = new StringPath(path);

        StringPath parent = sPath.getParentPath();
        while (!parent.isEmpty()) {
            parent.terminate();
            shelveIncludes.add(parent.getPath().replace('\\', '/'));
            parent = parent.getParentPath();
        }
    }

    /**
     * Creates directory scan. Scan could include start path directory if it not equals to workarea root.
     * @param container container to scan
     * @return list of files to transfer
     */
    private List<FileToTransfer> createDirectoryScan(IContainer container) {
        String dirPath = container.getLocation().toOSString();

        List<FileToTransfer> dirScan;
        if (container instanceof IProject && getShape() == Shape.TREE) {
            if (project.isContainedEclipseProject() && !project.isFullWorkArea()) {
                // for relative workarea case project root is a workarea folder
                dirScan = ObjectToTransfer.scanDirectoryEx(dirPath, true, false);
            } else if (!project.isContainedEclipseProject()) {
                // for not contained project project root is a workarea folder
                dirScan = ObjectToTransfer.scanDirectoryEx(dirPath, true, false);
            } else {
                // other cases
                dirScan = ObjectToTransfer.scanDirectoryEx(dirPath, true, true);
            }
        } else {
            // multiselect, not a project, always include self
            dirScan = ObjectToTransfer.scanDirectoryEx(dirPath, true, true);
        }
        return dirScan;
    }

    public String assembleResult() {
        List<ObjectToTransfer> results = getTransferResults();
        StringBuffer buf = new StringBuffer();

        for (Iterator<ObjectToTransfer> rIter = results.iterator(); rIter.hasNext();) {
            ObjectToTransfer fileResult = rIter.next();
            List<String> commands = fileResult.getCommands();
            if (commands != null) {
                for (Iterator<String> cIter = commands.iterator(); cIter.hasNext();) {
                    String command = cIter.next();
                    if (!Utils.isNullEmpty(command)) {
                        buf.append(command);
                        if (command.charAt(command.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
            List<String> messages = fileResult.getMessages();
            if (messages != null) {
                for (Iterator<String> mIter = messages.iterator(); mIter.hasNext();) {
                    String message = mIter.next();
                    if (!Utils.isNullEmpty(message)) {
                        buf.append(message);
                        if (message.charAt(message.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
        }
        return buf.toString();
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer("[IdeProject Shelve Bucket]\n"); //$NON-NLS-1$
        buf.append(contents.size() + " files:\n"); //$NON-NLS-1$
        for (int i = 0; i < contents.size(); i++) {
            WorkspaceResourceRequest request = contents.get(i);
            IResource res = request.getResource();
            if (i > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(res.getLocation().toOSString());
        }

        setLabel(project.getProject().getName());
        setOffset(project.getRemoteOffset().isEmpty() ? "" : project.getRemoteOffset().toOSString());
        setWorkareaRoot(project.getUserDirectory().toOSString());
        setUploadRuleset(project.getUploadRuleId() + ':' + String.valueOf(project.getIdeProjectUid()));
        setShape(opData.getTransferShape().getShape());
        buf.append("\nLabel=").append(getLabel()).append('\n'); //$NON-NLS-1$
        buf.append("Offset=").append(getOffset()).append('\n'); //$NON-NLS-1$
        buf.append("WorkareaRoot=").append(getWorkareaRoot()).append('\n'); //$NON-NLS-1$
        buf.append("Shape=").append(getShape()).append('\n'); //$NON-NLS-1$
        buf.append("CommandParameters=").append(getCommandParameters().toString()).append('\n'); //$NON-NLS-1$

        buf.append("Attributes:\n"); //$NON-NLS-1$
        Map<?, ?> attrMap = getAttributeMap();
        int cnt = 0;
        for (Iterator<?> iter = attrMap.entrySet().iterator(); iter.hasNext();) {
            Map.Entry<?, ?> entry = (Entry<?, ?>) iter.next();
            if (cnt > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(entry.getKey()).append('=').append(entry.getValue());
            cnt++;
        }
        buf.append("\n[/IdeProject Shelve Bucket]"); //$NON-NLS-1$
        return buf.toString();
    }

    public String getShelveIncludes() {
        return StringPath.join(shelveIncludes, ",");
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * Merge specific sync info
 * @author V.Grishchenko
 */
public class DMMergeSyncInfo extends DMSyncInfo {

    /**
     * @param local
     * @param base
     * @param remote
     * @param comparator
     */
    public DMMergeSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote, IResourceVariantComparator comparator,
            Subscriber subscriber, DimensionsConnectionDetailsEx connection) {
        super(local, base, remote, comparator, subscriber, connection);
    }

    @Override
    protected int calculateKind() throws TeamException {
        // Report merged resources as in-sync
        if (((DMMergeSubscriber) getSubscriber()).isMerged(getLocal())) {
            return IN_SYNC;
        }

        int kind = getSyncKind();

        // Report outgoing resources as in-sync
        if ((kind & DIRECTION_MASK) == OUTGOING) {
            return IN_SYNC;
        }

        return kind;
    }

    private int getSyncKind() throws TeamException {
        int sync = super.calculateKind();
        try {
            if (DMTeamPlugin.getWorkspace().getWorkspaceResource(getLocal()) instanceof IDMWorkspaceFile) {
                IDMWorkspaceFile localFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(getLocal());
                if (TeamUtils.isConsiderContentsForComparison()) {
                    if (sync == (CONFLICTING | CHANGE) || sync == (CONFLICTING | ADDITION)
                            || sync == (CONFLICTING | ADDITION | PSEUDO_CONFLICT) || sync == (INCOMING | CHANGE)
                            || sync == (OUTGOING | CHANGE)) {
                        DMRemoteFile remoteFile = (DMRemoteFile) super.getRemote();
                        if (TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                            return IN_SYNC;
                        }
                    }
                }
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
        return sync;
    }
}

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.ISubscriberChangeEvent;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantTree;

import com.serena.eclipse.dimensions.core.util.Utils;

public class CustomSubscriber extends DMSyncTreeSubscriber {
    private IResource[] roots;
    private DMResourceVariantTree remoteTree;
    private Map<?, ?> remoteResourcesMap;

    public CustomSubscriber(IResource[] roots, Map<?, ?> remoteResourcesMap) {
        this.roots = roots;
        this.remoteResourcesMap = remoteResourcesMap;
        remoteTree = new CustomResourceVariantTree(new CustomByteStore(), this);
        ((DMWorkspace) DMTeamPlugin.getWorkspace()).setUpdateFromReqSubscriber(this);
    }

    @Override
    public IStatus merged(IResource[] locals, IDMRemoteResource[] remotes, IProgressMonitor monitor) throws CoreException {
        // delegate this operation to DMWorkspace
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).merged(locals, remotes, monitor);
    }

    // Open this method to public to invoke it on refresh in DMWorkspace
    @Override
    public void fireTeamResourceChange(final ISubscriberChangeEvent[] deltas) {
        super.fireTeamResourceChange(deltas);
    }

    @Override
    protected IResourceVariantTree getBaseTree() {
        return ((DMWorkspace) DMTeamPlugin.getWorkspace()).getBaseTree();
    }

    @Override
    protected IResourceVariantTree getRemoteTree() {
        return remoteTree;
    }

    public Map<?, ?> getResourceMap() {
        return remoteResourcesMap;
    }

    @Override
    public boolean isSupervised(IResource resource) throws TeamException {
        if (resource.getType() == IResource.FOLDER || resource.getType() == IResource.PROJECT) {
            Iterator<?> iter = remoteResourcesMap.keySet().iterator();
            while (iter.hasNext()) {
                IPath resourcePath = resource.getFullPath();
                IPath mappedPath = ((IResource) iter.next()).getFullPath();
                // we supervise all parent resources for the mapped files
                // directly mapped folder paths are supervised as well
                if (resourcePath.isPrefixOf(mappedPath) || resourcePath.equals(mappedPath)) {
                    return super.isSupervised(resource);
                }
            }
        } else {
            if (remoteResourcesMap.containsKey(resource)) {
                return super.isSupervised(resource);
            }
        }
        return false;
    }

    @Override
    public IResource[] roots() {
        if (roots == null) {
            return new IResource[0];
        }
        return roots;
    }

    @Override
    protected SyncInfo getSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote) throws TeamException {
        try {
            DMWorkspaceSyncInfo syncInfo = new DMWorkspaceSyncInfo(local, base, remote, getResourceComparator(), this,
                    getConnectionForResource(local, base, remote));
            syncInfo.init();
            return syncInfo;
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
    }

    @Override
    public void refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
        super.refresh(resources, depth, monitor);
        DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
        // Update DMWorkspace remote tree (to use its searchForMovedInRepostoryResources() in the right way)
        Iterator<?> iter = remoteResourcesMap.keySet().iterator();
        while (iter.hasNext()) {
            IResource resourceToUpdate = (IResource) iter.next();
            workspace.updateRemote(resourceToUpdate, getRemoteTree().getResourceVariant(resourceToUpdate));
        }
        // seek for and register repository moves
        try {
            List<IResource> resourcesToCheck = new ArrayList<IResource>();
            for (int i = 0; i < resources.length; i++) {
                if (resources[i] instanceof IProject && !(((IProject) resources[i]).isOpen() && workspace.isManaged(resources[i]))) {
                    continue;
                }
                resourcesToCheck.add(resources[i]);
            }
            workspace.searchForMovedInRepostoryResources(
                    resourcesToCheck.toArray(new IResource[resourcesToCheck.size()]), depth,
                    Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        } finally {
            monitor.done();
        }
    }
}

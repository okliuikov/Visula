/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.util.List;

import org.eclipse.core.runtime.IPath;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.core.VersionManagementProject;

/**
 * Should contains all information to perform three way merge/update.
 */
public abstract class MergeCommandOptions {
    private VersionManagementProject sourceWorkset = null;
    private MergeCommandLocalScope localScope = null;
    private boolean interactive = false;
    private boolean autoMerge = false;
    private boolean applyRepositoryDateTime = false;
    private boolean showSummary = false;
    private boolean loggingEnabled = false;
    private IPath loggingPath = null;
    private boolean doUpdate = false;
    private boolean expandSubstitution = false;

    public boolean isValidCommandMode() {
        if (localScope == null || sourceWorkset == null) {
            return false;
        }
        boolean sameSrcDst = localScope.getTargetProjectSpec().equals(sourceWorkset.getProjectSpec());
        return sameSrcDst == doUpdate;
    }

    public String getLocalSpec() {
        if (localScope == null) {
            return null;
        }
        return localScope.getTargetProjectSpec();
    }

    public String getRemoteSpec() {
        if (sourceWorkset == null) {
            return null;
        }
        return sourceWorkset.getProjectSpec();
    }

    public MergeCommandLocalScope getLocalScope() {
        return localScope;
    }

    public void setLocalScope(MergeCommandLocalScope localScope) {
        this.localScope = localScope;
    }

    public boolean isExpandSubstitution() {
        return expandSubstitution;
    }

    public void setExpandSubstitution(boolean expandSubstitution) {
        this.expandSubstitution = expandSubstitution;
    }

    public boolean isInteractive() {
        return interactive;
    }

    public void setInteractive(boolean interactive) {
        this.interactive = interactive;
    }

    public boolean isAutoMerge() {
        return autoMerge;
    }

    public void setAutoMerge(boolean autoMerge) {
        this.autoMerge = autoMerge;
    }

    public boolean isApplyRepositoryDateTime() {
        return applyRepositoryDateTime;
    }

    public void setApplyRepositoryDateTime(boolean applyRepositoryDateTime) {
        this.applyRepositoryDateTime = applyRepositoryDateTime;
    }

    public boolean isShowSummary() {
        return showSummary;
    }

    public void setShowSummary(boolean showSummary) {
        this.showSummary = showSummary;
    }

    public boolean isLoggingEnabled() {
        return loggingEnabled;
    }

    public void setLoggingEnabled(boolean loggingEnabled) {
        this.loggingEnabled = loggingEnabled;
    }

    public IPath getLoggingPath() {
        return loggingPath;
    }

    public void setLoggingPath(IPath loggingPath) {
        this.loggingPath = loggingPath;
    }

    public VersionManagementProject getSourceWorkset() {
        return sourceWorkset;
    }

    public String getSourceWorksetSpec() {
        if (sourceWorkset != null) {
            return sourceWorkset.getObjectSpec();
        }
        return "";
    }

    public void setSourceWorkset(VersionManagementProject sourceWorkset) {
        this.sourceWorkset = sourceWorkset;
    }

    public boolean isDoUpdate() {
        return doUpdate;
    }

    public void setDoUpdate(boolean doUpdate) {
        this.doUpdate = doUpdate;
    }

    /**
     * Contains options that specific for project/baseline merge/update. Represents source of merge
     */
    public static class MergeWorksetOptions extends MergeCommandOptions {
        private boolean baseline;
        private DimensionsChangeSet changeSet;
        private boolean reset;
        private boolean clean;
        private boolean undo = false;

        public DimensionsChangeSet getChangeSet() {
            return changeSet;
        }

        public void setChangeSet(DimensionsChangeSet changeSet) {
            this.changeSet = changeSet;
        }

        public boolean isBaseline() {
            return baseline;
        }

        public void setBaseline(boolean baseline) {
            this.baseline = baseline;
        }

        public boolean isReset() {
            return reset;
        }

        public void setReset(boolean reset) {
            this.reset = reset;
        }

        public boolean isClean() {
            return clean;
        }

        public void setClean(boolean clean) {
            this.clean = clean;
        }

        public void setUndo(boolean undo) {
            this.undo = undo;
        }

        public boolean isUndo() {
            return undo;
        }
    }

    /**
     * Contains options that specific for request merge/update. Represents source of merge
     */
    public static class MergeRequestsOptions extends MergeCommandOptions {
        private List<Request> requests = null;
        private boolean includeRealtedItems = false;
        private boolean cherrypick = false;

        public boolean isIncludeRealtedItems() {
            return includeRealtedItems;
        }

        public void setIncludeChildRequests(boolean includeRealtedItems) {
            this.includeRealtedItems = includeRealtedItems;
        }

        public boolean isCherrypick() {
            return cherrypick;
        }

        public void setCherrypick(boolean cherrypick) {
            this.cherrypick = cherrypick;
        }

        public List<Request> getSourceRequests() {
            return requests;
        }

        public void setSourceRequests(List<Request> requests) {
            this.requests = requests;
        }

    }

}
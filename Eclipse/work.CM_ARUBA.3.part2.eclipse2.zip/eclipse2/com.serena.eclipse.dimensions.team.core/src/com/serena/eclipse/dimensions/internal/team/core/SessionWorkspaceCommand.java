/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Provides a convenience method to run this command inside a <code>ISessionRunnable</code>.
 *
 * @author V.Grishchenko
 */
abstract class SessionWorkspaceCommand extends DMWorkspaceCommand1 {

    /**
     * @param dmProject
     * @param requests
     * @param outputToConsole
     */
    public SessionWorkspaceCommand(DMProject dmProject, WorkspaceResourceRequest[] requests, boolean outputToConsole) {
        super(dmProject, requests);
    }

    @Override
    protected final void execute(final IProgressMonitor monitor) throws CoreException {
        final Session session = dmProject.getConnection().openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                sessionExecute(session, Utils.monitorFor(monitor));
            }
        }, monitor);
    }

    /** called within IConsoleOperation, monitor is guaranteed to be non-null */
    protected abstract void sessionExecute(Session session, IProgressMonitor monitor) throws Exception;

}

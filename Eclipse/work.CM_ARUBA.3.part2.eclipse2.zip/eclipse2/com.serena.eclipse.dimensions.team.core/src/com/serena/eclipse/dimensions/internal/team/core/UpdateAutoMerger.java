/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.compare.rangedifferencer.IRangeComparator;
import org.eclipse.compare.rangedifferencer.RangeDifference;
import org.eclipse.compare.rangedifferencer.RangeDifferencer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.ExpandMode;

/**
 * @author S.Korniychuk
 */
public class UpdateAutoMerger {
    private IFile localFile;
    private ItemRevision baseRevision;
    private ItemRevision remoteRevision;

    public UpdateAutoMerger(IFile file, ItemRevision remoteRevision, ItemRevision baseRevision) throws CoreException {
        this.localFile = file;
        this.remoteRevision = remoteRevision;
        this.baseRevision = baseRevision;
    }

    private class LinesRangeComparator implements IRangeComparator {

        private String[] fLines;

        public LinesRangeComparator(InputStream is, String charsetName) throws IOException {
            List<String> result = new ArrayList<String>();
            DataInputStream in = new DataInputStream(is);
            BufferedReader br = new BufferedReader(new InputStreamReader(in, charsetName));
            String strLine;
            // Read Line By Line
            while ((strLine = br.readLine()) != null) {
                result.add(strLine);
            }
            // Close the input stream
            in.close();
            fLines = result.toArray(new String[result.size()]);
        }

        String getLine(int ix) {
            return fLines[ix];
        }

        @Override
        public int getRangeCount() {
            return fLines.length;
        }

        @Override
        public boolean rangesEqual(int thisIndex, IRangeComparator other, int otherIndex) {
            String s1 = fLines[thisIndex];
            String s2 = ((LinesRangeComparator) other).fLines[otherIndex];
            return s1.equals(s2);
        }

        @Override
        public boolean skipRangeComparison(int length, int maxLength, IRangeComparator other) {
            return false;
        }
    }

    public IStatus merge(DimensionsConnectionDetailsEx connection, IProgressMonitor monitor) {
        LinesRangeComparator base, local, remote;
        String charsetName;

        try {
            charsetName = localFile.getCharset();

            base = new LinesRangeComparator(TeamUtils.getContents(baseRevision, connection,
                    new ExpandMode[] { ExpandMode.UNEXPANDED }), charsetName); // don't expand substitute variables
            local = new LinesRangeComparator(localFile.getContents(), charsetName);
            remote = new LinesRangeComparator(TeamUtils.getContents(remoteRevision, connection,
                    new ExpandMode[] { ExpandMode.UNEXPANDED }), charsetName); // don't expand substitute variables
        } catch (DMException e) {
            return new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_DMException, e.getMessage()), e, localFile);
        } catch (CoreException e) {
            return new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_CoreException, e.getMessage()), e,
                    localFile);
        } catch (IOException e) {
            return new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_IOException, e.getMessage()), e, localFile);
        }

        File f_out = null;
        OutputStream output = null;
        try {
            String lineSeparator = System.getProperty("line.separator"); //$NON-NLS-1$
            if (lineSeparator == null) {
                lineSeparator = "\n"; //$NON-NLS-1$
            }

            RangeDifference[] diffs = RangeDifferencer.findRanges(monitor, base, local, remote);

            f_out = TeamUtils.createTempFile("auto_merge");
            output = new FileOutputStream(f_out);

            for (int i = 0; i < diffs.length; i++) {
                RangeDifference rd = diffs[i];
                switch (rd.kind()) {
                case RangeDifference.ANCESTOR: // pseudo conflict
                case RangeDifference.NOCHANGE:
                case RangeDifference.RIGHT:
                    for (int j = rd.rightStart(); j < rd.rightEnd(); j++) {
                        String s = remote.getLine(j);
                        output.write(s.getBytes(charsetName));
                        output.write(lineSeparator.getBytes(charsetName));
                    }
                    break;

                case RangeDifference.LEFT:
                    for (int j = rd.leftStart(); j < rd.leftEnd(); j++) {
                        String s = local.getLine(j);
                        output.write(s.getBytes(charsetName));
                        output.write(lineSeparator.getBytes(charsetName));
                    }
                    break;

                case RangeDifference.CONFLICT:
                    return new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_conflict, localFile.getName()),
                            null, localFile);

                default:
                    break;
                }
            }
            output.close();
            output = null;
            // no conflicts so file should be merged at this point
            // let's copy it to locaFile then
            if (localFile.exists()) {
                TeamUtils.setReadOnly(localFile, false);
            }
            // now let's replace the content
            localFile.setContents(new FileInputStream(f_out), true, true, monitor);
            // update metadata
            IDMProject dmProj = DMTeamPlugin.getWorkspace().getProject(localFile);
            IStatus st = dmProj.resolveConflicts(new ResolveConflictRequest[] { new ResolveConflictRequest(localFile,
                    remoteRevision) }, Utils.subMonitorFor(monitor, 100));
            // and refresh
            localFile.refreshLocal(IResource.DEPTH_ONE, Utils.subMonitorFor(monitor, 100));
            if (!st.isOK()) {
                return st;
            }
        } catch (UnsupportedEncodingException e) {
            return new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_outEncodingException, e.getMessage()), e,
                    localFile);
        } catch (CoreException e) {
            return new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_outCoreException, e.getMessage()), e,
                    localFile);
        } catch (IOException e) {
            return new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_outIOException, e.getMessage()), e,
                    localFile);
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                }
            }
            if (f_out != null) {
                f_out.delete();
            }

        }

        return Status.OK_STATUS;
    }

}

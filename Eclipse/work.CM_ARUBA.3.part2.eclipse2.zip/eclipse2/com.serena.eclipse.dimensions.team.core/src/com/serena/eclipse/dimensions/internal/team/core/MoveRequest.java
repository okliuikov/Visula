/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.BaseMetadata;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.IDMConsoleListener;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * @author V.Grishchenko
 */
class MoveRequest extends WorkspaceResourceRequest {
    private boolean unmanage;
    private IResource cachedMovedFrom;
    private List<String> srcRequests = Collections.emptyList(); // requests for removing from the source project when x-project

    /**
     * @param resource
     * @throws CoreException
     */
    public MoveRequest(IResource resource) throws CoreException {
        super(resource);
        cachedMovedFrom = DMTeamPlugin.getWorkspace().getMovedFrom(resource);
    }

    /**
     * Call this method to specify requests to be used for removal from the
     * source project, used during cross-project moves only.
     *
     * @param requests
     */
    public void setSourceRequests(List<String> requests) {
        this.srcRequests = requests;
    }

    /**
     * @return requests to be used for removal from the source project such as
     *         when moving from one project to another
     */
    public List<String> getSourceRequests() {
        return srcRequests;
    }

    @Override
    public int getKind() {
        int kind = MOVE;
        try {
            if (isCrossProject()) {
                if (getResource().exists()) {
                    kind |= getResource().getType() == IResource.FILE ? IMPORT : CREATE;
                } else {
                    kind |= DELETE;
                }
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
        return kind;
    }

    /**
     * @return <code>true</code> if this requests is for move source, returns
     *         false if this request is for move destination
     */
    public boolean isSource() {
        return !getResource().exists();
    }

    public IResource getSource() throws CoreException {
        if (!getResource().exists()) {
            return getResource();
        }
        IResource movedFrom = DMTeamPlugin.getWorkspace().getMovedFrom(getResource());
        if (movedFrom == null) {
            movedFrom = cachedMovedFrom;
        }
        return movedFrom;
    }

    public IResource getDestination() throws CoreException {
        if (getResource().exists()) {
            return getResource();
        }
        return DMTeamPlugin.getWorkspace().getMovedTo(getResource());
    }

    public IDMProject getSourceProject() throws CoreException {
        return DMTeamPlugin.getWorkspace().getProject(getSource());
    }

    public IDMProject getDestinationProject() throws CoreException {
        return DMTeamPlugin.getWorkspace().getProject(getDestination());
    }

    public boolean isCrossProject() throws CoreException {
        IDMProject srcProject = getSourceProject();
        IDMProject dstProject = getDestinationProject();
        if (srcProject == null) {
            return false; // there was local project renaming
        } else {
            return !dstProject.remoteEquals(srcProject, false);
        }
    }

    /*
     * handles only:
     * 1. same project folder moves
     * 2. same project file moves into existing folders
     * 3. cross project file moves into existing folders
     * Directory existence must be ensured prior to executing this request
     */
    @Override
    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
        if (isUnmanage()) {
            DMTeamPlugin.getWorkspace().unmanage(getResource(), monitor);
            return new DimensionsResult(Messages.ok);
        }
        monitor = Utils.monitorFor(monitor);

        String[] requestIds = null;
        if (!getChangeRequests().isEmpty()) {
            requestIds = getChangeRequests().toArray(new String[getChangeRequests().size()]);
        }

        IResource dst = getDestination();
        IResource src = getSource();
        assert src != null;
        IDMProject dstProject = DMTeamPlugin.getWorkspace().getProject(getResource());
        IDMProject srcProject = DMTeamPlugin.getWorkspace().getProject(src);
        assert dstProject != null;
        boolean crossProject = false;
        if (src.getType() != IResource.PROJECT || src.exists()) { // if not project renaming
            assert srcProject != null;
            crossProject = !srcProject.remoteEquals(dstProject, false);
        }

        Project dstDmProject = (Project) dstProject.getDimensionsObject();
        DimensionsResult result = null;
        if (crossProject) {
            // we rely on the current project to be set externally during export,
            // it is currently done in MoveCommand, current project is set to $G:$G
            // to avoid problems when moving inside project group
            assert src.getType() == IResource.FILE; // can only move files across projects
            IDMRemoteFile remoteFile = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getRemoteResource(src);
            List<ItemRevision> revisionsToExport = null;
            if (srcProject.isWorkset()) {
                Map<String, List<ItemRevision>> expanded = srcProject.expandItemRevisions(Collections.singletonList(remoteFile.getItemRevision()), null, null);
                revisionsToExport = expanded.get(remoteFile.getItemSpec());
            } else {
                revisionsToExport = Collections.singletonList(remoteFile.getItemRevision());
            }
            assert revisionsToExport != null && !revisionsToExport.isEmpty();
            IDMConsoleListener console = getConsole();
            monitor.beginTask(null, revisionsToExport.size() + 10);
            try {
                // DMPROD_EC_607: in theory should not remove until successfully exported but it is the
                // only way to support cross-project moves between project group member projects - hopefully
                // will get a proper move command at some point so this will become unnecessary
                if (srcProject.isWorkset()) { // cannot remove from baseline
                    Project srcDmProject = (Project) srcProject.getDimensionsObject();
                    console.printMessage(NLS.bind(Messages.MoveRequest_removeRevisions, srcProject.getId()));
                    String[] remvRequestIds = null;
                    if (getSourceRequests() != null && !getSourceRequests().isEmpty()) {
                        remvRequestIds = getSourceRequests().toArray(new String[getSourceRequests().size()]);
                    }
                    revisionsToExport.get(revisionsToExport.size() - 1).removeFromProject(srcDmProject, true,
                            remvRequestIds);
                }
                monitor.worked(5);

                for (Iterator<ItemRevision> iter = revisionsToExport.iterator(); iter.hasNext();) {
                    ItemRevision revision = iter.next();
                    String msg = NLS.bind(Messages.MoveRequest_exporting,
                            new String[] { (String) revision.getAttribute(SystemAttributes.OBJECT_SPEC),
                                    IDMConstants.GLOBAL_WORKSET /* srcProject.getId() */, dstProject.getId() });
                    monitor.subTask(msg);
                    console.printMessage(msg);
                    IPath newPath = dstProject.getRemotePathForLocalResource(dst);
                    // Note: AIWS uses current project, not the revision's project, to export from
                    DimensionsResult exportResult = revision.exportToProject(dstDmProject, TeamUtils.getItemFullPath(newPath),
                            requestIds);
                    monitor.worked(1);
                    console.printMessage(exportResult.getMessage());
                }
                resourceMoved(dst, true);
                monitor.worked(5);
            } finally {
                monitor.done();
            }
            result = new DimensionsResult(Messages.ok);
        } else {
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            try {
                if (getResource().getType() == IResource.FILE) {
                    IDMRemoteFile srcRmtFile = (IDMRemoteFile) getWorkspace().getRemoteResource(src);
                    assert srcRmtFile != null;
                    ItemRevision srcItemRev = srcRmtFile.getItemRevision();
                    IPath dstRmtPath = dstProject.getRemotePathForLocalResource(dst);
                    result = srcItemRev.setRepositoryPath(TeamUtils.getItemFullPath(dstRmtPath), requestIds);
                    resourceMoved(dst, true);
                } else if (getResource().getType() == IResource.FOLDER) {
                    IContainer dstFolder = (IContainer) getResource();
                    IPath rmtSrcPath = srcProject.getRemotePathForLocalResource(src);
                    RepositoryFolder rmtSrc = dstDmProject.findRepositoryFolderByPath(TeamUtils.getFolderFullPath(rmtSrcPath));
                    IPath newPath = dstProject.getRemotePathForLocalResource(dstFolder);
                    result = rmtSrc.setPath(TeamUtils.getFolderFullPath(newPath), requestIds);
                    treeMoved(dstFolder);
                } else {
                    // resource type = PROJECT
                    result = ProjectRenamer.doRename(dstProject, src, dst, getChangeRequests(), monitor);
                }
            } finally {
                monitor.done();
            }
        }
        return result;
    }

    void delete(File f) throws IOException {
        if (f.isDirectory()) {
            for (File c : f.listFiles()) {
                delete(c);
            }
        }
        if (!f.delete()) {
            throw new FileNotFoundException("Failed to delete file: " + f);//$NON-NLS-1$
        }
    }

    public void setUnmanage(boolean b) {
        this.unmanage = b;
    }

    public boolean isUnmanage() {
        return unmanage;
    }

    private void treeMoved(IContainer root) throws CoreException {
        IResource source = DMTeamPlugin.getWorkspace().getMovedFrom(root);
        if (source != null) {
            getWorkspace().releaseBase(source, false, IResource.DEPTH_INFINITE, null); // purge base info for the whole tree
        }
        root.accept(new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                discardMoveState(resource);
                return true;
            }
        });
    }

    private void resourceMoved(IResource resource, boolean releaseBase) throws CoreException {
        IResource source = getWorkspace().getMovedFrom(resource);
        if (source != null && releaseBase) {
            getWorkspace().releaseBase(source, false, IResource.DEPTH_ZERO, null);
        }
        if (discardMoveState(resource)) {
            IContainer parent = resource.getParent();
            if (parent.getType() != IResource.PROJECT) {
                resourceMoved(resource.getParent(), false);
            }
        }
    }

    static boolean discardMoveState(IResource resource) throws CoreException {
        if (resource.getType() == IResource.PROJECT) {
            return false;
        }
        BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
        if (metadata != null) {
            if (MoveDeleteHook.discardMovedState(metadata)) {
                WorkspaceMetadataManager.getInstance().updateMetadata(resource, metadata);
                return true;
            }
        }
        return false;
    }

    private DMWorkspace getWorkspace() {
        return (DMWorkspace) DMTeamPlugin.getWorkspace();
    }

    String getTempDirectory() {
        return System.getProperty("java.io.tmpdir"); //$NON-NLS-1$
    }

    IDMConsoleListener getConsole() {
        return DMPlugin.getDefault().getConsole();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class CreateFoldersCommand extends DMWorkspaceCommand1 {

    public CreateFoldersCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            List<DimensionsArObject> folders = dmProject.fetchMembers(dmProject.getRoot(), IResource.FOLDER,
                    new int[] { SystemAttributes.OBJECT_SPEC }, true, Utils.subMonitorFor(monitor, 200));
            folders.add(dmProject.getRemoteRoot());
            final HashMap<IPath, RepositoryFolder> folderByPath = new HashMap<IPath, RepositoryFolder>();
            for (Iterator<DimensionsArObject> iter = folders.iterator(); iter.hasNext();) {
                DimensionsArObject next = iter.next();
                if (next instanceof RepositoryFolder) {
                    RepositoryFolder aFolder = (RepositoryFolder) next;
                    IPath folderPath = TeamUtils.getFolderPath(aFolder);
                    folderByPath.put(folderPath, aFolder);
                }
            }

            // make sure folders are created from root down the tree
            TreeMap<IResource, FolderRequest> sortedRequests = new TreeMap<IResource, FolderRequest>(new ContainmentComparator()); // resource -> FolderRequest
            for (int i = 0; i < requests.length; i++) {
                FolderRequest request = (FolderRequest) requests[i];
                sortedRequests.put(request.getResource(), request);
            }

            // check for any missing parents that should be created as well
            for (int i = 0; i < requests.length; i++) {
                FolderRequest request = (FolderRequest) requests[i];
                IContainer parent = request.getResource().getParent();
                while (parent.getType() != IResource.PROJECT) {
                    IPath parentPath = dmProject.getRemotePathForLocalResource(parent);
                    if (!folderByPath.containsKey(parentPath) && !sortedRequests.containsKey(parent)) {
                        sortedRequests.put(parent, new FolderRequest(parent));
                    }
                    parent = parent.getParent();
                }
            }

            IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 800);
            subMonitor.beginTask(null, sortedRequests.size());
            for (Iterator<FolderRequest> iter = sortedRequests.values().iterator(); iter.hasNext();) {
                final FolderRequest request = iter.next();
                final IResource localFolder = request.getResource();
                IContainer localParent = localFolder.getParent();
                IPath remoteParentPath = dmProject.getRemotePathForLocalResource(localParent);
                final RepositoryFolder remoteParent = folderByPath.get(remoteParentPath);
                assert remoteParent != null;
                String msg = NLS.bind(Messages.CreateFoldersCommand_create, localFolder.getProjectRelativePath().toString());
                subMonitor.subTask(msg);
                final RepositoryFolder[] createdFolder = new RepositoryFolder[1];
                dmProject.getConnection().openSession(null).run(new APIOperation(msg) {
                    @Override
                    public DimensionsResult doRun() throws Exception {
                        List<String> reqList = request.getChangeRequests();
                        String[] reqIds = reqList == null || reqList.isEmpty()
                                ? null : (String[]) reqList.toArray(new String[reqList.size()]);
                        createdFolder[0] = remoteParent.addChildFolder(localFolder.getName(), reqIds);
                        return new DimensionsResult(Messages.ok);
                    }
                }, subMonitor);
                TeamUtils.ensureReacheable((IContainer) localFolder, !hasAtLeastOneFile(localFolder.getLocation().toFile()));
                folderByPath.put(TeamUtils.getFolderPath(createdFolder[0]), createdFolder[0]);
                subMonitor.worked(1);
            }
            subMonitor.done();
        } finally {
            monitor.done();
        }
    }

    // Checks whether there is at least one file in this folder or its
    // subfolders.
    private boolean hasAtLeastOneFile(File dir) {
        File folderContents[];
        if (dir.isDirectory()) {
            folderContents = dir.listFiles();
            if (folderContents.length == 0) {
                return false;// folder is empty
            } else {
                // Iterate through the contents of the directory
                for (int i = 0; i < folderContents.length; i++) {
                    if (folderContents[i].isDirectory()) {
                        hasAtLeastOneFile(folderContents[i]);
                    } else {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

}

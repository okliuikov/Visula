/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.ResourceVariantByteStore;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * <P>
 * This store is intended to be used for caching metadata information for all resources in the workspace and persisting it in a
 * single file for efficient loading.
 *
 * <P>
 * Metadata changes are processed in a POST_CHANGE resources listener and then cached, cannot use ISynchronizer-based persistent
 * store provided by Eclispe as resource tree is locked for modifications during POST_CHANGE events - changing sync bytes is
 * considered to be a resource tree modification.
 *
 * <P>
 * If this store is created with an optional delete flag storage all requests to delete resource bytes will be ignored until bytes
 * are explicitly marked for deletion via a call to <code>prepareForDeletion</code>.
 *
 * <P>
 * This class is thread-safe.
 *
 * @author V.Grishchenko
 */
// TODO VG on Apr 17, 2006: handle incremental snapshots!
class PersistentByteStore extends ResourceVariantByteStore {
    private static final int BYTES_VERSION = 1;
    private static final int DELETES_VERSION = 1;

    private File byteStorage;
    private File deleteFlagStorage;

    private Map<IPath, byte[]> byteCache = new HashMap<IPath, byte[]>();
    private Map<IPath, Set<IPath>> memberCache = new HashMap<IPath, Set<IPath>>();
    private Map<IPath, Boolean> deleteFlagCache;// = new HashMap();

    private boolean initialized = false;

    private static boolean debug = DMTeamPlugin.getDefault().isDebuggingByteStore();

    PersistentByteStore(File byteStorage) {
        this(byteStorage, null);
    }

    PersistentByteStore(File byteStorage, File deleteFlagStorage) {
        Assert.isNotNull(byteStorage);
        this.byteStorage = byteStorage;
        this.deleteFlagStorage = deleteFlagStorage;
        if (deleteFlagStorage != null) {
            deleteFlagCache = new HashMap<IPath, Boolean>();
        }
    }

    private static void ensureIsNotAFolder(File file) throws IOException {
        if (file.isDirectory()) {
            throw new IOException(file.getAbsolutePath() + " is a directory!"); //$NON-NLS-1$
        }
    }

    @Override
    public synchronized void dispose() {
        byteCache.clear();
        memberCache.clear();
        if (deleteFlagCache != null) {
            deleteFlagCache.clear();
        }

        byteStorage.delete();
        if (deleteFlagStorage != null) {
            deleteFlagStorage.delete();
        }
    }

    @Override
    public synchronized byte[] getBytes(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        return internalGetBytes(resource.getFullPath());
    }

    @Override
    public synchronized boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        return internalSetBytes(resource.getFullPath(), bytes);
    }

    /**
     * Releases the bytes for the specified resource so that they can be deleted from
     * this store when delete or flush called
     */
    public synchronized void prepareForDeletion(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        internalPrepareForDeletion(resource.getFullPath());
    }

    /**
     * @param force unconditionally removes the bytes from this store if <code>true</code>
     */
    public boolean flushBytes(IResource resource, int depth, boolean force) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        if (debug) {
            System.out.println("PBS flush bytes" + resource.toString());
        }
        boolean result = false;
        IPath path = resource.getFullPath();
        if (force || deleteFlagCache == null || deleteFlagCache.containsKey(path)) {
            if (byteCache.containsKey(path)) {
                if (debug) {
                    System.out.println("PBS bc has key and del cache or force");
                }
                if (IResource.DEPTH_ZERO != depth) {
                    IResource[] members = members(resource);
                    for (int i = 0; i < members.length; i++) {
                        IResource child = members[i];
                        flushBytes(child, (depth == IResource.DEPTH_INFINITE) ? IResource.DEPTH_INFINITE : IResource.DEPTH_ZERO,
                                force);
                    }
                }
                byteCache.remove(path);
                internalRemoveFromParent(path);
                result = true;
            }
            if (deleteFlagCache != null) { // remove delete flag too
                deleteFlagCache.remove(path);
            }
        }
        return result;
    }

    @Override
    public synchronized boolean flushBytes(IResource resource, int depth) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        return flushBytes(resource, depth, false);
    }

    @Override
    public boolean deleteBytes(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        return flushBytes(resource, IResource.DEPTH_ZERO);
    }

    public boolean deleteBytes(IResource resource, boolean force) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        return flushBytes(resource, IResource.DEPTH_ZERO, force);
    }

    @Override
    public synchronized IResource[] members(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (!initialized) {
            initialize();
        }
        if (debug) {
            System.out.println("PBS members " + resource.toString());
        }
        Collection<IPath> members = memberCache.get(resource.getFullPath());
        if (members == null) {
            return new IResource[0];
        }
        ArrayList<IResource> result = new ArrayList<IResource>(members.size());
        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        for (Iterator<IPath> iter = members.iterator(); iter.hasNext();) {
            // try to use the workspace to resolve path to resource type,
            // if that fails rely on the remote resource type stored in bytes
            IPath memberPath = iter.next();
            IResource member = root.findMember(memberPath, true);
            if (member == null) {
                byte[] bytes = internalGetBytes(memberPath);
                if (bytes != null) {
                    if (DMRemoteResource.getResourceType(bytes) == IResource.FILE) {
                        member = root.getFile(memberPath);
                    } else {
                        member = root.getFolder(memberPath);
                    }
                }
            }
            if (member != null) {
                result.add(member);
            }
        }
        return result.toArray(new IResource[result.size()]);
    }

    synchronized void save() throws CoreException {
        if (debug) {
            System.out.println("PBS save");
        }
        DataOutputStream bytesOut = null;
        try {
            bytesOut = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(byteStorage), 10 * 1024));
            bytesOut.writeInt(BYTES_VERSION);
            bytesOut.writeInt(byteCache.size()); // store cache size
            for (Iterator<Entry<IPath, byte[]>> iter = byteCache.entrySet().iterator(); iter.hasNext();) {
                Entry<IPath, byte[]> entry = iter.next();
                IPath path = entry.getKey();
                byte[] bytes = entry.getValue();

                bytesOut.writeUTF(path.toString()); // store path
                bytesOut.writeInt(bytes.length); // store byte cnt
                bytesOut.write(bytes); // store bytes
            }

        } catch (IOException e) {
            throw new CoreException(DMTeamStatus.createErrorStatus(0, "Failed to persist metadata cache to disk", e)); //$NON-NLS-1$
        } finally {
            if (bytesOut != null) {
                try {
                    bytesOut.flush();
                    bytesOut.close();
                } catch (IOException ignore) {
                }
            }
        }

        if (deleteFlagStorage != null) {
            DataOutputStream deletesOut = null;
            try {
                deletesOut = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(deleteFlagStorage), 10 * 1024));
                deletesOut.writeInt(DELETES_VERSION);
                deletesOut.writeInt(deleteFlagCache.size());
                for (Iterator<IPath> iter = deleteFlagCache.keySet().iterator(); iter.hasNext();) {
                    IPath path = iter.next();
                    deletesOut.writeUTF(path.toString());
                }
            } catch (IOException e) {
                throw new CoreException(DMTeamStatus.createErrorStatus(0, "Failed to persist delete markers to disk", e)); //$NON-NLS-1$
            } finally {
                if (deletesOut != null) {
                    try {
                        deletesOut.flush();
                        deletesOut.close();
                    } catch (IOException ignore) {
                    }
                }
            }
        }
    }

    // -------------
    private void initialize() throws TeamException {
        try {
            // 1. read persistent bytes in
            ensureIsNotAFolder(byteStorage);
            if (byteStorage.exists()) {
                if (debug) {
                    System.out.println("PBS init read bs");
                }
                DataInputStream bytesIn = null;
                try {
                    int bufSize = TeamUtils.getReadBufferSize(byteStorage.length());
                    bytesIn = new DataInputStream(new BufferedInputStream(new FileInputStream(byteStorage), bufSize));
                    bytesIn.readInt();
                    int entryCnt = bytesIn.readInt();
                    int entriesRead = 0;
                    while (entriesRead < entryCnt) {
                        String path = bytesIn.readUTF();
                        int byteCnt = bytesIn.readInt();
                        byte[] bytes = new byte[byteCnt];
                        bytesIn.readFully(bytes);
                        internalSetBytes(new Path(path), bytes);
                        entriesRead++;
                    }

                } finally {
                    if (bytesIn != null) {
                        try {
                            bytesIn.close();
                        } catch (IOException ignore) {
                        }
                    }
                }
            }

            // 2. read delete flags in
            if (deleteFlagStorage != null) {
                ensureIsNotAFolder(deleteFlagStorage);
                DataInputStream deletesIn = null;
                if (deleteFlagStorage.exists()) {
                    if (debug) {
                        System.out.println("PBS init read dfs");
                    }
                    try {
                        int bufSize = TeamUtils.getReadBufferSize(deleteFlagStorage.length());
                        deletesIn = new DataInputStream(new BufferedInputStream(new FileInputStream(deleteFlagStorage), bufSize));
                        deletesIn.readInt();
                        int deleteCnt = deletesIn.readInt();
                        int entriesRead = 0;
                        while (entriesRead < deleteCnt) {
                            String path = deletesIn.readUTF();
                            internalPrepareForDeletion(new Path(path));
                            entriesRead++;
                        }
                    } finally {
                        if (deletesIn != null) {
                            try {
                                deletesIn.close();
                            } catch (IOException ignore) {
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new TeamException(DMTeamStatus.createErrorStatus(0, "Failed to restore metadata cache", e));
        }
        initialized = true;
    }

    private byte[] internalGetBytes(IPath resourcePath) {
        return byteCache.get(resourcePath);
    }

    private boolean internalSetBytes(IPath resourcePath, byte[] bytes) {
        Assert.isNotNull(bytes);
        byte[] oldBytes = internalGetBytes(resourcePath);
        if (oldBytes != null && equals(oldBytes, bytes)) {
            return false;
        }
        internalAddToParent(resourcePath);
        byteCache.put(resourcePath, bytes);
        return true;
    }

    private void internalAddToParent(IPath resourcePath) {
        // IContainer parent = resource.getParent();
        if (resourcePath.segmentCount() < 2) {
            return;
        }
        IPath parentPath = resourcePath.removeLastSegments(1);
        Set<IPath> members = memberCache.get(parentPath);
        if (members == null) {
            members = new HashSet<IPath>();
            memberCache.put(parentPath, members);
        }
        members.add(resourcePath);
    }

    private void internalRemoveFromParent(IPath resourcePath) {
        if (resourcePath.segmentCount() < 2) {
            return;
        }
        IPath parentPath = resourcePath.removeLastSegments(1);
        Set<IPath> members = memberCache.get(parentPath);
        if (members == null) {
            return;
        }
        members.remove(resourcePath);
        if (members.isEmpty()) {
            memberCache.remove(parentPath);
        }
    }

    private void internalPrepareForDeletion(IPath resourcePath) {
        if (deleteFlagCache != null) {
            if (debug) {
                System.out.println("PBS prepare " + resourcePath.toString());
            }
            deleteFlagCache.put(resourcePath, Boolean.TRUE);
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

/**
 * Local managed folder state.
 *
 * @author V.Grishchenko
 * @deprecated to be deleted it is not curerntly used
 */
@Deprecated
public interface IDMBaseFolder extends IDMRemoteFolder {

    /**
     * @return <code>true</code> if this folder contains modified files,
     *         returns <code>false</code> otherwise
     */
    boolean isModified(boolean deep);

    /**
     * @return <code>true</code> if this folder contains managed files,
     *         returns <code>false</code> otherwise
     */
    boolean isManaged(boolean deep);

    /**
     * @return <code>true</code> if this folder contains unmanaged files,
     *         returns <code>false</code> otherwise
     */
    boolean isUnmanaged(boolean deep);

    /**
     * @return <code>true</code> if this folder contains read-only files,
     *         returns <code>false</code> otherwise
     */
    boolean isReadOnly(boolean deep);

    /**
     * @return <code>true</code> if this folder contains writable files,
     *         returns <code>false</code> otherwise
     */
    boolean isWriteable(boolean deep);

    /**
     * @return <code>true</code> if this folder contains extracted files,
     *         returns <code>false</code> otherwise
     */
    boolean isExtracted(boolean deep);

    /**
     * @return <code>true</code> if this folder contains non-extracted managed
     *         files, returns <code>false</code> otherwise
     */
    boolean isNotExtracted(boolean deep);

}

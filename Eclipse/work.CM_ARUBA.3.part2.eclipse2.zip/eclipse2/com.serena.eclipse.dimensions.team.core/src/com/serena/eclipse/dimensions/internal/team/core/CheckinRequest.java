/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Collections;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Request to checkin a file extracted to local workspace.
 * @author V.Grishchenko
 */
public class CheckinRequest extends ItemRevisionRequest implements IUploadRequestParameters {
    private String comment;
    private boolean forceUpdate = true;
    private int[] attrs;
    private boolean readOnly = true;

    private boolean moved;
    private boolean movedCrossProject;

    /**
     * @param file
     * @param revision
     * @throws CoreException
     */
    public CheckinRequest(IFile file, ItemType itemType, ItemRevision revision, boolean requestSupported, boolean requestRequired)
            throws CoreException {
        super(file, itemType, revision, requestSupported, requestRequired);
    }

    public void setMoved(boolean b) {
        this.moved = b;
    }

    public void setMovedCrossProject(boolean b) {
        this.movedCrossProject = b;
    }

    @Override
    public int getKind() {
        int kind = MODIFY;
        if (moved) {
            kind |= MOVE;
            if (movedCrossProject) {
                kind |= IMPORT;
            }
        }
        return kind;
    }

    /**
     * @return Returns the comment.
     * @see com.serena.eclipse.dimensions.internal.team.core.IUploadRequestParameters#getComment()
     */
    @Override
    public String getComment() {
        return comment;
    }

    @Override
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return Returns the forceUpdate.
     */
    public boolean isForceUpdate() {
        return forceUpdate;
    }

    /**
     * @param forceUpdate The forceUpdate to set.
     */
    public void setForceUpdate(boolean forceUpdate) {
        this.forceUpdate = forceUpdate;
    }

    @Override
    public int[] getAttributes() {
        return attrs == null ? new int[0] : attrs;
    }

    @Override
    public void setAttributes(int[] attrs) {
        this.attrs = attrs;
    }

    @Override
    public void setReadOnly(boolean b) {
        this.readOnly = b;
    }

    @Override
    public boolean isReadOnly() {
        return readOnly;
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        return checkin();
    }

    DimensionsResult checkin() {
        ItemRevision revision = getItemRevision();
        IFile file = getFile();
        String source = file.getLocation().toOSString();
        DimensionsResult result = revision.checkIn(source, comment == null ? Utils.EMPTY_STRING : comment, true, forceUpdate, null,
                attrs, DMTeamPlugin.getDefault().getCharset(file));
        TeamUtils.setReadOnly(file, readOnly);
        return result;
    }

    @Override
    public Object getAttribute(int attrNum) {
        return getItemRevision().getAttribute(attrNum);
    }

    @Override
    public String getPart() {
        return null; // part is not needed on checkin
    }

    @Override
    public List getRelatedRequests() {
        return Collections.EMPTY_LIST; // no request relate on checkin
    }

    @Override
    public String getDescription() {
        return null;
    }

    @Override
    public String getCharset() {
        return DMTeamPlugin.getDefault().getCharset(getFile());
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmfile.progress.StateProgressListener;
import com.serena.eclipse.dimensions.core.util.Utils;

public class StateTransferMonitor extends TransferMonitor implements StateProgressListener {

    private IProgressMonitor stateProgress;
    private int stateStep = total / 10;
    private boolean caching = false;

    public StateTransferMonitor(IProgressMonitor monitor, int direction) {
        this(null, monitor, direction);
    }

    public StateTransferMonitor(String task, IProgressMonitor monitor, int direction) {
        super(task, monitor, direction);
    }

    @Override
    public void startFile(String filename) {
        startFileTransfer();

        String msg = "";
        if (direction == UP) {
            msg = NLS.bind(Messages.TransferMonitor_3, filename);
        } else if (direction == DOWN) {
            if (caching) {
                msg = NLS.bind(Messages.TransferMonitor_4, filename);
            } else {
                msg = NLS.bind(Messages.TransferMonitor_5, filename);

            }
        }

        fileProgress.subTask(msg);
    }

    @Override
    public void startStateUnit(int id) {
        if (StateProgressListener.STATE_WORKAREA_SCAN_ITEM == id) {
            if (stateProgress != null) {
                worked += stateStep;
                stateProgress.worked(stateStep);
                stateProgress.done();
            }
            this.stateProgress = Utils.subMonitorFor(mainProgress, stateStep);
            stateProgress.beginTask(task, stateStep);
            stateProgress.subTask(Messages.StateTransferMonitor_1);
        } else if (StateProgressListener.STATE_REPOSITORY_SCAN_ITEM == id) {
            if (stateProgress != null) {
                worked += stateStep;
                stateProgress.worked(stateStep);
                stateProgress.done();
            }
            this.stateProgress = Utils.subMonitorFor(mainProgress, stateStep);
            stateProgress.beginTask(task, stateStep);
            stateProgress.subTask(Messages.StateTransferMonitor_2);
        } else if (StateProgressListener.STATE_RESOLUTION_DETECTION_ITEM == id) {
            if (stateProgress != null) {
                worked += stateStep;
                stateProgress.worked(stateStep);
                stateProgress.done();
            }
            this.stateProgress = Utils.subMonitorFor(mainProgress, stateStep);
            stateProgress.beginTask(task, stateStep);
            stateProgress.subTask(Messages.StateTransferMonitor_3);
        } else if (StateProgressListener.STATE_AUTO_MERGE_ITEM == id) {
            if (stateProgress != null) {
                worked += stateStep;
                stateProgress.worked(stateStep);
                stateProgress.done();
            }
            this.stateProgress = Utils.subMonitorFor(mainProgress, stateStep);
            stateProgress.beginTask(task, stateStep);
            stateProgress.subTask(Messages.StateTransferMonitor_4);
        } else if (StateProgressListener.STATE_PLCD_ITEMS_CACHING == id) {
            this.caching = true;
        }
    }

    @Override
    public void endStateUnit(int id, int status) {
        if (STATE_PLCD_ITEMS_CACHING == id) {
            this.caching = false;
        }
    }

    @Override
    public void startStateProgress(long totalStatusUnits) {
        if (!mainProgressStarted) {
            mainProgress.beginTask(task, total);
            mainProgressStarted = true;
        }
    }

    @Override
    public void endStateProgress() {
        if (stateProgress != null) {
            stateProgress.worked(stateStep);
            worked += stateStep;
            stateProgress.done();
        }
    }

}

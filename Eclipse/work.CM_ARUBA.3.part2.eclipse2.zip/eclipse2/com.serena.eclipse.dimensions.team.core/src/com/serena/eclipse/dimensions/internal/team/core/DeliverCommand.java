/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.sbm.ActionDetails;
import com.serena.eclipse.dimensions.core.sbm.AssociateInput;
import com.serena.eclipse.dimensions.core.sbm.ISBMConnection;
import com.serena.eclipse.dimensions.core.sbm.ISBMManager;
import com.serena.eclipse.dimensions.core.sbm.SBMException;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Deliver one project command
 * @author V.Grishchenko
 */
class DeliverCommand extends DMWorkspaceCommand1 implements DeliverResults {
    private static boolean debug = DMTeamPlugin.getDefault().isDebugging();

    private boolean refreshNeeded; // post command remote tree refresh needed
    private DeliverHelper deliverHelper = new DeliverHelper(this);

    // inputs
    private TransferToStreamOperationData operationData;
    private List<WorkspaceResourceRequest> deliverList = new ArrayList<WorkspaceResourceRequest>();

    // results
    private Map<String, ObjectToTransfer> statusMap = new HashMap<String, ObjectToTransfer>();

    // sbm integration
    private ISBMConnection sbmc = null;
    private Map<IResource, ActionDetails> actionDetails = null;
    private List<DeliverBucket> buckets;

    public DeliverCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        super(dmProject, requests);
    }

    public DeliverCommand(DMProject dmProject, WorkspaceResourceRequest[] requests,
            TransferToStreamOperationData operationData) {
        super(dmProject, requests);
        this.operationData = operationData;
    }

    @Override
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        DeliverHelper.addDeliverSchedulingRule(rules, request);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, ((requests.length) * 100) + 15 + 5 + 10 /* 10 reserved */);
        try {
            beforeDeliver();
            deliver(Utils.subMonitorFor(monitor, (requests.length) * 100));
            afterDeliver(Utils.subMonitorFor(monitor, 20));
        } finally {
            monitor.done();
        }
    }

    private void beforeDeliver() {
        this.deliverList = new ArrayList<WorkspaceResourceRequest>();
        this.sbmc = dmProject.getConnection().getSBMConnection();
        if (sbmc != null) {
            this.actionDetails = new HashMap<IResource, ActionDetails>(); // resource -> action details
        }

        for (int i = 0; i < requests.length; i++) {
            deliverList.add(requests[i]);
        }

        refreshNeeded = !deliverList.isEmpty(); // refresh only if not already refreshed all because of merge/fetch
        this.buckets = bucketize(deliverList);
    }

    private void deliver(IProgressMonitor monitor) throws CoreException {
        IPath parentToCheck = dmProject.getProject().getLocation().removeLastSegments(1);
        MetadataProvider mdHolder = MetadataProviderFactory.providerFor(parentToCheck);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, ((requests.length) * 100));
        try {
            boolean isSharing = false;

            if (dmProject.isFullWorkArea() && !new File(parentToCheck.toFile(), mdHolder.metadataDirname()).exists()) {
                isSharing = true; // to check we need to be under FWA on the first command run
            }

            this.statusMap = run(buckets, monitor, isSharing, 100);

            // post-processing
            if (isSharing) {
                // first command run - hide metadata folders on the disk
                MetadataHelper.hideMetadataHierarchy(dmProject.getProject().getLocation(), dmProject.getWorkAreaPath(),
                        mdHolder);
            }
        } finally {
            if (mdHolder != null) {
                mdHolder.close();
            }
            monitor.done();
        }
    }

    private Map<String, ObjectToTransfer> run(List<DeliverBucket> buckets, IProgressMonitor monitor, boolean isSharing,
            int unitsPerFile) throws CoreException {
        // put results in a map for faster lookup
        Map<String, ObjectToTransfer> statusMap = new HashMap<String, ObjectToTransfer>();

        if (debug && !buckets.isEmpty()) {
            System.out.println("+ Uploading over " + buckets.size() + " buckets"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        for (Iterator<DeliverBucket> bIter = buckets.iterator(); bIter.hasNext();) {
            DeliverBucket aBucket = bIter.next();
            if (debug) {
                System.out.println(aBucket);
            }

            DimensionsResult dr = aBucket.deliver((WorksetProject) dmProject, isSharing,
                    Utils.subMonitorFor(monitor, aBucket.size() * unitsPerFile));

            List<?> details = dr.getResultList();
            for (Iterator<?> dIter = details.iterator(); dIter.hasNext();) {
                ObjectToTransfer fileDetails = (ObjectToTransfer) dIter.next();
                statusMap.put(fileDetails.getFileName(), fileDetails);

                addError(fileDetails);
            }
        }
        if (debug && !buckets.isEmpty()) {
            System.out.println("- done"); //$NON-NLS-1$
        }

        return statusMap;
    }

    private void afterDeliver(IProgressMonitor monitor) throws CoreException, SBMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, ((requests.length) * 20));
        try {
            // refresh local for the files just uploaded
            List<IResource> toClean = refresh(Utils.subMonitorFor(monitor, 15));
            cleanTimestamps(toClean, Utils.subMonitorFor(monitor, 5));

            // associate in SBM, if necessary
            if (sbmc != null && actionDetails != null && !actionDetails.isEmpty()) {
                ActionDetails[] actions = actionDetails.values().toArray(new ActionDetails[actionDetails.size()]);
                AssociateInput ai = new AssociateInput(actions, null);
                ISBMManager sbmManager = sbmc.getSBMManager();
                sbmManager.associate(ai, null);
            }
        } finally {
            monitor.done();
        }
    }

    private List<IResource> refresh(IProgressMonitor monitor) throws CoreException {
        List<IResource> toClean = new ArrayList<IResource>();
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, deliverList.size() * 10);
        try {
            deliverHelper.afterDeliver(deliverList, toClean, monitor);
            return toClean;
        } finally {
            monitor.done();
        }
    }

    private void cleanTimestamps(List<IResource> toClean, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 5);
        try {
            if (!toClean.isEmpty()) {
                IResource[] resources = toClean.toArray(new IResource[toClean.size()]);
                DMTeamPlugin.getWorkspace().cleanTimestamps(resources, IResource.DEPTH_ZERO,
                        Utils.subMonitorFor(monitor, 5));
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    public boolean modifiesRemote() {
        return refreshNeeded;
    }

    @Override
    protected String getErrorMessage(IStatus[] errors) {
        int coErrCnt = 0;
        for (int i = 0; i < errors.length; i++) {
            if (errors[i].getCode() == DMTeamStatus.CHECKOUT_FAILED) {
                coErrCnt++;
            }
        }
        if (coErrCnt == 0) {
            return Messages.UploadCommand_0;
        }
        if (coErrCnt == errors.length) {
            return Messages.UploadCommand_1;
        }
        return Messages.UploadCommand_2;
    }

    @Override
    public Map<String, ObjectToTransfer> getStatusMap() {
        return statusMap;
    }

    @Override
    public Map<IResource, ActionDetails> getActionDetails() {
        return actionDetails;
    }

    private List<DeliverBucket> bucketize(List<WorkspaceResourceRequest> deliverList) {
        List<DeliverBucket> buckets = new ArrayList<DeliverBucket>();
        for (Iterator<WorkspaceResourceRequest> uIter = deliverList.iterator(); uIter.hasNext();) {
            WorkspaceResourceRequest request = uIter.next();
            boolean added = false;
            for (Iterator<DeliverBucket> bIter = buckets.iterator(); bIter.hasNext() && !added;) {
                DeliverBucket aBucket = bIter.next();
                added = aBucket.add(request);
            }
            if (!added) {
                DeliverBucket deliverBucket = new DeliverBucket(request);
                deliverBucket.setDeliverData(operationData);
                buckets.add(deliverBucket);
            }
        }
        return buckets;
    }

}

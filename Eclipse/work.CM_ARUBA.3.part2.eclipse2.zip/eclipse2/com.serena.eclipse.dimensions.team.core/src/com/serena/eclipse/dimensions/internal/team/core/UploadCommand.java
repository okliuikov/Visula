/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.team.core.TeamException;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.FileToTransfer;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.sbm.ActionDetails;
import com.serena.eclipse.dimensions.core.sbm.AssociateInput;
import com.serena.eclipse.dimensions.core.sbm.ISBMConnection;
import com.serena.eclipse.dimensions.core.sbm.ISBMManager;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * @author V.Grishchenko
 */
class UploadCommand extends DMWorkspaceCommand1 { 
    private boolean refreshNeeded; // post command remote tree refresh needed

    public UploadCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        try {
            if (request instanceof MoveItemRequest) {
                MoveItemRequest moveRequest = (MoveItemRequest) request;
                rules.add(TeamUtils.parent(moveRequest.getSource()));
                rules.add(TeamUtils.parent(moveRequest.getDestination()));
            } else if (request instanceof MoveFolderRequest) {
                MoveFolderRequest moveRequest = (MoveFolderRequest) request;
                rules.add(TeamUtils.parent(moveRequest.getSource()));
                rules.add(TeamUtils.parent(moveRequest.getDestination()));
            } else {
                IResource resource = request.getResource();
                IResource parent = TeamUtils.parent(resource);
                rules.add(TeamUtils.findDeepestManagedResource(parent));
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        ArrayList<WorkspaceResourceRequest> merges = new ArrayList<WorkspaceResourceRequest>();
        ArrayList<WorkspaceResourceRequest> uploads = new ArrayList<WorkspaceResourceRequest>();
        ISBMConnection sbmc = dmProject.getConnection().getSBMConnection();
        Map<IResource, ActionDetails> actionDetails = null;
        if (sbmc != null) {
            actionDetails = new HashMap<IResource, ActionDetails>(); // resource -> action details
        }

        int requestedCheckoutCnt = 0;
        for (int i = 0; i < requests.length; i++) {
            WorkspaceResourceRequest request = requests[i];
            if (request instanceof UploadRequest) {
                UploadRequest uploadRequest = (UploadRequest) request;
                if (uploadRequest.getParameters() instanceof UpdateRevisionRequest
                        && ((UpdateRevisionRequest) uploadRequest.getParameters()).isMerge()) {
                    merges.add(request);
                } else {
                    // here FORCE_TIP indicates we are in "override" mode
                    if (uploadRequest.getMode() == UploadRequest.FORCE_TIP) {
                        if (getWorkspace().isManaged(request.getResource())) { // got md?
                            if (getWorkspace().hasRemote(request.getResource())) {
                                IDMWorkspaceFile dmFile = (IDMWorkspaceFile) getWorkspace()
                                        .getWorkspaceResource(request.getResource());
                                dmFile.setCacheVariants(true);
                                if (!dmFile.isModified()) {
                                    // DEF127600 - fool upload to believe there was a local change
                                    ItemMetadata itemMetadata = (ItemMetadata) WorkspaceMetadataManager.getInstance()
                                            .getMetadata(dmFile.getLocalResource());
                                    itemMetadata.setFetchSize(0L);
                                    WorkspaceMetadataManager.getInstance().updateMetadata(dmFile.getLocalResource(), itemMetadata);
                                }
                            } else {
                                // DEF127491 - pretend it is a new file
                                getWorkspace().unmanage(request.getResource(), null);
                            }
                        }
                    }

                    uploads.add(request);
                    if (actionDetails != null) {
                        ActionDetails aDetails = createActionDetails(uploadRequest);
                        if (aDetails != null) {
                            actionDetails.put(request.getResource(), aDetails);
                        }
                    }
                }
                if (uploadRequest.isCheckout()) {
                    requestedCheckoutCnt++;
                }
            } else {
                uploads.add(request);
            }
        }

        refreshNeeded = !uploads.isEmpty(); // refresh only if not already refreshed all because of merge/fetch

        List<UploadBucket> buckets = bucketize(uploads);

        // progress breakdown
        // 100 units for each:
        // 1. upload/merge
        // 2. refresh after merge
        // 3. fetch after merge
        // 4. requested checkout
        // 5. UEI
        // also reserve 10 units for open session, refresh local, and clean timestamps
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, ((requests.length + 2 * merges.size() + requestedCheckoutCnt) * 100) + 10 + 10 + 10);

        try {
            HashMap<String, FileToTransfer> statusMap = null;

            IPath parentToCheck = dmProject.getProject().getLocation().removeLastSegments(1);
            MetadataProvider mdHolder = MetadataProviderFactory.providerFor(parentToCheck);
            try {
                boolean isSharing = false;
                if (!dmProject.isFullWorkArea() || new File(parentToCheck.toFile(), mdHolder.metadataDirname()).exists()) {
                    parentToCheck = null; // to check we need to be under FWA on the first command run
                    isSharing = true;
                }

                statusMap = runUpload(buckets, monitor, isSharing, 100);

                // post-processing
                if (parentToCheck != null) { // first command run - hide metadata folders on the disk
                    MetadataHelper.hideMetadataHierarchy(parentToCheck, dmProject.getWorkAreaPath(), mdHolder);
                }
            } finally {
                if (mdHolder != null) {
                    mdHolder.close();
                }
            }

            ArrayList<UploadRequest> checkouts = new ArrayList<UploadRequest>(); // successful uploads to be checked out
            ArrayList<IFile> toClean = new ArrayList<IFile>(); // files for which to clean timestamps

            // refresh local for the files just uploaded
            IProgressMonitor refreshMonitor = Utils.subMonitorFor(monitor, 10);
            DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
            refreshMonitor.beginTask(null, uploads.size() * 10);
            for (Iterator<WorkspaceResourceRequest> uIter = uploads.iterator(); uIter.hasNext();) {
                WorkspaceResourceRequest resourceRequest = uIter.next();
                if (resourceRequest instanceof UploadRequest) {
                    UploadRequest request = (UploadRequest) resourceRequest;
                    IFile file = request.getFile();
                    FileToTransfer status = statusMap != null
                            ? (FileToTransfer) statusMap.get(file.getLocation().toOSString()) : null; // paranoid check
                    if (status != null && status.getCmdStatus() && ObjectToTransfer.STATUS_RESOLVED.equals(status.getStatus())) {
                        if (request.isCheckout()) {
                            checkouts.add(request);
                        }
                        IContainer parent = file.getParent();
                        if (parent.getType() != IResource.PROJECT) {
                            TeamUtils.ensureReacheable(parent, false); // upload was successful ensure have md up the hierarchy
                        }
                        if (request.isUndoCheckout() && ObjectToTransfer.UNCHANGED == status.getDiffType()
                                && isCIU(status.getCommands())) {
                            toClean.add(file);
                        }
                        TeamUtils.setReadOnly(file, request.getParameters().isReadOnly());
                    } else {
                        if (actionDetails != null) {
                            actionDetails.remove(file); // exclude failures from associations
                        }
                    }
                    file.refreshLocal(IResource.DEPTH_INFINITE, Utils.subMonitorFor(refreshMonitor, 5));
                    WorkspaceMetadataManager.refreshMetadata(file, Utils.subMonitorFor(refreshMonitor, 5));

                    // obtain resulting revision if need to send to SBM
                    if (actionDetails != null) {
                        ActionDetails aDetails = actionDetails.get(request.getResource());
                        if (aDetails != null) {
                            BaseMetadata bm = WorkspaceMetadataManager.getInstance().getMetadata(file);
                            if (bm instanceof ItemMetadata) {
                                String itemSpec = ((ItemMetadata) bm).getItemSpec();
                                if (itemSpec != null) {
                                    aDetails.setPath(TeamUtils.getFullSbmFilename(aDetails.getPath(), itemSpec, false));
                                    aDetails.setNewRevision(TeamUtils.extractRevisionFromSpec(itemSpec));
                                }
                            }
                        }
                    }
                } else if (resourceRequest instanceof CreateFolderRequest) {
                    CreateFolderRequest request = (CreateFolderRequest) resourceRequest;
                    IContainer resource = (IContainer) request.getResource();
                    if (resource.getType() != IResource.PROJECT) {
                        TeamUtils.ensureReacheable(resource, false); // deliver was successful ensure have md up the hierarchy
                    }
                } else if (resourceRequest instanceof MoveFolderRequest) {
                    MoveFolderRequest request = (MoveFolderRequest) resourceRequest;
                    IContainer resource = (IContainer) request.getDestination();
                    FileToTransfer fileToUpload = getFileToUploadFromStatusMap(statusMap, resource);
                    if (fileToUpload != null) {
                        String status = fileToUpload.getStatus();
                        if (status != null && fileToUpload.getCmdStatus() && (ObjectToTransfer.STATUS_RESOLVED.equals(status)
                                || (ObjectToTransfer.STATUS_IGNORED.equals(status)))) {
                            cleanDMWorkspaceMoveCache(resource);
                            workspace.unregisterMove(resource);
                        }
                    }
                } else if (resourceRequest instanceof MoveItemRequest) {
                    MoveItemRequest request = (MoveItemRequest) resourceRequest;
                    IResource resource = request.getDestination();
                    FileToTransfer fileToUpload = getFileToUploadFromStatusMap(statusMap, resource);
                    if (fileToUpload != null) {
                        String status = fileToUpload.getStatus();
                        if (status != null && fileToUpload.getCmdStatus() && (ObjectToTransfer.STATUS_RESOLVED.equals(status)
                                || (ObjectToTransfer.STATUS_IGNORED.equals(status)))) {
                            workspace.unregisterMove(resource);
                        }
                    }
                }
            }
            refreshMonitor.done();

            if (!toClean.isEmpty()) {
                DMTeamPlugin.getWorkspace().cleanTimestamps(toClean.toArray(new IResource[toClean.size()]), IResource.DEPTH_ZERO,
                        Utils.subMonitorFor(monitor, 10));
            } else {
                monitor.worked(10);
            }

            // associate in SBM, if necessary
            if (sbmc != null && actionDetails != null && !actionDetails.isEmpty()) {
                ActionDetails[] actions = actionDetails.values().toArray(new ActionDetails[actionDetails.size()]);
                AssociateInput ai = new AssociateInput(actions, null);
                ISBMManager sbmManager = sbmc.getSBMManager();
                sbmManager.associate(ai, null);
            }

            // merge individually
            for (Iterator<WorkspaceResourceRequest> mIter = merges.iterator(); mIter.hasNext();) {
                UploadRequest request = (UploadRequest) mIter.next();
                request.setProject(dmProject);
                request.process(Utils.subMonitorFor(monitor, 100));
                if (!request.getStatus().isOK()) {
                    addError(request.getStatus());
                    mIter.remove(); // do not replace failed merges!
                }
                Utils.checkCanceled(monitor);
            }

            // MI does not update metadata so need to refetch
            if (!merges.isEmpty()) {
                IFile[] filesToFetch = new IFile[merges.size()];
                for (int i = 0; i < filesToFetch.length; i++) {
                    filesToFetch[i] = ((UploadRequest) merges.get(i)).getFile();
                }
                // there is no way to find out the revision that was actually created by merge
                // so the best we can do is to find out what's latest and hope this is our merge result
                DMTeamPlugin.getWorkspace().getSubscriber().refresh(filesToFetch, IResource.DEPTH_INFINITE,
                        Utils.subMonitorFor(monitor, filesToFetch.length * 100));
                for (int i = 0; i < filesToFetch.length; i++) {
                    if (DMTeamPlugin.getWorkspace().hasRemote(filesToFetch[i])) {
                        IDMRemoteFile variant = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getRemoteResource(filesToFetch[i]);
                        ItemRevision revToFetch = variant.getItemRevision();
                        GetRevisionRequest getRequest = new GetRevisionRequest(filesToFetch[i], revToFetch);
                        getRequest.process(Utils.subMonitorFor(monitor, 100));
                        UploadRequest ur = (UploadRequest) merges.get(i);
                        if (ur.isCheckout()) {
                            checkouts.add(ur);
                        }
                    }
                }
            }

            if (!checkouts.isEmpty()) {
                runCheckout(checkouts, Utils.subMonitorFor(monitor, requestedCheckoutCnt * 100));
            }
        } finally {
            monitor.done();
        }
    }

    private FileToTransfer getFileToUploadFromStatusMap(HashMap<String, FileToTransfer> statusMap, IResource resource) {
        if (statusMap != null) {
            String path = resource.getLocation().toOSString();
            Object result = statusMap.get(path);
            if (result != null) {
                return (FileToTransfer) result;
            } else {
                path = StringPath.terminate(path);
                result = statusMap.get(path);
                if (result != null) {
                    return (FileToTransfer) result;
                }
            }
        }

        return null;
    }

    private void cleanDMWorkspaceMoveCache(IContainer resource) throws CoreException {
        DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
        IResource[] members = resource.members();
        for (int i = 0; i < members.length; i++) {
            workspace.unregisterMove(members[i]);
            if (members[i] instanceof IContainer) {
                cleanDMWorkspaceMoveCache((IContainer) members[i]);
            }
        }
    }

    @Override
    public boolean modifiesRemote() {
        return refreshNeeded;
    }

    @Override
    protected String getErrorMessage(IStatus[] errors) {
        int coErrCnt = 0;
        for (int i = 0; i < errors.length; i++) {
            if (errors[i].getCode() == DMTeamStatus.CHECKOUT_FAILED) {
                coErrCnt++;
            }
        }
        if (coErrCnt == 0) {
            return Messages.UploadCommand_0;
        }
        if (coErrCnt == errors.length) {
            return Messages.UploadCommand_1;
        }
        return Messages.UploadCommand_2;
    }

    private List<UploadBucket> bucketize(ArrayList<WorkspaceResourceRequest> uploads) {
        ArrayList<UploadBucket> buckets = new ArrayList<UploadBucket>();
        for (Iterator<WorkspaceResourceRequest> uIter = uploads.iterator(); uIter.hasNext();) {
            WorkspaceResourceRequest request = uIter.next();
            boolean added = false;
            for (Iterator<UploadBucket> bIter = buckets.iterator(); bIter.hasNext() && !added;) {
                UploadBucket aBucket = bIter.next();
                added = aBucket.add(request);
            }
            if (!added) {
                buckets.add(new UploadBucket(request));
            }
        }
        return buckets;
    }

    private HashMap<String, FileToTransfer> runUpload(List<UploadBucket> buckets, IProgressMonitor monitor, boolean isSharing,
            int unitsPerFile) throws CoreException {
        // put results in a map for faster lookup
        HashMap<String, FileToTransfer> statusMap = new HashMap<String, FileToTransfer>();

        boolean debug = DMTeamPlugin.getDefault().isDebugging();
        if (debug && !buckets.isEmpty()) {
            System.out.println("+ Uploading over " + buckets.size() + " buckets"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        for (Iterator<UploadBucket> bIter = buckets.iterator(); bIter.hasNext();) {
            UploadBucket aBucket = bIter.next();
            if (debug) {
                System.out.println(aBucket);
            }
            DimensionsResult dr = aBucket.upload((WorksetProject) dmProject, isSharing,
                    Utils.subMonitorFor(monitor, aBucket.size() * unitsPerFile));
            @SuppressWarnings("unchecked")
            List<FileToTransfer> details = dr.getResultList();
            for (Iterator<FileToTransfer> dIter = details.iterator(); dIter.hasNext();) {
                FileToTransfer fileDetails = dIter.next();
                statusMap.put(fileDetails.getFileName(), fileDetails);

                addError(fileDetails);
            }
        }
        if (debug && !buckets.isEmpty()) {
            System.out.println();
            System.out.println("- done"); //$NON-NLS-1$
        }

        return statusMap;
    }

    private boolean isCIU(List<String> commands) {
        if (commands.size() != 1) {
            return false;
        }
        String cmd = commands.get(0);
        if (cmd == null) {
            return false;
        }
        return cmd.toUpperCase().startsWith("CIU"); //$NON-NLS-1$
    }

    /*
     * checkout strategy is to attempt basic, if failure because server wants additional
     * data then report up appropriately so that a corrective action can be taken
     */
    private void runCheckout(ArrayList<UploadRequest> checkouts, IProgressMonitor coMon)
            throws TeamException, CoreException, DMException {
        coMon.beginTask(null, checkouts.size() * 10);
        try {
            for (int i = 0; i < checkouts.size(); i++) {
                UploadRequest ur = checkouts.get(i);
                ItemMetadata itemMetadata = (ItemMetadata) WorkspaceMetadataManager.getInstance().getMetadata(ur.getFile());
                if (itemMetadata != null) {
                    String createdSpec = itemMetadata.getItemSpec();
                    ItemRequest ir = (ItemRequest) ur.getParameters();
                    ItemRevision revToCheckout = dmProject.getItemRevisionProxy(createdSpec);
                    CheckoutRequest cor = new CheckoutRequest(ur.getFile(), ir.getType(), revToCheckout, false, false);
                    try {
                        cor.process(Utils.subMonitorFor(coMon, 10));
                    } catch (DMException e) {
                        addError(new DMTeamStatus(IStatus.ERROR, DMTeamStatus.CHECKOUT_FAILED, e.getStatus().getMessage(),
                                e.getStatus().getException(), ur.getFile()));
                    }
                }
            }
        } finally {
            coMon.done();
        }
    }

    private ActionDetails createActionDetails(UploadRequest request) throws TeamException {
        List<String> sbmItems = request.getChangeRequests();
        if (sbmItems == null || sbmItems.isEmpty()) {
            return null; // nothing to associate
        }

        ActionDetails result = new ActionDetails();
        List<String> itemIds = sbmItems;
        result.setItemIds(itemIds);
        result.setAction(getSBMAction(request.getKind()));
        result.setPath(TeamUtils.getBaseSbmFilename(dmProject.getId(),
                dmProject.getRemotePathForLocalResource(request.getResource()).toString()));
        // set prev rev unless creating a new resource
        if ((request.getKind() & WorkspaceResourceRequest.CREATE) == 0) {
            IDMRemoteResource base = DMTeamPlugin.getWorkspace().getBaseResource(request.getResource());
            if (base instanceof IDMRemoteFile) {
                IDMRemoteFile baseRevision = (IDMRemoteFile) base;
                result.setPrevRevision(baseRevision.getRevision());
            }
        }
        result.setComment(request.getParameters().getComment());
        return result;
    }

    private String getSBMAction(int kind) {
        return ActionDetails.ASSOCIATE;
    }

}

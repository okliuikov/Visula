package com.serena.eclipse.dimensions.internal.team.core;

import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.OverlappingStatsCallback;

/**
 * Collecting files in the refresh list
 */
class CollectFilesStatsCallback implements OverlappingStatsCallback {
    // maximum quantity of files that will be refreshed per file instead of project recursive update
    static final int MAX_SINGLE_FILES_TO_REFRESH = 5120;

    private boolean filesLimitReached = false;
    private int singleFiles = 0;

    /**
     * return false if files size more than reasonable level
     */
    @Override
    public boolean fileAdded() {
        this.singleFiles++;
        if (singleFiles > MAX_SINGLE_FILES_TO_REFRESH) {
            this.filesLimitReached = true;
            return false;
        } else {
            return true;
        }
    }

    /**
     * returns true if single files limit was reached
     */
    @Override
    public boolean isStatsLimitReached() {
        return filesLimitReached;
    }

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Cancels extract.
 *
 * @author V.Grishchenko
 */
class UndoCheckoutCommand extends DMWorkspaceCommand1 {
    private boolean needsLatestRemoteState;

    public UndoCheckoutCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    public boolean modifiesRemote() {
        return !needsLatestRemoteState; // if need to replace already refreshed by execute
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        List<DimensionsArObject> objects = dmProject.fetchMembers(dmProject.getRoot(), IResource.FILE,
                new int[] { SystemAttributes.OBJECT_SPEC }, true, Utils.subMonitorFor(monitor, 100));

        List<ItemRevision> latestRevisions = new ArrayList<ItemRevision>();
        for (DimensionsArObject dimensionsArObject : objects) {
            if (dimensionsArObject instanceof ItemRevision) {
                latestRevisions.add((ItemRevision) dimensionsArObject);
            }
        }

        Map<String, List<ItemRevision>> expandedRevs = dmProject.expandItemRevisions(latestRevisions,
                new int[] { SystemAttributes.OBJECT_SPEC }, Utils.subMonitorFor(monitor, 100));
        HashMap<String, ItemRevision> allRevisions = new HashMap<String, ItemRevision>();
        for (Iterator<Entry<String, List<ItemRevision>>> iter = expandedRevs.entrySet().iterator(); iter.hasNext();) {
            Entry<String, List<ItemRevision>> entry = iter.next();
            List<ItemRevision> revisions = entry.getValue();
            for (Iterator<ItemRevision> iterator = revisions.iterator(); iterator.hasNext();) {
                ItemRevision otherRevision = iterator.next();
                allRevisions.put((String) otherRevision.getAttribute(SystemAttributes.OBJECT_SPEC), otherRevision);
            }
        }
        // undo checkout only for existing revisions
        ArrayList<UndoCheckoutRequest> toUncheckout = new ArrayList<UndoCheckoutRequest>(requests.length);
        HashSet<String> missing = new HashSet<String>();
        boolean needToReplace = false;
        for (int i = 0; i < requests.length; i++) {
            UndoCheckoutRequest undoCheckoutRequest = (UndoCheckoutRequest) requests[i];
            ItemRevision revToUncheckout = undoCheckoutRequest.getItemRevision();
            if (!allRevisions.containsKey(revToUncheckout.getAttribute(SystemAttributes.OBJECT_SPEC))) {
                // revision does not exist for some reason, replace such files with latest
                // as this is the only viable option - checkout base revision is not available from metadata
                if (undoCheckoutRequest.getReplace() == UndoCheckoutRequest.REPLACE_BASE) {
                    undoCheckoutRequest.setReplace(UndoCheckoutRequest.REPLACE_LATEST);
                } else if (!undoCheckoutRequest.isReplace()) {
                    undoCheckoutRequest.setReplace(UndoCheckoutRequest.REPLACE_METADATA_ONLY);
                }
                missing.add((String) revToUncheckout.getAttribute(SystemAttributes.OBJECT_SPEC));
            } else {
                toUncheckout.add(undoCheckoutRequest);
            }
            needToReplace |= undoCheckoutRequest.isReplace();
            needsLatestRemoteState |= (undoCheckoutRequest.getReplace() == UndoCheckoutRequest.REPLACE_LATEST
                    || undoCheckoutRequest.getReplace() == UndoCheckoutRequest.REPLACE_METADATA_ONLY);
        }

        IProgressMonitor progress = Utils.subMonitorFor(monitor, 800);
        int refreshUnits = needsLatestRemoteState ? 500 : 0;
        progress.beginTask(null, requests.length * 200 + refreshUnits);

        // 1. uncheckout
        for (Iterator<UndoCheckoutRequest> iter = toUncheckout.iterator(); iter.hasNext();) {
            UndoCheckoutRequest request = iter.next();
            request.process(Utils.subMonitorFor(monitor, needToReplace ? 100 : 200));
            Utils.checkCanceled(progress);
        }

        if (needToReplace) {
            // 2. refresh remote workspace state so we know correct remote, avoid base tree refresh because don't want to send
            // base changes too early
            if (needsLatestRemoteState) {
                setChanges(getWorkspace().refreshRemoteTree(getResourcesToRefresh(), IResource.DEPTH_INFINITE, false,
                        Utils.subMonitorFor(monitor, refreshUnits)));
            }

            // 3. replace
            for (int i = 0; i < requests.length; i++) {
                UndoCheckoutRequest request = (UndoCheckoutRequest) requests[i];
                request.processReplace(Utils.subMonitorFor(monitor, 100));
                if (missing.contains(request.getItemRevision().getAttribute(SystemAttributes.OBJECT_SPEC))) {
                    String msg;
                    if (request.getReplace() == UndoCheckoutRequest.REPLACE_METADATA_ONLY) {
                        msg = NLS.bind(Messages.UndoCheckoutCommand_revNotFoundKeep,
                                request.getItemRevision().getAttribute(SystemAttributes.OBJECT_SPEC));
                    } else {
                        msg = NLS.bind(Messages.UndoCheckoutCommand_revNotFound,
                                request.getItemRevision().getAttribute(SystemAttributes.OBJECT_SPEC),
                                request.getFile().getFullPath().toString());
                    }
                    addError(new DMTeamStatus(IStatus.WARNING, DMTeamStatus.UNKNOWN, msg, null));
                }
                Utils.checkCanceled(progress);
            }
        }
    }

    @Override
    protected String getErrorMessage(IStatus[] errors) {
        return Messages.UndoCheckoutCommand_revsNotFound;
    }

}

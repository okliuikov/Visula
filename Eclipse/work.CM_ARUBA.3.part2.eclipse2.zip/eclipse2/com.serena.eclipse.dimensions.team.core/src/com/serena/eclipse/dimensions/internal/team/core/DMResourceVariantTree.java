/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.ResourceVariantByteStore;
import org.eclipse.team.core.variants.ResourceVariantTree;

import com.serena.eclipse.dimensions.core.DMException;

/**
 * Base class for DM variant trees. Creates dm variants from bytes.
 *
 * @author V.Grishchenko
 */
abstract class DMResourceVariantTree extends ResourceVariantTree implements IDMRemoteTree {
    private Subscriber subscriber;

    /**
     * Creates a new tree on top of the specified byte store.
     * @param store
     */
    public DMResourceVariantTree(ResourceVariantByteStore store, Subscriber subscriber) {
        super(store);
        this.subscriber = subscriber;
    }

    @Override
    public ResourceVariantByteStore getByteStore() {
        return super.getByteStore();
    }

    /**
     * @return Returns the subscriber.
     */
    public Subscriber getSubscriber() {
        return subscriber;
    }

    @Override
    public IResource[] roots() {
        return subscriber.roots();
    }

    public void dispose() {
        getByteStore().dispose();
    }

    /**
     * @return project based on resource sharing or <code>null</code> if
     *         resource is from a project not shared with Dimensions
     */
    protected IDMProject getDMProject(IResource resource) throws CoreException {
        DMRepositoryProvider provider = DMRepositoryProvider.getDMProvider(resource);
        if (provider == null) {
            return null;
        }
        return provider.getIdmProject();
    }

    @Override
    public IResourceVariant getResourceVariant(IResource resource) throws TeamException {
        if (resource == null) {
            return null;
        }

        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        IDMProject dmProject;
        try {
            dmProject = getDMProject(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        if (dmProject == null) {
            return null;
        }

        IPath remotePath = dmProject.getRemotePathForLocalResource(resource);
        if (remotePath == null) {
            return null;
        }

        // check if we have something in the cache first
        IDMRemoteResource variant = getCachedRemoteResource(resource);
        if (variant != null) {
            return variant;
        }

        byte[] bytes = getByteStore().getBytes(resource);
        if (bytes == null) {
            return null;
        }

        // create from bytes as the last resort
        try {
            if (DMRemoteResource.getResourceType(bytes) == IResource.FILE) {
                return DMRemoteFile.fromBytes(remotePath, dmProject, this, bytes);
            } else if (resource.getType() == IResource.PROJECT && !resource.getName().equals("Left")
                    && !resource.getName().equals("Right") && !resource.getName().equals("Ancestor")) {
                // As getResourceType(bytes) may be FOLDER for PROJECT. The else if block must not be executed when projects are
                // compared in the Serena explorer view.
                DMRemoteFolder dmRemoteFolder = DMRemoteFolder.fromBytes(remotePath, dmProject, this, bytes);
                return dmRemoteFolder;
            }
            return DMRemoteFolder.fromBytes(remotePath, dmProject, this, bytes);
        } catch (IOException ioe) {
            DMTeamStatus error = DMTeamStatus.createErrorStatus(DMTeamStatus.BAD_SYNC_BYTES,
                    NLS.bind(Messages.error_badSyncBytes, resource.getLocation().toOSString()), ioe);
            throw new TeamException(error);
        }
    }

    /*
     * returns members if cached, otherwise performs a fetch
     */
    @Override
    protected IResourceVariant[] fetchMembers(IResourceVariant variant, IProgressMonitor progress) throws TeamException {
        if (variant instanceof IDMRemoteFolder) {
            DMRemoteFolder remoteFolder = (DMRemoteFolder) variant;
            IResourceVariant[] members = (IResourceVariant[]) remoteFolder.getCachedMembers();
            if (members == null) {
                try {
                    members = (IResourceVariant[]) remoteFolder.fetchMembers(progress);
                } catch (CoreException e) {
                    throw TeamException.asTeamException(e);
                }
            }
            return members;
        }
        return new IResourceVariant[0];
    }

    protected IDMRemoteResource getCachedRemoteResource(IResource resource/* , IDMProject project */) {
        return null;
    }

    @Override
    protected IResource[] collectedMembers(IResource local, IResource[] members) throws TeamException {
        IResource[] resources = getStoredMembers(local);
        List<IResource> children = new ArrayList<IResource>();
        List<IResource> changedResources = new ArrayList<IResource>();
        children.addAll(Arrays.asList(members));
        for (int i = 0; i < resources.length; i++) {
            IResource resource = resources[i];
            if (!children.contains(resource)) {
                // These sync bytes are stale. Purge them
                flushVariants(resource, IResource.DEPTH_INFINITE);
                changedResources.add(resource);
            }
        }
        return changedResources.toArray(new IResource[changedResources.size()]);
    }

    /**
     * Return all the members of that have resource variant information associated with them,
     * such as members that are explicitly flagged as not having a resource variant.
     */
    private IResource[] getStoredMembers(IResource local) throws TeamException {
        return getByteStore().members(local);
    }

    void newManagedProject(IDMProject project) throws TeamException {
        IContainer localRoot = project.getRoot();
        DMRemoteFolder remoteRoot = new DMRemoteFolder(null, Path.EMPTY, project, this);
        setVariant(localRoot, remoteRoot);
    }

    /**
     * Always obtains the latest information.
     *
     * @param folder
     * @param monitor
     * @return
     * @throws DMException
     */
    protected abstract List<IDMRemoteResource> fetchFolderMembers(IDMRemoteFolder folder, IProgressMonitor monitor)
            throws CoreException;

}

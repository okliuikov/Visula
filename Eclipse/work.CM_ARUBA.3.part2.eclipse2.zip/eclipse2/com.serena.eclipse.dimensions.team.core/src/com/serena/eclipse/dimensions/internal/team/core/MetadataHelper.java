package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileInfo;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.filesystem.IFileSystem;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

public final class MetadataHelper {

    public static void writeMetadataForContainer(IContainer container) throws CoreException {
        if (container.getType() == IResource.PROJECT
                || WorkspaceMetadataManager.getInstance().hasMetadataRecord(container)) {
            return;
        }

        IDMWorkspaceResource resource = DMTeamPlugin.getWorkspace().getWorkspaceResource(container);
        IDMProject project = resource.getProject();

        DirectoryMetadata metadata = new DirectoryMetadata();
        metadata.setVersion(TeamUtils.CURRENT_METADATA_VERSION);
        metadata.setProject(project.getId());
        metadata.setProjectUid(project.getDmUid());
        if (project.isFullWorkArea()) {
            metadata.setRelPath(container.getLocation().makeRelativeTo(project.getWorkAreaPath()).toString());
        } else {
            metadata.setRelPath(container.getProjectRelativePath().toOSString());
        }

        WorkspaceMetadataManager.getInstance().createDirectoryMetadata(container, metadata);
    }

    /**
     * Finds all metadata containers below the specified container.
     *
     * @param container
     * @param teamPrivate
     *            include team private
     * @param nonTeamPrivate
     *            include non team private
     * @return guaranteed not to be <code>null</code>
     * @throws CoreException
     */
    public static List<IResource> findMetadataContainers(IContainer container, final boolean teamPrivate,
            final boolean nonTeamPrivate) throws CoreException {
        final List<IResource> result = new ArrayList<IResource>();
        final MetadataProvider mdProvider = MetadataProviderFactory.providerFor(container);
        try {
            container.accept(new IResourceVisitor() {

                @Override
                public boolean visit(IResource resource) throws CoreException {
                    if (resource.getType() == IResource.FOLDER && mdProvider.metadataDirname().equals(resource.getName())
                            && ((teamPrivate && resource.isTeamPrivateMember())
                                    || (nonTeamPrivate && !resource.isTeamPrivateMember()))) {
                        result.add(resource);
                    }
                    return true;
                }

            }, IResource.DEPTH_INFINITE, IContainer.INCLUDE_TEAM_PRIVATE_MEMBERS);
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
        return result;
    }

    /**
     * Sets 'hidden' attribute for the metadata folders in the hierarchy from child to parent path.
     * Returns false if there are no metadata folder above the child
     *
     * @param fromChild
     *            - child path to traverse from, inclusively
     * @param toParent
     *            - parent path to traverse to, inclusively
     * @param mdParentProvider
     *            - metadata holder
     * @return - return false if there are no metadata folder above the child path in the hierarchy, true otherwise
     */
    public static boolean hideMetadataHierarchy(IPath fromChild, IPath toParent, MetadataProvider mdParentProvider) {
        Assert.isLegal(fromChild != null && toParent != null, "fromChild path or toParent path is null"); //$NON-NLS-1$
        Assert.isLegal(toParent.isPrefixOf(fromChild), "toParent path is not the prefix of a fromChild path"); //$NON-NLS-1$

        MetadataProvider mdProvider = null;
        if (mdParentProvider != null) {
            mdProvider = mdParentProvider;
        } else {
            mdProvider = MetadataProviderFactory.providerFor(fromChild);
        }
        try {
            IFileSystem fsystem = EFS.getLocalFileSystem();
            IPath currPath = fromChild;
            while (currPath.segmentCount() >= toParent.segmentCount()) {
                File metadataFolder = new File(currPath.toFile(), mdProvider.metadataDirname());
                if (metadataFolder.exists() && mdProvider.isMetadataDir(metadataFolder.toString())) {

                    IFileStore fstore = fsystem.fromLocalFile(metadataFolder);
                    IFileInfo finfo = fstore.fetchInfo();
                    finfo.setAttribute(EFS.ATTRIBUTE_HIDDEN, true);
                    try {
                        fstore.putInfo(finfo, EFS.SET_ATTRIBUTES, null);
                    } catch (CoreException e) {
                        DMTeamPlugin.getDefault().getLog().log(e.getStatus());
                    }
                } else {
                    return false;
                }
                if (currPath.isRoot()) {
                    break;
                }
                currPath = currPath.removeLastSegments(1);
            }
        } finally {
            if (mdParentProvider == null) {
                mdProvider.close();
            }
        }
        return true;
    }

}
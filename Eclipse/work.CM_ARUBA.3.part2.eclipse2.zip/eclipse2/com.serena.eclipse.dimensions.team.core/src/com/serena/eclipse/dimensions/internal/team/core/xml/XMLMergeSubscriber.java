/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.subscribers.SubscriberChangeEvent;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;
import org.eclipse.team.core.variants.IResourceVariantTree;
import org.eclipse.team.core.variants.PersistantResourceVariantByteStore;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.sync.SyncConstants.ContainerObjectClass;
import com.serena.dmfile.sync.SyncMode;
import com.serena.dmfile.xml.ContainerAttributes;
import com.serena.dmfile.xml.DetectedResolutions;
import com.serena.dmfile.xml.DetectedResolutionsContainer;
import com.serena.dmfile.xml.MergeParams;
import com.serena.dmfile.xml.ObjectAttributes;
import com.serena.dmfile.xml.Resolution;
import com.serena.dmfile.xml.utility.NonConsecutiveCherrypickUtility;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.Messages;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer;

/**
 * This special subscriber creates sync-infos without internal sync kind calculation. Subscriber
 * sync-infos generation based on the three way merge xml results
 */
public class XMLMergeSubscriber extends Subscriber implements IResourceChangeListener {
    public static final String ID = "com.serena.eclipse.dimensions.team.dmxmlmerge-subscriber"; //$NON-NLS-1$
    public static final String SYNC_KEY_QUALIFIER = "com.serena.eclipse.dimensions.team"; //$NON-NLS-1$
    public static final String ANCESTOR_TREE_SUFFIX = "-ancestor-tree"; //$NON-NLS-1$
    public static final String REMOTE_TREE_SUFFIX = "-remote-tree"; //$NON-NLS-1$

    private static boolean debugUpdateMerge = DMTeamPlugin.getDefault().isDebuggingUpdateMerge();

    private MergeDescriptorsContainer descriptorsContainer;
    private Map<IProject, IResourceVariantTree> ancTrees;
    private Map<IProject, IResourceVariantTree> srcTrees;

    /**
     * do we need to refetch data from server
     */
    private boolean refetch = false;
    /**
     * do we need to clean subscriber
     */
    private boolean clean = false;
    /**
     * Indicates whether all descriptors in subscriber are up to date
     */
    private boolean upToDate = true;
    /***
     * Set of SyncInfo that was affected by "Apply Selected Changes"
     */
    private Set<XMLSyncInfo> applySelectedChangesScope;

    public XMLMergeSubscriber(MergeDescriptorsContainer container) {
        this.descriptorsContainer = container;
        this.ancTrees = new HashMap<IProject, IResourceVariantTree>();
        this.srcTrees = new HashMap<IProject, IResourceVariantTree>();
    }

    @Override
    public void refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
        if (debugUpdateMerge) {
            DMPlugin.getDefault().getConsole().printMessage("XMLMergeSubscriber#refresh started");
        }

        Set<IResource> changes = new HashSet<IResource>();

        if (refetch && !clean) {
            // clear all projects if refresh was submitted
            changes.addAll(Arrays.asList(descriptorsContainer.getAllTargetResources()));
            descriptorsContainer.clearCachedInfo();
        } else if (clean && applySelectedChangesScope != null) {
            // clean only selected resources
            List<XMLMergeDescriptor> executedDescriptors = descriptorsContainer.getExecutedDescriptors();
            changes.addAll(Arrays.asList(MergeDescriptorsContainer.getAllTargetResources(executedDescriptors)));
            descriptorsContainer.clearCachedInfo(executedDescriptors, applySelectedChangesScope);
        } else if (clean) {
            // clear executed projects that has any applied changes
            List<XMLMergeDescriptor> executedDescriptors = descriptorsContainer.getExecutedDescriptors();
            changes.addAll(Arrays.asList(MergeDescriptorsContainer.getAllTargetResources(executedDescriptors)));
            descriptorsContainer.clearCachedInfo(executedDescriptors);
        }

        try {
            monitor.beginTask(null, (!clean ? 100 : 0)
                    + (refetch && !clean ? descriptorsContainer.getMergeDescriptors().size() * 100 : 0));

            if (refetch && !clean) {
                // when toolbar button was pressed force descriptors update
                List<XMLMergeDescriptor> descrs = descriptorsContainer.getMergeDescriptors();
                for (XMLMergeDescriptor descr : descrs) {
                    IDMProject target = descr.getTarget();
                    IDMProject[] projects = DMTeamPlugin.getWorkspace().getProjects();

                    if (target == null || projects == null || projects.length == 0) {
                        return;
                    }

                    // always try to replace target project in descriptor during refresh because
                    // user can refetch it to another location and old path information will be
                    // invalid.
                    boolean candidateMatch = false;
                    for (int i = 0; i < projects.length; i++) {
                        IDMProject candidate = projects[i];
                        if (target.getId().equals(candidate.getId()) && target.getType() == candidate.getType()
                                && target.getRemoteOffset().equals(candidate.getRemoteOffset())
                                && target.getConnection().equals(candidate.getConnection())
                                && target.getProject().equals(candidate.getProject())) {
                            descr.setTarget(candidate);
                            candidateMatch = true;
                            break;
                        }
                    }

                    // avoid running of the merge command for unmaintained workspace project
                    if (!candidateMatch) {
                        descr.dropXMLResolutions();
                        continue;
                    }

                    descr.setCurrentMode(SyncMode.DETECT_RESOLUTIONS);
                    XMLWorkspaceMergeCommand command = new XMLWorkspaceMergeCommand(descr);
                    command.execute(Utils.subMonitorFor(monitor, 100));
                }
            }

            if (!clean) {
                refetchVariants(Utils.subMonitorFor(monitor, 100));

                List<XMLMergeDescriptor> descrs = descriptorsContainer.getMergeDescriptors();
                for (XMLMergeDescriptor descr : descrs) {
                    if (descr.getTarget().getProject().exists() && descr.getDetectedResolutions() != null) {
                        DetectedResolutions detectedResolutions = descr.getDetectedResolutions();
                        if (detectedResolutions.getResolutions() != null) {
                            // process new resolutions
                            for (Resolution resolution : detectedResolutions.getRootResolutions()) {
                                XMLSyncInfo info = XMLSyncInfoFactory.create(resolution, descr, this);
                                IResource local = info.getLocal();
                                if (!(local instanceof IProject)) {
                                    changes.add(info.getLocal());
                                }
                            }
                        }
                    }
                }
            }
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        } finally {
            // execution except first one should be a toolbar update on the sync view
            this.refetch = true;
            // clean execution removes old sync infos from view without refetch
            this.clean = false;
            // indicates that subscriber is up to date
            setUpToDate(true);
            // clear list of selected resources
            this.applySelectedChangesScope = null;
            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, changes.toArray(new IResource[changes.size()])));
            monitor.done();
            if (debugUpdateMerge) {
                DMPlugin.getDefault().getConsole().printMessage("XMLMergeSubscriber#refresh finished");
            }
        }
    }

    /**
     * Creates ancestor and remote trees for every local target that was included to merge
     */
    private void refetchVariants(IProgressMonitor monitor) throws CoreException {
        try {
            monitor.beginTask(null, descriptorsContainer.getAllTargetProjects().size() * 300);
            for (XMLMergeDescriptor descr : descriptorsContainer.getMergeDescriptors()) {
                if (descr.getTarget().getProject().exists() && descr.getDetectedResolutions() != null) {

                    DetectedResolutions detectedResolutions = descr.getDetectedResolutions();
                    if (detectedResolutions.getMergeParams() == null) {
                        continue;
                    }

                    MergeParams mp = detectedResolutions.getMergeParams();

                    IDMProject srcPrj = createRemoteProject(mp.getSrc(), descr, Utils.subMonitorFor(monitor, 50));
                    IDMProject ancPrj;
                    if (mp.getAnc() != null) {
                        ancPrj = createRemoteProject(mp.getAnc(), descr, Utils.subMonitorFor(monitor, 50));
                    } else {
                        ContainerAttributes generic = new ContainerAttributes();
                        generic.setSpec("$GENERIC:$GLOBAL"); //$NON-NLS-1$
                        generic.setObjClass(ContainerObjectClass.PCMS_WORKSET);
                        ancPrj = createRemoteProject(generic, descr, Utils.subMonitorFor(monitor, 50));
                    }

                    DetectedResolutionsContainer container = descr.getDetectedResolutionsContainer();

                    List<ObjectAttributes> sources = container.getAllSources();
                    if (sources != null) {
                        XMLMergeTree srcTree = createMergeTree(sources, descr.getTarget(), srcPrj, false);
                        srcTree.refresh(Utils.subMonitorFor(monitor, 100));
                        srcTrees.put(srcPrj.getProject(), srcTree);
                    } else {
                        monitor.worked(100);
                    }

                    List<ObjectAttributes> ancestors = getAncestors(container);
                    if (ancestors != null && ancestors.size() > 0) {
                        XMLMergeTree ancTree = createMergeTree(ancestors, descr.getTarget(), ancPrj, true);
                        ancTree.refresh(Utils.subMonitorFor(monitor, 100));
                        ancTrees.put(ancPrj.getProject(), ancTree);
                    } else {
                        monitor.worked(100);
                    }
                }
            }
        } finally {
            monitor.done();
        }
    }

    /***
     * Return list of ancestors for all root resolutions (for non-consecutive resolutions shifted ancestors are retrieved).
     */
    private List<ObjectAttributes> getAncestors(DetectedResolutionsContainer container) {
        if (container == null) {
            return Collections.emptyList();
        }
        if (container.getDetectedResolutions() == null) {
            return Collections.emptyList();
        }
        List<Resolution> rootResolutions = container.getDetectedResolutions().getRootResolutions();
        if (rootResolutions == null) {
            return Collections.emptyList();
        }
        
        List<ObjectAttributes> ancestors = new ArrayList<ObjectAttributes>();
        for (Resolution rootResolution : rootResolutions) {
            if (rootResolution.isConsecutive()) {
                if (rootResolution.getAnc() != null) {
                    ancestors.add(rootResolution.getAnc());
                }
            } else {
                ObjectAttributes shiftedAncestor = NonConsecutiveCherrypickUtility.getShiftedAncestor(rootResolution);
                if (shiftedAncestor != null) {
                    ancestors.add(shiftedAncestor);
                }
            }
        }
        return ancestors;
    }

    /**
     * Creates resource tree by attributes that were received from server
     */
    private XMLMergeTree createMergeTree(List<ObjectAttributes> attrs, IDMProject local, IDMProject target, boolean isAncestor) {
        Map<IResource, ObjectAttributes> resourceToAttribute = new HashMap<IResource, ObjectAttributes>();
        for (ObjectAttributes attr : attrs) {
            if (attr.isFileAttributes()) {
                IResource resource = TeamUtils.constructRelativeResource(attr, local);
                resourceToAttribute.put(resource, attr);
            }
        }

        PersistantResourceVariantByteStore store = null;
        if (!isAncestor) {
            store = new PersistantResourceVariantByteStore(new QualifiedName(SYNC_KEY_QUALIFIER, ID + REMOTE_TREE_SUFFIX
                    + target.getProject().getName()));
        } else {
            store = new PersistantResourceVariantByteStore(new QualifiedName(SYNC_KEY_QUALIFIER, ID + ANCESTOR_TREE_SUFFIX
                    + target.getProject().getName()));
        }

        return new XMLMergeTree(this, store, target, resourceToAttribute);
    }

    /**
     * Creates remote project by attributes that were received from server
     */
    private IDMProject createRemoteProject(final ContainerAttributes cattr, XMLMergeDescriptor descr, final IProgressMonitor monitor)
            throws CoreException {
        IDMProject result = null;
        final DimensionsConnectionDetailsEx connection = descr.getTarget().getConnection();
        final Session session = connection.openSession(monitor);
        if (cattr.getObjClass() == ContainerObjectClass.PCMS_WORKSET) {
            final WorksetAdapter[] workset = new WorksetAdapter[1];
            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    Project ancestor = session.getObjectFactory().getProject(cattr.getSpec());
                    if (ancestor == null) {
                        throw new CoreException(new Status(IStatus.WARNING, DMTeamPlugin.ID, NLS.bind(
                                Messages.DMXMLMergeCommand_project_source_not_found, cattr.getSpec())));
                    }
                    workset[0] = new WorksetAdapter(ancestor, connection);
                }
            }, monitor);
            if (workset[0] != null) {
                result = DMRepositoryProvider.createProject(workset[0], descr.getTarget().getProject(), null);
            }
        } else {
            final BaselineAdapter[] baseline = new BaselineAdapter[1];
            session.run(new ISessionRunnable() {

                @Override
                @SuppressWarnings("unchecked")
                public void run() throws Exception {
                    Filter filter = new Filter();
                    filter.criteria().add(
                            new Filter.Criterion(SystemAttributes.OBJECT_SPEC, cattr.getSpec(), Filter.Criterion.EQUALS));

                    List<?> baselines = session.getObjectFactory().getBaselines(filter);
                    if (baselines.isEmpty() || baselines.get(0) == null) {
                        throw new CoreException(new Status(IStatus.WARNING, DMTeamPlugin.ID, NLS.bind(
                                Messages.DMXMLMergeCommand_baseline_source_not_found, cattr.getSpec())));
                    }
                    Baseline ancestor = (Baseline) baselines.get(0);
                    baseline[0] = new BaselineAdapter(ancestor, connection);
                }
            }, monitor);
            if (baseline[0] != null) {
                result = DMRepositoryProvider.createProject(baseline[0], descr.getTarget().getProject(), null);
            }
        }
        return result;
    }

    /**
     * Find local projects that were deleted or disconnected from dimensions but still have a
     * relation with current merge data
     */
    private boolean findUnmaintainedProject(Set<XMLMergeDescriptor> unmaintained, IResourceDelta delta) throws CoreException {
        IResource resource = delta.getResource();

        if (resource != null && (delta.getFlags() == IResourceDelta.SYNC || delta.getKind() == IResourceDelta.REMOVED)) {
            Set<IDMProject> existingSet = new HashSet<IDMProject>(Arrays.asList(DMTeamPlugin.getWorkspace().getProjects()));
            Set<IDMProject> targetSet = new HashSet<IDMProject>(descriptorsContainer.getAllTargetProjects());

            targetSet.removeAll(existingSet);

            // contains only unmaintained projects
            if (targetSet.size() > 0) {
                for (IDMProject candidate : targetSet) {
                    if (candidate.getProject().getFullPath().isPrefixOf(resource.getFullPath())) {
                        // unmapped or deleted projects have been found
                        if (candidate.getProject().exists()) {
                            // unmapped project
                            return true;
                        } else if (delta.getKind() == IResourceDelta.REMOVED) {
                            // deleted project
                            XMLMergeDescriptor descr = descriptorsContainer.getTargetDescriptor(candidate);
                            if (descr != null) {
                                unmaintained.add(descr);
                                return true;
                            }
                        }
                    }
                }
            }
        }

        return false;
    }

    /**
     * Marks current merge results as STALE if corresponding change event has been occurred
     */
    @Override
    public void resourceChanged(IResourceChangeEvent event) {
        if (debugUpdateMerge) {
            DMPlugin.getDefault().getConsole().printMessage("XMLMergeSubscriber#resourceChanged started");
        }
        final boolean[] isStale = new boolean[] { false };
        final boolean[] isCleaned = new boolean[] { false };
        final Set<XMLMergeDescriptor> unmaintained = new HashSet<XMLMergeDescriptor>();

        try {
            if (descriptorsContainer.isInUse()) {
                return;
            }

            if (descriptorsContainer.isStale()) {

                // already stale but removed.
                if (event.getDelta().getKind() == IResourceDelta.CHANGED) {
                    event.getDelta().accept(new IResourceDeltaVisitor() {

                        @Override
                        public boolean visit(IResourceDelta delta) throws CoreException {
                            IResource resource = delta.getResource();
                            if (resource != null
                                    && (delta.getKind() == IResourceDelta.CHANGED || delta.getKind() == IResourceDelta.REMOVED)) {

                                if (findUnmaintainedProject(unmaintained, delta)) {
                                    isCleaned[0] = true;
                                    return false;
                                }
                                return true;
                            }
                            return false;
                        }

                    });
                }

                if (debugUpdateMerge) {
                    DMPlugin.getDefault().getConsole().printMessage("descriptorsContainer is stale");
                }

                // already marked as stale
                return;
            }

            if (event.getDelta().getKind() == IResourceDelta.CHANGED) {
                event.getDelta().accept(new IResourceDeltaVisitor() {

                    @Override
                    public boolean visit(IResourceDelta delta) throws CoreException {
                        IResource resource = delta.getResource();
                        if (resource != null
                                && (delta.getKind() == IResourceDelta.CHANGED || delta.getKind() == IResourceDelta.REMOVED || delta.getKind() == IResourceDelta.ADDED)) {

                            if (findUnmaintainedProject(unmaintained, delta)) {
                                isStale[0] = true;
                                return false;
                            }

                            XMLSyncInfo syncInfo = descriptorsContainer.getSyncInfoFromTarget(resource);
                            if (syncInfo == null) {
                                syncInfo = descriptorsContainer.getSyncInfoFromLocal(resource);
                            }

                            if (syncInfo != null) {
                                isStale[0] = true;
                                return false;
                            }

                            return true;
                        }

                        return false;
                    }
                });
            }
        } catch (CoreException e) {
            DMPlugin.log(e.getStatus());
        } finally {
            if (isStale[0] || isCleaned[0]) {
                if (debugUpdateMerge) {
                    DMPlugin.getDefault().getConsole().printMessage("isStale or isCleaned is true");
                }

                if (unmaintained.size() > 0) {
                    for (XMLMergeDescriptor descr : unmaintained) {
                        descr.markInSync();
                    }
                }

                if (isStale[0]) {
                    descriptorsContainer.markStale();
                }

                fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(XMLMergeSubscriber.this,
                        descriptorsContainer.getAllTargetResources()));

                // indicates that subscriber is out of date
                setUpToDate(false);
            }
            if (debugUpdateMerge) {
                DMPlugin.getDefault().getConsole().printMessage("XMLMergeSubscriber#resourceChanged finished");
            }
        }
    }

    @Override
    public String getName() {
        boolean doUpdate = descriptorsContainer.getMergeOptions().isDoUpdate();
        String name = doUpdate ? Messages.DMXMLUpdateSubscriber_name : Messages.DMXMLMergeSubscriber_name;
        return NLS.bind(name, descriptorsContainer.getMergeSourceSpec());
    }

    @Override
    public boolean isSupervised(IResource resource) throws TeamException {
        // stub value
        return true;
    }

    @Override
    public IResource[] members(IResource resource) throws TeamException {
        // stub value
        return new IResource[0];
    }

    @Override
    public IResource[] roots() {
        ArrayList<IResource> result = new ArrayList<IResource>();

        List<IDMProject> projects = descriptorsContainer.getAllTargetProjects();
        for (IDMProject idmProject : projects) {
            result.add(idmProject.getProject());
        }

        return result.toArray(new IProject[result.size()]);
    }

    @Override
    public SyncInfo getSyncInfo(IResource resource) throws TeamException {
        return descriptorsContainer.getSyncInfoFromTarget(resource);
    }

    public IResourceVariant getSourceResourceVariant(IResource resource) throws TeamException {
        if (resource != null) {
            IResourceVariantTree tree = srcTrees.get(resource.getProject());
            if (tree != null) {
                return tree.getResourceVariant(resource);
            }

        }
        return null;
    }

    public IResourceVariant getAncestorResourceVariant(IResource resource) throws TeamException {
        if (resource != null) {
            IResourceVariantTree tree = ancTrees.get(resource.getProject());
            if (tree != null) {
                return tree.getResourceVariant(resource);
            }

        }
        return null;
    }

    @Override
    public IResourceVariantComparator getResourceComparator() {
        return new IResourceVariantComparator() {

            @Override
            public boolean isThreeWay() {
                return ancTrees.size() > 0;
            }

            @Override
            public boolean compare(IResourceVariant base, IResourceVariant remote) {
                // stub value
                return false;
            }

            @Override
            public boolean compare(IResource local, IResourceVariant remote) {
                // stub value
                return false;
            }
        };
    }

    /**
     * @return merge data that was related to this subscriber
     */
    public MergeDescriptorsContainer getDescriptorsContainer() {
        return descriptorsContainer;
    }

    /**
     * Next execution will remove all data about file resolution from subscriber
     */
    public void forceCleanExecution() {
        this.clean = true;
    }

    /**
     * @return true if all descriptors in subscriber are up to date
     */
    public boolean isUpToDate() {
        return upToDate;
    }

    /**
     * @param upToDate
     *            the upToDate status to set
     */
    void setUpToDate(boolean upToDate) {
        this.upToDate = upToDate;
    }

    /***
     * Set some SyncInfo that were selected when "Apply Selected Changes" was executed.
     * 
     * @param subset
     *            subset of SyncInfo that was affected by "Apply Selected Changes"
     */
    public void setApplySelectedChangesScope(Set<XMLSyncInfo> subset) {
        this.applySelectedChangesScope = subset;
    }

}

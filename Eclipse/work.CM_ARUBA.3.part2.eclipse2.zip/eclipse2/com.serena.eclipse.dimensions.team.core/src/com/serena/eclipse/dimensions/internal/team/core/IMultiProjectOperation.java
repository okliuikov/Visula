package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IProject;

public interface IMultiProjectOperation {

    public IProject[] getProjectsToOperateOn(IProject[] topProjects);

}

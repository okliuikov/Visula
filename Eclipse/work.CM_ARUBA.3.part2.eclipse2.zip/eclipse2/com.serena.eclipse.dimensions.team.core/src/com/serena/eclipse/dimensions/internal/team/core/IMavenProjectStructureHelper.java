/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IMavenProjectStructureHelper {

    /**
     * @param project the project to find his root maven directory
     * @return the root directory of maven projects hierarchy or null if it doesn't have parent.
     *         If all parent projects were closed/deleted from eclipse this method returns null.
     *         If project isn't imported by maven (has maven nature, but unresolved in workspace)
     *         this method return null.
     */
    File getRootMavenProjectDir(IProject project, IProgressMonitor monitor);

    /**
     * @param project the project to find his root maven project
     * @return the root project of maven projects hierarchy or null if it doesn't have parent.
     *         If all parent projects was closed/deleted from eclipse this method returns null.
     *         If project isn't imported by maven (has maven nature, but unresolved in workspace)
     *         this method return null.
     */
    IProject getRootMavenProject(IProject project, IProgressMonitor monitor);

    /**
     * @param project the project to find his parent project directory
     * @return the parent project directory in the maven projects hierarchy or null if it doesn't have parent.
     *         If parent project was closed/deleted from eclipse this method returns null.
     *         If project isn't imported by maven (has maven nature, but unresolved in workspace)
     *         this method return null.
     */
    File getParentMavenProjectDir(IProject project, IProgressMonitor monitor);

    /**
     * @param project the project to find his parent project
     * @return the parent project in the maven projects hierarchy or null if it doesn't have parent.
     *         If parent project was closed/deleted from eclipse this method returns null.
     *         If project isn't imported by maven (has maven nature, but unresolved in workspace)
     *         this method return null.
     */
    IProject getParentMavenProject(IProject project, IProgressMonitor monitor);

    /**
     * @param project the project to check
     * @return true if project has parent maven pom/project upper in the directory hierarchy. This method doesn't take into
     *         account availability of parent project in the Eclipse. If project isn't imported by maven
     *         (has maven nature, but unresolved in workspace) this method return false.
     */
    public boolean hasParentPomInTree(IProject project, IProgressMonitor monitor);

    /**
     * @param project the project to check
     * @return true if project has maven nature.
     * @throws CoreException
     */
    public boolean hasMavenNature(IProject project);

    /**
     * @param project the project to check
     * @return true if project has maven nature and resolved by workspace.
     * @throws CoreException
     */
    public boolean isMavenProjectResolvedByWorkspace(IProject project);

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.ResourceVariantByteStore;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.xml.ObjectAttributes;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRemoteTree;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.Messages;

/**
 * Fake tree that contain cached variants only for resources that present in command XML file:
 * resolution source or resolution ancestor
 */
class XMLMergeTree extends DMRemoteTree {
    private IDMProject project;
    private Map<IResource, ObjectAttributes> resourceToAttribute;
    private Map<IResource, IDMRemoteResource> resourceToVariant;

    private XMLMergeTree(ResourceVariantByteStore store, Subscriber subscriber) {
        super(store, subscriber);
    }

    public XMLMergeTree(XMLMergeSubscriber xsubscriber, ResourceVariantByteStore store, IDMProject project,
            Map<IResource, ObjectAttributes> resourceToAttribute) {
        this(store, xsubscriber);
        this.project = project;
        this.resourceToAttribute = resourceToAttribute;
        this.resourceToVariant = new HashMap<IResource, IDMRemoteResource>();
    }

    @Override
    protected IDMProject getDMProject(IResource resource) throws CoreException {
        return project;
    }

    public IResource[] refresh(IProgressMonitor monitor) throws TeamException {
        return super.refresh(project.getProject(), IResource.DEPTH_ONE, monitor);
    }

    @Override
    protected IResourceVariant fetchVariant(IResource resource, int depth, IProgressMonitor monitor) throws TeamException {
        if (resource == null || project == null || !(resource instanceof IProject)) {
            return null;
        }

        try {
            monitor = Utils.monitorFor(monitor);
            monitor.beginTask(null, 100 * resourceToAttribute.size());
            monitor.subTask(Messages.RemoteTree_gettingLatest);
            for (Entry<IResource, ObjectAttributes> entry : resourceToAttribute.entrySet()) {
                IResource key = entry.getKey();
                final ObjectAttributes attr = entry.getValue();
                if (key.getType() == IResource.FILE) {
                    final ItemRevision[] revHolder = new ItemRevision[1];
                    Session session = project.getConnection().openSession(monitor);
                    session.run(new ISessionRunnable() {

                        @Override
                        public void run() throws Exception {
                            DimensionsLcObject object = project.getDimensionsObject();
                            if (object instanceof Project) {
                                Project project = (Project) object;
                                revHolder[0] = project.createItemRevisionFromUid(attr.getUid());
                            } else {
                                Baseline baseline = (Baseline) object;
                                revHolder[0] = baseline.createItemRevisionFromUid(attr.getUid());
                            }
                        }
                    }, Utils.subMonitorFor(monitor, 100));

                    if (revHolder[0] != null) {
                        ItemRevision revision = revHolder[0];
                        IPath relPath = new Path(attr.getRelPath());
                        revision.setAttribute(SystemAttributes.ITEMFILE_FILENAME, relPath.lastSegment());
                        revision.setAttribute(SystemAttributes.FULL_PATH_NAME, relPath);
                        revision.setAttribute(SystemAttributes.FILE_VERSION, attr.getFileVersion().intValue());
                        revision.setAttribute(SystemAttributes.OBJECT_SPEC, attr.getSpec());

                        resourceToVariant.put(key, createRemoteFile(null, relPath, project, revision, null));
                    }

                }
            }
        } catch (DMException e) {
            DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, e.getMessage()));
        } finally {
            resourceToAttribute = null;
            monitor.done();
        }

        return null;
    }

    @Override
    protected IDMRemoteResource getCachedRemoteResource(IResource resource) {
        return resourceToVariant.get(resource);
    }
}
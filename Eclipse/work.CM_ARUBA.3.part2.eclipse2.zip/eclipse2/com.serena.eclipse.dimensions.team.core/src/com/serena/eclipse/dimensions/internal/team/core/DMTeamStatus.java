/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

/**
 * @author V.Grishchenko
 */
public class DMTeamStatus extends Status {
    // status codes
    /** non-specific failure code */
    public static final int UNKNOWN = -100;
    /** connection name cannot be resolved to one of the registered connectios */
    public static final int MISSING_CONNECTION = -101;
    /** local path is not at below Eclipse project */
    public static final int INVALID_LOCAL_ROOT = -102;
    /** error processing sync bytes */
    public static final int BAD_SYNC_BYTES = -103;
    /** resource is not known to be under source control */
    public static final int UNMANAGED = -104;
    /** conflicting resource types, e.g. local file->remote folder */
    public static final int GENDER_CONFLICT = -105;
    /** attempt to checkout failed */
    public static final int CHECKOUT_FAILED = -106;

    private IResource resource;

    /**
     * @param severity
     * @param pluginId
     * @param code
     * @param message
     * @param exception
     */
    public DMTeamStatus(int severity, int code, String message, Throwable exception) {
        super(severity, DMTeamPlugin.ID, code, message, exception);
    }

    public DMTeamStatus(int severity, int code, String message, Throwable exception, IResource resource) {
        super(severity, DMTeamPlugin.ID, code, message, exception);
        this.resource = resource;
    }

    public static DMTeamStatus createErrorStatus(int code, String message, Throwable exception) {
        return new DMTeamStatus(IStatus.ERROR, code, message, exception);
    }

    public static DMTeamStatus createErrorStatus(int code, String message) {
        return new DMTeamStatus(IStatus.ERROR, code, message, null);
    }

    /**
     * @return the associated resource or <code>null</code> if none
     */
    public IResource getResource() {
        return resource;
    }

}

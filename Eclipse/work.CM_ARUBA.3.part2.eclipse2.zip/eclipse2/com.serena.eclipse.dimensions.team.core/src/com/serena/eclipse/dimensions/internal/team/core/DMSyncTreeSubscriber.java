/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceStatus;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.team.core.RepositoryProvider;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;
import org.eclipse.team.core.variants.ResourceVariantTreeSubscriber;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * Base dimensions subscriber.
 *
 * @author V.Grishchenko
 */
public abstract class DMSyncTreeSubscriber extends ResourceVariantTreeSubscriber implements IResourceVariantComparator {

    public static final String SYNC_KEY_QUALIFIER = "com.serena.eclipse.dimensions.team"; //$NON-NLS-1$
    public static final String BASE_TREE_SUFFIX = "-base-tree"; //$NON-NLS-1$
    public static final String REMOTE_TREE_SUFFIX = "-remote-tree"; //$NON-NLS-1$

    private String name;

    public DMSyncTreeSubscriber() {
    }

    public DMSyncTreeSubscriber(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean compare(IResourceVariant base, IResourceVariant remote) {
        if (base == remote) {
            return true;
        }

        if (base != null) {
            return base.equals(remote);
        }

        return false;
    }

    @Override
    public boolean compare(IResource local, IResourceVariant remote) {
        if (local.getType() != IResource.FILE) {
            if (remote.isContainer()) {
                return true;
            }
            return false;
        }
        IFile file = (IFile) local;
        try {
            IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
            if (workspace.isModified(file)) {
                if (TeamUtils.isConsiderContentsForComparison() && TeamUtils.areContentsEqual(local, remote)) {
                    return true;
                }
                return false;
            }
            IDMRemoteResource base = workspace.getBaseResource(file);
            if (base == remote) {
                return true;
            }
            if (base != null) {
                if (!base.equals(remote)) {
                    if (TeamUtils.isConsiderContentsForComparison() && TeamUtils.areContentsEqual(local, remote)) {
                        return true;
                    }
                } else {
                    return true;
                }
            } else { // local file is not managed
                if (TeamUtils.isConsiderContentsForComparison() && TeamUtils.areContentsEqual(local, remote)) {
                    return true;
                }
            }
            return false;
        } catch (CoreException e) {
            DMTeamPlugin.getDefault().getLog().log(e.getStatus());
        }
        return false;
    }

    @Override
    public boolean isThreeWay() {
        return getBaseTree() != null;
    }

    /**
     * Marks local resources as merged from the remote revisions. Behavior
     * is subscriber specific.
     *
     * @param locals
     * @param remotes
     * @throws CoreException
     */
    public abstract IStatus merged(IResource[] locals, IDMRemoteResource[] remotes, IProgressMonitor monitor) throws CoreException;

    /**
     * Finds a matching connection using the 1st non-null resource.
     */
    protected DimensionsConnectionDetailsEx getConnectionForResource(IResource local, IResourceVariant base, IResourceVariant remote)
            throws CoreException {
        DimensionsConnectionDetailsEx connection = null;
        if (local != null) {
            IDMProject project = DMTeamPlugin.getWorkspace().getProject(local);
            if (project != null) {
                connection = project.getConnection();
            }
        } else if (base != null) {
            connection = ((IDMRemoteResource) base).getProject().getConnection();
        } else if (remote != null) {
            connection = ((IDMRemoteResource) remote).getProject().getConnection();
        }
        return connection;
    }

    @Override
    public boolean isSupervised(IResource resource) throws TeamException {
        try {
            IProject project = resource.getProject();
            if (project == null) {
                return false;
            }
            RepositoryProvider provider = RepositoryProvider.getProvider(resource.getProject(), DMRepositoryProvider.ID);
            if (provider == null) {
                return false;
            }
            IDMWorkspaceResource dmResource = DMTeamPlugin.getWorkspace().getWorkspaceResource(resource);
            if (dmResource == null) {
                return false;
            }

            if (dmResource.isIgnored()) {
                // An ignored resource could have an incoming addition
                return getRemoteTree().hasResourceVariant(resource);
            }
            return true;
        } catch (CoreException e) {
            // If there is no resource in coe this means there is no local and no remote
            // so the resource is not supervised.
            if (e.getStatus().getCode() == IResourceStatus.RESOURCE_NOT_FOUND) {
                return false;
            }
            throw TeamException.asTeamException(e);
        }
    }

    @Override
    public IResourceVariantComparator getResourceComparator() {
        return this;
    }

}

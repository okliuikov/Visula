/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Updates item revision or runs a merge if local state indicates
 * parallel development merges occurred.
 * @author V.Grishchenko
 */
public class UpdateRevisionRequest extends CreateNewItemRevisionRequest {
    private ItemRevision revisionToUpdate;
    private boolean force = true;
    private String[] mergedFrom;

    private boolean moved;
    private boolean movedCrossProject;

    public UpdateRevisionRequest(IFile file, ItemType itemType, ItemRevision revisionToUpdate, boolean enforceRequest,
            boolean anyRequest) throws CoreException {
        // use checkout for cm rules as update is essentially an atomic checkout/checkin operation
        super(file, itemType, CHECKOUT, enforceRequest, anyRequest);
        this.revisionToUpdate = revisionToUpdate;
        IDMRemoteFile base = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(file);
        mergedFrom = base != null ? base.getMergedFromRevisions() : Utils.ZERO_LENGTH_STRING_ARRAY;
    }

    public void setMoved(boolean b) {
        this.moved = b;
    }

    public void setMovedCrossProject(boolean b) {
        this.movedCrossProject = b;
    }

    @Override
    public int getKind() {
        int kind = MODIFY;
        if (moved) {
            kind |= MOVE;
            if (movedCrossProject) {
                kind |= IMPORT;
            }
        }
        return kind;
    }

    public void setForceUpdate(boolean b) {
        this.force = b;
    }

    public boolean isForceUpadate() {
        return force;
    }

    /**
     * @return revision to update
     */
    public ItemRevision getRevision() {
        return revisionToUpdate;
    }

    boolean isMerge() {
        return mergedFrom.length > 0;
    }

    @Override
    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            List<String> docList = getChangeRequests();
            String[] docs = docList.toArray(new String[docList.size()]);
            IFile file = getFile();
            String source = file.getLocation().toOSString();
            DimensionsResult result;
            String charset = DMTeamPlugin.getDefault().getCharset(file);
            if (isMerge()) {
                List<String> revisionsToMerge = new ArrayList<String>(Arrays.asList(mergedFrom));
                result = revisionToUpdate.mergeItemRevisions(revisionsToMerge, null, source, getComment(), docList, true, charset);
            } else {
                getNewRevisionDetails().setExpand(Boolean.valueOf(TeamUtils.isExpandSubstitution()));
                result = revisionToUpdate.revise(source, getComment(), true, force, null, docs, getNewRevisionDetails(), charset);
            }
            TeamUtils.setReadOnly(file, isReadOnly());
            return result;
        } finally {
            monitor.done();
        }
    }

    @Override
    protected String getMessage() {
        if (isMerge()) {
            return NLS.bind(Messages.UpdateRevisionRequest_mergeMessage, getResourceMessage());
        }
        return super.getMessage();
    }

}

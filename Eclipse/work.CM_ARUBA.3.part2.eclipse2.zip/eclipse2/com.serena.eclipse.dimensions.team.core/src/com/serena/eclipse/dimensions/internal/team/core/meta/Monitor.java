/*
 * Copyright 2002 SERENA Software, Inc. All Rights Reserved.
 * This software is proprietary information of SERENA Software, Inc.
 * Use is subject to license terms.
 */
package com.serena.eclipse.dimensions.internal.team.core.meta;

import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/**
 * This monitor is intended to be used when there is a need to synchronize
 * threads on a shared resource with multiple views. An example of such
 * resource is a physical file and its multiple views are instances of <code>java.io.File</code>. If the following fragment is run
 * thread t2
 * waits for t1 to complete before sending "t2" to stdout even though the
 * monitor is requested for different instances of <code>java.io.File</code>.
 *
 * <pre>
 * final Monitor m = new Monitor();
 * final java.io.File file1 = new java.io.File(&quot;/file.txt&quot;);
 * final java.io.File file2 = new java.io.File(&quot;/file.txt&quot;);
 * Thread t1 = new Thread() {
 *     public void run() {
 *         synchronized (m.get(file1)) {
 *             try {
 *                 Thread.sleep(5000);
 *             } catch (InterruptedException e) {
 *             }
 *             System.out.println(&quot;t1&quot;);
 *         }
 *     }
 * };
 * Thread t2 = new Thread() {
 *     public void run() {
 *         synchronized (m.get(file2)) {
 *             System.out.println(&quot;t2&quot;);
 *         }
 *     }
 * };
 * t1.start();
 * t2.start();
 * 
 * <pre>
 *
 * @author      V.Grishchenko
 */
/* public */class Monitor {
    private WeakHashMap map = new WeakHashMap() {
        @Override
        public final Object get(Object key) {
            Object ref = super.get(key);
            Object monitor = ((ref == null) ? null : ((WeakReference) ref).get());
            if (monitor == null) {
                monitor = key;
                put(monitor, new WeakReference(monitor));
            }
            return monitor;
        }
    };

    public synchronized Object get(Object key) {
        return map.get(key);
    }

}

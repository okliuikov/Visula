/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Comparator;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;

/**
 * Compares resources or paths based on their mutual containment.
 *
 * @author V.Grishchenko
 */
public class ContainmentComparator implements Comparator<Object> {
    private boolean reverse;

    /**
     * Creates a direct comparator, resources contained deeper in the
     * workspace are considered to be greater than the ones above them.
     */
    public ContainmentComparator() {
    }

    /**
     * Creates a comparator that can do forward and reverse comparison
     * according to the value passed. Reverse comparator will consider
     * resources/paths that are closer to workspace root to be greater
     * than the ones that are deeper down in the hierarchy.
     */
    public ContainmentComparator(boolean reverse) {
        this.reverse = reverse;
    }

    /**
     * @return when direct:
     *
     * <br>
     *         a) 0 is returned if both resources/paths are the same <br>
     *         b) -1 is returned when the first resources/path logically contains the second
     *         at some level in the hierarchy <br>
     *         c) 1 is returned when the second resource/path logically contains the first
     *         at some level in the hierarchy <br>
     *         d) if resources/paths are not related by containment returns the result
     *         of a lexicographical comparison of their paths to ensure symmetry
     *
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    @Override
    public int compare(Object o1, Object o2) {
        IPath path1 = o1 instanceof IPath ? (IPath) o1 : ((IResource) o1).getFullPath();
        IPath path2 = o2 instanceof IPath ? (IPath) o2 : ((IResource) o2).getFullPath();
        if (path1.equals(path2)) {
            return 0;
        }
        int result = 0;
        if (path1.isPrefixOf(path2)) {
            result = -1;
        } else if (path2.isPrefixOf(path1)) {
            result = 1;
        } else {
            // if we got here resources are not related in a
            // ancestor/descendant sense, compare paths lexicographically
            // to ensure symmetry
            result = path1.toString().compareTo(path2.toString());
        }
        if (reverse) {
            result = -result;
        }
        return result;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.runtime.CoreException;

/**
 * Request to delete a folder.
 *
 * @author V.Grishchenko
 */
public class DeleteFolderRequest extends FolderRequest {

    /**
     * @param folder
     * @param requestSupported
     * @param requestRequired
     * @throws CoreException
     */
    public DeleteFolderRequest(IContainer folder, boolean requestRequired) throws CoreException {
        super(folder, true, requestRequired);
    }

    @Override
    public int getKind() {
        int kind = DELETE;
        try {
            if (DMTeamPlugin.getWorkspace().isMoved(getResource())) {
                kind |= MOVE;
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
        return kind;
    }

}

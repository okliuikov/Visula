/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.team.core.TeamException;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public class StatusFilter implements IDMWorkspaceResourceFilter {
    /** all bits must match */
    public static final int AND = 1;
    /** any bits may match */
    public static final int OR = 2;

    private int mask;
    private int type;

    public StatusFilter(int mask, int type) {
        Assert.isLegal(type == AND || type == OR);
        this.mask = mask;
        this.type = type;
    }

    @Override
    public boolean select(IDMWorkspaceResource resource) throws TeamException {
        if (type == AND) {
            return resource.getStatus().matchAll(mask);
        }
        return resource.getStatus().matchAny(mask);
    }

}

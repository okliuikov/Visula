/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;

/**
 * Resource that belongs to a project shared via Dimensions.
 *
 * @author V.Grishchenko
 */
public interface IDMResource extends IAdaptable {

    /**
     * @return project that this resource is shared with
     */
    IDMProject getProject();

    /**
     * Set the project for this resource
     */
    void setProject(IDMProject project);

    /**
     * @return resource name
     */
    String getName();

    /**
     * @return corresponding local resource
     */
    IResource getLocalResource();

    /**
     * @return <code>true</code> if this resource is a folder, returns <code>false</code> otherewise
     */
    boolean isContainer();

    void accept(IDMResourceVisitor visitor) throws CoreException;

    void delete(IProgressMonitor monitor) throws CoreException;

    boolean exists();

}

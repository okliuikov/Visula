/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Arrays;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Describes a merge or compare between local and remote resources. Implements <code>equals</code> and <code>hashCode</code>.
 * @author V.Grishchenko
 */
public class ProjectMergeDescriptor {
    private IProject local;
    private IDMProject ancestor;
    private IDMProject remote;
    private IResource[] roots;

    /**
     * Creates a new compare descriptor.
     *
     * @param local local part of compare
     * @param roots root resources for compare
     * @param remote remote part of compare
     */
    public ProjectMergeDescriptor(IProject local, IResource[] roots, IDMProject remote) {
        this(local, roots, null, remote);
    }

    /**
     * Creates a new merge descriptor.
     *
     * @param local local merge target
     * @param roots root resources for merge
     * @param ancestor common ancestor (a baseline)
     * @param remote remote merge source
     */
    public ProjectMergeDescriptor(IProject local, IResource[] roots, IDMProject ancestor, IDMProject remote) {
        Assert.isLegal(local != null && roots != null && /* ancestor != null && */remote != null);
        this.local = local;
        this.roots = roots;
        this.ancestor = ancestor;
        this.remote = remote;
    }

    /**
     * @return local project for compare or merge
     */
    public IProject getLocal() {
        return local;
    }

    /**
     * @return remote project for compare or merge
     */
    public IDMProject getRemote() {
        return remote;
    }

    /**
     * @return merge common ancestor or <code>null</code> for compare
     */
    public IDMProject getAncestor() {
        return ancestor;
    }

    /**
     * @return root compare resources
     */
    public IResource[] getRoots() {
        return roots;
    }

    /**
     * @return <code>true</code> if this descriptor is for a 3-way compare such as merge
     */
    public boolean isThreeWay() {
        return getAncestor() != null;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof ProjectMergeDescriptor) {
            ProjectMergeDescriptor otherDesc = (ProjectMergeDescriptor) obj;
            if (local.equals(otherDesc.local) && remote.equals(otherDesc.remote)
                    && (ancestor == null ? otherDesc.ancestor == null : ancestor.equals(otherDesc.ancestor)) // ancestor may be null
                                                                                                             // for compare
                    && roots.length == otherDesc.roots.length) {
                IResource[] _roots = roots.clone();
                IResource[] _otherRoots = otherDesc.roots.clone();
                Arrays.sort(_roots, TeamUtils.resourceComparator);
                Arrays.sort(_otherRoots, TeamUtils.resourceComparator);
                return Arrays.equals(_roots, _otherRoots);
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hashCode = local.hashCode() ^ remote.hashCode();
        if (ancestor != null) {
            hashCode ^= ancestor.hashCode();
        }
        for (int i = 0; i < roots.length; i++) {
            hashCode ^= roots[i].hashCode();
        }
        return hashCode;
    }

}

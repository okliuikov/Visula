/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.ResourceVariantByteStore;

/**
 * Ignores deletion requests per <code>ResourceVariantByteStore</code> contract
 * unless the resource is marked for deletion via <code>prepareForDeletion</code>.
 *
 * @author V.Grishchenko
 */
class ProtectedResourceVariantByteStore extends ResourceVariantByteStore {
    // use 1 byte as persistent store intrenally uses zero-length array to mark non-existent variant
    private static final byte[] DELETION_MARK = new byte[] { 0 };
    private ResourceVariantByteStore store, markers;

    /**
     * @param store underlying byte storage
     * @param markers deletion mark storage
     */
    public ProtectedResourceVariantByteStore(ResourceVariantByteStore store, ResourceVariantByteStore markers) {
        this.store = store;
        this.markers = markers;
    }

    @Override
    public void dispose() {
        store.dispose();
        markers.dispose();
    }

    @Override
    public byte[] getBytes(IResource resource) throws TeamException {
        return store.getBytes(resource);
    }

    @Override
    public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
        boolean result = store.setBytes(resource, bytes);
        markers.deleteBytes(resource);
        return result;
    }

    public boolean flushBytes(IResource resource, int depth, boolean force) throws TeamException {
        if (force || markers.getBytes(resource) != null) {
            markers.flushBytes(resource, depth);
            return store.flushBytes(resource, depth);
        }
        return false;
    }

    @Override
    public boolean flushBytes(IResource resource, int depth) throws TeamException {
        return flushBytes(resource, depth, false);
    }

    public void prepareForDeletion(IResource resource) throws TeamException {
        markers.setBytes(resource, DELETION_MARK);
    }

    public boolean deleteBytes(IResource resource, boolean force) throws TeamException {
        if (force || markers.getBytes(resource) != null) {
            markers.flushBytes(resource, IResource.DEPTH_ZERO);
            return store.deleteBytes(resource);
        }
        return false;
    }

    @Override
    public boolean deleteBytes(IResource resource) throws TeamException {
        return deleteBytes(resource, false);
    }

    @Override
    public IResource[] members(IResource resource) throws TeamException {
        return store.members(resource);
    }

}

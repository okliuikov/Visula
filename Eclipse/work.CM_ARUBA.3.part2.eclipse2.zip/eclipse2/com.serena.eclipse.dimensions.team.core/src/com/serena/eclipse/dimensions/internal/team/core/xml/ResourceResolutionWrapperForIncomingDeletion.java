package com.serena.eclipse.dimensions.internal.team.core.xml;

import org.eclipse.core.resources.IResource;

class ResourceResolutionWrapperForIncomingDeletion implements IResourceResolutionWrapper {
    private IResource wrappedResource;

    public ResourceResolutionWrapperForIncomingDeletion(IResource resource) {
        wrappedResource = resource;
    }

    public IResource getResource() {
        return wrappedResource;
    }

    public boolean isIncomingDeletion() {
        return true;
    }
}

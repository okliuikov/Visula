package com.serena.eclipse.dimensions.internal.team.core.xml;

import org.eclipse.core.resources.IResource;
import org.eclipse.team.core.synchronize.SyncInfo;

class SyncInfoResourceResolutionWrapper implements IResourceResolutionWrapper {
    private XMLSyncInfo info;

    public SyncInfoResourceResolutionWrapper(XMLSyncInfo info) {
        this.info = info;
    }

    public IResource getResource() {
        return info.getLocalResource();
    }

    public boolean isIncomingDeletion() {
        return (info.getKind() & SyncInfo.DIRECTION_MASK) == SyncInfo.INCOMING
                && (info.getKind() & SyncInfo.CHANGE_MASK) == SyncInfo.DELETION;
    }
}

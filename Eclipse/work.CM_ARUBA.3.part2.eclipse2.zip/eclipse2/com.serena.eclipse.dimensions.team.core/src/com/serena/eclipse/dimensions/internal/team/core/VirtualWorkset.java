package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IProject;

/**
 * Implementation of virtual project for case when it is mapped for a workset. Most of methods are unsupported
 */
public class VirtualWorkset extends VirtualDmProject {

    public VirtualWorkset(WorksetProject parent, IProject project) {
        super(parent, project);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.eclipse.dimensions.core.Session;

/**
 * @author V.Grishchenko
 */
public class FolderRequest extends WorkspaceResourceRequest {

    /**
     * @param resource
     * @throws CoreException
     */
    public FolderRequest(IContainer folder) throws CoreException {
        super(folder);
    }

    public FolderRequest(IContainer folder, boolean requestSupported, boolean requestRequired/* , int kind */) throws CoreException {
        super(folder, requestSupported, requestRequired);
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        return new DimensionsResult("ok"); //$NON-NLS-1$
    }

    @Override
    public int getKind() {
        return UNKNOWN;
    }

}

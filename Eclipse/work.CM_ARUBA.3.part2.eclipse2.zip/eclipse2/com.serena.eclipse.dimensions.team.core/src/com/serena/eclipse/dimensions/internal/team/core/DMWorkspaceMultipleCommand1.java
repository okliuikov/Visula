package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.team.core.TeamException;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Workspace command which supports multiple projects.
 */
public abstract class DMWorkspaceMultipleCommand1 extends DMWorkspaceBaseCommand1 {
    private CollectFilesStatsCallback fileStats = new CollectFilesStatsCallback();

    private IResource[] toRefresh;

    private SortedSet<IResource> rawToRefresh;
    private SortedSet<IResource> rawRules;

    private Map<IDMProject, WorkspaceResourceRequest[]> dataMap;

    DMWorkspaceMultipleCommand1(Map<IDMProject, WorkspaceResourceRequest[]> dataMap) {
        Assert.isNotNull(dataMap);
        this.dataMap = dataMap;
        init();
    }

    private void init() {
        this.rawRules = new TreeSet<IResource>(new ContainmentComparator());
        this.rawToRefresh = new TreeSet<IResource>(new ContainmentComparator());

        for (Map.Entry<IDMProject, WorkspaceResourceRequest[]> entry : dataMap.entrySet()) {
            WorkspaceResourceRequest[] requests = entry.getValue();
            for (int i = 0; i < requests.length; i++) {
                // init scheduling rule
                addSchedulingRule(rawRules, requests[i]);

                // add resource to raw refresh list
                addResourceToRefresh(rawToRefresh, requests[i]);
            }
        }
    }

    /**
     * Creates rules from change request and add them to rules collection. Clients can override this
     * method to customize rule creation.
     *
     * @param rules
     *            cache of rules that were produced from change requests
     * @param request
     *            change request that is a source for new rule
     */
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        IResource resource = request.getResource();
        IResource ruleCandidate = TeamUtils.parent(resource);
        try {
            rules.add(TeamUtils.findDeepestManagedResource(ruleCandidate));
        } catch (TeamException e) {
            rules.add(ruleCandidate);
            DMTeamPlugin.log(e.getStatus());
        }
    }

    /**
     * Find a resource candidate that will be refreshed after command execution. It's a resource
     * itself or highest unmanaged parent resource.
     *
     * @param toRefresh
     *            cache of resources that were produced from change requests
     * @param request
     *            change request
     * @throws TeamException
     */
    protected void addResourceToRefresh(SortedSet<IResource> toRefresh, WorkspaceResourceRequest request) {
        IResource resource = request.getResource();
        IResource parent = resource;

        try {
            while ((parent = TeamUtils.parent(parent)) != resource) {
                if (parent.getType() == IResource.ROOT || parent.getType() == IResource.PROJECT) {
                    toRefresh.add(resource);
                    return;
                }

                if (DMTeamPlugin.getWorkspace().isManaged(parent)) {
                    toRefresh.add(resource);
                    return;
                }

                resource = parent;
            }
        } catch (TeamException e) {
            toRefresh.add(resource);
            DMTeamPlugin.log(e.getStatus());
        }
    }

    @Override
    public ISchedulingRule getSchedulingRule() throws CoreException {
        Assert.isNotNull(rawRules);
        return new MultiRule(TeamUtils.getNonOverlapping(rawRules));
    }

    @Override
    public IResource[] getBaseResourcesToRefresh() throws CoreException {
        Assert.isNotNull(rawToRefresh);
        if (toRefresh == null) {
            this.toRefresh = TeamUtils.getNonOverlappingWithStats(rawToRefresh, fileStats);

            // to many single files
            if (fileStats.isStatsLimitReached()) {
                List<IResource> refreshList = new ArrayList<IResource>();
                for (IDMProject project : dataMap.keySet()) {
                    refreshList.add(project.getRoot());
                }

                this.toRefresh = refreshList.toArray(new IResource[refreshList.size()]);
            }
        }
        return toRefresh;
    }

    @Override
    public IResource[] getResourcesToRefresh() throws CoreException {
        Assert.isNotNull(rawToRefresh);
        if (toRefresh == null) {
            this.toRefresh = TeamUtils.getNonOverlappingWithStats(rawToRefresh, fileStats);

            // to many single files
            if (fileStats.isStatsLimitReached()) {
                List<IResource> refreshList = new ArrayList<IResource>();
                for (IDMProject project : dataMap.keySet()) {
                    refreshList.add(project.getRoot());
                }

                this.toRefresh = refreshList.toArray(new IResource[refreshList.size()]);
            }

        }
        return toRefresh;
    }

    @Override
    public boolean isValidSharing() throws CoreException {
        for (IDMProject dmProject : dataMap.keySet()) {
            if (!dmProject.equals(getWorkspace().getProject(dmProject.getProject()))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean modifiesBase() {
        for (WorkspaceResourceRequest[] requests : dataMap.values()) {
            for (int i = 0; i < requests.length; i++) {
                if (requests[i].modifiesMetadata()) {
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public boolean modifiesRemote() {
        return false;
    }

}

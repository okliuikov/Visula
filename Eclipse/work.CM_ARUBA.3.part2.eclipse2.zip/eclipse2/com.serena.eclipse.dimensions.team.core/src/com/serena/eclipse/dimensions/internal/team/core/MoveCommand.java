/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.jobs.ILock;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;

import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
class MoveCommand extends DMWorkspaceCommand1 { 
    private String currentDefault;
    private Map<String, List<MoveRequest>> crossProjectMoves = new HashMap<String, List<MoveRequest>>(); // src project ->
                                                                                                         // {MoveRequest}
    private ILock changeDefaultLock;

    // local projects participating in move operation
    private Set<IProject> participatingProjects = new HashSet<IProject>();
    // folders to be created during move
    private TreeSet<IContainer> folderCreates = new TreeSet<IContainer>(new ContainmentComparator());
    // folders to be deleted during move
    private TreeSet<IContainer> folderDeletes = new TreeSet<IContainer>(new ContainmentComparator(true));

    private HashMap<IResource, String[]> dstRequests = new HashMap<IResource, String[]>();
    private HashMap<IResource, String[]> srcRequests = new HashMap<IResource, String[]>();

    public MoveCommand(DMProject dmProject, MoveRequest[] requests) {
        super(dmProject, requests);
        changeDefaultLock = dmProject.getConnection().getChangeDefaultProjectLock();
    }

    MoveRequest[] getNonOverlapping() {
        IResource[] resources = new IResource[requests.length];
        HashMap<IResource, WorkspaceResourceRequest> lookup = new HashMap<IResource, WorkspaceResourceRequest>();
        for (int i = 0; i < requests.length; i++) {
            resources[i] = requests[i].getResource();
            lookup.put(resources[i], requests[i]);
        }
        resources = TeamUtils.getNonOverlapping(resources);
        MoveRequest[] result = new MoveRequest[resources.length];
        for (int i = 0; i < resources.length; i++) {
            result[i] = (MoveRequest) lookup.get(resources[i]);
        }
        return result;
    }

    void cacheChangeRequests() {
        for (int i = 0; i < requests.length; i++) {
            MoveRequest moveRequest = (MoveRequest) requests[i];
            List<String> mvChgRequests = moveRequest.getChangeRequests();
            if (!mvChgRequests.isEmpty()) {
                dstRequests.put(moveRequest.getResource(), mvChgRequests.toArray(new String[mvChgRequests.size()]));
            }
            mvChgRequests = moveRequest.getSourceRequests();
            if (!mvChgRequests.isEmpty()) {
                srcRequests.put(moveRequest.getResource(), mvChgRequests.toArray(new String[mvChgRequests.size()]));
            }
        }
    }

    String[] getChangeRequests(IResource resource, boolean source) {
        if (resource == null) {
            return null;
        }
        Map<IResource, String[]> lookup = source ? srcRequests : dstRequests;
        String[] result = lookup.get(resource);
        if (result != null) {
            return result;
        }
        return getChangeRequests(resource.getParent(), source);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        participatingProjects.add(dmProject.getProject()); // always include destination project in refresh
        try {
            cacheChangeRequests();
            MoveRequest[] moveRequests = getNonOverlapping();
            List<MoveRequest> requestsToProcess = collectMoveRequests(moveRequests); // all requests that should be processed by
                                                                                     // this command

            // separate all requests that we will be processing into same project moves
            // and cross project moves as cross project ones will likely require default project changes
            ArrayList<MoveRequest> sameProject = new ArrayList<MoveRequest>();
            for (Iterator<MoveRequest> iter = requestsToProcess.iterator(); iter.hasNext();) {
                MoveRequest request = iter.next();
                if (request.isCrossProject()) {
                    IDMProject srcProject = request.getSourceProject();
                    String key = srcProject.isWorkset() ? srcProject.getId() : IDMConstants.GLOBAL_WORKSET;
                    List<MoveRequest> list = crossProjectMoves.get(key);
                    if (list == null) {
                        list = new ArrayList<MoveRequest>();
                        crossProjectMoves.put(key, list);
                    }
                    list.add(request);
                } else {
                    sameProject.add(request);
                }
            }

            monitor.beginTask(null, 1000);

            // create destination parents, if any
            createFolders(folderCreates, Utils.subMonitorFor(monitor, 150));
            IResource[] resourcesToRefresh = getResourcesToRefresh(moveRequests);
            // process same project moves first
            IProgressMonitor requestMonitor = Utils.subMonitorFor(monitor, 500);
            // total # of requests is what we have for same and cross project moves
            requestMonitor.beginTask(null, requestsToProcess.size() * 10);
            for (Iterator<MoveRequest> requestIter = sameProject.iterator(); requestIter.hasNext();) {
                MoveRequest request = requestIter.next();
                request.process(Utils.subMonitorFor(requestMonitor, 10));
                IResource resource = request.getResource();
                getWorkspace().unregisterMove(resource);
                if (resource instanceof IContainer) {
                    IContainer container = (IContainer) request.getResource();
                    cleanDMWorkspaceMoveCache(container);
                }
            }

            // if any, process cross project moves second setting default project as needed
            if (!crossProjectMoves.isEmpty()) {
                changeDefaultLock.acquire();
                // DMPROD_EC_607: use $G:$G as MoveRequest removes from src project first now
                setCurrentProject(IDMConstants.GLOBAL_WORKSET);
                for (Iterator<Entry<String, List<MoveRequest>>> entryIter = crossProjectMoves.entrySet().iterator(); entryIter.hasNext();) {
                    Entry<String, List<MoveRequest>> entry = entryIter.next();
                    List<MoveRequest> cpReqs = entry.getValue();
                    for (Iterator<MoveRequest> crossReqIter = cpReqs.iterator(); crossReqIter.hasNext();) {
                        MoveRequest crossPrjMoveReq = crossReqIter.next();
                        crossPrjMoveReq.process(Utils.subMonitorFor(requestMonitor, 10));
                    }
                }
            }
            requestMonitor.done(); // 650 done

            getWorkspace().refresh(resourcesToRefresh, IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, 200));

            // delete any folders moved by creation
            cleanupMovedFolders(folderDeletes, Utils.subMonitorFor(monitor, 100)); // 950 done

            // ensure no stale move state is left over
            discardMoveState(folderCreates);
        } finally {
            if (!crossProjectMoves.isEmpty()) {
                changeDefaultLock.release();
            }
            monitor.done();
        }
    }

    private void cleanDMWorkspaceMoveCache(IContainer resource) throws CoreException {
        DMWorkspace workspace = getWorkspace();
        IResource[] members = resource.members();
        for (int i = 0; i < members.length; i++) {
            workspace.unregisterMove(members[i]);
            if (members[i] instanceof IContainer) {
                cleanDMWorkspaceMoveCache((IContainer) members[i]);
            }
        }
    }

    private void discardMoveState(Collection<IContainer> toDiscard) throws CoreException {
        for (Iterator<IContainer> iterator = toDiscard.iterator(); iterator.hasNext();) {
            IResource res = iterator.next();
            MoveRequest.discardMoveState(res);
            getWorkspace().unregisterMove(res);
        }
    }

    private void setCurrentProject(final String project) throws DMException {
        if (currentDefault != null && currentDefault.equalsIgnoreCase(project)) {
            return; // nothing to do
        }
        final Session session = dmProject.getConnection().openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                DimensionsObjectFactory factory = session.getObjectFactory();
                factory.setCurrentProject(project, false, null, null, null, true);
                currentDefault = project;
            }
        }, new NullProgressMonitor());
    }

    // finds a safe way to move what's requested
    private List<MoveRequest> collectMoveRequests(MoveRequest[] moveRequests) throws CoreException {
        ArrayList<MoveRequest> requestsToProcess = new ArrayList<MoveRequest>();
        for (int i = 0; i < moveRequests.length; i++) {
            MoveRequest moveRequest = moveRequests[i];
            if (!moveRequest.isCrossProject() && moveRequest.getResource().getType() != IResource.FILE) {
                IResource src = getWorkspace().getMovedFrom(moveRequest.getResource());
                assert src != null;
                if (moveRequest.getResource().getType() == IResource.PROJECT) {
                    requestsToProcess.add(moveRequest); // don't need to include src project there
                    continue;
                    // TODO KB>create move requests for renamed child resources
                } else if (isFolderMoveOk(moveRequest.getResource(), src)) {
                    requestsToProcess.add(moveRequest);
                    participatingProjects.add(src.getProject());
                    continue;
                }
            }
            collectFileMoves(moveRequest, requestsToProcess);
        }
        return requestsToProcess;
    }

    // checks if remote source is consistent with local destination, also checks if remote destinatino does not exist
    private boolean isFolderMoveOk(IResource lclDstRoot, IResource lclSrcRoot) throws CoreException {
        IDMRemoteResource rmtDst = getWorkspace().getRemoteResource(lclDstRoot);
        IDMRemoteResource rmtSrc = getWorkspace().getRemoteResource(lclSrcRoot);

        if (rmtDst != null || rmtSrc == null) {
            return false; // cannot move if destination exists or move source is missing
        }

        if (lclDstRoot.getType() != IResource.FILE) {
            IResource[] lclDstMembers = ((IContainer) lclDstRoot).members();
            IResource[] lclSrcMembers = DMTeamPlugin.getWorkspace().getSubscriber().members(lclSrcRoot);
            // only interested in ones with remote
            ArrayList<IResource> list = new ArrayList<IResource>();
            for (int i = 0; i < lclSrcMembers.length; i++) {
                if (DMTeamPlugin.getWorkspace().hasRemote(lclSrcMembers[i])) {
                    list.add(lclSrcMembers[i]);
                }
            }
            lclSrcMembers = list.toArray(new IResource[list.size()]);

            Set<String> all = new HashSet<String>();
            Map<String, IResource> lclDstSet = new HashMap<String, IResource>();
            Map<String, IResource> lclSrcSet = new HashMap<String, IResource>();

            for (int i = 0; i < lclDstMembers.length; i++) {
                all.add(lclDstMembers[i].getName());
                lclDstSet.put(lclDstMembers[i].getName(), lclDstMembers[i]);
            }

            for (int i = 0; i < lclSrcMembers.length; i++) {
                all.add(lclSrcMembers[i].getName());
                lclSrcSet.put(lclSrcMembers[i].getName(), lclSrcMembers[i]);
            }

            for (Iterator<String> iter = all.iterator(); iter.hasNext();) {
                String key = iter.next();
                IResource lclDstMember = lclDstSet.get(key);
                IResource lclSrcMember = lclSrcSet.get(key);
                if (lclDstMember == null || lclSrcMember == null) {
                    return false; // something's fishy if source or destination don't match, safer to move file by file
                }
                if (!isFolderMoveOk(lclDstMember, lclSrcMember)) {
                    return false;
                }
            }
        }
        return true;
    }

    // collects/creates file move requests
    private void collectFileMoves(MoveRequest request, Collection<MoveRequest> fileMoves) throws CoreException {
        IResource lclDst = request.getDestination();
        IResource lclSrc = request.getSource();
        if (lclDst.getType() == IResource.FILE) {
            if (lclSrc != null) {
                participatingProjects.add(lclSrc.getProject());
                IDMRemoteResource rmtDst = getWorkspace().getRemoteResource(lclDst);
                IDMRemoteResource rmtSrc = getWorkspace().getRemoteResource(lclSrc);

                if (rmtDst != null) {
                    addError(DMTeamStatus.createErrorStatus(0,
                            NLS.bind(Messages.MoveCommand_remoteExists, lclDst.getFullPath().toOSString())));
                } else if (rmtSrc == null) {
                    addError(DMTeamStatus.createErrorStatus(0,
                            NLS.bind(Messages.MoveCommand_noRemote, lclSrc.getFullPath().toOSString())));
                } else {
                    addMissingParents(lclDst.getParent());
                    fileMoves.add(request);
                }
            }
            return;
        }

        addMissingParents((IContainer) lclDst); // this takes care of empty folder moves
        IResource[] members = ((IContainer) lclDst).members();
        for (int i = 0; i < members.length; i++) {
            MoveRequest subRequest = new MoveRequest(members[i]);
            subRequest.setUnmanage(request.isUnmanage());
            subRequest.setChangeRequests(request.getChangeRequests());
            subRequest.setSourceRequests(request.getSourceRequests());
            collectFileMoves(subRequest, fileMoves);
        }
    }

    private void createFolders(Collection<IContainer> folders, IProgressMonitor monitor) throws DMException, CoreException {
        try {
            monitor.beginTask(null, folders.size());
            for (Iterator<IContainer> fldCreateIterator = folders.iterator(); fldCreateIterator.hasNext();) {
                final IContainer lcl = fldCreateIterator.next();
                IPath rmtPath = dmProject.getRemotePathForLocalResource(lcl);
                IContainer lclParent = lcl.getParent();
                IPath rmtParentPath = dmProject.getRemotePathForLocalResource(lclParent);
                final RepositoryFolder rmtParent = dmProject.getRepositoryFolderProxy(rmtParentPath);
                String msg = NLS.bind(Messages.MoveCommand_createRemoteFolder, TeamUtils.getFolderFullPath(rmtPath));
                monitor.subTask(msg);
                dmProject.getConnection().openSession(null).run(new APIOperation(msg) {
                    @Override
                    protected DimensionsResult doRun() throws Exception {
                        RepositoryFolder result = rmtParent.addChildFolder(lcl.getName(), getChangeRequests(lcl, false));
                        MetadataHelper.writeMetadataForContainer(lcl);
                        return new DimensionsResult(NLS.bind(Messages.MoveCommand_createdRemoteFolder,
                                result.getAttribute(SystemAttributes.OBJECT_SPEC)));
                    }
                }, monitor);
                TeamUtils.ensureReacheable(lcl, false);
                monitor.worked(1);
            }
        } finally {
            monitor.done();
        }
    }

    private void cleanupMovedFolders(Collection<IContainer> folders, IProgressMonitor monitor) throws CoreException, TeamException,
            DMException {
        monitor.beginTask(null, folders.size());
        try {
            if (folders.isEmpty()) {
                return;
            }
            for (Iterator<IContainer> fldCreateIterator = folders.iterator(); fldCreateIterator.hasNext();) {
                final IContainer lcl = fldCreateIterator.next();
                if (!getWorkspace().hasRemote(lcl)) {
                    treeMoved(lcl);
                    continue;
                }
                // may be different from command's project if cross-project move
                final IDMProject srcProject = getWorkspace().getProject(lcl);
                assert srcProject != null;
                final IPath rmtSrcPath = srcProject.getRemotePathForLocalResource(lcl);
                final RepositoryFolder rmtSrc = srcProject.getRepositoryFolderProxy(rmtSrcPath);
                String msg = NLS.bind(Messages.MoveCommand_attemptDeleteRemoteFolder, TeamUtils.getFolderFullPath(rmtSrcPath));
                monitor.subTask(msg);
                srcProject.getConnection().openSession(null).run(new APIOperation(msg) {

                    @SuppressWarnings("unchecked")
                    @Override
                    protected DimensionsResult doRun() throws Exception {
                        DMPlugin.getDefault().getConsole().printMessage(Messages.MoveCommand_checkFolderEmpty);
                        List<?> childFolders = rmtSrc.getImmediateChildFolders();
                        if (childFolders.isEmpty()) {
                            rmtSrc.flushRelatedObjects(ItemRevision.class, true);
                            Filter filter = new Filter();
                            filter.criteria().add(DMProject.LATEST_CRITERION); // insist on file-version based query
                            List<?> childRevs = rmtSrc.getLatestItemRevisions(filter);
                            rmtSrc.flushRelatedObjects(ItemRevision.class, true);
                            if (childRevs.isEmpty()) {
                                IContainer lclSrcParent = lcl.getParent();
                                IPath rmtSrcParentPath = srcProject.getRemotePathForLocalResource(lclSrcParent);
                                RepositoryFolder rmtParent = srcProject.getRepositoryFolderProxy(rmtSrcParentPath);
                                DMPlugin.getDefault().getConsole().printMessage(Messages.MoveCommand_folderIsEmpty);
                                DimensionsResult result = rmtParent.removeChildFolder(rmtSrc, getChangeRequests(lcl, true));
                                treeMoved(lcl);
                                return result;
                            }
                        }
                        return new DimensionsResult(NLS.bind(Messages.MoveCommand_didNotDelete,
                                TeamUtils.getFolderFullPath(rmtSrcPath)));
                    }

                }, monitor);
                monitor.worked(1);
            }
        } finally {
            monitor.done();
        }
    }

    private void addMissingParents(IContainer parent) throws CoreException {
        if (parent.getType() == IResource.PROJECT || parent.getType() == IResource.ROOT) {
            return;
        }
        if (!getWorkspace().hasRemote(parent)) {
            folderCreates.add(parent);
            IContainer source = (IContainer) getWorkspace().getMovedFrom(parent);
            if (source != null) {
                folderDeletes.add(source);
            }
            addMissingParents(parent.getParent());
        }
    }

    // root is the move source here
    private void treeMoved(IContainer root) throws CoreException {
        getWorkspace().releaseBase(root, true, IResource.DEPTH_INFINITE, null); // purge base info for the whole tree
    }

    // resources to refresh initially
    private IResource[] getResourcesToRefresh(MoveRequest[] _requests) throws CoreException {
        ArrayList<IResource> result = new ArrayList<IResource>();
        for (int i = 0; i < _requests.length; i++) {
            result.add(_requests[i].getDestination());
            IResource source = _requests[i].getSource();
            if (source.getType() == IResource.PROJECT && !source.exists()) {
                continue;
            } else {
                result.add(source);
            }
        }
        return result.toArray(new IResource[result.size()]);
    }

    /*
     * resources to refresh after this command finishes, can be smarter here but refresh all projects for now
     */
    @Override
    public IResource[] getResourcesToRefresh() {
        return participatingProjects.toArray(new IResource[participatingProjects.size()]);
    }

    @Override
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        try {
            if (request instanceof MoveRequest) {
                MoveRequest moveRequest = (MoveRequest) request;
                // combine parents of src and dst
                IResource[] resources = new IResource[] { moveRequest.getSource(), moveRequest.getDestination() };
                for (int j = 0; j < resources.length; j++) {
                    IResource parent = TeamUtils.parent(resources[j]);
                    while (parent.getType() != IResource.PROJECT && !parent.exists()) {
                        parent = parent.getParent();
                    }
                    rules.add(parent);
                }
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

}

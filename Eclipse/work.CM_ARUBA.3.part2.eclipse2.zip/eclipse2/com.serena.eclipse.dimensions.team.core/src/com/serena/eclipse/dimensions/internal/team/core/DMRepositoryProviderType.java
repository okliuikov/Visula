/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.ProjectSetCapability;
import org.eclipse.team.core.RepositoryProviderType;

import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class DMRepositoryProviderType extends RepositoryProviderType { 

    private static AutoShareJob autoShareJob;

    private static List<ConnectionProviderProxyAction> myProxies = null;

    @Override
    public ProjectSetCapability getProjectSetCapability() {
        return new DMProjectSetCapability();
    }

    @Override
    public void metaFilesDetected(IProject project, IContainer[] containers) {
        String providerMetadataDir = Utils.EMPTY_STRING;
        MetadataProvider mdp = MetadataProviderFactory.providerFor(project);
        try {
            providerMetadataDir = mdp.metadataDirname();

            boolean autoshare = false;
            IResource dmResource = project.findMember(providerMetadataDir);
            if (dmResource != null && dmResource.getType() != IResource.FILE) {
                autoshare = isAutoShare(project, mdp, (IContainer) dmResource);
            }

            if (!autoshare) {
                for (int i = 0; i < containers.length; i++) {
                    IContainer container = containers[i];
                    IContainer dmDir = null;
                    if (container.getName().equals(providerMetadataDir)) {
                        dmDir = container;
                    } else {
                        IResource resource = container.findMember(providerMetadataDir);
                        if (resource != null && resource.getType() != IResource.FILE) {
                            dmDir = (IContainer) resource;
                        }
                    }
                    autoshare = isAutoShare(project, mdp, dmDir);
                }
            }

            // need to poke the ui plugin to start it
            poke();
            // really only want to autoshare if a controlled .project
            if (autoshare && DMTeamPlugin.getDefault().isAutoshareOnImport()) {
                getAutoShareJob().share(project);
            }
        } finally {
            mdp.close();
        }
    }

    static DimensionsConnectionDetailsEx getConnectionFromList(DimensionsConnectionDetailsEx[] inp) {
        // short circuit

        if (inp.length == 1) {
            return inp[0];
        }
        if (!setupProxies()) {
            return null;
        }
        // get known connections
        return ((IDMConnectionProvider) myProxies.get(0)).getConnection(inp);
    }

    private static boolean setupProxies() {
        if (myProxies != null && myProxies.size() == 1) {
            // we are set up
            return true;
        }
        if (myProxies == null) {
            // haven't been through here
            myProxies = new ArrayList<ConnectionProviderProxyAction>();
            // use connectionProvider extension point to get the connection
            IExtensionRegistry er = Platform.getExtensionRegistry();
            IExtensionPoint ep = er.getExtensionPoint(DMTeamPlugin.ID, DMTeamPlugin.CONNECTION_PROVIDER_EP);
            IExtension[] extensions = ep.getExtensions();
            for (int i = 0; i < extensions.length; i++) {
                IConfigurationElement[] ces = extensions[i].getConfigurationElements();
                for (int j = 0; j < ces.length; j++) {
                    myProxies.add(new ConnectionProviderProxyAction(ces[j]));
                }
            }
        }

        if (myProxies.size() == 0) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.WARNING, Messages.ConnectionProvider_NoConnection));
            return false;
        }
        return true;
    }

    private static boolean poke() {
        if (!setupProxies()) {
            return false;
        }
        return ((IDMConnectionProvider) myProxies.get(0)).poke();
    }

    private synchronized static AutoShareJob getAutoShareJob() {
        if (autoShareJob == null) {
            autoShareJob = new AutoShareJob();
            autoShareJob.addJobChangeListener(new JobChangeAdapter() {
                @Override
                public void done(IJobChangeEvent event) {
                    // Reschedule the job if it has unprocessed projects
                    if (!autoShareJob.isQueueEmpty()) {
                        autoShareJob.schedule();
                    } else {
                        // clear connection as have finished sequence
                        AutoShareJob.setConnection(null);
                        if (autoShareJob.wereErrors()) {
                            Display.getDefault().syncExec(new Runnable() {
                                @Override
                                public void run() {
                                    MessageDialog.openError(null, Messages.Dialog_title, Messages.AutoShare_Were_Errors);
                                }
                            });
                            autoShareJob.clearErrors();
                        }
                    }

                }
            });

            autoShareJob.setSystem(false);
            autoShareJob.setPriority(Job.LONG);
            autoShareJob.setUser(false);
            // Must run with the workspace rule to ensure that projects added while we're running
            // can be shared
            autoShareJob.setRule(ResourcesPlugin.getWorkspace().getRoot());
        }
        return autoShareJob;
    }

    private boolean isAutoShare(IProject project, MetadataProvider mdp, IContainer dmDir) {
        boolean autoShare = false;
        if (dmDir != null && dmDir.getParent().equals(project)) {
            if (mdp.metadataExists(MetadataTypes.MT_ITEM,
                    project.getLocation().append(IProjectDescription.DESCRIPTION_FILE_NAME).toOSString())) {
                autoShare = true;
            } else if (mdp.metadataExists(MetadataTypes.MT_WORKAREACONFIG, project.getLocation().toOSString())) {
                autoShare = true;
            }
        }
        try {
            if (dmDir != null && !dmDir.isTeamPrivateMember()) {
                dmDir.setTeamPrivateMember(true);
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(Utils.createStatus(DMTeamPlugin.ID, IStatus.ERROR,
                    NLS.bind(Messages.MetaFilesDetected_TeamPrivate_Error, dmDir.getFullPath()), e));
        }
        return autoShare;
    }

}

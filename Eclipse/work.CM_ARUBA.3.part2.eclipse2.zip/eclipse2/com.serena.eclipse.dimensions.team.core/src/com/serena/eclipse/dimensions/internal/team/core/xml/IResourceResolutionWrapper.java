package com.serena.eclipse.dimensions.internal.team.core.xml;

import org.eclipse.core.resources.IResource;

interface IResourceResolutionWrapper {
    IResource getResource();

    boolean isIncomingDeletion();
}

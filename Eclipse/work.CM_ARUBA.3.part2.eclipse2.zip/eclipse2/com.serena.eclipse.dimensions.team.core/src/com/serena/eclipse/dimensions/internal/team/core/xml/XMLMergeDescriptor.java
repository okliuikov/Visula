/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.dmclient.api.MergeCommonCommandDetails;
import com.serena.dmclient.api.Request;
import com.serena.dmfile.sync.SyncMode;
import com.serena.dmfile.xml.DetectedResolutions;
import com.serena.dmfile.xml.DetectedResolutionsContainer;
import com.serena.dmfile.xml.ExecutedResolutions;
import com.serena.dmfile.xml.Resolution;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandOptions.MergeRequestsOptions;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandOptions.MergeWorksetOptions;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer.MergeType;

/**
 * Class that contains merge information about local project aka target
 */
public class XMLMergeDescriptor {
    private IDMProject target;
    private List<IResource> scope;
    private MergeDescriptorsContainer parentContainer;
    private SyncMode currentMode;
    private MergeCommonCommandDetails details;
    private Map<Resolution, XMLSyncInfo> resolutionToInfo;
    private Map<IResource, XMLSyncInfo> targetToInfo;
    private Map<IResource, XMLSyncInfo> localToInfo;
    private Map<XMLSyncInfo, IFileStore> infoToTempStore;
    private boolean stale = false;
    private boolean wasExecuted = false;

    private XMLMergeDescriptor() {
    }

    private XMLMergeDescriptor(IDMProject target, List<IResource> scope, MergeDescriptorsContainer parentContainer) {
        this.target = target;
        this.scope = scope;
        this.parentContainer = parentContainer;
        this.resolutionToInfo = new HashMap<Resolution, XMLSyncInfo>();
        this.targetToInfo = new HashMap<IResource, XMLSyncInfo>();
        this.localToInfo = new HashMap<IResource, XMLSyncInfo>();
        this.infoToTempStore = new HashMap<XMLSyncInfo, IFileStore>();
    }

    /**
     * @return current merge mode (detection, execution, non-interactive)
     */
    public SyncMode getCurrentMergeMode() {
        return currentMode;
    }

    /**
     * Change current merge mode (detection, execution, non-interactive)
     *
     * @param currentMode
     */
    public void setCurrentMode(SyncMode currentMode) {
        this.currentMode = currentMode;
        if (getCommandDetails() != null) {
            getCommandDetails().setMergeMode(currentMode);
        }
    }

    /**
     * @return local project which is a merge target
     */
    public IDMProject getTarget() {
        return target;
    }

    /**
     * @param target
     *            that is a local project
     */
    void setTarget(IDMProject target) {
        this.target = target;
    }

    /**
     * @return list of resources in the target project if was specified
     */
    public List<IResource> getScope() {
        return scope;
    }

    /**
     * @return true is descriptor has a resource scope
     */
    public boolean hasScope() {
        return getScope().size() > 0;
    }

    /**
     * @return parent container that contains all merge descriptors
     */
    public MergeDescriptorsContainer getDescriptorsContainer() {
        return parentContainer;
    }

    /**
     * @return merge details that is being used by API level
     */
    public MergeCommonCommandDetails getCommandDetails() {
        return details;
    }

    /**
     * @return detected resolutions container bean
     */
    public DetectedResolutionsContainer getDetectedResolutionsContainer() {
        MergeCommonCommandDetails commandDetails = getCommandDetails();
        if (commandDetails == null) {
            return null;
        }

        return commandDetails.getDetectedResolutionsContainer();
    }

    /**
     * @return detected resolutions bean
     */
    public DetectedResolutions getDetectedResolutions() {
        DetectedResolutionsContainer container = getDetectedResolutionsContainer();
        if (container == null) {
            return null;
        }

        return container.getDetectedResolutions();
    }

    public ExecutedResolutions getExecutedResolutions() {
        DetectedResolutionsContainer container = getDetectedResolutionsContainer();
        if (container == null) {
            return null;
        }

        return container.getExecutedResolutions();
    }

    /**
     * @param merge
     *            details that is being used by API level
     */
    void setCommandDetails(MergeCommonCommandDetails details) {
        this.details = details;
    }

    /**
     * @return current merge options
     */
    public MergeCommandOptions getMergeOptions() {
        return getDescriptorsContainer().getMergeOptions();
    }

    /**
     * @return current merge type (PROJECT, BASELINE, REQUEST)
     */
    public MergeType getMergeType() {
        return getDescriptorsContainer().getMergeType();
    }

    /**
     * @return spec of the workset which is a source of changes
     */
    public String getSourceWorksetSpec() {
        MergeCommandOptions opts = getMergeOptions();
        if (opts != null && opts.getSourceWorkset() != null) {
            return opts.getSourceWorkset().getObjectSpec();
        }
        return "";
    }

    /**
     * @return workset which is a source of changes
     */
    public VersionManagementProject getSourceWorkset() {
        MergeCommandOptions opts = getMergeOptions();
        if (opts != null) {
            return opts.getSourceWorkset();
        }
        return null;
    }

    /**
     * @return list of requests that are a source of changes. Can be empty
     */
    public List<Request> getSourceRequests() {
        MergeCommandOptions opts = getMergeOptions();
        if (opts instanceof MergeRequestsOptions) {
            MergeRequestsOptions wopts = (MergeRequestsOptions) opts;
            return wopts.getSourceRequests();
        }
        return null;
    }

    /**
     * @return true if descriptor does not have any changes
     */
    public boolean isInSync() {
        DetectedResolutions detected = getDetectedResolutions();
        if (detected == null) {
            return true;
        }
        if (detected.getResolutions() == null) {
            return true;
        }
        if (detected.getResolutions().size() != 0) {
            return false;
        }
        return true;
    }

    /**
     * Removes all information about changes from the descriptor
     */
    void markInSync() {
        DetectedResolutions detected = getDetectedResolutions();
        if (detected != null) {
            detected.setResolutions(null);
        }

        if (targetToInfo != null) {
            for (Entry<IResource, XMLSyncInfo> entry : targetToInfo.entrySet()) {
                entry.getValue().setDerivedKind(SyncInfo.IN_SYNC);
                try {
                    entry.getValue().init();
                } catch (TeamException e) {
                }
            }
        }
    }

    /**
     * @return temporary file store for sync info
     */
    public IFileStore getTempStore(XMLSyncInfo info) {
        return infoToTempStore.get(info);
    }

    /**
     * Cache temporary file store for sync info
     */
    public void addTempStore(XMLSyncInfo info, IFileStore store) {
        infoToTempStore.put(info, store);
    }

    /**
     * @return map between server resolutions and generated infos
     */
    public Map<Resolution, XMLSyncInfo> getResolutionToInfo() {
        return resolutionToInfo;
    }

    /**
     * @return map between local resource (may not exist) and generated infos
     */
    Map<IResource, XMLSyncInfo> getTargetToInfo() {
        return targetToInfo;
    }

    /**
     * @return map between local resources that exists and generated infos
     */
    Map<IResource, XMLSyncInfo> getLocalToInfo() {
        return localToInfo;
    }

    /**
     * @return map between generated infos and temporary files
     */
    Map<XMLSyncInfo, IFileStore> getInfoToStore() {
        return infoToTempStore;
    }

    /**
     * @return sync info using target resource from server resolutions
     */
    XMLSyncInfo getSyncInfoFromTarget(IResource resource) {
        return targetToInfo.get(resource);
    }

    /**
     * @return sync info using resource from local workspace
     */
    XMLSyncInfo getSyncInfoFromLocal(IResource resource) {
        return localToInfo.get(resource);
    }

    /**
     * @return if descriptor has STALE status
     */
    boolean isStale() {
        return stale;
    }

    /**
     * set STALE status to the descriptor
     */
    void markStale() {
        this.stale = true;
        for (XMLSyncInfo info : resolutionToInfo.values()) {
            info.markStale();
        }
    }

    public void markStale(XMLSyncInfo info) {
        this.stale = true;
        info.markStale();
    }

    /**
     * Removes information about file resolutions from descriptor
     */
    void dropXMLResolutions() {
        DetectedResolutions detectedResolutions = getDetectedResolutions();
        if (detectedResolutions != null) {
            detectedResolutions.setResolutions(null);
        }
    }

    /**
     * clear all related to descriptor sync info
     */
    void clearCachedInfo() {
        this.stale = false;
        this.wasExecuted = false;

        for (Resolution resolution : resolutionToInfo.keySet()) {
            String mrg = resolution.getMergedFile();
            String src = resolution.getSourceFile();
            String anc = resolution.getAncestorFile();

            if (mrg != null) {
                TeamUtils.deltree(new File(mrg).getParentFile());
            } else if (anc != null) {
                TeamUtils.deltree(new File(anc).getParentFile());
            } else if (src != null) {
                TeamUtils.deltree(new File(src).getParentFile());
            }
        }

        resolutionToInfo.clear();
        targetToInfo.clear();
        localToInfo.clear();

        for (IFileStore store : infoToTempStore.values()) {
            try {
                store.delete(EFS.NONE, new NullProgressMonitor());
            } catch (CoreException e) {
                DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, e.getMessage()));
            }
        }

        infoToTempStore.clear();
    }

    /***
     * clear all related to descriptor sync info that is in the input set
     * @param syncInfosToClear set of XMLSyncInfo that need to be used when clearing cached info
     */
    void clearCachedInfo(Set<XMLSyncInfo> syncInfosToClear) {
        this.stale = false;
        this.wasExecuted = false;

        DetectedResolutionsContainer container = this.details.getDetectedResolutionsContainer();
        if (container != null) {
            container.setExecutedResolutions(null);
        }
        DetectedResolutions detRess = this.details.getDetectedResolutions();
        boolean detRessCheck = detRess != null && detRess.getResolutions() != null;

        for (XMLSyncInfo syncInfoToClear : syncInfosToClear) {
            Resolution resolutionToClear = syncInfoToClear.getResolution();
            String mrg = resolutionToClear.getMergedFile();
            String src = resolutionToClear.getSourceFile();
            String anc = resolutionToClear.getAncestorFile();

            if (mrg != null) {
                TeamUtils.deltree(new File(mrg));
            } else if (anc != null) {
                TeamUtils.deltree(new File(anc));
            } else if (src != null) {
                TeamUtils.deltree(new File(src));
            }

            IResource localResource = syncInfoToClear.getLocalResource();
            IResource targetResource = syncInfoToClear.getLocal();

            resolutionToInfo.remove(resolutionToClear);
            targetToInfo.remove(targetResource);
            localToInfo.remove(localResource);

            IFileStore store = infoToTempStore.get(syncInfoToClear);
            if (store != null) {
                try {
                    store.delete(EFS.NONE, new NullProgressMonitor());
                } catch (CoreException e) {
                    DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, e.getMessage()));
                }
            }

            if (detRessCheck) {
                detRess.getResolutions().remove(syncInfoToClear.getResolution());
            }
        }
    }

    /**
     * @return true if any changes were applied to local target project
     */
    boolean hasAppliedChanges() {
        ExecutedResolutions executed = getExecutedResolutions();
        if (executed != null && executed.getActionMap() != null && executed.getActionMap().size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * @return true if processed by server in EXECUTE_RESOLUTIONS mode
     */
    boolean wasExecuted() {
        return wasExecuted;
    }

    /**
     * mark descriptor as executed if it was processed by server in EXECUTE_RESOLUTIONS mode), false otherwise
     */
    void setExecuted(boolean executed) {
        this.wasExecuted = executed;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((scope == null) ? 0 : scope.hashCode());
        result = prime * result + ((target == null) ? 0 : target.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        XMLMergeDescriptor other = (XMLMergeDescriptor) obj;
        if (scope == null) {
            if (other.scope != null) {
                return false;
            }
        } else if (!scope.equals(other.scope)) {
            return false;
        }
        if (target == null) {
            if (other.target != null) {
                return false;
            }
        } else if (!target.equals(other.target)) {
            return false;
        }
        return true;
    }

    private static List<XMLMergeDescriptor> createMergeDescriptors(MergeCommandLocalScope mergeScope,
            MergeDescriptorsContainer container, SyncMode mode) {
        List<XMLMergeDescriptor> result = new ArrayList<XMLMergeDescriptor>();

        Map<IDMProject, List<IResource>> mergeScopes = mergeScope.getMergeScopes();
        Set<Entry<IDMProject, List<IResource>>> entrySet = mergeScopes.entrySet();
        for (Entry<IDMProject, List<IResource>> entry : entrySet) {
            XMLMergeDescriptor desc = new XMLMergeDescriptor(entry.getKey(), entry.getValue(), container);
            desc.setCurrentMode(mode);
            result.add(desc);
        }

        return result;
    }

    /**
     * Container for all descriptors that takes part in merge
     */
    public static class MergeDescriptorsContainer {
        private List<XMLMergeDescriptor> descriptors;
        private MergeCommandOptions options;
        private MergeType mergeType;
        private SyncMode baseMode;
        private boolean isInUse;

        private MergeDescriptorsContainer() {
        }

        private MergeDescriptorsContainer(MergeCommandOptions options, MergeType mergeType, SyncMode baseMode) {
            this.options = options;
            this.mergeType = mergeType;
            this.baseMode = baseMode;
        }

        public enum MergeType {
            PROJECT,
            BASELINE,
            REQUEST
        }

        /**
         * @return current merge mode (detection, execution, non-interactive)
         */
        public SyncMode getBaseMode() {
            return baseMode;
        }

        public void setBaseModeSilent() {
            baseMode = SyncMode.NON_INTERACTIVE;
            if (getMergeDescriptors() == null) {
                return;
            }

            for (XMLMergeDescriptor descr : getMergeDescriptors()) {
                descr.setCurrentMode(SyncMode.NON_INTERACTIVE);
                descr.setCommandDetails(null);
            }
        }

        /**
         * @return current merge options
         */
        public MergeCommandOptions getMergeOptions() {
            return options;
        }

        /**
         * @return current merge type (PROJECT, BASELINE, REQUEST)
         */
        public MergeType getMergeType() {
            return mergeType;
        }

        /**
         * @return list of all merge descriptors related to this container
         */
        public List<XMLMergeDescriptor> getMergeDescriptors() {
            return descriptors;
        }

        /**
         * @return workset which is a source of changes
         */
        public VersionManagementProject getMergeSource() {
            return getMergeOptions().getSourceWorkset();
        }

        /**
         * @return spec of the workset which is a source of changes
         */
        public String getMergeSourceSpec() {
            if (getMergeOptions().getSourceWorkset() != null) {
                return getMergeOptions().getSourceWorkset().getObjectSpec();
            }
            return "";
        }

        /**
         * @return all local resources that takes part in merge
         */
        public IResource[] getResourceScope() {
            List<IResource> resources = new ArrayList<IResource>();

            for (XMLMergeDescriptor descr : getMergeDescriptors()) {
                if (descr.hasScope()) {
                    resources.addAll(descr.getScope());
                } else {
                    resources.add(descr.getTarget().getProject());
                }
            }

            return resources.toArray(new IResource[resources.size()]);
        }

        /**
         * @return all local target projects
         */
        public List<IDMProject> getAllTargetProjects() {
            List<IDMProject> result = new ArrayList<IDMProject>();
            for (XMLMergeDescriptor descr : getMergeDescriptors()) {
                result.add(descr.getTarget());
            }
            Collections.sort(result, new Comparator<IDMProject>() {

                @Override
                public int compare(IDMProject o1, IDMProject o2) {
                    String n1 = o1.getIdeProjectName();
                    String n2 = o2.getIdeProjectName();
                    return n1.compareTo(n2);
                }
            });
            return result;
        }

        /**
         * @return all descriptors that currently in detect resolutions phase
         */
        public List<XMLMergeDescriptor> getAllInteractives() {
            List<XMLMergeDescriptor> result = new ArrayList<XMLMergeDescriptor>();
            for (XMLMergeDescriptor descr : descriptors) {
                if (descr.getCurrentMergeMode() == SyncMode.DETECT_RESOLUTIONS) {
                    result.add(descr);
                }
            }
            return result;
        }

        /**
         * @return true if non-interactive merge has fails
         */
        public boolean isSilentModeFailed() {
            if (baseMode == SyncMode.NON_INTERACTIVE) {
                for (XMLMergeDescriptor descr : descriptors) {
                    if (descr.getCurrentMergeMode() == SyncMode.DETECT_RESOLUTIONS) {
                        return true;
                    }
                }
            }
            return false;
        }

        /**
         * @return true if any changes were applied to any local target
         */
        public boolean hasAppliedChanges() {
            for (XMLMergeDescriptor descr : descriptors) {
                if (descr.hasAppliedChanges()) {
                    return true;
                }
            }
            return false;
        }

        /**
         * @return true if all contained descriptors does not have any changes
         */
        public boolean isInSync() {
            for (XMLMergeDescriptor descr : descriptors) {
                if (!descr.isInSync()) {
                    return false;
                }
            }
            return true;
        }

        /**
         * Removes all information about changes from all contained descriptors
         */
        public void markInSync() {
            for (XMLMergeDescriptor descr : descriptors) {
                descr.markInSync();
            }
        }

        /**
         * set STALE status to all contained descriptors
         */
        public void markStale() {
            for (XMLMergeDescriptor descr : descriptors) {
                descr.markStale();
            }
        }

        /**
         * set STALE status to selected contained descriptors
         */
        public void markStale(List<XMLMergeDescriptor> selected) {
            Set<XMLMergeDescriptor> all = new HashSet<XMLMergeDescriptor>(descriptors);

            for (Iterator<XMLMergeDescriptor> iterator = selected.iterator(); iterator.hasNext();) {
                XMLMergeDescriptor selDescr = iterator.next();
                if (all.contains(selDescr)) {
                    selDescr.markStale();
                }
            }
        }

        public void markStale(Set<XMLSyncInfo> subset) {
            if (subset != null) {
                for (XMLSyncInfo info : subset) {
                    XMLMergeDescriptor desc = info.getDescriptor();
                    if (desc != null && descriptors.contains(desc)) {
                        desc.markStale(info);
                    }
                }
            }
        }

        /**
         * return list of descriptors that were executed and any changes were applied
         */
        public List<XMLMergeDescriptor> getExecutedDescriptors() {
            List<XMLMergeDescriptor> result = new ArrayList<XMLMergeDescriptor>();

            for (XMLMergeDescriptor descr : descriptors) {
                if (descr.wasExecuted()) {
                    result.add(descr);
                }
            }

            return result;
        }

        /**
         * @return if any of contained descriptors has STALE status
         */
        public boolean isStale() {
            for (XMLMergeDescriptor descr : descriptors) {
                if (descr.isStale()) {
                    return true;
                }
            }
            return false;
        }

        /**
         * clear all related to container syncinfo
         */
        public void clearCachedInfo() {
            this.isInUse = false;
            clearCachedInfo(descriptors);
        }

        /**
         * clear syncinfo from descriptors
         */
        public void clearCachedInfo(List<XMLMergeDescriptor> descriptors) {
            this.isInUse = false;
            for (XMLMergeDescriptor descr : descriptors) {
                descr.clearCachedInfo();
            }
        }

        /**
         * clear syncinfo from descriptors that is in the input set
         */
        public void clearCachedInfo(List<XMLMergeDescriptor> descriptors, Set<XMLSyncInfo> syncInfosToClear) {
            this.isInUse = false;
            for (XMLMergeDescriptor descr : descriptors) {
                descr.clearCachedInfo(syncInfosToClear);
            }
        }

        /**
         * @return sync info using target resource from file resolution
         */
        public XMLSyncInfo getSyncInfoFromTarget(IResource resource) {
            for (XMLMergeDescriptor descr : descriptors) {
                XMLSyncInfo xinfo = descr.getSyncInfoFromTarget(resource);
                if (xinfo != null) {
                    return xinfo;
                }
            }
            return null;
        }

        /**
         * @return sync info using local resource from workspace
         */
        public XMLSyncInfo getSyncInfoFromLocal(IResource resource) {
            for (XMLMergeDescriptor descr : descriptors) {
                XMLSyncInfo xinfo = descr.getSyncInfoFromLocal(resource);
                if (xinfo != null) {
                    return xinfo;
                }
            }
            return null;
        }

        /**
         * @return temporary file store for sync info
         */
        public IFileStore getTempStore(XMLSyncInfo info) {
            for (XMLMergeDescriptor descr : descriptors) {
                IFileStore store = descr.getTempStore(info);
                if (store != null) {
                    return store;
                }
            }
            return null;
        }

        /**
         * @return all resources that were generated from resolutions
         */
        public IResource[] getAllTargetResources() {
            return getAllTargetResources(descriptors);
        }

        /**
         * @return resources that were generated from merge descriptors
         */
        public static IResource[] getAllTargetResources(List<XMLMergeDescriptor> descriptors) {
            List<IResource> result = new ArrayList<IResource>();
            for (XMLMergeDescriptor descr : descriptors) {
                result.addAll(descr.getTargetToInfo().keySet());
            }
            return result.toArray(new IResource[result.size()]);
        }

        /**
         * @return all descriptors that has any related sync info
         */
        public List<XMLMergeDescriptor> getNonEmptyDescriptors() {
            List<XMLMergeDescriptor> result = new ArrayList<XMLMergeDescriptor>();
            for (XMLMergeDescriptor descr : descriptors) {
                if (descr.getResolutionToInfo().size() > 0) {
                    result.add(descr);
                }
            }
            return result;
        }

        /**
         * @param target
         * @return descriptor that contains target project
         */
        public XMLMergeDescriptor getTargetDescriptor(IDMProject target) {
            for (XMLMergeDescriptor descr : descriptors) {
                if (descr.getTarget().equals(target)) {
                    return descr;
                }
            }
            return null;
        }

        private void setDescriptors(List<XMLMergeDescriptor> descriptors) {
            this.descriptors = descriptors;
        }

        public static MergeDescriptorsContainer createMergeContainer(MergeCommandOptions options) {
            MergeType type = null;
            if (options instanceof MergeWorksetOptions) {
                MergeWorksetOptions wopts = (MergeWorksetOptions) options;
                type = wopts.isBaseline() ? MergeType.BASELINE : MergeType.PROJECT;
            } else if (options instanceof MergeRequestsOptions) {
                type = MergeType.REQUEST;
            }

            SyncMode mode = null;
            if (options.isInteractive()) {
                mode = SyncMode.DETECT_RESOLUTIONS;
            } else {
                mode = SyncMode.NON_INTERACTIVE;
            }

            MergeDescriptorsContainer con = new MergeDescriptorsContainer(options, type, mode);
            MergeCommandLocalScope localScope = options.getLocalScope();
            con.setDescriptors(XMLMergeDescriptor.createMergeDescriptors(localScope, con, mode));
            return con;
        }

        public void setInUse(boolean isInUse) {
            this.isInUse = isInUse;
        }

        public boolean isInUse() {
            return this.isInUse;
        }

    }

}

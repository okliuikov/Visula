/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

/**
 * @author V.Grishchenko
 */
public interface IUploadRequestParameters {
    String getComment();

    void setComment(String comment);

    String getDescription();

    /** @return custom attribute numbers */
    int[] getAttributes();

    void setAttributes(int[] attrs);

    Object getAttribute(int attrNum);

    List<String> getRelatedRequests();

    String getPart();

    String getCharset();

    /**
     * Sets whether or not the local file should be made read only after successful upload.
     */
    void setReadOnly(boolean b);

    boolean isReadOnly();
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.TeamException;

import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Container status, supports persistence and deep status that is
 * reflects cumulative status of all descendants of a container.
 *
 * @author V.Grishchenko
 */
class WorkspaceFolderStatus extends WorkspaceResourceStatus { 

    private static boolean debugFolderStatus = DMTeamPlugin.getDefault().isDebuggingFolderStatus();
    static final byte VERSION = 1; // persistence format version

    public static final WorkspaceFolderStatus NULL_STATUS = new WorkspaceFolderStatus() {
        @Override
        void update(IDMWorkspaceResource member) throws TeamException {
        }

        @Override
        void read(DataInputStream dataIn) {
        }
    };

    private int deepStatus;
    private Set<String> addedMembers;
    private Set<String> deletedMemebers;

    static WorkspaceFolderStatus createFolderStatus(IContainer local, IDMRemoteResource base, IDMRemoteResource remote,
            MetadataProvider provider) throws TeamException {
        int status = NONE;
        if (local != null) {
            if (DMTeamPlugin.getWorkspace().isIgnored(local, provider)) {
                status |= IGNORED;
            }
        }
        if (base != null) {
            status |= MANAGED;
            try {
                status |= base.isMoved()
                        ? WorkspaceResourceStatus.MOVED : DMTeamPlugin.getWorkspace().getMovedFrom(local) != null
                                ? WorkspaceResourceStatus.MOVED : WorkspaceResourceStatus.NOT_MOVED;
            } catch (CoreException e) {
                throw TeamException.asTeamException(e);
            }
        } else {
            status |= UNMANAGED;
        }
        if (remote != null) {
            status |= REMOTE_PRESENT;
        } else {
            status |= REMOTE_MISSING;
        }
        if (local != null && local.exists()
                && (status & (MANAGED | REMOTE_MISSING | NOT_MOVED)) == (MANAGED | REMOTE_MISSING | NOT_MOVED)) {
            status |= MANAGED_NO_REMOTE_NOT_MOVED;
        }
        if (local != null && local.exists() && (status & (UNMANAGED | REMOTE_MISSING)) == (UNMANAGED | REMOTE_MISSING)
                && (status & IGNORED) == 0) {
            status |= UNMANAGED_NO_REMOTE_NOT_IGNORED;
        }
        return new WorkspaceFolderStatus(status, status);
    }

    static WorkspaceFolderStatus createFolderStatus(IContainer local, IDMRemoteResource base, IDMRemoteResource remote)
            throws TeamException {
        return createFolderStatus(local, base, remote, null);
    }

    WorkspaceFolderStatus() {
        this(NONE, NONE);
    }

    WorkspaceFolderStatus(int status, int deepStatus) {
        super(status);
        this.deepStatus = deepStatus;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof WorkspaceFolderStatus) {
            WorkspaceFolderStatus otherFldStatus = (WorkspaceFolderStatus) obj;
            if (status == otherFldStatus.status && deepStatus == otherFldStatus.deepStatus) {
                return setsEqual(addedMembers, otherFldStatus.addedMembers)
                        && setsEqual(deletedMemebers, otherFldStatus.deletedMemebers);
            }
        }
        return false;
    }

    private boolean setsEqual(Set<String> set1, Set<String> set2) {
        if (set1 == null) {
            set1 = Collections.emptySet();
        }
        if (set2 == null) {
            set2 = Collections.emptySet();
        }
        if (set1.size() != set2.size()) {
            return false;
        }
        return set1.containsAll(set2);
    }

    @Override
    public int hashCode() {
        return status ^ deepStatus;
    }

    void update(IDMWorkspaceResource member, MetadataProvider provider) throws TeamException {
        if (member == null) {
            return;
        }

        // don't allow updating deep status with statuses of ignored resources
        if (member.isIgnored(provider)) {
            return;
        }

        IResource local = member.getLocalResource();
        if (member.isManaged()) {
            if (!local.exists()) {
                if (debugFolderStatus) {
                    System.out.println("WFS update managed local !exists - deleted " + local.toString());
                }
                deleted(local);
            }
        } else {
            if (member.exists()) {
                if (debugFolderStatus) {
                    System.out.println("WFS update !managed member exists - added  " + local.toString());
                }
                added(local);
            }
        }

        WorkspaceResourceStatus memberStatus = member.getStatus(provider);
        if (member.isContainer()) {
            WorkspaceFolderStatus otherFolderStatus = (WorkspaceFolderStatus) memberStatus;
            this.deepStatus |= otherFolderStatus.deepStatus;
            if (otherFolderStatus.hasAddedOrDeletedMembers()) {
                if (debugFolderStatus) {
                    System.out.println("WFS update container modified " + local.toString());
                }
                this.deepStatus |= MODIFIED;
            }
            return;
        }
        this.deepStatus |= memberStatus.status;
    }

    void update(IDMWorkspaceResource member) throws TeamException {
        update(member, null);
    }

    @Override
    public boolean matchAll(int mask) {
        return matchAll(mask, true);
    }

    public boolean matchAll(int mask, boolean deep) {
        if (deep) {
            return (deepStatus & mask) == mask;
        }
        return super.matchAll(mask);
    }

    @Override
    public boolean matchAny(int mask) {
        return matchAny(mask, true);
    }

    public boolean matchAny(int mask, boolean deep) {
        if (deep) {
            return (deepStatus & mask) != 0;
        }
        return super.matchAny(mask);
    }

    @Override
    public String toString() {
        return super.toString() + getStatusString(deepStatus, "\nDEEP_STATUS={", "}");
    }

    /**
     * Writes this status to the stream.
     * @param dataOut
     * @throws IOException
     */
    void write(DataOutputStream dataOut) throws IOException {
        dataOut.writeByte(VERSION);
        dataOut.writeInt(status);
        dataOut.writeInt(deepStatus);
        writeCollection(dataOut, addedMembers == null ? Collections.<String>emptySet() : addedMembers);
        writeCollection(dataOut, deletedMemebers == null ? Collections.<String>emptySet() : deletedMemebers);
    }

    private void writeCollection(DataOutputStream dataOut, Collection<String> collection) throws IOException {
        dataOut.writeInt(collection.size());
        for (Iterator<String> iter = collection.iterator(); iter.hasNext();) {
            String name = iter.next();
            dataOut.writeUTF(name);
        }
    }

    private Set<String> readSet(DataInputStream dataIn) throws IOException {
        int size = dataIn.readInt();
        if (size == 0) {
            return null;
        }
        HashSet<String> result = new HashSet<String>();
        for (int i = 0; i < size; i++) {
            result.add(dataIn.readUTF());
        }
        return result;
    }

    /**
     * Initializes this status from the stream.
     * @param dataIn
     * @throws IOException
     */
    void read(DataInputStream dataIn) throws IOException {
        dataIn.readByte();
        this.status = dataIn.readInt();
        this.deepStatus = dataIn.readInt();
        this.addedMembers = readSet(dataIn);
        this.deletedMemebers = readSet(dataIn);
    }

    // uncontrolled added
    void added(IResource resource) {
        if (addedMembers == null) {
            addedMembers = new HashSet<String>();
        }
        addedMembers.add(resource.getName());
        if (deletedMemebers != null) {
            deletedMemebers.remove(resource);
        }
    }

    // controlled deleted
    void deleted(IResource resource) {
        if (deletedMemebers == null) {
            deletedMemebers = new HashSet<String>();
        }
        deletedMemebers.add(resource.getName());
        if (addedMembers != null) {
            addedMembers.remove(resource);
        }
    }

    String[] getAddedMembers() {
        if (addedMembers == null) {
            return Utils.ZERO_LENGTH_STRING_ARRAY;
        }
        return addedMembers.toArray(new String[addedMembers.size()]);
    }

    String[] getDeletedMembers() {
        if (deletedMemebers == null) {
            return Utils.ZERO_LENGTH_STRING_ARRAY;
        }
        return deletedMemebers.toArray(new String[deletedMemebers.size()]);
    }

    boolean hasAddedOrDeletedMembers() {
        if ((addedMembers != null && !addedMembers.isEmpty()) || (deletedMemebers != null && !deletedMemebers.isEmpty())) {
            return true;
        }
        return false;
    }

}

package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.variants.IResourceVariant;

import com.serena.dmfile.StringPath;
import com.serena.dmfile.sync.XSyncResolutions;
import com.serena.dmfile.xml.ObjectAttributes;
import com.serena.dmfile.xml.Resolution;
import com.serena.dmfile.xml.utility.NonConsecutiveCherrypickUtility;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.Messages;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;

public class XMLSyncInfoFactory {

    /**
     * Create sync info based on the xml resolution bean
     */
    public static XMLSyncInfo create(Resolution resolution, XMLMergeDescriptor descriptor, Subscriber subscriber)
            throws CoreException {

        Assert.isLegal(resolution.isRoot(), Messages.DMXMLMergeInfo_invalidResolution);

        Resolution ancResolution = resolution;
        Resolution srcResolution = resolution;

        if (!resolution.isConsecutive()) {
            ancResolution = NonConsecutiveCherrypickUtility.getOldestResolution(resolution);
            srcResolution = NonConsecutiveCherrypickUtility.getMostRecentResolution(resolution);
        }

        IDMProject project = descriptor.getTarget();
        XMLMergeSubscriber xsubscriber = (XMLMergeSubscriber) subscriber;

        IResourceVariant remote = null;
        ObjectAttributes src = srcResolution.getSrc();
        if (src != null && src.isFileAttributes()) {
            remote = xsubscriber.getSourceResourceVariant(TeamUtils.constructRelativeResource(src, project));
        }

        IResourceVariant ancestor = null;
        ObjectAttributes anc = ancResolution.getAnc();
        if (anc != null && anc.isFileAttributes()) {
            ancestor = xsubscriber.getAncestorResourceVariant(TeamUtils.constructRelativeResource(anc, project));
        }

        String relPath = "";
        if (!StringPath.isNullorEmpty(resolution.getRelPath())) {
            relPath = resolution.getRelPath();
        } else if (resolution.getTgt() != null && !StringPath.isNullorEmpty(resolution.getTgt().getRelPath())) {
            relPath = resolution.getTgt().getRelPath();
        } else {
            throw new CoreException(new Status(IStatus.ERROR, DMTeamPlugin.ID, Messages.DMXMLMergeInfo_invalidPath));
        }

        IResource target = TeamUtils.constructRelativeResource(relPath, resolution.isFileResolution(), project);

        XMLSyncInfo info = null;
        if (resolution.isConsecutive()) {
            info = new XMLSyncInfo(target, ancestor, remote, subscriber.getResourceComparator(), subscriber,
                    project.getConnection());
        } else {
            info = new CherrypickXmlSyncInfo(target, ancestor, remote, subscriber.getResourceComparator(), subscriber,
                    project.getConnection());
        }
        info.setDescriptor(descriptor);
        info.setResolution(resolution);

        XSyncResolutions type = resolution.getType();
        boolean isMetadataResolution = false;
        int kind = XMLSyncInfo.IN_SYNC;
        // merge can handle only incoming changes
        if (type == XSyncResolutions.SR_CONFLICT) {
            kind = XMLConflictTypeResolver.resolveConflictType(resolution);
        } else if (type == XSyncResolutions.SR_REMOVE) {
            kind = XMLSyncInfo.DELETION | XMLSyncInfo.INCOMING;
        } else if (type == XSyncResolutions.SR_MODIFY) {
            kind = XMLSyncInfo.CHANGE | XMLSyncInfo.INCOMING;
        } else if (type == XSyncResolutions.SR_CREATE || type == XSyncResolutions.SR_RENAME || type == XSyncResolutions.SR_MOVE
                || type == XSyncResolutions.SR_MOVE_MODIFY || type == XSyncResolutions.SR_RENAME_MODIFY) {
            kind = XMLSyncInfo.ADDITION | XMLSyncInfo.INCOMING;
        } else {
            // cases where we receive
            // XSyncResolutions.SR_REMOVE_METADATA
            // XSyncResolutions.SR_CREATE_METADATA
            // XSyncResolutions.SR_UPDATE_METADATA
            // XSyncResolutions.SR_MOVE_METADATA
            // XSyncResolutions.SR_MOVE_UPDATE_METADATA
            isMetadataResolution = true;
        }

        info.setDerivedKind(kind);
        info.init();
        info.initActions();

        addSyncInfoToDescriptor(resolution, descriptor, info, target, isMetadataResolution);

        return info;
    }

    /**
     * Adds XMLSyncInfo instance to descriptor's internal maps.
     */
    private static void addSyncInfoToDescriptor(Resolution resolution, XMLMergeDescriptor descriptor, XMLSyncInfo info,
            IResource target, boolean isMetadataResolution) {

        // resolutionToInfo
        descriptor.getResolutionToInfo().put(resolution, info);
        if (!resolution.isConsecutive()) {
            List<Resolution> allChildResolutions = NonConsecutiveCherrypickUtility.getAllChildResolutions(resolution);
            for (Resolution res : allChildResolutions) {
                descriptor.getResolutionToInfo().put(res, info);
            }
        }

        /***
         * Sometimes we have 2 resolutions for 1 file/folder, for example: SR_RENAME and SR_UPDATE_METADATA resolutions.
         * In that case, info for SR_RENAME must override info for SR_UPDATE_METADATA in targetToInfo and localToInfo maps
         * (because both resolutions have same "target" and "local" objects)
         */

        // targetToInfo
        if (!isMetadataResolution || !descriptor.getTargetToInfo().containsKey(target)) {
            descriptor.getTargetToInfo().put(target, info);
        }

        // localToInfo
        IResource local = info.getLocalResource();
        if (local != null) {
            if (!isMetadataResolution || !descriptor.getLocalToInfo().containsKey(local)) {
                descriptor.getLocalToInfo().put(local, info);
            }
        }

    }
}

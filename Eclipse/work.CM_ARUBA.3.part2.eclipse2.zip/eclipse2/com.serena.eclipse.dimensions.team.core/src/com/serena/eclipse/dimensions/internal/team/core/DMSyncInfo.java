/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * Dimensions sync info.
 *
 * @author V.Grishchenko
 */
public/* abstract */class DMSyncInfo extends SyncInfo {
    private Subscriber subscriber;
    private DimensionsConnectionDetailsEx connection;

    /**
     * @param local
     * @param base
     * @param remote
     * @param comparator
     */
    public DMSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote, IResourceVariantComparator comparator,
            Subscriber subscriber, DimensionsConnectionDetailsEx connection) {
        super(local, base, remote, comparator);
        this.subscriber = subscriber;
        this.connection = connection;
    }

    /**
     * @return Returns the connection.
     */
    public DimensionsConnectionDetailsEx getConnection() {
        return connection;
    }

    @Override
    public String getLocalContentIdentifier() {
        IResource local = getLocal();
        if (local != null && local.getType() == IResource.FILE) {
            try {
                IDMRemoteFile base = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
                if (base != null) {
                    return base.getContentIdentifier();
                }
            } catch (TeamException e) {
                DMTeamPlugin.log(e.getStatus());
            }
        }
        return null;
    }

    /**
     * @return the subscriber created this info
     */
    public Subscriber getSubscriber() {
        return subscriber;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.osgi.util.NLS;

/**
 * NLS convenience methods for the plugin.
 *
 * @author V.Grishchenko
 */
public class Messages extends NLS {
    private static final String BUNDLE_NAME = "com.serena.eclipse.dimensions.internal.team.core.messages"; //$NON-NLS-1$

    static {
        NLS.initializeMessages(BUNDLE_NAME, Messages.class);
    }

    public static String Dialog_title;
    public static String ok;

    public static String error_badSyncBytes;
    public static String error_worksetNotFound;
    public static String error_baselineNotFound;

    // generic
    public static String MessageDialog_warningTitle;

    public static String MoveDeleteHook_sccProjectWarning;

    // requests

    // This fields are used by reflection mechanism and
    // stay discoverable through 'Find Broken Externalized Strings' wizard
    public static String GetRevisionRequest_message;
    public static String UndoCheckoutRequest_message;
    public static String CheckoutRequest_message;
    public static String CheckinRequest_message;
    public static String CreateItemRequest_message;
    public static String UploadRequest_message;
    public static String ImportRequest_message;
    public static String UpdateFilenameRequest_message;
    public static String DeleteItemRevisionRequest_message;
    public static String ResolveConflictRequest_message;
    public static String MoveRequest_message;
    public static String UpdateRevisionRequest_message;
    public static String UpdateAutoMergeRevisionRequest_message;

    public static String UndoCheckoutRequest_replaceMessage;
    public static String UndoCheckoutRequest_noRemote;
    public static String UploadRequest_unknownError;
    public static String UploadRequest_metadataError;
    public static String ResolveConflictRequest_tipChanged;
    public static String ResolveConflictRequest_noRemote;
    public static String UpdateRevisionRequest_mergeMessage;

    // trees
    public static String RemoteTree_gettingLatest;
    public static String BaseTree_readingMetadata;

    // subscribers
    public static String DMWorkspace_off;
    public static String DMWorkspace_on;
    public static String DMWorkspace_27;
    public static String DMWorkspace_0;
    public static String DMWorkspace_42;
    public static String DMWorkspace_30;
    public static String DMWorkspace_31;
    public static String DMWorkspace_32;
    public static String DMWorkspace_34;
    public static String DMWorkspace_35;
    public static String DMWorkspace_36;
    public static String DMWorkspace_37;
    public static String DMWorkspace_38;
    public static String DMWorkspace_39;
    public static String DMWorkspace_43;
    public static String DMWorkspace_40;
    public static String DMWorkspace_41;
    public static String DMWorkspace_setReadOnly;
    public static String DMWorkspace_name;
    public static String DMWorkspace_cleanTSTask;
    public static String DMWorkspace_calcCS;
    public static String DMWorkspace_calcCSError;
    public static String DMWorkspace_unmanaged;
    public static String DMWorkspace_SynchronizationCancelled;

    public static String DMMergeSubscriber_ancestorAndSource;

    public static String MoveCommand_remoteExists;
    public static String MoveCommand_noRemote;
    public static String MoveCommand_createRemoteFolder;
    public static String MoveCommand_createdRemoteFolder;
    public static String MoveCommand_attemptDeleteRemoteFolder;
    public static String MoveCommand_checkFolderEmpty;
    public static String MoveCommand_folderIsEmpty;
    public static String MoveCommand_didNotDelete;

    public static String MoveRequest_exporting;
    public static String MoveRequest_removeRevisions;

    public static String DMProjectSetCapability_0;
    public static String DMProjectSetCapability_1;
    public static String DMProjectSetCapability_2;

    public static String DMRemoteFile_0;
    public static String DMRemoteFile_1;
    public static String DMRemoteFile_2;
    public static String DMRepositoryProvider_0;
    public static String DMRepositoryProvider_1;
    public static String DMRepositoryProvider_2;
    public static String DMRepositoryProvider_BrokenMapping3;

    public static String UndoCheckoutCommand_revNotFound;
    public static String UndoCheckoutCommand_revNotFoundKeep;
    public static String UndoCheckoutCommand_revsNotFound;

    public static String UploadCommand_0;
    public static String UploadCommand_1;
    public static String UploadCommand_2;
    public static String UploadCommand_UnknownError;

    public static String CreateFoldersCommand_create;
    public static String DeleteFoldersCommand_delete;
    public static String DownloadCommand_downloadingSingle;
    public static String DownloadCommand_downloadingMulti;
    public static String DownloadCommand_createMetaFolders;
    public static String DownloadCommand_downloadDir;
    public static String DownloadCommand_downloadingFolders;
    public static String DownloadMonitor_message;

    public static String FindAncestorBaseline_message;

    public static String TransferMonitor_0;
    public static String TransferMonitor_1;
    public static String TransferMonitor_2;
    public static String TransferMonitor_5;
    public static String TransferMonitor_3;
    public static String TransferMonitor_4;

    public static String WorksetProject_0;

    public static String UploadBucket_0;
    public static String UploadBucket_1;

    public static String DeliverBucket_0;
    public static String DeliverBucket_1;
    public static String DeliverMultipleCommandData_0deliveryToMultipleProjectsError;
    public static String DeliverMultipleCommandData_0differentCommandsError;
    public static String DeliverMultipleCommandData_0differentCommandUndefinedError;
    public static String DeliverMultipleCommandData_0differentWorkareaTypesError;

    public static String methodUnsupported_error;

    public static String UpdateAutoMerger_DMException;
    public static String UpdateAutoMerger_CoreException;
    public static String UpdateAutoMerger_IOException;
    public static String UpdateAutoMerger_conflict;
    public static String UpdateAutoMerger_conflict_binary;
    public static String UpdateAutoMerger_outEncodingException;
    public static String UpdateAutoMerger_outCoreException;
    public static String UpdateAutoMerger_outIOException;

    public static String dmStartupProcessing;
    public static String processSavedState;
    public static String registerMDListener;

    public static String DMTeamProviderAutoshareJob;
    public static String DMXMLMergeCommand_baseline_source_not_found;
    public static String DMXMLMergeCommand_project_source_not_found;
    public static String DMXMLMergeCommand_request_source_is_empty;
    public static String DMXMLMergeCommand_task_detection_mode_subtask;
    public static String DMXMLMergeCommand_task_execution_mode_subtask;
    public static String DMXMLMergeCommand_task_scan_mode_subtask;
    public static String DMXMLMergeInfo_invalidResolution;
    public static String DMXMLMergeInfo_invalidPath;
    public static String DMXMLMergeSubscriber_name;
    public static String DMXMLUpdateSubscriber_name;
    public static String MetaFilesDetected_TeamPrivate_Error;
    public static String ConnectionProvider_NoConnection;
    public static String Autoshare_No_Marker;
    public static String AutoShare_ErrorReading_Metadata;
    public static String AutoShare_No_Metadata;
    public static String AutoShare_Incompatible_Metadata;
    public static String AutoShare_Incompatible_Metadata1;
    public static String AutoShare_No_Connection;
    public static String AutoShare_InvalidProject;
    public static String AutoShare_FailedToShare;
    public static String AutoShare_FailedToShareVirtual;
    public static String AutoShare_ErrorFetchingProject;
    public static String AutoShare_NoProject;
    public static String AutoShare_ErrorDeleting_MarkerFile;
    public static String Autoshare_No_Connections;
    public static String AutoShare_Warning_Project_Orphaned;
    public static String AutoShare_Warning_Project_Renamed;
    public static String AutoShare_Were_Errors;
    public static String AutoShare_Error_Deleting_Metadata;
    public static String AutoShare_Deleting_All_Metadata;
    public static String AutoShare_Deleting_Project;
    public static String AutoShare_No_WorkAreaMetadata;
    public static String AutoShare_MavenProjectNotResolved;
    public static String AutoShare_MavenProjectNotResolvedParent;
    public static String AutoShare_MavenProjectNotSharedParent;
    public static String AutoShare_Multiple_WorkArea_Metadata;
    public static String AutoShare_Workspace_WorkArea_Error;
    public static String AutoShare_Error_Deleting_Project;
    public static String AutoShare_connectionError;
    public static String ShelveBucket_0;
    public static String ShelveBucket_1;
    public static String StateTransferMonitor_1;
    public static String StateTransferMonitor_2;
    public static String StateTransferMonitor_3;
    public static String StateTransferMonitor_4;
    public static String RehomeMonitor_1;
    public static String RehomeMonitor_2;
    public static String TreeSynchronizationCacheRefreshOperation;
    public static String TreeSynchronizationCacheRefreshOperation_files;
    
    public static String ProjectsToRehomeNotSpecified;
}
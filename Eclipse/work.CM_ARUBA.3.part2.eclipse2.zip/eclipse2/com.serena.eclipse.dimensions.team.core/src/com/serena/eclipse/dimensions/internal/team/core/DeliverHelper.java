package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.sbm.ActionDetails;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

class DeliverHelper {
    private DeliverResults deliverResults;

    static DMWorkspace getWorkspace() {
        return (DMWorkspace) DMTeamPlugin.getWorkspace();
    }

    DeliverHelper(DeliverResults deliverCommand) {
        Assert.isNotNull(deliverCommand);
        this.deliverResults = deliverCommand;
    }

    static void addDeliverSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        try {
            if (request instanceof MoveItemRequest) {
                MoveItemRequest moveRequest = (MoveItemRequest) request;
                rules.add(TeamUtils.parent(moveRequest.getSource()));
                rules.add(TeamUtils.parent(moveRequest.getDestination()));
            } else if (request instanceof MoveFolderRequest) {
                MoveFolderRequest moveRequest = (MoveFolderRequest) request;
                rules.add(TeamUtils.parent(moveRequest.getSource()));
                rules.add(TeamUtils.parent(moveRequest.getDestination()));
            } else {
                IResource resource = request.getResource();
                IResource parent = TeamUtils.parent(resource);
                rules.add(TeamUtils.findDeepestManagedResource(parent));
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
    }

    static ObjectToTransfer getTransferObjectFromStatusMap(Map<String, ObjectToTransfer> statusMap, IResource resource) {
        if (statusMap != null) {
            String path = resource.getLocation().toOSString();
            Object result = statusMap.get(path);
            if (result != null) {
                return (ObjectToTransfer) result;
            } else {
                path = StringPath.terminate(path);
                result = statusMap.get(path);
                if (result != null) {
                    return (ObjectToTransfer) result;
                }
            }
        }

        return null;
    }

    void afterDeliver(List<WorkspaceResourceRequest> deliverList, List<IResource> toClean, IProgressMonitor monitor)
            throws CoreException {

        Map<String, ObjectToTransfer> statusMap = deliverResults.getStatusMap();
        Map<IResource, ActionDetails> actionDetails = deliverResults.getActionDetails();

        for (Iterator<WorkspaceResourceRequest> uIter = deliverList.iterator(); uIter.hasNext();) {
            WorkspaceResourceRequest request = uIter.next();
            if (request instanceof UploadRequest) {
                processDeliverRequestStatus(statusMap, request, actionDetails, toClean, monitor);
            } else if (request instanceof CreateFolderRequest) {
                processCreateFolderRequestStatus(request);
            } else if (request instanceof MoveFolderRequest) {
                processMoveFolderRequestStatus(statusMap, request);
            } else if (request instanceof MoveItemRequest) {
                processMoveItemRequestStatus(statusMap, request);
            }
        }
    }

    private static void processMoveItemRequestStatus(Map<String, ObjectToTransfer> statusMap, WorkspaceResourceRequest wsRequest)
            throws CoreException {
        DMWorkspace workspace = getWorkspace();
        MoveItemRequest request = (MoveItemRequest) wsRequest;
        IResource resource = request.getDestination();
        ObjectToTransfer fileToUpload = getTransferObjectFromStatusMap(statusMap, resource);
        if (fileToUpload != null) {
            String status = fileToUpload.getStatus();
            if (status != null && fileToUpload.getCmdStatus()
                    && (ObjectToTransfer.STATUS_RESOLVED.equals(status) || (ObjectToTransfer.STATUS_IGNORED.equals(status)))) {
                workspace.unregisterMove(resource);
            }
        }
    }

    private static void processMoveFolderRequestStatus(Map<String, ObjectToTransfer> statusMap, WorkspaceResourceRequest wsRequest)
            throws CoreException {
        DMWorkspace workspace = getWorkspace();
        MoveFolderRequest request = (MoveFolderRequest) wsRequest;
        IContainer resource = (IContainer) request.getDestination();
        ObjectToTransfer fileToUpload = getTransferObjectFromStatusMap(statusMap, resource);
        if (fileToUpload != null) {
            String status = fileToUpload.getStatus();
            if (status != null && fileToUpload.getCmdStatus()
                    && (ObjectToTransfer.STATUS_RESOLVED.equals(status) || (ObjectToTransfer.STATUS_IGNORED.equals(status)))) {
                DeliverHelper.cleanDMWorkspaceMoveCache(resource);
                workspace.unregisterMove(resource);
            }
        }
    }

    private static void processCreateFolderRequestStatus(WorkspaceResourceRequest wsRequest) throws CoreException {
        CreateFolderRequest request = (CreateFolderRequest) wsRequest;
        IContainer resource = (IContainer) request.getResource();
        if (resource.getType() != IResource.PROJECT) {
            // deliver was successful ensure have md up the hierarchy
            TeamUtils.ensureReacheable(resource, false);
        }
    }

    private static void processDeliverRequestStatus(Map<String, ObjectToTransfer> statusMap, WorkspaceResourceRequest request,
            Map<IResource, ActionDetails> actionDetails, List<IResource> toClean, IProgressMonitor monitor) throws CoreException {
        IFile file = ((UploadRequest) request).getFile();

        ObjectToTransfer status = getTransferObjectFromStatusMap(statusMap, file);
        if (status != null && status.getCmdStatus() && ObjectToTransfer.STATUS_RESOLVED.equals(status.getStatus())) {
            IContainer parent = file.getParent();
            if (parent.getType() != IResource.PROJECT) {
                // deliver was successful ensure have md up the hierarchy
                TeamUtils.ensureReacheable(parent, false);
            }
        } else if (status != null && status.getCmdStatus() && ObjectToTransfer.STATUS_IGNORED.equals(status.getStatus())) {
            // item has modification of its date. So we add it to a list which will be cleaned with timestamps.
            toClean.add(file);
        } else {
            if (actionDetails != null) {
                // exclude failures from associations
                actionDetails.remove(file);
            }
        }

        file.refreshLocal(IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, 5));
        WorkspaceMetadataManager.refreshMetadata(file, Utils.subMonitorFor(monitor, 5));

        // obtain resulting revision if need to send to SBM
        if (actionDetails != null) {
            ActionDetails aDetails = actionDetails.get(request.getResource());
            if (aDetails != null) {
                BaseMetadata bm = WorkspaceMetadataManager.getInstance().getMetadata(file);
                if (bm instanceof ItemMetadata) {
                    String itemSpec = ((ItemMetadata) bm).getItemSpec();
                    if (itemSpec != null) {
                        aDetails.setPath(TeamUtils.getFullSbmFilename(aDetails.getPath(), itemSpec, false));
                        aDetails.setNewRevision(TeamUtils.extractRevisionFromSpec(itemSpec));
                    }
                }
            }
        }
    }

    private static void cleanDMWorkspaceMoveCache(IContainer resource) throws CoreException {
        DMWorkspace workspace = getWorkspace();
        IResource[] members = resource.members();
        for (int i = 0; i < members.length; i++) {
            workspace.unregisterMove(members[i]);
            if (members[i] instanceof IContainer) {
                cleanDMWorkspaceMoveCache((IContainer) members[i]);
            }
        }
    }

}

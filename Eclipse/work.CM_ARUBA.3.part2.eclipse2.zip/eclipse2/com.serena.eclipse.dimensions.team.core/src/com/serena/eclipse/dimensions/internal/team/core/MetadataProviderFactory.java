package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;

import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.dmfile.metadb.MetadataProviderCache;
import com.serena.dmfile.metadb.MetadataProviderCacheFactory;
import com.serena.eclipse.dimensions.core.util.Assert;

public final class MetadataProviderFactory { 

    public static MetadataProvider providerFor(IResource resource) {
        Assert.isNotNull(resource);
        boolean isFile = resource.getType() == IResource.FILE;
        String pathName = resource.getLocation().toOSString();
        return MetadataProviderCacheFactory.providerFor(pathName, isFile);
    }

    public static MetadataProvider providerFor(IPath path) {
        Assert.isNotNull(path);
        boolean isFile = new File(path.toOSString()).isFile();
        return providerFor(path, isFile);
    }

    public static MetadataProvider providerFor(IPath path, boolean isFile) {
        Assert.isNotNull(path);
        String pathName = path.toOSString();
        return MetadataProviderCacheFactory.providerFor(pathName, isFile);
    }

    public static MetadataProvider providerFor(String path) {
        Assert.isNotNull(path);
        boolean isFile = new File(path).isFile();
        return providerFor(path, isFile);
    }

    public static MetadataProvider providerFor(String path, boolean isFile) {
        Assert.isNotNull(path);
        String pathName = path;
        return MetadataProviderCacheFactory.providerFor(pathName, isFile);
    }

    public static MetadataProvider providerFor(File file) {
        Assert.isNotNull(file);
        String pathName = file.getAbsolutePath();
        return MetadataProviderCacheFactory.providerFor(pathName, file.isFile());
    }

    public static boolean removeProvider(String workareaPath) {
        Assert.isNotNull(workareaPath);
        return MetadataProviderCache.getInstance().removeProvider(workareaPath);
    }

}
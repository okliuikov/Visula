package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemDirMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.metadata.IgnoredContributorList;
import com.serena.dmfile.xml.OutgoingMergePoint;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

public class DeliverBucketHelper {

    static DMWorkspace getWorkspace() {
        return (DMWorkspace) DMTeamPlugin.getWorkspace();
    }

    /**
     * Sets part for transfer. Ignores part if not explicitly changed by user - will be resolved by upload from rules
     * @param request
     * @return part
     */
    static String getOwningPart(UploadRequest request) {
        if (!request.isCreateItem()) {
            return null;
        }
        CreateItemRequest cir = (CreateItemRequest) request.getParameters();
        if (cir.isPartUpdated()) {
            return cir.getPart();
        }
        return null;
    }

    /**
     * This method returns the foreign Stream name from which the resource came.
     * @param local
     *            - Local resource being checked
     * @return Foreign Stream name
     */
    static String getStream(IResource local) {
        try {
            if (!local.exists()) {
                return null;
            }
            if (local.getType() == IResource.PROJECT) {
                return null;
            }
            BaseMetadata metaData = WorkspaceMetadataManager.getInstance().getMetadata(local);
            if (metaData == null) {
                return null;
            }
            if (local.getType() == IResource.FILE) {
                return (((ItemMetadata) metaData).getProject());
            } else if (local.getType() == IResource.FOLDER) {
                return (((DirectoryMetadata) metaData).getProject());
            }

        } catch (CoreException ce) {
            return null;
        }
        return null;
    }

    /**
     * Returns true if this resource came from baseline
     *
     * @param local
     *            - Local resource being checked
     * @return true if it is baseline resource, false otherwise
     */
    static boolean isBaseline(IResource local) {
        try {
            if (!local.exists()) {
                return false;
            }
            if (local.getType() == IResource.PROJECT) {
                return false;
            }
            BaseMetadata metaData = WorkspaceMetadataManager.getInstance().getMetadata(local);
            if (metaData == null) {
                return false;
            }
            if (local.getType() == IResource.FILE) {
                return ((ItemMetadata) metaData).getBaseline() != null;
            } else if (local.getType() == IResource.FOLDER) {
                return ((DirectoryMetadata) metaData).getBaseline() != null;
            }
        } catch (CoreException ce) {
            return false;
        }
        return false;
    }

    /**
     * Adds to merge points list a set of special ignored contributors records. Result is based on excluded resources.
     * Exclusion list makes sense only for TREE or MULTISELECT shapes and iff workarea has merge points
     * @param mergePoints to update with ignored contributors
     * @param cmdData which contains deliver data
     * @throws DMException
     */
    static void addIgnoredContributors(List<OutgoingMergePoint> mergePoints, TransferToStreamOperationData cmdData) {
        Set<IResource> excludedResources = cmdData.getExcludedResources();
        TransferShape transferShape = cmdData.getTransferShape();
        IDMProject project = cmdData.getProject();

        if (!transferShape.isMergePointsAware()) {
            return;
        }

        if (mergePoints == null || excludedResources == null || mergePoints.size() == 0 || excludedResources.size() == 0) {
            return;
        }

        String workareaPath = project.getUserDirectory().toOSString();
        IgnoredContributorList ignoredList = null;
        if (project.isContainedEclipseProject() && !project.isFullWorkArea()) {
            ignoredList = new IgnoredContributorList(workareaPath, project.getRemoteOffset().toOSString());
        } else {
            ignoredList = new IgnoredContributorList(workareaPath);
        }

        try {
            long uid = project.getDimensionsObject().getUid();
            for (IResource excluded : excludedResources) {
                if (ignoredList.isIgnoredAll()) {
                    break;
                }

                IResource movedTo = getWorkspace().getMovedTo(excluded);
                if (movedTo != null && !excludedResources.contains(movedTo)) {
                    // if resource was moved and target side not excluded
                    continue;
                }

                IDMRemoteResource baseResource = DMTeamPlugin.getWorkspace().getBaseResource(excluded);
                ItemDirMetadata mdItemDir = null;
                if (baseResource instanceof DMRemoteFile) {
                    DMRemoteFile file = (DMRemoteFile) baseResource;
                    mdItemDir = file.getMetadata();
                } else if (baseResource instanceof DMRemoteFolder) {
                    DMRemoteFolder folder = (DMRemoteFolder) baseResource;
                    mdItemDir = folder.getMetadata();
                }

                if (mdItemDir != null) {
                    ignoredList.addIgnoredContributor(uid, mdItemDir);
                }
            }
        } catch (CoreException e) {
            // something went wrong but deliver will be performed anyway
            DMTeamPlugin.log(e.getStatus());
        }
        List<OutgoingMergePoint> ignored = ignoredList.toMergePoint();
        mergePoints.addAll(ignored);
    }

    static void manageMetadataAfterMultipleDeliver(List<IdeProjectDeliverBucket> buckets) {
        for (IdeProjectDeliverBucket bucket : buckets) {
            manageMetadataAfterDeliver(bucket.getContents());
        }
    }

    static void manageMetadataAfterDeliver(List<WorkspaceResourceRequest> contents) {
        DMWorkspace workspace = DeliverBucketHelper.getWorkspace();
        try {
            for (int i = 0; i < contents.size(); i++) {
                WorkspaceResourceRequest request = contents.get(i);
                if (request instanceof MoveItemRequest) {
                    DeliverBucketHelper.resourceMoved(request.getResource(), true);
                    // If you create a new revision of a file in a Stream in the repository and another user who does not have this
                    // change locally moves the same file to a different location locally and does a sync. Sync view will show the
                    // file in the source location ,from where the file was moved, as conflict and when you do a Mark as Merged
                    // metadata is created in the source location. We need to delete this metadata once deliver is done
                    // or else this file will be shown as an outgoing addition when deliver is completed.
                    WorkspaceMetadataManager.getInstance().deleteMetadata(((MoveItemRequest) request).getSource(),
                            WorkspaceMetadataManager.DELETE);
                } else if (request instanceof MoveFolderRequest) {
                    DeliverBucketHelper.treeMoved((IFolder) request.getResource());
                } else if (request instanceof DeleteFolderRequest || request instanceof DeleteItemRevisionRequest) {
                    // special case of unmanaging - existing parent folder - should be deleted
                    if (request.getResource().getType() == IResource.FOLDER
                            && TeamUtils.isSpecialCaseOfFolderAndFileDeletion(request.getResource(), false)) {
                        ((IFolder) request.getResource()).refreshLocal(IResource.DEPTH_INFINITE, null);
                        ((IFolder) request.getResource()).delete(false, true, null);
                    }
                    workspace.unmanage(request.getResource(), true, null);
                }
            }
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
    }

    private static void resourceMoved(IResource resource, boolean releaseBase) throws CoreException {
        IResource source = DeliverBucketHelper.getWorkspace().getMovedFrom(resource);
        if (source != null && releaseBase) {
            DeliverBucketHelper.getWorkspace().releaseBase(source, true, IResource.DEPTH_ZERO, null);
            DeliverBucketHelper.getWorkspace().refreshRemoteTree(new IResource[] { source }, IResource.DEPTH_ZERO, null);
        }
        MoveRequest.discardMoveState(resource);
    }

    private static void treeMoved(IContainer root) throws CoreException {
        IResource source = DMTeamPlugin.getWorkspace().getMovedFrom(root);
        if (source != null) {
            // purge base info for the whole tree
            DeliverBucketHelper.getWorkspace().releaseBase(source, true, IResource.DEPTH_INFINITE, null);
            DeliverBucketHelper.getWorkspace().refreshRemoteTree(new IResource[] { source }, IResource.DEPTH_INFINITE, null);
        }
        root.accept(new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                MoveRequest.discardMoveState(resource);
                return true;
            }
        });
    }

}

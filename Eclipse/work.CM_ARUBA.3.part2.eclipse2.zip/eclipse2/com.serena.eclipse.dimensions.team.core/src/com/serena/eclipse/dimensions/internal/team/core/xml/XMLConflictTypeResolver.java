/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.dmfile.sync.XSyncConflictTypes;
import com.serena.dmfile.xml.Resolution;

/**
 * Groups conflicts by additions, deletions or simple changes
 */
public class XMLConflictTypeResolver {

    private static Set<XSyncConflictTypes> additionConflicts = new HashSet<XSyncConflictTypes>();
    static {
        additionConflicts.add(XSyncConflictTypes.SCT_FCREATED_DCREATED);
        additionConflicts.add(XSyncConflictTypes.SCT_DCREATED_FCREATED);
        additionConflicts.add(XSyncConflictTypes.SCT_DMOVED_DMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_DDELETED_DMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FDELETED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_DADDED_DADDED);
        additionConflicts.add(XSyncConflictTypes.SCT_FADDED_FADDED);
        additionConflicts.add(XSyncConflictTypes.SCT_FADDED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_DADDED_DMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMODIFIED_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMODIFIED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FDELETED_FMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_FDELETED_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVED_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVEDMODIFIED_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVEDMODIFIED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FUNCHANGEDCHECKEDOUT_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FUNCHANGEDCHECKEDOUT_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_DADDED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_DADDED_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_DDELETED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_DDELETED_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_DMOVED_FMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_DMOVED_FMOVEDMODIFIED);
        additionConflicts.add(XSyncConflictTypes.SCT_FDELETED_FADDED);
        additionConflicts.add(XSyncConflictTypes.SCT_DDELETED_DADDED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVEDMODIFIED_DADDED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVED_DADDED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVEDMODIFIED_DMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMOVED_DMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FMODIFIED_DMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_FADDED_DMOVED);
        additionConflicts.add(XSyncConflictTypes.SCT_DMOVED_FADDED);
    }

    private static Set<XSyncConflictTypes> deletionConflicts = new HashSet<XSyncConflictTypes>();
    static {
        deletionConflicts.add(XSyncConflictTypes.SCT_FADDED_FDELETED);
        deletionConflicts.add(XSyncConflictTypes.SCT_DADDED_DDELETED);
        deletionConflicts.add(XSyncConflictTypes.SCT_DMOVED_DDELETED);
        deletionConflicts.add(XSyncConflictTypes.SCT_FMOVED_FDELETED);
        deletionConflicts.add(XSyncConflictTypes.SCT_FMODIFIED_FDELETED);
        deletionConflicts.add(XSyncConflictTypes.SCT_FMOVEDMODIFIED_FDELETED);
    }

    private static Set<XSyncConflictTypes> changeConflicts = new HashSet<XSyncConflictTypes>();
    static {
        changeConflicts.add(XSyncConflictTypes.SCT_FREPLACED_FUNCHANGED);
        changeConflicts.add(XSyncConflictTypes.SCT_FMODIFIED_FUNCHANGED);
        changeConflicts.add(XSyncConflictTypes.SCT_FUNCHANGED_FREPLACED);
        changeConflicts.add(XSyncConflictTypes.SCT_DUNCHANGED_DREPLACED);
        changeConflicts.add(XSyncConflictTypes.SCT_DREPLACED_DUNCHANGED);

        changeConflicts.add(XSyncConflictTypes.SCT_FMODIFIED_FMODIFIED);
        changeConflicts.add(XSyncConflictTypes.SCT_FUNCHANGEDCHECKEDOUT_FMODIFIED);

        changeConflicts.add(XSyncConflictTypes.SCT_FADDED_FMOVEDMODIFIED);
        changeConflicts.add(XSyncConflictTypes.SCT_FMOVED_FMODIFIED);
        changeConflicts.add(XSyncConflictTypes.SCT_FMOVEDMODIFIED_FMODIFIED);
        changeConflicts.add(XSyncConflictTypes.SCT_FREPLACED_FMODIFIED);
        changeConflicts.add(XSyncConflictTypes.SCT_FMODIFIED_FREPLACED);
        changeConflicts.add(XSyncConflictTypes.SCT_FMOVEDMODIFIED_FREPLACED);
        changeConflicts.add(XSyncConflictTypes.SCT_FMOVED_FREPLACED);
        changeConflicts.add(XSyncConflictTypes.SCT_FDELETED_DMOVED);
    }

    public static int resolveConflictType(Resolution resolution) {
        int result = SyncInfo.CONFLICTING;
        XSyncConflictTypes conflictType = resolution.getConflictType();
        if (additionConflicts.contains(conflictType)) {
            result |= SyncInfo.ADDITION;
        } else if (deletionConflicts.contains(conflictType)) {
            result |= SyncInfo.DELETION;
        } else if (changeConflicts.contains(conflictType)) {
            result |= SyncInfo.CHANGE;
        } else {
            // XSyncConflictTypes.SCT_UNKNOWN(-2)
            // XSyncConflictTypes.SCT_PSEUDO_CONFLICT(-1)
            // tracking them as change conflicts for now
            result |= SyncInfo.CHANGE;
        }
        return result;
    }

    public static boolean isAdditionConflict(XSyncConflictTypes type) {
        return additionConflicts.contains(type);
    }

    public static boolean isDeletionConflict(XSyncConflictTypes type) {
        return deletionConflicts.contains(type);
    }

    public static boolean isChangeConflict(XSyncConflictTypes type) {
        return changeConflicts.contains(type);
    }
}
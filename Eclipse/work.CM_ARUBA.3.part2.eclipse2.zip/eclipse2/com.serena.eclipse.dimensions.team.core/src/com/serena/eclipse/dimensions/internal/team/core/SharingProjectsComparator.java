/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Comparator;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Compares two projects as a maven projects. If project is deeper in the maven projects hierarchy
 * then this project is greater then another.
 */
final class SharingProjectsComparator implements Comparator<IProject> {

    private IProgressMonitor monitor;

    public SharingProjectsComparator(IProgressMonitor monitor) {
        this.monitor = monitor;
    }

    @Override
    public int compare(IProject o1, IProject o2) {
        IMavenProjectStructureHelper mavenHelper = DMTeamPlugin.getDefault().getMavenProjectStructureHelper();
        if (mavenHelper != null) {
            boolean firstHasPom = mavenHelper.hasParentPomInTree(o1, Utils.monitorFor(monitor));
            boolean secondHasPom = mavenHelper.hasParentPomInTree(o2, Utils.monitorFor(monitor));
            if (firstHasPom && !secondHasPom) {
                return 1;
            } else if (!firstHasPom && secondHasPom) {
                return -1;
            } else if (!firstHasPom && !secondHasPom) {
                return 0;
            } else {
                IProject firstParent = mavenHelper.getParentMavenProject(o1, Utils.monitorFor(monitor));
                IProject secondParent = mavenHelper.getParentMavenProject(o2, Utils.monitorFor(monitor));

                if (firstParent != null && secondParent == null) {
                    return 1;
                } else if (firstParent == null && secondParent != null) {
                    return -1;
                } else if (firstParent == null && secondParent == null) {
                    return 0;
                } else {
                    IPath firstLocation = firstParent.getLocation();
                    IPath secondLocation = secondParent.getLocation();

                    if (firstLocation.isPrefixOf(secondLocation)) {
                        return -1;
                    } else if (secondLocation.isPrefixOf(firstLocation)) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            }
        }
        return 0;
    }

}
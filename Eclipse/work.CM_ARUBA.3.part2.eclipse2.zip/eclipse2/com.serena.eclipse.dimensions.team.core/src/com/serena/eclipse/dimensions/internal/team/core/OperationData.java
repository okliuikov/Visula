package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Arrays;
import java.util.List;

import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;

/**
 * Operation parameters holder
 */
public class OperationData {
    private DMRepositoryProvider provider;
    private IDMProject project;
    private List<WorkspaceResourceRequest> requests;

    public OperationData(DMRepositoryProvider provider, List<WorkspaceResourceRequest> requests) throws CoreException {
        Assert.isNotNull(provider);
        Assert.isNotNull(requests);
        this.provider = provider;
        this.requests = requests;
        this.project = provider.getIdmProject();
        Assert.isNotNull(project);
    }

    public OperationData(DMRepositoryProvider provider, WorkspaceResourceRequest[] requests) throws CoreException {
        Assert.isNotNull(provider);
        Assert.isNotNull(requests);
        this.provider = provider;
        this.requests = Arrays.asList(requests);
        this.project = provider.getIdmProject();
        Assert.isNotNull(project);
    }

    /**
     * @return the provider
     */
    public DMRepositoryProvider getProvider() {
        return provider;
    }

    /**
     * @return the requests
     */
    public List<WorkspaceResourceRequest> getRequests() {
        return requests;
    }

    /**
     * @return the requests array
     */
    public WorkspaceResourceRequest[] getRequestsArray() {
        return requests.toArray(new WorkspaceResourceRequest[requests.size()]);
    }

    /**
     * @return the project
     */
    public IDMProject getProject() {
        return project;
    }

}

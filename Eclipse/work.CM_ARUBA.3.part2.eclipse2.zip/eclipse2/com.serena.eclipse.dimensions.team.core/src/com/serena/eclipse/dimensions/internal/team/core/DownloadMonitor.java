/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.eclipse.dimensions.core.util.Assert;

/*
 * Checks for changed timestamps during download and updates the underlying
 * monitor with progress.
 * @author V.Grishchenko
 */
class DownloadMonitor extends Thread {
    static final long DEFAULT_POLL_INTERVAL = 1000; // poll lfs every second by default

    private IFile[] files;
    private IProgressMonitor monitor;
    private Map timestamps; // java.io.File -> Long
    private long pollInterval = DEFAULT_POLL_INTERVAL;
    private int downloaded = 0;
    private int unitsPerFile = 1;

    DownloadMonitor(IFile[] files, IProgressMonitor monitor) {
        super("Download Monitor"); //$NON-NLS-1$
        this.files = files;
        this.monitor = monitor;
        setPriority(Thread.MIN_PRIORITY);
        initializeTimestamps();
    }

    void setPollInterval(long interval) {
        Assert.isLegal(interval >= 100);
        this.pollInterval = interval;
    }

    void setUnitsPerFile(int units) {
        Assert.isLegal(units >= 1);
        this.unitsPerFile = units;
    }

    private void initializeTimestamps() {
        timestamps = new HashMap();
        for (int i = 0; i < files.length; i++) {
            File lfsFile = files[i].getLocation().toFile();
            timestamps.put(lfsFile, new Long(lfsFile.lastModified()));
        }
    }

    @Override
    public void run() {
        while (!isInterrupted() && timestamps.size() > 0) {
            try {
                Thread.sleep(pollInterval);
                int delta = collectChanged();
                if (delta > 0) {
                    monitor.worked(delta * unitsPerFile);
                    downloaded += delta;
                    monitor.subTask(NLS.bind(Messages.DownloadMonitor_message, String.valueOf(downloaded),
                            String.valueOf(files.length)));
                }
            } catch (InterruptedException e) {
                break;
            }
        }
        monitor.worked((files.length - downloaded) * unitsPerFile); // assume the rest was downloaded
    }

    private int collectChanged() {
        int cnt = 0;
        for (Iterator iter = timestamps.entrySet().iterator(); iter.hasNext();) {
            Map.Entry entry = (Map.Entry) iter.next();
            File lfsFile = (File) entry.getKey();
            Long stamp = (Long) entry.getValue();
            long currentStamp = lfsFile.lastModified();
            if (currentStamp != stamp.longValue()) {
                iter.remove();
                cnt++;
            }
        }
        return cnt;
    }

}

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

public interface IMoveRequest {

    IResource getSource() throws CoreException;

    IResource getDestination() throws CoreException;

    IDMProject getSourceProject() throws CoreException;

    IDMProject getDestinationProject() throws CoreException;

    boolean isCrossProject() throws CoreException;

    void setUnmanage(boolean b);

    boolean isUnmanage();

    boolean isSource();

    IResource getResource();

    /**
     * Call this method to specify requests to be used for removal from the
     * source project, used during cross-project moves only.
     *
     * @param requests
     */
    void setSourceRequests(List<String> requests);

    /**
     * @return requests to be used for removal from the source project such as
     *         when moving from one project to another
     */
    public List<String> getChangeRequests();

    public void setComment(String comment);

    public String getComment();

}
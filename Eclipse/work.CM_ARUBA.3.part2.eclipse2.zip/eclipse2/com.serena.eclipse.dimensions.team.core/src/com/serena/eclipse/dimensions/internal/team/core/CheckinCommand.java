/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Perform pessimistic checkin.
 *
 * @author V.Grishchenko
 */
class CheckinCommand extends DMWorkspaceCommand1 {

    /**
     * @param dmProject
     * @param requests
     */
    public CheckinCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    protected void execute(IProgressMonitor progress) throws CoreException {
        progress = Utils.monitorFor(progress);
        progress.beginTask(null, requests.length);
        try {
            for (int i = 0; i < requests.length; i++) {
                CheckinRequest checkinRequest = (CheckinRequest) requests[i];
                checkinRequest.process(progress);
                progress.worked(1);
                Utils.checkCanceled(progress);
            }
        } finally {
            progress.done();
        }
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

}

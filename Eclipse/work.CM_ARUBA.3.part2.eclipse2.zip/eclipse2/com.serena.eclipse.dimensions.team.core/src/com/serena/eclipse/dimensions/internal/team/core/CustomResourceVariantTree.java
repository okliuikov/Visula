package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.IResourceVariant;

import com.serena.dmclient.api.RepositoryFolder;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.util.Utils;

public class CustomResourceVariantTree extends DMResourceVariantTree {
    private Map remoteResourceMap;

    public CustomResourceVariantTree(CustomByteStore store, CustomSubscriber subscriber) {
        super(store, subscriber);
        remoteResourceMap = subscriber.getResourceMap() != null ? subscriber.getResourceMap() : new HashMap();
        // do this to have initial remote variants for parent projects
        List localProjectList = new ArrayList();
        for (Iterator iter = remoteResourceMap.keySet().iterator(); iter.hasNext();) {
            IResource resource = (IResource) iter.next();
            if (!localProjectList.contains(resource.getProject())) {
                localProjectList.add(resource.getProject());
            }
        }
        for (Iterator iter = localProjectList.iterator(); iter.hasNext();) {
            IProject localRoot = (IProject) iter.next();
            try {
                IDMProject project = getDMProject(localRoot);
                if (project == null) {
                    break;
                }
                IPath remotePath = project.getRemotePathForLocalResource(localRoot);
                if (remotePath == null) {
                    break;
                }
                RepositoryFolder remoteRootFolder = project.getRemoteFolder(localRoot, new NullProgressMonitor());
                if (remoteRootFolder == null) {
                    break;
                }
                DMRemoteFolder remoteRoot = createRemoteFolder(null, remotePath, project, remoteRootFolder);

                setVariant(localRoot, remoteRoot);
            } catch (CoreException e) {
                e.printStackTrace();
            }
        }
    }

    public void prepareForDeletion(IResource resource) throws CoreException {
        CustomByteStore byteStore = (CustomByteStore) getByteStore();
        IResource[] members = byteStore.members(resource);
        for (int i = 0; i < members.length; i++) {
            prepareForDeletion(members[i]);
        }
        byteStore.prepareForDeletion(resource);
    }

    @Override
    protected List fetchFolderMembers(IDMRemoteFolder folder, IProgressMonitor monitor) throws CoreException {
        return fetchFolderMembers(folder, false, monitor);
    }

    protected List fetchFolderMembers(IDMRemoteFolder folder, boolean recursive, IProgressMonitor monitor) {
        List<IDMRemoteResource> resultList = new ArrayList<IDMRemoteResource>();
        try {
            List coveredPaths = new ArrayList();
            List toDeletePaths = new ArrayList();

            Iterator iter = remoteResourceMap.keySet().iterator();
            while (iter.hasNext()) {
                IResource localRes = (IResource) iter.next();
                IDMRemoteResource remoteResource = (IDMRemoteResource) remoteResourceMap.get(localRes);

                if (remoteResource == null) { // means resource was removed in repository
                    try {
                        // we don't want to see parent resource of this resource as deleted
                        IDMProject dmProject = folder.getProject();
                        IPath remotePath = dmProject.getRemotePathForLocalResource(localRes.getParent());
                        RepositoryFolder repoFolder = dmProject.getRemoteFolder(remotePath, Utils.subMonitorFor(monitor, 20));
                        remoteResource = createRemoteFolder(null, remotePath, dmProject, repoFolder);
                        // register deleted folders paths to delete their child resources if we've created ones
                        if (localRes.getType() != IResource.FILE) {
                            toDeletePaths.add(dmProject.getRemotePathForLocalResource(localRes));
                        }
                    } catch (DMException e) {
                        e.printStackTrace();
                    }
                }

                if (remoteResource != null && folder.getPath().isPrefixOf(remoteResource.getPath())) { // if folder is parent
                    int segmentExtent = 0;
                    if (recursive) {
                        segmentExtent = remoteResource.getPath().segmentCount() - folder.getPath().segmentCount();
                    } else {
                        segmentExtent = 1;
                    }
                    for (int i = 1; i <= segmentExtent; i++) {
                        IPath childRemotePath = remoteResource.getPath().uptoSegment(folder.getPath().segmentCount() + i);
                        if (childRemotePath.segmentCount() == remoteResource.getPath().segmentCount()
                                && remoteResource.getType() == IDMRemoteResource.FILE) {
                            resultList.add(remoteResource);
                        } else if (!coveredPaths.contains(childRemotePath)) {
                            RepositoryFolder repositoryFolder = null;
                            try {
                                repositoryFolder = folder.getProject().getRemoteFolder(childRemotePath,
                                        Utils.subMonitorFor(monitor, 200)); // TODO ticks
                            } catch (DMException e) {
                                e.printStackTrace();
                            }
                            DMRemoteFolder remoteChildFolder = createRemoteFolder(null, childRemotePath, folder.getProject(),
                                    repositoryFolder);
                            resultList.add(remoteChildFolder);
                            coveredPaths.add(childRemotePath);
                        }
                    }
                }
            }

            for (Iterator toDeleteIter = toDeletePaths.iterator(); toDeleteIter.hasNext();) {
                IPath remotePath = (IPath) toDeleteIter.next();
                for (Iterator resultListIter = resultList.iterator(); resultListIter.hasNext();) {
                    IDMRemoteResource dmRemoteResource = (IDMRemoteResource) resultListIter.next();
                    if (remotePath.isPrefixOf(dmRemoteResource.getPath()) || remotePath.equals(dmRemoteResource.getPath())) {
                        resultListIter.remove();
                    }
                }
            }
        } finally {
            monitor.done();
        }
        return resultList;
    }

    protected DMRemoteFolder createRemoteFolder(DMRemoteFolder parent, IPath folderPath, IDMProject project,
            RepositoryFolder repositoryFolder) {
        DMRemoteFolder remoteFolder = new DMRemoteFolder(parent, folderPath, project, this, repositoryFolder);
        return remoteFolder;
    }

    @Override
    protected IResourceVariant fetchVariant(IResource resource, int depth, IProgressMonitor monitor) throws TeamException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        monitor.subTask(Messages.RemoteTree_gettingLatest); // TODO message

        if (resource == null) {
            return null;
        }

        try {
            IDMProject project = getDMProject(resource);
            if (project == null) {
                return null;
            }
            IPath remotePath = project.getRemotePathForLocalResource(resource);
            if (remotePath == null) {
                return null;
            }
            if (resource.getType() == IResource.FILE) {
                return (IResourceVariant) remoteResourceMap.get(resource);
            }
            IContainer localRoot = (IContainer) resource;

            RepositoryFolder remoteRootFolder = null;
            try {
                remoteRootFolder = project.getRemoteFolder(localRoot, Utils.subMonitorFor(monitor, 200));
            } catch (Exception e) {
                DMTeamPlugin.log(new Status(IStatus.WARNING, DMTeamPlugin.ID, e.getMessage()));
            }

            if (remoteRootFolder == null) {
                return null;
            }
            DMRemoteFolder remoteRoot = createRemoteFolder(null, remotePath, project, remoteRootFolder);
            if (depth == IResource.DEPTH_ZERO) {
                return remoteRoot;
            }

            List resources = fetchFolderMembers(remoteRoot, depth == IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, 10));
            resources.add(remoteRoot);

            return buildTree(resources, project, depth == IResource.DEPTH_INFINITE);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        } finally {
            monitor.done();
        }
    }

    private IResourceVariant buildTree(List remoteResources, IDMProject project, boolean recursive) {
        // sort folders by their containment
        TreeMap folders = new TreeMap(new ContainmentComparator());
        ArrayList files = new ArrayList();
        for (Iterator iter = remoteResources.iterator(); iter.hasNext();) {
            Object remoteResource = iter.next();
            if (remoteResource instanceof DMRemoteFolder) {
                DMRemoteFolder remoteFolder = (DMRemoteFolder) remoteResource;
                folders.put(remoteFolder.getPath(), remoteFolder);
            } else if (remoteResource instanceof IDMRemoteFile) {
                files.add(remoteResource);
            }
        }

        HashMap parents = new HashMap(folders.size()); // parent lookup

        // folders
        DMRemoteFolder root = null;
        for (Iterator folderIter = folders.entrySet().iterator(); folderIter.hasNext();) {
            Map.Entry entry = (Map.Entry) folderIter.next();
            IPath remoteFolderPath = (IPath) entry.getKey();
            DMRemoteFolder remoteFolder = (DMRemoteFolder) entry.getValue();

            if (root == null) {
                root = remoteFolder; // first folder is remote project folder
            } else {
                DMRemoteFolder parent = (DMRemoteFolder) parents.get(remoteFolder.getPath().removeLastSegments(1));
                assert parent != null;
                if (parent != null) {
                    try {
                        remoteFolder = createRemoteFolder(parent, remoteFolder.getPath(), project,
                                remoteFolder.getRepositoryFolder());
                    } catch (DMException e) {
                        e.printStackTrace();
                        break;
                    }
                } else {
                    remoteFolder = null;
                }
            }

            if (remoteFolder != null) {
                if (recursive) { // initialize members on recursive to avoid querying for children on empty folders later
                    remoteFolder.initMembers();
                }
                parents.put(remoteFolderPath, remoteFolder);
            }
        }

        // files
        for (Iterator fileIter = files.iterator(); fileIter.hasNext();) {
            IDMRemoteFile remoteFile = (IDMRemoteFile) fileIter.next();
            IPath remoteFilePath = remoteFile.getPath();
            if (remoteFilePath != null) { // assume was deleted if could not get full path after got the initial handle
                DMRemoteFolder parent = (DMRemoteFolder) parents.get(remoteFilePath.removeLastSegments(1));
                assert parent != null;
                if (parent != null) {
                    try {
                        new DMRemoteFile(parent, remoteFilePath, project, this, remoteFile.getItemRevision());
                    } catch (DMException e) {
                        DMTeamPlugin.log(e.getStatus());
                    }
                }
            }
        }

        return root;
    }

}

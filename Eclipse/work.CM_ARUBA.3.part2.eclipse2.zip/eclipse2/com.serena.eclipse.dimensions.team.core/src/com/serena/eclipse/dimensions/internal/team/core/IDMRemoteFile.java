/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.IPath;

import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DMException;

/**
 * Item - variant.
 *
 * @author V.Grishchenko
 */
public interface IDMRemoteFile extends IDMRemoteResource, IDMFile {

    /**
     * @return project uid that stored in metadata or -1
     */
    long getProjectUid();

    /**
     * @return full item specification
     */
    String getItemSpec();

    /**
     * @return PRODUCT:ITEM-ID
     */
    String getItemSpecId();

    /**
     * @return revision name
     */
    String getRevision();

    /**
     * @return file-version
     */
    int getVersion();

    /**
     * Indicates that this revision is extracted. This property has slightly
     * different meaning for base and remote variants:
     * <ul>
     * <li>base - means it is extracted locally as recorded in the metadata
     * <li>remote - means the remote revision represented by this variant is extracted
     * </ul>
     *
     * @return <code>true</code> if variant is extracted, returns <code>false</code> otherwise
     */
    boolean isExtracted();

    /**
     * This property is only valid for remote resources, indicates if one
     * or more revisions of an item are extracted.
     *
     * @return <code>true</code> if extracted, returns <code>false</code> otherwise
     */
    boolean isAnyExtracted();

    /**
     * This property is only valid for remote variants, indicates if more
     * than revision of an item is extracted.
     *
     * @return <code>true</code> if more than one item revision is currently
     *         extracted, returns <code>false</code> otherwise
     */
    boolean isMultiExtracted();

    /**
     * This property is only valid for remote variants, indicates if
     * one or more revisions of an item are extracted by users other than
     * the current user.
     * @return <code>true</code> if extracted by others, returns <code>false</code> otherwise
     */
    boolean isExtractedOther();

    boolean isExtractedExclusive();

    /**
     * @return <code>true</code> if locally merged, <code>false</code> otherwise or if this variant represents remote (not base)
     */
    boolean isMerged();

    /**
     * Makes sense only for base variants
     * @return revisions local contents was merged from, alphabetically sorted,
     *         guraranteed not to return <code>null</code>
     */
    String[] getMergedFromRevisions();

    /**
     * @return proxy for remote item revision, note that because no server side
     *         validation is done when the proxy is constructed it is possible that
     *         the actual revision may not actually exist
     */
    ItemRevision getItemRevision() throws DMException;

    /**
     * @param itemRevision
     * @return <code>true</code> if this variant is based on the supplied
     *         revision, returns <code>false</code> otherwise
     */
    boolean isBasedOn(ItemRevision itemRevision);

    /**
     *
     * @param path
     */
    void updatePath(IPath path);

    /**
     * This property is only valid for remote variants, indicates if this
     * revision of an item is locked.
     *
     * @return <code>true</code> if item revision is currently
     *         locked, returns <code>false</code> otherwise
     */
    boolean isLocked();

    /**
     * This property is only valid for remote variants, indicates together with isLocked()
     * that revision of an item was locked by user other than
     * the current user.
     *
     * @return <code>true</code> if item revision is locked by user other than the current user,
     *         returns <code>false</code> otherwise
     */
    boolean isLockedOther();

    /**
     * This property is only valid for remote variants, indicates user who locks an item.
     *
     * @return user name
     */
    String getLockUser();

    /**
     * This property is only valid for remote variants, indicates date when an item was locked.
     *
     * @return locked date
     */
    String getLockDate();

    /**
     * Returns cached expand mode flag.
     *
     * @return <code>true</code> if the item was fetched expanded, <code>false</code> otherwise.
     *         Returns null if the item expand mode was not cached.
     */
    Boolean isFetchedExpanded();
}

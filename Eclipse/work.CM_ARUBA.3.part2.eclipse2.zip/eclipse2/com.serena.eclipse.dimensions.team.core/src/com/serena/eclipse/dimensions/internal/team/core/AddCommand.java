/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Creates new items in the repository.
 *
 * @author V.Grishchenko
 */
class AddCommand extends DMWorkspaceCommand1 {

    /**
     * @param dmProject
     * @param requests
     */
    public AddCommand(DMProject dmProject, CreateItemRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, requests.length * 100);
        try {
            for (int i = 0; i < requests.length; i++) {
                CreateItemRequest request = (CreateItemRequest) requests[i];
                request.setWorkset((Project) dmProject.getDimensionsObject());
                requests[i].process(Utils.subMonitorFor(monitor, 100));
                Utils.checkCanceled(monitor);
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

}

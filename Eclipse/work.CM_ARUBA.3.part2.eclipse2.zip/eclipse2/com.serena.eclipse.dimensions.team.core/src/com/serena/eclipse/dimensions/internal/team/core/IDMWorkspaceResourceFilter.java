/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.team.core.TeamException;

/**
 * Filters dimensions workspace resources.
 *
 * @author V.Grishchenko
 */
public interface IDMWorkspaceResourceFilter {

    /**
     * A compound filter that consisting of a set of filters.
     */
    public abstract class CompoundWorkspaceResourceFilter implements IDMWorkspaceResourceFilter {
        protected IDMWorkspaceResourceFilter[] filters;

        public CompoundWorkspaceResourceFilter(IDMWorkspaceResourceFilter[] filters) {
            this.filters = filters == null ? new IDMWorkspaceResourceFilter[0] : filters;
        }
    }

    /**
     * Implements AND-logic, i.e. resource is selected only if it is selected
     * by all contained filters.
     */
    public class AndFilter extends CompoundWorkspaceResourceFilter {
        public AndFilter(IDMWorkspaceResourceFilter[] filters) {
            super(filters);
        }

        @Override
        public boolean select(IDMWorkspaceResource resource) throws TeamException {
            for (int i = 0; i < filters.length; i++) {
                if (!filters[i].select(resource)) {
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * Implements OR-logic, i.e. resource is selected if it is selected by
     * at least one of the contained filters.
     */
    public class OrFilter extends CompoundWorkspaceResourceFilter {
        public OrFilter(IDMWorkspaceResourceFilter[] filters) {
            super(filters);
        }

        @Override
        public boolean select(IDMWorkspaceResource resource) throws TeamException {
            for (int i = 0; i < filters.length; i++) {
                if (filters[i].select(resource)) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * @return <code>true</code> if resource makes through this filter,
     *         returns <code>false</code> otherwise
     */
    boolean select(IDMWorkspaceResource resource) throws TeamException;
}

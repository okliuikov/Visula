/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2007, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DeliverCommandDetails;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.UploadCommandDetails;
import com.serena.dmfile.FileToTransfer;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.sync.Shape;
import com.serena.dmfile.xml.OutgoingMergePoint;
import com.serena.dmfile.xml.Workarea;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Encompasses a collection of resources that can be fed to a single upload
 * command.
 *
 * @author V.Grishchenko
 */
class DeliverBucket extends UploadCommandDetails {
    private List<WorkspaceResourceRequest> contents = new ArrayList<WorkspaceResourceRequest>();
    private boolean sawCreate;
    private boolean sawUpdate;
    private TransferToStreamOperationData opData;
    private Shape shape;

    public DeliverBucket(WorkspaceResourceRequest resourceRequest) {
        internalAdd(resourceRequest);
    }

    public int size() {
        return contents.size();
    }

    public TransferToStreamOperationData getDeliverData() {
        return opData;
    }

    public void setDeliverData(TransferToStreamOperationData opData) {
        this.opData = opData;
    }

    public Shape getShape() {
        return shape;
    }

    public void setShape(Shape shape) {
        this.shape = shape;
    }

    public boolean add(WorkspaceResourceRequest request) {
        internalAdd(request);
        return true;
    }

    private void internalAdd(WorkspaceResourceRequest resourceRequest) {
        contents.add(resourceRequest);
        if (resourceRequest instanceof UploadRequest) {
            UploadRequest request = (UploadRequest) resourceRequest;
            setForceTip(Boolean.valueOf(request.getMode() == UploadRequest.FORCE_TIP));
            setForceCheckin(Boolean.valueOf(request.getMode() == UploadRequest.FORCE_TIP));

            if (getComment() == null) {
                setComment(Utils.getString(request.getParameters().getComment()));
            }

            if (!(sawCreate || sawUpdate) && (request.isCreateItem() || request.isUpdate())) {
                setDescription(request.getParameters().getDescription());
                setRelatedRequests(request.getParameters().getRelatedRequests());
            }

            if (!sawCreate && request.isCreateItem()) {
                setPart(DeliverBucketHelper.getOwningPart(request));
            }

            if (getAttributeMap() == null || getAttributeMap().isEmpty()) {
                int[] attrs = request.getParameters().getAttributes();
                Map<Integer, Object> amap = attrs == null || attrs.length == 0
                        ? Collections.<Integer, Object>emptyMap() : new HashMap<Integer, Object>(attrs.length);
                for (int i = 0; attrs != null && i < attrs.length; i++) {
                    amap.put(new Integer(attrs[i]), request.getParameters().getAttribute(attrs[i]));
                }
                setAttributeMap(amap);
            }

            sawCreate |= request.isCreateItem();
            sawUpdate |= request.isUpdate();
        } else if (resourceRequest instanceof FolderRequest || resourceRequest instanceof ItemRevisionRequest) {
            WorkspaceResourceRequest request = resourceRequest;
            if (request.isRequestSupported()) {
                setRelatedRequests(request.getChangeRequests());
            }
            if (resourceRequest instanceof IMoveRequest) {
                setComment(Utils.getString(((IMoveRequest) resourceRequest).getComment()));
            }
        }
    }

    /**
     * Uploads the contents of this bucket into the specified project
     *
     * @param project
     * @param monitor
     * @return
     * @throws DMException
     */
    public DimensionsResult deliver(final WorksetProject project, boolean isSharing, IProgressMonitor monitor) throws DMException {
        // offset from the workset root to the project folder
        setRelativeLocation(project.getRelativeLocation() != null ? project.getRelativeLocation().toOSString() : null);
        setUserDirectory(project.getUserDirectory().toOSString()); // local path to the project folder
        setForceBranch(Boolean.FALSE);
        setKeep(Boolean.TRUE);
        setVerbose(Boolean.TRUE);
        setXmlMode(Boolean.TRUE);
        setXmlExecute(Boolean.TRUE);
        setUploadRuleset(project.getUploadRuleId() + ':' + String.valueOf(project.getIdeProjectUid()));
        String foreignStream;
        setAll(false); // state depends on the contents only, should be initialized before processing

        Workarea workarea = ObjectToTransfer.scanWorkAreaMetadata(project.getUserDirectory().toOSString());
        List<OutgoingMergePoint> mergePoints = ObjectToTransfer.scanMergePointsMetadata(project.getUserDirectory().toOSString());

        TransferShape transferShape = null;
        TransferToStreamOperationData opData = getDeliverData();
        if (opData != null) {
            transferShape = opData.getTransferShape();
            setShape(transferShape.getShape());
        }

        if (transferShape != null) {
            setScopingDir(project, transferShape);
            DeliverBucketHelper.addIgnoredContributors(mergePoints, opData);
        }

        setWorkarea(workarea);
        setMergePoints(mergePoints);

        final List<FileToTransfer> filesToUpload = new ArrayList<FileToTransfer>(contents.size());
        for (int i = 0; i < contents.size(); i++) {
            WorkspaceResourceRequest request = contents.get(i);
            String resPath = request.getResource().getLocation().toOSString();
            if (request instanceof DeleteItemRevisionRequest) {
                // check if container folder was moved (renamed)
                // if so, path will be a new renamed folder for deleted item
                IResource parentRes = request.getResource().getParent();
                try {
                    IResource movedToRes = DMTeamPlugin.getWorkspace().getMovedTo(parentRes);
                    if (movedToRes != null) {
                        resPath = movedToRes.getLocation().append(request.getResource().getName()).toOSString();
                    }
                } catch (CoreException e) {
                }
            }
            FileToTransfer fileToUpload = ObjectToTransfer.scanSingleFileEx(resPath);

            if (request.getResource().getType() == IResource.FILE) {
                fileToUpload.setResourceType("file");
                if (request instanceof UploadRequest) {
                    UploadRequest uploadRequest = (UploadRequest) request;
                    IUploadRequestParameters parameters = uploadRequest.getParameters();
                    if (parameters != null) {
                        fileToUpload.setFileEncoding(parameters.getCharset());
                    }
                }
            } else if (request.getResource().getType() == IResource.FOLDER) {
                fileToUpload.setResourceType("folder");
            }

            // Needed as the metadata scans returns this as an addition if there is no file and no metadata
            if (request instanceof DeleteItemRevisionRequest || request instanceof DeleteFolderRequest) {
                fileToUpload.setDiffType(ObjectToTransfer.DELETION);
                fileToUpload.setDeletionType("from-project");
            }

            filesToUpload.add(fileToUpload);
            foreignStream = DeliverBucketHelper.getStream(request.getResource());
            // Check for Global workset is added in the below if clause because when you do a "Mark as merged" the project in the
            // metadata file is set as $GLOBAL:$GENERAL and not the actual project of the item being marked as merged
            // So we need to exclude $GLOBAL:$GENERAL from the list of foreign streams

            // KB> DEF211040 fix - enable delivering baseline contents by using /ALL instead of /CONTRIB=()
            // KB> We use /ALL as a shortcut to deliver resources from all the streams except those deselected on
            // RunAndProcessStreamSelectDialog and all the baselines.
            if (!getAll() && foreignStream != null && !foreignStream.equals(project.getId())) {
                setAll(true);
            } else if (!getAll() && DeliverBucketHelper.isBaseline(request.getResource())) {
                setAll(true);
            }
        }
        setFilesToTransfer(filesToUpload);

        final DimensionsResult[] resultHolder = new DimensionsResult[1];
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            Session session = project.getConnection().openSession(Utils.subMonitorFor(monitor, 50));
            TransferMonitor tMonitor = new TransferMonitor(Utils.subMonitorFor(monitor, 950), TransferMonitor.UP);
            setListener(tMonitor);
            setCancelMonitor(tMonitor);
            String msg = filesToUpload.size() == 1
                    ? NLS.bind(Messages.DeliverBucket_1, String.valueOf(filesToUpload.size())) : NLS.bind(Messages.DeliverBucket_0,
                            String.valueOf(filesToUpload.size()));
            session.run(new APIOperation(msg) {
                @Override
                protected DimensionsResult doRun() throws Exception {
                    resultHolder[0] = project.getWorkset().deliver(getDeliverDetails(DeliverBucket.this));

                    // TODO VG on Jul 26, 2007: better to print individual messages to console
                    // directly but this is slow in 3.0, may need to reconsider after 3.0 support
                    // is no longer necessary, for now assemble all messages into a big string and
                    // send it up as final result
                    return assembleResult(resultHolder[0]);
                }
            }, monitor);
            DeliverBucketHelper.manageMetadataAfterDeliver(contents);
            return resultHolder[0];
        } finally {
            monitor.done();
        }
    }

    // dir scope makes sense only for TREE shape
    private void setScopingDir(final WorksetProject project, TransferShape deliverShape) {
        if (deliverShape.getShape() == Shape.TREE) {
            IResource resource = deliverShape.getScopes().get(0);
            if (project.isContainedEclipseProject() && project.isFullWorkArea()) {
                setDirectory(project.getRemotePathForLocalResource(resource).toOSString());
            } else {
                setDirectory(resource.getProjectRelativePath().toOSString());
            }
        }
    }

    private DeliverCommandDetails getDeliverDetails(DeliverBucket uploadDetails) {
        DeliverCommandDetails deliverDetails = new DeliverCommandDetails();
        deliverDetails.setAttributeMap(uploadDetails.getAttributeMap());
        deliverDetails.setCacheFiles(uploadDetails.getCacheFiles());
        deliverDetails.setCancelMonitor(uploadDetails.getCancelMonitor());
        deliverDetails.setCancelUnchanged(uploadDetails.getCancelUnchanged());
        deliverDetails.setCheckConflict(uploadDetails.getCheckConflict());
        deliverDetails.setCodePage(uploadDetails.getCodePage());
        deliverDetails.setComment(uploadDetails.getComment());
        deliverDetails.setContentEncoding(uploadDetails.getContentEncoding());
        deliverDetails.setDescription(uploadDetails.getDescription());
        deliverDetails.setDirectory(uploadDetails.getDirectory());
        deliverDetails.setFileCachesize(uploadDetails.getFileCachesize());
        deliverDetails.setFilesToTransfer(uploadDetails.getFilesToTransfer());
        deliverDetails.setFilter(uploadDetails.getFilter());
        deliverDetails.setIgnoreErrors(uploadDetails.getIgnoreErrors());
        deliverDetails.setListener(uploadDetails.getListener());
        deliverDetails.setLogFile(uploadDetails.getLogFile());
        deliverDetails.setPart(uploadDetails.getPart());
        deliverDetails.setPerms(uploadDetails.getPerms());
        deliverDetails.setRecursive(uploadDetails.getRecursive());
        deliverDetails.setRelatedRequests(uploadDetails.getRelatedRequests());
        deliverDetails.setRelativeLocation(uploadDetails.getRelativeLocation());
        deliverDetails.setUploadRuleset(uploadDetails.getUploadRuleset());
        deliverDetails.setUserDirectory(uploadDetails.getUserDirectory());
        deliverDetails.setVerbose(uploadDetails.getVerbose());
        deliverDetails.setXmlExecute(uploadDetails.getXmlExecute());
        deliverDetails.setXmlMode(uploadDetails.getXmlMode());
        deliverDetails.setAll(uploadDetails.getAll());
        deliverDetails.setWorkarea(uploadDetails.getWorkarea());
        deliverDetails.setMergePoints(uploadDetails.getMergePoints());
        deliverDetails.setXmlShape(uploadDetails.getShape());

        return deliverDetails;
    }

    private DimensionsResult assembleResult(DimensionsResult result) {
        if (result.getResultList() == null) {
            return result;
        }

        StringBuffer buf = new StringBuffer();
        for (Iterator<?> rIter = result.getResultList().iterator(); rIter.hasNext();) {
            FileToTransfer fileResult = (FileToTransfer) rIter.next();
            List<String> commands = fileResult.getCommands();
            if (commands != null) {
                for (Iterator<String> cIter = commands.iterator(); cIter.hasNext();) {
                    String command = cIter.next();
                    if (!Utils.isNullEmpty(command)) {
                        buf.append(command);
                        if (command.charAt(command.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
            List<String> messages = fileResult.getMessages();
            if (messages != null) {
                for (Iterator<String> mIter = messages.iterator(); mIter.hasNext();) {
                    String message = mIter.next();
                    if (!Utils.isNullEmpty(message)) {
                        buf.append(message);
                        if (message.charAt(message.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
        }
        return new DimensionsResult(buf.toString());
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer("[Deliver Bucket]\n"); //$NON-NLS-1$
        buf.append(contents.size() + " files:\n"); //$NON-NLS-1$
        for (int i = 0; i < contents.size(); i++) {
            WorkspaceResourceRequest request = contents.get(i);
            IResource res = request.getResource();
            if (i > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(res.getLocation().toOSString());
        }
        buf.append("\nForceTip=").append(getForceTip()).append('\n'); //$NON-NLS-1$
        buf.append("ForceCheckin=").append(getForceCheckin()).append('\n'); //$NON-NLS-1$
        buf.append("Comment=").append(getComment()).append('\n'); //$NON-NLS-1$
        buf.append("Description=").append(getDescription()).append('\n'); //$NON-NLS-1$
        buf.append("Requests=").append(getRelatedRequests()).append('\n'); //$NON-NLS-1$
        buf.append("Part=").append(getPart()).append('\n'); //$NON-NLS-1$
        buf.append("ContentEncoding=").append(getContentEncoding()).append('\n'); //$NON-NLS-1$
        buf.append("CancelUnchanged=").append(getCancelUnchanged()).append('\n'); //$NON-NLS-1$
        buf.append("Attributes:\n"); //$NON-NLS-1$
        Map<?, ?> attrMap = getAttributeMap();
        int cnt = 0;
        for (Iterator<?> iter = attrMap.entrySet().iterator(); iter.hasNext();) {
            Map.Entry<?, ?> entry = (Entry<?, ?>) iter.next();
            if (cnt > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(entry.getKey()).append('=').append(entry.getValue());
            cnt++;
        }
        buf.append("\n[/Deliver Bucket]"); //$NON-NLS-1$
        return buf.toString();
    }

}
package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.internal.resources.Container;
import org.eclipse.core.internal.resources.Resource;
import org.eclipse.core.internal.resources.ResourceInfo;
import org.eclipse.core.internal.resources.Workspace;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.ResourceVariantByteStore;

import com.serena.eclipse.dimensions.core.util.Assert;

public class CustomByteStore extends ResourceVariantByteStore {

    private Map byteCache = new HashMap();
    private Map deleteFlagCache;
    private Map memberCache = new HashMap();

    private static final byte[] NO_REMOTE = new byte[0];

    public CustomByteStore() {
        this(null, new ArrayList());
    }

    public CustomByteStore(Map resourceMap) {
        this(resourceMap, new ArrayList());
    }

    public CustomByteStore(Map resourceMap, List deleteList) {
        if (resourceMap != null) {
            Iterator iter = resourceMap.keySet().iterator();
            while (iter.hasNext()) {
                IResource resource = (IResource) iter.next();
                IResourceVariant resourceVariant = (IResourceVariant) resourceMap.get(resource);
                internalSetBytes(resource.getFullPath(), resourceVariant.asBytes());
            }
        }
        if (deleteList != null) {
            deleteFlagCache = new HashMap();
            Iterator iter = deleteList.iterator();
            while (iter.hasNext()) {
                IResource resource = (IResource) iter.next();
                if (internalGetBytes(resource.getFullPath()) != null) {
                    internalPrepareForDeletion(resource.getFullPath());
                }
            }
        }

    }

    @Override
    public synchronized boolean deleteBytes(IResource resource) throws TeamException {
        return flushBytes(resource, IResource.DEPTH_ZERO);
    }

    @Override
    public synchronized void dispose() {
        byteCache.clear();
        memberCache.clear();
        if (deleteFlagCache != null) {
            deleteFlagCache.clear();
        }
    }

    @Override
    public synchronized boolean flushBytes(IResource resource, int depth) throws TeamException {
        return flushBytes(resource, depth, false);
    }

    public synchronized boolean flushBytes(IResource resource, int depth, boolean force) {
        IPath path = resource.getFullPath();
        if (force || deleteFlagCache == null || deleteFlagCache.containsKey(path)) {
            if (byteCache.containsKey(path)) {
                byteCache.remove(path);
                internalRemoveFromParent(path);
                if (deleteFlagCache != null) {
                    deleteFlagCache.remove(path);
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public synchronized byte[] getBytes(IResource resource) throws TeamException {
        byte[] syncBytes = internalGetBytes(resource.getFullPath());
        if (syncBytes != null && equals(syncBytes, NO_REMOTE)) {
            // If it is known that there is no remote, return null
            return null;
        }
        return syncBytes;
    }

    @Override
    public synchronized boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
        Assert.isNotNull(bytes);
        byte[] oldBytes = internalGetBytes(resource.getFullPath());
        if (oldBytes != null && equals(oldBytes, bytes)) {
            return false;
        }

        Workspace workspace = (Workspace) ResourcesPlugin.getWorkspace();
        try {
            workspace.prepareOperation(resource, null);
            workspace.beginOperation(true);

            // we do not store sync info on the workspace root
            if (resource.getType() == IResource.ROOT) {
                return false;
            }
            // if the resource doesn't yet exist then create a phantom so we can set the sync info on it
            Resource target = (Resource) resource;

            ResourceInfo resourceInfo = workspace.getResourceInfo(target.getFullPath(), true, false);
            int flags = target.getFlags(resourceInfo);
            if (!target.exists(flags, false)) {
                if (bytes == null) {
                    return false;
                }
                // ensure it is possible to create this resource
                target.checkValidPath(target.getFullPath(), target.getType(), false);
                Container parent = (Container) target.getParent();
                parent.checkAccessible(parent.getFlags(parent.getResourceInfo(true, false)));
                workspace.createResource(target, true);
            }
            workspace.endOperation(resource, false);

            return internalSetBytes(resource.getFullPath(), bytes);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
    }

    @Override
    public synchronized IResource[] members(IResource resource) throws TeamException {
        Collection members = (Collection) memberCache.get(resource.getFullPath());
        if (members == null) {
            return new IResource[0];
        }

        ArrayList result = new ArrayList(members.size());
        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        for (Iterator iter = members.iterator(); iter.hasNext();) {
            // try to use the workspace to resolve path to resource type,
            // if that fails rely on the remote resource type stored in bytes
            IPath memberPath = (IPath) iter.next();
            IResource member = root.findMember(memberPath, true);
            if (member == null) {
                byte[] bytes = internalGetBytes(memberPath);
                if (bytes != null) {
                    if (DMRemoteResource.getResourceType(bytes) == IResource.FILE) {
                        member = root.getFile(memberPath);
                    } else {
                        member = root.getFolder(memberPath);
                    }
                }
            }
            if (member != null) {
                result.add(member);
            }
        }
        return (IResource[]) result.toArray(new IResource[result.size()]);
    }

    public synchronized void prepareForDeletion(IResource resource) throws TeamException {
        internalPrepareForDeletion(resource.getFullPath());
    }

    private byte[] internalGetBytes(IPath resourcePath) {
        return (byte[]) byteCache.get(resourcePath);
    }

    private boolean internalSetBytes(IPath resourcePath, byte[] bytes) {
        byteCache.put(resourcePath, bytes);
        internalAddToParent(resourcePath);
        return true;
    }

    private void internalPrepareForDeletion(IPath resourcePath) {
        if (deleteFlagCache != null) {
            deleteFlagCache.put(resourcePath, Boolean.TRUE);
        }
    }

    private void internalAddToParent(IPath resourcePath) {
        if (resourcePath.segmentCount() < 2) {
            return; // 1-project, 2-folder or a file
        }
        IPath parentPath = resourcePath.removeLastSegments(1);
        Set members = (Set) memberCache.get(parentPath);
        if (members == null) {
            members = new HashSet();
            memberCache.put(parentPath, members);
        }
        members.add(resourcePath);
    }

    private void internalRemoveFromParent(IPath resourcePath) {
        if (resourcePath.segmentCount() < 2) {
            return;
        }
        IPath parentPath = resourcePath.removeLastSegments(1);
        Set members = (Set) memberCache.get(parentPath);
        if (members == null) {
            return;
        }
        members.remove(resourcePath);
        if (members.isEmpty()) {
            memberCache.remove(parentPath);
        }
    }

}

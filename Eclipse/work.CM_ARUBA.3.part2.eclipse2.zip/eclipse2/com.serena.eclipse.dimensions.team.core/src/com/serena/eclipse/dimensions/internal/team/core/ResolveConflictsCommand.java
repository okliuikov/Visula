/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.SortedSet;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class ResolveConflictsCommand extends DMWorkspaceCommand1 {
    private boolean checkoutsUpdated = false;

    public ResolveConflictsCommand(DMProject dmProject, ResolveConflictRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    public boolean modifiesRemote() {
        return checkoutsUpdated; // refresh remote only if any checkouts moved
    }

    @Override
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        try {
            // DEF146784 - ensure the rule includes the first existing managed resource up the hierarchy
            // as metadata refresh will start from the topmost non-existing resource and default
            // refresh rule is its parent per ResourceRuleFactory.refreshRule()
            IResource resource = request.getResource();
            IResource parent = TeamUtils.parent(resource);
            IResource firstManagedAncestor = TeamUtils.findDeepestManagedResource(parent);
            while (firstManagedAncestor.getType() != IResource.PROJECT && !firstManagedAncestor.exists()) {
                firstManagedAncestor = firstManagedAncestor.getParent();
            }
            rules.add(firstManagedAncestor);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, requests.length * 100);
        try {
            for (int i = 0; i < requests.length; i++) {
                ResolveConflictRequest resolveConflictRequest = (ResolveConflictRequest) requests[i];
                resolveConflictRequest.process(Utils.subMonitorFor(monitor, 100));
                checkoutsUpdated |= resolveConflictRequest.isCheckoutUpdated();
                if (!resolveConflictRequest.getStatus().isOK()) {
                    addError(resolveConflictRequest.getStatus());
                }
                Utils.checkCanceled(monitor);
            }
        } finally {
            monitor.done();
        }
    }

}

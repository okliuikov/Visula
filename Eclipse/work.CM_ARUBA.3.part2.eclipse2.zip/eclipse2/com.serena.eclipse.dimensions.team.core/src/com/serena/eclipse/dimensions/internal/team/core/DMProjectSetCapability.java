/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.team.core.ProjectSetCapability;
import org.eclipse.team.core.ProjectSetSerializationContext;
import org.eclipse.team.core.TeamException;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;

/*
 * @author V.Grishchenko
 */
class DMProjectSetCapability extends ProjectSetCapability {
    private static final int VERSION_1 = 1;
    private static final int CURRENT_VERSION = VERSION_1;

    public DMProjectSetCapability() {
    }

    /*
     * Each reference is hex-encoded binary data containing:
     * 1. reference version
     * 2. local project name
     * 3. local mount point (currently always empty)
     * 4. hostname
     * 5. db
     * 6. db connection
     * 7. remote project id
     * 8. remote project type (project/baseline)
     * 9. remote offset
     */
    @Override
    public String[] asReference(IProject[] providerProjects, ProjectSetSerializationContext context, IProgressMonitor monitor)
            throws TeamException {
        if (providerProjects == null || providerProjects.length == 0) {
            return Utils.ZERO_LENGTH_STRING_ARRAY;
        }
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN); // operation is quick but follow the monitor protocol nevertheless
        String[] result = new String[providerProjects.length];
        try {
            for (int i = 0; i < providerProjects.length; i++) {
                result[i] = serializeProject(providerProjects[i], DMTeamPlugin.getWorkspace().getProject(providerProjects[i]));
            }
        } catch (CoreException ce) {
            throw TeamException.asTeamException(ce);
        } catch (IOException ioe) {
            throw new TeamException(DMTeamStatus.createErrorStatus(0, Messages.DMProjectSetCapability_0, ioe));
        } finally {
            monitor.done();
        }
        return result;
    }

    @Override
    public IProject[] addToWorkspace(String[] referenceStrings, ProjectSetSerializationContext context, IProgressMonitor monitor)
            throws TeamException {
        if (referenceStrings == null || referenceStrings.length == 0) {
            return new IProject[0];
        }
        ArrayList infos = new ArrayList(referenceStrings.length);
        ArrayList projects = new ArrayList(referenceStrings.length);
        try {
            for (int i = 0; i < referenceStrings.length; i++) {
                DMProjectLoadInfo loadInfo = deserializeProject(referenceStrings[i]);
                if (loadInfo != null) {
                    infos.add(loadInfo);
                    projects.add(loadInfo.getLocalProject());
                }
            }
        } catch (IOException ioe) {
            throw new TeamException(DMTeamStatus.createErrorStatus(0, Messages.DMProjectSetCapability_1, ioe));
        }
        if (infos.isEmpty()) {
            return new IProject[0];
        }
        IProject[] projectsToImport = confirmOverwrite(context, (IProject[]) projects.toArray(new IProject[projects.size()]));
        if (projectsToImport == null) {
            return new IProject[0];
        }
        if (projectsToImport.length == 0) {
            return projectsToImport;
        }
        List list = Arrays.asList(projectsToImport);
        for (Iterator infoIter = infos.iterator(); infoIter.hasNext();) {
            DMProjectLoadInfo loadInfo = (DMProjectLoadInfo) infoIter.next();
            if (!list.contains(loadInfo.getLocalProject())) {
                infoIter.remove();
            }
        }
        return addToWorkspace((DMProjectLoadInfo[]) infos.toArray(new DMProjectLoadInfo[infos.size()]), context, monitor);
    }

    private IProject[] addToWorkspace(DMProjectLoadInfo[] loadInfos, ProjectSetSerializationContext context,
            IProgressMonitor monitor) throws TeamException {
        IProjectSetImportHandler handler = DMTeamPlugin.getDefault().getPluggedInImportHandler();
        if (handler == null) {
            throw new TeamException(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMProjectSetCapability_2));
        }
        try {
            return handler.addToWorkspace(loadInfos, context, monitor);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
    }

    private String serializeProject(IProject project, IDMProject dmProject) throws IOException {
        if (dmProject == null) {
            return Utils.EMPTY_STRING;
        }
        // project id may have unusual chars -> don't want to deal with escapes -> use binary
        ByteArrayOutputStream byteAccumulator = new ByteArrayOutputStream();
        DataOutputStream dataOut = new DataOutputStream(byteAccumulator);
        dataOut.writeInt(CURRENT_VERSION);
        // local params
        dataOut.writeUTF(project.getName());
        dataOut.writeUTF(dmProject.getProjectRelativePath().toString());
        // remote params
        DimensionsConnectionDetailsEx connection = dmProject.getConnection();
        dataOut.writeUTF(connection.getServer());
        dataOut.writeUTF(connection.getDbName());
        dataOut.writeUTF(connection.getDbConn());
        dataOut.writeUTF(dmProject.getId());
        dataOut.writeInt(dmProject.getType());
        dataOut.writeUTF(dmProject.getRemoteOffset().toString());
        dataOut.flush();
        return Utils.hexEncode(byteAccumulator.toByteArray(), false);
    }

    private DMProjectLoadInfo deserializeProject(String hexData) throws IOException {
        byte[] bytes = Utils.hexDecode(hexData);
        DataInputStream dataIn = new DataInputStream(new ByteArrayInputStream(bytes));
        int version = dataIn.readInt();
        if (version != CURRENT_VERSION) {
            return null;
        }
        DMProjectLoadInfo result = new DMProjectLoadInfo();
        result.localProject = ResourcesPlugin.getWorkspace().getRoot().getProject(dataIn.readUTF());
        result.localPath = new Path(dataIn.readUTF());
        result.server = dataIn.readUTF();
        result.dbName = dataIn.readUTF();
        result.dbConnection = dataIn.readUTF();
        result.remoteProjectId = dataIn.readUTF();
        result.remoteProjectType = dataIn.readInt();
        result.remotePath = new Path(dataIn.readUTF());
        dataIn.close();
        return result;
    }

}

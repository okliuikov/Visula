package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.io.File;

import com.serena.dmfile.IResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;

class DerivedResourceFilter implements IResourceFilter {
    private boolean derivedResourcesIgnored;

    public DerivedResourceFilter(boolean derivedResourcesIgnored) {
        this.derivedResourcesIgnored = derivedResourcesIgnored;
    }

    @Override
    public boolean accept(File pathname) {
        if (!derivedResourcesIgnored) {
            return true;
        } else {
            IDMWorkspace idmWorkspace = DMTeamPlugin.getWorkspace();
            return !idmWorkspace.isDerivedAndUnmanaged(pathname);
        }
    }
}

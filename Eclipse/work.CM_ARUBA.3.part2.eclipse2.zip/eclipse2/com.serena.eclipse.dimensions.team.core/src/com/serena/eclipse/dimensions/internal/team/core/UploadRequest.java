/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.util.Encoding;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsConnectionException;
import com.serena.dmclient.api.DimensionsNetworkException;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.DimensionsRuntimeException;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.objects.AttributeDefinition;
import com.serena.dmclient.objects.Type;
import com.serena.dmfile.FileToTransfer;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class UploadRequest extends FileRequest {
    public static final int DEFAULT = 0;
    // public static final int BRANCH = 1;
    public static final int FORCE_TIP = 2;

    private IDMProject project;
    private int mode = DEFAULT;
    private IUploadRequestParameters parameters;
    private IStatus status = Status.OK_STATUS;
    private boolean undoCheckout;
    private boolean checkout;

    public UploadRequest(IFile file) throws CoreException {
        super(file);
    }

    public UploadRequest(IFile file, IUploadRequestParameters parameters) throws CoreException {
        super(file);
        this.parameters = parameters;
    }

    /**
     * @return <code>true</code> if this is a request to create a new item
     */
    public boolean isCreateItem() {
        return parameters instanceof CreateItemRequest;
    }

    /**
     * @return <code>true</code> if this is a request to perform a pessimistic checkin
     */
    public boolean isCheckin() {
        return parameters instanceof CheckinRequest;
    }

    /**
     * @return <code>true</code> if this a request to perform an optimistic checkin
     */
    public boolean isUpdate() {
        return parameters instanceof UpdateRevisionRequest;
    }

    public void setParameters(IUploadRequestParameters parameters) {
        this.parameters = parameters;
    }

    public IUploadRequestParameters getParameters() {
        return parameters;
    }

    public void setCheckout(boolean checkout) {
        this.checkout = checkout;
    }

    public boolean isCheckout() {
        return checkout;
    }

    /**
     * @return Returns the status.
     */
    public IStatus getStatus() {
        return status;
    }

    /**
     * Sets whether or not the local file should be made read only after successful upload.
     */
    public void setReadOnly(boolean b) {
        if (parameters != null) {
            parameters.setReadOnly(b);
        }
    }

    public void setMode(int mode) {
        Assert.isLegal(mode == DEFAULT || /* mode == BRANCH || */mode == FORCE_TIP);
        this.mode = mode;
    }

    /**
     * Sets a boolean to control if checkout will be cancelled for resources without changes.
     * @param b <code>true</code> to undo checkout, <code>false</code> to halt checkin
     */
    public void setUndoCheckout(boolean b) {
        this.undoCheckout = b;
    }

    public boolean isUndoCheckout() {
        return undoCheckout;
    }

    public int getMode() {
        return mode;
    }

    public void setComment(String comment) {
        if (parameters != null) {
            parameters.setComment(comment);
        }
    }

    public void setAttributes(int[] attrs) {
        if (parameters != null) {
            parameters.setAttributes(attrs);
        }
    }

    void setProject(IDMProject project) {
        this.project = project;
    }

    @Override
    protected String getMessage() {
        return ((WorkspaceResourceRequest) parameters).getMessage();
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        // TODO VG on Jul 26, 2006: provide more granular progress reporting
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            DimensionsResult result = null;
            IFile local = getFile();
            FileToTransfer fileToUpload = ObjectToTransfer.scanSingleFileEx(local.getLocation().toOSString());
            if (fileToUpload != null) { // play safe
                IPath userDir = ((DMProject) project).getUserDirectory();
                IPath remoteOffset = ((DMProject) project).getRemoteOffset();
                List list = ((Project) project.getDimensionsObject()).upload(Collections.singletonList(fileToUpload),
                        remoteOffset.toOSString(),
                        false /* forceBranch */,
                        mode == FORCE_TIP /* forceTip */,
                        mode == FORCE_TIP /* forceCheckin */,
                        // undoCheckout, /* cancelUnchanged */
                        parameters.getComment() == null ? Utils.EMPTY_STRING : parameters.getComment(), null /* description */,
                        true /* keep */, getAttributesAsString(getRevision(), Utils.subMonitorFor(monitor, 5)) /* attrs */,
                        null /* codePage */, getRelatedRequestsAsString() /* requests */, null /* part */, null /* logFile */,
                        userDir.toOSString(), parameters.getCharset(), true /* verbose */);
                fileToUpload = (FileToTransfer) list.get(0);

                if (fileToUpload.getStatus().equals(ObjectToTransfer.STATUS_RESOLVED)) {
                    try {
                        if (fileToUpload.getDiffType() == ObjectToTransfer.ADDITION) {
                            // for add cannot specify item type via upload - use createItem via object factory
                            // note that this shouldn't normally happen in the integration as add is done via IDMProject.add()
                            result = ((WorkspaceResourceRequest) parameters).execute(session, monitor);
                        } else {
                            if (parameters instanceof UpdateRevisionRequest && ((UpdateRevisionRequest) parameters).isMerge()) {
                                // merges are handled via update revision
                                ((UpdateRevisionRequest) parameters).execute(session, new NullProgressMonitor());
                            } else {
                                List<String> cmds = fileToUpload.getCommands();
                                for (Iterator<String> iter = cmds.iterator(); iter.hasNext();) {
                                    String aCmd = iter.next();
                                    DMPlugin.getDefault().getConsole().printMessage(aCmd);
                                    result = session.getObjectFactory().runCommand(aCmd);
                                }
                                TeamUtils.setReadOnly(local, parameters.isReadOnly());
                            }
                        }
                    } catch (DimensionsNetworkException ne) {
                        throw ne; // fail when no network
                    } catch (DimensionsConnectionException ce) {
                        throw ce; // fail when no network
                    } catch (DimensionsRuntimeException e) {
                        String msg = e.getMessage();
                        if (Utils.isNullEmpty(msg)) {
                            msg = Messages.UploadRequest_unknownError;
                        }
                        status = new DMTeamStatus(IStatus.ERROR, 0, msg, e);
                        result = new DimensionsResult(msg);
                    }
                } else if (fileToUpload.getStatus().equals(ObjectToTransfer.STATUS_UNRESOLVED)) {
                    status = new DMTeamStatus(IStatus.ERROR, 0, fileToUpload.getMessage(), null);
                    result = new DimensionsResult(fileToUpload.getMessage());
                } else if (fileToUpload.getStatus().equals(ObjectToTransfer.STATUS_ERROR)) {
                    throw new DMException(new DMTeamStatus(IStatus.ERROR, 0, fileToUpload.getMessage(), null));
                } else if (fileToUpload.getStatus().equals(ObjectToTransfer.STATUS_IGNORED)) {
                    status = new DMTeamStatus(IStatus.WARNING, 0, fileToUpload.getMessage(), null);
                    result = new DimensionsResult(fileToUpload.getMessage());
                }
            } else { // failed to read metadata?
                String msg = NLS.bind(Messages.UploadRequest_metadataError, local.getFullPath().toString());
                status = new DMTeamStatus(IStatus.ERROR, 0, msg, null);
                result = new DimensionsResult(msg);
            }
            return result == null ? new DimensionsResult(Messages.ok) : result;
        } finally {
            monitor.done();
        }
    }

    private String getRelatedRequestsAsString() {
        List relatedRequests = parameters.getRelatedRequests();
        if (relatedRequests == null || relatedRequests.isEmpty()) {
            return null;
        }
        String[] quoted = new String[relatedRequests.size()];
        for (int i = 0; i < quoted.length; i++) {
            quoted[i] = "\"" + (String) relatedRequests.get(i) + "\""; //$NON-NLS-1$ //$NON-NLS-2$
        }
        return Utils.toCsvString(quoted, false);
    }

    private String getAttributesAsString(ItemRevision revision, IProgressMonitor monitor) throws DMException {
        if (revision == null) {
            return null;
        }
        int[] attrs = parameters.getAttributes();
        if (attrs == null || attrs.length == 0) {
            return null;
        }
        monitor.beginTask(null, 10);
        Type type = getConnection().getType(revision, Utils.subMonitorFor(monitor, 5));
        AttributeDefinition[] defs = getConnection().getAttributeDefinitions(type, IDMConstants.ROLE_SECTION_ALL, false,
                Utils.subMonitorFor(monitor, 5));
        monitor.done();
        HashMap<Integer, String> numberToName = new HashMap<Integer, String>();
        for (int i = 0; i < defs.length; i++) {
            int number = defs[i].getNumber();
            String name = defs[i].getName();
            numberToName.put(new Integer(number), name);
        }
        ArrayList<String> nameValPairs = new ArrayList<String>();
        for (int i = 0; i < attrs.length; i++) {
            int attrNum = attrs[i];
            String name = numberToName.get(new Integer(attrNum));
            if (name != null) {
                Object value = parameters.getAttribute(attrNum);
                String aPair = name + "=" + getAttributeValueAsString(value); //$NON-NLS-1$
                nameValPairs.add(aPair);
            }
        }
        String[] arr = nameValPairs.toArray(new String[nameValPairs.size()]);
        return Utils.toCsvString(arr, false);
    }

    private String getAttributeValueAsString(Object val) {
        if (val instanceof String) {
            return Encoding.escapeDMCLI((String) val);
        }
        if (val instanceof Integer) {
            return Encoding.escapeDMCLI(val.toString());
        }
        if (val instanceof List) {
            StringBuffer buf = new StringBuffer();
            buf.append('[');
            for (Iterator<?> iter = ((List<?>) val).iterator(); iter.hasNext();) {
                Object aVal = iter.next();
                buf.append(getAttributeValueAsString(aVal)).append(',');
            }
            buf.append(']');
            return buf.toString();
        }
        return "\"\""; //$NON-NLS-1$
    }

    private ItemRevision getRevision() {
        if (parameters instanceof UpdateRevisionRequest) {
            return ((UpdateRevisionRequest) parameters).getRevision();
        }
        if (parameters instanceof CheckinRequest) {
            return ((CheckinRequest) parameters).getItemRevision();
        }
        return null;
    }

    @Override
    public boolean isRequestsMandatory() {
        if (parameters instanceof WorkspaceResourceRequest) {
            return ((WorkspaceResourceRequest) parameters).isRequestsMandatory();
        }
        return false;
    }

    @Override
    public boolean isRequestSupported() {
        if (parameters instanceof WorkspaceResourceRequest) {
            return ((WorkspaceResourceRequest) parameters).isRequestSupported();
        }
        return false;
    }

    @Override
    public int getKind() {
        if (parameters instanceof WorkspaceResourceRequest) {
            return ((WorkspaceResourceRequest) parameters).getKind();
        }
        return 0;
    }

    @Override
    public List<String> getChangeRequests() {
        if (parameters instanceof WorkspaceResourceRequest) {
            return ((WorkspaceResourceRequest) parameters).getChangeRequests();
        }
        return Collections.emptyList();
    }

}

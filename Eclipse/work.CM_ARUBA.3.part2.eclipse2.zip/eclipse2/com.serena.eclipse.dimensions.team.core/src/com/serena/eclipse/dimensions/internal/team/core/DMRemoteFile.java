/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;

import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.ExpandMode;

/**
 * Remote file implementation.
 *
 * @author V.Grishchenko
 */
class DMRemoteFile extends DMRemoteResource implements IDMRemoteFile {
    private static final int EXTRACTED = 0x00000001;
    private static final int EXTRACTED_ANY = 0x00000002;
    private static final int EXTRACTED_OTHER = 0x00000004;
    private static final int EXTRACTED_MULTI = 0x00000008;
    private static final int EXTRACTED_EXCLUSIVE = 0x00000010;
    private static final int READ_ONLY = 0x00000020;
    private static final int LOCKED_FILE = 0x00000040;
    private static final int LOCKED_FILE_OTHER = 0x00000080;

    // @formatter:off
    static final int[] RESOURCE_VARIANT_ATTRS_FILE = new int[] {
        SystemAttributes.OBJECT_SPEC,
        SystemAttributes.OBJECT_UID,
        SystemAttributes.IS_EXTRACTED,
        SystemAttributes.FULL_PATH_NAME,
        SystemAttributes.UTC_MODIFIED_DATE,
        SystemAttributes.FILE_VERSION,
        SystemAttributes.ITEM_LIB_FILE_VERSION,
        SystemAttributes.IS_LOCKED,
        SystemAttributes.LOCKED_USER,
        SystemAttributes.LOCKED_DATE };
    // @formatter:on
    
    private static final byte VERSION_2 = 2; // adds item revision uid
    private static final byte VERSION_3 = 3; // add lockedby & lockeddate
    private static final byte VERSION_4 = 4; // timestamp written/read as byte flag
    private static final byte VERSION_5 = 5; // project/baseline uid and project version
    private static final byte VERSION_6 = 6; // item lib_version
    private static final byte BYTES_VERSION = VERSION_6; // ensure we have a way to know what's stored

    private String itemSpec;
    private long uid = IDMConstants.INVALID_UID; // invalid initially
    private String itemSpecId = Utils.EMPTY_STRING; // PRODUCT:ITEM-ID
    private String revision = Utils.EMPTY_STRING;
    private String lockUser = Utils.EMPTY_STRING;
    private String lockDate = Utils.EMPTY_STRING;
    // private boolean extracted;
    private int version;
    private int lib_version;
    private long modtime;
    private String mdRelPath = Utils.EMPTY_STRING;
    private long mdProjectVer = IDMConstants.INVALID_UID;
    private long mdProjectUid = IDMConstants.INVALID_UID;
    private long mdBaselineUid = IDMConstants.INVALID_UID;
    private String[] mergedFromRevisions = Utils.ZERO_LENGTH_STRING_ARRAY;
    private ItemRevision revisionHandle;
    private ItemMetadata metadata;
    
    // Map of registered expand mode flags indexed by cachePath
    // String (cachePath) -> Enum (expand mode flag)
    private static Map<String, ExpandMode> expandModeCache = new HashMap<String, ExpandMode>();

    public DMRemoteFile(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree tree, ItemRevision repositoryFile) {
        super(parent, path, project, tree);
        fromRepositoryFile(repositoryFile);
    }

    public DMRemoteFile(IPath path, DimensionsConnectionDetailsEx connection, ItemRevision repositoryFile) {
        super(path, connection);
        fromRepositoryFile(repositoryFile);
    }

    public DMRemoteFile(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree tree, byte[] bytes) throws IOException {
        super(parent, path, project, tree);
        fromBytes(bytes);
    }

    public DMRemoteFile(DMRemoteFolder parent, IPath path, IDMProject project, IDMRemoteTree tree, ItemMetadata itemMetadata,
            long timestamp) /* throws IOException */{
        super(parent, path, project, tree, timestamp);
        fromMetadata(itemMetadata);
    }

    @Override
    public byte getType() {
        return FILE;
    }

    @Override
    public void accept(IDMResourceVisitor visitor) throws CoreException {
        visitor.visit(this);
    }

    @Override
    public ItemRevision getItemRevision() throws DMException {
        if (revisionHandle == null) {
            // originally had only spec which slows down querying performed using
            // the returned proxy, using spec and uid speed things up but we may not
            // have the uid if this object is based on BYTES_VERSION 1, create a proxy
            // from the data we have
            if (uid == IDMConstants.INVALID_UID) {
                revisionHandle = getProject().getItemRevisionProxy(itemSpec);
            } else {
                ItemMetadata md = this.metadata; // use md if already have it
                if (md == null) {
                    md = new ItemMetadata();
                    md.setItemSpec(itemSpec);
                    md.setItemUid(uid);
                }
                revisionHandle = getProject().getItemRevisionProxy(md, null);
            }
        }
        return revisionHandle;
    }

    public ItemMetadata getMetadata() {
        ItemMetadata result = this.metadata; // use md if already have it
        if (result == null) {
            result = new ItemMetadata();
            result.setItemSpec(itemSpec);
            result.setItemUid(uid);
            result.setMovedFrom(movedFromPath);

            result.setRelPath(mdRelPath);
            result.setProjectUid(mdProjectUid);
            result.setBaselineUid(mdBaselineUid);
            result.setProjectVer(mdProjectVer);
        }
        return result;
    }

    @Override
    public String getItemSpec() {
        return itemSpec;
    }

    @Override
    public String getItemSpecId() {
        return itemSpecId;
    }

    @Override
    public long getModtime() {
        return modtime;
    }

    @Override
    public boolean isExtracted() {
        return isFlagSet(EXTRACTED);
    }

    @Override
    public boolean isAnyExtracted() {
        return isFlagSet(EXTRACTED_ANY);
    }

    void setAnyExtracted(boolean value) {
        updateFlag(EXTRACTED_ANY, value);
    }

    @Override
    public boolean isMultiExtracted() {
        return isFlagSet(EXTRACTED_MULTI);
    }

    void setMultiExtracted(boolean value) {
        updateFlag(EXTRACTED_MULTI, value);
    }

    @Override
    public boolean isExtractedExclusive() {
        return isFlagSet(EXTRACTED_EXCLUSIVE);
    }

    void setExtractedExclusive(boolean value) {
        updateFlag(EXTRACTED_EXCLUSIVE, value);
    }

    @Override
    public boolean isExtractedOther() {
        return isFlagSet(EXTRACTED_OTHER);
    }

    void setExtractedOther(boolean value) {
        updateFlag(EXTRACTED_OTHER, value);
    }

    @Override
    public String getRevision() {
        return revision;
    }

    @Override
    public int getVersion() {
        return version;
    }

    @Override
    public IFile getLocalFile() {
        return (IFile) getLocalResource();
    }

    @Override
    public boolean isMerged() {
        return mergedFromRevisions.length > 0;
    }

    @Override
    public String[] getMergedFromRevisions() {
        return isMerged() ? (String[]) mergedFromRevisions.clone() : mergedFromRevisions;
    }

    @Override
    protected void fetchContents(IProgressMonitor monitor) throws TeamException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            ItemRevision rev = getItemRevision();
            TeamUtils.setFilename(rev, getName()); // WORKAROUND set the name so that darius doesn't attempt to query for it when FI
            monitor.subTask(NLS.bind(Messages.DMRemoteFile_0, itemSpec));
            ExpandMode[] expModeHolder = new ExpandMode[1]; // 1-element array to contain a value on return
            InputStream contents = TeamUtils.getContents(rev, getConnection(), expModeHolder);
            setContents(contents, null);
            setFetchExpandMode(expModeHolder[0]);
        } catch (DMException e) {
            throw TeamException.asTeamException(e);
        } finally {
            monitor.done();
        }
    }

    protected void replaceContents(InputStream contents, ExpandMode mode) throws TeamException {
        cacheHandle(); // Workaround to make contents to be written into a cache file - otherwise contents would get lost
        setContents(contents, null);
        setFetchExpandMode(mode);
    }

    protected InputStream getContents(IProgressMonitor monitor) throws TeamException {
        monitor = Utils.monitorFor(monitor);
        InputStream contents = null;
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            ItemRevision rev = getItemRevision();
            TeamUtils.setFilename(rev, getName()); // WORKAROUND set the name so that darius doesn't attempt to query for it when FI
            monitor.subTask(NLS.bind(Messages.DMRemoteFile_0, itemSpec));
            // should we check/set expand mode here? invoked from TeamUtils.areContentsEqual()
            contents = TeamUtils.getContents(rev, getConnection(), null);
        } catch (DMException e) {
            throw TeamException.asTeamException(e);
        } finally {
            monitor.done();
        }
        return contents;
    }

    @Override
    public String getContentIdentifier() {
        return itemSpecId + ';' + version;
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof DMRemoteFile) {
            DMRemoteFile otherRemote = (DMRemoteFile) object;
            if (!itemSpecId.equals(otherRemote.itemSpecId))
            	return false;
            
            if (getConnection() == otherRemote.getConnection()) {
            	
        		if (isExtracted()) {
                	// If Both extracted consider them as equal
        			if (otherRemote.isExtracted())
                		return true;
        			else
	        			return (lib_version == -1 ? version : lib_version) == otherRemote.version;
        		} else if (otherRemote.isExtracted()) {
        			return version == (otherRemote.lib_version == -1 ? otherRemote.version : otherRemote.lib_version);
        		}
        		
                return version == otherRemote.version;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return getConnection().hashCode() ^ itemSpecId.hashCode() /* itemSpec.hashCode() */^ version;
    }

    @Override
    public boolean isStale() {
        // answer true if missing uid, i.e. created from bytes VERSION_1
        return super.isStale() || uid == IDMConstants.INVALID_UID;
    }

    @Override
    public boolean isBasedOn(ItemRevision itemRevision) {
        Assert.isNotNull(itemRevision);

        // rely on uid if available
        if (uid != IDMConstants.INVALID_UID) {
            Long otherUid = (Long) itemRevision.getAttribute(SystemAttributes.OBJECT_UID);
            if (otherUid != null && otherUid.longValue() != IDMConstants.INVALID_UID) {
                return uid == otherUid.longValue();
            }
        }

        // otherwise fall back to spec compare
        String otherSpec = (String) itemRevision.getAttribute(SystemAttributes.OBJECT_SPEC);
        return otherSpec != null && otherSpec.equals(itemSpec);
    }

    /*
     * 1. bytes version
     * 2. resource type
     * 3. item spec
     * 4. uid
     * 5. file version (content id)
     * 6. modtime
     * 7. flags
     * 8. merge revisions
     * 9. movedFrom
     * 10. movedFromProject
     * 11. timestamp
     * (non-Javadoc)
     *
     * @see com.serena.eclipse.dimensions.internal.team.core.resources.DMRemoteResource#toBytes()
     */
    @Override
    protected byte[] toBytes() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DataOutputStream dataOut = new DataOutputStream(out);
        try {
            dataOut.writeByte(BYTES_VERSION);
            dataOut.writeByte(FILE);
            dataOut.writeUTF(itemSpec == null ? Utils.EMPTY_STRING : itemSpec);
            dataOut.writeLong(uid);
            dataOut.writeInt(version);
            dataOut.writeLong(modtime);
            if (isBaseResource()) {
                ResourceAttributes attributes = getLocalResource().getResourceAttributes();
                updateFlag(READ_ONLY, attributes != null ? attributes.isReadOnly() : false);
            }
            dataOut.writeInt(flags);
            dataOut.writeShort(mergedFromRevisions.length);
            for (int i = 0; i < mergedFromRevisions.length; i++) {
                String rev = mergedFromRevisions[i];
                dataOut.writeUTF(rev);
            }
            dataOut.writeUTF(movedFromPath != null ? movedFromPath : Utils.EMPTY_STRING);
            dataOut.writeUTF(movedFromProject != null ? movedFromProject : Utils.EMPTY_STRING);
            dataOut.writeByte((int) timestamp);
            dataOut.writeUTF(lockUser == null ? Utils.EMPTY_STRING : lockUser);
            dataOut.writeUTF(lockDate == null ? Utils.EMPTY_STRING : lockDate);

            // since 14.1
            dataOut.writeUTF(mdRelPath == null ? Utils.EMPTY_STRING : mdRelPath);
            dataOut.writeLong(mdProjectUid);
            dataOut.writeLong(mdBaselineUid);
            dataOut.writeLong(mdProjectVer);

            // VERSION_6
            dataOut.writeInt(lib_version);
            
            dataOut.flush();
        } catch (IOException e) {
            DMTeamPlugin.getDefault()
                    .getLog()
                    .log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMRemoteFile_1, e));
        }
        return out.toByteArray();
    }

    private void fromBytes(byte[] bytes) throws IOException {
        assert bytes != null;
        DataInputStream dataIn = new DataInputStream(new ByteArrayInputStream(bytes));
        byte bytesVersion = dataIn.readByte();
        byte resourceType = dataIn.readByte();
        assert resourceType == FILE;
        itemSpec = dataIn.readUTF();
        if (bytesVersion >= VERSION_2) { // read uid in only if v2 and later
            uid = dataIn.readLong();
        }
        version = dataIn.readInt();
        modtime = dataIn.readLong();
        // extracted = dataIn.readBoolean();
        flags = dataIn.readInt();
        int mergedCnt = 0xFFFF & dataIn.readShort();
        if (mergedCnt > 0) {
            mergedFromRevisions = new String[mergedCnt];
            for (int i = 0; i < mergedCnt; i++) {
                mergedFromRevisions[i] = dataIn.readUTF();
            }
        }
        String movedFrom = dataIn.readUTF();
        if (movedFrom.length() > 0) {
            movedFromPath = movedFrom;
        }
        movedFrom = dataIn.readUTF();
        if (movedFrom.length() > 0) {
            movedFromProject = movedFrom;
        }
        if (bytesVersion < VERSION_4) {
            // was a full value
            timestamp = dataIn.readLong();
        } else {
            timestamp = dataIn.readByte();
        }
        if (bytesVersion >= VERSION_3) {
            lockUser = dataIn.readUTF();
            lockDate = dataIn.readUTF();
        }

        // since 14.1
        if (bytesVersion >= VERSION_5) {
            mdRelPath = dataIn.readUTF();
            mdProjectUid = dataIn.readLong();
            mdBaselineUid = dataIn.readLong();
            mdProjectVer = dataIn.readLong();
        }

        if (bytesVersion >= VERSION_6) {
            lib_version = dataIn.readInt();
        } else {
            lib_version = -1;
        }
        
        revision = extractRevisionFromSpec(itemSpec);
        if (revision.length() > 0) {
            itemSpecId = itemSpec.substring(0, itemSpec.length() - revision.length() - 1);
        }
    }

    // to be called from session runnable
    private void fromRepositoryFile(ItemRevision itemRevision) {
        itemSpec = (String) itemRevision.getAttribute(SystemAttributes.OBJECT_SPEC);
        Object uidObject = itemRevision.getAttribute(SystemAttributes.OBJECT_UID);
        if (uidObject instanceof Long) {
            uid = ((Long) uidObject).longValue();
        }
        revision = extractRevisionFromSpec(itemSpec);
        if (revision.length() > 0) {
            itemSpecId = itemSpec.substring(0, itemSpec.length() - revision.length() - 1);
        }
        String utcDateString = (String) itemRevision.getAttribute(SystemAttributes.UTC_MODIFIED_DATE);
        Date utcDate = getConnection().getDateTimeHelper().getDate(utcDateString, SystemAttributes.UTC_MODIFIED_DATE);
        if (utcDate != null) {
            modtime = utcDate.getTime();
        } else {
            modtime = 0L;
        }
        Boolean b = (Boolean) itemRevision.getAttribute(SystemAttributes.IS_EXTRACTED);
        updateFlag(EXTRACTED, b == null ? false : b.booleanValue());
        Integer i = (Integer) itemRevision.getAttribute(SystemAttributes.FILE_VERSION);
        version = i == null ? -1 : i.intValue();
        i = (Integer) itemRevision.getAttribute(SystemAttributes.ITEM_LIB_FILE_VERSION);
        lib_version = i == null ? -1 : i.intValue();
        this.revisionHandle = itemRevision;
        Boolean locked = (Boolean) itemRevision.getAttribute(SystemAttributes.IS_LOCKED);
        setLocked(locked == null ? false : locked.booleanValue());
        String lockedOther = (String) itemRevision.getAttribute(SystemAttributes.LOCKED_USER);
        setLockedOther((lockedOther == null || !isLocked()) ? false : !lockedOther.equals(getConnection().getUsername()
                .toUpperCase()));
        if (locked != null && locked.booleanValue()) {
            lockUser = (String) itemRevision.getAttribute(SystemAttributes.LOCKED_USER);
            lockDate = (String) itemRevision.getAttribute(SystemAttributes.LOCKED_DATE);
        }
    }

    private void fromMetadata(ItemMetadata itemMetadata) {
        assert itemMetadata != null;
        this.itemSpec = itemMetadata.getItemSpec();
        this.uid = itemMetadata.getItemUid();
        this.version = itemMetadata.getFileVersion();
        this.lib_version = -1;
        Date date = itemMetadata.getModTime();
        if (date != null) {
            this.modtime = date.getTime();
        }
        updateFlag(EXTRACTED, itemMetadata.isExtracted());
        this.revision = extractRevisionFromSpec(itemSpec);
        if (revision.length() > 0) {
            this.itemSpecId = itemSpec.substring(0, itemSpec.length() - revision.length() - 1);
        }
        String mergeString = itemMetadata.getRevisionListAsString();
        if (!Utils.isNullEmpty(mergeString)) {
            SortedSet<String> set = TeamUtils.parseRevisionList(mergeString);
            this.mergedFromRevisions = set.toArray(new String[set.size()]);
        }
        initMovedState(itemMetadata);
        this.mdRelPath = itemMetadata.getRelPath();
        this.mdProjectUid = itemMetadata.getProjectUid();
        this.mdProjectVer = itemMetadata.getProjectVer();
        this.mdBaselineUid = itemMetadata.getBaselineUid();
        this.metadata = itemMetadata;
    }

    private static String extractRevisionFromSpec(String spec) {
        String result = Utils.EMPTY_STRING;
        if (spec != null) {
            int idx = spec.lastIndexOf(';');
            if (idx >= 0) {
                result = spec.substring(idx + 1);
            }
        }
        return result;
    }

    static DMRemoteFile fromBytes(IPath path, IDMProject dmProject, IDMRemoteTree tree, byte[] bytes) throws IOException {
        return new DMRemoteFile(null, path, dmProject, tree, bytes);
    }

    public long getUid() {
        return uid;
    }

    @Override
    public void updatePath(IPath path) {
        this.name = path.isEmpty() ? Utils.EMPTY_STRING : path.lastSegment();
        this.path = path;
    }

    @Override
    public boolean isLocked() {
        return isFlagSet(LOCKED_FILE);
    }

    void setLocked(boolean value) {
        updateFlag(LOCKED_FILE, value);
    }

    @Override
    public boolean isLockedOther() {
        return isFlagSet(LOCKED_FILE_OTHER);
    }

    void setLockedOther(boolean value) {
        updateFlag(LOCKED_FILE_OTHER, value);
    }

    @Override
    public String getLockDate() {
        return lockDate;
    }

    @Override
    public String getLockUser() {
        return lockUser;
    }

    /*
     * Caches expand mode flag. Common for base and remote.
     */
    private synchronized void setFetchExpandMode(ExpandMode mode) {
        expandModeCache.put(getCachePath(), mode);
    }

    @Override
    public synchronized Boolean isFetchedExpanded() {
        ExpandMode em = null;
        if (!isContentsCached()) { // The cache may have been cleared - need to remove expand mode entry as well
            expandModeCache.remove(getCachePath());
            return null;
        } else {
            em = expandModeCache.get(getCachePath());
        }
        return (em == null) ? null : ExpandMode.EXPANDED.equals(em) ? true : false;
    }

    @Override
    public long getProjectUid() {
        return mdProjectUid;
    }

}

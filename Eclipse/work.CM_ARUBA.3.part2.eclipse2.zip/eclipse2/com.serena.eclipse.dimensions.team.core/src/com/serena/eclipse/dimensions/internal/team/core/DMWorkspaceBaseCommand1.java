package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Status;

import com.serena.dmfile.ObjectToTransfer;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * <P>
 * Base class for workspace commands, workspace commands implement
 *
 * <pre>
 * Command
 * </pre>
 *
 * pattern for workspace update and are not actual DM commands. Provides callback that can be invoked from DMWorkspace
 */
public abstract class DMWorkspaceBaseCommand1 implements IDMWorkspaceExecutable {
    protected static final IStatus OK = Status.OK_STATUS;
    protected IStatus finalStatus = OK;
    private List<IStatus> errors = new ArrayList<IStatus>();
    private boolean exceptionCaught = false;
    private long start;

    /**
     * Executes this command, subclasses need to implement.
     * @param monitor
     * @throws CoreException
     */
    protected abstract void execute(IProgressMonitor monitor) throws CoreException;

    protected void startExecute() {
        resetErrors();
    }

    protected void endExecute() throws DMException {
        handleErrors(errors.toArray(new IStatus[errors.size()]));
    }

    public IStatus run(IProgressMonitor monitor) throws CoreException {
        getWorkspace().run(this, monitor);
        return finalStatus;
    }

    @Override
    public void workspaceRun(IProgressMonitor monitor) throws CoreException {
        boolean debug = DMTeamPlugin.getDefault().isDebugging();
        startExecute();
        try {
            if (debug) {
                System.out.println("+ Executing: " + getClass().getName());
                start = System.currentTimeMillis();
            }
            execute(monitor);
            if (debug) {
                long stop = System.currentTimeMillis();
                System.out.println("- Executing done: " + getClass().getName() + ", took " + (stop - start) + "ms");
            }
        } catch (CoreException e) {
            exceptionCaught = true;
            addError(e.getStatus());
        }
        endExecute();
    }

    protected void handleErrors(IStatus[] errors) throws DMException {
        finalStatus = assembleFinalStatus(errors);
        if (exceptionCaught) {
            throw new DMException(finalStatus);
        }
    }

    private IStatus assembleFinalStatus(IStatus[] errors) {
        if (errors.length == 0) {
            return OK;
        }

        if (errors.length == 1) {
            return errors[0];
        }

        MultiStatus result = new MultiStatus(DMTeamPlugin.ID, 0, getErrorMessage(errors), null);
        for (int i = 0; i < errors.length; i++) {
            IStatus s = errors[i];
            if (s.isMultiStatus()) {
                result.add(new Status(s.getSeverity(), s.getPlugin(), s.getCode(), s.getMessage(), s.getException()));
                result.addAll(s);
            } else {
                result.add(s);
            }
        }
        return result;
    }

    protected String getErrorMessage(IStatus[] errors) {
        return "Error";
    }

    protected void addError(IStatus status) {
        if (status.isOK() || isLastError(status)) {
            return;
        }
        errors.add(status);
    }

    protected void addError(ObjectToTransfer fileDetails) {
        IStatus errorStatus = null;
        String status = fileDetails.getStatus();
        if (ObjectToTransfer.STATUS_UNRESOLVED.equals(status)) {
            String cause = fileDetails.getCause();
            if (ObjectToTransfer.CAUSE_NOT_EXISTS.equals(cause)) {
                errorStatus = new DMTeamStatus(IStatus.WARNING, 0, fileDetails.getMessage(), null);
            } else {
                errorStatus = new DMTeamStatus(IStatus.ERROR, 0, fileDetails.getMessage(), null);
            }
        } else if (ObjectToTransfer.STATUS_ERROR.equals(status)) {
            errorStatus = new DMTeamStatus(IStatus.WARNING, 0, fileDetails.getMessage(), null);
        } else if (ObjectToTransfer.STATUS_IGNORED.equals(status)) {
            errorStatus = new DMTeamStatus(IStatus.WARNING, 0, fileDetails.getMessage(), null);
        }

        if (errorStatus == null && !fileDetails.getCmdStatus()) {
            String msg = fileDetails.getMessage();
            if (Utils.isNullEmpty(msg)) {
                msg = Messages.UploadCommand_UnknownError;
            }
            errorStatus = new DMTeamStatus(IStatus.ERROR, 0, msg, null);
        }

        if (errorStatus != null) {
            addError(errorStatus);
        }
    }

    protected void resetErrors() {
        errors.clear();
    }

    protected IStatus getLastError() {
        IStatus status = errors.get(errors.size() - 1);
        return status;
    }

    protected DMWorkspace getWorkspace() {
        return (DMWorkspace) DMTeamPlugin.getWorkspace();
    }

    private boolean isLastError(IStatus status) {
        return (errors.size() > 0 && getLastError() == status);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeMap;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class DeleteFoldersCommand extends DMWorkspaceCommand1 {
    private boolean deleteLocal;

    public DeleteFoldersCommand(DMProject dmProject, WorkspaceResourceRequest[] requests, boolean deleteLocal) {
        super(dmProject, requests);
        this.deleteLocal = deleteLocal;
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            List<DimensionsArObject> folders = dmProject.fetchMembers(dmProject.getRoot(), IResource.FOLDER,
                    new int[] { SystemAttributes.OBJECT_SPEC }, true, Utils.subMonitorFor(monitor, 200));
            folders.add(dmProject.getRemoteRoot());
            HashMap<IPath, RepositoryFolder> folderByPath = new HashMap<IPath, RepositoryFolder>();
            for (Iterator<DimensionsArObject> iter = folders.iterator(); iter.hasNext();) {
                DimensionsArObject next = iter.next();
                if (next instanceof RepositoryFolder) {
                    RepositoryFolder aFolder = (RepositoryFolder) next;
                    IPath folderPath = TeamUtils.getFolderPath(aFolder);
                    folderByPath.put(folderPath, aFolder);
                }
            }

            // make sure folders are created from root down the tree
            TreeMap<IResource, FolderRequest> sortedRequests = new TreeMap<IResource, FolderRequest>(
                    new ContainmentComparator(true));
            for (int i = 0; i < requests.length; i++) {
                FolderRequest request = (FolderRequest) requests[i];
                if (folderByPath.containsKey(dmProject.getRemotePathForLocalResource(request.getResource()))) {
                    sortedRequests.put(request.getResource(), request);
                }
            }

            IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 800);
            subMonitor.beginTask(null, sortedRequests.size() * 2);

            List<VirtualIdmProject> childProjects = dmProject.getVirtualChildProjects();

            for (Iterator<FolderRequest> iter = sortedRequests.values().iterator(); iter.hasNext();) {
                final FolderRequest request = iter.next();

                IResource localFolder = request.getResource();
                IPath remotePath = dmProject.getRemotePathForLocalResource(localFolder);
                final RepositoryFolder remoteChild = folderByPath.get(remotePath);
                assert remoteChild != null;

                IContainer localParent = localFolder.getParent();
                IPath remoteParentPath = dmProject.getRemotePathForLocalResource(localParent);
                final RepositoryFolder remoteParent = folderByPath.get(remoteParentPath);
                assert remoteParent != null;

                String msg = NLS.bind(Messages.DeleteFoldersCommand_delete, localFolder.getProjectRelativePath().toString());
                subMonitor.subTask(msg);
                dmProject.getConnection().openSession(null).run(new APIOperation(msg) {
                    @Override
                    public DimensionsResult doRun() throws Exception {
                        List<String> reqList = request.getChangeRequests();
                        String[] reqIds = reqList == null || reqList.isEmpty()
                                ? null : (String[]) reqList.toArray(new String[reqList.size()]);
                        return remoteParent.removeChildFolder(remoteChild, reqIds);
                    }
                }, subMonitor);
                subMonitor.worked(1);

                if (deleteLocal) {
                    localFolder.delete(IResource.KEEP_HISTORY, null);
                }

                // avoid incoming deletions
                DMTeamPlugin.getWorkspace().unmanage(localFolder, null);

                // if folder is pointing to the virtual project unmanage it
                for (VirtualIdmProject child : childProjects) {
                    IResource rel = child.makeRelativeResourceFromOriginal(localFolder);
                    if (rel != localFolder && rel.getType() == IResource.PROJECT) {
                        DMTeamPlugin.getWorkspace().unmanageVirtual((IProject) rel, null);
                    }
                }

                subMonitor.worked(1);
            }
            subMonitor.done();
        } finally {
            monitor.done();
        }
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

    @Override
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        super.addSchedulingRule(rules, request);
        IResource resource = request.getResource();
        if (resource.getType() == IResource.FOLDER) {
            try {
                // virtual projects to the scheduling rule
                List<VirtualIdmProject> childProjects = dmProject.getVirtualChildProjects();
                for (VirtualIdmProject child : childProjects) {
                    IResource rel = child.makeRelativeResourceFromOriginal(resource);
                    if (rel != resource && rel.getType() == IResource.PROJECT) {
                        rules.add(rel);
                    }
                }
            } catch (CoreException e) {
                DMTeamPlugin.log(e.getStatus());
            }
        }
    }

}

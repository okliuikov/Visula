/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.ProjectSetSerializationContext;
import org.eclipse.team.core.TeamException;

/**
 * Handles all the user interactions necessary to import
 * projects to the workspace during team project set import.
 *
 * @author V.Grishchenko
 */
public interface IProjectSetImportHandler {

    /**
     * Adds projects to workspace. This handler should assume that it is safe to
     * overwrite existing projects.
     *
     * @param loadInfos import parameters
     * @param context not <code>null</code>, provides access to UI context
     * @param monitor
     * @return imported projects
     * @throws TeamException
     */
    IProject[] addToWorkspace(DMProjectLoadInfo[] loadInfos, ProjectSetSerializationContext context, IProgressMonitor monitor)
            throws CoreException;

}

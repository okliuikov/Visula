package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Map;

import org.eclipse.core.resources.IResource;

import com.serena.dmfile.ObjectToTransfer;
import com.serena.eclipse.dimensions.core.sbm.ActionDetails;

interface DeliverResults {

    Map<String, ObjectToTransfer> getStatusMap();

    Map<IResource, ActionDetails> getActionDetails();

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IConsoleOperation;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * @author V.Grishchenko
 */
public class UndoCheckoutRequest extends SimpleItemRevisionRequest {
    /** do not replace local file */
    public static final int REPLACE_NONE = 0;
    /** replace with base revision */
    public static final int REPLACE_BASE = 1;
    /** replace with latest revisions */
    public static final int REPLACE_LATEST = 2;
    /** only update the metadata but not the content */
    public static final int REPLACE_METADATA_ONLY = 3;

    private int replace = REPLACE_BASE;
    private int metadataReplace = REPLACE_LATEST;
    private boolean readOnly = true;

    /**
     * @param file
     * @param itemRevision
     * @throws CoreException
     */
    public UndoCheckoutRequest(IFile file, ItemRevision itemRevision) throws CoreException {
        super(file, itemRevision);
    }

    @Override
    public int getKind() {
        return MODIFY;
    }

    /**
     * @param value one of <code>REPLACE_NONE</code>, <code>REPLACE_BASE</code>, <code>REPLACE_LATEST</code>
     */
    public void setReplace(int value) {
        Assert.isLegal(value == REPLACE_NONE || value == REPLACE_BASE || value == REPLACE_LATEST || value == REPLACE_METADATA_ONLY);
        this.replace = value;
    }

    /**
     * @param value one of <code>REPLACE_BASE</code>, <code>REPLACE_LATEST</code>
     */
    public void setMetadataReplace(int value) {
        Assert.isLegal(value == REPLACE_BASE || value == REPLACE_LATEST);
        this.metadataReplace = value;
    }

    public boolean isReplace() {
        return replace != REPLACE_NONE;
    }

    public int getReplace() {
        return replace;
    }

    public void setMakeReadOnly(boolean value) {
        this.readOnly = value;
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            return undoCheckout();
        } finally {
            monitor.done();
        }
    }

    DimensionsResult undoCheckout() {
        IFile local = getFile();
        DimensionsResult result;
        result = getItemRevision().undoCheckout(true, local.getLocation().toOSString());
        TeamUtils.setReadOnly(local, readOnly);
        return result;
    }

    void processReplace(final IProgressMonitor monitor) throws DMException {
        final Session session = getConnection().openSession(null);
        session.run(new IConsoleOperation() {
            IStatus status;

            @Override
            public String getMessage() {
                return getReplaceMessage();
            }

            @Override
            public IStatus getStatus() {
                return status;
            }

            @Override
            public void run() throws Exception {
                try {
                    DimensionsResult result = replace(session, monitor);
                    status = new Status(IStatus.OK, DMTeamPlugin.ID, 0, result.getMessage(), null);
                } finally {
                    TeamUtils.refreshLocal(getResource(), null);
                    WorkspaceMetadataManager.refreshMetadata(getResource(), null);
                }
            }
        }, monitor);
    }

    String getReplaceMessage() {
        return NLS.bind(Messages.UndoCheckoutRequest_replaceMessage, getFile().getFullPath().toString());
    }

    private DimensionsResult replace(Session session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        monitor.subTask(getReplaceMessage());
        try {
            IFile local = getFile();
            DimensionsResult replaceResult = null;
            String msg = Utils.EMPTY_STRING;
            if (replace == REPLACE_BASE) {
                ItemRevision base = null;
                ItemMetadata itemMetadata = (ItemMetadata) WorkspaceMetadataManager.getLfsMetadata(local.getLocation().toFile());
                if (itemMetadata != null) {
                    IDMProject project = DMTeamPlugin.getWorkspace().getProject(local);
                    if (project != null) {
                        base = ((Project) project.getDimensionsObject()).createItemRevisionFromSpec(itemMetadata.getItemSpec());
                    }
                }
                if (base != null) {
                    replace(local, base);
                }
            } else if (replace == REPLACE_LATEST) {
                ItemRevision latest = null;
                if (DMTeamPlugin.getWorkspace().hasRemote(local)) {
                    IDMRemoteFile remoteRes = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getRemoteResource(local);
                    if (remoteRes != null) {
                        latest = remoteRes.getItemRevision();
                    }
                }
                if (latest != null) {
                    replace(local, latest);
                }
            } else if (replace == REPLACE_METADATA_ONLY) {
                ItemRevision latest = null;
                if (metadataReplace == REPLACE_LATEST) {
                    IDMRemoteFile remoteRes = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getRemoteResource(local);
                    if (remoteRes != null) {
                        latest = remoteRes.getItemRevision();
                    }
                } else if (metadataReplace == REPLACE_BASE) {
                    IDMRemoteFile baseRes = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
                    if (baseRes != null) {
                        latest = baseRes.getItemRevision();
                    }
                }
                if (latest != null) {
                    File temp = TeamUtils.getTempCopy(local, latest, session.getConnectionDetails());
                    BaseMetadata metadata = WorkspaceMetadataManager.getLfsMetadata(temp);
                    if (metadata != null) {
                        WorkspaceMetadataManager.getInstance().updateMetadata(local, metadata);
                    }
                    TeamUtils.setReadOnly(local, readOnly);
                } else {
                    msg = Messages.UndoCheckoutRequest_noRemote;
                }
            }
            return replaceResult == null ? new DimensionsResult(msg) : replaceResult;
        } finally {
            monitor.done();
        }
    }

    private DimensionsResult replace(IFile local, ItemRevision remote) throws Exception {
        TeamUtils.setFilename(remote, local.getName()); // make darius happy so it won't query for filename
        DimensionsResult replaceResult = remote.getCopy(local.getLocation().toOSString(), TeamUtils.isExpandSubstitution(), true,
                false);
        TeamUtils.setReadOnly(local, readOnly);
        local.touch(null);
        return replaceResult;
    }

    @Override
    protected boolean modifiesLocal() {
        return false; // local will be refreshed by replace if content is to be replaced
    }

    @Override
    protected boolean modifiesMetadata() {
        return true;
    }

}

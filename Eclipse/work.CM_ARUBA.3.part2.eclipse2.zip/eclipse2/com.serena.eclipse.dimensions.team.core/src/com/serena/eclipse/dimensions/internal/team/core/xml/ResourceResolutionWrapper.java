package com.serena.eclipse.dimensions.internal.team.core.xml;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.serena.dmfile.sync.XSyncResolutions;
import com.serena.dmfile.xml.Resolution;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;

class ResourceResolutionWrapper implements IResourceResolutionWrapper {
    private Resolution resolution;
    private XMLMergeDescriptor mergeDescriptor;

    public ResourceResolutionWrapper(Resolution resolution, XMLMergeDescriptor mergeDescriptor) {
        this.resolution = resolution;
        this.mergeDescriptor = mergeDescriptor;
    }

    public IResource getResource() {
        try {
            return TeamUtils.constructRelativeResource(resolution, mergeDescriptor);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
            return null;
        }
    }

    public boolean isIncomingDeletion() {
        XSyncResolutions type = resolution.getType();
        return type == XSyncResolutions.SR_REMOVE;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.UploadItemDetails;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.SessionRunnableWithProgress;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Project-based dimensions project.
 *
 * @author V.Grishchenko
 */
class WorksetProject extends DMProject {
    private Project/* Adapter */workset;
    private RepositoryFolder rootFolder; // folder at remote offset
    private boolean isStream;

    public WorksetProject(String id, DimensionsConnectionDetailsEx connection, IProject project, IPath localOffset,
            IPath remoteOffset, IPath workAreaRoot, IDMRemoteTree remoteTree) {
        super(id, WORKSET, connection, project, localOffset, remoteOffset, workAreaRoot, remoteTree);
    }

    public WorksetProject(WorksetAdapter workset, APIObjectAdapter uidObject, IProject project, IPath localOffset,
            IPath remoteOffset, IPath workAreaPath, IDMRemoteTree remoteTree) {
        super(workset, uidObject, project, localOffset, remoteOffset, workAreaPath, remoteTree);
        this.workset = workset.getWorkset();
        this.initial = "Y".equalsIgnoreCase((String) workset.getAPIObject().getAttribute(SystemAttributes.IDE_INITIAL)); //$NON-NLS-1$
        this.defaultRequest = (String) workset.getAPIObject().getAttribute(SystemAttributes.DEFAULT_REQUEST);
        this.isStream = Boolean.TRUE.equals(workset.getAPIObject().getAttribute(SystemAttributes.WSET_IS_STREAM));
    }

    @Override
    public String getDefaultRequest(boolean query) throws CoreException {
        if (query) {
            final Project _workset = getWorkset();
            Session session = getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    _workset.queryAttribute(SystemAttributes.DEFAULT_REQUEST);
                }
            }, new NullProgressMonitor());
            setDefaultRequest((String) workset.getAttribute(SystemAttributes.DEFAULT_REQUEST), true);
        }
        return getDefaultRequest();
    }

    @Override
    public DimensionsLcObject getDimensionsObject() throws DMException {
        return getWorkset();
    }

    @Override
    public/* synchronized */VersionManagementProject getDimensionsObjectAdapter() throws DMException {
        return new WorksetAdapter(getWorkset(), getConnection());
    }

    public Project getWorkset() throws DMException {
        if (workset == null) {
            final Session session = getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    workset = session.getObjectFactory().getProject(getId());
                }
            }, new NullProgressMonitor());
        }
        if (workset == null) {
            throw new DMException(NLS.bind(Messages.error_worksetNotFound, getId()), null);
        }
        return workset;
    }

    @Override
    public synchronized RepositoryFolder getRemoteRoot() throws DMException {
        if (rootFolder == null) {
            final Session session = getConnection().openSession(null);

            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    RepositoryFolder projectRoot = getWorkset().getRootFolder();
                    if (getRemoteOffset().isEmpty()) {
                        rootFolder = projectRoot;
                    } else {
                        List<RepositoryFolder> allFolders = projectRoot.getAllChildFolders();
                        rootFolder = findFolder(allFolders, getRemoteOffset());
                    }
                }

            }, new NullProgressMonitor());

        }
        return rootFolder;
    }

    @Override
    public void flushRemoteRoot() {
        rootFolder = null;
    }

    @Override
    public ItemRevision getItemRevisionProxy(final String spec) throws DMException {
        Assert.isLegal(!Utils.isNullEmpty(spec), "empty item spec"); //$NON-NLS-1$
        final ItemRevision[] resultHolder = new ItemRevision[1];
        Session session = getConnection().openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                resultHolder[0] = getWorkset().createItemRevisionFromSpec(spec);
            }
        }, new NullProgressMonitor());
        return resultHolder[0];
    }

    @Override
    public ItemRevision getItemRevisionProxy(final ItemMetadata itemMetadata, IProgressMonitor monitor) throws DMException {
        Assert.isLegal(itemMetadata != null && !Utils.isNullEmpty(itemMetadata.getItemSpec()) && itemMetadata.getItemUid() != -1,
                "must have spec and uid in item metadata object " + String.valueOf(itemMetadata)); //$NON-NLS-1$
        final ItemRevision[] resultHolder = new ItemRevision[1];
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        try {
            Session session = getConnection().openSession(Utils.subMonitorFor(monitor, 10));
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    resultHolder[0] = getWorkset().createItemRevisionFromMetadata(itemMetadata);
                }
            }, monitor);
            monitor.worked(90);
            return resultHolder[0];
        } finally {
            monitor.done();
        }
    }

    @Override
    public RepositoryFolder getRepositoryFolderProxy(final IPath path) throws DMException {
        if (path.isEmpty()) {
            return getRemoteRoot();
        }
        // getting a folder by path seem to be a local call but do via session anyway
        Session session = getConnection().openSession(null);
        final RepositoryFolder[] result = new RepositoryFolder[1];
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                result[0] = getWorkset().findRepositoryFolderByPath(TeamUtils.getFolderFullPath(path));
            }
        }, new NullProgressMonitor());
        return result[0];
    }

    @Override
    public IStatus checkout(CheckoutRequest[] files, IProgressMonitor monitor) throws CoreException {
        CheckoutLatestRevisionsCommand1 cmd = new CheckoutLatestRevisionsCommand1(this, files);
        return cmd.run(monitor);
    }

    @Override
    public IStatus checkin(CheckinRequest[] files, IProgressMonitor monitor) throws CoreException {
        CheckinCommand cmd = new CheckinCommand(this, files);
        return cmd.run(monitor);
    }

    @Override
    public IStatus undoCheckout(UndoCheckoutRequest[] files, IProgressMonitor monitor) throws CoreException {
        UndoCheckoutCommand cmd = new UndoCheckoutCommand(this, files);
        return cmd.run(monitor);
    }

    @Override
    public IStatus add(CreateItemRequest[] files, IProgressMonitor monitor) throws CoreException {
        AddCommand cmd = new AddCommand(this, files);
        return cmd.run(monitor);
    }

    @Override
    public UploadItemDetails[] queryUploadRules(final String[] filenames, final String[] attrs, IProgressMonitor monitor)
            throws DMException {
        Assert.isNotNull(filenames, "null filenames"); //$NON-NLS-1$
        if (filenames.length == 0) {
            return new UploadItemDetails[0];
        }
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.WorksetProject_0, IProgressMonitor.UNKNOWN);
        monitor.subTask(Utils.EMPTY_STRING);
        try {
            final Session session = getConnection().openSession(Utils.subMonitorFor(monitor, 5));
            final UploadItemDetails[][] result = new UploadItemDetails[1][];
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    String worksetRoot = getRoot().getLocation().toOSString();
                    String contextRoot = worksetRoot;
                    // TODO if a non ide project tag/pn == null use mrg ruleset ?
                    result[0] = session.getObjectFactory().queryDurulesEx(getUploadRuleId(), String.valueOf(getIdeProjectUid()),
                            getProduct(), getId(), worksetRoot, contextRoot, filenames, attrs);
                }
            }, monitor);
            return result[0];
        } finally {
            monitor.done();
        }
    }

    @Override
    public IStatus delete(DeleteItemRevisionRequest[] files, IProgressMonitor monitor) throws CoreException {
        DeleteItemRevisionsCommand command = new DeleteItemRevisionsCommand(this, files);
        return command.run(monitor);
    }

    @Override
    public Map<String, List<ItemRevision>> expandItemRevisions(final List<ItemRevision> revisions, final int[] attrs,
            IProgressMonitor monitor) throws DMException {
        if (revisions.isEmpty()) {
            return Collections.emptyMap();
        }
        monitor = Utils.monitorFor(monitor);
        // first expand and query attributes if any requested
        final Unit<List<ItemRevision>> holder = new Unit<List<ItemRevision>>();
        final Session session = getConnection().openSession(null);

        session.run(new SessionRunnableWithProgress(monitor) {

            @SuppressWarnings("unchecked")
            @Override
            public void run() throws Exception {
                progress.beginTask(null, 100);
                try {
                    final Project workset = getWorkset();
                    progress.worked(20);
                    holder.setValue(workset.ExpandItemRevisions(revisions));
                    progress.worked(40);
                    if (attrs != null && attrs.length > 0 && !holder.getValue().isEmpty()) {
                        Utils.queryAttributes(holder.getValue(), attrs, session.getObjectFactory(), true);
                    }
                    progress.worked(40);
                } finally {
                    progress.done();
                }
            }

        }, monitor);

        // put expanded revisions into a map for quicker lookup
        Map<String, List<ItemRevision>> expandedMap = new HashMap<String, List<ItemRevision>>(); // item_spec_id -> {ItemRevision}
        List<ItemRevision> expandedRevisions = holder.getValue();
        for (Iterator<ItemRevision> iter = expandedRevisions.iterator(); iter.hasNext();) {
            ItemRevision expRevision = iter.next();
            String expSpec = (String) expRevision.getAttribute(SystemAttributes.OBJECT_SPEC);
            Assert.isNotNull(expSpec);
            String expSpecId = TeamUtils.getItemSpecId(expSpec);
            Assert.isNotNull(expSpecId);
            List<ItemRevision> list = expandedMap.get(expSpecId);
            if (list == null) {
                list = new ArrayList<ItemRevision>();
                expandedMap.put(expSpecId, list);
            }
            list.add(expRevision);
        }

        // now iterate over input revision trying to find item spec id matches in expanded map
        Map<String, List<ItemRevision>> result = new HashMap<String, List<ItemRevision>>(); // item_spec -> {ItemRevision}
        for (Iterator<ItemRevision> inIter = revisions.iterator(); inIter.hasNext();) {
            ItemRevision inRevision = inIter.next();
            String inSpec = (String) inRevision.getAttribute(SystemAttributes.OBJECT_SPEC);
            Assert.isNotNull(inSpec);
            String inSpecId = TeamUtils.getItemSpecId(inSpec);
            Assert.isNotNull(inSpecId);
            List<ItemRevision> expList = expandedMap.get(inSpecId);
            if (expList != null) {
                result.put(inSpec, expList);
            }
        }

        return result;
    }

    @Override
    public IStatus upload(OperationData commandData, IProgressMonitor monitor) throws CoreException {
        List<WorkspaceResourceRequest> requests = commandData.getRequests();
        UploadCommand cmd = new UploadCommand(this, requests.toArray(new WorkspaceResourceRequest[requests.size()]));
        return cmd.run(monitor);
    }

    @Override
    public IStatus deliver(TransferToStreamOperationData commandData, IProgressMonitor monitor) throws CoreException {
        List<WorkspaceResourceRequest> requests = commandData.getRequests();
        DeliverCommand cmd = new DeliverCommand(this, requests.toArray(new WorkspaceResourceRequest[requests.size()]), commandData);
        return cmd.run(monitor);
    }

    @Override
    public IStatus createDirectories(CreateFolderRequest[] dirs, IProgressMonitor monitor) throws CoreException {
        CreateFoldersCommand cmd = new CreateFoldersCommand(this, dirs);
        return cmd.run(monitor);
    }

    @Override
    public IStatus deleteDirectories(DeleteFolderRequest[] dirs, boolean deleteLocal, IProgressMonitor monitor)
            throws CoreException {
        DeleteFoldersCommand cmd = new DeleteFoldersCommand(this, dirs, deleteLocal);
        return cmd.run(monitor);
    }

    @Override
    public IStatus updateFilename(UpdateFilenameRequest[] files, IProgressMonitor monitor) throws CoreException {
        UpdateFilenameCommand moveCommand = new UpdateFilenameCommand(this, files);
        return moveCommand.run(monitor);
    }

    @Override
    public IStatus importFiles(ImportRequest[] files, IProgressMonitor monitor) throws CoreException {
        ImportCommand importCommand = new ImportCommand(this, files);
        return importCommand.run(monitor);
    }

    @Override
    public IStatus resolveConflicts(ResolveConflictRequest[] conflicts, IProgressMonitor monitor) throws CoreException {
        ResolveConflictsCommand cmd = new ResolveConflictsCommand(this, conflicts);
        return cmd.run(monitor);
    }

    @Override
    public IStatus move(IMoveRequest[] movedResources, IProgressMonitor monitor) throws CoreException {
        // return null;
        MoveRequest[] impls = new MoveRequest[movedResources.length];
        for (int i = 0; i < movedResources.length; i++) {
            MoveRequest anImpl = null;
            if (movedResources[i] instanceof MoveFolderRequest) {
                anImpl = ((MoveFolderRequest) movedResources[i]).getImpl();
            } else if (movedResources[i] instanceof MoveItemRequest) {
                anImpl = ((MoveItemRequest) movedResources[i]).getImpl();
            }
            if (anImpl != null) {
                impls[i] = anImpl;
            }
        }
        MoveCommand moveCommand = new MoveCommand(this, impls);
        return moveCommand.run(monitor);
    }
    
    String getUploadRuleId() {
        return isSccStyle() ? IDMConstants.SCC_DURULES_ID : IDMConstants.DURULES_ID;
    }

    @Override
    protected void sessionDestroyed() {
        rootFolder = null;
        workset = null;
    }

    @Override
    public void setIsStream(boolean isStream) {
        this.isStream = isStream;
    }

    @Override
    public boolean getIsStream() {
        return isStream;
    }

    @Override
    public synchronized List<ItemMetadata> queryForeignContentStatus(final List<ItemMetadata> localMetadatas,
            final List<ItemMetadata> remoteMetadatas, IProgressMonitor monitor) throws CoreException {
        if (localMetadatas == null || remoteMetadatas == null || localMetadatas.size() != remoteMetadatas.size()) {
            return null;
        }
        monitor = Utils.monitorFor(monitor);
        // first expand and query attributes if any requested
        final Unit<List<ItemMetadata>> listHolder = new Unit<List<ItemMetadata>>();
        final Session session = getConnection().openSession(monitor);
        session.run(new SessionRunnableWithProgress(monitor) {
            @Override
            public void run() throws Exception {
                progress.beginTask(null, 100);
                try {
                    Project workset = session.getObjectFactory().getProject(getId());
                    ItemMetadata[] data = workset.syncQueryItemInfo(
                            localMetadatas.toArray(new ItemMetadata[localMetadatas.size()]),
                            remoteMetadatas.toArray(new ItemMetadata[localMetadatas.size()]));
                    if (data != null) {
                        listHolder.setValue(Arrays.asList(data));
                    }
                } finally {
                    progress.done();
                }
            }
        }, monitor);
        return listHolder.getValue();
    }

    /**
     * This method returns the project UID
     * @param projectSpec - Project spec in String format. eg: $GLOBAL:$GENERIC
     * @return - Project UID
     * @throws CoreException
     */
    public long getProjectUid(final String projectSpec) throws CoreException {
        final Session session = getConnection().openSession(null);
        final Project[] workset = new Project[1];
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                workset[0] = session.getObjectFactory().getProject(projectSpec);
                if (workset[0] != null) {
                    workset[0].queryAttribute(SystemAttributes.OBJECT_UID);
                }
            }
        }, new NullProgressMonitor());
        if (workset[0] == null) {
            throw new DMException(NLS.bind(Messages.error_worksetNotFound, getId()), null);
        }
        return ((Long) workset[0].getAttribute(SystemAttributes.OBJECT_UID)).longValue();
    }

}

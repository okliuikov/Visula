/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.ISaveContext;
import org.eclipse.core.resources.ISaveParticipant;
import org.eclipse.core.resources.ISavedState;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.ISafeRunnable;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.SafeRunner;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.core.runtime.jobs.ILock;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.ITeamStatus;
import org.eclipse.team.core.RepositoryProvider;
import org.eclipse.team.core.Team;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.TeamStatus;
import org.eclipse.team.core.subscribers.ISubscriberChangeEvent;
import org.eclipse.team.core.subscribers.SubscriberChangeEvent;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;
import org.eclipse.team.core.variants.IResourceVariantTree;

import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.VerifyForeignUpdate;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.MetadataStrings;
import com.serena.dmfile.metadb.IMetadataChange;
import com.serena.dmfile.metadb.IMetadataChange.MetadataChangeType;
import com.serena.dmfile.metadb.IMetadataChangeListener;
import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IConnectionRegistryListener;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.WaRootInfo;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLWorkspaceMergeCommand;

/**
 * @author V.Grishchenko
 */
public final class DMWorkspace extends DMSyncTreeSubscriber implements IDMWorkspace, IResourceVariantComparator,
        IResourceChangeListener, IResourceDeltaVisitor, IConnectionRegistryListener, ISaveParticipant { 
    public static final String DM_IGNORE = ".dmignore"; //$NON-NLS-1$
    public static final String RECURSIVE_MASK_PREFIX = "r:"; //$NON-NLS-1$
    public static final String CLEAR_RECURSIVE_MASK_PREFIX = "c:"; //$NON-NLS-1$
    public static final String COMMENT_MASK_PREFIX = ":"; //$NON-NLS-1$

    private static final int FOLDER_STATE_VERSION = 1;
    private static final int MOVE_STATE_VERSION = 1;
    private static final int UNINITIALIZED = 0;
    private static final int INITIALIZING = 1;
    private static final int INITIALIZED = 2;

    // Constants for verifying foreign updates RPC (GetForeignChangetypeInfo) input/output parameters
    private static final int DELETION = 0x0004; // Deletion (no such item in Foreign Stream)
    private static final int ADDITION = 0x0008; // Addition (new item in Foreign Stream)
    private static final int RENAME_MOVE = 0x0010; // Rename/Move
    // Output parameters
    private static final int NO_CHANGES = 0x0000; // No changes - ignore
    private static final int CHANGE = 0x0002; // Change (new item Revision from Foreign Stream)
    private static final int CONFLICT = 0x8000; // Conflict (Changes from Foreign Stream conflict with local)

    // consider the following changes types and ignore the others (e.g. marker and description changes are ignored)
    private static final int INTERESTING_CHANGES = IResourceDelta.CONTENT | IResourceDelta.MOVED_FROM
            | IResourceDelta.MOVED_TO | IResourceDelta.OPEN | IResourceDelta.REPLACED | IResourceDelta.TYPE;

    private static final String FOLDER_STATUS_STATE = ".folder_state"; //$NON-NLS-1$
    private static final String METADATA_CACHE = ".metadata_cache"; //$NON-NLS-1$
    private static final String BASE_DELETE_MARKERS = ".base_deletions"; //$NON-NLS-1$
    private static final String MOVE_STATE = ".move_state"; //$NON-NLS-1$
    private static final String WORKSPACE_TREE_PREFIX = "workspace"; //$NON-NLS-1$
    private static final String QUALIFIER = "dimensions.teamprovider"; //$NON-NLS-1$

    private static final QualifiedName REMOTE_TREE = new QualifiedName(SYNC_KEY_QUALIFIER,
            WORKSPACE_TREE_PREFIX + REMOTE_TREE_SUFFIX);
    private static final QualifiedName CONNECTION_NAME_PROP = new QualifiedName(QUALIFIER, "connection"); //$NON-NLS-1$

    private static final ThreadLocal<List<StaleCheckoutInfo>> INVALID_CHECKOUTS = new ThreadLocal<List<StaleCheckoutInfo>>();
    // use to keep MetadataProvider for current top resource project, several projects could be handled concurrently
    private static final ThreadLocal<MetadataProvider> METADATA_PROVIDER = new ThreadLocal<MetadataProvider>();

    private static final ThreadLocal<TreeSet<IContainer>> CONTAINER_CHANGES = new ThreadLocal<TreeSet<IContainer>>() {

        @Override
        protected TreeSet<IContainer> initialValue() {
            return new TreeSet<IContainer>(new ContainmentComparator(true));
        }
    };

    // use linked list because ArrayList does not guarantee to shrink its
    // internal array when cleared plus it may be faster to grow a LL as
    // no need to copy elements to a bigger array
    private static final ThreadLocal<LinkedList<IResource>> LOCAL_CHANGES = new ThreadLocal<LinkedList<IResource>>() {

        @Override
        protected LinkedList<IResource> initialValue() {
            return new LinkedList<IResource>();
        }
    };

    // use linked list because ArrayList does not guarantee to shrink its
    // internal array when cleared plus it may be faster to grow a LL as
    // no need to copy elements to a bigger array
    private static final ThreadLocal<LinkedList<IMetadataChange[]>> SAVED_METADATA_CHANGES = new ThreadLocal<LinkedList<IMetadataChange[]>>() {

        @Override
        protected LinkedList<IMetadataChange[]> initialValue() {
            return new LinkedList<IMetadataChange[]>();
        }
    };

    private static final ThreadLocal<LinkedList<IResource>> LISTENER_METADATA_CHANGED = new ThreadLocal<LinkedList<IResource>>() {

        @Override
        protected LinkedList<IResource> initialValue() {
            return new LinkedList<IResource>();
        }
    };

    private static final ThreadLocal<Boolean> DEFERRED_METADATA_LISTENER_ACTIVE = new ThreadLocal<Boolean>() {

        @Override
        protected Boolean initialValue() {
            return Boolean.FALSE;
        }
    };

    private static boolean debug = DMTeamPlugin.getDefault().isDebugging();
    private static boolean debugResources = DMTeamPlugin.getDefault().isDebuggingResources();
    private static boolean debugListeners = DMTeamPlugin.getDefault().isDebuggingListeners();
    private static boolean debugFolderStatus = DMTeamPlugin.getDefault().isDebuggingFolderStatus();
    private static boolean debugByteStore = DMTeamPlugin.getDefault().isDebuggingByteStore();

    private MetadataChangeListener metadataChangeListener;
    private DMRemoteTree remoteTree;
    private DMBaseResourceVariantTree baseTree;
    private ILock baseTreeLock;
    private CustomSubscriber updateFromReqSubscriber = null; // access to the subscriber for Update from request

    private int folderCacheStatus = UNINITIALIZED;
    private int moveStateStatus = UNINITIALIZED;

    private List<IResourceStateChangeListener> listeners = new ArrayList<IResourceStateChangeListener>(); // resource state change
    private Map<IPath, WorkspaceFolderStatus> folderStatusCache = Collections
            .<IPath, WorkspaceFolderStatus>synchronizedMap(new HashMap<IPath, WorkspaceFolderStatus>());
    // move source -> move destination
    private Map<IResource, IResource> movedSrcDst = new HashMap<IResource, IResource>();
    // move destination -> move source
    private Map<IResource, IResource> movedDstSrc = new HashMap<IResource, IResource>();
    // move source -> move destination
    private Map<IResource, IResource> movedInRepositorySrcDst = new HashMap<IResource, IResource>();
    // move destination -> move source
    private Map<IResource, IResource> movedInRepositoryDstSrc = new HashMap<IResource, IResource>();
    // folder -> String[] of patterns
    private Map<IContainer, FileNameMatcher> ignoreCache = new HashMap<IContainer, FileNameMatcher>();
    // move destination(repository) -> move source(local)
    private Map<IResource, IResource> movedInRepoDstSrcMerged = new HashMap<IResource, IResource>();

    // This map stores the metadata of the item being moved locally in the following case:
    // Create StreamA with two folder(Folder1 and Folder2) and a file in each of these folders( file1 and file2 respectively ).
    // Create a StreamB from StreamA.
    // User1 adds StreamA to workspace. Modifies file1 locally and delivers it to StreamA.
    // User2 adds StreamB to workspace. Moves file1 locally and moves to Folder2 and delivers it toStreamB.
    // User1 switches to StreamB, does a sync and Updates the repository move. Switches back to StreamA and does a syn.
    // Sync view shows local move.
    // Do a deliver. In this scenario we need some part of the metadata of Folder1/File1 to use in the metadata
    // of Folder2/File1 during Update of repository move and we store the metadata in this map.
    private Map<String, ItemMetadata> metadataCacheOfItemBeingMoved = new HashMap<String, ItemMetadata>();

    // resource --> Integer sync kind updated as result of GetForeignChangetypeInfo invocation
    private Map<IResource, Integer> foreignUpdateSyncKindCache = new HashMap<IResource, Integer>();

    public static boolean setupDeferredMdListener() {
        // if already in a deferred listener for this thread don't defer
        Boolean tldeferred = DEFERRED_METADATA_LISTENER_ACTIVE.get();
        if (tldeferred == Boolean.TRUE) {
            return false;
        }
        SAVED_METADATA_CHANGES.get().clear();
        DEFERRED_METADATA_LISTENER_ACTIVE.set(Boolean.TRUE);
        return true;
    }

    public static void processDeferredMdListener() {
        processDeferredMdListener(false);
    }

    public static void processDeferredMdListener(boolean filterMDRemovals) {
        LinkedList<IMetadataChange[]> mcChanges = SAVED_METADATA_CHANGES.get();
        List<IMetadataChange> collectedChanges = null;
        IMetadataChange[] toProcess = null;
        try {
            if (mcChanges.size() > 0) {
                if (mcChanges.size() == 1) {
                    if (!filterMDRemovals) {
                        // just do it
                        toProcess = mcChanges.getFirst();
                    } else {
                        // filter removals changes
                        collectedChanges = new ArrayList<IMetadataChange>();
                        for (IMetadataChange[] mcArr : mcChanges) {
                            for (IMetadataChange mc : mcArr) {
                                if (mc.getChange() != MetadataChangeType.MC_REMOVED) {
                                    collectedChanges.add(mc);
                                }
                            }
                        }
                        toProcess = collectedChanges.toArray(new IMetadataChange[collectedChanges.size()]);
                    }
                } else {
                    // collect changes
                    collectedChanges = new ArrayList<IMetadataChange>();
                    for (IMetadataChange[] mcArr : mcChanges) {
                        for (IMetadataChange mc : mcArr) {
                            if (!filterMDRemovals) {
                                collectedChanges.add(mc);
                            } else if (mc.getChange() != MetadataChangeType.MC_REMOVED) {
                                collectedChanges.add(mc);
                            }
                        }
                    }
                    toProcess = collectedChanges.toArray(new IMetadataChange[collectedChanges.size()]);
                }
                processSavedMetadataChanges(toProcess);
                mcChanges.clear();
            }
        } finally {
            DEFERRED_METADATA_LISTENER_ACTIVE.set(Boolean.FALSE);
        }
    }

    /*
     * Private class used to safely notify listeners of resource sync info changes.
     * Subclass override the notify(IResourceStateChangeListener) method to
     * fire specific events inside an ISafeRunnable.
     */
    private abstract class Notification implements ISafeRunnable {
        private IResourceStateChangeListener listener;

        @Override
        public void handleException(Throwable exception) {
            // don't log the exception....it is already being logged in Platform#run
        }

        public void run(IResourceStateChangeListener listener) {
            this.listener = listener;
            SafeRunner.run(this);
        }

        @Override
        public void run() throws Exception {
            notify(listener);
        }

        /**
         * Subclasses override this method to send an event safely to a listener
         *
         * @param listener
         */
        protected abstract void notify(IResourceStateChangeListener listener);
    }

    private static class StaleCheckoutInfo {
        IDMWorkspaceFile dmFile;
        boolean revisionExists; // true means revision exists but no longer checked out

        StaleCheckoutInfo(IDMWorkspaceFile dmFile, boolean revisionExists) {
            this.dmFile = dmFile;
            this.revisionExists = revisionExists;
        }
    }

    private class WorkspaceRemoteTree extends DMRemoteTree {

        public WorkspaceRemoteTree() {
            super(new SynchronizerByteStore(REMOTE_TREE), DMWorkspace.this);
        }

        @Override
        protected int[] getAttributesForExpand() {
            return DEFAULT_EXPAND_ATTRS;
        }

        @Override
        protected DMRemoteFile createRemoteFile(DMRemoteFolder parent, IPath filePath, IDMProject project,
                ItemRevision itemRevision, List<ItemRevision> expandedRevisions) {
            List<StaleCheckoutInfo> list = INVALID_CHECKOUTS.get();
            if (list != null) {
                // Only detect invalid checkouts during explicit subscriber refresh
                // if project is scc style remote path = remote offset + project relative path
                // if SEP , then remote path = project relative path
                IPath rel = null;
                if (project.isSccStyle()) {
                    rel = filePath.removeFirstSegments(project.getRemoteOffset().segmentCount());
                } else {
                    rel = filePath;
                }
                IFile file = project.getRoot().getFile(rel);
                if (file.exists()) {
                    try {
                        IDMWorkspaceFile dmFile = (IDMWorkspaceFile) getWorkspaceResource(file);
                        dmFile.setCacheVariants(true);
                        if (dmFile.isManaged() && dmFile.isExtracted()) {
                            IDMRemoteFile extrVariant = dmFile.getBaseFile();
                            boolean found = false;
                            Boolean stillExtracted = null;
                            for (Iterator<ItemRevision> iter = expandedRevisions.iterator(); iter.hasNext();) {
                                ItemRevision otherRev = iter.next();
                                if (extrVariant.isBasedOn(otherRev)) {
                                    found = true;
                                    // should have value as it is queried for expand
                                    stillExtracted = (Boolean) otherRev.getAttribute(SystemAttributes.IS_EXTRACTED);
                                    break;
                                }
                            }
                            if (!found || (found && stillExtracted != null && !stillExtracted.booleanValue())) {
                                list.add(new StaleCheckoutInfo(dmFile, found));
                            }
                        }
                    } catch (CoreException e) {
                        DMTeamPlugin.log(e.getStatus());
                    }
                }
            }
            return super.createRemoteFile(parent, filePath, project, itemRevision, expandedRevisions);
        }

        // Expose this to update the tree from outside (another up-to-date tree)
        @Override
        public boolean setVariant(IResource local, IResourceVariant remote) throws TeamException {
            return super.setVariant(local, remote);
        }
    }

    private static void processSavedMetadataChanges(IMetadataChange[] changes) {
        // this is the body of the listener
        Collection<IResource> cMetadataChanged = LISTENER_METADATA_CHANGED.get();
        for (IMetadataChange mdChange : changes) {
            MetadataTypes mt = mdChange.getType();
            String path = mdChange.getFilename();
            if (debugListeners) {
                System.out.println(
                        TeamUtils.myThread() + " DW psmc " + path + " type " + mt + " change " + mdChange.getChange()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            }
            IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();

            if (mdChange.getChange() == MetadataChangeType.MC_WRITTEN) {
                IResource[] resources = null;
                if (mt == MetadataTypes.MT_ITEM) {
                    resources = root.findFilesForLocationURI(new File(path).toURI());
                } else if (mt == MetadataTypes.MT_DIR) {
                    resources = root.findContainersForLocationURI(new File(path).toURI());
                }
                // have a write to metadata
                if (resources != null && resources.length > 0) {
                    IResource resource = resources[0];
                    // now get matching resource
                    IDMRemoteResource remoteResource = null;
                    try {
                        remoteResource = DMTeamPlugin.getWorkspace().getBaseResource(resource);
                    } catch (TeamException e) {
                        // swallow
                        remoteResource = null;
                    }

                    if (remoteResource != null) {
                        remoteResource.markStale();
                        try {
                            // update base as base is used in fetchVariant / fetch folder
                            DMTeamPlugin.getWorkspace().updateBase(resource, remoteResource);
                        } catch (TeamException e) {
                            DMPlugin.log(
                                    new Status(IStatus.ERROR, DMPlugin.ID, 0, Messages.DMWorkspace_42 + e.getMessage(), e));
                        }
                    }
                    cMetadataChanged.add(resource);
                }

            } else if (mdChange.getChange() == MetadataChangeType.MC_REMOVED) {
                IResource[] resources = null;
                if (mt == MetadataTypes.MT_ITEM) {
                    resources = root.findFilesForLocationURI(new File(path).toURI());
                } else if (mt == MetadataTypes.MT_DIR) {
                    resources = root.findContainersForLocationURI(new File(path).toURI());
                }

                if (resources != null && resources.length > 0) {
                    IResource resource = resources[0];
                    if (resource.exists()) {
                        // metadata was deleted but resource still exists - release base
                        try {
                            ((DMWorkspace) DMTeamPlugin.getWorkspace()).releaseBase(resource);
                            cMetadataChanged.add(resource);

                            IResource movedFrom = ((DMWorkspace) DMTeamPlugin.getWorkspace()).getMovedFrom(resource);
                            // if resource was moved previously and source was deleted ensure that
                            // metadata was released
                            if (movedFrom != null && !movedFrom.exists()) {
                                ((DMWorkspace) DMTeamPlugin.getWorkspace()).releaseBase(movedFrom);
                                cMetadataChanged.add(movedFrom);
                            }
                        } catch (CoreException e) {
                            DMTeamPlugin.log(e.getStatus());
                        }
                    } else {
                        cMetadataChanged.add(resource);
                    }
                }
            }

        } // loop
        try {
            if (!cMetadataChanged.isEmpty()) {
                IResource[] changedResources = cMetadataChanged.toArray(new IResource[cMetadataChanged.size()]);
                changedResources = TeamUtils.getNonOverlapping(changedResources);
                ((DMWorkspace) DMTeamPlugin.getWorkspace()).metadataChanged(changedResources, null);
            }

        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        } finally {
            cMetadataChanged.clear();
        }
    }

    private static class WorkspaceMetadataChangeListener implements IMetadataChangeListener {

        @Override
        public void metadataChanged(IMetadataChange[] changes) {

            // if inside workspace job
            boolean inWsRun = DEFERRED_METADATA_LISTENER_ACTIVE.get().booleanValue();
            if (inWsRun) {
                LinkedList<IMetadataChange[]> saveChanges = SAVED_METADATA_CHANGES.get();
                saveChanges.add(changes);
            } else {
                processSavedMetadataChanges(changes);
            }
        }
    }

    IMetadataChangeListener providerMetadataChangeListener = new WorkspaceMetadataChangeListener();

    DMWorkspace() {
        super(Messages.DMWorkspace_name);
        metadataChangeListener = new MetadataChangeListener();
        remoteTree = new WorkspaceRemoteTree();
        baseTree = new DMBaseResourceVariantTree(
                new PersistentByteStore(getStateFile(METADATA_CACHE), getStateFile(BASE_DELETE_MARKERS)), this);
        baseTreeLock = Job.getJobManager().newLock();
    }

    /**
     * Registers this workspace for resource deltas and as a workspace save participant
     *
     * @throws CoreException
     */
    void initialize() throws CoreException {
        // Called during bundle activation, it is important to register the save participant before resource listeners
        // as its registration may block and while it is blocked we don't want to process any resource deltas
        // fired on other threads as they will trigger parallel bundle activation which is doomed to fail as the
        // bundle is already being activated (this potentially results in messages about timeouts during starting
        // bundle in the .log, slow startup, and other problems).
        registerSaveParticipant();

        // event type is important
        ResourcesPlugin.getWorkspace().addResourceChangeListener(metadataChangeListener, IResourceChangeEvent.POST_CHANGE);
        ResourcesPlugin.getWorkspace().addResourceChangeListener(this, IResourceChangeEvent.POST_CHANGE);
        DMPlugin.getDefault().addRegistryListener(this);

        // set up metadata Listeners
        // in a job as cause bundle startup errors
        registerMetadataListeners();

    }

    /**
     * Register metadata listeners in job
     */
    private void registerMetadataListeners() {
        final IWorkspace workspace = ResourcesPlugin.getWorkspace();
        final IWorkspaceRunnable theRunnable = new IWorkspaceRunnable() {
            @Override
            public void run(IProgressMonitor progress) throws CoreException {
                IDMProject[] projects = getProjects(); // mapped projects

                if (projects.length == 0) {
                    // no projects in workspace setup default for ws root
                    IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();

                    MetadataProvider mdp = MetadataProviderFactory.providerFor(root);
                    try {
                        mdp.addMetadataChangeListener(providerMetadataChangeListener);
                    } finally {
                        mdp.close();
                    }

                } else {
                    for (IDMProject p : projects) {
                        IProject ip = p.getProject();
                        MetadataProvider mdp = MetadataProviderFactory.providerFor(ip);
                        try {
                            mdp.addMetadataChangeListener(providerMetadataChangeListener);
                        } finally {
                            mdp.close();
                        }
                    }
                }
            }
        };
        Job registermdlisteners = new Job(Messages.registerMDListener) {

            @Override
            protected IStatus run(IProgressMonitor monitor) {
                try {
                    workspace.run(theRunnable, Utils.monitorFor(null));
                } catch (CoreException e) {
                    DMTeamPlugin.log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN,
                            "error in regisrering save participant", e)); //$NON-NLS-1$
                }
                return Status.OK_STATUS;
            }
        };
        registermdlisteners.setSystem(true);
        registermdlisteners.setPriority(Job.SHORT);
        registermdlisteners.schedule();
    }

    /**
     * Unregister this workspace from workspace notifications
     */
    void dispose() {
        ResourcesPlugin.getWorkspace().removeSaveParticipant(DMTeamPlugin.ID);
        ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
        ResourcesPlugin.getWorkspace().removeResourceChangeListener(metadataChangeListener);
        DMPlugin.getDefault().removeRegistryListener(this);
        // remove provider listener
        IDMProject[] projects;
        try {
            projects = getProjects();
        } catch (CoreException e) {
            return;
        }
        if (projects.length == 0) {
            // no projects in workspace setup default for ws root
            IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
            MetadataProvider mdp = MetadataProviderFactory.providerFor(root);
            try {
                mdp.removeMetadataChangeListener(providerMetadataChangeListener);
            } finally {
                mdp.close();
            }
        } else {
            // mapped projects
            for (IDMProject p : projects) {
                IProject ip = p.getProject();
                MetadataProvider mdp = MetadataProviderFactory.providerFor(ip);
                try {
                    mdp.removeMetadataChangeListener(providerMetadataChangeListener);
                } finally {
                    mdp.close();
                }
            }
        }
    }

    @Override
    public void addResourceStateChangeListener(IResourceStateChangeListener listener) {
        synchronized (listeners) {
            if (!listeners.contains(listener)) {
                listeners.add(listener);
            }
        }
    }

    @Override
    public void removeResourceStateChangeListener(IResourceStateChangeListener listener) {
        synchronized (listeners) {
            listeners.remove(listener);
        }
    }

    private void fireNotification(Notification notification) {
        // Get a snapshot of the listeners so the list doesn't change while we're firing
        IResourceStateChangeListener[] _listeners = getListeners();
        // Notify each listener in a safe manner (i.e. so their exceptions don't kill us)
        for (int i = 0; i < _listeners.length; i++) {
            IResourceStateChangeListener listener = _listeners[i];
            notification.run(listener);
        }
    }

    private void fireResourceStateChanged(final IResource[] resources) {
        if (resources.length == 0) {
            return;
        }
        fireNotification(new Notification() {
            @Override
            protected void notify(IResourceStateChangeListener listener) {
                listener.resourceStateChanged(resources);
            }
        });
    }

    private void fireResourceModified(final IResource[] resources) {
        if (resources.length == 0) {
            return;
        }
        fireNotification(new Notification() {
            @Override
            protected void notify(IResourceStateChangeListener listener) {
                listener.resourceModified(resources);
            }
        });
    }

    private void fireProjectConfigured(final IProject project) {
        fireNotification(new Notification() {
            @Override
            protected void notify(IResourceStateChangeListener listener) {
                listener.projectConfigured(project);
            }
        });
    }

    private void fireProjectDeconfigured(final IProject project) {
        fireNotification(new Notification() {
            @Override
            protected void notify(IResourceStateChangeListener listener) {
                listener.projectDeconfigured(project);
            }
        });
    }

    private IResourceStateChangeListener[] getListeners() {
        synchronized (listeners) {
            return listeners.toArray(new IResourceStateChangeListener[listeners.size()]);
        }
    }

    @Override
    public DMSyncTreeSubscriber getSubscriber() {
        return this;
    }

    @Override
    public DMRepositoryProvider manage(IProject project, IContainer root, APIObjectAdapter remoteObject)
            throws CoreException {
        return manage(project, root, remoteObject, null, true);
    }

    @Override
    public DMRepositoryProvider manage(IProject project, IContainer root, APIObjectAdapter remoteObject, IPath workAreaPath)
            throws CoreException {
        return manage(project, root, remoteObject, workAreaPath, true);
    }

    @Override
    public DMRepositoryProvider manage(IProject project, IContainer root, APIObjectAdapter remoteObject, IPath workAreaPath,
            boolean doRefresh) throws CoreException {
        DMRepositoryProvider provider = DMRepositoryProvider.getDMProvider(project);
        if (provider == null) {
            // map project to dm provider
            DMRepositoryProvider.map(project, root, remoteObject, workAreaPath);
            provider = DMRepositoryProvider.getDMProvider(project);
            assert provider != null;

            // set tree sync bytes so that root is in sync - doing this upfront avoids weird problems in the sync view
            baseTree.newManagedProject(provider.getIdmProject());
            remoteTree.newManagedProject(provider.getIdmProject());

            // initialize folder statuses
            final TreeSet<IContainer> projectFolders = new TreeSet<IContainer>(new ContainmentComparator(true));
            project.accept(new IResourceVisitor() {
                @Override
                public boolean visit(IResource resource) throws CoreException {
                    if (resource.getType() != IResource.FILE) {
                        projectFolders.add((IContainer) resource);
                    }
                    return true;
                }
            }, IResource.DEPTH_INFINITE, true);
            processContainerStateChanged(projectFolders);

            // mark .metadata as team private
            List<IResource> nonTeamPrivateMetaContainers = MetadataHelper.findMetadataContainers(project, false, true);
            for (Iterator<IResource> iter = nonTeamPrivateMetaContainers.iterator(); iter.hasNext();) {
                IContainer metaContainer = (IContainer) iter.next();
                metaContainer.setTeamPrivateMember(true);
            }

            // notify about added root
            fireProjectConfigured(project);
            if (doRefresh) {
                // Do not use refresh against empty workarea as it could significantly degrade performance.
                // Dimensions plugin creates metadata provider for each file, trying to fill base metadata tree.
                // In the empty folder there are no metadata so it is impossible to cache empty provider.
                refresh(new IResource[] { project }, IResource.DEPTH_INFINITE, false, null);
            } else {
                refreshRemoteTree(new IResource[] { project }, IResource.DEPTH_INFINITE, true, null);
            }

            SubscriberChangeEvent rootDelta = new SubscriberChangeEvent(this, ISubscriberChangeEvent.ROOT_ADDED, project);
            fireTeamResourceChange(new SubscriberChangeEvent[] { rootDelta });

            // set read-only flags where applicable
            setMode(new IResource[] { project }, true, null);
        } else {
            RepositoryProvider.unmap(project);
            DMRepositoryProvider.map(project, root, remoteObject, workAreaPath);
            provider = DMRepositoryProvider.getDMProvider(project);
            assert provider != null;
            // notify about changed root
            fireProjectConfigured(project);
        }
        return provider;
    }

    @Override
    public void unmanage(IProject project, boolean deleteMeta, IProgressMonitor monitor) throws CoreException {
        // collect read-only files first - don't want to make writable files not managed by us
        final List<IResource> readOnlyFiles = new ArrayList<IResource>();
        project.accept(new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                if (resource.getType() == IResource.FILE && TeamUtils.isReadOnly(resource)) {
                    // isManaged() was removed because it causes infinite loop
                    // if unmanage() was called from getIdmProject() method
                    // I hope this check is not necessary
                    readOnlyFiles.add(resource);
                }
                return true;
            }
        });

        IDMProject dmProject = getProject(project);
        IPath workAreaPath = dmProject.getWorkAreaPath();
        if (deleteMeta) {
            // delete marker file if metadata should be deleted
            if (dmProject != null && dmProject.isSccStyle()) {
                IPath path = project.getFullPath().addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);
                IFile eclFile = project.getFile(path);
                if (eclFile != null && eclFile.exists() && eclFile.isTeamPrivateMember()) {
                    eclFile.delete(true, monitor);
                }
            }
        }

        // if this is a regular project we need to remove all virtual child projects
        TeamUtils.unmanageVirtualChildren(project, monitor);
        RepositoryProvider.unmap(project);
        // flush all cached state for this project
        flushBaseTree(project);
        getRemoteTree().flushVariants(project, IResource.DEPTH_INFINITE);
        flushFolderStatus(project);
        flushMoveState(project);

        for (int i = 0; i < readOnlyFiles.size(); i++) {
            TeamUtils.setReadOnly(readOnlyFiles.get(i), false);
        }
        monitor = Utils.monitorFor(monitor);
        try {
            final List<IResource> metaContainers = MetadataHelper.findMetadataContainers(project, true, true);
            monitor.beginTask(null, metaContainers.size() * 1000);
            for (int i = 0; i < metaContainers.size(); i++) {
                IFolder metaFolder = (IFolder) metaContainers.get(i);
                monitor.subTask(metaFolder.getFullPath().toString());
                if (deleteMeta) {
                    metaFolder.delete(true, false, Utils.subMonitorFor(monitor, 1000));
                } else if (metaFolder.isTeamPrivateMember()) {
                    metaFolder.setTeamPrivateMember(false);
                }
            }
        } finally {
            monitor.done();
        }

        if (workAreaPath != null && !workAreaPath.isEmpty()) {
            MetadataProviderFactory.removeProvider(workAreaPath.toOSString());
        } else {
            MetadataProviderFactory.removeProvider(project.getLocation().toOSString());
        }

        fireProjectDeconfigured(project);
        fireTeamResourceChange(new SubscriberChangeEvent[] {
                new SubscriberChangeEvent(this, ISubscriberChangeEvent.ROOT_REMOVED, project) });
    }

    @Override
    public void unmanage(IResource resource, IProgressMonitor monitor) throws CoreException {
        resource = TeamUtils.getResource(resource);
        unmanage(resource, true, monitor);
    }

    private void flushBaseTree(IProject project) throws CoreException, TeamException {
        baseTree.prepareForDeletion(project);
        baseTree.flushVariants(project, IResource.DEPTH_INFINITE);
    }

    void unmanage(IResource resource, boolean refresh, IProgressMonitor monitor) throws CoreException {
        resource = TeamUtils.getResource(resource);
        monitor = Utils.monitorFor(monitor);
        WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();
        if (debugResources) {
            System.out.println("DW Unmanage " + resource.toString()); //$NON-NLS-1$
        }
        releaseBase(resource);
        DMProject dmProject = (DMProject) DMTeamPlugin.getWorkspace().getProject(resource);
        // this hack - get&check metadataProjID before TeamUtils.isResourceFromForeignStream()
        // is because WorkspaceMetadataManager.getInstance().updateMetadata()
        // writes project field as plain text (this is a problem)
        BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
        String metadataProjID = null;
        if (metadata != null) {
            metadataProjID = (resource.getType() == IResource.FOLDER)
                    ? ((DirectoryMetadata) metadata).getProject() : ((ItemMetadata) metadata).getProject();
        }

        if (dmProject != null && metadataProjID != null && TeamUtils.isResourceFromForeignStream(resource)
                && (TeamUtils.isLocalWorksetPointingToForeignStream(resource)
                        || TeamUtils.isLocalWorksetPointingToForeignProject(resource))) {
            metadata.put(TeamUtils.METADATA_OF_DELETED_FOREIGN_RESOURCE, "yes"); //$NON-NLS-1$
            WorkspaceMetadataManager.getInstance().updateMetadata(resource, metadata);
        } else {
            if (!metaMan.deleteMetadata(resource, WorkspaceMetadataManager.DELETE_ALL)) {
                // throw?
            }
            if (resource.getType() != IResource.FILE && resource.exists()) {
                metaMan.deleteMetadataFolders((IContainer) resource);
            }
        }
        if (refresh & getBaseTree().hasResourceVariant(resource)) { // resource delta could have refreshed the tree already
            refreshBaseTree(new IResource[] { resource }, IResource.DEPTH_INFINITE, null);
        }
        DMPlugin.getDefault()
                .getConsole()
                .printMessage(NLS.bind(Messages.DMWorkspace_unmanaged, resource.getFullPath().toString()));
    }

    @Override
    public DMRepositoryProvider manageVirtual(IProject project, IProject toProject) throws CoreException {
        DMRepositoryProvider provider = DMRepositoryProvider.getDMProvider(project);
        if (provider == null) {
            DMRepositoryProvider.mapVirtual(project, toProject);
            fireProjectConfigured(project);
            refresh(new IResource[] { project }, IResource.DEPTH_INFINITE, false, null);
            SubscriberChangeEvent rootDelta = new SubscriberChangeEvent(this, ISubscriberChangeEvent.ROOT_ADDED, project);
            fireTeamResourceChange(new SubscriberChangeEvent[] { rootDelta });
            provider = DMRepositoryProvider.getDMProvider(project);
        }
        return provider;
    }

    @Override
    public void unmanageVirtual(IProject project, IProgressMonitor monitor) throws CoreException {
        IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(project);
        if (dmProject instanceof VirtualIdmProject) {
            RepositoryProvider.unmap(project);
            fireProjectDeconfigured(project);
            fireTeamResourceChange(new SubscriberChangeEvent[] {
                    new SubscriberChangeEvent(this, ISubscriberChangeEvent.ROOT_REMOVED, project) });
        }
    }

    @Override
    public void makeIncoming(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        if (resource.getType() == IResource.FILE) {
            WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();
            ItemMetadata itemMetadata = (ItemMetadata) metaMan.getMetadata(resource);
            if (itemMetadata != null) {
                itemMetadata.setFileVersion(-1);
                metaMan.updateMetadata(resource, itemMetadata);
                refreshBaseTree(new IResource[] { resource }, IResource.DEPTH_INFINITE, null);
            }
        }
    }

    @Override
    public IDMProject[] getProjects() throws CoreException {
        IProject[] allProjects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
        List<IDMProject> result = new ArrayList<IDMProject>();
        for (int i = 0; i < allProjects.length; i++) {
            DMRepositoryProvider dmProvider = (DMRepositoryProvider) RepositoryProvider.getProvider(allProjects[i],
                    DMRepositoryProvider.ID);
            if (dmProvider != null) {
                IDMProject idmProject = dmProvider.getIdmProject();
                if (idmProject != null) {
                    result.add(idmProject);
                }
            }
        }
        return result.toArray(new IDMProject[result.size()]);
    }

    @Override
    public IDMProject getProject(IResource resource) throws CoreException {
        DMRepositoryProvider dmProvider = DMRepositoryProvider.getDMProvider(resource);
        if (dmProvider == null) {
            return null;
        }
        return dmProvider.getIdmProject();
    }

    @Override
    public IDMRemoteResource getBaseResource(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        return (IDMRemoteResource) getBaseTree().getResourceVariant(resource);
    }

    @Override
    public IDMRemoteResource getRemoteResource(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        return (IDMRemoteResource) getRemoteTree().getResourceVariant(resource);
    }

    @Override
    public boolean isManaged(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        boolean managed = getBaseTree().hasResourceVariant(resource);
        if (debugByteStore) {
            System.out.println("DW PBS is managed " + resource.toString() + " " + managed); //$NON-NLS-1$ //$NON-NLS-2$
        }
        return managed;
    }

    @Override
    public boolean hasRemote(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        return getRemoteTree().hasResourceVariant(resource);
    }

    @Override
    public boolean updateBase(IResource resource, IResourceVariant remote) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        return ((DMBaseResourceVariantTree) getBaseTree()).setVariant(resource, remote);
    }

    @Override
    public boolean updateRemote(IResource resource, IResourceVariant remote) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        return ((WorkspaceRemoteTree) getRemoteTree()).setVariant(resource, remote);
    }

    @Override
    public boolean isOrphanedSubtree(IContainer container) throws CoreException {
        try {
            container = TeamUtils.getContainer(container);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        if (container.getType() != IResource.FOLDER || TeamUtils.isLinkedResource(container)) {
            return false;
        }
        if (WorkspaceMetadataManager.getInstance().getMetadata(container) != null) {
            return false;
        }
        return WorkspaceMetadataManager.hasMetadata(container);
    }

    @Override
    public boolean isDerivedAndUnmanaged(File resourceFile) {
        return isDerivedAndUnmanaged(resourceFile, true);
    }

    private boolean isManaged(IResource[] resources) {
        boolean managed = false;
        if (resources != null) {
            for (IResource currentResource : resources) {
                try {
                    if (isManaged(currentResource)) {
                        managed = true;
                        break;
                    }
                } catch (TeamException e) {
                    // It's better to treat this case as the currentResource is not managed and continue iteration.
                    // isManaged() still can return true for another resource and then the resource certainly shouldn't
                    // be ignored. After scanning workarea all found managed and unmanaged resource paths should be passed to
                    // the server to get detected changes and resolutions from the server. In the worst case some resource
                    // can be treated as unmanaged due to this exception and the resource can be replaced from repository or
                    // deleted. But this resource is derived and can be easily regenerated. If after this exception return
                    // true from the method isDerivedAndUnmanaged(File resourceFile, boolean checkManaged) even non-derived
                    // resource will be treated as derived and therefore their paths will not be passed to the server after
                    // workarea scan. Due to this if some folder with local non-derived unmanaged files was deleted in
                    // repository update operation will not know about such files and the server will return resolution to
                    // delete entire directory. This is incorrect. Therefore it's more safe to treat this case as the
                    // currentResource is not managed.
                    DMTeamPlugin.log(e.getStatus());
                }
            }
        }
        return managed;
    }

    private boolean isDerived(IResource[] resources) {
        boolean derived = false;
        if (resources != null) {
            for (IResource currentResource : resources) {
                if (currentResource.isDerived(IResource.CHECK_ANCESTORS)) {
                    derived = true;
                    break;
                }
            }
        }
        return derived;
    }

    private boolean isDerivedAndUnmanaged(File resourceFile, boolean checkManaged) {
        boolean managed = false;
        boolean derived = false;
        IResource[] resources = TeamUtils.findResourcesForLocationFile(resourceFile);
        if (checkManaged) {
            managed = isManaged(resources);
        }
        if (!managed) {
            derived = isDerived(resources);
        }
        return derived && !managed;
    }

    @Override
    public boolean isDerived(IResource resource) {
        String resourcePath = resource.getLocation().toOSString();
        File resourceFile = new File(resourcePath);
        return isDerivedAndUnmanaged(resourceFile, false);
    }

    @Override
    public boolean isIgnored(IResource resource) throws TeamException {
        return isIgnored(resource, null);
    }

    @Override
    public boolean isIgnored(IResource resource, MetadataProvider provider) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        // a managed resource is never ignored unless it is linked
        boolean resourceIsLinked = TeamUtils.isLinkedResource(resource);
        if ((!resourceIsLinked && isManaged(resource)) || resource.getType() == IResource.ROOT
                || resource.getType() == IResource.PROJECT) {
            return false;
        }

        // if the resource is a derived or linked resource, it is ignored
        if ((TeamUtils.isDerivedResourcesIgnored() && isDerived(resource)) || resourceIsLinked) {
            return true;
        }

        if (resource.getType() != IResource.FILE) {
            MetadataProvider mdSession = null;
            if (provider == null) {
                mdSession = MetadataProviderFactory.providerFor(resource.getLocation(), false);
            } else {
                mdSession = provider;
            }
            try {
                if (mdSession.metadataDirname().equals(resource.getName())) {
                    // always ignore metadata folders
                    return true;
                }
            } finally {
                if (provider == null && mdSession != null) {
                    mdSession.close();
                }
            }
        }

        // check the global ignores from Team
        if (Team.isIgnoredHint(resource)) {
            return true;
        }

        // check the parent
        IContainer parent = resource.getParent();
        if (parent != null && isIgnored(parent, provider)) {
            return true;
        }

        if (checkDmIgnore(resource)) {
            return true;
        }

        // not ignored
        return false;
    }

    @Override
    public void addIgnorePattern(IContainer parent, String pattern, boolean isRecursive) throws CoreException {
        parent = TeamUtils.getContainer(parent);

        Assert.isLegal(parent != null && parent.getType() != IResource.ROOT, "invalid parent"); //$NON-NLS-1$
        pattern = pattern == null ? Utils.EMPTY_STRING : pattern.trim();
        Assert.isLegal(pattern.length() > 0, "invalid pattern"); //$NON-NLS-1$

        if (isRecursive) {
            pattern = RECURSIVE_MASK_PREFIX + pattern;
        }

        String[] ignores = readIgnoreFile(parent);
        if (ignores != null) {
            for (int i = 0; i < ignores.length; i++) {
                if (ignores[i].equals(pattern)) {
                    return; // pattern has already been added
                }
            }
            // add the pattern
            String[] oldIgnores = ignores;
            ignores = new String[oldIgnores.length + 1];
            System.arraycopy(oldIgnores, 0, ignores, 0, oldIgnores.length);
            ignores[oldIgnores.length] = pattern;
        } else {
            ignores = new String[] { pattern };
        }
        cacheFolderIgnores(parent, ignores);
        writeIgnoreFile(parent, ignores);
        // broadcast changes to unmanaged children - they are the only candidates for being ignored
        List<IResource> possibleIgnores = new ArrayList<IResource>();
        accumulateNonManagedChildren(parent, possibleIgnores);
        if (!possibleIgnores.isEmpty()) {
            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this,
                    possibleIgnores.toArray(new IResource[possibleIgnores.size()])));
        }
    }

    @Override
    public boolean isModified(IResource resource) throws CoreException {
        Assert.isNotNull(resource);
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        if (!resource.exists()) {
            return false;
        }
        if (getWorkspaceResource(resource) == null) {
            return false;
        }
        return getWorkspaceResource(resource).isModified();
    }

    static boolean isFileModified(IFile local, ItemMetadata base) {
        long baseModeTime = base.getModTime() != null ? base.getModTime().getTime() : 0L;
        return compareTimestamps(local.getLocalTimeStamp(), baseModeTime);
    }

    static boolean isFileModified(IResource local, IDMRemoteFile base) {
        return compareTimestamps(local.getLocalTimeStamp(), base.getModtime());
    }

    // return true if different ts
    static boolean compareTimestamps(long localTS, long baseTS) {
        // ignore ms values as this is the resolution supported by the server
        return (localTS / 1000) != (baseTS / 1000);
    }

    @Override
    public void setMode(IResource[] resources, boolean pessimistic, IProgressMonitor monitor) throws CoreException {
        if (resources == null || resources.length == 0) {
            return;
        }
        List<IFile> files = TeamUtils.collectFiles(resources);
        if (files.isEmpty()) {
            return;
        }
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(
                NLS.bind(Messages.DMWorkspace_setReadOnly, pessimistic ? Messages.DMWorkspace_on : Messages.DMWorkspace_off),
                1000);
        try {
            IProgressMonitor subMon = Utils.subMonitorFor(monitor, 500);
            subMon.beginTask(null, files.size());
            for (Iterator<IFile> fileIter = files.iterator(); fileIter.hasNext();) {
                IFile file = fileIter.next();
                file = TeamUtils.getFile(file);
                IDMWorkspaceFile workspaceFile = (IDMWorkspaceFile) getWorkspaceResource(file);
                boolean change = (pessimistic && workspaceFile.isOptimistic())
                        || (!pessimistic && workspaceFile.isPessimistic());
                if (change) {
                    TeamUtils.setReadOnly(file, pessimistic);
                }
                subMon.worked(1);
            }
            subMon.done();
            refreshBaseTree(resources, IResource.DEPTH_INFINITE,
                    Utils.subMonitorFor(monitor, 500, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK));
        } finally {
            monitor.done();
        }
    }

    @Override
    public IDMWorkspaceResource getWorkspaceResource(IResource original) throws CoreException {
        IResource resource;
        try {
            resource = TeamUtils.getResource(original);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        IDMProject project = getProject(resource);
        if (project == null || !project.isManaged(resource)) {
            return null;
        }

        IDMWorkspaceResource workspaceResource = null;
        if (workspaceResource == null) {
            if (resource.getType() == IResource.FILE) {
                workspaceResource = new DMWorkspaceFile(resource, project, original);
            } else {
                DMWorkspaceFolder folder = new DMWorkspaceFolder(resource, project,
                        getCachedFolderStatus(resource.getFullPath()), original);
                workspaceResource = folder;
            }
        }
        return workspaceResource;
    }

    private WorkspaceFolderStatus getCachedFolderStatus(IPath folderPath) {
        IPath key = folderPath;
        WorkspaceFolderStatus result = null;
        synchronized (folderStatusCache) {
            ensureFolderStatusCacheInitialized();
            result = folderStatusCache.get(key);
        }
        if (result == null) {
            result = WorkspaceFolderStatus.NULL_STATUS;
        }
        return result;
    }

    private void cacheFolderStatus(IPath folderPath, WorkspaceFolderStatus status) {
        synchronized (folderStatusCache) {
            ensureFolderStatusCacheInitialized();
            if (debugFolderStatus) {
                System.out.println("DW cache folder status  " + folderPath + " " + status.toString()); //$NON-NLS-1$ //$NON-NLS-2$
            }
            folderStatusCache.put(folderPath, status);
        }
    }

    private void ensureFolderStatusCacheInitialized() {
        if (folderCacheStatus == INITIALIZED || folderCacheStatus == INITIALIZING) {
            return;
        }
        try {
            folderCacheStatus = INITIALIZING;
            folderStatusCache.clear();
            readFolderStatusCache();
        } finally {
            folderCacheStatus = UNINITIALIZED;
        }
        folderCacheStatus = INITIALIZED;
    }

    private void flushFolderStatus(IProject project) {
        if (debugFolderStatus) {
            System.out.println("DW flush folder status " + project.toString()); //$NON-NLS-1$
        }
        String name = project.getName();
        synchronized (folderStatusCache) {
            ensureFolderStatusCacheInitialized();
            for (Iterator<Map.Entry<IPath, WorkspaceFolderStatus>> iter = folderStatusCache.entrySet().iterator(); iter
                    .hasNext();) {
                Map.Entry<IPath, WorkspaceFolderStatus> entry = iter.next();
                IPath entryPath = entry.getKey();
                if (name.equals(entryPath.segment(0))) {
                    iter.remove();
                }
            }
        }
    }

    /***
     * @param list
     *            List that will be filled with resources that needs to refresh its metadata.
     * @throws CoreException
     */
    private void collectForMdRefresh(IResource[] roots, int depth, final List<IResource> list) throws CoreException {
        IResourceVisitor visitor = new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                if (resource.getType() != IResource.PROJECT) {
                    list.add(resource);
                }
                return true;
            }
        };
        for (int i = 0; i < roots.length; i++) {
            roots[i].accept(visitor, depth, IContainer.INCLUDE_PHANTOMS | IContainer.DO_NOT_CHECK_EXISTENCE);
        }
    }

    // sync up workspace state with local file system
    private void lfsSync(final IResource[] resources, final int depth, IProgressMonitor monitor) throws CoreException {
        long start = 0l;
        if (debug) {
            System.out.println("+ lfsSync"); //$NON-NLS-1$
            start = System.currentTimeMillis();
        }

        // DEF146784 - ensure the rule includes the first existing resource up the hierarchy
        // as TeamUtils.refreshLocal will start from the topmost non-existing resource and default
        // refresh rule is its parent per ResourceRuleFactory.refreshRule()
        Set<IResource> parents = new HashSet<IResource>();
        for (int i = 0; i < resources.length; i++) {
            IResource parent = TeamUtils.parent(resources[i]);
            while (parent.getType() != IResource.PROJECT && !parent.exists()) {
                parent = parent.getParent();
            }
            parents.add(parent);
        }
        MultiRule rule = new MultiRule(TeamUtils.getNonOverlapping(parents.toArray(new IResource[parents.size()])));

        ResourcesPlugin.getWorkspace().run(new IWorkspaceRunnable() {

            @Override
            public void run(IProgressMonitor monitor1) throws CoreException {
                IProgressMonitor refreshMon = Utils.subMonitorFor(monitor1, 25);
                refreshMon.beginTask(null, 10 * resources.length);
                for (int i = 0; i < resources.length; i++) {
                    TeamUtils.refreshLocal(resources[i], depth, Utils.subMonitorFor(refreshMon, 10));
                }
                List<IResource> mdSync = new ArrayList<IResource>(); // resources for which to sync up metadata
                collectForMdRefresh(resources, depth, mdSync);

                IResource[] resourcesToRefresh = mdSync.toArray(new IResource[mdSync.size()]);

                // handle the case of pending metadata entry of foreign deleted resource
                if (resourcesToRefresh.length > 0 && TeamUtils.isLocalWorksetAProject(resourcesToRefresh[0]) != null) {
                    for (IResource resource : resourcesToRefresh) {
                        if (TeamUtils.isSpecialCaseOfFolderAndFileDeletion(resource, false) && !hasRemote(resource)) {
                            WorkspaceMetadataManager.getInstance().deleteMetadata(resource,
                                    WorkspaceMetadataManager.DELETE_ALL);
                        }
                    }
                }

                WorkspaceMetadataManager.refreshMetadata(resourcesToRefresh, Utils.subMonitorFor(monitor1, 25));
            }

        }, rule, IWorkspace.AVOID_UPDATE, monitor);

        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- lfsSync done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    @Override
    public void refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
        refresh(resources, depth, false, monitor);
    }

    public void refresh(IResource[] resources, int depth, boolean beforeDownload, IProgressMonitor monitor)
            throws TeamException {
        monitor = Utils.monitorFor(monitor);
        long kstart = 0l;
        if (debug) {
            System.out.println("+ refresh() begin"); //$NON-NLS-1$
            kstart = System.currentTimeMillis();
        }
        try {
            monitor.beginTask(null, 1500);
            if (resources == null || resources.length == 0) {
                return;
            }

            resources = TeamUtils.getNonOverlapping(resources, depth);
            Set<IResource> allChanges = new HashSet<IResource>();
            long start = 0l;
            if (debug) {
                System.out.println("+ refresh() local tree"); //$NON-NLS-1$
                start = System.currentTimeMillis();
            }

            try {
                // refresh local may send resource deltas that can be reported
                // in a separate thread via a call to metadataChanged by the
                // metadata listener, we synchronize on a lock to ensure sure
                // this method picks the changes, however if delta notification happens
                // on the same thread (it is up to the platform) some sync state changes may
                // be sent out before this method completes
                if (debugResources) {
                    System.out.println(TeamUtils.myThread() + " dmws refresh btl lfs acquire"); //$NON-NLS-1$
                }
                baseTreeLock.acquire();
                lfsSync(resources, depth, Utils.subMonitorFor(monitor, 50));
                IResource[] baseChanges = refreshBaseTree(resources, depth, false, Utils.subMonitorFor(monitor, 200));
                allChanges.addAll(Arrays.asList(baseChanges));
            } finally {
                if (debugResources) {
                    System.out.println(TeamUtils.myThread() + " dmws refresh btl lfs release"); //$NON-NLS-1$
                }
                baseTreeLock.release();
                if (debug) {
                    long stop = System.currentTimeMillis();
                    System.out.println("- refresh() local tree done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
                }
            }

            if (debug) {
                System.out.println("+ refresh() remote tree"); //$NON-NLS-1$
                start = System.currentTimeMillis();
            }

            List<StaleCheckoutInfo> ic = new ArrayList<StaleCheckoutInfo>(); // invalid checkouts detected in this refresh
            INVALID_CHECKOUTS.set(ic); // workspace remote tree will add invalid checkouts if non-null
            IResource[] remoteChanges = refreshRemoteTree(resources, depth, false, Utils.subMonitorFor(monitor, 700));

            // need to process remote changes
            for (IResource remChanged : remoteChanges) {
                if (remChanged.isPhantom() && isManaged(remChanged) && !remoteTree.hasResourceVariant(remChanged)) {
                    if (debugResources) {
                        System.out.println(TeamUtils.myThread() + " dmws refresh local managed phantom, remote gone " //$NON-NLS-1$
                                + remChanged.toString());
                    }
                    // phantom and managed but remote not there
                    releaseBase(remChanged, true, IResource.DEPTH_INFINITE, null);
                    // was this the source of a move
                    if (movedSrcDst.containsKey(remChanged)) {
                        IResource dstRes = movedSrcDst.get(remChanged);
                        if (debugResources) {
                            System.out.println(
                                    TeamUtils.myThread() + " dmws refresh local managed phantom, remote gone was move src " //$NON-NLS-1$
                                            + remChanged.toString() + " " + dstRes.toString()); //$NON-NLS-1$
                        }
                        if (dstRes != null) {
                            unregisterMove(dstRes);
                        }
                    }
                }
            }

            allChanges.addAll(Arrays.asList(remoteChanges));
            if (debug) {
                long stop = System.currentTimeMillis();
                System.out.println("- refresh() remote tree done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
            }

            if (DMTeamPlugin.getDefault().isCleanTimetsaps()) {
                List<IResource> cleaned = cleanTimestamps(resources, depth, false, false, Utils.subMonitorFor(monitor, 100));
                allChanges.addAll(cleaned);
            } else {
                monitor.worked(100);
            }

            IResource[] changedResources = allChanges.toArray(new IResource[allChanges.size()]);

            if (!beforeDownload) {
                queryContentStatus(changedResources, depth, null, Utils.subMonitorFor(monitor, 100));
            } else {
                monitor.worked(100);
            }

            if (!beforeDownload) {
                IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 150);
                try {
                    subMonitor.beginTask(null, IProgressMonitor.UNKNOWN);
                    if (debugResources) {
                        System.out.println(TeamUtils.myThread() + " dmws refresh btl move rep acquire"); //$NON-NLS-1$
                    }

                    // lock concurrent access to MovedInRepostoryResources cache
                    baseTreeLock.acquire();

                    List<IResource> movedChanges = searchForMovedInRepostoryResources(resources, depth, subMonitor);
                    if (movedChanges.size() > 0) {
                        allChanges.addAll(movedChanges);
                        changedResources = allChanges.toArray(new IResource[allChanges.size()]);
                        if (debugResources) {
                            System.out.println("changedResources"); //$NON-NLS-1$
                            for (IResource r : changedResources) {
                                System.out.println(r.toString());
                            }
                        }
                    }
                } finally {
                    if (debugResources) {
                        System.out.println(TeamUtils.myThread() + " dmws refresh btl  move rep release"); //$NON-NLS-1$
                    }
                    baseTreeLock.release();
                    subMonitor.done();
                }
            } else {
                monitor.worked(150);
            }

            allChanges = TeamUtils.getAllNestedChanges(allChanges);

            // FIXME: 12-26-13, works long on the big folder hierarchy with a lot of
            // files (60K for example) because recursively updates all child statuses
            IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 100);
            try {
                subMonitor.beginTask(null, IProgressMonitor.UNKNOWN);
                processResourceStateChanges(allChanges);
            } finally {
                subMonitor.done();
            }

            if (debug) {
                System.out.println("+ refresh() firing changes"); //$NON-NLS-1$
                start = System.currentTimeMillis();
            }
            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, changedResources));
            if (updateFromReqSubscriber != null) {
                for (int i = 0; i < remoteChanges.length; i++) {
                    // update remote tree for custom subscriber as result of dmworkspace refresh operation
                    ((CustomResourceVariantTree) updateFromReqSubscriber.getRemoteTree()).getByteStore()
                            .setBytes(remoteChanges[i], getRemoteTree().getResourceVariant(remoteChanges[i]).asBytes());
                }
                updateFromReqSubscriber.fireTeamResourceChange(
                        SubscriberChangeEvent.asSyncChangedDeltas(updateFromReqSubscriber, changedResources));
            }
            if (debug) {
                long stop = System.currentTimeMillis();
                System.out.println("- refresh() firing changes done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
            }

            if (!ic.isEmpty()) {
                IProgressMonitor monitor2 = Utils.subMonitorFor(monitor, 100);
                monitor2.beginTask(null, ic.size() * 10);
                List<IFile> processed = new ArrayList<IFile>();
                for (Iterator<StaleCheckoutInfo> iter = ic.iterator(); iter.hasNext();) {
                    StaleCheckoutInfo sci = iter.next();
                    IDMWorkspaceFile dmFile = sci.dmFile;
                    UndoCheckoutRequest request = new UndoCheckoutRequest(dmFile.getLocalFile(),
                            dmFile.getBaseFile().getItemRevision());
                    request.setReplace(UndoCheckoutRequest.REPLACE_METADATA_ONLY);
                    request.setMetadataReplace(
                            sci.revisionExists ? UndoCheckoutRequest.REPLACE_BASE : UndoCheckoutRequest.REPLACE_LATEST);
                    request.setMakeReadOnly(dmFile.getLocalFile().isReadOnly());
                    request.processReplace(Utils.subMonitorFor(monitor2, 10));
                    // need to refresh base
                    processed.add(dmFile.getLocalFile());
                }
                refreshBaseTree(processed.toArray(new IResource[processed.size()]), IResource.DEPTH_INFINITE,
                        Utils.subMonitorFor(monitor2, 10));
                monitor2.done();
            } else {
                monitor.worked(100);
            }
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        } finally {
            INVALID_CHECKOUTS.set(null);
            if (debug) {
                long kstop = System.currentTimeMillis();
                System.out.println("- refresh() done in " + (kstop - kstart) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            monitor.done();
        }
    }

    void processResourceStateChanges(Collection<IResource> resources) throws CoreException {
        long start = 01;
        if (debug) {
            System.out.println("+ processResourceStateChanges"); //$NON-NLS-1$
            start = System.currentTimeMillis();
        }

        Set<IResource> resourcesLookup = new HashSet<IResource>(resources);

        Set<IResource> allChanges = new HashSet<IResource>();
        Set<IResource> originalChanges = new HashSet<IResource>();
        NavigableSet<IContainer> parents = new TreeSet<IContainer>(new ContainmentComparator(true));
        for (Iterator<IResource> iter = resourcesLookup.iterator(); iter.hasNext();) {
            IResource resource = iter.next();
            IResource original = TeamUtils.getResource(resource);
            if (!original.equals(resource) && !resourcesLookup.contains(original)) {
                originalChanges.add(original);
            }

            allChanges.add(resource);
            collectAncestry(resource, parents);
            if (resource.getType() != IResource.FILE && resource instanceof IContainer) {
                parents.add((IContainer) resource);
            }
        }
        allChanges.addAll(processContainerStateChanged(parents));
        fireResourceStateChanged(allChanges.toArray(new IResource[allChanges.size()]));
        if (!originalChanges.isEmpty()) {
            processResourceStateChanges(originalChanges);
        }

        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- processResourceStateChanges  done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    void collectAncestry(IResource resource, Collection<IContainer> ancestry) {
        IContainer parent = resource.getParent();
        if (parent.getType() == IResource.ROOT) {
            return;
        }
        ancestry.add(parent);
        collectAncestry(parent, ancestry);
    }

    void collectAffectedAncestry(IResource resource) {
        collectAncestry(resource, CONTAINER_CHANGES.get());
    }

    // iteration should be from deeper to shallower, see ContainmentComparator
    Collection<IContainer> processContainerStateChanged(Collection<IContainer> containers) throws CoreException {
        if (containers.isEmpty()) {
            return Collections.emptyList();
        }

        Map<IProject, MetadataProvider> cache = new HashMap<IProject, MetadataProvider>();
        try {
            List<IContainer> result = new ArrayList<IContainer>();
            for (Iterator<IContainer> containerIter = containers.iterator(); containerIter.hasNext();) {
                IContainer container = containerIter.next();
                if (!container.exists() && !container.isPhantom()) {
                    continue;
                }
                IDMRemoteResource base = getBaseResource(container);
                IDMRemoteResource remote = getRemoteResource(container);

                IProject project = container.getProject();
                MetadataProvider metadataProvider = cache.get(project);
                if (metadataProvider == null) {
                    metadataProvider = MetadataProviderFactory.providerFor(project);
                    cache.put(project, metadataProvider);
                }

                WorkspaceFolderStatus status = WorkspaceFolderStatus.createFolderStatus(container, base, remote,
                        metadataProvider);
                IResource[] members = container.members(true);
                for (int i = 0; i < members.length; i++) {
                    if (debugResources) {
                        System.out.println(
                                "DW pcsc " + members[i].toString() + " " + TeamUtils.resourceProperties(members[i])); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                    IDMWorkspaceResource workspaceResource = getWorkspaceResource(members[i]);
                    status.update(workspaceResource, metadataProvider);
                }

                synchronized (folderStatusCache) {
                    IPath containerPath = container.getFullPath();
                    WorkspaceFolderStatus currentStatus = getCachedFolderStatus(containerPath);
                    if (!currentStatus.equals(status)) {
                        cacheFolderStatus(containerPath, status);
                        result.add(container);
                    }
                }
            }
            return result;
        } finally {
            for (MetadataProvider provider : cache.values()) {
                provider.close();
            }
        }

    }

    private void refreshBaseTree(IResource[] resources, int depth, IProgressMonitor monitor) throws CoreException {
        refreshBaseTree(resources, depth, true, monitor);
    }

    // returns changed resources
    private IResource[] refreshBaseTree(IResource[] resources, int depth, boolean sendStateChanges, IProgressMonitor monitor)
            throws CoreException {
        if (debugResources) {
            System.out.println(TeamUtils.myThread() + "DWS rBT " + resources.length + " resources"); //$NON-NLS-1$ //$NON-NLS-2$
            for (IResource r : resources) {
                System.out.println("    " + r.getLocation().toOSString()); //$NON-NLS-1$
            }
        }
        monitor = Utils.monitorFor(monitor);
        long start = 0l;
        if (debug) {
            System.out.println("+ Refreshing base tree for " + resources.length + " resources"); //$NON-NLS-1$ //$NON-NLS-2$
            start = System.currentTimeMillis();
        }
        IResource[] baseChanges = getBaseTree().refresh(resources, depth, monitor);
        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- Refreshing base tree done, took " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if (baseChanges.length > 0) {
            handleBaseChanges(baseChanges, sendStateChanges);
        }
        return baseChanges;
    }

    void handleBaseChanges(IResource[] baseChanges, boolean sendStateChanges) throws CoreException {
        long start = 0l;
        if (debug) {
            System.out.println("+ Handling base tree changes for " + baseChanges.length + " resources"); //$NON-NLS-1$ //$NON-NLS-2$
            start = System.currentTimeMillis();
        }
        Set<IResource> allBaseChanges = new HashSet<IResource>(Arrays.asList(baseChanges));
        for (int i = 0; i < baseChanges.length; i++) {
            IResource baseChange = baseChanges[i];
            baseChange = TeamUtils.getResource(baseChange);
            IResource source = null;
            IDMRemoteResource baseResource = (IDMRemoteResource) getBaseTree().getResourceVariant(baseChange);
            IResource movedParent = null;
            if (baseChange.getType() == IResource.PROJECT) {
                String movedFrom = ((IProject) baseChange).getPersistentProperty(DMRepositoryProvider.DM_PROJECT_MOVED_PROP);
                if (baseResource != null && !Utils.isNullEmpty(movedFrom)) {
                    // cache move state if not yet previously cached, this
                    // should handle external moves too
                    source = registerMove(baseChange, movedFrom, baseResource.getMovedFromProject(),
                            baseResource.getMovedFromProjectType(), baseResource.getProject().getConnection());
                } else {
                    source = unregisterMove(baseChange);
                }
            } else {
                if (baseResource != null && baseResource.isMoved()) {
                    if ((movedParent = TeamUtils.getParentWithMovedFromMetadata(baseChange)) != null) {
                        boolean movesCached = false;
                        if (movedParent instanceof IProject) {
                            movesCached = isMoved(baseChange);
                        } else {
                            movesCached = isMoved(movedParent) && isMoved(baseChange);
                        }
                        if (movesCached) {
                            source = getMovedFrom(baseChange);
                        }
                    } else {
                        source = registerMove(baseChange, baseResource.getMovedFromPath(),
                                baseResource.getMovedFromProject(), baseResource.getMovedFromProjectType(),
                                baseResource.getProject().getConnection());
                    }
                } else if (baseResource != null
                        && ((movedParent = TeamUtils.getParentWithMovedFromMetadata(baseChange)) != null)) {
                    boolean movesCached = false;
                    if (movedParent instanceof IProject) {
                        movesCached = isMoved(baseChange);
                    } else {
                        movesCached = isMoved(movedParent) && isMoved(baseChange);
                    }
                    if (movesCached) {
                        source = getMovedFrom(baseChange);
                    }
                } else {
                    source = unregisterMove(baseChange);
                }

                unregisterForeignUpdateSyncKind(baseChange); // remove from the table of verified foreign update status
            }
            if (source != null) {// include changed move sources to the base tree change set
                allBaseChanges.add(source);
            }
        }
        if (baseChanges.length != allBaseChanges.size()) {
            baseChanges = allBaseChanges.toArray(new IResource[allBaseChanges.size()]);
        }
        if (sendStateChanges && baseChanges.length > 0) { // if requested notify state change listener
            if (debug) {
                System.out.println("+ Firing changes"); //$NON-NLS-1$
                start = System.currentTimeMillis();
            }
            baseChanges = TeamUtils.getAllNestedChangesArr(baseChanges);
            // must have current folder statuses before firing sync deltas
            processResourceStateChanges(Arrays.asList(baseChanges));
            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, baseChanges));
            if (updateFromReqSubscriber != null) {
                updateFromReqSubscriber.fireTeamResourceChange(
                        SubscriberChangeEvent.asSyncChangedDeltas(updateFromReqSubscriber, baseChanges));
            }
        }
        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- Handling base tree changes done, took " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    void refreshRemoteTree(IResource[] resources, int depth, IProgressMonitor monitor) throws CoreException {
        refreshRemoteTree(resources, depth, true, monitor);
    }

    IResource[] refreshRemoteTree(IResource[] resources, int depth, boolean sendStateChanges, IProgressMonitor monitor)
            throws CoreException {
        monitor = Utils.monitorFor(monitor);
        long start = 0l;
        if (debug) {
            System.out.println("+ Refreshing remote tree for " + resources.length + " resources"); //$NON-NLS-1$ //$NON-NLS-2$
            start = System.currentTimeMillis();
        }
        IResource[] remoteChanges = remoteTree.refresh(resources, depth, monitor);
        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- Refreshing remote tree done, took " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if (sendStateChanges && remoteChanges.length > 0) {
            if (debug) {
                System.out.println("+ Firing changes"); //$NON-NLS-1$
                start = System.currentTimeMillis();
            }
            remoteChanges = TeamUtils.getAllNestedChangesArr(remoteChanges);
            processResourceStateChanges(Arrays.asList(remoteChanges));
            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, remoteChanges));
            if (debug) {
                long stop = System.currentTimeMillis();
                System.out.println("- Firing changes done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
            }
        }
        return remoteChanges;
    }

    @Override
    protected IResourceVariantTree getBaseTree() {
        return baseTree;
    }

    @Override
    protected IResourceVariantTree getRemoteTree() {
        return remoteTree;
    }

    @Override
    public IResource[] roots() {
        IProject[] allProjects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
        List<IContainer> result = new ArrayList<IContainer>();
        for (int i = 0; i < allProjects.length; i++) {
            DMRepositoryProvider dmProvider = (DMRepositoryProvider) RepositoryProvider.getProvider(allProjects[i],
                    DMRepositoryProvider.ID);
            if (dmProvider != null) {
                try {
                    result.add(dmProvider.getIdmProject().getRoot());
                } catch (CoreException e) {
                    DMTeamPlugin.getDefault().getLog().log(e.getStatus());
                }
            }
        }
        return result.toArray(new IContainer[result.size()]);
    }

    @Override
    public void resourceChanged(IResourceChangeEvent event) {
        // be ready for this method to be called concurrently - changes
        // are collected per thread using ThreadLocal variables
        Collection<IResource> modifiedResources = LOCAL_CHANGES.get();
        Collection<IContainer> affectedContainers = CONTAINER_CHANGES.get();
        try {
            event.getDelta().accept(this);
            if (!modifiedResources.isEmpty() || !affectedContainers.isEmpty()) {
                modifiedResources.addAll(processContainerStateChanged(affectedContainers));
                fireResourceModified(modifiedResources.toArray(new IResource[modifiedResources.size()]));
            }
        } catch (CoreException e) {
            DMTeamPlugin.getDefault().getLog().log(e.getStatus());
        } finally {
            modifiedResources.clear();
            affectedContainers.clear();
            if (METADATA_PROVIDER.get() != null) {
                METADATA_PROVIDER.get().close();
            }
        }
    }

    @Override
    public boolean visit(IResourceDelta delta) throws CoreException {
        IResource resource = delta.getResource();
        switch (resource.getType()) {
        case IResource.PROJECT:
            return visitProject(delta, (IProject) resource);
        case IResource.FOLDER:
            return visitFolder(delta, (IFolder) resource);
        case IResource.FILE:
            return visitFile(delta, (IFile) resource);
        default:
            return true;
        }
    }

    private boolean visitProject(IResourceDelta delta, IProject project) {
        if (!project.isAccessible()) {
            try {
                switch (delta.getKind()) {
                case IResourceDelta.ADDED:
                    if ((delta.getFlags() & IResourceDelta.MOVED_FROM) != 0) {
                        delta.getMovedFromPath();
                    }
                    break;
                case IResourceDelta.REMOVED:
                    if ((delta.getFlags() & IResourceDelta.MOVED_FROM) == 0) {
                        boolean moved = (delta.getFlags() & IResourceDelta.MOVED_TO) == IResourceDelta.MOVED_TO;
                        // flush all caches if indeed removed
                        flushBaseTree(project);
                        flushFolderStatus(project);
                        try {
                            if (!moved) {
                                flushMoveState(project);
                            }
                        } catch (CoreException e) {
                            DMTeamPlugin.log(e.getStatus());
                        }
                    }
                    break;
                }
            } catch (CoreException e) {
                DMTeamPlugin.log(e.getStatus());
            }
            return false;
        }
        if ((delta.getFlags() & IResourceDelta.OPEN) != 0) {
            return false;
        }
        if (DMRepositoryProvider.getDMProvider(project) == null) {
            return false;
        }
        METADATA_PROVIDER.set(MetadataProviderFactory.providerFor(project));
        return true;
    }

    private boolean visitFolder(IResourceDelta delta, IFolder folder) {
        MetadataProvider mdProvider = METADATA_PROVIDER.get();
        if (mdProvider.metadataDirname().equals(folder.getName())) {
            return false; // metadata changes are handled in the appropriate listener
        }
        switch (delta.getKind()) {
        case IResourceDelta.ADDED:
        case IResourceDelta.REMOVED:
            collectAffectedAncestry(folder);
            CONTAINER_CHANGES.get().add(folder); // add folder itself so its status is calculated
        }
        return true;
    }

    private boolean visitFile(IResourceDelta delta, IFile file) {
        switch (delta.getKind()) {
        case IResourceDelta.ADDED:
            processFileChange(file, true);
            break;
        case IResourceDelta.CHANGED:
            if (((delta.getFlags() & INTERESTING_CHANGES) != 0) && file.exists()) {
                processFileChange(file, true);
            }
            break;
        case IResourceDelta.REMOVED:
            processFileChange(file, false);
            break;
        }
        return true;
    }

    private void processFileChange(IFile file, boolean includeFile) /* throws CoreException */ {
        collectAffectedAncestry(file);
        if (includeFile) {
            Collection<IResource> modifiedResources = LOCAL_CHANGES.get();
            modifiedResources.add(file);
        }
    }

    private void registerSaveParticipant() throws CoreException {
        // run in iworkspace runnable as per
        // add save participant and process delta atomically
        // see https://bugs.eclipse.org/bugs/show_bug.cgi?id=59937
        // also run in separate job
        // see http://www-1.ibm.com/support/docview.wss?uid=swg24027897
        final IWorkspace workspace = ResourcesPlugin.getWorkspace();
        final ISaveParticipant saveParticipant = this;
        final IResourceChangeListener listener = this;
        final IWorkspaceRunnable theRunnable = new IWorkspaceRunnable() {
            @Override
            public void run(IProgressMonitor progress) throws CoreException {
                ISavedState ss = workspace.addSaveParticipant(DMTeamPlugin.ID, saveParticipant);
                if (ss != null) {
                    ss.processResourceChangeEvents(listener);
                    // TODO VG on Mar 13, 2006: to be 100% correct build and metadata
                    // listeners should also process missed changes, may call processResourceChangeEvents
                    // only once - consider caching all deltas and firing them to
                    // the listeners
                }
            }
        };
        Job processSavedState = new Job(Messages.processSavedState) {

            @Override
            protected IStatus run(IProgressMonitor monitor) {
                try {
                    workspace.run(theRunnable, Utils.monitorFor(null));

                } catch (CoreException e) {
                    DMTeamPlugin.log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN,
                            "error in regisrering save participant", e)); //$NON-NLS-1$
                }
                return Status.OK_STATUS;
            }
        };
        processSavedState.setSystem(true);
        processSavedState.setPriority(Job.SHORT);
        processSavedState.schedule();
    }

    @Override
    public void doneSaving(ISaveContext context) {
    }

    @Override
    public void prepareToSave(ISaveContext context) throws CoreException {
    }

    @Override
    public void rollback(ISaveContext context) {
    }

    @Override
    public void saving(ISaveContext context) throws CoreException {
        if (context.getKind() == ISaveContext.FULL_SAVE) {
            context.needDelta();
            // TODO VG on Nov 28, 2005: support rollback?
            writeFolderStatusCache();
            writeMoveState();
            ((PersistentByteStore) baseTree.getByteStore()).save();
        }
    }

    private void recomputeFolderStatus() {
        final TreeSet<IContainer> sortedContainers = new TreeSet<IContainer>(new ContainmentComparator(true));
        final MetadataProvider mdProvider[] = new MetadataProvider[1];
        IProject[] allProjects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
        IResourceVisitor containerCollector = new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                if (resource.getType() != IResource.FILE) {
                    MetadataProvider mdProv = mdProvider[0];
                    if (mdProv.metadataDirname().equals(resource.getName())) {
                        return false;
                    }
                    sortedContainers.add((IContainer) resource);
                }
                return true;
            }
        };
        try {
            for (int i = 0; i < allProjects.length; i++) {
                if (!allProjects[i].isAccessible() || DMRepositoryProvider.getDMProvider(allProjects[i]) == null) {
                    continue;
                }
                mdProvider[0] = MetadataProviderFactory.providerFor(allProjects[i]);
                try {
                    allProjects[i].accept(containerCollector, IResource.DEPTH_INFINITE, true);
                } finally {
                    if (mdProvider[0] != null) {
                        mdProvider[0].close();
                    }
                }
            }
            Collection<IContainer> changedContainers = processContainerStateChanged(sortedContainers);
            // notify listeners so that they can update their state
            if (!changedContainers.isEmpty()) {
                fireResourceStateChanged(changedContainers.toArray(new IResource[changedContainers.size()]));
            }
        } catch (CoreException e1) {
            DMTeamPlugin.getDefault().getLog().log(e1.getStatus());
        }
    }

    private File getStateFile(String filename) {
        return DMTeamPlugin.getDefault().getStateLocation().append(filename).toFile();
    }

    // must be called from synchronized on cache
    private void readFolderStatusCache() {
        boolean success = false;
        File stateFile = getStateFile(FOLDER_STATUS_STATE);
        if (stateFile.exists()) {
            DataInputStream dataIn = null;
            try {
                dataIn = new DataInputStream(new BufferedInputStream(new FileInputStream(stateFile),
                        TeamUtils.getReadBufferSize(stateFile.length())));
                dataIn.readInt();
                int entriesStored = dataIn.readInt();
                int entriesRead = 0;
                while (entriesRead < entriesStored) {
                    String path = dataIn.readUTF();
                    WorkspaceFolderStatus status = new WorkspaceFolderStatus();
                    status.read(dataIn);
                    folderStatusCache.put(new Path(path), status);
                    entriesRead++;
                }
                success = true;
            } catch (IOException e) {
                DMTeamPlugin.log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMWorkspace_27, e));
            } finally {
                if (dataIn != null) {
                    try {
                        dataIn.close();
                    } catch (IOException ignore) {
                    }
                }
                stateFile.delete();
            }
        }

        if (!success) {
            DMTeamPlugin.log(new DMTeamStatus(IStatus.INFO, DMTeamStatus.UNKNOWN, "Recomputing folder status", null)); //$NON-NLS-1$
            folderStatusCache.clear();
            recomputeFolderStatus();
        }
    }

    private void writeFolderStatusCache() {
        if (folderCacheStatus == UNINITIALIZED) {
            return;
        }
        File tmpFile = getStateFile(FOLDER_STATUS_STATE + ".tmp"); //$NON-NLS-1$
        boolean tempFileWritten = false;
        DataOutputStream dataOut = null;
        try {
            dataOut = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmpFile), 8192));
            dataOut.writeInt(FOLDER_STATE_VERSION);
            synchronized (folderStatusCache) {
                dataOut.writeInt(folderStatusCache.size());
                for (Iterator<Map.Entry<IPath, WorkspaceFolderStatus>> cacheIterator = folderStatusCache.entrySet()
                        .iterator(); cacheIterator.hasNext();) {
                    Map.Entry<IPath, WorkspaceFolderStatus> cacheEntry = cacheIterator.next();
                    String path = cacheEntry.getKey().toString();
                    dataOut.writeUTF(path);
                    WorkspaceFolderStatus status = cacheEntry.getValue();
                    status.write(dataOut);
                }
            }
            tempFileWritten = true;
        } catch (IOException e) {
            DMTeamPlugin.getDefault()
                    .getLog()
                    .log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMWorkspace_0));
        } finally {
            if (dataOut != null) {
                try {
                    dataOut.flush();
                    dataOut.close();
                } catch (IOException ignore) {
                }
            }
        }

        if (tempFileWritten) {
            File stateFile = getStateFile(FOLDER_STATUS_STATE);
            stateFile.delete();
            if (!stateFile.exists()) {
                if (!tmpFile.renameTo(stateFile)) {
                    DMTeamPlugin.getDefault()
                            .getLog()
                            .log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMWorkspace_30));
                }
            } else {
                DMTeamPlugin.getDefault()
                        .getLog()
                        .log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMWorkspace_31));
            }
        }
        tmpFile.delete();
    }

    private void prepareDataForQueryContentStatus(IResource resource, int depth, SyncInfoSet set,
            Map<DMProject, List<?>[]> resourcesByProject, IProgressMonitor monitor) {

        Utils.checkCanceled(monitor);

        if (resource.getType() != IResource.FILE && depth != IResource.DEPTH_ZERO) {
            try {
                IResource[] members = members(resource);
                for (int i = 0; i < members.length; i++) {
                    prepareDataForQueryContentStatus(members[i],
                            depth == IResource.DEPTH_INFINITE ? IResource.DEPTH_INFINITE : IResource.DEPTH_ZERO, set,
                            resourcesByProject, Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
                }
            } catch (TeamException e) {
                String msg = NLS.bind(Messages.DMWorkspace_32, resource.getFullPath().toString(), e.getMessage());
                if (set != null) {
                    set.addError(new TeamStatus(IStatus.ERROR, DMTeamPlugin.ID, ITeamStatus.SYNC_INFO_SET_ERROR, msg, e,
                            resource));
                } else {
                    DMPlugin.log(e.getStatus());
                }
            }
        }

        monitor.subTask(NLS.bind(Messages.DMWorkspace_35, resource.getFullPath().toString()));
        try {
            if (resource.getType() == IResource.FILE) {
                addResourceForQueryContentStatus(resourcesByProject, (IFile) resource);
            }
        } catch (CoreException e) {
            String msg = NLS.bind(Messages.DMWorkspace_34, resource.getFullPath().toString(), e.getMessage());
            if (set != null) {
                set.addError(
                        new TeamStatus(IStatus.ERROR, DMTeamPlugin.ID, ITeamStatus.SYNC_INFO_SET_ERROR, msg, e, resource));
            } else {
                DMPlugin.log(e.getStatus());
            }
        }
        // Tick the monitor to give the owner a chance to do something
        monitor.worked(1);
    }

    @SuppressWarnings("unchecked")
    private void addResourceForQueryContentStatus(Map<DMProject, List<?>[]> resourcesByProject, IFile resource)
            throws CoreException {
        if (resourcesByProject == null || resource == null) {
            return;
        }

        DMProject dmProject = TeamUtils.getDmProject(resource);

        String projectIdMd = null;
        BaseMetadata localMd = WorkspaceMetadataManager.getInstance().getMetadata(resource);
        if (localMd instanceof ItemMetadata) {
            projectIdMd = ((ItemMetadata) localMd).getProject();
            if (projectIdMd == null) {
                projectIdMd = ((ItemMetadata) localMd).getBaseline();
            }

            if (dmProject != null && projectIdMd != null) {
                String projectId = dmProject.getId();
                if (projectId != null && !projectId.equals(projectIdMd)) { // for foreign content only
                    IDMWorkspaceFile localFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace()
                            .getWorkspaceResource(resource);
                    if (localFile != null) {
                        DMRemoteFile remoteFile = (DMRemoteFile) localFile.getRemoteFile();
                        ItemMetadata remoteMd = null;
                        if (remoteFile != null) {
                            remoteMd = remoteFile.getMetadata();
                        } else {
                            remoteMd = new ItemMetadata();
                            remoteMd.setItemUid(-1);
                        }
                        List<IResource> foundResources = null;
                        List<ItemMetadata> localMetadatas = null;
                        List<ItemMetadata> remoteMetadatas = null;
                        Object obj = resourcesByProject.get(dmProject);
                        if (obj instanceof List[] && ((List[]) obj).length == 3) {
                            foundResources = ((List<IResource>[]) obj)[0];
                            localMetadatas = ((List<ItemMetadata>[]) obj)[1];
                            remoteMetadatas = ((List<ItemMetadata>[]) obj)[2];
                        } else {
                            foundResources = new ArrayList<IResource>();
                            localMetadatas = new ArrayList<ItemMetadata>();
                            remoteMetadatas = new ArrayList<ItemMetadata>();
                            resourcesByProject.put(dmProject,
                                    new List<?>[] { foundResources, localMetadatas, remoteMetadatas });
                        }
                        foundResources.add(resource);
                        localMetadatas.add((ItemMetadata) localMd);
                        remoteMetadatas.add(remoteMd);
                    }
                }
            }
        }

    }

    @SuppressWarnings("unchecked")
    private void queryContentStatusByProjects(SyncInfoSet set, Map<DMProject, List<?>[]> resourcesByProject,
            IProgressMonitor pMonitor) {
        if (resourcesByProject.size() > 0) {
            for (Iterator<Map.Entry<DMProject, List<?>[]>> iter = resourcesByProject.entrySet().iterator(); iter
                    .hasNext();) {
                Map.Entry<DMProject, List<?>[]> entry = iter.next();
                if (entry.getKey() instanceof DMProject && entry.getValue() instanceof List[]
                        && ((List[]) entry.getValue()).length == 3) {
                    DMProject dmProject = entry.getKey();
                    List<IResource> resourcesWithForeignContent = ((List<IResource>[]) entry.getValue())[0];
                    List<ItemMetadata> localMetadatas = ((List<ItemMetadata>[]) entry.getValue())[1];
                    List<ItemMetadata> remoteMetadatas = ((List<ItemMetadata>[]) entry.getValue())[2];
                    try {
                        List<ItemMetadata> result = dmProject.queryForeignContentStatus(localMetadatas, remoteMetadatas,
                                pMonitor);
                        if (result != null && result.size() == resourcesWithForeignContent.size()) {
                            for (int i = 0; i < result.size(); i++) {
                                ItemMetadata md = result.get(i);
                                IResource res = resourcesWithForeignContent.get(i);
                                if (res != null && md != null && res.exists()) {
                                    res.setSessionProperty(DMWorkspaceSyncInfo.KEY_SYNC_REMOTE_METADATA, md);
                                }
                            }
                        }
                    } catch (CoreException e) {
                        String msg = NLS.bind(Messages.DMWorkspace_41, dmProject.getId(), e.getMessage());
                        if (set != null) {
                            set.addError(new TeamStatus(IStatus.ERROR, DMTeamPlugin.ID, ITeamStatus.SYNC_INFO_SET_ERROR, msg,
                                    e, dmProject.getProject()));
                        } else {
                            DMTeamPlugin.log(e.getStatus());
                        }
                    }

                }
            }
        }
    }

    public void queryContentStatus(IResource[] resources, int depth, SyncInfoSet set, IProgressMonitor monitor) {
        long start = 01;
        if (debug) {
            System.out.println("+ queryContentStatus"); //$NON-NLS-1$
            start = System.currentTimeMillis();
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 200);
        try {
            // request sync data for foreign contents
            IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 150);
            subMonitor.beginTask(null, resources.length);
            Map<DMProject, List<?>[]> resourcesByProject = new HashMap<DMProject, List<?>[]>();
            try {
                for (int i = 0; i < resources.length; i++) {
                    IResource resource = resources[i];
                    prepareDataForQueryContentStatus(resource, depth, set, resourcesByProject, subMonitor);
                }
            } finally {
                subMonitor.done();
            }

            queryContentStatusByProjects(set, resourcesByProject, Utils.subMonitorFor(monitor, 50));
        } finally {
            monitor.done();
            if (debug) {
                long stop = System.currentTimeMillis();
                System.out.println("- queryContentStatus done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
            }
        }
    }

    @Override
    public void collectOutOfSync(IResource[] resources, int depth, SyncInfoSet set, IProgressMonitor monitor) {
        // TODO VG on Feb 14, 2006: optimize?
        try {
            monitor.beginTask(null, 100 * resources.length);
            for (int i = 0; i < resources.length; i++) {
                IResource resource = resources[i];
                resource = TeamUtils.getResource(resource);
                IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 100);
                subMonitor.beginTask(null, IProgressMonitor.UNKNOWN);
                flushForeignUpdateSyncKind();
                // force a login here
                // avoids multiple cancels if we are mapped to foreign and there
                // are differences and sync on startup

                boolean inForeign = TeamUtils.isLocalWorksetPointingToForeignStream(resource)
                        || TeamUtils.isLocalWorksetPointingToForeignProject(resource);

                if (inForeign) {
                    IDMProject dmproj = getProject(resource);
                    DimensionsConnectionDetailsEx con = dmproj.getConnection();
                    con.openSession(null);
                }

                collect(resource, depth, set, subMonitor);
                IDMProject project = getProject(resource);
                if (inForeign) {
                    try {
                        if (debugResources) {
                            System.out.println(TeamUtils.myThread() + " dmws cOOS btl acquire"); //$NON-NLS-1$
                        }
                        baseTreeLock.acquire(); // lock concurrent access to MovedInRepostoryResources cache
                        searchForMovedInRepostoryResources(new IResource[] { resource }, depth, subMonitor);
                        if (!(project instanceof BaselineProject)) {
                            verifyForeignUpdates(resource, set);
                        } else {
                            SyncInfo[] syncInfo = set.getSyncInfos();
                            for (int j = 0; j < syncInfo.length; j++) {
                                DMWorkspaceSyncInfo info = (DMWorkspaceSyncInfo) syncInfo[j];
                                int syncKind = info.getKind();
                                if ((syncKind & SyncInfo.DIRECTION_MASK) == SyncInfo.OUTGOING) {
                                    registerForeignUpdateSyncKind(info.getLocal(), NO_CHANGES);
                                    info.init();
                                    set.add(info);
                                }
                            }
                        }
                    } finally {
                        if (debugResources) {
                            System.out.println(TeamUtils.myThread() + "dmws cOOS btl release"); //$NON-NLS-1$
                        }
                        baseTreeLock.release();
                    }
                }
                subMonitor.done();
            }
        } catch (Exception e) {
            DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, 0, Messages.DMWorkspace_43 + e.getMessage(), e));
        } finally {
            monitor.done();
        }
    }

    /*
     * Collect the calculated synchronization information for the given resource at the given depth. The
     * results are added to the provided list.
     */
    private void collect(IResource resource, int depth, SyncInfoSet set, IProgressMonitor monitor) throws CoreException {
        resource = TeamUtils.getResource(resource);
        Utils.checkCanceled(monitor);

        if (resource.getType() != IResource.FILE && depth != IResource.DEPTH_ZERO) {
            try {
                IResource[] members = members(resource);
                for (int i = 0; i < members.length; i++) {
                    collect(members[i], depth == IResource.DEPTH_INFINITE ? IResource.DEPTH_INFINITE : IResource.DEPTH_ZERO,
                            set, monitor);
                }
            } catch (Exception e) {
                String msg = NLS.bind(Messages.DMWorkspace_32, resource.getFullPath().toString(), e.getMessage());
                set.addError(
                        new TeamStatus(IStatus.ERROR, DMTeamPlugin.ID, ITeamStatus.SYNC_INFO_SET_ERROR, msg, e, resource));
            }
        }

        monitor.subTask(NLS.bind(Messages.DMWorkspace_35, resource.getFullPath().toString()));
        try {
            SyncInfo info = getSyncInfo(resource);
            if (info == null /* || info.getKind() == SyncInfo.IN_SYNC */) {
                // Resource is no longer under the subscriber control.
                // This can occur for the resources past as arguments to collectOutOfSync
                set.remove(resource);
            } else {
                set.add(info);
            }
        } catch (Exception e) {
            String msg = NLS.bind(Messages.DMWorkspace_34, resource.getFullPath().toString(), e.getMessage());
            set.addError(
                    new TeamStatus(IStatus.ERROR, DMTeamPlugin.ID, ITeamStatus.RESOURCE_SYNC_INFO_ERROR, msg, e, resource));
        }
        // Tick the monitor to give the owner a chance to do something
        monitor.worked(1);
    }

    /*
     * The method checks synchronization statuses for cross-stream merge operation
     */
    private SyncInfoSet verifyForeignUpdates(IResource resource, SyncInfoSet set) throws Exception {
        // executes only after switching to foreign stream
        if (TeamUtils.isLocalWorksetPointingToForeignStream(resource) && set.getSyncInfos().length > 0) {
            if (debugResources) {
                System.out.println("DWS vfu " + resource.toString()); //$NON-NLS-1$
            }
            IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
            IDMProject project = workspace.getRemoteResource(resource.getProject()).getProject();
            String foreighStreamSpec = project.getId();
            String homeStreamSpec = TeamUtils.isLocalWorksetAStream(resource);
            // general input
            long foreignStreamUid = ((WorksetProject) workspace.getProject(resource)).getProjectUid(foreighStreamSpec);
            long homeStreamUid = ((WorksetProject) workspace.getProject(resource)).getProjectUid(homeStreamSpec);
            // item input
            List<Integer> localItemUids = new ArrayList<Integer>();
            List<String> localItemPaths = new ArrayList<String>();
            List<Integer> foreignItemUids = new ArrayList<Integer>();
            List<String> foreignItemPaths = new ArrayList<String>();
            List<Integer> foreignItemChanges = new ArrayList<Integer>();
            // directory input
            List<String> localDirPaths = new ArrayList<String>();
            List<String> foreignDirPaths = new ArrayList<String>();
            List<Integer> foreignDirChanges = new ArrayList<Integer>();

            List<SyncInfo[]> itemSyncInfos = new ArrayList<SyncInfo[]>();
            List<DMWorkspaceSyncInfo> folderSyncInfos = new ArrayList<DMWorkspaceSyncInfo>();

            Set<IResource> movedRenamed = new HashSet<IResource>(); // home-stream names of renamed/moved resources

            SyncInfo[] syncInfo = set.getSyncInfos();
            for (int i = 0; i < syncInfo.length; i++) {
                DMWorkspaceSyncInfo info = (DMWorkspaceSyncInfo) syncInfo[i];
                int syncKind = info.getKind();
                // only these types of sync kind are involved in the verify foreign update operation
                // this could be incoming deletion actually, verify this to be sure
                if (syncKind == (SyncInfo.OUTGOING | SyncInfo.ADDITION)
                        || syncKind == (SyncInfo.INCOMING | SyncInfo.ADDITION)
                        || syncKind == (SyncInfo.INCOMING | SyncInfo.DELETION)) {

                    if (info.getLocal().getType() == IResource.FILE) {
                        // 1. check for renames
                        IResource homeNameRes = getMovedInRepositoryFrom(info.getLocal());
                        IResource foreignNameRes = null;
                        if (homeNameRes == null && (foreignNameRes = getMovedInRepositoryTo(info.getLocal())) != null) {
                            homeNameRes = getMovedInRepositoryFrom(foreignNameRes);
                        } else {
                            foreignNameRes = getMovedInRepositoryTo(homeNameRes);
                        }

                        if (homeNameRes != null && foreignNameRes != null) {
                            if (!movedRenamed.contains(homeNameRes)) {
                                movedRenamed.add(homeNameRes); // add visited parts of rename/move

                                itemSyncInfos.add(
                                        new SyncInfo[] { set.getSyncInfo(homeNameRes), set.getSyncInfo(foreignNameRes) });
                                localItemPaths.add(
                                        project.getRemotePathForLocalPath(homeNameRes.getProjectRelativePath()).toString());
                                DMRemoteFile baseFile = (DMRemoteFile) workspace.getBaseResource(homeNameRes);
                                if (baseFile == null) {
                                    localItemUids.add(new Integer(0));
                                } else {
                                    localItemUids.add(new Integer((int) baseFile.getUid()));
                                }
                                DMRemoteFile remoteFile = (DMRemoteFile) workspace.getRemoteResource(foreignNameRes);
                                if (remoteFile == null) {
                                    foreignItemUids.add(new Integer(0));
                                    foreignItemPaths.add(""); //$NON-NLS-1$
                                } else {
                                    foreignItemUids.add(new Integer((int) remoteFile.getUid()));
                                    foreignItemPaths.add(remoteFile.getPath().toString());
                                }
                                foreignItemChanges.add(new Integer(RENAME_MOVE));
                            }
                            continue;
                        }
                        // 2. if the file was not renamed/moved
                        itemSyncInfos.add(new SyncInfo[] { info });
                        localItemPaths.add(project.getRemotePathForLocalResource(info.getLocal()).toString());
                        DMRemoteFile baseFile = (DMRemoteFile) workspace.getBaseResource(info.getLocal());
                        if (baseFile == null) {
                            localItemUids.add(new Integer(0));
                        } else {
                            localItemUids.add(new Integer((int) baseFile.getUid()));
                        }
                        DMRemoteFile remoteFile = (DMRemoteFile) workspace.getRemoteResource(info.getLocal());
                        if (remoteFile == null) {
                            foreignItemUids.add(new Integer(0));
                            foreignItemPaths.add(""); //$NON-NLS-1$
                        } else {
                            foreignItemUids.add(new Integer((int) remoteFile.getUid()));
                            foreignItemPaths.add(remoteFile.getPath().toString());
                        }
                        foreignItemChanges.add(new Integer(translateSyncKind(info))); // get "plain" sync kind RPC understands

                    } else if (info.getLocal().getType() == IResource.FOLDER) {
                        folderSyncInfos.add(info);
                        localDirPaths.add(project.getRemotePathForLocalResource(info.getLocal()).toString());
                        DMRemoteFolder remoteDir = (DMRemoteFolder) workspace.getRemoteResource(info.getLocal());
                        if (remoteDir == null) {
                            foreignDirPaths.add(""); //$NON-NLS-1$
                        } else {
                            foreignDirPaths.add(remoteDir.getPath().toString());
                        }
                        foreignDirChanges.add(new Integer(translateSyncKind(info)));
                        // TODO do we really can determine renames/moves of folders?
                    }
                } else if ((syncKind & SyncInfo.DIRECTION_MASK) == SyncInfo.OUTGOING) { // ignore outgoing changes
                    registerForeignUpdateSyncKind(info.getLocal(), NO_CHANGES);
                    info.init();
                    set.add(info); // ensure events fired when modify in place
                }

            }
            // 3. fill in input parameters and invoke
            if (!(itemSyncInfos.isEmpty() && folderSyncInfos.isEmpty())) {
                int[] localItemUidsArray = new int[localItemUids.size()];
                for (int i = 0; i < localItemUids.size(); i++) {
                    localItemUidsArray[i] = localItemUids.get(i).intValue();
                }
                int[] foreignItemUidsArray = new int[foreignItemUids.size()];
                for (int i = 0; i < foreignItemUids.size(); i++) {
                    foreignItemUidsArray[i] = foreignItemUids.get(i).intValue();
                }
                int[] foreignItemChangesArray = new int[foreignItemChanges.size()];
                for (int i = 0; i < foreignItemChanges.size(); i++) {
                    foreignItemChangesArray[i] = foreignItemChanges.get(i).intValue();
                }
                int[] foreignDirChangesArray = new int[foreignDirChanges.size()];
                for (int i = 0; i < foreignDirChanges.size(); i++) {
                    foreignDirChangesArray[i] = foreignDirChanges.get(i).intValue();
                }

                Project proj = (Project) workspace.getProject(resource).getDimensionsObject();
                Object[] verifiedChangesInfo = VerifyForeignUpdate.getVerifiedForeignUpdate(proj, homeStreamUid,
                        foreignStreamUid, localItemUidsArray, localItemPaths.toArray(new String[localItemPaths.size()]),
                        foreignItemUidsArray, foreignItemPaths.toArray(new String[foreignItemPaths.size()]),
                        foreignItemChangesArray, localDirPaths.toArray(new String[localDirPaths.size()]),
                        foreignDirPaths.toArray(new String[localDirPaths.size()]), foreignDirChangesArray);
                // 4. interpret output and update sync kinds of resources
                if (verifiedChangesInfo != null) {
                    int[] verifiedItemChanges = (int[]) verifiedChangesInfo[0];
                    int[] verifiedDirChanges = (int[]) verifiedChangesInfo[2];
                    // items
                    for (int i = 0; i < verifiedItemChanges.length; i++) {
                        SyncInfo[] syncArray = itemSyncInfos.get(i);
                        if (syncArray.length > 1) { // (syncArray.length > 1) contains rename/move pairs
                            DMWorkspaceSyncInfo dsiLocal = (DMWorkspaceSyncInfo) syncArray[0];
                            DMWorkspaceSyncInfo dsiRemote = (DMWorkspaceSyncInfo) syncArray[1];
                            if (verifiedItemChanges[i] == NO_CHANGES) { // ren/mov was at home stream not foreign
                                // if we have conflict - maintain existing behavior for rename/move pair elsewise hide changes
                                // recalculate kind - need to have up-to-date after searchForMovedInRepostoryResources refresh
                                dsiLocal.init();
                                if ((dsiLocal.getKind() & SyncInfo.DIRECTION_MASK) != SyncInfo.CONFLICTING) {
                                    registerForeignUpdateSyncKind(dsiLocal.getLocal(), NO_CHANGES);
                                    registerForeignUpdateSyncKind(dsiRemote.getLocal(), NO_CHANGES);
                                } else {
                                    // show conflicting rename/move pair as before, dsiLocal's been recalculated already
                                    dsiRemote.init();
                                    set.add(dsiRemote);
                                    continue;
                                }
                            } else if ((verifiedItemChanges[i] & CONFLICT) == CONFLICT) {
                                // conflict on which of 2 changes?
                                registerForeignUpdateSyncKind(dsiLocal.getLocal(), CONFLICT | DELETION);
                                registerForeignUpdateSyncKind(dsiRemote.getLocal(), ADDITION);
                            }
                            dsiLocal.init();
                            dsiRemote.init();
                            set.add(dsiLocal);
                            set.add(dsiRemote);
                        } else { // no rename/move
                            DMWorkspaceSyncInfo dsi = (DMWorkspaceSyncInfo) syncArray[0];
                            registerForeignUpdateSyncKind(dsi.getLocal(), verifiedItemChanges[i]);
                            dsi.init();
                            set.add(dsi);
                        }
                    }
                    // dirs
                    for (int i = 0; i < verifiedDirChanges.length; i++) {
                        DMWorkspaceSyncInfo dsi = folderSyncInfos.get(i);
                        registerForeignUpdateSyncKind(dsi.getLocal(), verifiedDirChanges[i]);
                        dsi.init();
                        set.add(dsi);
                    }
                }
            }
        }
        return set;
    }

    /*
     * Translates sync kind into GetForeignChangetypeInfo func RPC format
     */
    private int translateSyncKind(DMWorkspaceSyncInfo info) {
        // don't check some kinds of conflicts(PSEUDO_CONFLICT, AUTOMERGE_CONFLICT, MANUAL_CONFLICT)
        // because there is a requirement workarea should be in-sync with home stream
        int resultKind = NO_CHANGES;
        int kind = info.getKind();
        switch (kind & SyncInfo.DIRECTION_MASK) {
        case SyncInfo.INCOMING:
            switch (kind & SyncInfo.CHANGE_MASK) {
            case SyncInfo.ADDITION:
                resultKind = ADDITION;
                break;
            case SyncInfo.DELETION:
                resultKind = DELETION;
                break;
            case SyncInfo.CHANGE:
                resultKind = CHANGE;
                break;
            }
            break;
        case SyncInfo.CONFLICTING:
            switch (kind & SyncInfo.CHANGE_MASK) {
            case SyncInfo.ADDITION:
                resultKind = CONFLICT | ADDITION;
                break;
            case SyncInfo.DELETION:
                resultKind = CONFLICT | DELETION;
                break;
            case SyncInfo.CHANGE:
                resultKind = CONFLICT | CHANGE;
                break;
            }
            break;
        // We shouldn't pass outgoing changes to RPC. But in fact, we could have sync kind OUTGOING ADDITION for actual INCOMING
        // DELETION We reckon OUTGOING ADDITION case as INCOMING DELETION to validate it.
        case SyncInfo.OUTGOING:
            switch (kind & SyncInfo.CHANGE_MASK) {
            case SyncInfo.ADDITION:
                resultKind = DELETION;
                break;
            }
            break;
        }
        return resultKind;
    }

    /*
     * Updates foreignUpdateSyncKindCache with SyncInfo-type sync kinds
     * Translates GetForeignChangetypeInfo func RPC-format sync kinds into SyncInfo-type sync kinds
     */
    private int registerForeignUpdateSyncKind(IResource resource, int updatedSyncKind) throws CoreException {
        Assert.isNotNull(resource);
        resource = TeamUtils.getResource(resource);
        Integer kind = null;
        if (updatedSyncKind == NO_CHANGES) {
            kind = SyncInfo.IN_SYNC;
        } else if ((updatedSyncKind & CONFLICT) == CONFLICT) {
            if ((updatedSyncKind & ADDITION) == ADDITION) {
                kind = SyncInfo.CONFLICTING | SyncInfo.ADDITION;
            } else if ((updatedSyncKind & DELETION) == DELETION) {
                kind = SyncInfo.CONFLICTING | SyncInfo.DELETION;
            } else {
                kind = SyncInfo.CONFLICTING | SyncInfo.CHANGE;
            }
        } else if (updatedSyncKind == ADDITION) {
            kind = SyncInfo.INCOMING | SyncInfo.ADDITION;
        } else if (updatedSyncKind == DELETION) {
            kind = SyncInfo.INCOMING | SyncInfo.DELETION;
        } else if (updatedSyncKind == CHANGE) {
            kind = SyncInfo.INCOMING | SyncInfo.CHANGE;
        } else {
            return DMWorkspaceSyncInfo.NOT_VALID_SYNC_KIND;
        }
        synchronized (foreignUpdateSyncKindCache) {
            if (debugResources) {
                System.out.println("DW update fuskc " + resource.toString() + " " + SyncInfo.kindToString(kind)); //$NON-NLS-1$ //$NON-NLS-2$
            }
            foreignUpdateSyncKindCache.put(resource, kind);
            return kind.intValue();
        }
    }

    private void flushForeignUpdateSyncKind() {
        synchronized (foreignUpdateSyncKindCache) {
            if (debugResources) {
                System.out.println("DW flush fuskc"); //$NON-NLS-1$
            }
            foreignUpdateSyncKindCache.clear();
        }
    }

    public int getForeignUpdateSyncKind(IResource resource) {
        Assert.isNotNull(resource);
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
            return DMWorkspaceSyncInfo.NOT_VALID_SYNC_KIND;
        }
        synchronized (foreignUpdateSyncKindCache) {
            Integer kind = foreignUpdateSyncKindCache.get(resource);
            if (kind != null) {
                return kind.intValue();
            }
        }
        return DMWorkspaceSyncInfo.NOT_VALID_SYNC_KIND;
    }

    private void unregisterForeignUpdateSyncKind(IResource resource) throws CoreException {
        Assert.isNotNull(resource);
        resource = TeamUtils.getResource(resource);
        synchronized (foreignUpdateSyncKindCache) {
            foreignUpdateSyncKindCache.remove(resource);
        }
    }

    @Override
    protected SyncInfo getSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote) throws TeamException {
        try {
            local = TeamUtils.getResource(local);
            DMWorkspaceSyncInfo syncInfo = new DMWorkspaceSyncInfo(local, base, remote, getResourceComparator(), this,
                    getConnectionForResource(local, base, remote));
            syncInfo.init();
            return syncInfo;
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
    }

    @Override
    public IStatus merged(IResource[] locals, IDMRemoteResource[] remotes, IProgressMonitor monitor) throws CoreException {
        // TODO VG on Jan 16, 2007: handle conflicts that involve a deletion on one side and change on other side
        Assert.isLegal(locals.length == remotes.length, "lengths must match"); //$NON-NLS-1$
        if (locals.length == 0) {
            return Status.OK_STATUS;
        }

        HashMap<IDMProject, List<ResolveConflictRequest>> byProject = new HashMap<IDMProject, List<ResolveConflictRequest>>();
        for (int i = 0; i < locals.length; i++) {
            assert locals[i] != null;

            IResource local = locals[i];
            local = TeamUtils.getResource(local);

            IDMProject project = getProject(local);
            if (project == null) {
                continue;
            }
            if (!local.exists() && remotes[i] == null) { // handle conflicting deletions
                if (isManaged(local)) {
                    unmanage(local, null);
                }
                continue;
            }
            if (local.getType() == IResource.FOLDER && local.exists() && !isManaged(local) && remotes[i] != null) {
                // handle conflicting folder add
                TeamUtils.ensureReacheable((IContainer) local, true);
                continue;
            }
            if (local.getType() == IResource.FOLDER && !local.exists() && !isManaged(local) && remotes[i] != null) {
                // When you are "marking as merged" an incoming addition folder in a Stream
                TeamUtils.ensureReacheable((IContainer) local, true);
                continue;
            }

            if (local.getType() == IResource.FILE && remotes[i] != null && remotes[i].getType() == IDMRemoteResource.FILE) {
                // If the resource is involved in a repository move then do not process Mark as Merged operation
                if (DMTeamPlugin.getWorkspace().getMovedInRepositoryFrom(local) != null) {
                    continue;
                }
                List<ResolveConflictRequest> projectRequests = byProject.get(project);
                if (projectRequests == null) {
                    projectRequests = new ArrayList<ResolveConflictRequest>();
                    byProject.put(project, projectRequests);
                }
                IFile localFile = (IFile) local;
                IDMRemoteFile remoteFile = (IDMRemoteFile) remotes[i];

                if (isManaged(local) && TeamUtils.isLocalWorksetPointingToForeignStream(local)) {
                    // If merge is against a foreign stream, then we need to retain the local metadata and add revision-list to
                    // the metadata so that we can retain pedigree when this item is delivered back to the parent stream.
                    // After "Mark as Merged" the item will disappear from the sync view
                    mergeFromForeignStream(local, remotes[i]);
                    fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, new IResource[] { local }));
                } else {
                    projectRequests.add(new ResolveConflictRequest(localFile, remoteFile.getItemRevision()));
                }

            }
            // conflicting deletion (deletion in the foreign stream) on cross-stream merge
            if (TeamUtils.isLocalWorksetPointingToForeignStream(local) && local.exists() && isManaged(local)
                    && remotes[i] == null) {
                BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(local);
                String mergedFromStreamsList = metadata.get(TeamUtils.MERGED_FROM_FOREIGN_STREAM);
                String remoteStreamName = DMTeamPlugin.getWorkspace()
                        .getRemoteResource(local.getProject())
                        .getProject()
                        .getId();
                if (mergedFromStreamsList != null && mergedFromStreamsList.length() != 0) {
                    mergedFromStreamsList += "," + remoteStreamName; //$NON-NLS-1$
                } else {
                    mergedFromStreamsList = remoteStreamName;
                }
                metadata.put(TeamUtils.MERGED_FROM_FOREIGN_STREAM, mergedFromStreamsList);
                WorkspaceMetadataManager.getInstance().updateMetadata(local, metadata);
                IResource movedInRepo = getMovedInRepositoryTo(local);
                if (movedInRepo != null) {
                    registerMovedInRepoMergedCache(movedInRepo, local); // register resource for further kind calculation
                    // need to fire event to update Sync view for both parts of rename/move
                    fireTeamResourceChange(
                            SubscriberChangeEvent.asSyncChangedDeltas(this, new IResource[] { local, movedInRepo }));
                    continue;
                }
                fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, new IResource[] { local }));
                continue;
            }
            // If there is no remote then delete the metadata of the local file so that it will be shown as out going
            // addition in the sync view after the "Mark as Merged" operation.( This is needed for Streams in certain
            // cases. eg:- I have a Stream in my workspace with a file in it. Another user deleted this file from
            // repository. When I do a sync this file will be shown as incoming deletion. If I decide to use my local
            // to deliver I can't do it because there is no "Override and Deliver" option for Streams. To overcome this
            // problem we need to allow the user to do "Mark as Merged").
            if (local.getType() == IResource.FILE && remotes[i] == null) {
                // If the resource is involved in a repository move then do not process Mark as Merged operation
                if (DMTeamPlugin.getWorkspace().getMovedInRepositoryTo(local) != null) {
                    continue;
                }
                WorkspaceMetadataManager.getInstance().deleteMetadata(local, WorkspaceMetadataManager.DELETE);
            }
        }
        List<IStatus> errors = new ArrayList<IStatus>();
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, byProject.size() * 100);
        try {
            for (Iterator<Map.Entry<IDMProject, List<ResolveConflictRequest>>> iter = byProject.entrySet().iterator(); iter
                    .hasNext();) {
                Map.Entry<IDMProject, List<ResolveConflictRequest>> entry = iter.next();
                IDMProject project = entry.getKey();
                List<ResolveConflictRequest> list = entry.getValue();
                ResolveConflictRequest[] requests = list.toArray(new ResolveConflictRequest[list.size()]);
                IStatus status = project.resolveConflicts(requests, Utils.subMonitorFor(monitor, 100));
                if (!status.isOK()) {
                    if (status.isMultiStatus()) {
                        errors.addAll(Arrays.asList(status.getChildren()));
                    } else {
                        errors.add(status);
                    }
                } else {
                    // If the Project/Stream in the workspace is pointing to a foreign Stream , then those items which were
                    // unmanaged before the merge (Pseudo conflicting addition) need to be hidden in the sync view against this
                    // Stream after merge( for that we need to add "merged_from_foreign_stream" key to the metadata
                    for (int i = 0; i < list.size(); i++) {
                        IResource res = list.get(i).getResource();
                        if (TeamUtils.isLocalWorksetPointingToForeignStream(res)) {
                            // If merge is against a foreign stream, then we retain the local metadata and add revision-list to
                            // the metadata. After "Mark as Merged" the item will disappear from the sync view
                            mergeFromForeignStream(res, getRemoteResource(res));
                            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, new IResource[] { res }));
                        }
                    }
                }
            }
        } finally {
            monitor.done();
        }
        if (!errors.isEmpty()) {
            if (errors.size() == 1) {
                return errors.get(0);
            }
            return new MultiStatus(DMTeamPlugin.ID, 0, errors.toArray(new IStatus[errors.size()]), Messages.DMWorkspace_36,
                    null);
        }
        return Status.OK_STATUS;
    }

    @Override
    public IDMRemoteFile getRemoteFile(IFile local, final ItemRevision remote) throws CoreException {
        IDMProject project = getProject(local);
        if (project == null) {
            return null;
        }

        final Session session = project.getConnection().openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                int[] atts = DMRemoteFile.RESOURCE_VARIANT_ATTRS_FILE;
                ArrayList<Integer> toQuery = new ArrayList<Integer>();
                for (int i = 0; i < atts.length; i++) {
                    if (remote.getAttribute(atts[i]) == null) {
                        toQuery.add(new Integer(atts[i]));
                    }
                }
                if (!toQuery.isEmpty()) {
                    atts = new int[toQuery.size()];
                    for (int i = 0; i < toQuery.size(); i++) {
                        atts[i] = toQuery.get(i).intValue();
                    }
                    Utils.queryAttributes(Collections.singletonList(remote), atts, session.getObjectFactory(), true);
                }
            }
        }, new NullProgressMonitor());

        IPath path = project.getRemotePathForLocalResource(local);
        return new DMRemoteFile(null, path, project, project.getRemoteTree(), remote);
    }

    /*
     * Advises the workspace that it is ok to purge any cached state for this
     * resource. This method does not fire notifications to workspace listeners.
     * This method should typically be called prior to workspace refresh
     * (base tree refresh) during which base information will be purged if
     * it is also missing in the metadata.
     */
    public void releaseBase(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        releaseBase(resource, false, 0, null);
    }

    void releaseBase(IResource resource, boolean refresh, int depth, IProgressMonitor monitor) throws CoreException {
        resource = TeamUtils.getResource(resource);
        if (debugResources) {
            System.out.println("DW releaseBase " + resource.toString() + " refresh = " + refresh + " depth = " + depth); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        }
        baseTree.prepareForDeletion(resource);
        if (refresh) {
            refreshBaseTree(new IResource[] { resource }, depth, monitor);
        }
    }

    @Override
    public boolean isMoved(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        synchronized (movedSrcDst) {
            ensureMoveStateInitialized();
            return movedSrcDst.containsKey(resource) || movedDstSrc.containsKey(resource);
        }
    }

    @Override
    public IResource getMovedTo(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        synchronized (movedSrcDst) {
            ensureMoveStateInitialized();
            return movedSrcDst.get(resource);
        }
    }

    @Override
    public IResource getMovedFrom(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        synchronized (movedSrcDst) {
            ensureMoveStateInitialized();
            return movedDstSrc.get(resource);
        }
    }

    public boolean isMovedInRepository(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        synchronized (movedInRepositorySrcDst) {
            return movedInRepositorySrcDst.containsKey(resource) || movedInRepositoryDstSrc.containsKey(resource);
        }
    }

    @Override
    public IResource getMovedInRepositoryTo(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        synchronized (movedInRepositorySrcDst) {
            return movedInRepositorySrcDst.get(resource);
        }
    }

    @Override
    public IResource getMovedInRepositoryFrom(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        synchronized (movedInRepositorySrcDst) {
            return movedInRepositoryDstSrc.get(resource);
        }
    }

    @Override
    public List<IResource> cleanTimestamps(IResource[] resources, int depth, IProgressMonitor monitor) throws CoreException {
        return cleanTimestamps(resources, depth, true, true, monitor);
    }

    private List<IResource> cleanTimestamps(IResource[] resources, int depth, boolean fireModified, boolean fireTeamChange,
            IProgressMonitor monitor) throws CoreException {
        long start = 01;
        if (debug) {
            System.out.println("+ cleanTimestamps"); //$NON-NLS-1$
            start = System.currentTimeMillis();
        }

        List<IFile> files = TeamUtils.collectFiles(resources, depth); // ensures only existent files are returned
        if (files.isEmpty()) {
            return Collections.emptyList();
        }
        List<IResource> result = new ArrayList<IResource>();
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.DMWorkspace_cleanTSTask, files.size());
        try {
            for (Iterator<IFile> iter = files.iterator(); iter.hasNext();) {
                IFile file = TeamUtils.getFile(iter.next());
                IDMWorkspaceFile dmFile = (IDMWorkspaceFile) getWorkspaceResource(file);

                if (dmFile != null && dmFile.isModified()) {
                    BaseMetadata baseMetadata = WorkspaceMetadataManager.getInstance().getMetadata(file);
                    if (baseMetadata instanceof ItemMetadata) {
                        if (isClean(file, baseMetadata, monitor)) {
                            dmFile.makeUnmodified(); // takes care of read-only resources
                            Set<IResource> allNestedChanges = TeamUtils.getAllNestedChanges(new IResource[] { file });
                            result.addAll(allNestedChanges);
                        }
                    }
                }
                monitor.worked(1);
            }
        } finally {
            monitor.done();
        }

        if (!result.isEmpty()) {
            if (fireModified) {
                processResourceStateChanges(result);
            }
            if (fireTeamChange) {
                fireTeamResourceChange(
                        SubscriberChangeEvent.asSyncChangedDeltas(this, result.toArray(new IResource[result.size()])));
            }
        }

        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- cleanTimestamps done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        return result;
    }

    private static boolean isClean(IFile file, BaseMetadata baseMetadata, IProgressMonitor monitor) throws DMException {
        boolean clean = false;
        ItemMetadata itemMetadata = (ItemMetadata) baseMetadata;
        File lfsFile = file.getLocation().toFile();
        long length = lfsFile.length();
        if (itemMetadata.getFetchSize() != length) {
            return clean;
        }

        // different size always means different content
        monitor.subTask(NLS.bind(Messages.DMWorkspace_calcCS, file.getFullPath().toString()));
        FileInputStream in = null;
        try {
            in = new FileInputStream(lfsFile);
            byte[] was = itemMetadata.getChecksum();
            MetadataStrings.populateItemMetadata(itemMetadata, in, null, TeamUtils.getReadBufferSize(length));
            byte[] now = itemMetadata.getChecksum();
            clean = Arrays.equals(was, now);
        } catch (IOException ioe) {
            throw new DMException(NLS.bind(Messages.DMWorkspace_calcCSError, file.getFullPath().toString()), ioe);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignore) {
                }
            }
        }
        return clean;
    }

    /**
     * Registers a move with dimensions workspace. This method attempts
     * to reconstruct move source/destination pair based on the moved-from
     * data available from the metadata.
     * Note that Eclipse workspace may contain several local projects shared
     * with the same remote, in such case we use the first match when identifying
     * source project if movedFromProjectId is not null.
     *
     * @param destination
     *            move destination
     * @param movedFromPath
     *            project relative path the resource was moved from
     * @param movedFromProjectId
     *            DM project or baseline id, may be <code>null</code>
     * @param movedFromProjectType
     *            <code>IDMProject.WORKSET</code> or <code>IDMProject.BASELINE</code>
     * @param connection
     *            associated connection at destination
     * @return move source or <code>null</code> if unchanged
     * @throws CoreException
     */
    public IResource registerMove(IResource destination, String movedFromPath, String movedFromProjectId,
            int movedFromProjectType, DimensionsConnectionDetailsEx connection) throws CoreException {
        if (debugResources) {
            System.out.println("DW registerMove dst = " + destination.toString() + " from = " + movedFromPath); //$NON-NLS-1$ //$NON-NLS-2$
        }
        Assert.isNotNull(destination);
        Assert.isNotNull(movedFromPath);
        synchronized (movedSrcDst) {
            ensureMoveStateInitialized();
            IPath movedFromPath1 = new Path(movedFromPath);
            IDMProject dstProject = getProject(destination);
            IPath dstRmtOffset = dstProject.getRemoteOffset();

            // 1. attempt to resolve local source project
            IDMProject sourceProject = null;
            // handle cross-project moves
            if (!Utils.isNullEmpty(movedFromProjectId) || !dstRmtOffset.isPrefixOf(movedFromPath1)) {
                if (Utils.isNullEmpty(movedFromProjectId)) { // cross local but same remote
                    movedFromProjectId = dstProject.getId();
                    movedFromProjectType = dstProject.getType();
                }
                IDMProject[] dmProjects = getProjects();
                for (int i = 0; i < dmProjects.length; i++) {
                    if (movedFromProjectId.equalsIgnoreCase(dmProjects[i].getId())
                            && movedFromProjectType == dmProjects[i].getType()
                            && dmProjects[i].getRemoteOffset().isPrefixOf(movedFromPath1)
                            && connection.equals(dmProjects[i].getConnection())) {
                        sourceProject = dmProjects[i];
                        break;
                    }
                }
            } else {
                sourceProject = getProject(destination);
            }

            if (sourceProject == null) {
                return null;
            }

            // 2. check if we already have this move pair
            IPath srcPath = sourceProject.getLocalPathForRemotePath(movedFromPath1);
            IProject iproject = sourceProject.getProject();

            IResource source = null;
            if (destination.getType() == IResource.FILE) {
                source = iproject.getFile(srcPath);
            } else if (destination.getType() == IResource.FOLDER) {
                source = iproject.getFolder(srcPath);
            } else {
                // type is project
                IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
                source = root.getProject(movedFromPath1.lastSegment());
            }
            IResource storedDestination = movedSrcDst.get(source);
            if (!destination.equals(storedDestination)) { // cache if stored dest is null or different
                // moved(source, destination);
                if (debugResources) {
                    System.out.println("DW register move src = " + source.toString() + " dst = " + destination.toString()); //$NON-NLS-1$ //$NON-NLS-2$
                }

                // try to remove any invalid data from caches before adding of new pairs
                IResource storedSource = movedDstSrc.get(destination);
                if (storedSource != null && movedSrcDst.get(storedSource) != null) {
                    movedSrcDst.remove(storedSource);
                }

                movedSrcDst.put(source, destination);
                if (storedDestination != null) {
                    movedDstSrc.remove(storedDestination);
                }
                movedDstSrc.put(destination, source);

                return source;
            }
        }
        return null;
    }

    private void flushMoveInRepository() throws CoreException {
        synchronized (movedInRepositorySrcDst) {
            movedInRepositorySrcDst.clear();
            movedInRepositoryDstSrc.clear();
        }
    }

    private IResource registerMoveInRepository(IResource destination, IResource source) throws CoreException {
        Assert.isNotNull(destination);
        Assert.isNotNull(source);
        synchronized (movedInRepositorySrcDst) {
            IResource storedDestination = movedInRepositorySrcDst.get(source);
            if (!destination.equals(storedDestination)) {
                movedInRepositorySrcDst.put(source, destination);
                if (storedDestination != null) {
                    movedInRepositoryDstSrc.remove(storedDestination);
                }
                movedInRepositoryDstSrc.put(destination, source);
                return source;
            }
        }
        return null;
    }

    private void flushMovedInRepoMergedCache() throws CoreException {
        synchronized (movedInRepoDstSrcMerged) {
            movedInRepoDstSrcMerged.clear();
        }
    }

    private IResource registerMovedInRepoMergedCache(IResource destination, IResource source) throws CoreException {
        Assert.isNotNull(destination);
        Assert.isNotNull(source);
        synchronized (movedInRepoDstSrcMerged) {
            return movedInRepoDstSrcMerged.put(destination, source);
        }
    }

    public boolean isMovedInRepoMerged(IResource resource) throws CoreException {
        synchronized (movedInRepoDstSrcMerged) {
            return movedInRepoDstSrcMerged.containsKey(resource);
        }
    }

    // returns move source or null
    IResource unregisterMove(IResource destination) throws CoreException {
        destination = TeamUtils.getResource(destination);
        synchronized (movedSrcDst) {
            ensureMoveStateInitialized();
            if (movedDstSrc.containsKey(destination)) {
                IResource source = movedDstSrc.get(destination);
                movedSrcDst.remove(source);
                movedDstSrc.remove(destination);
                return source;
            }
            return null;
        }
    }

    private void flushMoveState(IProject project) throws CoreException {
        ArrayList<IResource> changedSources = new ArrayList<IResource>();
        synchronized (movedSrcDst) {
            ensureMoveStateInitialized();
            for (Iterator<Map.Entry<IResource, IResource>> iter = movedSrcDst.entrySet().iterator(); iter.hasNext();) {
                Map.Entry<IResource, IResource> entry = iter.next();
                IResource src = entry.getKey();
                IResource dst = entry.getValue();
                if ((src instanceof IProject) && src.getProject().equals(project)) {
                    // handle the situation of first local rename r(remote) -> r1 and project == r
                    // we don't have to flush data for remote project renamed locally
                    String movedFrom = dst.getPersistentProperty(DMRepositoryProvider.DM_PROJECT_MOVED_PROP);
                    if (src.getName().equals(movedFrom)) {
                        continue;
                    }
                }
                if (src.getProject().equals(project) || dst.getProject().equals(project)) {
                    iter.remove();
                    movedDstSrc.remove(dst);
                    if (!src.getProject().equals(project)) {
                        changedSources.add(src);
                    }
                }
            }
        }

        if (!changedSources.isEmpty()) { // if any, notify subscriber listeners to refresh decorations on the source resources
            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this,
                    changedSources.toArray(new IResource[changedSources.size()])));
        }
    }

    private void ensureMoveStateInitialized() throws CoreException {
        if (moveStateStatus == INITIALIZED || moveStateStatus == INITIALIZING) {
            return;
        }
        try {
            moveStateStatus = INITIALIZING;
            movedDstSrc.clear();
            movedSrcDst.clear();
            readMoveState();
        } finally {
            moveStateStatus = UNINITIALIZED;
        }
        moveStateStatus = INITIALIZED;
    }

    private void readMoveState() throws CoreException {
        boolean success = false;
        File stateFile = getStateFile(MOVE_STATE);
        if (stateFile.exists()) {
            DataInputStream dataIn = null;
            try {
                dataIn = new DataInputStream(new BufferedInputStream(new FileInputStream(stateFile),
                        TeamUtils.getReadBufferSize(stateFile.length())));
                dataIn.readInt();
                int size = dataIn.readInt();
                int cnt = 0;
                IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
                while (cnt < size) {
                    int type = dataIn.readInt();
                    String srcPath = dataIn.readUTF();
                    String dstPath = dataIn.readUTF();
                    IResource source, destination;
                    if (type == IResource.FILE) {
                        source = root.getFile(new Path(srcPath));
                        destination = root.getFile(new Path(dstPath));
                    } else if (type == IResource.FOLDER) {
                        source = root.getFolder(new Path(srcPath));
                        destination = root.getFolder(new Path(dstPath));
                    } else {
                        // if project
                        source = root.getProject(srcPath);
                        destination = root.getProject(dstPath);
                    }
                    movedSrcDst.put(source, destination);
                    movedDstSrc.put(destination, source);
                    cnt++;
                }
                success = true;
            } catch (IOException e) {
                DMTeamPlugin.log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMWorkspace_37, e));
            } finally {
                try {
                    if (dataIn != null) {
                        dataIn.close();
                    }
                } catch (IOException ignore) {
                }
                stateFile.delete();
            }
        }
        if (!success) {
            // log so that there is a trace as this should not normally happen except on fresh workspace
            DMTeamPlugin.log(new DMTeamStatus(IStatus.INFO, DMTeamStatus.UNKNOWN, "Discovering moved resources", null)); //$NON-NLS-1$
            movedDstSrc.clear();
            movedSrcDst.clear();
            discoverMovedResources();
        }
    }

    private void writeMoveState() {
        if (moveStateStatus == UNINITIALIZED) {
            return; // external data was not read in this session, no need to save
        }
        File tmpFile = getStateFile(MOVE_STATE + ".tmp"); //$NON-NLS-1$
        DataOutputStream dataOut = null;
        boolean tempFileWritten = false;
        try {
            dataOut = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmpFile), 8192));
            dataOut.writeInt(MOVE_STATE_VERSION);
            dataOut.writeInt(movedSrcDst.size());
            for (Iterator<Map.Entry<IResource, IResource>> iter = movedSrcDst.entrySet().iterator(); iter.hasNext();) {
                Map.Entry<IResource, IResource> entry = iter.next();
                IResource source = entry.getKey();
                IResource destination = entry.getValue();
                dataOut.writeInt(source.getType());
                dataOut.writeUTF(source.getFullPath().toString());
                dataOut.writeUTF(destination.getFullPath().toString());
            }
            tempFileWritten = true;
        } catch (IOException e) {
            DMTeamPlugin.log(DMTeamStatus.createErrorStatus(0, Messages.DMWorkspace_38, e));
        } finally {
            if (dataOut != null) {
                try {
                    dataOut.flush();
                    dataOut.close();
                } catch (IOException ignore) {
                }
            }
        }

        if (tempFileWritten) {
            File stateFile = getStateFile(MOVE_STATE);
            stateFile.delete();
            if (!stateFile.exists()) {
                if (!tmpFile.renameTo(stateFile)) {
                    DMTeamPlugin.getDefault()
                            .getLog()
                            .log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMWorkspace_39));
                }
            } else {
                DMTeamPlugin.getDefault()
                        .getLog()
                        .log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMWorkspace_40));
            }
        }
        tmpFile.delete();
    }

    private void discoverMovedResources() throws CoreException {
        IDMProject[] dmProjects = getProjects();
        for (int i = 0; i < dmProjects.length; i++) {
            final IDMProject dmProject = dmProjects[i];
            dmProjects[i].getRoot().accept(new IResourceVisitor() {
                @Override
                public boolean visit(IResource resource) throws CoreException {
                    IDMRemoteResource base = getBaseResource(resource);
                    if (base != null && base.isMoved() && isMovedInRepository(resource)) {
                        registerMove(resource, base.getMovedFromPath(), base.getMovedFromProject(), dmProject.getType(),
                                dmProject.getConnection());
                    }
                    return true;
                }
            }, IResource.DEPTH_INFINITE, true);
        }
    }

    void run(final IDMWorkspaceExecutable command, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            // clear savedMetadata Changes
            boolean deferredMD = setupDeferredMdListener();
            monitor.worked(50);

            ResourcesPlugin.getWorkspace().run(new IWorkspaceRunnable() {
                @Override
                public void run(IProgressMonitor _monitor) throws CoreException {
                    command.workspaceRun(_monitor);
                }
            }, command.getSchedulingRule(), IWorkspace.AVOID_UPDATE, Utils.subMonitorFor(monitor, 750));

            if (command.isValidSharing()) {

                XMLWorkspaceMergeCommand cmd = null;
                if (command instanceof XMLWorkspaceMergeCommand) {
                    cmd = (XMLWorkspaceMergeCommand) command;
                }

                boolean modifiesBase = command.modifiesBase();
                boolean modifiesRemote = command.modifiesRemote();

                // process metadata changes here
                if (deferredMD) {
                    if (cmd != null && !cmd.isUpdateMode()) {
                        // leave metadata for deleted resources in base tree if merge mode.
                        processDeferredMdListener(true);
                    } else {
                        // remove metadata for deleted resources by default.
                        processDeferredMdListener();
                    }
                }

                IProgressMonitor refreshMonitor = null;
                if (cmd != null && (cmd.wasDownloadCancelled() && monitor.isCanceled())) {
                    // main monitor was cancelled but we still should refresh new files in project
                    refreshMonitor = new NullProgressMonitor();
                }

                if (modifiesBase && modifiesRemote) {
                    Set<IResource> toRefresh = new HashSet<IResource>();
                    toRefresh.addAll(Arrays.asList(command.getBaseResourcesToRefresh()));
                    toRefresh.addAll(Arrays.asList(command.getResourcesToRefresh()));
                    refresh(toRefresh.toArray(new IResource[toRefresh.size()]), IResource.DEPTH_INFINITE,
                            refreshMonitor != null ? refreshMonitor : Utils.subMonitorFor(monitor, 200));
                } else if (modifiesBase) {
                    IResource[] toRefresh = command.getBaseResourcesToRefresh();
                    queryContentStatus(toRefresh, IResource.DEPTH_INFINITE, null,
                            refreshMonitor != null ? refreshMonitor : Utils.subMonitorFor(monitor, 100));
                    refreshBaseTree(toRefresh, IResource.DEPTH_INFINITE,
                            refreshMonitor != null ? refreshMonitor : Utils.subMonitorFor(monitor, 100));
                } else if (modifiesRemote) {
                    IResource[] toRefresh = command.getResourcesToRefresh();
                    queryContentStatus(toRefresh, IResource.DEPTH_INFINITE, null,
                            refreshMonitor != null ? refreshMonitor : Utils.subMonitorFor(monitor, 100));
                    refreshRemoteTree(toRefresh, IResource.DEPTH_INFINITE,
                            refreshMonitor != null ? refreshMonitor : Utils.subMonitorFor(monitor, 100));
                }
                // check if command has any additional changes to report
                if (command.getChanges() != null && command.getChanges().length > 0) {
                    processResourceStateChanges(Arrays.asList(command.getChanges()));
                    fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this, command.getChanges()));
                }
            }
        } finally {
            monitor.done();
        }
    }

    /**
     * Notifies workspace that metadata changed for the supplied resources
     *
     * @param resources
     *            supplied resources
     * @param monitor
     * @param sendStateChanges
     *            true if changes will be propagated
     * @throws CoreException
     */
    public void metadataChanged(IResource[] resources, IProgressMonitor monitor) throws CoreException {
        try {
            if (debugResources) {
                System.out.println(TeamUtils.myThread() + "dmws md changed " + resources.length + " resources"); //$NON-NLS-1$ //$NON-NLS-2$
                for (IResource r : resources) {
                    System.out.println("    " + r.getLocation().toOSString()); //$NON-NLS-1$
                }
                System.out.println(TeamUtils.myThread() + " dmws md changed btl acquire"); //$NON-NLS-1$
            }
            baseTreeLock.acquire();
            refreshBaseTree(resources, IResource.DEPTH_INFINITE, true, monitor);
        } finally {
            if (debugResources) {
                System.out.println(TeamUtils.myThread() + " dmws md changed btl release"); //$NON-NLS-1$
            }
            baseTreeLock.release();
        }
    }

    // notifies workspace that .dmignore files changed in the supplied folders
    void ignoreChanged(IContainer[] folders) throws CoreException {
        synchronized (ignoreCache) {
            for (int i = 0; i < folders.length; i++) {
                ignoreCache.remove(folders[i]); // no cache entry will cause ignores to be re-read from disk
            }
        }
        List<IResource> possibleIgnores = new ArrayList<IResource>();
        for (int i = 0; i < folders.length; i++) {
            accumulateNonManagedChildren(folders[i], possibleIgnores);
        }
        if (!possibleIgnores.isEmpty()) {
            fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this,
                    possibleIgnores.toArray(new IResource[possibleIgnores.size()])));
        }
    }

    private void accumulateNonManagedChildren(IContainer parent, List<IResource> possibleIgnores) throws CoreException {
        IResource[] members = parent.members();
        for (int i = 0; i < members.length; i++) {
            if (!isManaged(members[i])) {
                possibleIgnores.add(members[i]);
            }
            if (members[i].getType() != IResource.FILE) {
                accumulateNonManagedChildren((IContainer) members[i], possibleIgnores);
            }
        }
    }

    private void cacheFolderIgnores(IContainer parent, String[] ignoresPatterns) throws CoreException {
        synchronized (ignoreCache) {
            ignoreCache.put(parent, new FileNameMatcher(ignoresPatterns));
        }
    }

    // returns null if .dmignore does not exist
    private String[] readIgnoreFile(IContainer parent) throws CoreException {
        return TeamUtils.readLines(parent.getFile(new Path(DM_IGNORE)), true);
    }

    private void writeIgnoreFile(IContainer parent, String[] ignores) throws CoreException {
        TeamUtils.writeLines(parent.getFile(new Path(DM_IGNORE)), ignores);
    }

    private boolean checkDmIgnore(IResource resource) throws TeamException {
        if (resource.getType() == IResource.PROJECT || resource.getType() == IResource.ROOT || !resource.exists()) {
            return false;
        }

        IContainer parentFolder = null;

        if (resource.getType() == IResource.FILE) {
            parentFolder = resource.getParent();
        } else if ((resource.getType() != IResource.ROOT)) {
            parentFolder = (resource).getParent();
        }
        boolean parent = false;

        /* Note: If we look at the parent dmignore location we should skip all not recursive paths */
        while ((parentFolder.getType() != IResource.ROOT)) {
            synchronized (ignoreCache) {
                FileNameMatcher matcher = ignoreCache.get(parentFolder);
                if (matcher == null) {
                    try {
                        String[] ignoresPatrerns = readIgnoreFile(parentFolder);

                        /* FileNameMatcher should trim recursive path prefix. Maybe should store recursive path separately. */
                        matcher = ignoresPatrerns == null
                                ? FileNameMatcher.NULL_MATCHER : new FileNameMatcher(ignoresPatrerns);
                        ignoreCache.put(parentFolder, matcher);
                    } catch (CoreException e) {
                        throw TeamException.asTeamException(e);
                    }
                }

                /* Also check recursive paths */
                if (matcher.match(resource.getName(), parent) == true) {
                    return true;
                }

                if (matcher.IsStopRecursive()) {
                    break;
                }
            }

            parentFolder = ((IResource) (parentFolder)).getParent();

            parent = true;
        }
        return false;
    }

    @Override
    public void connectionAdded(DimensionsConnectionDetailsEx addedCon) {
        // do nothing here
    }

    @Override
    public void connectionDeleted(DimensionsConnectionDetailsEx deletedCon) {
        // disconnect all projects on this connection
        IProject[] allProjects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
        for (int i = 0; i < allProjects.length; i++) {
            DMRepositoryProvider dmProvider = (DMRepositoryProvider) RepositoryProvider.getProvider(allProjects[i],
                    DMRepositoryProvider.ID);
            if (dmProvider != null) {
                try {
                    String connName = allProjects[i].getPersistentProperty(CONNECTION_NAME_PROP);
                    if (connName != null && connName.equals(deletedCon.getConnName())) {
                        DMTeamPlugin.getWorkspace().unmanage(allProjects[i], false, null);
                    }
                } catch (CoreException cex) {
                    DMTeamPlugin.getDefault().getLog().log(cex.getStatus());
                }
            }
        }

    }

    @Override
    public void connectionUpdated(DimensionsConnectionDetailsEx oldCon, DimensionsConnectionDetailsEx newCon) {
        // do nothing here
    }

    private void collectResourcesByKind(IResource resource, int depth, int change_kind, int direction_kind,
            List<SyncInfo> result, IProgressMonitor monitor) throws CoreException {
        if (resource == null) {
            return;
        }
        if (resource.getType() == IResource.PROJECT) {
            return;
        }
        if (resource.exists()) {
            resource.setSessionProperty(DMWorkspaceSyncInfo.KEY_SYNC_REPOSITORY_MOVE, null);
        }
        SyncInfo info = getSyncInfo(resource);
        if (info != null && !result.contains(info) && (info.getKind() & SyncInfo.CHANGE_MASK) == change_kind
                && (info.getKind() & SyncInfo.DIRECTION_MASK) == direction_kind) {
            result.add(info);
        }
    }

    private void collectMergedFromForeignResources(IResource resource, int depth, List<SyncInfo> result,
            IProgressMonitor monitor) throws CoreException {
        if (resource == null) {
            return;
        }
        if (resource.getType() == IResource.PROJECT) {
            return;
        }
        if (resource.exists()) {
            resource.setSessionProperty(DMWorkspaceSyncInfo.KEY_SYNC_REPOSITORY_MOVE, null);
        }
        SyncInfo info = getSyncInfo(resource);
        if (info != null && !result.contains(info) && DMWorkspaceSyncInfo.isMergedFromForeignStream(resource)) {
            result.add(info);
        }
    }

    private void addResourcesByKind(IResource[] resources, List<SyncInfo> destination, List<SyncInfo> source, int depth,
            IProgressMonitor monitor) throws CoreException {
        for (int i = 0; i < resources.length; i++) {
            IResource resource = resources[i];
            resource = TeamUtils.getResource(resource);
            if (TeamUtils.isResourceFromForeignStream(resource)) {
                // Moves involving foreign contents are shown as incoming addition and outgoing addition/conflicting change
                collectResourcesByKind(resource, depth, SyncInfo.ADDITION, SyncInfo.INCOMING, destination, monitor);
                collectResourcesByKind(resource, depth, SyncInfo.CHANGE, SyncInfo.CONFLICTING, source, monitor);
                collectResourcesByKind(resource, depth, SyncInfo.ADDITION, SyncInfo.OUTGOING, source, monitor);
                // conf deletion can occur on rename/move
                collectResourcesByKind(resource, depth, SyncInfo.DELETION, SyncInfo.CONFLICTING, source, monitor);
                // collect marked as merged local parts of rename/move
                collectMergedFromForeignResources(resource, depth, source, monitor);
            } else {
                collectResourcesByKind(resource, depth, SyncInfo.ADDITION, SyncInfo.INCOMING, destination, monitor);
                collectResourcesByKind(resource, depth, SyncInfo.CHANGE, SyncInfo.CONFLICTING, source, monitor);
                collectResourcesByKind(resource, depth, SyncInfo.DELETION, SyncInfo.INCOMING, source, monitor);
            }
            if (resource.getType() != IResource.FILE && depth != IResource.DEPTH_ZERO) {
                addResourcesByKind(members(resource), destination, source, depth, monitor);
            }
        }
    }

    @Override
    public IResource[] members(IResource resource) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        return super.members(resource);
    }

    public List<IResource> searchForMovedInRepostoryResources(IResource[] resources, int depth, IProgressMonitor monitor)
            throws CoreException {
        long start = 01;
        if (debug) {
            System.out.println("+ searchForMovedInRepostoryResources"); //$NON-NLS-1$
            start = System.currentTimeMillis();
        }

        flushMoveInRepository();
        flushMovedInRepoMergedCache();

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            List<IResource> result = new ArrayList<IResource>();
            if (resources != null && resources.length > 0) {
                List<SyncInfo> adding = new ArrayList<SyncInfo>();
                List<SyncInfo> deleting = new ArrayList<SyncInfo>();

                boolean isForeignContent = false;
                boolean isLocalWorksetPointingToForeign = TeamUtils.isLocalWorksetPointingToForeignStream(resources[0])
                        || TeamUtils.isLocalWorksetPointingToForeignProject(resources[0]);
                boolean localIsStreamOrProject = TeamUtils.isLocalWorksetAStream(resources[0]) != null
                        ? true : TeamUtils.isLocalWorksetAProject(resources[0]) != null;
                addResourcesByKind(resources, adding, deleting, depth,
                        Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));

                List<SyncInfo> incomingAdditions = new ArrayList<SyncInfo>();
                List<SyncInfo> outgoingAdditions = new ArrayList<SyncInfo>();

                for (Iterator<SyncInfo> delIterator = deleting.iterator(); delIterator.hasNext();) {
                    SyncInfo delInfo = delIterator.next();
                    isForeignContent = TeamUtils.isResourceFromForeignStream(delInfo.getLocal());
                    IResourceVariant delBase = delInfo.getBase();

                    if (delBase instanceof DMRemoteFile) {

                        boolean simpleDeletion = true;
                        for (Iterator<SyncInfo> addIterator = adding.iterator(); addIterator.hasNext();) {
                            SyncInfo addInfo = addIterator.next();
                            IResourceVariant addRemote = addInfo.getRemote();
                            if (addRemote == null) {
                                // if that was merged at first iteration then we have to use the base for check
                                addRemote = addInfo.getBase();
                            }
                            if (addRemote instanceof DMRemoteFile && ((DMRemoteFile) addRemote).getItemSpecId()
                                    .equals(((DMRemoteFile) delBase).getItemSpecId())) {
                                simpleDeletion = false;
                                if (isForeignContent && localIsStreamOrProject && !isLocalWorksetPointingToForeign) {
                                    registerMoveInRepository(delInfo.getLocal(), addInfo.getLocal());
                                } else if (delInfo.getKind() == SyncInfo.IN_SYNC) {
                                    // this is marked as merged resource - resolved conflicting part of rename/move in repo
                                    // register resolved rename/move
                                    registerMovedInRepoMergedCache(addInfo.getLocal(), delInfo.getLocal());
                                    continue;
                                } else {
                                    registerMoveInRepository(addInfo.getLocal(), delInfo.getLocal());
                                }

                                if (isForeignContent && !isLocalWorksetPointingToForeign
                                        && (addInfo.getKind() & SyncInfo.DIRECTION_MASK) == SyncInfo.INCOMING
                                        && (addInfo.getKind() & SyncInfo.CHANGE_MASK) == SyncInfo.ADDITION) {
                                    incomingAdditions.add(addInfo);
                                }

                                if (isForeignContent && isLocalWorksetPointingToForeign
                                        && (delInfo.getKind() & SyncInfo.DIRECTION_MASK) == SyncInfo.OUTGOING
                                        && (delInfo.getKind() & SyncInfo.CHANGE_MASK) == SyncInfo.ADDITION) {
                                    outgoingAdditions.add(delInfo);
                                }

                                cacheMetadataOfItemBeingMoved(delInfo, addInfo,
                                        Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
                                break;
                            }
                        }

                        // deleted resource should be marked as well as moved resource for future sync kind calculation
                        if (simpleDeletion && isForeignContent && isLocalWorksetPointingToForeign
                                && (delInfo.getKind() & SyncInfo.DIRECTION_MASK) == SyncInfo.OUTGOING
                                && (delInfo.getKind() & SyncInfo.CHANGE_MASK) == SyncInfo.ADDITION) {
                            outgoingAdditions.add(delInfo);
                        }
                    }
                }

                if (incomingAdditions.size() > 0) {
                    SyncInfo[] nodes = incomingAdditions.toArray(new SyncInfo[incomingAdditions.size()]);
                    IResource[] locals = new IResource[nodes.length];
                    IDMRemoteResource[] remotes = new IDMRemoteResource[nodes.length];
                    for (int i = 0; i < nodes.length; i++) {
                        locals[i] = nodes[i].getLocal();
                        remotes[i] = (IDMRemoteResource) nodes[i].getRemote();
                        result.add(locals[i]);
                    }
                    merged(locals, remotes, Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
                }

                if (outgoingAdditions.size() > 0) {
                    SyncInfo[] nodes = outgoingAdditions.toArray(new SyncInfo[outgoingAdditions.size()]);
                    for (int i = 0; i < nodes.length; i++) {
                        IResource local = nodes[i].getLocal();
                        local.setSessionProperty(DMWorkspaceSyncInfo.KEY_SYNC_REPOSITORY_MOVE, Boolean.TRUE);
                        result.add(local);
                    }
                }
            }
            return result;
        } finally {
            monitor.done();
            if (debug) {
                long stop = System.currentTimeMillis();
                System.out.println("- searchForMovedInRepostoryResources done in " + (stop - start) + "ms"); //$NON-NLS-1$ //$NON-NLS-2$
            }
        }

    }

    private void cacheMetadataOfItemBeingMoved(SyncInfo sourceInfo, SyncInfo destinationInfo, IProgressMonitor monitor)
            throws CoreException {
        ItemMetadata localMetadata = (ItemMetadata) WorkspaceMetadataManager.getInstance()
                .getMetadata(sourceInfo.getLocal());
        ItemMetadata remoteMetadata = ((DMRemoteFile) destinationInfo.getRemote()).getMetadata();
        String sourceRevision = localMetadata.getItemSpec().substring(localMetadata.getItemSpec().lastIndexOf(';') + 1);
        String destinationRevision = remoteMetadata.getItemSpec()
                .substring(remoteMetadata.getItemSpec().lastIndexOf(';') + 1);
        DMProject dmProject = TeamUtils.getDmProject(destinationInfo.getLocal());

        if (!sourceRevision.equals(destinationRevision)) {
            if (isCommonAncestor(dmProject, localMetadata, remoteMetadata, monitor)) { // Have a common ancestor
                sourceInfo.getLocal().setSessionProperty(
                        DMWorkspaceSyncInfo.KEY_SYNC_REPOSITORY_MOVE_AND_LOCAL_HAVE_COMMON_ANCESTOR, Boolean.TRUE);
                localMetadata.setRevisionListAsString(destinationRevision);
                flushRetainedMetadataOfItemBeingMoved();
                String spec = localMetadata.getItemSpec().substring(0, localMetadata.getItemSpec().lastIndexOf(';'));
                storeMetadataOfItemBeingMoved(spec, localMetadata);
            }
        }
    }

    private boolean isCommonAncestor(DMProject dmProject, ItemMetadata localMetadata, ItemMetadata remoteMetadata,
            IProgressMonitor monitor) throws CoreException {
        List<ItemMetadata> localMetadatas = new ArrayList<ItemMetadata>();
        List<ItemMetadata> remoteMetadatas = new ArrayList<ItemMetadata>();
        localMetadatas.add(localMetadata);
        remoteMetadatas.add(remoteMetadata);

        List<ItemMetadata> result = dmProject.queryForeignContentStatus(localMetadatas, remoteMetadatas, monitor);
        if (result != null) {
            ItemMetadata md = result.get(0);
            if (md.getItemUid() != -1) {
                if ((localMetadata.getItemUid() != md.getItemUid() && remoteMetadata.getItemUid() != md.getItemUid())
                        || (localMetadata.getItemUid() == md.getItemUid()
                                && remoteMetadata.getItemUid() != md.getItemUid())) {
                    // Have a common ancestor
                    return true;

                }
            }
        }
        return false;
    }

    /**
     * This method stores the metadata of the item being moved locally in the following use case:
     * Create StreamA with two folder(Folder1 and Folder2) and a file in each of these folders( file1 and file2 respectively ).
     * Create a StreamB from StreamA.
     * User1 adds StreamA to workspace. Modifies file1 locally and delivers it to StreamA.
     * User2 adds StreamB to workspace. Moves file1 locally and moves to Folder2 and delivers it toStreamB.
     * User1 switches to StreamB , does a sync and Updates the repository move. Switches back to StreamA and does a syn. Sync view
     * shows local move.
     * Do a deliver.
     * In this scenario ,during Update of repository move ,we need some part of the metadata of Folder1/File1 to use in the
     * metadata
     * of Folder2/File1 during Update of repository move and we store
     * the metadata here for future use.
     */
    @Override
    public void retainMetadataOfTheResourceBeingMoved(List<SyncInfo> adding, List<SyncInfo> deleting,
            IProgressMonitor monitor) throws CoreException {
        if ((adding != null && adding.size() > 0) && (deleting != null && deleting.size() > 0)) {
            for (Iterator<SyncInfo> delIterator = deleting.iterator(); delIterator.hasNext();) {
                SyncInfo delInfo = delIterator.next();
                IResourceVariant delBase = delInfo.getBase();
                if (delBase instanceof DMRemoteFile) {
                    for (Iterator<SyncInfo> addIterator = adding.iterator(); addIterator.hasNext();) {
                        SyncInfo addInfo = addIterator.next();
                        IResourceVariant addRemote = addInfo.getRemote();
                        if (addRemote == null) {
                            // if that was merged at first iteration then we have to use the base for check
                            addRemote = addInfo.getBase();
                        }
                        if (addRemote instanceof DMRemoteFile && ((DMRemoteFile) addRemote).getItemSpecId()
                                .equals(((DMRemoteFile) delBase).getItemSpecId())) {
                            cacheMetadataOfItemBeingMoved(delInfo, addInfo, monitor);
                            break;
                        }
                    }
                }
            }
        }
    }

    private void flushRetainedMetadataOfItemBeingMoved() throws CoreException {
        synchronized (metadataCacheOfItemBeingMoved) {
            metadataCacheOfItemBeingMoved.clear();
        }
    }

    private void storeMetadataOfItemBeingMoved(String itemSpec, ItemMetadata metadata) throws CoreException {
        Assert.isNotNull(itemSpec);
        Assert.isNotNull(metadata);
        synchronized (metadataCacheOfItemBeingMoved) {
            if (metadataCacheOfItemBeingMoved.get(itemSpec) == null) {
                metadataCacheOfItemBeingMoved.put(itemSpec, metadata);
            }
        }
    }

    public ItemMetadata getCachedMetadataOfItemBeingMoved(String itemSpec) throws CoreException {
        synchronized (metadataCacheOfItemBeingMoved) {
            return metadataCacheOfItemBeingMoved.get(itemSpec);
        }
    }

    public void renameInMovedCaches(IProject srcProject, IProject dstProject) throws CoreException {
        String oldName = srcProject.getName();
        synchronized (movedSrcDst) {
            ensureMoveStateInitialized();
            Map<IResource, IResource> cacheSrcDst = new HashMap<IResource, IResource>();
            Map<IResource, IResource> cacheDstSrc = new HashMap<IResource, IResource>();
            for (Iterator<Map.Entry<IResource, IResource>> iter = movedSrcDst.entrySet().iterator(); iter.hasNext();) {
                Map.Entry<IResource, IResource> entry = iter.next();
                IResource src = entry.getKey();
                IResource dst = entry.getValue();

                IResource newSrc = src;
                IResource newDst = dst;
                if (src.getFullPath().segment(0).equals(oldName)) {
                    if (src instanceof IFolder) {
                        newSrc = dstProject.getFolder(src.getFullPath().removeFirstSegments(1));
                    } else if (src instanceof IFile) {
                        newSrc = dstProject.getFile(src.getFullPath().removeFirstSegments(1));
                    }
                }

                if (dst.getFullPath().segment(0).equals(oldName)) {
                    if (dst instanceof IFolder) {
                        newDst = dstProject.getFolder(dst.getFullPath().removeFirstSegments(1));
                    } else if (dst instanceof IFile) {
                        newDst = dstProject.getFile(dst.getFullPath().removeFirstSegments(1));
                    }
                }
                iter.remove();
                movedDstSrc.remove(dst);

                cacheSrcDst.put(newSrc, newDst);
                cacheDstSrc.put(newDst, newSrc);
            }
            movedSrcDst.putAll(cacheSrcDst);
            movedDstSrc.putAll(cacheDstSrc);
        }
    }

    public void renameInFolderStatusCache(IProject srcProject, IProject dstProject) {
        String name = srcProject.getName();
        IPath newNamePath = new Path(dstProject.getName());
        synchronized (folderStatusCache) {
            ensureFolderStatusCacheInitialized();
            Map<IPath, WorkspaceFolderStatus> cache = new HashMap<IPath, WorkspaceFolderStatus>();
            for (Iterator<Map.Entry<IPath, WorkspaceFolderStatus>> iter = folderStatusCache.entrySet().iterator(); iter
                    .hasNext();) {
                Map.Entry<IPath, WorkspaceFolderStatus> entry = iter.next();
                IPath entryPath = entry.getKey();
                if (name.equals(entryPath.segment(0))) {
                    IPath newEntryPath = newNamePath.append(entryPath.removeFirstSegments(1));
                    cache.put(newEntryPath, entry.getValue());
                    iter.remove();
                }
            }
            folderStatusCache.putAll(cache);
        }
    }

    public void setUpdateFromReqSubscriber(CustomSubscriber updateFromReqSubscriber) {
        this.updateFromReqSubscriber = updateFromReqSubscriber;
    }

    /**
     * If the merge is against a foreign stream, then we need to retain the local metadata and add "revision-list" key
     * and "merged_from_foreign_stream" key to the metadata. After "Mark as Merged" the item will disappear from the sync view.
     * The "revision-list" key will only be added if the files have a common ancestor. If two files have different spec
     * or if the local file in unmanaged then we will not add "revision-list" key to the metadata. Which means there will not be
     * any pedigree maintained if these files are delivered back to the parent stream after merge from the foreign Stream.
     *
     * @param local
     *            - local resource
     * @param remote
     *            - remote resource
     * @throws CoreException
     */
    private void mergeFromForeignStream(IResource local, IDMRemoteResource remote) throws CoreException {
        if (TeamUtils.isLocalWorksetPointingToForeignStream(local)) {
            if (local.getType() == IResource.FILE && local.exists() && remote != null
                    && remote.getType() == IDMRemoteResource.FILE) {
                IDMRemoteFile base = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
                IDMRemoteFile remoteFile = (IDMRemoteFile) remote;
                BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(local);
                if (metadata instanceof ItemMetadata) {
                    ItemMetadata itemMetadata = (ItemMetadata) metadata;
                    String mergeString = itemMetadata.getRevisionListAsString();
                    boolean change = false; // anything changed?
                    if (Utils.isNullEmpty(mergeString)) {
                        mergeString = remoteFile.getRevision();
                        change = true;
                    } else {
                        Set<String> revisions = TeamUtils.parseRevisionList(mergeString);
                        if (revisions.add(remoteFile.getRevision())) {
                            mergeString = Utils.toCsvString(revisions.toArray(new String[revisions.size()]), false);
                            change = true;
                        }
                    }
                    if (change) {
                        // Do not store revision if the files don't have a common ancestor(will result in a failed deliver).
                        // This is the case where a file was added to the parent stream and a file with the same name at the
                        // same path was added to the child stream.
                        if (isSameItem(base, remoteFile) && !base.getRevision().equals(remoteFile.getRevision())) {
                            itemMetadata.setRevisionListAsString(mergeString);
                        }

                        String mergedFromStreamsList = itemMetadata.get(TeamUtils.MERGED_FROM_FOREIGN_STREAM);
                        if (mergedFromStreamsList != null && mergedFromStreamsList.length() != 0) {
                            mergedFromStreamsList += "," + remoteFile.getProject().getId(); //$NON-NLS-1$
                        } else {
                            mergedFromStreamsList = remoteFile.getProject().getId();
                        }
                        itemMetadata.put(TeamUtils.MERGED_FROM_FOREIGN_STREAM, mergedFromStreamsList);
                        WorkspaceMetadataManager.getInstance().updateMetadata(local, itemMetadata);
                    }
                }
            } else if (!local.exists() && isManaged(local) && remote != null && remote.getType() == IDMRemoteResource.FILE) {
                // the case when conf addition was marked as merged: md is here but local file doesn't exist
                BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(local);
                String mergedFromStreamsList = metadata.get(TeamUtils.MERGED_FROM_FOREIGN_STREAM);
                String remoteStreamName = DMTeamPlugin.getWorkspace()
                        .getRemoteResource(local.getProject())
                        .getProject()
                        .getId();
                if (mergedFromStreamsList != null && mergedFromStreamsList.length() != 0) {
                    mergedFromStreamsList += "," + remoteStreamName; //$NON-NLS-1$
                } else {
                    mergedFromStreamsList = remoteStreamName;
                }
                metadata.put(TeamUtils.MERGED_FROM_FOREIGN_STREAM, mergedFromStreamsList);
                WorkspaceMetadataManager.getInstance().updateMetadata(local, metadata);
            }
        }
    }

    // checks if 2 items have the same item spec id, i.e. checks if 2 item revisions one pedigree
    private boolean isSameItem(IDMRemoteFile file1, IDMRemoteFile file2) {
        return file1 != null && file2 != null && file1.getItemSpecId().equals(file2.getItemSpecId());
    }

    /*
     * Update resources from collection that represents all controlled files under
     * uncontrolled folders
     */
    public void updateBaseResourcesUnderUncontrolledFolders(Collection<IResource> resourcesList) throws CoreException {
        try {
            if (debugResources) {
                System.out.println(TeamUtils.myThread() + " dmws uBRUUF btl acquire"); //$NON-NLS-1$
            }
            baseTreeLock.acquire();
            // uncommenting prevent additional computations but in this case we can lose more complex cases
            // resources = TeamUtils.getNonOverlapping(resources);
            for (IResource resource : resourcesList) {
                if (!isManaged(resource)) {
                    getBaseTree().refresh(new IResource[] { resource }, IResource.DEPTH_ZERO, new NullProgressMonitor());
                }
            }
        } finally {
            if (debugResources) {
                System.out.println(TeamUtils.myThread() + " dmws uBRUU btl release"); //$NON-NLS-1$
            }
            baseTreeLock.release();
        }
    }

    // in the workspace run under BTL

    @Override
    public void markStaleAndProcess(Collection<IContainer> folders, boolean doFiles) throws CoreException {
        List<IResource> processed = new ArrayList<IResource>();
        // foreach folder
        try {
            if (debugResources) {
                System.out.println(TeamUtils.myThread() + " dmws mSAP btl acquire"); //$NON-NLS-1$
            }
            baseTreeLock.acquire();
            for (Iterator<IContainer> fit = folders.iterator(); fit.hasNext();) {
                IContainer cont = fit.next();
                if (!markStale(cont, doFiles, processed)) {
                    continue;
                }
            }

            IResource[] mdChanged = processed.toArray(new IResource[processed.size()]);
            mdChanged = TeamUtils.getNonOverlapping(mdChanged);
            metadataChanged(mdChanged, null);
            processed.clear();
        } finally {
            if (debugResources) {
                System.out.println(TeamUtils.myThread() + " dmws mSAP btl release"); //$NON-NLS-1$
            }
            baseTreeLock.release();
        }
    }

    // marks all in Container as stale
    @Override
    public boolean markStale(IContainer cont, boolean doFiles, List<IResource> processed) {
        IResource[] resources;
        try {
            resources = cont.members();
        } catch (CoreException e1) {
            return false;
        }
        for (IResource res : resources) {
            if (doFiles) {
                // dont process non-files if doing files
                if (res.getType() != IResource.FILE) {
                    continue;
                }
            } else {
                // dont process files if not doing files
                if (res.getType() == IResource.FILE) {
                    continue;
                }
            }

            IDMRemoteResource remoteResource = null;
            try {
                remoteResource = getBaseResource(res);
            } catch (TeamException e) {
                // swallow
                remoteResource = null;
            }

            if (remoteResource != null) {
                if (debugResources) {
                    System.out.println(TeamUtils.myThread() + " dmws marking stale " //$NON-NLS-1$
                            + remoteResource.getLocalResource().getLocation().toOSString());
                }
                remoteResource.markStale();
                try {
                    // update base as base is used in fetchVariant / fetch folder
                    updateBase(res, remoteResource);
                } catch (TeamException e) {
                }
                if (processed != null) {
                    processed.add(res);
                }
            }
        }
        return true;
    }
    
    @Override
    public boolean handlePossibleWorkAreaRehome(Collection<IContainer> filesOrFolders) {
        WaRootInfo targetRoot = null;
        HashSet<IProject> canditatesToRehome = new HashSet<IProject>();
        for (IContainer item : filesOrFolders) {
            canditatesToRehome.add(item.getProject());
        }

        try {
            final List<IDMProject> projectsToRehome = new ArrayList<IDMProject>();
            for (IDMProject p : getProjects()) {
                IProject eclipseProject = p.getProject();
                if (canditatesToRehome.contains(eclipseProject)) {
                    if (DMRepositoryProvider.getDMProvider(eclipseProject) == null) {
                        continue;
                    }
                    WaRootInfo currentRoot = null;
                    if (canUseSameRoot(targetRoot, eclipseProject)) {
                        currentRoot = targetRoot;
                    } else {
                        currentRoot = queryWorkAreaToRehome(p);
                    }
                    if (currentRoot != null) {
                        if (targetRoot == null) {
                            targetRoot = currentRoot;
                        }
                        if (targetRoot.path.equals(currentRoot.path)) {
                            projectsToRehome.add(p);
                        }
                    }
                }
            }
            if (projectsToRehome.size() > 0) {
                DimensionsConnectionDetailsEx connection = projectsToRehome.get(0).getConnection();
                Session session = connection.openSession(null);
                Project project = session.getObjectFactory().getProject(targetRoot.project);
                if (project != null) {
                    final WorksetAdapter target = new WorksetAdapter(project, connection);
                    fireNotification(new Notification() {
                        @Override
                        protected void notify(IResourceStateChangeListener listener) {
                            listener.workAreaRehomeDetected(projectsToRehome, target);
                        }
                    });
                    return true;
                }
            }
        } catch (CoreException e) {
            DMPlugin.log(e.getStatus());
        }
        return false;
    }
    
    private boolean canUseSameRoot(WaRootInfo targetRoot, IProject eclipseProject) {
        if (targetRoot == null) {
            return false;
        }
        IPath projectPath = eclipseProject.getFullPath();
        return targetRoot.path.equals(projectPath) || targetRoot.path.isPrefixOf(projectPath);
    }

    private WaRootInfo queryWorkAreaToRehome(IDMProject candidate) {
        String parentStreamSpec = candidate.getId();
        
        List<WaRootInfo> info = new ArrayList<WaRootInfo>();
        IPath wa = TeamUtils.queryCompatibleWorkAreaRoot(candidate.getUserDirectory(), parentStreamSpec,
                false /* isBaseline */, info);
        WaRootInfo result = null;
        if (wa == null && info != null) {
            for (WaRootInfo root : info) {
                if (root.project.equalsIgnoreCase(parentStreamSpec) == false) {
                    result = root;
                }
            }
        }
        return result;
    }
}

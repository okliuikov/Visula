/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class GetRevisionRequest extends SimpleItemRevisionRequest {
    private boolean metadata = true;
    private boolean makeWriteable = false;
    private Boolean expandSubstitutionVariables = null;

    /**
     * @param file
     * @param itemRevision
     * @throws CoreException
     */
    public GetRevisionRequest(IFile file, ItemRevision itemRevision) throws CoreException {
        super(file, itemRevision);
    }

    @Override
    public int getKind() {
        if (getResource().exists()) {
            return MODIFY;
        }
        return CREATE;
    }

    /**
     * Sets whether or not metadata should be updated. Metadata is updated
     * by default.
     * @param value <code>true</code> to update md, <code>false</code> not to update
     */
    public void setMetadata(boolean value) {
        this.metadata = value;
    }

    /**
     * Sets whether or not file should be made writable after get succeeds.
     * By default the file is left in read-only state.
     * @param value <code>true</code> to make writable, <code>false</code> to
     *            leave as read-only
     */
    public void setMakeWriteable(boolean value) {
        this.makeWriteable = value;
    }

    /**
     * Sets whether or not parameters should be substituted.
     * Global option is used by default.
     * @param value <code>true</code> to substitute, <code>false</code> not to substituted, <code>null</code> use default
     */
    public void setExpandSubstitutionVariables(Boolean value) {
        this.expandSubstitutionVariables = value;
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            return get();
        } finally {
            monitor.done();
        }

    }

    /*
     * copies remote revision to local, must be called in session runnable
     */
    DimensionsResult get() throws Exception {
        ItemRevision itemRevision = getItemRevision();
        IFile target = getFile();
        if (target.exists()) {
            TeamUtils.setReadOnly(target, false); // TODO VG on Jan 28, 2006: work around an API bug
        }
        boolean debug = DMTeamPlugin.getDefault().isDebuggingItemCommands();
        long start = 0l;
        if (debug) {
            System.out.println("+ about to call getCopy for '" + itemRevision.getAttribute(SystemAttributes.OBJECT_SPEC) + "'->'"
                    + target.getLocation().toOSString() + "'");
            start = System.currentTimeMillis();
        }

        // TODO VG on Mar 6, 2006: darius runs a db query if filename is missing,
        // this is our "optimization" to work around this peculiarity, can be
        // removed when darius is fixed
        // workaround start
        if (itemRevision.getAttribute(SystemAttributes.ITEMFILE_FILENAME) == null) {
            TeamUtils.setFilename(itemRevision, target.getName());
        }
        // workaround end

        DimensionsResult result = null;
        boolean expandVars = expandSubstitutionVariables == null
                ? TeamUtils.isExpandSubstitution() : expandSubstitutionVariables.booleanValue();
        if (metadata) {
            result = itemRevision.getCopy(target.getLocation().toOSString(), expandVars, true, false);
        } else {
            result = itemRevision.getCopyNoMetadata(target.getLocation().toOSString(), expandVars, true, false);
        }

        if (debug) {
            long stop = System.currentTimeMillis();
            System.out.println("- done, took " + (stop - start) + "ms");
        }

        TeamUtils.setReadOnly(target, !makeWriteable);
        target.touch(null);

        TeamUtils.ensureReacheable(target.getParent(), false);

        return result;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2007, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmfile.progress.CancelMonitor;
import com.serena.dmfile.progress.ProgressListener;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Adapts an Eclipse progress monitor so it can be used with dmclient.
 * @author V.Grishchenko
 */
public class TransferMonitor implements ProgressListener, CancelMonitor {
    public static final int DOWN = 1;
    public static final int UP = 2;

    private static final long MAX_VALUE = Integer.MAX_VALUE / 2;

    protected String task;
    protected IProgressMonitor mainProgress;
    protected IProgressMonitor fileProgress;
    protected int direction;
    protected int total = 2000;
    protected int worked = 0;
    protected boolean mainProgressStarted;

    private boolean fileTransferStarted;
    private boolean fileTransferRequested;
    private double scale;
    private long work = 0;

    /**
     * @param monitor
     */
    public TransferMonitor(IProgressMonitor monitor, int direction) {
        this(null, monitor, direction);
    }

    /**
     * @param task
     * @param monitor
     */
    public TransferMonitor(String task, IProgressMonitor monitor, int direction) {
        Assert.isLegal(direction == DOWN || direction == UP);
        this.task = task;
        this.mainProgress = this.fileProgress = Utils.monitorFor(monitor);
        this.direction = direction;
    }

    @Override
    public void end() {
        fileTransferStarted = false;
        fileProgress.done();
        mainProgress.done();
    }

    @Override
    public void endFile(String filename, int status) {
        // print unusual things only as print to console is slow in 3.0
        String consoleMsg = null;
        switch (status) {
        case ACTION_IGNORED:
            consoleMsg = NLS.bind(Messages.TransferMonitor_0, filename);
            break;
        case ACTION_UNRESOLVED:
            consoleMsg = NLS.bind(Messages.TransferMonitor_1, filename);
            break;
        case ACTION_ERROR:
            consoleMsg = NLS.bind(Messages.TransferMonitor_2, filename);
            break;
        }
        if (consoleMsg != null) {
            DMPlugin.getDefault().getConsole().printError(consoleMsg);
        }
    }

    @Override
    public void processed(long workUnits) {
        startFileTransfer();
        fileProgress.worked(convertWorkUnits(workUnits));
    }

    @Override
    public void startFile(String filename) {
        startFileTransfer();

        String msg = direction == UP ? NLS.bind(Messages.TransferMonitor_3, filename) : NLS.bind(Messages.TransferMonitor_5,
                filename);

        fileProgress.subTask(msg);
        // do not print to console as this slow in 3.0
    }

    @Override
    public void start(long totalWorkUnits) {
        if (!mainProgressStarted) {
            mainProgress.beginTask(task, total);
            mainProgressStarted = true;
        }

        // PLCD changes total work units so progress monitor will have initialized within next call of startTime or processed
        // methods
        work = totalWorkUnits;
        fileTransferRequested = true;
    }

    @Override
    public boolean isCancelled() {
        return mainProgress.isCanceled();
    }

    protected void startFileTransfer() {
        if (fileTransferRequested) {
            fileProgress = Utils.subMonitorFor(mainProgress, Math.abs(total - worked));
            fileProgress.beginTask(task, convertWorkUnits(work));
            fileTransferStarted = true;
            fileTransferRequested = false;
        }
    }

    // converts long to int as this is what we need to feed to IProgressMonitor,
    // there will be some loss of precision if received total work units does not
    // fit into an int.
    private int convertWorkUnits(long workUnits) {
    	if (!fileTransferStarted) {
            if (workUnits > MAX_VALUE) {
                scale = ((double) workUnits) / ((double) MAX_VALUE);
            } else {
                scale = 1.0;
            }
        }
        return (int) (((double) workUnits) / scale);
    }

}

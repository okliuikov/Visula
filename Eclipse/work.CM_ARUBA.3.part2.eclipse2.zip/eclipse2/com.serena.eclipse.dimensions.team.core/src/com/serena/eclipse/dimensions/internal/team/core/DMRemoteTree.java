/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.ResourceVariantByteStore;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public abstract class DMRemoteTree extends DMResourceVariantTree {

    static final int[] DEFAULT_EXPAND_ATTRS = new int[] { SystemAttributes.IS_EXTRACTED, SystemAttributes.CREATION_USER };

    /**
     * @param store
     * @param subscriber
     */
    public DMRemoteTree(ResourceVariantByteStore store, Subscriber subscriber) {
        super(store, subscriber);
    }

    @Override
    public IResource[] refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
        List<IResource> changedResources = new ArrayList<IResource>();
        List<IResource> containers = new ArrayList<IResource>();
        Map<IDMProject, Map<IPath, IFile>> projectToFiles = new HashMap<IDMProject, Map<IPath, IFile>>();

        try {
            // separate file containers and files
            for (int i = 0; i < resources.length; i++) {
                IResource resource = TeamUtils.getResource(resources[i]);
                IDMProject project = getDMProject(resource);
                IPath remotePath = project.getRemotePathForLocalResource(resource);
                if (remotePath != null) {
                    if (resource instanceof IFile) {
                        Map<IPath, IFile> paths = projectToFiles.get(project);

                        if (paths == null) {
                            paths = new HashMap<IPath, IFile>();
                            projectToFiles.put(project, paths);
                        }
                        paths.put(remotePath, (IFile) resource);
                    } else {
                        containers.add(resource);
                    }
                }
            }
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        // refresh containers
        monitor.beginTask(null, 100 * containers.size() + 100);

        try {
            for (int i = 0; i < containers.size(); i++) {
                IResource container = containers.get(i);
                IResource[] refreshedResources = refresh(container, depth, Utils.subMonitorFor(monitor, 100));
                changedResources.addAll(Arrays.asList(refreshedResources));
            }

            // refresh files
            List<IResource> changed = customBulkFileRefresh(projectToFiles, Utils.subMonitorFor(monitor, 100));
            changedResources.addAll(changed);
        } finally {
            monitor.done();
        }

        return changedResources.toArray(new IResource[changedResources.size()]);
    }

    /**
     * Refreshes all local files
     *
     * @param projectsToFiles
     *            map between projects and associated project files. Project
     *            files is a map: remote path for local file -> local file
     * @param monitor
     * @return list of
     * @throws TeamException
     */
    protected List<IResource> customBulkFileRefresh(Map<IDMProject, Map<IPath, IFile>> projectToFiles, IProgressMonitor monitor)
            throws TeamException {
        List<IResource> changedResources = new ArrayList<IResource>();
        monitor.beginTask(null, 100);
        try {
            monitor.setTaskName(Messages.TreeSynchronizationCacheRefreshOperation_files);

            Map<IFile, IDMRemoteFile> localToRemote = fetchFilesVariants(projectToFiles, Utils.subMonitorFor(monitor, 90));

            if (localToRemote == null) {
                return changedResources;
            }

            // update the known remote handles
            IProgressMonitor sub = Utils.subMonitorFor(monitor, 10);
            try {
                sub.beginTask(null, IProgressMonitor.UNKNOWN);

                for (Map.Entry<IFile, IDMRemoteFile> result : localToRemote.entrySet()) {
                    changedResources.addAll(Arrays.asList(collectChanges(result.getKey(), result.getValue(), IResource.DEPTH_ONE,
                            Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN))));
                }
            } finally {
                sub.done();
            }
        } finally {
            monitor.done();
        }
        return changedResources;
    }

    /**
     * Queries remote variants per project for local resources
     *
     * @param projectsToFiles
     *            map between projects and associated project files. Project
     *            file is a map: remote path for local file -> local file
     * @param monitor
     * @return
     * @throws TeamException
     */
    protected Map<IFile, IDMRemoteFile> fetchFilesVariants(Map<IDMProject, Map<IPath, IFile>> projectsToFiles,
            IProgressMonitor monitor) throws TeamException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        monitor.subTask(Messages.RemoteTree_gettingLatest);

        if (projectsToFiles == null) {
            return null;
        }

        Map<IFile, IDMRemoteFile> fileToVariant = new HashMap<IFile, IDMRemoteFile>(projectsToFiles.size());

        try {
            // fetch files per project
            for (Map.Entry<IDMProject, Map<IPath, IFile>> projectToFile : projectsToFiles.entrySet()) {
                IDMProject project = projectToFile.getKey();
                Map<IPath, IFile> files = projectToFile.getValue();

                // perform fetch as a bulk operation
                Map<IPath, ItemRevision> revisions = project.fetchFiles(files.keySet(), DMRemoteFile.RESOURCE_VARIANT_ATTRS_FILE,
                        true, Utils.subMonitorFor(monitor, 850));

                // perform revision expansion as a bulk operation
                Map<String, List<ItemRevision>> expanded = getExpandedRevisions(project, revisions.values(),
                        Utils.subMonitorFor(monitor, 150));

                // convert query result to output
                for (Map.Entry<IPath, ItemRevision> pathToItem : revisions.entrySet()) {
                    ItemRevision revision = pathToItem.getValue();
                    IPath remotePath = pathToItem.getKey();

                    if (revision != null) {
                        DMRemoteFile variant = createRemoteFile(null, remotePath, project, revision,
                                getExpandedList(expanded, revision));
                        fileToVariant.put(files.get(remotePath), variant);
                    } else {
                        // assume was deleted
                        fileToVariant.put(files.get(remotePath), null);
                    }
                }
            }
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        } finally {
            monitor.done();
        }
        return fileToVariant;
    }

    protected DMRemoteFile createRemoteFile(DMRemoteFolder parent, IPath filePath, IDMProject project, ItemRevision itemRevision,
            List<ItemRevision> expandedRevisions) {
        DMRemoteFile remoteFile = new DMRemoteFile(parent, filePath, project, this, itemRevision);
        if (expandedRevisions != null) {
            String currentUser = project.getConnection().getUsername();
            boolean extractedAny = false;
            boolean extractedOther = false;
            int extractCount = 0;
            for (Iterator<ItemRevision> iter = expandedRevisions.iterator(); iter.hasNext();) {
                ItemRevision otherRev = iter.next();
                boolean extracted = Boolean.TRUE.equals(otherRev.getAttribute(SystemAttributes.IS_EXTRACTED));
                extractedAny |= extracted;
                if (extracted) {
                    String creator = (String) otherRev.getAttribute(SystemAttributes.CREATION_USER);
                    extractedOther |= !currentUser.equals(creator);
                    extractCount++;
                }
                if (extractedAny && extractedOther && extractCount > 1) {
                    break; // can stop now
                }
            }
            remoteFile.setAnyExtracted(extractedAny);
            remoteFile.setExtractedOther(extractedAny);
            remoteFile.setMultiExtracted(extractCount > 1);
            boolean allowParallelCheckout = true;
            remoteFile.setExtractedExclusive(!allowParallelCheckout && extractedAny);
        }
        return remoteFile;
    }

    protected DMRemoteFolder createRemoteFolder(DMRemoteFolder parent, IPath folderPath, IDMProject project,
            RepositoryFolder repositoryFolder) {
        DMRemoteFolder remoteFolder = new DMRemoteFolder(parent, folderPath, project, this, repositoryFolder);
        return remoteFolder;
    }

    @Override
    public List<IDMRemoteResource> fetchFolderMembers(IDMRemoteFolder folder, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);

        try {
            RepositoryFolder repositoryFolder = ((DMRemoteFolder) folder).getRepositoryFolder();
            if (repositoryFolder == null) {
                repositoryFolder = folder.getProject().getRemoteFolder((IContainer) folder.getLocalResource(),
                        Utils.subMonitorFor(monitor, 100));
                if (repositoryFolder == null) {
                    return Collections.emptyList();
                }
                ((DMRemoteFolder) folder).setRepositoryFolder(repositoryFolder);
            } else {
                monitor.worked(100);
            }

            List<DimensionsArObject> resources = folder.getProject().fetchMembers(repositoryFolder,
                    IResource.FILE | IResource.FOLDER, DMRemoteFile.RESOURCE_VARIANT_ATTRS_FILE, false,
                    Utils.subMonitorFor(monitor, 700));

            IDMProject project = folder.getProject();

            Map<String, List<ItemRevision>> expanded = getExpandedRevisions(project, resources,
                    Utils.subMonitorFor(monitor, 200));

            List<IDMRemoteResource> result = new ArrayList<IDMRemoteResource>(resources.size());
            for (Iterator<DimensionsArObject> resourceIter = resources.iterator(); resourceIter.hasNext();) {
                DimensionsArObject resource = resourceIter.next();

                if (resource instanceof RepositoryFolder) {
                    RepositoryFolder memberFolder = (RepositoryFolder) resource;
                    IPath folderPath = TeamUtils.getFolderPath(memberFolder);
                    result.add(createRemoteFolder((DMRemoteFolder) folder, folderPath, project, memberFolder));
                } else if (resource instanceof ItemRevision) {
                    ItemRevision memberFile = (ItemRevision) resource;
                    IPath filePath = DMProject.getFilePath(memberFile);
                    if (filePath != null) {
                        result.add(createRemoteFile((DMRemoteFolder) folder, filePath, project, memberFile,
                                getExpandedList(expanded, memberFile)));
                    }
                }
            }
            return result;
        } finally {
            monitor.done();
        }
    }

    @Override
    protected IResourceVariant fetchVariant(IResource resource, int depth, IProgressMonitor monitor) throws TeamException {
        try {
            resource = TeamUtils.getResource(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        monitor.subTask(Messages.RemoteTree_gettingLatest);

        if (resource == null) {
            return null;
        }

        try {
            IDMProject project = getDMProject(resource);
            if (project == null) {
                return null;
            }
            IPath remotePath = project.getRemotePathForLocalResource(resource);
            if (remotePath == null) {
                return null;
            }

            // applicable for containers only
            if (resource.getType() == IResource.FILE) {
                return null;
            }

            IContainer localRoot = (IContainer) resource;
            RepositoryFolder remoteRootFolder = project.getRemoteFolder(localRoot, Utils.subMonitorFor(monitor, 200));
            if (remoteRootFolder == null) {
                return null;
            }
            DMRemoteFolder remoteRoot = createRemoteFolder(null, remotePath, project, remoteRootFolder);
            if (depth == IResource.DEPTH_ZERO) {
                return remoteRoot;
            }

            List<DimensionsArObject> resources = project.fetchMembers(remoteRootFolder, IResource.FILE | IResource.FOLDER,
                    DMRemoteFile.RESOURCE_VARIANT_ATTRS_FILE, depth == IResource.DEPTH_INFINITE,
                    Utils.subMonitorFor(monitor, 650));
            resources.add(remoteRootFolder);

            Map<String, List<ItemRevision>> expandRevisions = getExpandedRevisions(project, resources,
                    Utils.subMonitorFor(monitor, 150));

            return buildTree(resources, project, expandRevisions, depth == IResource.DEPTH_INFINITE);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        } finally {
            monitor.done();
        }
    }

    private IResourceVariant buildTree(List<DimensionsArObject> remoteResources, IDMProject project,
            Map<String, List<ItemRevision>> expandedRevisions, boolean recursive) {
        // sort folders by their containment
        Map<IPath, RepositoryFolder> folders = new TreeMap<IPath, RepositoryFolder>(new ContainmentComparator());
        List<ItemRevision> files = new ArrayList<ItemRevision>();
        for (Iterator<DimensionsArObject> resourceIter = remoteResources.iterator(); resourceIter.hasNext();) {
            DimensionsArObject resource = resourceIter.next();
            if (resource instanceof RepositoryFolder) {
                RepositoryFolder repositoryFolder = (RepositoryFolder) resource;
                IPath folderPath = TeamUtils.getFolderPath(repositoryFolder);
                folders.put(folderPath, repositoryFolder);
            } else if (resource instanceof ItemRevision) {
                files.add((ItemRevision) resource);
            }
        }

        Map<IPath, DMRemoteFolder> parents = new HashMap<IPath, DMRemoteFolder>(folders.size()); // parent lookup

        // folders
        DMRemoteFolder root = null;
        for (Iterator<Entry<IPath, RepositoryFolder>> folderIter = folders.entrySet().iterator(); folderIter.hasNext();) {
            Entry<IPath, RepositoryFolder> entry = folderIter.next();
            IPath folderPath = entry.getKey();
            RepositoryFolder aFolder = entry.getValue();

            DMRemoteFolder remoteFolder = null;
            if (root == null) {
                root = createRemoteFolder(null, folderPath, project, aFolder);
                remoteFolder = root;
            } else {
                DMRemoteFolder parent = parents.get(folderPath.removeLastSegments(1));
                assert parent != null;
                if (parent != null) {
                    remoteFolder = createRemoteFolder(parent, folderPath, project, aFolder);
                }
            }
            if (remoteFolder != null) {
                if (recursive) { // initialize members on recursive to avoid querying for children on empty folders later
                    remoteFolder.initMembers();
                }
                parents.put(folderPath, remoteFolder);
            }
        }

        // files
        for (Iterator<ItemRevision> fileIter = files.iterator(); fileIter.hasNext();) {
            ItemRevision aFile = fileIter.next();
            IPath filePath = DMProject.getFilePath(aFile);
            if (filePath != null) { // assume was deleted if could not get full path after got the initial handle
                DMRemoteFolder parent = parents.get(filePath.removeLastSegments(1));
                assert parent != null;
                if (parent != null) {
                    createRemoteFile(parent, filePath, project, aFile, getExpandedList(expandedRevisions, aFile));
                }
            }
        }

        return root;
    }

    private <T extends DimensionsArObject> Map<String, List<ItemRevision>> getExpandedRevisions(IDMProject project,
            Collection<T> revisions, IProgressMonitor monitor) throws DMException {
        Map<String, List<ItemRevision>> expanded;
        if (!project.getIsStream()) {
            expanded = expandRevisions(project, revisions, monitor);
        } else {
            expanded = Collections.emptyMap();
        }
        return expanded;
    }

    private Map<String, List<ItemRevision>> expandRevisions(IDMProject project, Collection<?> resources, IProgressMonitor monitor)
            throws DMException {
        int[] attrs = getAttributesForExpand();
        if (attrs == null || resources.isEmpty()) {
            if (monitor != null) {
                monitor.done();
            }
            return Collections.emptyMap();
        }
        List<ItemRevision> revisions = new ArrayList<ItemRevision>();
        for (Iterator<?> iter = resources.iterator(); iter.hasNext();) {
            Object resource = iter.next();
            if (resource instanceof ItemRevision) {
                revisions.add((ItemRevision) resource);
            }
        }
        return project.expandItemRevisions(revisions, attrs, monitor);
    }

    private List<ItemRevision> getExpandedList(Map<String, List<ItemRevision>> expandedMap, ItemRevision revision) {
        if (expandedMap == null) {
            return null;
        }
        String itemSpec = (String) revision.getAttribute(SystemAttributes.OBJECT_SPEC);
        assert itemSpec != null;
        return expandedMap.get(itemSpec);
    }

    /**
     * @return attributes to be queried on expanded item revisions or <code>null</code> if this tree needs no revision "expansion"
     */
    protected int[] getAttributesForExpand() {
        return null;
    }

}

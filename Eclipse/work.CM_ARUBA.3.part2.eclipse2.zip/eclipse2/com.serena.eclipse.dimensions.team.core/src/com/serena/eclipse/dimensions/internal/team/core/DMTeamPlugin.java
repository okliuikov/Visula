package com.serena.eclipse.dimensions.internal.team.core;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.resources.WorkspaceJob;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.osgi.framework.BundleContext;

import com.serena.eclipse.dimensions.core.DMException;

/**
 * Team plugin for dimensions.
 */
public class DMTeamPlugin extends Plugin {
    private static final String USE_CONTENT_ENCODING = "use_content_encoding"; //$NON-NLS-1$
    private static final String FETCH_AREA = ".projects"; //$NON-NLS-1$

    public static final String ID = "com.serena.eclipse.dimensions.team.core"; //$NON-NLS-1$
    /** file modification validator extension point name */
    public static final String MODIFICATION_VALIDATOR_EP = "fileModificationValidator"; //$NON-NLS-1$
    public static final String IMPORT_HANDLER_EP = "projectSetImportHandler"; //$NON-NLS-1$
    public static final String CONNECTION_PROVIDER_EP = "connectionProvider"; //$NON-NLS-1$
    public static final String MAVEN_ADAVANCED_SHARING_SUPPORT_EP = "mavenProjectStructureHelper"; //$NON-NLS-1$
    // The shared instance.
    private static DMTeamPlugin plugin;
    // Resource bundle.
    private ResourceBundle resourceBundle;

    private DMWorkspace workspace;
    private Boolean debugItems = null; // set up for lazy initialization
    private boolean cleanTimestamps;
    private boolean allowUpdateAutoMerge;
    private boolean autoShare;
    private Boolean debugMetadata = null;
    private Boolean debugResources = null;
    private Boolean debugfolderStatus = null;
    private Boolean debugbyteStore = null;
    private Boolean debugsyncState = null;
    private Boolean debugListeners = null;
    private Boolean debugMoveDelete = null;
    private Boolean debugUpdateMerge = null;

    /**
     * @return dmexception for core exception
     */
    public static DMException asDMException(CoreException e) {
        return DMException.asDMException(e, ID);
    }

    public static IDMWorkspace getWorkspace() {
        return plugin.workspace;
    }

    public static void log(IStatus status) {
        if (plugin != null) {
            plugin.getLog().log(status);
        }
    }

    /**
     * The constructor.
     */
    public DMTeamPlugin() {
        super();
        plugin = this;
        try {
            resourceBundle = ResourceBundle.getBundle("com.serena.eclipse.dimensions.team.core.DMTeamPluginResources");
        } catch (MissingResourceException x) {
            resourceBundle = null;
        }
    }

    /**
     * This method is called upon plug-in activation
     */
    @Override
    public void start(BundleContext context) throws Exception {
        super.start(context);
        workspace = new DMWorkspace();
        workspace.initialize();

        final String IGNORE_DM_MERGE_FILES = Messages.dmStartupProcessing;
        // run as background job
        WorkspaceJob ignoreDmcli = new WorkspaceJob(IGNORE_DM_MERGE_FILES) {
            @Override
            public IStatus runInWorkspace(IProgressMonitor monitor) throws CoreException {
                monitor.beginTask(IGNORE_DM_MERGE_FILES, 100);
                DMRepositoryProvider.ignoreFilesLeftByDMCommandLineClient();
                monitor.worked(100);
                monitor.done();
                return new Status(IStatus.OK, ID, IStatus.OK, IGNORE_DM_MERGE_FILES, null);
            }
        };
        ISchedulingRule ignoreRule = ResourcesPlugin.getWorkspace().getRoot();
        ignoreDmcli.setRule(ignoreRule);
        ignoreDmcli.schedule();
    }

    public boolean isDebuggingItemCommands() {
        if (debugItems == null) {
            debugItems = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/items"));
        }
        return debugItems.booleanValue();
    }

    public boolean isDebuggingMetadata() {
        if (debugMetadata == null) {
            debugMetadata = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/metadata"));
        }
        return debugMetadata.booleanValue();
    }

    public boolean isDebuggingResources() {
        if (debugResources == null) {
            debugResources = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/resources"));
        }
        return debugResources.booleanValue();
    }

    public boolean isDebuggingFolderStatus() {
        if (debugfolderStatus == null) {
            debugfolderStatus = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/folderStatus"));
        }
        return debugfolderStatus.booleanValue();
    }

    public boolean isDebuggingByteStore() {
        if (debugbyteStore == null) {
            debugbyteStore = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/byteStore"));
        }
        return debugbyteStore.booleanValue();
    }

    public boolean isDebuggingSyncState() {
        if (debugsyncState == null) {
            debugsyncState = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/syncState"));
        }
        return debugsyncState.booleanValue();
    }

    public boolean isDebuggingListeners() {
        if (debugListeners == null) {
            debugListeners = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/listeners"));
        }
        return debugListeners.booleanValue();
    }

    public boolean isDebuggingMoveDelete() {
        if (debugMoveDelete == null) {
            debugMoveDelete = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/moveDelete"));
        }
        return debugMoveDelete.booleanValue();
    }

    public boolean isDebuggingUpdateMerge() {
        if (debugUpdateMerge == null) {
            debugUpdateMerge = Boolean.valueOf(Platform.getDebugOption(ID + "/debug/updateMerge"));
        }
        return debugUpdateMerge.booleanValue();
    }

    /**
     * This method is called when the plug-in is stopped
     */
    @Override
    public void stop(BundleContext context) throws Exception {
        if (workspace != null) {
            workspace.dispose();
            workspace = null;
        }
        cleanupFetchArea();
        super.stop(context);
    }

    /**
     * Returns the shared instance.
     */
    public static DMTeamPlugin getDefault() {
        return plugin;
    }

    /**
     * Returns the string from the plugin's resource bundle,
     * or 'key' if not found.
     */
    public static String getResourceString(String key) {
        ResourceBundle bundle = DMTeamPlugin.getDefault().getResourceBundle();
        try {
            return (bundle != null) ? bundle.getString(key) : key;
        } catch (MissingResourceException e) {
            return key;
        }
    }

    /**
     * Returns the plugin's resource bundle,
     */
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    public IMavenProjectStructureHelper getMavenProjectStructureHelper() {
        IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(ID, MAVEN_ADAVANCED_SHARING_SUPPORT_EP);

        if (extensionPoint == null) {
            return null;
        }
        IExtension[] extensions = extensionPoint.getExtensions();
        if (extensions.length == 0) {
            return null;
        }
        IExtension firstExtension = extensions[0];
        IConfigurationElement[] configs = firstExtension.getConfigurationElements();
        if (configs.length == 0) {
            log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, "no config elements for advanced maven sharing")); //$NON-NLS-1$
            return null;
        }
        try {
            return (IMavenProjectStructureHelper) configs[0].createExecutableExtension("class"); //$NON-NLS-1$
        } catch (CoreException e) {
            log(e.getStatus());
        }
        return null;
    }

    public IDMFileModificationValidator getPluggedInValidator() {
        IExtension[] extensions = Platform.getExtensionRegistry().getExtensionPoint(ID, MODIFICATION_VALIDATOR_EP).getExtensions();
        if (extensions.length == 0) {
            return null;
        }
        IExtension firstExtension = extensions[0];
        IConfigurationElement[] configs = firstExtension.getConfigurationElements();
        if (configs.length == 0) {
            log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, "no config elements for file modification validator")); //$NON-NLS-1$
            return null;
        }
        try {
            return (IDMFileModificationValidator) configs[0].createExecutableExtension("class"); //$NON-NLS-1$
        } catch (CoreException e) {
            log(e.getStatus());
        }
        return null;
    }

    public IProjectSetImportHandler getPluggedInImportHandler() {
        IExtension[] extensions = Platform.getExtensionRegistry().getExtensionPoint(ID, IMPORT_HANDLER_EP).getExtensions();
        if (extensions.length == 0) {
            return null;
        }
        IExtension firstExtension = extensions[0];
        IConfigurationElement[] configs = firstExtension.getConfigurationElements();
        if (configs.length == 0) {
            log(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, "no config elements for file import handler")); //$NON-NLS-1$
            return null;
        }
        try {
            return (IProjectSetImportHandler) configs[0].createExecutableExtension("class"); //$NON-NLS-1$
        } catch (CoreException e) {
            log(e.getStatus());
        }
        return null;
    }

    private IPath getFetchArea() {
        return getStateLocation().append(FETCH_AREA);
    }

    private void cleanupFetchArea() {
        TeamUtils.deltree(getFetchArea().toFile());
    }

    /*
     * temp location within plugin state area
     */
    IPath getFetchLocationFor(IFile ifile) {
        return getFetchArea().append(ifile.getFullPath());
    }

    public boolean isUsePlatformLineend() {
        return true;
    }

    /**
     * @return <code>true</code> if modification timestamps should
     *         be cleaned on subscriber refresh, returns <code>false</code> otherwise
     */
    public boolean isCleanTimetsaps() {
        return cleanTimestamps;
    }

    /**
     * Sets whether modification timestamps should be cleaned on subscriber refresh
     *
     * @param b
     */
    public void setCleanTimestamps(boolean b) {
        this.cleanTimestamps = b;
    }

    public boolean isAllowUpdateAutoMerge() {
        return allowUpdateAutoMerge;
    }

    public void setAllowUpdateAutoMerge(boolean allowUpdateAutoMerge) {
        this.allowUpdateAutoMerge = allowUpdateAutoMerge;
    }

    /**
     * Returns the charset for the specified resource. Returns <code>null</code> if content encoding support is disabled, resource
     * is a container, does not exist or is not local, or if content encoding cannot be determined.
     *
     * @param resource
     *            resource for which return its charset
     * @return the charset
     * @see IFile#getCharset()
     */
    public String getCharset(IResource resource) {
        if (contentEncodingSupportEnabled() && resource.getType() == IResource.FILE && resource.exists()) {
            IFile file = (IFile) resource;
            try {
                return file.getCharset();
            } catch (CoreException e) {
                log(e.getStatus());
            }
        }
        return null;
    }

    /**
     * Content encoding setting is controlled by the <code></code>
     *
     * @return <code>true</code> if
     */
    public boolean contentEncodingSupportEnabled() {
        try {
            return Boolean.valueOf(Platform.getResourceBundle(getBundle()).getString(USE_CONTENT_ENCODING)).booleanValue();
        } catch (MissingResourceException e) {
        }
        return false;
    }

    public void setAutoshareOnImport(boolean auto) {
        autoShare = auto;

    }

    public boolean isAutoshareOnImport() {
        return autoShare;
    }

}

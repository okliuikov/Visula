/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core.meta;

import java.util.HashSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataException;
import com.serena.dmfile.metadb.MetadataHolder;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.dmfile.metadb.ProviderMetadataIterator;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.MetadataProviderFactory;

/**
 * Metadata entry for a file in the workspace, implements logic for
 * translating resource type into file or directory metadata.
 *
 * @author V.Grishchenko
 */
public class WorkspaceMetadataEntry { 
    private IResource resource;
    private IPath path;
    private static boolean debugMd = DMTeamPlugin.getDefault().isDebuggingMetadata();

    /**
     * @return metadata container whose parent is the supplied directory
     */
    public static IContainer getMetadataContainer(IContainer directory) {
        MetadataProvider mdProvider = MetadataProviderFactory.providerFor(directory);
        String mdDirname = null;
        try {
            mdDirname = mdProvider.metadataDirname();
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
        return directory.getFolder(new Path(mdDirname));
    }

    /**
     * @return metadata container whose parent is the supplied directory
     */
    public static IPath getMetadataContainer(IPath directory) {
        MetadataProvider mdProvider = MetadataProviderFactory.providerFor(directory);
        String mdDirname = null;
        try {
            mdDirname = mdProvider.metadataDirname();
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
        return directory.append(new Path(mdDirname));
    }

    public static IContainer getMetadataContainer(IContainer directory, MetadataProvider provider) {
        MetadataProvider mdSession = null;
        if (provider == null) {
            mdSession = MetadataProviderFactory.providerFor(directory);
        } else {
            mdSession = provider;
        }
        try {
            return directory.getFolder(new Path(mdSession.metadataDirname()));
        } finally {
            if (provider == null && mdSession != null) {
                mdSession.close();
            }
        }
    }

    /*
     * <p>Obtains container member handles corresponding to the existing
     * metadata entries. Can optionally include actual local files found
     * under the specified container.
     * <p><b>Note:</b> The resources returned may not necessarily
     * exist in the filesystem and even if they do the actual metadata
     * may be of different gender (file vs. folder)
     *
     * @return container members as recorded in the metadata
     */
    static IResource[] getMembers(IContainer container, boolean includeLocal) throws CoreException {
        MetadataProvider mdProvider = MetadataProviderFactory.providerFor(container);
        try {
            IContainer metaContainer = getMetadataContainer(container, mdProvider);
            if (!metaContainer.exists()) {
                return new IResource[0];
            }
            HashSet<IResource> result = new HashSet<IResource>();

            ProviderMetadataIterator itemMDProviderIter = mdProvider.getIterator(MetadataTypes.MT_ITEM,
                    container.getLocation().toOSString());
            MetadataHolder mdHolder = null;
            IResource resource = null;
            while (itemMDProviderIter != null && itemMDProviderIter.hasNext()) {
                mdHolder = itemMDProviderIter.next();
                resource = container.getFile(new Path(mdHolder.getBaseName()));
                result.add(resource);
            }
            ProviderMetadataIterator dirMDProviderIter = mdProvider.getIterator(MetadataTypes.MT_DIR,
                    container.getLocation().toOSString());
            while (dirMDProviderIter != null && dirMDProviderIter.hasNext()) {
                mdHolder = dirMDProviderIter.next();
                resource = container.getFolder(new Path(mdHolder.getBaseName()));
                result.add(resource);
            }

            if (includeLocal) {
                IResource[] localMembers = container.members();
                for (int i = 0; i < localMembers.length; i++) {
                    if (!mdProvider.metadataDirname().equals(localMembers[i].getName())) {
                        result.add(localMembers[i]);
                    }
                }
            }
            if (debugMd) {
                System.out.println("WME getMembers inc local " + includeLocal);
                for (IResource r : result) {
                    System.out.println("    " + r.toString());
                }
            }
            return result.toArray(new IResource[result.size()]);
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    WorkspaceMetadataEntry(IResource resource) {
        if (resource == null) {
            throw new IllegalArgumentException("null resource");
        }
        this.resource = resource;
    }

    WorkspaceMetadataEntry(IPath path) {
        if (path == null) {
            throw new IllegalArgumentException("null path");
        }
        this.path = path;
    }

    public boolean deleteAll(MetadataProvider mdParentProvider) throws CoreException {
        String pathName = null;
        if (resource != null) {
            pathName = resource.getLocation().toOSString();
        } else {
            pathName = path.toOSString();
        }

        MetadataProvider mdProvider = null;
        if (mdParentProvider != null) {
            mdProvider = mdParentProvider;
        } else {
            mdProvider = MetadataProviderFactory.providerFor(pathName);
        }
        try {
            try {
                if (mdProvider.metadataExists(MetadataTypes.MT_ITEM, pathName)) {
                    mdProvider.removeMetadata(MetadataTypes.MT_ITEM, pathName);
                }
                if (mdProvider.metadataExists(MetadataTypes.MT_DIR, pathName)) {
                    mdProvider.removeMetadata(MetadataTypes.MT_DIR, pathName);
                }
            } catch (MetadataException e) {
                throw new CoreException(DMTeamStatus.createErrorStatus(0, "Failed to delete metadata for: " + pathName, e));
            }
            return !mdProvider.metadataExists(MetadataTypes.MT_ITEM, pathName)
                    && !mdProvider.metadataExists(MetadataTypes.MT_DIR, pathName);
        } finally {
            if (mdParentProvider == null && mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    /**
     * @param conflicting
     *            <code>true</code> to entry that is opposite
     *            to the resource type, i.e. if the underlying resoruce is a file
     *            this will delete a directory metadata file and vice versa
     * @param mdProvider
     *            outer metadata provider
     * @return
     * @throws CoreException
     */
    public boolean delete(boolean conflicting, MetadataProvider mdParentProvider) throws CoreException {
        boolean deleteDirEntry = false;
        String pathName = null;
        if (resource != null) {
            pathName = resource.getLocation().toOSString();
            deleteDirEntry = (!conflicting && resource.getType() != IResource.FILE)
                    || (conflicting && resource.getType() == IResource.FILE);
        } else {
            pathName = path.toOSString();
            deleteDirEntry = (!conflicting && path.toFile().isDirectory()) || (conflicting && !path.toFile().isDirectory());
        }

        MetadataProvider mdProvider = null;
        if (mdParentProvider != null) {
            mdProvider = mdParentProvider;
        } else {
            mdProvider = MetadataProviderFactory.providerFor(pathName);
        }
        try {
            try {
                if (mdProvider.metadataExists((deleteDirEntry ? MetadataTypes.MT_DIR : MetadataTypes.MT_ITEM), pathName)) {
                    mdProvider.removeMetadata((deleteDirEntry ? MetadataTypes.MT_DIR : MetadataTypes.MT_ITEM), pathName);
                }
            } catch (MetadataException e) {
                throw new CoreException(DMTeamStatus.createErrorStatus(0, "Failed to delete metadata for: " + pathName, e));
            }
            return mdProvider.metadataExists((deleteDirEntry ? MetadataTypes.MT_DIR : MetadataTypes.MT_ITEM), pathName);
        } finally {
            if (mdParentProvider == null && mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    public boolean exists() {
        MetadataProvider mdProvider = null;
        String pathName = null;
        try {
            if (resource != null) {
                pathName = resource.getLocation().toOSString();
                mdProvider = MetadataProviderFactory.providerFor(resource);
            } else {
                pathName = path.toOSString();
                mdProvider = MetadataProviderFactory.providerFor(path);
            }
            return mdProvider.metadataExists(MetadataTypes.MT_DIR, pathName)
                    || mdProvider.metadataExists(MetadataTypes.MT_ITEM, pathName);
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    public IResource getResource() {
        return resource;
    }

    public ItemMetadata getFileRecord() throws CoreException {
        return readFileRecord();
    }

    public ItemMetadata readFileRecord() throws CoreException {
        if (debugMd) {
            System.out.println(
                    "WME read file metadata " + ((resource != null) ? resource.getFullPath().toString() : path.toOSString()));
        }
        MetadataProvider mdProvider = null;
        ItemMetadata metadata = null;
        try {
            if (resource != null) {
                mdProvider = MetadataProviderFactory.providerFor(resource);
                metadata = mdProvider.getItemMetadata(resource.getLocation().toOSString());
            } else {
                mdProvider = MetadataProviderFactory.providerFor(path);
                metadata = mdProvider.getItemMetadata(path.toOSString());
            }
            return metadata;
        } catch (MetadataException e) {
            throw new CoreException(DMTeamStatus.createErrorStatus(0,
                    "Failed to read metadata for: " + ((resource != null) ? resource.getFullPath().toString() : path.toOSString()),
                    e));
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    public DirectoryMetadata getDirRecord() throws CoreException {
        return readDirRecord();
    }

    public DirectoryMetadata readDirRecord() throws CoreException {
        if (debugMd) {
            System.out.println(
                    "WME read dir metadata " + ((resource != null) ? resource.getFullPath().toString() : path.toOSString()));
        }
        MetadataProvider mdProvider = null;
        DirectoryMetadata metadata = null;
        try {
            if (resource != null) {
                mdProvider = MetadataProviderFactory.providerFor(resource);
                metadata = mdProvider.getDirectoryMetadata(resource.getLocation().toOSString());
            } else {
                mdProvider = MetadataProviderFactory.providerFor(path);
                metadata = mdProvider.getDirectoryMetadata(path.toOSString());
            }
            return metadata;
        } catch (MetadataException e) {
            throw new CoreException(DMTeamStatus.createErrorStatus(0,
                    "Failed to read metadata for: " + ((resource != null) ? resource.getFullPath().toString() : path.toOSString()),
                    e));
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    void writeRecord(BaseMetadata record, MetadataProvider mdParentProvider) throws CoreException {
        String pathName = null;
        if (resource != null) {
            pathName = resource.getLocation().toOSString();
        } else {
            pathName = path.toOSString();
        }
        if (debugMd) {
            System.out.println("WME writeRecord " + pathName);
        }

        MetadataProvider mdProvider = null;
        if (mdParentProvider != null) {
            mdProvider = mdParentProvider;
        } else {
            mdProvider = MetadataProviderFactory.providerFor(pathName);
        }
        try {
            if (resource != null) {
                mdProvider.write(pathName, record);

                IContainer metadataContainer = getMetadataContainer(resource.getParent());
                if (!metadataContainer.exists()) {
                    metadataContainer.refreshLocal(IResource.DEPTH_INFINITE, null); // try to sync up with filesystem
                }
                if (!metadataContainer.isTeamPrivateMember()) {
                    metadataContainer.setTeamPrivateMember(true);
                }
                ResourceAttributes resAttributes = metadataContainer.getResourceAttributes();
                if (resAttributes != null) {
                    resAttributes.setHidden(true);
                    metadataContainer.setResourceAttributes(resAttributes);
                }
                mdProvider.metadataFilename(MetadataProvider.typeFromMetadata(record), pathName);

            } else {
                mdProvider.write(pathName, record);
            }
        } catch (MetadataException e) {
            throw new CoreException(DMTeamStatus.createErrorStatus(0,
                    "Failed to write metadata for: " + ((resource != null) ? resource.getFullPath().toString() : path.toOSString()),
                    e));
        } finally {
            if (mdParentProvider == null && mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    void createDirectoryMetadata(BaseMetadata record, MetadataProvider mdParentProvider) throws CoreException {
        String pathName = null;
        if (resource != null) {
            pathName = resource.getLocation().toOSString();
        } else {
            pathName = path.toOSString();
        }
        if (debugMd) {
            System.out.println("WME create dir meta" + pathName);
        }

        MetadataProvider mdProvider = null;
        if (mdParentProvider != null) {
            mdProvider = mdParentProvider;
        } else {
            mdProvider = MetadataProviderFactory.providerFor(pathName);
        }
        try {
            if (resource != null) {
                mdProvider.write(pathName, record);

                IContainer metadataContainer = getMetadataContainer(resource.getParent());
                if (!metadataContainer.exists()) {
                    metadataContainer.refreshLocal(IResource.DEPTH_INFINITE, null); // try to sync up with filesystem
                }
                if (!metadataContainer.isTeamPrivateMember()) {
                    metadataContainer.setTeamPrivateMember(true);
                }
                ResourceAttributes resAttributes = metadataContainer.getResourceAttributes();
                if (resAttributes != null) {
                    resAttributes.setHidden(true);
                    metadataContainer.setResourceAttributes(resAttributes);
                }
                // TODO KB> MD: get result of operation from listener and cache it - NYI, get md file to set session prop(?)

            } else {
                mdProvider.write(pathName, record);
            }
        } catch (MetadataException e) {
            throw new CoreException(DMTeamStatus.createErrorStatus(0,
                    "Failed to write metadata for: " + ((resource != null) ? resource.getFullPath().toString() : path.toOSString()),
                    e));
        } finally {
            if (mdParentProvider == null) {
                mdProvider.close();
            }
        }
    }

}

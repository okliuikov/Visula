/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2007, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DeliverCommandDetails;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.UploadCommandDetails;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.FileToTransfer;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.xml.OutgoingMergePoint;
import com.serena.dmfile.xml.Workarea;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Encompasses a collection of resources that can be fed to a single upload
 * command.
 *
 * @author V.Grishchenko
 */
class UploadBucket extends UploadCommandDetails {
    private List<WorkspaceResourceRequest> contents = new ArrayList<WorkspaceResourceRequest>();
    private boolean sawCreate;
    private boolean sawCheckin;
    private boolean sawUpdate;

    public UploadBucket(WorkspaceResourceRequest request) {
        internalAdd(request);
    }

    public int size() {
        return contents.size();
    }

    public boolean add(WorkspaceResourceRequest request) {
        internalAdd(request);
        return true;
    }

    private void internalAdd(WorkspaceResourceRequest resourceRequest) {
        contents.add(resourceRequest);
        if (resourceRequest instanceof UploadRequest) {
            UploadRequest request = (UploadRequest) resourceRequest;
            setForceTip(Boolean.valueOf(request.getMode() == UploadRequest.FORCE_TIP));
            setForceCheckin(Boolean.valueOf(request.getMode() == UploadRequest.FORCE_TIP));
            setForceTip(Boolean.valueOf(request.getMode() == UploadRequest.FORCE_TIP));
            setForceCheckin(Boolean.valueOf(request.getMode() == UploadRequest.FORCE_TIP));

            if (getComment() == null) {
                setComment(Utils.getString(request.getParameters().getComment()));
            }

            if (!(sawCreate || sawUpdate) && (request.isCreateItem() || request.isUpdate())) {
                setDescription(request.getParameters().getDescription());
                setRelatedRequests(internalGetRelatedRequests(request));
            }

            if (!sawCreate && request.isCreateItem()) {
                setPart(getOwningPart(request));
            }

            if (!sawCheckin && request.isCheckin()) {
                setCancelUnchanged(Boolean.valueOf(request.isUndoCheckout()));
            }

            if (getAttributeMap() == null || getAttributeMap().isEmpty()) {
                int[] attrs = request.getParameters().getAttributes();
                Map<Integer, Object> amap = attrs == null || attrs.length == 0
                        ? Collections.<Integer, Object>emptyMap() : new HashMap<Integer, Object>(attrs.length);
                for (int i = 0; attrs != null && i < attrs.length; i++) {
                    amap.put(new Integer(attrs[i]), request.getParameters().getAttribute(attrs[i]));
                }
                setAttributeMap(amap);
            }

            sawCreate |= request.isCreateItem();
            sawCheckin |= request.isCheckin();
            sawUpdate |= request.isUpdate();
        } else if (resourceRequest instanceof FolderRequest || resourceRequest instanceof ItemRevisionRequest) {
            WorkspaceResourceRequest request = resourceRequest;
            if (request.isRequestSupported()) {
                setRelatedRequests(request.getChangeRequests());
            }
            if (resourceRequest instanceof IMoveRequest) {
                setComment(Utils.getString(((IMoveRequest) resourceRequest).getComment()));
            }
        }
    }

    private List<String> internalGetRelatedRequests(UploadRequest request) {
        List<String> requests = request.getParameters().getRelatedRequests();
        return requests;
    }

    // ignore part if not explicitly changed by user - will be resolved by upload from rules
    private String getOwningPart(UploadRequest request) {
        if (!request.isCreateItem()) {
            return null;
        }
        CreateItemRequest cir = (CreateItemRequest) request.getParameters();
        if (cir.isPartUpdated()) {
            return cir.getPart();
        }
        return null;
    }

    /**
     * Uploads the contents of this bucket into the specified project
     *
     * @param project
     * @param monitor
     * @return
     * @throws DMException
     */
    public DimensionsResult upload(final WorksetProject project, boolean isSharing, IProgressMonitor monitor) throws DMException {

        // TODO VG on Jul 26, 2007: set params outside?

        setRelativeLocation(project.getRelativeLocation() != null ? project.getRelativeLocation().toOSString() : null);
        setForceBranch(Boolean.FALSE);
        setKeep(Boolean.TRUE);
        setUserDirectory(project.getUserDirectory().toOSString());
        setVerbose(Boolean.TRUE);
        setXmlMode(Boolean.TRUE);
        setXmlExecute(Boolean.TRUE);
        setUploadRuleset(project.getUploadRuleId() + ':' + String.valueOf(project.getIdeProjectUid()));
        setAll(false);

        Workarea workarea = ObjectToTransfer.scanWorkAreaMetadata(project.getUserDirectory().toOSString());
        List<OutgoingMergePoint> mergePoints = ObjectToTransfer.scanMergePointsMetadata(project.getUserDirectory().toOSString());
        setWorkarea(workarea);
        setMergePoints(mergePoints);

        final List<FileToTransfer> filesToUpload = new ArrayList<FileToTransfer>(contents.size());
        for (int i = 0; i < contents.size(); i++) {
            WorkspaceResourceRequest request = contents.get(i);
            String resPath = request.getResource().getLocation().toOSString();
            if (request instanceof DeleteItemRevisionRequest) {
                // check if container folder was moved (renamed)
                // if so, path will be a new renamed folder for deleted item
                IResource parentRes = request.getResource().getParent();
                try {
                    IResource movedToRes = DMTeamPlugin.getWorkspace().getMovedTo(parentRes);
                    if (movedToRes != null) {
                        resPath = movedToRes.getLocation().append(request.getResource().getName()).toOSString();
                    }
                } catch (CoreException e) {
                }
            }

            FileToTransfer fileToUpload = ObjectToTransfer.scanSingleFileEx(resPath);

            if (request.getResource().getType() == IResource.FILE) {
                fileToUpload.setResourceType("file"); //$NON-NLS-1$
                if (request instanceof UploadRequest) {
                    UploadRequest uploadRequest = (UploadRequest) request;
                    IUploadRequestParameters parameters = uploadRequest.getParameters();
                    if (parameters != null) {
                        fileToUpload.setFileEncoding(parameters.getCharset());
                    }
                }
            } else if (request.getResource().getType() == IResource.FOLDER) {
                fileToUpload.setResourceType("folder");
            }
            if (request instanceof DeleteItemRevisionRequest || request instanceof DeleteFolderRequest) {
                // Needed as the metadata scans returns this as an addition if there is no file and no metadata
                fileToUpload.setDiffType(ObjectToTransfer.DELETION);
                fileToUpload.setDeletionType("from-project");
            }

            if (isSharing && request instanceof FolderRequest && request.getResource().getType() == IResource.PROJECT) {
                LinkedList<FileToTransfer> intermediateFolders = new LinkedList<FileToTransfer>();
                IPath aboveProjPath = Path.fromOSString(fileToUpload.getFileName()).removeLastSegments(1);
                while (aboveProjPath.segmentCount() > project.getUserDirectory().segmentCount()) {
                    // from project parent up to work area exclusively
                    FileToTransfer ftuClone = new FileToTransfer(fileToUpload);
                    ftuClone.setFileName(aboveProjPath.toOSString());
                    intermediateFolders.addFirst(ftuClone); // to have order from upper to lower levels
                    aboveProjPath = aboveProjPath.removeLastSegments(1);
                }
                filesToUpload.addAll(intermediateFolders);
            }
            filesToUpload.add(fileToUpload);

            String foreignProject = getProject(request.getResource());
            if (!getAll() && foreignProject != null && !foreignProject.equals(project.getId())) {
                setAll(true);
            } else if (!getAll() && isBaseline(request.getResource())) {
                setAll(true);
            }
        }

        setFilesToTransfer(filesToUpload);

        final DimensionsResult[] resultHolder = new DimensionsResult[1];
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            Session session = project.getConnection().openSession(Utils.subMonitorFor(monitor, 50));
            TransferMonitor tMonitor = new TransferMonitor(Utils.subMonitorFor(monitor, 950), TransferMonitor.UP);
            setListener(tMonitor);
            setCancelMonitor(tMonitor);
            String msg = filesToUpload.size() == 1
                    ? NLS.bind(Messages.UploadBucket_1, String.valueOf(filesToUpload.size())) : NLS.bind(Messages.UploadBucket_0,
                            String.valueOf(filesToUpload.size()));
            session.run(new APIOperation(msg) {
                @Override
                protected DimensionsResult doRun() throws Exception {
                    if (project.getIsStream()) {
                        resultHolder[0] = project.getWorkset().deliver(getDeliverDetails(UploadBucket.this));
                    } else {
                        resultHolder[0] = project.getWorkset().upload(UploadBucket.this);
                    }

                    // TODO VG on Jul 26, 2007: better to print individual messages to console
                    // directly but this is slow in 3.0, may need to reconsider after 3.0 support
                    // is no longer necessary, for now assemble all messages into a big string and
                    // send it up as final result
                    return assembleResult(resultHolder[0]);
                }
            }, monitor);
            manageMetadataAfterUpload();
            return resultHolder[0];
        } finally {
            monitor.done();
        }
    }

    private void manageMetadataAfterUpload() {
        DMWorkspace workspace = getWorkspace();
        try {
            for (int i = 0; i < contents.size(); i++) {
                WorkspaceResourceRequest request = contents.get(i);
                if (request instanceof MoveItemRequest) {
                    resourceMoved(request.getResource(), true);
                    // If you create a new revision of a file in a Stream in the repository and another user who does not have this
                    // change locally moves the same file to a different location locally and does a sync. Sync view will show the
                    // file in the source location ,from where the file was moved, as conflict and when you do a Mark as Merged
                    // metadata is created in the source location. We need to delete this metadata once deliver is done
                    // or else this file will be shown as an outgoing addition when deliver is completed.
                    WorkspaceMetadataManager.getInstance().deleteMetadata(((MoveItemRequest) request).getSource(),
                            WorkspaceMetadataManager.DELETE);
                } else if (request instanceof MoveFolderRequest) {
                    treeMoved((IFolder) request.getResource());
                } else if (request instanceof DeleteFolderRequest || request instanceof DeleteItemRevisionRequest) {
                    // special case of unmanaging - existing parent folder - should be deleted
                    if (request.getResource().getType() == IResource.FOLDER
                            && TeamUtils.isSpecialCaseOfFolderAndFileDeletion(request.getResource(), false)) {
                        ((IFolder) request.getResource()).refreshLocal(IResource.DEPTH_INFINITE, null);
                        ((IFolder) request.getResource()).delete(false, true, null);
                    }
                    workspace.unmanage(request.getResource(), true, null);
                }
            }
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
    }

    private void resourceMoved(IResource resource, boolean releaseBase) throws CoreException {
        IResource source = getWorkspace().getMovedFrom(resource);
        if (source != null && releaseBase) {
            getWorkspace().releaseBase(source, true, IResource.DEPTH_ZERO, null);
            getWorkspace().refreshRemoteTree(new IResource[] { source }, IResource.DEPTH_ZERO, null);
        }
        MoveRequest.discardMoveState(resource);
    }

    private void treeMoved(IContainer root) throws CoreException {
        IResource source = DMTeamPlugin.getWorkspace().getMovedFrom(root);
        if (source != null) {
            getWorkspace().releaseBase(source, true, IResource.DEPTH_INFINITE, null); // purge base info for the whole tree
            getWorkspace().refreshRemoteTree(new IResource[] { source }, IResource.DEPTH_INFINITE, null);
        }
        root.accept(new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                MoveRequest.discardMoveState(resource);
                return true;
            }
        });
    }

    private DMWorkspace getWorkspace() {
        return (DMWorkspace) DMTeamPlugin.getWorkspace();
    }

    private DeliverCommandDetails getDeliverDetails(UploadBucket uploadDetails) {
        DeliverCommandDetails deliverDetails = new DeliverCommandDetails();
        deliverDetails.setAttributeMap(uploadDetails.getAttributeMap());
        deliverDetails.setCacheFiles(uploadDetails.getCacheFiles());
        deliverDetails.setCancelMonitor(uploadDetails.getCancelMonitor());
        deliverDetails.setCancelUnchanged(uploadDetails.getCancelUnchanged());
        deliverDetails.setCheckConflict(uploadDetails.getCheckConflict());
        deliverDetails.setCodePage(uploadDetails.getCodePage());
        deliverDetails.setComment(uploadDetails.getComment());
        deliverDetails.setContentEncoding(uploadDetails.getContentEncoding());
        deliverDetails.setDescription(uploadDetails.getDescription());
        deliverDetails.setDirectory(uploadDetails.getDirectory());
        deliverDetails.setFileCachesize(uploadDetails.getFileCachesize());
        deliverDetails.setFilesToTransfer(uploadDetails.getFilesToTransfer());
        deliverDetails.setFilter(uploadDetails.getFilter());
        deliverDetails.setIgnoreErrors(uploadDetails.getIgnoreErrors());
        deliverDetails.setListener(uploadDetails.getListener());
        deliverDetails.setLogFile(uploadDetails.getLogFile());
        deliverDetails.setPart(uploadDetails.getPart());
        deliverDetails.setPerms(uploadDetails.getPerms());
        deliverDetails.setRecursive(uploadDetails.getRecursive());
        deliverDetails.setRelatedRequests(uploadDetails.getRelatedRequests());
        deliverDetails.setRelativeLocation(uploadDetails.getRelativeLocation());
        deliverDetails.setUploadRuleset(uploadDetails.getUploadRuleset());
        deliverDetails.setUserDirectory(uploadDetails.getUserDirectory());
        deliverDetails.setVerbose(uploadDetails.getVerbose());
        deliverDetails.setXmlExecute(uploadDetails.getXmlExecute());
        deliverDetails.setXmlMode(uploadDetails.getXmlMode());
        deliverDetails.setAll(uploadDetails.getAll());
        deliverDetails.setWorkarea(uploadDetails.getWorkarea());
        deliverDetails.setMergePoints(uploadDetails.getMergePoints());

        return deliverDetails;
    }

    private DimensionsResult assembleResult(DimensionsResult result) {
        if (result.getResultList() == null) {
            return result;
        }
        StringBuffer buf = new StringBuffer();
        for (Iterator<?> rIter = result.getResultList().iterator(); rIter.hasNext();) {
            FileToTransfer fileResult = (FileToTransfer) rIter.next();
            List<String> commands = fileResult.getCommands();
            if (commands != null) {
                for (Iterator<String> cIter = commands.iterator(); cIter.hasNext();) {
                    String command = cIter.next();
                    if (!Utils.isNullEmpty(command)) {
                        buf.append(command);
                        if (command.charAt(command.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
            List<String> messages = fileResult.getMessages();
            if (messages != null) {
                for (Iterator<String> mIter = messages.iterator(); mIter.hasNext();) {
                    String message = mIter.next();
                    if (!Utils.isNullEmpty(message)) {
                        buf.append(message);
                        if (message.charAt(message.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
        }
        return new DimensionsResult(buf.toString());
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer("[Upload Bucket]\n"); //$NON-NLS-1$
        buf.append(contents.size() + " files:\n"); //$NON-NLS-1$
        for (int i = 0; i < contents.size(); i++) {
            WorkspaceResourceRequest request = contents.get(i);
            IResource file = request.getResource();
            if (i > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(file.getLocation().toOSString());
        }
        buf.append("\nForceTip=").append(getForceTip()).append('\n'); //$NON-NLS-1$
        buf.append("ForceCheckin=").append(getForceCheckin()).append('\n'); //$NON-NLS-1$
        buf.append("Comment=").append(getComment()).append('\n'); //$NON-NLS-1$
        buf.append("Description=").append(getDescription()).append('\n'); //$NON-NLS-1$
        buf.append("Requests=").append(getRelatedRequests()).append('\n'); //$NON-NLS-1$
        buf.append("Part=").append(getPart()).append('\n'); //$NON-NLS-1$
        buf.append("ContentEncoding=").append(getContentEncoding()).append('\n'); //$NON-NLS-1$
        buf.append("CancelUnchanged=").append(getCancelUnchanged()).append('\n'); //$NON-NLS-1$
        buf.append("Attributes:\n"); //$NON-NLS-1$
        @SuppressWarnings("unchecked")
        Map<Integer, Object> attrMap = getAttributeMap();
        int cnt = 0;
        for (Iterator<Entry<Integer, Object>> iter = attrMap.entrySet().iterator(); iter.hasNext();) {
            Entry<Integer, Object> entry = iter.next();
            if (cnt > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(entry.getKey()).append('=').append(entry.getValue());
            cnt++;
        }
        buf.append("\n[/Upload Bucket]"); //$NON-NLS-1$
        return buf.toString();
    }

    /**
     * This method returns the foreign Project name from which the resource came.
     *
     * @param local
     *            - Local resource being checked
     * @return Foreign Project name
     */
    private String getProject(IResource local) {
        try {
            if (!local.exists()) {
                return null;
            }
            if (local.getType() == IResource.PROJECT) {
                return null;
            }
            BaseMetadata metaData = WorkspaceMetadataManager.getInstance().getMetadata(local);
            if (metaData == null) {
                return null;
            }
            if (local.getType() == IResource.FILE) {
                return (((ItemMetadata) metaData).getProject());
            } else if (local.getType() == IResource.FOLDER) {
                return (((DirectoryMetadata) metaData).getProject());
            }
        } catch (CoreException ce) {
            return null;
        }
        return null;
    }

    /**
     * Returns true if this resource came from baseline
     *
     * @param local
     *            - Local resource being checked
     * @return true if it is baseline resource, false otherwise
     */
    private boolean isBaseline(IResource local) {
        try {
            if (!local.exists()) {
                return false;
            }
            if (local.getType() == IResource.PROJECT) {
                return false;
            }
            BaseMetadata metaData = WorkspaceMetadataManager.getInstance().getMetadata(local);
            if (metaData == null) {
                return false;
            }
            if (local.getType() == IResource.FILE) {
                return ((ItemMetadata) metaData).getBaseline() != null;
            } else if (local.getType() == IResource.FOLDER) {
                return ((DirectoryMetadata) metaData).getBaseline() != null;
            }
        } catch (CoreException ce) {
            return false;
        }
        return false;
    }

}
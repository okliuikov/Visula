/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Removes item revision from the workset.
 * @author V.Grishchenko
 */
public class DeleteItemRevisionRequest extends ItemRevisionRequest {
    private boolean deleteAll;
    private boolean deleteLocal;
    private Project project;
    private boolean unmanage = true;

    /**
     * Creates a "delete all" request.
     * @param file
     * @param itemRevision
     * @throws CoreException
     */
    public DeleteItemRevisionRequest(IFile file, ItemType itemType, ItemRevision itemRevision, boolean requestRequired)
            throws CoreException {
        this(file, itemType, itemRevision, requestRequired, true);
    }

    /**
     * @param file
     * @param itemRevision
     * @param requestRequired
     * @param deleteAll
     * @throws CoreException
     */
    public DeleteItemRevisionRequest(IFile file, ItemType itemType, ItemRevision itemRevision, boolean requestRequired,
            boolean deleteAll) throws CoreException {
        super(file, itemType, itemRevision, true, requestRequired);
        this.deleteAll = deleteAll;
    }

    @Override
    public int getKind() {
        return DELETE;
    }

    /**
     * @return <code>true</code> if this request to delete all item revisions,
     *         returns <code>false</code> to return just the revision contained in this
     *         request
     */
    public boolean isDeleteAll() {
        return deleteAll;
    }

    public void setDeleteAll(boolean deleteAll) {
        this.deleteAll = deleteAll;
    }

    /**
     * @param b <code>true</code> to also delete local resource if item remove succeeds
     */
    public void setDeleteLocal(boolean b) {
        this.deleteLocal = b;
    }

    public boolean getDeleteLocal() {
        return deleteLocal;
    }

    /**
     * If local metadata will be deleted, default is true
     * @param unmanage
     */
    public void setUnmanage(boolean unmanage) {
        this.unmanage = unmanage;
    }

    public boolean getUnmanage() {
        return unmanage;
    }

    void setProject(Project project) {
        this.project = project;
    }

    @Override
    protected boolean modifiesLocal() {
        return false; // file is deleted through IFile - no need to refresh
    }

    @Override
    protected boolean modifiesMetadata() {
        return unmanage;
    }

    @Override
    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
        monitor.beginTask(null, 100);
        try {
            // TODO VG on Mar 17, 2006: check if checked out and undo c/o if so?
            List<String> reqList = getChangeRequests();
            String[] reqIds = reqList == null || reqList.isEmpty() ? null : (String[]) reqList.toArray(new String[reqList.size()]);
            DimensionsResult result = getItemRevision().removeFromProject(project, deleteAll, reqIds);
            monitor.worked(70);

            IFile local = getFile();

            if (deleteAll) {
                if (unmanage) {
                    ((DMWorkspace) DMTeamPlugin.getWorkspace()).unmanage(local, false, Utils.subMonitorFor(monitor, 15));
                }
            } else {
                // TODO VG on Apr 15, 2006: check if remote is there, unmanage if not
                // Note: we always do deleteAll=true now so this is not implemented
            }

            if (deleteLocal) {
                local.delete(true, true, Utils.subMonitorFor(monitor, 15)); // delete of non-existing is ok
            }

            return result;
        } finally {
            monitor.done();
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Request to checkout a file.
 *
 * @author V.Grishchenko
 */
public class CheckoutRequest extends CreateNewItemRevisionRequest /* implements IUploadRequestParameters */{
    private ItemRevision baseRevision;
    private boolean expandSubstVars;

    /**
     * Creates a default checkout request with no documents, no overwrites, and no revision details.
     *
     * @param file
     * @param itemType
     * @param baseRevision
     * @param enforceRequest
     * @param anyRequest
     * @throws CoreException
     */
    public CheckoutRequest(IFile file, ItemType itemType, ItemRevision baseRevision, boolean enforceRequest, boolean anyRequest)
            throws CoreException {
        super(file, itemType, CHECKOUT, enforceRequest, anyRequest);
        this.baseRevision = baseRevision;
    }

    @Override
    public int getKind() {
        return MODIFY;
    }

    /**
     * @return Returns the baseRevision.
     */
    public ItemRevision getBasedOnRevision() {
        return baseRevision;
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        return checkout();
    }

    /**
     * checks out base revision, must be called from session runnable
     */
    DimensionsResult checkout() throws Exception {
        String target = getFile().getLocation().toOSString();
        List<String> docList = getChangeRequests();
        String[] docs = null;
        docs = docList.toArray(new String[docList.size()]);
        // darius runs a db query if filename is missing,
        // this is our "optimization" to work around this peculiarity, can be
        // removed when darius is fixed
        // workaround start
        if (baseRevision.getAttribute(SystemAttributes.ITEMFILE_FILENAME) == null) {
            TeamUtils.setFilename(baseRevision, getFile().getName());
        }
        // workaround end
        getNewRevisionDetails().setExpand(Boolean.valueOf(isExpandSubstVars()));
        DimensionsResult result = baseRevision.checkOut(target, true, false, docs, getNewRevisionDetails());
        TeamUtils.ensureReacheable(getFile().getParent(), false); // TODO VG on Jan 26, 2006: temp fix
        return result;
    }

    /**
     * @return the expandSubstVars
     */
    public boolean isExpandSubstVars() {
        return expandSubstVars;
    }

    /**
     * @param expandSubstVars the expandSubstVars to set
     */
    public void setExpandSubstVars(boolean expandSubstVars) {
        this.expandSubstVars = expandSubstVars;
    }

}

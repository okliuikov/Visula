package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DeliverMultipleIdeProjectsCommandDetails;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.sbm.ActionDetails;
import com.serena.eclipse.dimensions.core.sbm.AssociateInput;
import com.serena.eclipse.dimensions.core.sbm.ISBMConnection;
import com.serena.eclipse.dimensions.core.sbm.ISBMManager;
import com.serena.eclipse.dimensions.core.util.Utils;

public class DeliverMultipleCommand extends DMWorkspaceMultipleCommand1 implements DeliverResults {
    private static boolean debug = DMTeamPlugin.getDefault().isDebugging();

    private boolean refreshNeeded; // post command remote tree refresh needed
    private DeliverHelper deliverHelper = new DeliverHelper(this);

    // inputs
    private TransferToStreamMultipleCommandData transferData;
    private List<IdeProjectDeliverBucket> buckets = new ArrayList<IdeProjectDeliverBucket>();
    private DeliverMultipleIdeProjectsCommandDetails multiDetails = new DeliverMultipleIdeProjectsCommandDetails();

    // results
    private Map<String, ObjectToTransfer> statusMap = new HashMap<String, ObjectToTransfer>();

    // sbm integration
    private ISBMConnection sbmc = null;
    private Map<IResource, ActionDetails> actionDetails = null;

    public DeliverMultipleCommand(TransferToStreamMultipleCommandData transferData) {
        super(transferData.getRequests());
        this.transferData = transferData;
    }

    @Override
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        DeliverHelper.addDeliverSchedulingRule(rules, request);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            beforeDeliver();
            deliver(Utils.subMonitorFor(monitor, 950));
            afterDeliver(Utils.subMonitorFor(monitor, 50));
        } finally {
            monitor.done();
        }
    }

    /**
     * Creates multiple deliver details, init command data
     */
    @SuppressWarnings("unchecked")
    private void beforeDeliver() {
        Map<IDMProject, TransferToStreamOperationData> deliverOperations = transferData.getDeliverOpeartions();
        multiDetails.setAll(false); // state depends on the contents only, should be initialized before processing
        for (Map.Entry<IDMProject, TransferToStreamOperationData> entry : deliverOperations.entrySet()) {
            IDMProject dmProject = entry.getKey();
            if (sbmc == null) {
                this.sbmc = dmProject.getConnection().getSBMConnection();
                if (sbmc != null) {
                    this.actionDetails = new HashMap<IResource, ActionDetails>();
                }
            }

            TransferToStreamOperationData commandData = entry.getValue();
            List<WorkspaceResourceRequest> deliverList = commandData.getRequests();

            if (!refreshNeeded) {
                // refresh if any child bucket needs refresh
                this.refreshNeeded = !deliverList.isEmpty();
            }

            IdeProjectDeliverBucket deliverBucket = new IdeProjectDeliverBucket(deliverList, commandData);
            multiDetails.addProjectToTransfer(deliverBucket);
            buckets.add(deliverBucket);

            if (StringPath.isNullorEmpty(multiDetails.getUserDirectory())) {
                multiDetails.setUserDirectory(dmProject.getUserDirectory().toOSString());
            }

            if (StringPath.isNullorEmpty(multiDetails.getComment())) {
                multiDetails.setComment(deliverBucket.getComment());
            }

            if (!multiDetails.getAll()) {
                // all true for all buckets if any child bucket should send all items
                multiDetails.setAll(deliverBucket.isAll());
            }

            multiDetails.getAttributeMap().putAll(deliverBucket.getAttributeMap());
        }

        multiDetails.setWorkareaType(transferData.getWorkareaType());
        multiDetails.setVerbose(true);
        multiDetails.setXmlMode(true);
        multiDetails.setXmlExecute(true);
    }

    private void deliver(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            Session session = transferData.getAnyProject().getConnection().openSession(Utils.subMonitorFor(monitor, 50));
            TransferMonitor tMonitor = new TransferMonitor(Utils.subMonitorFor(monitor, 950), TransferMonitor.UP);
            multiDetails.setListener(tMonitor);
            multiDetails.setCancelMonitor(tMonitor);

            int requestsSize = transferData.getRequestsSize();
            String msg = requestsSize == 1 ? NLS.bind(Messages.DeliverBucket_1, String.valueOf(requestsSize)) : NLS.bind(
                    Messages.DeliverBucket_0, requestsSize);

            if (debug) {
                System.out.println("+ Delivering over " + buckets.size() + " buckets"); //$NON-NLS-1$ //$NON-NLS-2$
                System.out.println(buckets);
            }

            final Project project = (Project) transferData.getAnyProject().getDimensionsObject();
            session.run(new APIOperation(msg) {
                @Override
                protected DimensionsResult doRun() throws Exception {
                    project.deliver(multiDetails);
                    return assembleResult(buckets);
                }

                private DimensionsResult assembleResult(List<IdeProjectDeliverBucket> buckets) {
                    StringBuilder sb = new StringBuilder();
                    for (IdeProjectDeliverBucket ideProject : buckets) {
                        sb.append(ideProject.assembleResult());
                        List<ObjectToTransfer> transferResults = ideProject.getTransferResults();
                        fillStatusMap(transferResults, statusMap);
                    }
                    return new DimensionsResult(sb.toString());
                }
            }, monitor);

            if (debug) {
                System.out.println("- done"); //$NON-NLS-1$
            }
        } finally {
            monitor.done();
        }
    }

    /**
     * Manage metadata and refresh local for the files just uploaded
     * @param buckets
     * @param monitor
     * @throws CoreException
     */
    private void afterDeliver(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 200);
        try {
            DeliverBucketHelper.manageMetadataAfterMultipleDeliver(buckets);

            // refresh local for the files just uploaded
            List<IResource> toClean = refresh(Utils.subMonitorFor(monitor, 150));
            cleanTimestamps(toClean, Utils.subMonitorFor(monitor, 50));

            // associate in SBM, if necessary
            if (sbmc != null && actionDetails != null && !actionDetails.isEmpty()) {
                ActionDetails[] actions = actionDetails.values().toArray(new ActionDetails[actionDetails.size()]);
                AssociateInput ai = new AssociateInput(actions, null);
                ISBMManager sbmManager = sbmc.getSBMManager();
                sbmManager.associate(ai, null);
            }
        } finally {
            monitor.done();
        }
    }

    private List<IResource> refresh(IProgressMonitor monitor) throws CoreException {
        List<IResource> toClean = new ArrayList<IResource>();

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, transferData.getRequestsSize() * 10);
        try {
            for (IdeProjectDeliverBucket bucket : buckets) {
                deliverHelper.afterDeliver(bucket.getContents(), toClean, monitor);
            }
            return toClean;
        } finally {
            monitor.done();
        }
    }

    private void cleanTimestamps(List<IResource> toClean, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 50);
        try {
            if (!toClean.isEmpty()) {
                IResource[] resources = toClean.toArray(new IResource[toClean.size()]);
                DMTeamPlugin.getWorkspace().cleanTimestamps(resources, IResource.DEPTH_ZERO, Utils.subMonitorFor(monitor, 50));
            }
        } finally {
            monitor.done();
        }
    }

    void fillStatusMap(List<ObjectToTransfer> transferResults, Map<String, ObjectToTransfer> statusMap) {
        for (ObjectToTransfer fileDetails : transferResults) {
            statusMap.put(fileDetails.getFileName(), fileDetails);
            addError(fileDetails);
        }
    }

    @Override
    public boolean modifiesRemote() {
        return refreshNeeded;
    }

    @Override
    protected String getErrorMessage(IStatus[] errors) {
        return Messages.UploadCommand_0;
    }

    @Override
    public IResource[] getChanges() {
        return new IResource[0];
    }

    @Override
    public void setChanges(IResource[] changes) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<String, ObjectToTransfer> getStatusMap() {
        return statusMap;
    }

    @Override
    public Map<IResource, ActionDetails> getActionDetails() {
        return actionDetails;
    }
}

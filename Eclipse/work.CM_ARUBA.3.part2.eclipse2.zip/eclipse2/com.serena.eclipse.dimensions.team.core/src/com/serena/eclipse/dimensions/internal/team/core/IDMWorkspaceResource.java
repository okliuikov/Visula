/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;

import com.serena.dmfile.metadb.MetadataProvider;

/**
 * Helper interface that provides access to version control related
 * properties of workspace resources.
 *
 * @author V.Grishchenko
 * @see com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace#getWorkspaceResource(IResource)
 */
public interface IDMWorkspaceResource extends IDMResource { 

    /**
     * @return base resource or <code>null</code> if none
     * @throws TeamException
     */
    IDMRemoteResource getBaseResource() throws TeamException;

    /**
     * @return remote resource or <code>null</code> if none
     * @throws TeamException
     */
    IDMRemoteResource getRemoteResource() throws TeamException;

    /**
     * Clears cached base and remote variant data
     */
    void flushCachedVariants();

    /**
     * Controls whether or not this resource should keep once obtained variant
     * values, if caching is disabled up to date remote and base (as far as dm workspace
     * is concerned) will be returned each time corresponding methods are invoked.
     *
     * @param b
     *            pass <code>true</code> to cache (default), otherwise pass <code>false</code>
     */
    void setCacheVariants(boolean b);

    /**
     * <p>
     * Files are modified if they were somehow changed in the workspace after they were fetched from the repository.
     *
     * <p>
     * Folders are modified if they contain modified files, unmanaged files or deleted controlled files. Folder modified status is
     * always deep.
     *
     * @return <code>true</code> if local resource was modified, returns <code>false</code> otherwise or if this resource is not
     *         managed.
     * @throws TeamException
     */
    boolean isModified() throws TeamException;

    /**
     * @return <code>true</code> if this resource has base information
     */
    boolean isManaged() throws TeamException;

    /**
     * @return <code>true</code> if this resource has remote information
     */
    boolean hasRemote() throws TeamException;

    /**
     * @return <code>true</code> if this resource is ignored, managed
     *         resources are never ignored
     */
    boolean isIgnored() throws TeamException;

    /**
     * Check ignorance using specified metadata provider
     * @return <code>true</code> if this resource is ignored, managed
     *         resources are never ignored
     */
    boolean isIgnored(MetadataProvider provider) throws TeamException;

    /**
     * @return <code>true</code> if this resource is known to have been
     *         moved from another location
     */
    boolean isMoved() throws CoreException;

    /**
     * @return <code>true</code> if this resource is moved, and it is moved
     *         from one repository project namespace to another
     */
    boolean isMovedCrossProject() throws CoreException;

    /**
     * @return source this file moved from or <code>null</code> if none
     */
    IResource getMovedFrom() throws CoreException;

    /**
     * @return the project this resource was moved to its current location,
     *         returns <code>null</code> if resource is not moved or moved
     *         within one project
     */
    IDMProject getMovedFromProject() throws CoreException;

    /**
     * @return destination this resource was moved to or <code>null</code> if none
     */
    IResource getMovedTo() throws CoreException;

    /**
     * @return <code>true</code> if this resource is known to have been
     *         moved from another location in repository
     */
    boolean isMovedInRepository() throws CoreException;

    /**
     * @return source this file moved from or <code>null</code> if none
     */
    IResource getMovedInRepositoryFrom() throws CoreException;

    /**
     * @return destination this resource was moved to or <code>null</code> if none
     */
    IResource getMovedInRepositoryTo() throws CoreException;

    /**
     * Deletes the base information (metadata) for this resource, does
     * nothing if resource is not managed.
     *
     * @param progress
     * @throws CoreException
     */
    void unmanage(IProgressMonitor progress) throws CoreException;

    /**
     * @return resource status, for containers the status represents the
     *         cumulative status of all descendants, calculated recursively
     */
    WorkspaceResourceStatus getStatus() throws TeamException;

    /**
     * Check status using specified metadata provider
     * @return resource status, for containers the status represents the
     *         cumulative status of all descendants, calculated recursively
     */
    WorkspaceResourceStatus getStatus(MetadataProvider provider) throws TeamException;

    void makeUnmodified() throws CoreException;

    void makeIncoming() throws CoreException;

    /**
     * {@link IDMWorkspaceResource} could be created from resource which is relative to the
     * virtual project {@link VirtualIdmProject}. This method should return the original resource
     * or null if {@link IDMWorkspaceResource} was created from regular resource.
     *
     * @return original resource from virtual project or null
     */
    IResource geVirtualResource() throws TeamException;
}

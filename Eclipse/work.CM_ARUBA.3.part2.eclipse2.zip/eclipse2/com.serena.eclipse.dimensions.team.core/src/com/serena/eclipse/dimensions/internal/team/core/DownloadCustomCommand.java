package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.DownloadCommandDetails;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionLocationDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.metadb.MetadataException;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

public class DownloadCustomCommand extends DownloadCommand {
    private CustomSubscriber subscriber;

    public DownloadCustomCommand(CustomSubscriber subscriber, DMProject dmProject, WorkspaceResourceRequest[] requests) {
        this(subscriber, dmProject, requests, false, false);
    }

    public DownloadCustomCommand(CustomSubscriber subscriber, DMProject dmProject, WorkspaceResourceRequest[] requests,
            boolean overwrite, boolean deleteUnmanaged) {
        super(dmProject, requests);
        this.overwrite = overwrite;
        this.deleteUnmanaged = deleteUnmanaged;
        this.subscriber = subscriber;
    }

    @Override
    @SuppressWarnings({ "rawtypes", "unchecked" })
    protected void execute(IProgressMonitor monitor) throws CoreException {
        ArrayList filesToDownload = new ArrayList();
        ArrayList foldersToDownload = new ArrayList();
        boolean createFolder = false;
        IResource[] resources = TeamUtils.getNonOverlapping(getResources());
        for (int i = 0; i < resources.length; i++) {
            collectDownloadableResources(resources[i], filesToDownload, foldersToDownload);
        }
        ArrayList toDelete = new ArrayList(); // folders and files to be deleted
        // files to be deleted, but whose metadata should not be deleted.
        ArrayList toDeleteResourceButRetainMetadata = new ArrayList();
        // folders to be deleted, but whose metadata should not be deleted.
        ArrayList toDeleteFolderButRetainMetadata = new ArrayList();
        // precreate folders
        for (Iterator iter = foldersToDownload.iterator(); iter.hasNext();) {
            IContainer container = (IContainer) iter.next();
            if (container.getType() == IResource.FOLDER) {
                SyncInfo info = subscriber.getSyncInfo(container);
                if (info == null) {
                    continue;
                }
                int kind = info.getKind();
                switch (kind & SyncInfo.DIRECTION_MASK) {
                case SyncInfo.INCOMING:
                    switch (kind & SyncInfo.CHANGE_MASK) {
                    case SyncInfo.ADDITION:
                        createFolder = true;
                        break;
                    case SyncInfo.DELETION:
                        toDelete.add(container);
                        break;
                    }
                    break;
                case SyncInfo.CONFLICTING:
                    switch (kind & SyncInfo.CHANGE_MASK) {
                    case SyncInfo.DELETION:
                        toDelete.add(container); // only metadata will be deleted as delete is ok if not exists
                        break;
                    case SyncInfo.ADDITION:
                        createFolder = overwrite;
                        break;
                    }
                    break;
                case SyncInfo.OUTGOING:
                    if (overwrite) {
                        switch (SyncInfo.CHANGE_MASK & kind) {
                        case SyncInfo.ADDITION:
                            if (deleteUnmanaged) {
                                if (TeamUtils.isLocalWorksetPointingToForeignStream(container)
                                        || TeamUtils.isLocalWorksetPointingToForeignProject(container)) {
                                    toDeleteFolderButRetainMetadata.add(container);
                                    toDeleteResourceButRetainMetadata.add(container);
                                } else {
                                    toDelete.add(container);
                                }
                            }
                            break;
                        case SyncInfo.DELETION:
                            createFolder = true;
                            break;
                        }
                    }
                }

                if (createFolder) {
                    TeamUtils.ensureContainerExists(container);
                    TeamUtils.ensureReacheable(container, !TeamUtils.hasFolderGotFileInItOrItsSubfolders(container));
                }
            }
        }

        ArrayList getRequests = new ArrayList();
        ArrayList undoCheckoutRequests = new ArrayList();
        ArrayList autoMergeRequests = new ArrayList();
        boolean allowUpdateAutoMerge = DMTeamPlugin.getDefault().isAllowUpdateAutoMerge();
        for (int i = 0; i < filesToDownload.size(); i++) {
            IFile file = (IFile) filesToDownload.get(i);
            SyncInfo info = subscriber.getSyncInfo(file);
            if (info == null) {
                continue;
            }
            int kind = info.getKind();
            IDMWorkspaceFile dmFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(file);
            switch (kind & SyncInfo.DIRECTION_MASK) {
            case SyncInfo.INCOMING:
                switch (kind & SyncInfo.CHANGE_MASK) {
                case SyncInfo.ADDITION:
                case SyncInfo.CHANGE:
                    if (dmFile.isExtracted()) {
                        UndoCheckoutRequest ucr = new UndoCheckoutRequest(file, dmFile.getBaseFile().getItemRevision());
                        ucr.setReplace(UndoCheckoutRequest.REPLACE_NONE);
                        undoCheckoutRequests.add(ucr);
                    } else {
                        IDMRemoteFile remote = (IDMRemoteFile) subscriber.getRemoteTree().getResourceVariant(file);
                        ItemRevision itemRevision = remote.getItemRevision();
                        assert itemRevision != null;
                        getRequests.add(new GetRevisionRequest(file, itemRevision));
                    }
                    break;
                case SyncInfo.DELETION:
                    toDelete.add(file);
                }
                break;
            case SyncInfo.CONFLICTING:
                switch (kind & SyncInfo.CHANGE_MASK) {
                case SyncInfo.DELETION:
                    toDelete.add(file); // only metadata will be deleted as delete is ok if not exists
                    break;
                case SyncInfo.ADDITION:
                case SyncInfo.CHANGE:
                    if (overwrite) { // handle overwrite, otherwise fall through to default
                        IDMRemoteFile remoteFile = dmFile.getRemoteFile();
                        if (remoteFile != null) { // addition, vanilla conflict or no local/changed remote - just replace
                            if (dmFile.isExtracted()) {
                                UndoCheckoutRequest ucr = new UndoCheckoutRequest(file, dmFile.getBaseFile().getItemRevision());
                                ucr.setReplace(UndoCheckoutRequest.REPLACE_NONE);
                                undoCheckoutRequests.add(ucr);
                            } else {
                                IDMRemoteFile remote = (IDMRemoteFile) subscriber.getRemoteTree().getResourceVariant(file);
                                ItemRevision itemRevision = remote.getItemRevision();
                                assert itemRevision != null;
                                getRequests.add(new GetRevisionRequest(file, itemRevision));
                            }
                        } else { // local change + remote removal - just delete local as this what we have been asked for
                            toDelete.add(file);
                        }
                        break;
                    } else { // try auto-merge
                        if (allowUpdateAutoMerge) {
                            IDMRemoteFile baseFile = dmFile.getBaseFile();
                            IDMRemoteFile remoteFile = dmFile.getRemoteFile();
                            if (remoteFile != null && baseFile != null) {
                                // merge local=file, remote=remoteFile, ancestor=baseFile
                                autoMergeRequests.add(new UpdateAutoMergeRevisionRequest(file, remoteFile.getItemRevision(),
                                        baseFile.getItemRevision()));
                                break;
                            }
                        }
                    }
                default:
                    addError(new SyncStatus(file, kind));
                    break;
                }
                break;
            case SyncInfo.OUTGOING:
                if (overwrite) {
                    switch (SyncInfo.CHANGE_MASK & kind) {
                    case SyncInfo.CHANGE:
                    case SyncInfo.DELETION:
                        if (dmFile.isExtracted()) {
                            UndoCheckoutRequest ucr = new UndoCheckoutRequest(file, dmFile.getBaseFile().getItemRevision());
                            ucr.setReplace(UndoCheckoutRequest.REPLACE_NONE);
                            undoCheckoutRequests.add(ucr);
                        } else {
                            IDMRemoteFile remote = (IDMRemoteFile) subscriber.getRemoteTree().getResourceVariant(file);
                            ItemRevision itemRevision = remote.getItemRevision();
                            assert itemRevision != null;
                            getRequests.add(new GetRevisionRequest(file, itemRevision));
                        }
                        break;
                    case SyncInfo.ADDITION:
                        if (deleteUnmanaged) {
                            if (TeamUtils.isLocalWorksetPointingToForeignStream(file)
                                    || TeamUtils.isLocalWorksetPointingToForeignProject(file)) {
                                toDeleteResourceButRetainMetadata.add(file);
                            } else {
                                toDelete.add(file);
                            }
                        }
                        break;
                    }
                }
                break;
            }
        }

        // reserve 30 units for each undo checkout - 10 will go to get latest
        int dlWrkUnits = (getRequests.size() * 10)/* + 5 */;
        int uamWrkUnits = (autoMergeRequests.size() * 10)/* + 5 */;
        monitor.beginTask(null, (undoCheckoutRequests.size() * 30) + dlWrkUnits + uamWrkUnits + (toDelete.size() * 10));
        try {
            // undo checkout first
            for (int i = 0; i < undoCheckoutRequests.size(); i++) {
                UndoCheckoutRequest undoCheckoutrequest = (UndoCheckoutRequest) undoCheckoutRequests.get(i);
                undoCheckoutrequest.process(Utils.subMonitorFor(monitor, 10));
                // have to update cached latest revision info as undo checkout changes it
                getWorkspace().refresh(new IResource[] { undoCheckoutrequest.getFile() }, IResource.DEPTH_INFINITE,
                        Utils.subMonitorFor(monitor, 10));
                IDMRemoteFile remote = (IDMRemoteFile) subscriber.getRemoteTree().getResourceVariant(undoCheckoutrequest.getFile());
                if (remote != null) {
                    GetRevisionRequest getRev = new GetRevisionRequest(undoCheckoutrequest.getFile(), remote.getItemRevision());
                    getRequests.add(getRev);
                } else {
                    monitor.worked(10); // will not fetch, have to subtract here
                }
            }
            if (autoMergeRequests.size() > 0) {
                updateAutoMerge(autoMergeRequests, Utils.subMonitorFor(monitor, uamWrkUnits));
            }
            if (getRequests.size() > 0) {
                staleRemoteTree = runDownload(getRequests, Utils.subMonitorFor(monitor, dlWrkUnits));
            }
            // delete local last
            for (int i = toDelete.size() - 1; i >= 0; i--) { // delete files first
                IResource resourceToDelete = (IResource) toDelete.get(i);

                DMTeamPlugin.getWorkspace().unmanage(resourceToDelete, Utils.subMonitorFor(monitor, 5));
                // will not fail for not existing resources
                resourceToDelete.delete(IResource.KEEP_HISTORY, Utils.subMonitorFor(monitor, 5));
            }

            // delete local but retain metadata
            for (int i = toDeleteResourceButRetainMetadata.size() - 1; i >= 0; i--) {
                IResource resourceToDelete = (IResource) toDeleteResourceButRetainMetadata.get(i);
                if (isParentOfResourceAlsoBeingDeleted(resourceToDelete, toDeleteFolderButRetainMetadata)) {
                    WorkspaceMetadataManager.getInstance().deleteMetadata(resourceToDelete, WorkspaceMetadataManager.DELETE_ALL);
                } else {
                    // We add "metadata-of-deleted-foreign-resource=yes" tag to metadata to cover the following conflict case:
                    // A file/folder has been deleted from Child Stream. Now you want to apply this deletion back to Parent Stream.
                    // As per the best practices you will update your empty local workspace with the contents from Parent
                    // Stream.Then you switch your workspace to Child Stream and do a sync. The deleted file/folder will be shown as
                    // an outgoing addition. Do an Override and Update to delete the file/folder on disk. Under normal situation the
                    // metadata is deleted along with the file/folder. We do not delete the metadata as this will result in the file
                    // deletion being shown as incoming addition instead of an outgoing deletion when you
                    // switch back to Parent Stream and do a sync. But at the same time the presence of metadata will cause another
                    // problem, ie, if we do a resync with the Child Stream this deleted file/folder will be shown as
                    // an outgoing deletion due to the presence of metadata.In order to get around this issue we add
                    // "metadata-of-deleted-foreign-resource=yes" tag to the metadata ,which is used not to show the file in sync
                    // view when you do a resync with the Child Stream.
                    BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resourceToDelete);
                    if (metadata != null) {
                        metadata.put(TeamUtils.METADATA_OF_DELETED_FOREIGN_RESOURCE, "yes");
                        WorkspaceMetadataManager.getInstance().updateMetadata(resourceToDelete, metadata);
                    }
                }
                // will not fail for not existing resource
                resourceToDelete.delete(IResource.KEEP_HISTORY, Utils.subMonitorFor(monitor, 5));
            }

            // Refresh the whole project. Since Mars, directory metadata files are being written outside eclipse code. These
            // metadata files won't be in sink with workspace until resource is refreshed. Without this refresh projects/Streams
            // contents added to workspace won't have serena related menu enabled
            if (getRequests.size() > 0) {
                if (!((GetRevisionRequest) getRequests.get(0)).getResource().getProject().isSynchronized(IResource.DEPTH_INFINITE)) {
                    ((GetRevisionRequest) getRequests.get(0)).getResource()
                            .getProject()
                            .refreshLocal(IResource.DEPTH_INFINITE, monitor);
                }
            }

        } finally {
            monitor.done();
        }
    }

    // run download and return files with stale remote tree info
    protected IResource[] runDownload(ArrayList getRequests, IProgressMonitor monitor) throws CoreException {
        // get latest second
        final HashSet parents = new HashSet();
        final ArrayList itemsToDownload = new ArrayList();
        IFile[] filesToMonitor = new IFile[getRequests.size()];
        for (int i = 0; i < getRequests.size(); i++) {
            GetRevisionRequest request = (GetRevisionRequest) getRequests.get(i);
            IFile ifile = request.getFile();
            ItemRevisionLocationDetails loc = new ItemRevisionLocationDetails(request.getItemRevision(), ifile.getLocation()
                    .toOSString());
            itemsToDownload.add(loc);
            filesToMonitor[i] = ifile;
            parents.add(ifile.getParent());
        }

        // explicitly precreate metadata folders where we expect them to be,
        // the intention here is to mark them *team private* as early as possible
        // to avoid resource change listeners to see them as non-team private, e.g.
        // they may show up in the Navigator which is undesirable...
        monitor.subTask(Messages.DownloadCommand_createMetaFolders);
        precreateMetadataFolders(parents);

        String msg = getRequests.size() > 1 ? NLS.bind(Messages.DownloadCommand_downloadingMulti,
                String.valueOf(getRequests.size())) : NLS.bind(Messages.DownloadCommand_downloadingSingle,
                filesToMonitor[0].getFullPath().toOSString());
        monitor.subTask(msg);

        monitor.beginTask(null, 1010);

        try {
            Session session = dmProject.getConnection().openSession(Utils.subMonitorFor(monitor, 10)); // 10 of 1000
            final TransferMonitor tm = new TransferMonitor(Utils.subMonitorFor(monitor, 900), TransferMonitor.DOWN); // 910 of 1000
            session.run(new APIOperation(msg) {
                @Override
                protected DimensionsResult doRun() throws Exception {
                    IPath userDir = dmProject.getUserDirectory();

                    DownloadCommandDetails dcd = new DownloadCommandDetails();
                    dcd.setItemsToDownload(itemsToDownload);
                    dcd.setUserDirectory(userDir.toOSString());
                    dcd.setRelativeLocation(dmProject.getRelativeLocation() != null
                            ? dmProject.getRelativeLocation().toOSString() : null);
                    dcd.setTouch(Boolean.FALSE);
                    dcd.setOverwrite(Boolean.valueOf(overwrite));
                    dcd.setCheckConflict(Boolean.FALSE);
                    dcd.setCancelMonitor(tm);
                    dcd.setListener(tm);
                    dcd.setExpand(TeamUtils.isExpandSubstitution());

                    DimensionsResult downloadResult;
                    if (dmProject.isWorkset()) {
                        Project project = (Project) dmProject.getDimensionsObject();
                        downloadResult = project.download(dcd);
                    } else {
                        Baseline baseline = (Baseline) dmProject.getDimensionsObject();
                        downloadResult = baseline.download(dcd);
                    }
                    return downloadResult;
                }
            }, monitor);
            // find files with stale remote info, cannot rely on the base tree data here
            // as it may not yet be up to date due to the async nature of resource deltas
            ArrayList staleList = new ArrayList();
            IProgressMonitor refreshMonitor = Utils.subMonitorFor(monitor, 90); // 1000 of 1000
            refreshMonitor.beginTask(null, getRequests.size() * 10);
            for (int i = 0; i < getRequests.size(); i++) {
                GetRevisionRequest request = (GetRevisionRequest) getRequests.get(i);
                IFile file = request.getFile();
                try {
                    BaseMetadata metadata = WorkspaceMetadataManager.getLfsMetadata(file.getLocation().toFile());
                    if (metadata instanceof ItemMetadata) {
                        ItemMetadata itemMetadata = (ItemMetadata) metadata;
                        DMRemoteFile base = new DMRemoteFile(null, dmProject.getRemotePathForLocalResource(file), dmProject, null,
                                itemMetadata, 0);
                        IDMRemoteResource remoteRes = DMTeamPlugin.getWorkspace().getRemoteResource(file);
                        boolean stale = true;
                        if (remoteRes instanceof IDMRemoteFile) {
                            IDMRemoteFile remote = (IDMRemoteFile) remoteRes;
                            stale = !base.equals(remote);
                        }
                        if (stale) {
                            staleList.add(file);
                        }
                        // check if that is for items moved in repository
                        if (TeamUtils.isLocalWorksetPointingToForeignStream(file)) {
                            IResource movedFrom = DMTeamPlugin.getWorkspace().getMovedInRepositoryFrom(file);
                            if (movedFrom != null) {
                                String strMovedFrom = dmProject.getRemotePathForLocalResource(movedFrom).toOSString();
                                // Replace backward slashes with forward slashes. This will help to remove relative path from this
                                // while delivering a local move
                                strMovedFrom = strMovedFrom.replace('\\', '/');
                                itemMetadata.setMovedFrom(strMovedFrom);
                                ItemMetadata metadataOfItemBeingMoved = ((DMWorkspace) DMTeamPlugin.getWorkspace()).getCachedMetadataOfItemBeingMoved(itemMetadata.getItemSpec()
                                        .substring(0, itemMetadata.getItemSpec().lastIndexOf(';')));
                                if (metadataOfItemBeingMoved != null && metadataOfItemBeingMoved.getItemSpec() != null) {
                                    // This if clause is to cover following use case:
                                    // Create StreamA with two folder(Folder1 and Folder2) and a file in each of these folders(
                                    // file1 and file2 respectively ). Create a StreamB from StreamA.
                                    // User1 adds StreamA to workspace. Modifies file1 locally and delivers it to StreamA.
                                    // User2 adds StreamB to workspace. Moves file1 locally and moves to Folder2 and delivers it
                                    // toStreamB.
                                    // User1 switches to StreamB , does a sync and Updates the repository move. Switches back to
                                    // StreamA and does a syn. Sync view shows local move.
                                    // Do a deliver.
                                    // In this scenario ,during Update of repository move ,we need to pass the revision list etc..
                                    // to the metadata for the deliver to be successful.
                                    itemMetadata.setRevisionListAsString(itemMetadata.getItemSpec().substring(
                                            itemMetadata.getItemSpec().lastIndexOf(';') + 1));
                                    itemMetadata.setItemSpec(metadataOfItemBeingMoved.getItemSpec());
                                    itemMetadata.setItemUid(metadataOfItemBeingMoved.getItemUid());
                                    itemMetadata.setChecksum(metadataOfItemBeingMoved.getChecksum());
                                    itemMetadata.setFetchSize(metadataOfItemBeingMoved.getFetchSize());
                                    itemMetadata.setProjectUid(metadataOfItemBeingMoved.getProjectUid());
                                }
                                WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();
                                metaMan.updateMetadata(file, itemMetadata);
                            }
                        }
                    }
                } catch (MetadataException e) {
                    DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, 0, "error reading metadata", e)); //$NON-NLS-1$
                }

                file.refreshLocal(IResource.DEPTH_INFINITE, Utils.subMonitorFor(refreshMonitor, 5));
                WorkspaceMetadataManager.refreshMetadata(file, Utils.subMonitorFor(refreshMonitor, 5));
            }
            refreshMonitor.done();

            if (overwrite) {
                // clean timestamps for touched files as they are ignored by DOWNLOAD
                ArrayList filesToClean = new ArrayList();
                for (int i = 0; i < getRequests.size(); i++) {
                    GetRevisionRequest request = (GetRevisionRequest) getRequests.get(i);
                    IFile file = request.getFile();
                    // do not rely on the cached state in the DM workspace as resource delta may not have been processed yet at this
                    // point
                    BaseMetadata baseMetadata = WorkspaceMetadataManager.getInstance().getMetadata(file);
                    if (baseMetadata instanceof ItemMetadata && DMWorkspace.isFileModified(file, (ItemMetadata) baseMetadata)) {
                        filesToClean.add(file);
                    }
                }
                if (!filesToClean.isEmpty()) {
                    List cleaned = getWorkspace().cleanTimestamps(
                            (IResource[]) filesToClean.toArray(new IResource[filesToClean.size()]), IResource.DEPTH_INFINITE,
                            Utils.subMonitorFor(monitor, 10));
                    for (Iterator iterator = cleaned.iterator(); iterator.hasNext();) {
                        IResource cleanedFile = (IResource) iterator.next();
                        if (!cleanedFile.isReadOnly()) {
                            TeamUtils.setReadOnly(cleanedFile, true);
                        }
                    }
                }
            }

            return (IResource[]) staleList.toArray(new IResource[staleList.size()]);
        } finally {
            monitor.done();
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;

/**
 * Contains information about local projects that were mapped to eclipse workspace and take part
 * in merge. Represents merge target
 */
public class MergeCommandLocalScope {
    private Map<IDMProject, List<IResource>> mergeScopes;
    private DimensionsArObject targetAPIObject;
    private static boolean showProjectGroupSelectionDialog = false;

    /**
     * @param mergeScopes see {@link #setMergeScopes(Map)}
     * @throws CoreException
     */
    public MergeCommandLocalScope(Map<IDMProject, List<IResource>> mergeScopes) {
        Assert.isNotNull(mergeScopes);
        setMergeScopes(mergeScopes);
    }

    /**
     * @return map between workspace project and selected resources in this project:
     *         <ul>
     *         <li>if selected resources list is empty then this is a project scope and proper 3-way merge;</li>
     *         <li>if selected resources list contains one folder then this is a sub-folder scope and proper 3-way merge;</li>
     *         <li>if selected resources list contains more then one resource then this is a list shaped merge.</li>
     *         </ul>
     */
    public Map<IDMProject, List<IResource>> getMergeScopes() {
        return mergeScopes;
    }

    /**
     * @param mergeScopes
     *            is a map between workspace project and selected resources in this project:
     *            <ul>
     *            <li>if selected resources list is empty then this is a project scope and proper 3-way merge;</li>
     *            <li>if selected resources list contains one folder then this is a sub-folder scope and proper 3-way merge;</li>
     *            <li>if selected resources list contains more then one resource then this is a list shaped merge.</li>
     *            </ul>
     * @throws CoreException
     */
    private void setMergeScopes(Map<IDMProject, List<IResource>> mergeScopes) {
        Assert.isNotNull(mergeScopes);
        if (!validateInput(mergeScopes)) {
            throw new UnsupportedOperationException();
        }
        this.mergeScopes = mergeScopes;
    }

    /**
     * @return target product that associated with current scope
     */
    public String getTargetProductSpec() {
        IDMProject any = getMergeScopes().keySet().iterator().next();
        return any.getProduct();
    }

    /**
     * @return target spec that associated with current scope
     */
    public String getTargetProjectSpec() {
        IDMProject any = getMergeScopes().keySet().iterator().next();
        return any.getId();
    }

    /**
     * @return remote API object that associated with this scope. Possible object types: PROJECT or
     *         BASELINE
     * @throws DMException
     */
    public DimensionsArObject getTargetAPIObject() {
        if (targetAPIObject == null) {
            throw new UnsupportedOperationException();
        }
        return targetAPIObject;
    }

    public DimensionsConnectionDetailsEx getConnection() {
        IDMProject any = getMergeScopes().keySet().iterator().next();
        return any.getConnection();
    }

    /**
     * @return remote offsets for every target project that associated with current scope
     */
    public IPath[] getDefaultOffsets() {
        List<IPath> offsets = new ArrayList<IPath>();
        for (Iterator<IDMProject> iterator = getMergeScopes().keySet().iterator(); iterator.hasNext();) {
            IDMProject project = iterator.next();
            offsets.add(project.getRemoteOffset());
        }
        return offsets.toArray(new IPath[getMergeScopes().size()]);
    }

    /**
     * @param mergeScopes {@link #setMergeScopes(Map)}
     * @return true iff projects are related to same remote API object
     * @throws DMException
     */
    private boolean validateInput(final Map<IDMProject, List<IResource>> mergeScopes) {
        IDMProject first = mergeScopes.keySet().iterator().next();
        try {

            if (first == null) {
                return false;
            }

            targetAPIObject = first.getDimensionsObjectAdapter().getAPIObject();

            if (mergeScopes.size() == 1) {
                return true;
            }

            for (IDMProject otherAPIObject : mergeScopes.keySet()) {
                if (!targetAPIObject.equals(otherAPIObject.getDimensionsObjectAdapter().getAPIObject())) {
                    return false;
                }
            }
        } catch (DMException e) {
            DMPlugin.log(e.getStatus());
            return false;
        }

        return true;
    }

    public static MergeCommandLocalScope createMergeCommandLocalScope(IResource[] resources, boolean checkFullWorkArea) throws CoreException {
        final Map<IDMProject, List<IResource>> mergeScopes = getScopes(resources, checkFullWorkArea);
        if (mergeScopes == null) {
            return null;
        }

        final MergeCommandLocalScope[] result = new MergeCommandLocalScope[1];

        Display.getDefault().syncExec(new Runnable() {

            @Override
            public void run() {
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {

                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
                            try {
                                if (checkConnection(mergeScopes, Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN))) {
                                    result[0] = new MergeCommandLocalScope(mergeScopes);
                                }
                            } catch (CoreException e) {
                                throw new InvocationTargetException(e);
                            } finally {
                                monitor.done();
                            }
                        }

                    });
                } catch (InterruptedException ignore) {
                } catch (InvocationTargetException ex) {
                    if (ex.getTargetException() instanceof CoreException) {
                        CoreException ce = (CoreException) ex.getTargetException();
                        DMTeamPlugin.log(ce.getStatus());
                    }
                }
            }

        });

        return result[0];
    }
    
    public static boolean doShowProjectSelectionDialog() {
        return showProjectGroupSelectionDialog;
    }

    public static Map<IDMProject, List<IResource>> getScopes(IResource[] resources, boolean checkFullWorkArea) throws CoreException {
        // map project -> selected resources in project
        // if selected resources list is empty then this is a project scope and proper 3-way merge
        // if selected resources list contains one folder then this is a sub-folder scope and proper 3-way merge
        // if selected resources list contains more then one resource then this is a list shaped merge
        final Map<IDMProject, List<IResource>> mergeScopes = new HashMap<IDMProject, List<IResource>>();
        Set<IDMProject> contained = new HashSet<IDMProject>();

        for (int i = 0; i < resources.length; i++) {
            IProject project = resources[i].getProject();
            IDMProject dmproject = DMTeamPlugin.getWorkspace().getProject(project);

            if (dmproject == null || dmproject.isBaseline()) {
                return null;
            }

            if (!mergeScopes.containsKey(dmproject)) {
                mergeScopes.put(dmproject, new ArrayList<IResource>());
            }

            if (dmproject.isSccStyle()) {
                contained.add(dmproject);
            }

            if (!(resources[i] instanceof IProject)) {
                mergeScopes.get(dmproject).add(resources[i]);
            }
        }

        int scopesSize = mergeScopes.size();
        int containedSize = contained.size();

        if (scopesSize > containedSize && containedSize != 0) {
            // mixed projects will be dropped
            return null;
        } else if (scopesSize > 1 && containedSize == 0) {
            // more then one uncontained will be dropped
            return null;
        } else if (containedSize > 1) {
            if (checkFullWorkArea) {
                showProjectGroupSelectionDialog = false;
                // same workset mapping check for contained projects
                // same path model check for contained projects
                Map<String, Boolean> diffMap = new HashMap<String, Boolean>();
                for (IDMProject dmproject : contained) {
                    Boolean isFullWA = diffMap.put(dmproject.getId(), dmproject.isFullWorkArea());
                    if (diffMap.size() > 1 || (isFullWA != null && isFullWA != dmproject.isFullWorkArea())) {
                        return null;
                    }
                }
            }
            else {
                boolean checked = false;
                boolean firstIsFullWA = false;
                Set<IDMProject> containedWithTheSameIsFullWorkArea = new HashSet<IDMProject>();
                for (IDMProject dmproject : contained) {
                    boolean isFullWA = dmproject.isFullWorkArea();
                    if (!checked) {
                        checked = true;
                        firstIsFullWA = isFullWA;
                        containedWithTheSameIsFullWorkArea.add(dmproject);
                    }
                    else if (isFullWA==firstIsFullWA) {
                        containedWithTheSameIsFullWorkArea.add(dmproject);
                    }
                }
                contained.removeAll(containedWithTheSameIsFullWorkArea);
                if (!contained.isEmpty()) {
                    showProjectGroupSelectionDialog = true;
                    for (IDMProject dmproject : contained) {
                        mergeScopes.remove(dmproject);
                    }
                }
                else {
                    showProjectGroupSelectionDialog = false;
                }
            }
        }

        // TODO: Temporary restriction for the list shaped merge.
        for (Entry<IDMProject, List<IResource>> entry : mergeScopes.entrySet()) {
            List<IResource> value = entry.getValue();

            if (value.size() > 1) {
                return null;
            }

            if (value.size() > 0 && value.get(0) instanceof IFile) {
                return null;
            }
        }

        if (mergeScopes.isEmpty()) {
            return null;
        }

        return mergeScopes;
    }

    private static boolean checkConnection(Map<IDMProject, List<IResource>> mergeScopes, IProgressMonitor monitor)
            throws CoreException {
        final IDMProject any = mergeScopes.keySet().iterator().next();
        if (any.getConnection().isSessionOpen()) {
            return true;
        }

        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            any.getConnection().openSession(monitor);
            if (any.getConnection().isSessionOpen()) {
                return true;
            }
        } finally {
            monitor.done();
        }

        return false;
    }

}
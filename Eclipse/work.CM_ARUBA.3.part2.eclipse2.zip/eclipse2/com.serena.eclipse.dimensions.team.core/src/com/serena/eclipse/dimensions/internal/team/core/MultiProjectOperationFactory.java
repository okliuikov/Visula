package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.IProduct;
import org.eclipse.core.runtime.Platform;

/**
 * Factory creates multiple project handlers and could detect if current IDE is a windriver workbench. Since 14.2 windriver isn't
 * supported.
 */
public class MultiProjectOperationFactory {

    private static IMultiProjectOperation theHandler = null;
    private static final String WR_PROD = "com.windriver.ide.wrworkbench"; //$NON-NLS-1$

    public static IMultiProjectOperation getHandler() {
        if (theHandler == null) {
            // find the handler
            if (isWindRiver()) {
                theHandler = new WindRiverMultiProjectHandler();
            } else {
                theHandler = new NullMultiProjectHandler();
            }
        }
        return theHandler;
    }

    /**
     * @return true if current ide is a wind river workbench
     */
    private static boolean isWindRiver() {
        // use Platform.id
        IProduct me = Platform.getProduct();
        if (me == null) {
            return false;
        }
        String id = me.getId();
        return WR_PROD.equalsIgnoreCase(id);
        // fool it for test in eclipse
        // return true;
    }

    /**
     * @return if multiple projects mode is allowed
     */
    public static boolean multiProjectAllowed() {
        if (isWindRiver()) {
            return true;
        }
        return false;
    }

}

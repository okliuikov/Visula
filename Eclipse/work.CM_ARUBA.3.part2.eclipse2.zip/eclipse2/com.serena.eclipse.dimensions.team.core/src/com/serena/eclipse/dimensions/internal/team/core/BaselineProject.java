/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.UploadItemDetails;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.SessionRunnableWithProgress;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Represents a remote project based on a baseline.
 *
 * @author V.Grishchenko
 */
class BaselineProject extends DMProject {
    private Baseline baseline;
    private RepositoryFolder rootFolder;

    public BaselineProject(String id, DimensionsConnectionDetailsEx connection, IProject project, IPath localOffset,
            IPath remoteOffset, IPath workAreaRoot, IDMRemoteTree remoteTree) {
        super(id, BASELINE, connection, project, localOffset, remoteOffset, workAreaRoot, remoteTree);
    }

    public BaselineProject(BaselineAdapter baseline, APIObjectAdapter uidObject, IProject project, IPath localOffset,
            IPath remoteOffset, IPath workAreaPath, IDMRemoteTree remoteTree) {
        super(baseline, uidObject, project, localOffset, remoteOffset, workAreaPath, remoteTree);
        this.baseline = baseline.getBaseline();
    }

    @Override
    public boolean isInitial() {
        return false; // baselines are never initial
    }

    @Override
    public String getDefaultRequest() {
        return null;
    }

    @Override
    public String getDefaultRequest(boolean query) throws CoreException {
        return null;
    }

    @Override
    public DimensionsLcObject getDimensionsObject() throws DMException {
        return getBaseline();
    }

    @Override
    public synchronized List<ItemMetadata> queryForeignContentStatus(final List<ItemMetadata> localMetadatas,
            final List<ItemMetadata> remoteMetadatas, IProgressMonitor monitor) throws CoreException {
        if (localMetadatas == null || remoteMetadatas == null || localMetadatas.size() != remoteMetadatas.size()) {
            return null;
        }
        String waLocation = isFullWorkArea() ? getWorkAreaPath().toOSString() : getProject().getLocation().toOSString();
        final String projectName = TeamUtils.getLocalWorksetSpec(waLocation);

        monitor = Utils.monitorFor(monitor);
        final Unit<List<ItemMetadata>> listHolder = new Unit<List<ItemMetadata>>();
        final Session session = getConnection().openSession(monitor);
        session.run(new SessionRunnableWithProgress(monitor) {

            @Override
            public void run() throws Exception {
                progress.beginTask(null, 100);
                try {
                    ItemMetadata[] data = session.getObjectFactory().getProject(projectName).syncQueryItemInfo(
                            localMetadatas.toArray(new ItemMetadata[localMetadatas.size()]),
                            remoteMetadatas.toArray(new ItemMetadata[localMetadatas.size()]));
                    if (data != null) {
                        listHolder.setValue(Arrays.asList(data));
                    }
                } finally {
                    progress.done();
                }
            }

        }, monitor);
        return listHolder.getValue();
    }

    @Override
    public/* synchronized */VersionManagementProject getDimensionsObjectAdapter() throws DMException {
        return new BaselineAdapter(getBaseline(), getConnection());
    }

    public synchronized Baseline getBaseline() throws DMException {
        if (baseline == null) {
            final Session session = getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    baseline = resolveBaseline(session.getObjectFactory());
                }
            }, new NullProgressMonitor());
        }
        if (baseline == null) {
            throw new DMException(NLS.bind(Messages.error_baselineNotFound, getId()), null);
        }
        return baseline;
    }

    @SuppressWarnings("unchecked")
    private Baseline resolveBaseline(DimensionsObjectFactory factory) {
        String baselineSpec = getId();
        int idx = baselineSpec.indexOf(':');
        if (idx == -1) {
            throw new RuntimeException("Baseline name must be PRODUCT_NAME:BASELINE_NAME"); //$NON-NLS-1$
        }

        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, baselineSpec, Filter.Criterion.EQUALS));

        List<Baseline> baselines = factory.getBaselines(filter);
        if (baselines.isEmpty()) {
            return null;
        }
        return baselines.get(0);
    }

    @Override
    public RepositoryFolder getRemoteRoot() throws DMException {
        if (rootFolder == null) {
            final Session session = getConnection().openSession(null);

            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    RepositoryFolder baselineRoot = getBaseline().getRootFolder();
                    if (getRemoteOffset().isEmpty()) {
                        rootFolder = baselineRoot;
                    } else {
                        List<RepositoryFolder> allFolders = baselineRoot.getAllChildFolders();
                        rootFolder = findFolder(allFolders, getRemoteOffset());
                    }
                }

            }, new NullProgressMonitor());
        }
        return rootFolder;
    }

    @Override
    public void flushRemoteRoot() {
        rootFolder = null;
    }

    @Override
    public ItemRevision getItemRevisionProxy(final String spec) throws DMException {
        Assert.isLegal(!Utils.isNullEmpty(spec), "empty item spec"); //$NON-NLS-1$
        final ItemRevision[] resultHolder = new ItemRevision[1];
        Session session = getConnection().openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                resultHolder[0] = getBaseline().createItemRevisionFromSpec(spec);
            }
        }, new NullProgressMonitor());
        return resultHolder[0];
    }

    @Override
    public ItemRevision getItemRevisionProxy(final ItemMetadata itemMetadata, IProgressMonitor monitor) throws DMException {
        Assert.isLegal(itemMetadata != null && !Utils.isNullEmpty(itemMetadata.getItemSpec()) && itemMetadata.getItemUid() != -1,
                "must have spec and uid in item metadata object " + String.valueOf(itemMetadata)); //$NON-NLS-1$
        final ItemRevision[] resultHolder = new ItemRevision[1];
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        try {
            Session session = getConnection().openSession(Utils.subMonitorFor(monitor, 10));
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    resultHolder[0] = getBaseline().createItemRevisionFromMetadata(itemMetadata);
                }
            }, monitor);
            monitor.worked(90);
            return resultHolder[0];
        } finally {
            monitor.done();
        }
    }

    @Override
    public RepositoryFolder getRepositoryFolderProxy(IPath path) throws DMException {
        return getRemoteFolder(path, null);
    }

    @Override
    public IStatus checkout(CheckoutRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Checkout from baseline is unsupported"); //$NON-NLS-1$
    }

    @Override
    public IStatus checkin(CheckinRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Checkin into baseline is unsupported"); //$NON-NLS-1$
    }

    @Override
    public IStatus undoCheckout(UndoCheckoutRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Undo Checkout is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus add(CreateItemRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Add is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public UploadItemDetails[] queryUploadRules(String[] filenames, String[] attrs, IProgressMonitor monitor) throws DMException {
        throw new UnsupportedOperationException("Cannot query upload rules for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus delete(DeleteItemRevisionRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Cannot delete items from baselines"); //$NON-NLS-1$
    }

    @Override
    public Map<String, List<ItemRevision>> expandItemRevisions(final List<ItemRevision> revisions, final int[] attrs,
            final IProgressMonitor monitor) throws DMException {
        if (revisions.isEmpty()) {
            return Collections.emptyMap();
        }

        // baselines contain exactly 1 revision of each item
        final Map<String, ItemRevision> baselineMemberMap = new HashMap<String, ItemRevision>();
        if (attrs != null && attrs.length > 0) {
            final Session session = getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    Set<Integer> set = new HashSet<Integer>();
                    set.add(new Integer(SystemAttributes.OBJECT_SPEC));
                    if (attrs != null) {
                        for (int i = 0; i < attrs.length; i++) {
                            set.add(new Integer(attrs[i]));
                        }
                    }
                    int[] attrsToQuery = new int[set.size()];
                    int cnt = 0;
                    for (Iterator<Integer> iter = set.iterator(); iter.hasNext();) {
                        Integer i = iter.next();
                        attrsToQuery[cnt++] = i.intValue();
                    }
                    Baseline bl = getBaseline();
                    List<ItemRevision> baselineMembers = getMemberFiles(bl, bl.getRootFolder(), true, attrsToQuery,
                            session.getObjectFactory(), monitor);
                    for (Iterator<ItemRevision> memberIter = baselineMembers.iterator(); memberIter.hasNext();) {
                        ItemRevision revision = memberIter.next();
                        String spec = (String) revision.getAttribute(SystemAttributes.OBJECT_SPEC);
                        Assert.isNotNull(spec);
                        String specId = TeamUtils.getItemSpecId(spec);
                        baselineMemberMap.put(specId, revision);
                    }
                }
            }, monitor);
        }

        Map<String, List<ItemRevision>> result = new HashMap<String, List<ItemRevision>>(revisions.size());
        for (Iterator<ItemRevision> iter = revisions.iterator(); iter.hasNext();) {
            ItemRevision inRevision = iter.next();
            String inSpec = (String) inRevision.getAttribute(SystemAttributes.OBJECT_SPEC);
            Assert.isNotNull(inSpec);
            String inSpecId = TeamUtils.getItemSpecId(inSpec);
            Assert.isNotNull(inSpecId);

            List<ItemRevision> list;
            if (baselineMemberMap.containsKey(inSpecId)) {
                list = Collections.singletonList(baselineMemberMap.get(inSpec));
            } else {
                list = Collections.emptyList();
            }
            result.put(inSpecId, list);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<DimensionsArObject> fetchMembers(final RepositoryFolder folder, final int types, final int[] attrs,
            final boolean recursive, IProgressMonitor monitor) throws DMException {
        final boolean includeFiles = (IResource.FILE & types) != 0;
        final boolean includeFolders = (IResource.FOLDER & types) != 0;
        if (!includeFiles && !includeFolders) {
            return Collections.emptyList();
        }
        monitor = Utils.monitorFor(monitor);
        final Session session = getConnection().openSession(null);
        final List<DimensionsArObject>[] fetchedMembersHolder = new List[1];

        session.run(new SessionRunnableWithProgress(monitor) {

            @Override
            public void run() throws Exception {
                try {
                    List<RepositoryFolder> memberFolders = Collections.emptyList();
                    List<ItemRevision> memberFiles = Collections.emptyList();
                    progress.beginTask(null, 500);
                    if (includeFolders) {
                        if (recursive) {
                            memberFolders = folder.getAllChildFolders();
                            removeFolderFromList(folder, memberFolders); // folder itself is in the returned recursive list!
                        } else {
                            memberFolders = folder.getImmediateChildFolders();
                        }
                    }
                    progress.worked(200);
                    if (includeFiles) {
                        memberFiles = getMemberFiles(getDimensionsObject(), folder, recursive, attrs, session.getObjectFactory(),
                                Utils.subMonitorFor(progress, 300));
                    } else {
                        progress.worked(300);
                    }
                    fetchedMembersHolder[0] = new ArrayList<DimensionsArObject>(memberFolders.size() + memberFiles.size());
                    fetchedMembersHolder[0].addAll(memberFolders);
                    fetchedMembersHolder[0].addAll(memberFiles);
                } finally {
                    progress.done();
                }
            }
        }, monitor);
        return fetchedMembersHolder[0];
    }

    @SuppressWarnings("unchecked")
    private List<ItemRevision> getMemberFiles(DimensionsLcObject projectObj, RepositoryFolder from, boolean recursive, int[] attrs,
            DimensionsObjectFactory factory, IProgressMonitor monitor) {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        try {
            Filter filter = new Filter();
            if (!isBaseline()) {
                filter.criteria().add(FAST_LATEST_CRITERION);
            }
            if (recursive) {
                filter.criteria().add(FAST_RECURSIVE_CRITERION);
            }

            List<ItemRevision> revisions;
            from.flushRelatedObjects(ItemRevision.class, true);
            revisions = from.getLatestItemRevisions(filter);
            from.flushRelatedObjects(ItemRevision.class, true);

            monitor.worked(60);
            if (attrs != null && attrs.length > 0 && !revisions.isEmpty()) {
                Utils.queryAttributes(revisions, initDefaultAttributes(attrs), factory, true);
            }
            monitor.worked(40);
            return revisions;
        } finally {
            monitor.done();
        }
    }

    @Override
    public IStatus upload(OperationData commandData, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Upload is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus deliver(TransferToStreamOperationData commandData, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Deliver is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus createDirectories(CreateFolderRequest[] dirs, IProgressMonitor monitor) throws DMException {
        throw new UnsupportedOperationException("Create directory is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus deleteDirectories(DeleteFolderRequest[] dirs, boolean deleteLocal, IProgressMonitor monitor) throws DMException {
        throw new UnsupportedOperationException("Delete directory is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus updateFilename(UpdateFilenameRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Move is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus importFiles(ImportRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Import is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus resolveConflicts(ResolveConflictRequest[] conflicts, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Resolve conflicts is unsupported for baselines"); //$NON-NLS-1$
    }

    @Override
    public IStatus move(IMoveRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException("Move is unsupported for baselines"); //$NON-NLS-1$
    }
    
    @Override
    protected void sessionDestroyed() {
        rootFolder = null;
        baseline = null;
    }

    @Override
    public boolean getIsStream() {
        return false;
    }

}

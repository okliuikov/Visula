/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.SortedSet;
import java.util.TreeSet;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.team.core.TeamException;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Workspace commands support multiple resources and bulk mode
 * should be used whenever possible.
 *
 * <P>
 * Value returned from <code>modifiesRemote()</code> controls remote tree refresh that occurs after command is executed.
 *
 * @author V.Grishchenko
 */
abstract class DMWorkspaceCommand1 extends DMWorkspaceBaseCommand1 {
    private CollectFilesStatsCallback fileStats = new CollectFilesStatsCallback();

    private IResource[] changes;
    private IResource[] resources;
    private IResource[] toRefresh;

    private SortedSet<IResource> rawToRefresh;
    private SortedSet<IResource> rawRules;

    protected DMProject dmProject;
    protected WorkspaceResourceRequest[] requests;

    /**
     * Creates a new command.
     *
     * @param dmProject
     * @param requests
     */
    DMWorkspaceCommand1(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        Assert.isNotNull(dmProject);
        Assert.isNotNull(requests);
        this.dmProject = dmProject;
        this.requests = requests;
        init();
    }

    private void init() {
        this.rawRules = new TreeSet<IResource>(new ContainmentComparator());
        this.rawToRefresh = new TreeSet<IResource>(new ContainmentComparator());
        this.resources = new IResource[requests.length];
        if (requests.length > 0) {
            for (int i = 0; i < requests.length; i++) {
                IResource resource = requests[i].getResource();
                resources[i] = resource;

                // init scheduling rule
                addSchedulingRule(rawRules, requests[i]);

                // add resource to raw refresh list
                addResourceToRefresh(rawToRefresh, requests[i]);
            }
        }
    }

    /**
     * Creates rules from change request and add them to rules collection. Clients can override this
     * method to customize rule creation.
     *
     * @param rules
     *            cache of rules that were produced from change requests
     * @param request
     *            change request that is a source for new rule
     */
    protected void addSchedulingRule(SortedSet<IResource> rules, WorkspaceResourceRequest request) {
        IResource resource = request.getResource();
        IResource ruleCandidate = TeamUtils.parent(resource);
        try {
            rules.add(TeamUtils.findDeepestManagedResource(ruleCandidate));
        } catch (TeamException e) {
            rules.add(ruleCandidate);
            DMTeamPlugin.log(e.getStatus());
        }
    }

    /**
     * Find a resource candidate that will be refreshed after command execution. It's a resource
     * itself or highest unmanaged parent resource.
     *
     * @param toRefresh
     *            cache of resources that were produced from change requests
     * @param request
     *            change request
     * @throws TeamException
     */
    protected void addResourceToRefresh(SortedSet<IResource> toRefresh, WorkspaceResourceRequest request) {
        IResource resource = request.getResource();
        IResource parent = resource;

        try {
            while ((parent = TeamUtils.parent(parent)) != resource) {
                if (parent.getType() == IResource.ROOT || parent.getType() == IResource.PROJECT) {
                    toRefresh.add(resource);
                    return;
                }

                if (DMTeamPlugin.getWorkspace().isManaged(parent)) {
                    toRefresh.add(resource);
                    return;
                }

                resource = parent;
            }
        } catch (TeamException e) {
            toRefresh.add(resource);
            DMTeamPlugin.log(e.getStatus());
        }
    }

    /**
     * @return sorted tree of all resources that take part in command execution. Resources contained
     *         deeper in the workspace are considered to be greater than the ones above them.
     * @throws TeamException
     */
    protected IResource[] getResources() {
        Assert.isNotNull(resources);
        return resources;
    }

    /**
     * Answers a scheduling rule for running this command on the current Eclipse workspace, this
     * implementation combines the closest ancestors of the command's resources that have metadata.
     *
     * @return scheduling rule
     * @throws CoreException
     */
    @Override
    public ISchedulingRule getSchedulingRule() throws CoreException {
        Assert.isNotNull(rawRules);
        return new MultiRule(TeamUtils.getNonOverlapping(rawRules));
    }

    /**
     * @return resources for which to refresh base tree
     */
    @Override
    public IResource[] getBaseResourcesToRefresh() {
        Assert.isNotNull(rawToRefresh);
        if (toRefresh == null) {
            this.toRefresh = TeamUtils.getNonOverlappingWithStats(rawToRefresh, fileStats);

            // to many single files
            if (fileStats.isStatsLimitReached()) {
                this.toRefresh = new IResource[] { dmProject.getRoot() };
            }
        }
        return toRefresh;
    }

    /**
     * @return resources for which to refresh remote tree
     */
    @Override
    public IResource[] getResourcesToRefresh() {
        Assert.isNotNull(rawToRefresh);
        if (toRefresh == null) {
            this.toRefresh = TeamUtils.getNonOverlappingWithStats(rawToRefresh, fileStats);

            // to many single files
            if (fileStats.isStatsLimitReached()) {
                this.toRefresh = new IResource[] { dmProject.getRoot() };
            }

        }
        return toRefresh;
    }

    @Override
    public boolean isValidSharing() throws CoreException {
        return dmProject.equals(getWorkspace().getProject(dmProject.getProject()));
    }

    @Override
    public boolean modifiesBase() {
        for (int i = 0; i < requests.length; i++) {
            if (requests[i].modifiesMetadata()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean modifiesRemote() {
        return false;
    }

    @Override
    public IResource[] getChanges() {
        return changes;
    }

    @Override
    public void setChanges(IResource[] changes) {
        this.changes = changes;
    }

}

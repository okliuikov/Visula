/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
class DMWorkspaceFile extends DMWorkspaceResource implements IDMWorkspaceFile { 
    private WorkspaceResourceStatus status;

    /**
     * @param resource
     *            the resource from workspace project
     * @param project
     *            the dimensions project which is mapped to the workspace project
     * @param virtualResource
     *            the original resource that is relative to the {@link VirtualIdmProject} or null
     */
    public DMWorkspaceFile(IResource resource, IDMProject project, IResource virtualResource) {
        super(resource, project, virtualResource);
    }

    @Override
    public void accept(IDMResourceVisitor visitor) throws CoreException {
        visitor.visit(this);
    }

    @Override
    public IDMRemoteFile getBaseFile() throws TeamException {
        IDMRemoteResource res = getBaseResource();
        if (res instanceof IDMRemoteFile) {
            return (IDMRemoteFile) res;
        }
        return null;
    }

    @Override
    public IDMRemoteFile getRemoteFile() throws TeamException {
        IDMRemoteResource res = getRemoteResource();
        if (res instanceof IDMRemoteFile) {
            return (IDMRemoteFile) res;
        }
        return null;
    }

    @Override
    public IFile getLocalFile() {
        return (IFile) getLocalResource();
    }

    @Override
    public boolean isRemoteModified() throws TeamException {
        SyncInfo syncInfo = DMTeamPlugin.getWorkspace().getSubscriber().getSyncInfo(getLocalResource());
        if (syncInfo != null) {
            return (syncInfo.getKind() & SyncInfo.INCOMING) != 0;
        }
        return false;
    }

    @Override
    public boolean isExtracted() throws TeamException {
        IDMRemoteFile base = getBaseFile();
        if (base == null) {
            return false;
        }
        return base.isExtracted();
    }

    @Override
    public boolean isExtractedOther() throws TeamException {
        IDMRemoteFile remote = getRemoteFile();
        if (remote == null) {
            return false;
        }
        return remote.isExtractedOther();
    }

    @Override
    public boolean isAnyExtracted() throws TeamException {
        IDMRemoteFile remote = getRemoteFile();
        if (remote == null) {
            return false;
        }
        return remote.isAnyExtracted();
    }

    @Override
    public boolean isMultiExtracted() throws TeamException {
        IDMRemoteFile remote = getRemoteFile();
        if (remote == null) {
            return false;
        }
        return remote.isMultiExtracted();
    }

    @Override
    public boolean isExtractedExclusive() throws TeamException {
        IDMRemoteFile remote = getRemoteFile();
        if (remote == null) {
            return false;
        }
        return remote.isExtractedExclusive();
    }

    public boolean isReadOnly() {
        return TeamUtils.isReadOnly(getLocalResource());
    }

    @Override
    public boolean isOptimistic() throws TeamException {
        IDMProject project;
        try {
            project = DMTeamPlugin.getWorkspace().getProject(getLocalResource());
            if (project.getIsStream()) {
                return isModified() && isManaged() && !isExtracted();
            }
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
        return !isReadOnly() && isManaged() && !isExtracted();
    }

    @Override
    public boolean isPessimistic() throws TeamException {
        return isReadOnly() && isManaged() && !isExtracted();
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    @Override
    public long getModtime() {
        return getLocalResource().getLocalTimeStamp();
    }

    @Override
    public WorkspaceResourceStatus getStatus(MetadataProvider provider) throws TeamException {
        if (status == null) {

            status = WorkspaceResourceStatus.createStatus(getLocalResource(), getBaseFile(), getRemoteFile(), provider);

            if (getProject().getIsStream()) {
                ResourceAttributes resAttributes = getLocalResource().getResourceAttributes();
                if (resAttributes != null && isLockedOther() && !isReadOnly() && !isModified()) {
                    try {
                        resAttributes.setReadOnly(true);
                        getLocalResource().setResourceAttributes(resAttributes);
                        // on mac need to turn off immutable
                        TeamUtils.makeMutable(getLocalResource());
                    } catch (CoreException e) {
                        // failure is not an option
                    }
                } else if (resAttributes != null && !isLockedOther() && isReadOnly()) {
                    try {
                        resAttributes.setReadOnly(false);
                        getLocalResource().setResourceAttributes(resAttributes);
                    } catch (CoreException e) {
                        // failure is not an option
                    }
                }
            }
        }

        return status;
    }

    @Override
    public WorkspaceResourceStatus getStatus() throws TeamException {
        return getStatus(null);
    }

    @Override
    public void delete(IProgressMonitor monitor) throws CoreException {
        IFile localFile = getLocalFile();
        if (localFile.exists()) {
            localFile.delete(false /* force */, true /* keepHistory */, monitor);
            return;
        }
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1);
        monitor.worked(1);
        monitor.done();
    }

    @Override
    public void makeUnmodified() throws CoreException {
        if (!exists()) {
            return;
        }
        IDMRemoteFile base = getBaseFile();
        if (base != null) {
            long stamp = base.getModtime();
            IFile local = getLocalFile();
            boolean readOnly = local.isReadOnly();
            if (readOnly) {
                TeamUtils.setReadOnly(local, false);
            }
            local.setLocalTimeStamp(stamp);
            if (readOnly) {
                TeamUtils.setReadOnly(local, true);
            }
        }
    }

    @Override
    public boolean isModified() throws TeamException {
        IDMRemoteResource baseResource = getBaseResource();
        if (baseResource == null || !(baseResource instanceof IDMRemoteFile)) {
            return false;
        }
        return DMWorkspace.isFileModified(getLocalResource(), (IDMRemoteFile) baseResource);
    }

    @Override
    public boolean isLocked() throws TeamException {
        IDMRemoteFile remote = getRemoteFile();
        if (remote == null) {
            return false;
        }
        return remote.isLocked();
    }

    @Override
    public boolean isLockedOther() throws TeamException {
        IDMRemoteFile remote = getRemoteFile();
        if (remote == null) {
            return false;
        }
        return remote.isLockedOther();
    }

}

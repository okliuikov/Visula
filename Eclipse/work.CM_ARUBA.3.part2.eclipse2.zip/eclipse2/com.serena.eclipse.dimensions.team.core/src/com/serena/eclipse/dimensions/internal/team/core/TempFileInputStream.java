/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/*
 * Deletes temporary file on close.
 * @author V.Grishchenko
 */
/* public */class TempFileInputStream extends FileInputStream {
    private File tmpFile;

    /**
     * @param file
     * @throws java.io.FileNotFoundException
     */
    public TempFileInputStream(File tmpFile) throws FileNotFoundException {
        super(tmpFile);
        this.tmpFile = tmpFile;
    }

    /**
     * @param name
     * @throws java.io.FileNotFoundException
     */
    public TempFileInputStream(String name) throws FileNotFoundException {
        this(new File(name));
    }

    @Override
    public void close() throws IOException {
        try {
            super.close();
        } finally {
            tmpFile.delete();
        }
    }

}

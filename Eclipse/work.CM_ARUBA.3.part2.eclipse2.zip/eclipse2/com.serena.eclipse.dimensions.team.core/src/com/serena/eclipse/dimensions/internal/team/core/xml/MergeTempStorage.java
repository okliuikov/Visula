/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

import org.eclipse.compare.BufferedContent;
import org.eclipse.compare.CompareUI;
import org.eclipse.compare.IEditableContent;
import org.eclipse.compare.ITypedElement;
import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.graphics.Image;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;

/**
 * Storage of the temporary merged content
 */
public class MergeTempStorage extends BufferedContent implements ITypedElement, IEditableContent {

    private IFileStore fileStore;
    private IResource local;

    public MergeTempStorage(IFileStore fileStore, IResource local) {
        this.fileStore = fileStore;
        this.local = local;
    }

    @Override
    public boolean isEditable() {
        return true;
    }

    @Override
    public ITypedElement replace(ITypedElement dest, ITypedElement src) {
        return null;
    }

    @Override
    public String getName() {
        return local.getName();
    }

    @Override
    public Image getImage() {
        return CompareUI.getImage(getType());
    }

    @Override
    public String getType() {
        String name = getName();
        if (name != null) {
            int index = name.lastIndexOf('.');
            if (index == -1) {
                return ""; //$NON-NLS-1$
            }
            if (index == (name.length() - 1)) {
                return ""; //$NON-NLS-1$
            }
            return name.substring(index + 1);
        }
        return ITypedElement.FOLDER_TYPE;
    }

    @Override
    protected InputStream createStream() throws CoreException {
        return fileStore.openInputStream(EFS.NONE, new NullProgressMonitor());
    }

    @Override
    public void setContent(byte[] contents) {
        if (contents == null) {
            contents = new byte[0];
        }

        ByteBuffer buffer = ByteBuffer.wrap(contents);

        FileOutputStream out = null;
        try {
            out = (FileOutputStream) fileStore.openOutputStream(EFS.NONE, new NullProgressMonitor());
            if (out != null) {
                out.getChannel().write(buffer);
                out.getChannel().force(false);
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        } catch (IOException e) {
            DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, e.getMessage()));
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    DMTeamPlugin.log(new Status(IStatus.ERROR, DMTeamPlugin.ID, e.getMessage()));
                }
            }
        }
        super.setContent(contents);
    }

}

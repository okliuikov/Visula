/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.team.core.variants.CachedResourceVariant;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * @author V.Grishchenko
 */
abstract class DMResourceVariant extends CachedResourceVariant {
    private DimensionsConnectionDetailsEx connection;
    private byte[] bytes;

    /**
     *
     */
    public DMResourceVariant(DimensionsConnectionDetailsEx connection) {
        this.connection = connection;
    }

    /**
     * @return Returns the connection.
     */
    public DimensionsConnectionDetailsEx getConnection() {
        return connection;
    }

    @Override
    protected String getCachePath() {
        StringBuffer cachePath = new StringBuffer(connection.getServer());
        cachePath = cachePath.append('/').append(connection.getDbConn());
        cachePath = cachePath.append('/').append(connection.getDbName());
        cachePath = cachePath.append('/').append(getContentIdentifier());
        return cachePath.toString();
    }

    @Override
    protected String getCacheId() {
        return DMTeamPlugin.ID;
    }

    @Override
    public byte[] asBytes() {
        if (bytes == null) {
            bytes = toBytes();
        }
        return bytes;
    }

    protected abstract byte[] toBytes();

}

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ISchedulingRule;

import com.serena.dmclient.api.DownloadCommandDetails;
import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;

public class RehomeCommand extends DMWorkspaceBaseCommand1 {

    private WorksetAdapter targetStream;
    private List<IDMProject> projectsToRehome;
    
    public RehomeCommand(List<IDMProject> projectsToRehome, WorksetAdapter targetStream) throws DMException {
    	if (projectsToRehome == null || projectsToRehome.size() == 0) {
    			throw new DMException(new Status(IStatus.ERROR, DMTeamPlugin.ID, Messages.ProjectsToRehomeNotSpecified));
    	}
    	this.projectsToRehome = projectsToRehome;
        this.targetStream = targetStream;
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
    	
    	IDMProject firstProject = projectsToRehome.get(0);
    	String wa = firstProject.getUserDirectory().toOSString();
    	final StateRehomeMonitor rehomeMonitor = new StateRehomeMonitor(Utils.monitorFor(monitor));
        DownloadCommandDetails dcd = new DownloadCommandDetails();
        dcd.setUserDirectory(wa);
        if (firstProject.isContainedEclipseProject() && !firstProject.isFullWorkArea()) {
            dcd.setRelativeLocation(firstProject.getRemoteOffset().toOSString());
        } else {
            dcd.setDirectory(TeamUtils.calculateCommonOffset(projectsToRehome));
        }
        dcd.setTouch(Boolean.FALSE);
        dcd.setOverwrite(Boolean.FALSE);
        dcd.setCheckConflict(Boolean.FALSE);
        dcd.setExpand(TeamUtils.isExpandSubstitution());
        dcd.setRehome(Boolean.TRUE);
        dcd.setQuiet(Boolean.TRUE);
        dcd.setListener(rehomeMonitor);
        dcd.setTopicStreamSpec(targetStream.getObjectSpec());

        Project project = (Project) firstProject.getDimensionsObject();
        project.download(dcd);
    }

    @Override
    public ISchedulingRule getSchedulingRule() throws CoreException {
        return null;
    }

    @Override
    public boolean isValidSharing() throws CoreException {
        return false;
    }

    @Override
    public boolean modifiesBase() {
        return false;
    }

    @Override
    public boolean modifiesRemote() {
        return false;
    }

    @Override
    public IResource[] getChanges() {
        return null;
    }

    @Override
    public void setChanges(IResource[] changes) {
    }

    @Override
    public IResource[] getBaseResourcesToRefresh() throws CoreException {
        return null;
    }

    @Override
    public IResource[] getResourcesToRefresh() throws CoreException {
        return null;
    }
}

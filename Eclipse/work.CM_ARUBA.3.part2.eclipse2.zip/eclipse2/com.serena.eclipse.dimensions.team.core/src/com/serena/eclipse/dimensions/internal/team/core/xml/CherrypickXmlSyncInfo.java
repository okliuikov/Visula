package com.serena.eclipse.dimensions.internal.team.core.xml;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;

import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.dmfile.xml.Resolution;
import com.serena.dmfile.xml.utility.NonConsecutiveCherrypickUtility;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/***
 * XmlSyncInfo implementation for resolving non-consecutive resolutions during cherrypick.
 * 
 * @author apitukh
 * 
 */
public class CherrypickXmlSyncInfo extends XMLSyncInfo {

    CherrypickXmlSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote, IResourceVariantComparator comparator,
            Subscriber subscriber, DimensionsConnectionDetailsEx connecion) {
        super(local, base, remote, comparator, subscriber, connecion);
        this.resolutionsToIgnore = new ArrayList<Resolution>();
    }

    private Resolution lastRevisionResolution;
    private List<Resolution> resolutionsToIgnore;

    @Override
    protected String getMergedFilePath() {
        Resolution resolutionWithMergedFile = NonConsecutiveCherrypickUtility.getMostRecentResolution(resolution);
        return resolutionWithMergedFile.getMergedFile();
    }

    @Override
    public void setResolution(Resolution resolution) {
        super.setResolution(resolution);
        while (!resolution.isLeaf()) {
            resolutionsToIgnore.add(resolution);
            resolution = resolution.getChildResolution();
        }
        lastRevisionResolution = resolution;
    }

    @Override
    protected void initActions() throws CoreException {
        // Fill root specific actions
        List<Integer> rootSpecificActions = new ArrayList<Integer>();
        if (resolution.getDefaultAction() != null) {
            rootSpecificActions.add(resolution.getDefaultAction());
        }
        if (resolution.getActions() != null) {
            rootSpecificActions.addAll(resolution.getActions());
        }

        // Fill last revision specific actions
        List<Integer> lastRevisionSpecificActions = new ArrayList<Integer>();
        if (lastRevisionResolution.getDefaultAction() != null) {
            lastRevisionSpecificActions.add(lastRevisionResolution.getDefaultAction());
        }
        if (lastRevisionResolution.getActions() != null) {
            lastRevisionSpecificActions.addAll(lastRevisionResolution.getActions());
        }

        // Fill common (merged) actions
        Integer defaultAction = mergeActions(resolution.getDefaultAction(), lastRevisionResolution.getDefaultAction());
        
        List<Integer> actions = mergeActions(rootSpecificActions, lastRevisionSpecificActions);
        setActions(actions);
        
        if (defaultAction != null) {
            setDefaultAction(defaultAction);
        } else {
            setCurrentAction(XSyncUserAction.SUAL_UNRESOLVED.value());
            String mstr = getMergedFilePath();
            File mergedFile = null;
            if (mstr != null && (mergedFile = new File(mstr)).exists()) {
                IFileStore store = EFS.getStore(mergedFile.toURI());
                descriptor.addTempStore(this, store);
            }
        }
    }

    public Resolution getLastRevisionResolution() {
        return lastRevisionResolution;
    }

    public List<Resolution> getResolutionsToIgnore() {
        return resolutionsToIgnore;
    }

    private static List<Integer> mergeActions(List<Integer> actionsForPathConflicts, List<Integer> actionsForContentConflicts) {
        if (actionsForPathConflicts == null && actionsForContentConflicts == null) {
            return Collections.emptyList();
        }
        if (actionsForPathConflicts == null) {
            return actionsForContentConflicts;
        }
        if (actionsForContentConflicts == null) {
            return actionsForPathConflicts;
        }
        boolean hasContentConflicts = false;
        for (Integer actionForContentConflict : actionsForContentConflicts) {
            if (isContentConflict(actionForContentConflict)) {
                hasContentConflicts = true;
                break;
            }
        }
        boolean hasPathConflicts = false;
        for (Integer actionForPathConflict : actionsForPathConflicts) {
            if (isPathConflict(actionForPathConflict)) {
                hasPathConflicts = true;
                break;
            }
        }
        Set<Integer> mergedActions = new HashSet<Integer>();
        if (hasContentConflicts && hasPathConflicts) {
            // Merge actions
            for (Integer actionForContentConflict : actionsForContentConflicts) {
                if (isContentConflict(actionForContentConflict)) {
                    for (Integer actionForPathConflict : actionsForPathConflicts) {
                        if (isPathConflict(actionForPathConflict)) {
                            mergedActions.add(actionForPathConflict | actionForContentConflict);
                        } else {
                            mergedActions.add(actionForPathConflict);
                        }
                    }
                } else {
                    mergedActions.add(actionForContentConflict);
                }
            }
        } else {
            // Do not merge actions
            mergedActions.addAll(actionsForContentConflicts);
            mergedActions.addAll(actionsForPathConflicts);
        }
        return new ArrayList<Integer>(mergedActions);
    }

    private static boolean isPathConflict(int action) {
        if (((action & XSyncUserAction.SUAO_USE_LOCAL_PATH.value()) != 0)
                || ((action & XSyncUserAction.SUAO_USE_REPOSITORY_PATH.value()) != 0)) {
            return true;
        }
        return false;
    }

    private static boolean isContentConflict(int action) {
        if (((action & XSyncUserAction.SUAL_MERGE.value()) != 0) || ((action & XSyncUserAction.SUAL_USE_LOCAL.value()) != 0)
                || ((action & XSyncUserAction.SUAL_USE_REPOSITORY.value()) != 0)) {
            return true;
        }
        return false;
    }

    private static Integer mergeActions(Integer action1, Integer action2) {
        if (action1 == null && action2 == null) {
            return null;
        }
        if (action1 == null) {
            return action2;
        }
        if (action2 == null) {
            return action1;
        }
        return action1 | action2;
    }

}

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;

import com.serena.dmclient.api.DeliverCommandDetails;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.DownloadCommandDetails;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionLocationDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.FileToTransfer;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.IDMConsoleListener;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

public class ProjectRenamer { 

    private List<String> requests;

    ProjectRenamer() {
    }

    public static DimensionsResult doRename(IDMProject dstProject, IResource src, IResource dst, List<String> changeRequests,
            IProgressMonitor monitor) throws Exception {
        IPath offsetPath = dstProject.getRemotePathForLocalResource(src); // remote project path for local resource name

        IPath newOffsetPath = offsetPath;
        if (offsetPath.lastSegment().equals(dstProject.getIdeProjectName())) {
            newOffsetPath = offsetPath.removeLastSegments(1).append(dst.getName());
        }

        ProjectRenamer pr = new ProjectRenamer();
        pr.setChangeRequests(changeRequests);
        DimensionsResult result = pr.renameProject(dstProject, src, dst, monitor);

        pr.dmProjectRenamed(dstProject, dst, newOffsetPath);
        // do this to unregister project move on base tree refreshing
        DMBaseResourceVariantTree baseTree = (DMBaseResourceVariantTree) getWorkspace().getBaseTree();
        ((PersistentByteStore) baseTree.getByteStore()).flushBytes(dst, IResource.DEPTH_ZERO, true);

        pr.treeMoved((IContainer) dst);

        // KB>Temporary fix of .project delivering issue - this should be fixed in MORE NEAT WAY!!
        dstProject.getConnection().destroySession();
        dstProject.getConnection().openSessionDirect(Utils.monitorFor(null));
        return result;
    }

    private DimensionsResult renameProject(IDMProject dstProject, IResource src, IResource dst, IProgressMonitor monitor)
            throws DMException, Exception {
        ItemRevision markerRev = getMarkerRevision(dstProject, monitor);

        DimensionsResult result = null;

        // example conditions: suppose we want to rename project 'source' to 'target' with offset a/b/c
        // comments below for every variable declaration after 'example:' will contain values according to example conditions

        // example: source // assume that it always equals to ide project name
        final IPath oldMarkerFileName = new Path(dstProject.getIdeProjectName());
        final IPath newMarkerFileName = new Path(dst.getName()); // example: target

        // example: source.ecl
        final IPath oldMarkerFileNameWithExt = oldMarkerFileName.addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);
        // example: target.ecl
        final IPath newMarkerFileNameWithExt = newMarkerFileName.addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);

        final IPath oldProjectName = new Path(src.getName()); // example: c
        final IPath newProjectName = new Path(dst.getName()); // example: target

        // example: a/b/c (remote offset can be not equal to project name like in this example case)
        final IPath oldProjectOffset = dstProject.getRemoteOffset();
        // local path of project (example: d:/workspace/projectpath/)
        final IPath projectUserDirectory = dstProject.getUserDirectory();

        if (dstProject.isFullWorkArea()) {
            // this is "full workarea case" (means that project was fetched by other client than eclipse plugin and than
            // autoshared by eclipse in this case we always rename containing folder and deliver it
            final IPath newProjectOffset = oldProjectOffset.removeLastSegments(1).append(newProjectName); // example: a/b/target
            final IPath oldFolderPath = projectUserDirectory.append(oldProjectOffset); // example: d:/workspace/projectpath/a/b/c
            // example: d:/workspace/projectpath/a/b/target
            final IPath newFolderPath = projectUserDirectory.append(newProjectOffset);
            // example: d:/workspace/projectpath/a/b/target/target.ecl
            final IPath newLocalMarkerFilePath = newFolderPath.append(newMarkerFileNameWithExt);

            renameLocalMarkerFileAndSetAttributes(dstProject, oldMarkerFileNameWithExt, newMarkerFileNameWithExt);
            writeMovedFromMDForFolder(dstProject, oldFolderPath, newFolderPath, newProjectOffset, oldProjectOffset);
            result = deliverFWA(newFolderPath, newLocalMarkerFilePath, dstProject, result);
            IResource resMoved = dstProject.getProject().findMember(newMarkerFileNameWithExt);
            if (resMoved != null) {
                resourceMoved(resMoved, true);
            }
        } else {
            // this is "non full workarea case" (means that project was fetched from Serena Explorer by eclipse plugin)
            // in this case we deliver containing folder only if it name equals to source project (it's no in example)

            // if remote offset consists more than
            final boolean additionalOffset = dstProject.getRemoteOffset().segments().length > 1;
            // from one segment (like a/b/c)

            final boolean remoteOffsetEndsLikeProjName = oldProjectOffset.lastSegment()
                    .equals(oldMarkerFileName.toOSString());
            IPath newProjectTempFolder = null;
            IPath tempNewMarkerFilePath = null;
            try {
                newProjectTempFolder = createTempProjectDirAndSetMD(oldProjectName, newProjectName,
                        remoteOffsetEndsLikeProjName);
                result = downloadMarkerFileToTempDir(dstProject, newProjectTempFolder, markerRev, oldMarkerFileNameWithExt,
                        result, monitor);
                tempNewMarkerFilePath = renameTempMarkerFileAndSetMd(oldMarkerFileName, newProjectName,
                        newProjectTempFolder);

                if (tempNewMarkerFilePath != null && newProjectTempFolder != null) {
                    result = deliverTempMarkerFile(newMarkerFileNameWithExt, oldMarkerFileNameWithExt, tempNewMarkerFilePath,
                            dstProject, newProjectName, newProjectTempFolder, result, remoteOffsetEndsLikeProjName,
                            additionalOffset);
                }

                // example: d:/workspace/projectpath/source.ecl
                final IPath localOldMakerFilePath = projectUserDirectory.append(oldMarkerFileNameWithExt);
                // example: d:/workspace/projectpath/target.ecl
                final IPath localNewMakerFilePath = projectUserDirectory.append(newMarkerFileNameWithExt);

                setLocalMarkerFileMD(dstProject, localOldMakerFilePath, localNewMakerFilePath, tempNewMarkerFilePath);
                renameLocalMarkerFile(dstProject, localOldMakerFilePath, localNewMakerFilePath);
            } finally {
                cleanupTempFilesAndMd(new IPath[] { tempNewMarkerFilePath, newProjectTempFolder });
            }
        }
        return result;
    }

    private void writeMovedFromMDForFolder(IDMProject dstProject, IPath srcProjPath, IPath dstProjPath, IPath newRelPath,
            IPath movedFrom) throws CoreException {
        WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();

        BaseMetadata sourceMetadata = metaMan.getMetadata(srcProjPath);
        BaseMetadata targetMetadata = metaMan.getMetadata(dstProjPath);
        if (sourceMetadata != null) {
            if (targetMetadata != null) {
                metaMan.deleteMetadata(dstProjPath, WorkspaceMetadataManager.DELETE_ALL);
            }
            ((DirectoryMetadata) sourceMetadata).setMovedFrom(movedFrom.toOSString());
            ((DirectoryMetadata) sourceMetadata).setRelPath(newRelPath.toOSString());
            metaMan.deleteMetadata(srcProjPath, WorkspaceMetadataManager.DELETE_ALL);

            metaMan.updateMetadata(dstProjPath, sourceMetadata);
        }
    }

    private void renameLocalMarkerFileAndSetAttributes(IDMProject dstProject, IPath oldMarkerFileNameWithExt,
            IPath newMarkerFileNameWithExt) throws Exception {
        // make marker file writable and move it
        IResource markerFileResource = dstProject.getProject().findMember(oldMarkerFileNameWithExt);
        if (!dstProject.getIsStream()) {
            TeamUtils.setReadOnly(markerFileResource, false);
        }
        // MoveDeleteHook changes state of marker file to "moved" here
        markerFileResource.move(newMarkerFileNameWithExt, true, null);

        markerFileResource = dstProject.getProject().findMember(newMarkerFileNameWithExt);
        hideMarkerFile(markerFileResource, !dstProject.getIsStream());
    }

    private DimensionsResult deliverFWA(IPath newFolderPath, IPath newMarkerFilename, IDMProject dstProject,
            DimensionsResult result) throws DMException {
        // deliver moved marker file and folder
        DeliverCommandDetails deliverDetails = new DeliverCommandDetails();
        ArrayList<FileToTransfer> filesToDeliver = new ArrayList<FileToTransfer>();
        FileToTransfer markerFTU = null;

        markerFTU = ObjectToTransfer.scanSingleFileEx(newFolderPath.toOSString()); // full path to folder
        filesToDeliver.add(markerFTU);

        markerFTU = ObjectToTransfer.scanSingleFile(newMarkerFilename.toOSString()); // full path to ecl file
        filesToDeliver.add(markerFTU);

        deliverDetails.setFilesToTransfer(filesToDeliver);
        deliverDetails.setUserDirectory(dstProject.getUserDirectory().toOSString());
        deliverDetails.setVerbose(Boolean.TRUE);
        deliverDetails.setXmlMode(Boolean.TRUE);
        deliverDetails.setXmlExecute(Boolean.TRUE);
        deliverDetails.setRelatedRequests(getChangeRequests());

        try {
            result = ((Project) dstProject.getDimensionsObject()).deliver(deliverDetails);
        } catch (Throwable e) {
            System.out.println();
        }
        @SuppressWarnings("unchecked")
        Iterator<FileToTransfer> iter = result.getResultList().iterator();
        while (iter.hasNext()) {
            getConsole().printMessage(iter.next().getMessage());
        }
        return result;
    }

    private void renameLocalMarkerFile(IDMProject dstProject, IPath wsMarkerFilePath, IPath newWsMarkerFilePath)
            throws CoreException {
        File markerFile = new File(wsMarkerFilePath.toOSString());
        markerFile.renameTo(new File(newWsMarkerFilePath.toOSString()));
        IResource res = dstProject.getProject().findMember(wsMarkerFilePath.lastSegment());
        if (res != null) {
            getWorkspace().releaseBase(res);
        }
        TeamUtils.refreshLocal(dstProject.getProject(), IResource.DEPTH_ONE, null);

        IResource markerFileResource = dstProject.getProject().findMember(newWsMarkerFilePath.lastSegment());
        hideMarkerFile(markerFileResource, false);
    }

    private void setLocalMarkerFileMD(IDMProject dstProject, IPath wsOldMarkerFilePath, IPath wsNewMarkerFilePath,
            IPath newTempMarkerFilePath) throws CoreException {
        WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();
        BaseMetadata tempMarkerFileMetadata = metaMan.getMetadata(newTempMarkerFilePath);
        BaseMetadata targetMetadata = metaMan.getMetadata(wsOldMarkerFilePath);

        if (tempMarkerFileMetadata != null) {
            if (targetMetadata != null) {
                metaMan.deleteMetadata(wsOldMarkerFilePath, WorkspaceMetadataManager.DELETE_ALL);
            }

            metaMan.updateMetadata(wsNewMarkerFilePath, tempMarkerFileMetadata);
        }
    }

    private IPath renameTempMarkerFileAndSetMd(IPath oldMarkerFilename, IPath newMarkerFilename, IPath markerFileLocation)
            throws Exception {
        IPath oldMarker = markerFileLocation.append(oldMarkerFilename)
                .addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);
        IPath newMarker = markerFileLocation.append(newMarkerFilename)
                .addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);

        java.io.File localMarkerFile = new File(oldMarker.toOSString());
        java.io.File newLocalMarkerFile = new File(newMarker.toOSString());

        WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();
        BaseMetadata sourceMetadata = metaMan.getMetadata(oldMarker);
        BaseMetadata targetMetadata = metaMan.getMetadata(newMarker);
        if (sourceMetadata != null) {
            if (targetMetadata != null) { // discard old md if any
                metaMan.deleteMetadata(newMarker, WorkspaceMetadataManager.DELETE_ALL);
            }

            ((ItemMetadata) sourceMetadata).setMovedFrom(oldMarkerFilename.toOSString());
            ((ItemMetadata) sourceMetadata).setRelPath(newMarkerFilename.toOSString());

            metaMan.deleteMetadata(oldMarker, WorkspaceMetadataManager.DELETE_ALL);
            if (!localMarkerFile.renameTo(newLocalMarkerFile)) {
                // last resort
                localMarkerFile.delete();
                newLocalMarkerFile.createNewFile();
                if (!newLocalMarkerFile.exists()) {
                    return null;
                }
            }
            metaMan.updateMetadata(newMarker, sourceMetadata);
        } else {
            return null;
        }
        return newMarker;
    }

    private IPath createTempProjectDirAndSetMD(IPath oldProjectName, IPath newProjectName, boolean setFolderMdToMovedState)
            throws CoreException {
        IPath projectTempFolderPath = getTempDirectory().append(setFolderMdToMovedState ? newProjectName : oldProjectName);
        java.io.File newProjectFolder = new File(projectTempFolderPath.toOSString());

        if (!newProjectFolder.mkdirs() && !newProjectFolder.exists()) {
            return null;
        }
        if (setFolderMdToMovedState) {
            DirectoryMetadata dirMeta = new DirectoryMetadata();
            dirMeta.setMovedFrom(oldProjectName.toOSString());
            dirMeta.setRelPath(newProjectName.toOSString());

            WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();
            if (metaMan.deleteMetadata(projectTempFolderPath, WorkspaceMetadataManager.DELETE)) {
                metaMan.createDirectoryMetadata(projectTempFolderPath, dirMeta);
            } else {
                metaMan.updateMetadata(projectTempFolderPath, dirMeta);
            }
        }
        return projectTempFolderPath;
    }

    private void cleanupTempFilesAndMd(IPath[] paths) {
        for (int i = 0; i < paths.length; i++) {
            if (paths[i] != null) {
                try {
                    delete(new File(paths[i].toOSString()));
                } catch (IOException e) {
                    DMTeamPlugin.log(new Status(IStatus.WARNING, DMTeamPlugin.ID, e.getMessage()));
                }
            }
        }
        deleteTempMetadata();
    }

    private ItemRevision getMarkerRevision(IDMProject dstProject, IProgressMonitor monitor) throws DMException {
        IPath markerFilename = dstProject.getRemoteOffset()
                .append(dstProject.getIdeProjectName())
                .addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);
        ItemRevision markerRev = dstProject.fetchFile(markerFilename, null, true,
                Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
        return markerRev;
    }

    private DimensionsResult downloadMarkerFileToTempDir(IDMProject dstProject, IPath newProjectFolder,
            ItemRevision markerRev, IPath markerFilename, DimensionsResult result, IProgressMonitor monitor)
            throws DMException {

        TransferMonitor tMonitor = new TransferMonitor(Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN),
                TransferMonitor.UP);
        List<ItemRevisionLocationDetails> itemList = new ArrayList<ItemRevisionLocationDetails>();
        itemList.add(new ItemRevisionLocationDetails(markerRev, markerFilename.toOSString()));

        // download .ecl file from the stream project into temp dir
        DownloadCommandDetails dcd = new DownloadCommandDetails();
        dcd.setItemsToDownload(itemList);
        dcd.setUserDirectory(newProjectFolder.toOSString());
        dcd.setTouch(Boolean.FALSE);
        dcd.setExpand(Boolean.FALSE);
        dcd.setOverwrite(Boolean.TRUE);
        dcd.setCheckConflict(Boolean.FALSE);
        dcd.setCancelMonitor(tMonitor);
        dcd.setListener(tMonitor);

        result = ((Project) dstProject.getDimensionsObject()).download(dcd);
        getConsole().printMessage(result.getMessage());
        return result;
    }

    private void hideMarkerFile(IResource markerFileResource, boolean setReadOnly) throws CoreException {
        if (markerFileResource != null && markerFileResource.exists()) {
            markerFileResource.setTeamPrivateMember(true);
            ResourceAttributes resourceAttributes = markerFileResource.getResourceAttributes();
            if (resourceAttributes != null) {
                resourceAttributes.setHidden(true);
                if (setReadOnly) {
                    resourceAttributes.setReadOnly(true);
                }
                markerFileResource.setResourceAttributes(resourceAttributes);
            }
        }
    }

    private DimensionsResult deliverTempMarkerFile(IPath newMarkerFilenameWithExt, IPath oldMakerFilenameWithExt,
            IPath newLocalMarkerFilePath, IDMProject dstProject, IPath newFolderName, IPath newProjectFolderPath,
            DimensionsResult result, boolean deliverFolder, boolean additionalOffset) throws DMException {

        DeliverCommandDetails deliverDetails = new DeliverCommandDetails();
        ArrayList<FileToTransfer> filesToDeliver = new ArrayList<FileToTransfer>();

        FileToTransfer markerFTU = null;
        if (deliverFolder) { // folder moved too
            markerFTU = ObjectToTransfer.scanSingleFileEx(newProjectFolderPath.toOSString());
            markerFTU.setRelPath(newFolderName.toOSString());
            filesToDeliver.add(markerFTU);
        }

        //
        // Depending on whether we want to deliver only marker file or marker file and containing folder
        // we must to set correct relPath, movedFrom and userDirectory variables.
        //
        // Examples:
        //
        // If deliverFolder==true:
        // relPath = renameddir/newmarker.ecl
        // movedFrom = renameddir/oldmarker.ecl
        // userDirectory = d:/workspace/projectpath/
        //
        // If deliverFolder==false:
        // relPath = newmarker.ecl
        // movedFrom = oldmarker.ecl
        // userDirectory = d:/workspace/projectpath/renameddir/
        //

        IPath relPath = deliverFolder ? (newFolderName.append(newMarkerFilenameWithExt)) : newMarkerFilenameWithExt;
        IPath movedFrom = deliverFolder ? (newFolderName.append(oldMakerFilenameWithExt)) : oldMakerFilenameWithExt;

        markerFTU = ObjectToTransfer.scanSingleFile(newLocalMarkerFilePath.toOSString());
        markerFTU.setRelPath(relPath.toOSString());
        markerFTU.setMovedFrom(movedFrom.toOSString());
        filesToDeliver.add(markerFTU);

        deliverDetails.setFilesToTransfer(filesToDeliver);

        IPath userDirectory = deliverFolder ? getTempDirectory() : newProjectFolderPath;
        deliverDetails.setUserDirectory(userDirectory.toOSString());

        deliverDetails.setVerbose(Boolean.TRUE);
        deliverDetails.setXmlMode(Boolean.TRUE);
        deliverDetails.setXmlExecute(Boolean.TRUE);

        if (additionalOffset && deliverFolder) {
            // if we deliver folder too and remote offset longer than one segment - reduce it (a/b/c -> a/b)
            deliverDetails.setRelativeLocation(dstProject.getRemoteOffset().removeLastSegments(1).toOSString());
        } else if (!deliverFolder) { // if we don't deliver folder set relative location to remote offset
            deliverDetails.setRelativeLocation(dstProject.getRemoteOffset().toOSString());
        }

        deliverDetails.setRelatedRequests(getChangeRequests());

        result = ((Project) dstProject.getDimensionsObject()).deliver(deliverDetails);

        @SuppressWarnings("unchecked")
        Iterator<FileToTransfer> iter = result.getResultList().iterator();

        while (iter.hasNext()) {
            getConsole().printMessage(iter.next().getMessage());
        }
        return result;
    }

    private void deleteTempMetadata() {
        File temp = new File(getTempDirectory().toOSString());
        MetadataProvider provider = MetadataProviderFactory.providerFor(temp);
        String mdDirname = null;
        try {
            mdDirname = provider.metadataDirname();
        } finally {
            if (provider != null) {
                provider.close();
            }
        }

        if (mdDirname != null) {
            try {
                delete(new File(temp, mdDirname));
            } catch (IOException e) {
                DMTeamPlugin.log(new Status(IStatus.WARNING, DMTeamPlugin.ID, e.getMessage()));
            }
        }
    }

    private IPath getTempDirectory() {
        return new Path(System.getProperty("java.io.tmpdir")); //$NON-NLS-1$
    }

    private IDMConsoleListener getConsole() {
        return DMPlugin.getDefault().getConsole();
    }

    private void resourceMoved(IResource resource, boolean releaseBase) throws CoreException {
        IResource source = getWorkspace().getMovedFrom(resource);
        if (source != null && releaseBase) {
            getWorkspace().releaseBase(source, false, IResource.DEPTH_ZERO, null);
        }
        if (discardMoveState(resource)) {
            IContainer parent = resource.getParent();
            if (parent.getType() != IResource.PROJECT) {
                resourceMoved(resource.getParent(), false);
            }
        }
    }

    private boolean discardMoveState(IResource resource) throws CoreException {
        if (resource.getType() == IResource.PROJECT) {
            return false;
        }
        BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
        if (metadata != null) {
            if (MoveDeleteHook.discardMovedState(metadata)) {
                WorkspaceMetadataManager.getInstance().updateMetadata(resource, metadata);
                return true;
            }
        }
        return false;
    }

    private static DMWorkspace getWorkspace() {
        return (DMWorkspace) DMTeamPlugin.getWorkspace();
    }

    void delete(File f) throws IOException {
        if (f.isDirectory()) {
            for (File c : f.listFiles()) {
                delete(c);
            }
        }
        if (!f.delete()) {
            throw new FileNotFoundException("Failed to delete file: " + f);//$NON-NLS-1$
        }
    }

    private List<String> getChangeRequests() {
        if (requests == null) {
            return Collections.emptyList();
        }
        return requests;
    }

    public void setChangeRequests(List<String> requests) {
        this.requests = requests;
    }

    private void dmProjectRenamed(IDMProject dstProject, IResource dst, IPath dstOffset) throws CoreException {
        dst.setPersistentProperty(DMRepositoryProvider.DM_PROJECT_MOVED_PROP, null);
        dst.setPersistentProperty(DMRepositoryProvider.REMOTE_OFFSET, dstOffset.toString());
        dst.setPersistentProperty(DMRepositoryProvider.IDE_PROJECT_NAME_PROP, dst.getName());

        ((DMProject) dstProject).setIdeProjectName(dst.getName());
        ((DMProject) dstProject).setRemoteOffset(dstOffset);
        // we do this to keep repository folder up-to-date and fetch from the right location
        // if remoteRoot==null it can be found by remote offset from the project child folders
        ((DMProject) dstProject).flushRemoteRoot();
    }

    private void treeMoved(IContainer root) throws CoreException {
        IResource source = DMTeamPlugin.getWorkspace().getMovedFrom(root);
        if (source != null) {
            getWorkspace().releaseBase(source, false, IResource.DEPTH_INFINITE, null); // purge base info for the whole tree
        }
        root.accept(new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                discardMoveState(resource);
                return true;
            }
        });
    }
}

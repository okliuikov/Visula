/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;

import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.StatusReference;
import com.serena.eclipse.dimensions.core.TypeReference;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public abstract class ItemRequest extends FileRequest {
    private ItemType itemType;
    private int options;
    private String typeName;
    private String productName;
    private TypeReference typeReference;
    private StatusReference statusReference;

    public ItemRequest(IFile file, ItemType itemType, boolean requestSupported, boolean requestMandatory) throws CoreException {
        super(file, requestSupported, requestMandatory);
        Assert.isNotNull(itemType);
        this.itemType = itemType;

        getConnection().openSession(null).run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                typeName = ItemRequest.this.itemType.getName();
                productName = ItemRequest.this.itemType.getProduct().getName();
                options = ItemRequest.this.itemType.getOptions();
            }
        }, new NullProgressMonitor());
    }

    public ItemType getType() {
        return itemType;
    }

    public int getItemTypeOptions() {
        return options;
    }

    /**
     * @return Returns the typeName.
     */
    public String getTypeName() {
        return typeName;
    }

    /**
     * @return Returns the productName.
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @return Returns the typeReference.
     */
    public TypeReference getTypeReference() {
        if (typeReference == null) {
            typeReference = new TypeReference(getConnection(), productName, DMTypeScope.ITEM, typeName);
        }
        return typeReference;
    }

    /**
     * @return Returns the statusReference.
     */
    public StatusReference getStatusReference() {
        if (statusReference == null) {
            statusReference = new StatusReference(getTypeReference(), getStatus());
        }
        return statusReference;
    }

    /**
     * @return item revision status or <code>null</code> if unknown
     */
    public String getStatus() {
        return null;
    }

}

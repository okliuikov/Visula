/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.ISubscriberChangeEvent;
import org.eclipse.team.core.subscribers.ISubscriberChangeListener;
import org.eclipse.team.core.subscribers.SubscriberChangeEvent;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Base class for merge and compare subscribers.
 * @author V.Grishchenko
 */
public abstract class DMBaseCompareSubscriber extends DMSyncTreeSubscriber implements ISubscriberChangeListener,
        IResourceChangeListener {

    private List<ProjectMergeDescriptor> descriptors;
    private IResource[] roots;
    private QualifiedName id;

    static QualifiedName getUniqueId(String qualifier, String prefix) {
        String uniqueId = Long.toString(System.currentTimeMillis());
        return new QualifiedName(qualifier, prefix + uniqueId);
    }

    /**
     * @param name
     */
    public DMBaseCompareSubscriber(QualifiedName id, ProjectMergeDescriptor[] descriptors) {
        Assert.isNotNull(id);
        Assert.isNotNull(descriptors);
        this.id = id;
        this.descriptors = new ArrayList<ProjectMergeDescriptor>(Arrays.asList(descriptors));
        setName(getName(descriptors));
    }

    /**
     * @return subscriber's id
     */
    public String getId() {
        return id.getLocalName();
    }

    /**
     * @return subscriber's descriptors
     */
    public ProjectMergeDescriptor[] getDescriptors() {
        return descriptors.toArray(new ProjectMergeDescriptor[descriptors.size()]);
    }

    @Override
    public IResource[] roots() {
        if (roots == null) {
            ArrayList<IResource> list = new ArrayList<IResource>();
            for (Iterator<ProjectMergeDescriptor> iter = descriptors.iterator(); iter.hasNext();) {
                ProjectMergeDescriptor aMerge = iter.next();
                list.addAll(Arrays.asList(aMerge.getRoots()));
            }
            roots = list.toArray(new IResource[list.size()]);
        }
        return roots;
    }

    /**
     * Clears any cached state, once disposed cannot be reused.
     */
    public void dispose() {
    }

    private ProjectMergeDescriptor findDescriptor(IProject project) {
        for (Iterator<ProjectMergeDescriptor> iter = descriptors.iterator(); iter.hasNext();) {
            ProjectMergeDescriptor descriptor = iter.next();
            if (descriptor.getLocal().equals(project)) {
                return descriptor;
            }
        }
        return null;
    }

    // adjusts subscriber's roots based on a root removed from the workspace subscriber
    protected SubscriberChangeEvent[] handleRemovedRoot(IResource removedRoot) {
        ProjectMergeDescriptor affectedDescriptor = findDescriptor(removedRoot.getProject());
        if (affectedDescriptor == null) {
            return new SubscriberChangeEvent[0]; // no project in our scope
        }
        ArrayList<IResource> unaffected = new ArrayList<IResource>();
        ArrayList<IResource> removals = new ArrayList<IResource>();
        IResource[] dRoots = affectedDescriptor.getRoots();
        for (int i = 0; i < dRoots.length; i++) {
            if (removedRoot.getFullPath().isPrefixOf(dRoots[i].getFullPath())) {
                removals.add(dRoots[i]);
            } else {
                unaffected.add(dRoots[i]);
            }
        }

        if (removals.isEmpty()) {
            return new SubscriberChangeEvent[0]; // this removal does not affect us
        }

        descriptors.remove(affectedDescriptor);
        if (!unaffected.isEmpty()) {
            IResource[] newRoots = unaffected.toArray(new IResource[unaffected.size()]);
            descriptors.add(new ProjectMergeDescriptor(affectedDescriptor.getLocal(), newRoots, affectedDescriptor.getAncestor(),
                    affectedDescriptor.getRemote()));
            roots = null;
        }

        SubscriberChangeEvent[] result = new SubscriberChangeEvent[removals.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = new SubscriberChangeEvent(this, ISubscriberChangeEvent.ROOT_REMOVED, removals.get(i));
        }
        return result;
    }

    protected List<ProjectMergeDescriptor> getDescriptorList() {
        return descriptors;
    }

    protected IDMProject getAncestorProject(IResource resource) {
        IProject project = resource.getProject();
        for (Iterator<ProjectMergeDescriptor> iter = descriptors.iterator(); iter.hasNext();) {
            ProjectMergeDescriptor aMerge = iter.next();
            if (project.equals(aMerge.getLocal())) {
                return aMerge.getAncestor();
            }
        }
        return null;
    }

    protected IDMProject getRemoteProject(IResource resource) {
        IProject project = resource.getProject();
        for (Iterator<ProjectMergeDescriptor> iter = descriptors.iterator(); iter.hasNext();) {
            ProjectMergeDescriptor aMerge = iter.next();
            if (project.equals(aMerge.getLocal())) {
                return aMerge.getRemote();
            }
        }
        return null;
    }

    protected abstract String getName(ProjectMergeDescriptor[] compareDescriptors);

    @Override
    public void subscriberResourceChanged(ISubscriberChangeEvent[] deltas) {
        ArrayList<ISubscriberChangeEvent> deltasToForward = new ArrayList<ISubscriberChangeEvent>(deltas.length);
        for (int i = 0; i < deltas.length; i++) {
            ISubscriberChangeEvent delta = deltas[i];
            if ((delta.getFlags() & ISubscriberChangeEvent.SYNC_CHANGED) == ISubscriberChangeEvent.SYNC_CHANGED) {
                try {
                    if (isSupervised(delta.getResource())) {
                        deltasToForward.add(delta);
                    }
                } catch (TeamException e) {
                    DMTeamPlugin.log(e.getStatus());
                }
            }
            if ((delta.getFlags() & ISubscriberChangeEvent.ROOT_REMOVED) == ISubscriberChangeEvent.ROOT_REMOVED) {
                IResource removedRoot = delta.getResource();
                deltasToForward.addAll(Arrays.asList(handleRemovedRoot(removedRoot)));
            }
        }
        if (!deltasToForward.isEmpty()) {
            fireTeamResourceChange(deltasToForward.toArray(new ISubscriberChangeEvent[deltasToForward.size()]));
        }
    }

    @Override
    public void resourceChanged(IResourceChangeEvent event) {
    }

}

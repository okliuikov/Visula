/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFileState;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.SubscriberChangeEvent;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantTree;
import org.eclipse.team.core.variants.PersistantResourceVariantByteStore;
import org.eclipse.team.core.variants.ResourceVariantByteStore;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Maintains remote trees for a merge into workspace.
 *
 * @author V.Grishchenko
 */
public class DMMergeSubscriber extends DMBaseCompareSubscriber {
    private static final String ID = "com.serena.eclipse.dimensions.team.merge-subscriber"; //$NON-NLS-1$
    private static final String MERGE_PREFIX = "merge-"; //$NON-NLS-1$

    private MergeBaseTree baseTree;
    private MergeSourceTree sourceTree;
    private DimensionsConnectionDetailsEx connection;
    // One modificationTime map for different merge roots
    private static Map modificationTimeBeforeMerge = new HashMap(); // save resource->modificationTimeBeforeMerge to get original
                                                                    // contents from history

    private class MergeSourceTree extends DMRemoteTree {
        public MergeSourceTree(ResourceVariantByteStore store) {
            super(store, DMMergeSubscriber.this);
        }

        @Override
        protected IDMProject getDMProject(IResource resource) throws CoreException {
            return getRemoteProject(resource);
        }

        @Override
        public IResource[] refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
            // Override refresh to check if already merged
            monitor.beginTask(null, 100);
            try {
                IResource[] refreshed = super.refresh(resources, depth, Utils.subMonitorFor(monitor, 80));
                checkAlreadyMerged(refreshed, Utils.subMonitorFor(monitor, 20));
                return refreshed;
            } catch (CoreException e) {
                throw TeamException.asTeamException(e);
            } finally {
                monitor.done();
            }
        }
    }

    private class MergeBaseTree extends DMRemoteTree {
        public MergeBaseTree(ResourceVariantByteStore store) {
            super(store, DMMergeSubscriber.this);
        }

        @Override
        protected IDMProject getDMProject(IResource resource) throws CoreException {
            return getAncestorProject(resource);
        }

        @Override
        public IResource[] refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
            // Only refresh the base of a resource once as it should not change
            List unrefreshed = new ArrayList();
            for (int i = 0; i < resources.length; i++) {
                IResource resource = resources[i];
                if (!hasResourceVariant(resource)) {
                    unrefreshed.add(resource);
                }
                flushModifiedChildren(resource, unrefreshed);
            }
            if (unrefreshed.isEmpty()) {
                monitor.done();
                return new IResource[0];
            }
            IResource[] refreshed = super.refresh((IResource[]) unrefreshed.toArray(new IResource[unrefreshed.size()]), depth,
                    monitor);
            return refreshed;
        }

        private void flushModifiedChildren(IResource resource, List unrefreshed) {
            assert resource != null;
            assert unrefreshed != null;

            final List memberList = new ArrayList();
            if (resource.getType() == IResource.FILE) {
                memberList.add(resource);
            } else {
                memberList.addAll(TeamUtils.collectFiles(new IResource[] { resource }, IResource.DEPTH_INFINITE));
            }

            for (Iterator iter = memberList.iterator(); iter.hasNext();) {
                IResource member = (IResource) iter.next();
                Long timeBeforeMerge = (Long) modificationTimeBeforeMerge.get(member);
                if (timeBeforeMerge != null) {
                    try {
                        // Time-consuming operation, we should re-implement this
                        IFileState[] states = ((IFile) member).getHistory(new NullProgressMonitor());
                        IFileState stateBeforeMerge = null;
                        for (int j = 0; j < states.length; j++) {
                            if (states[j].getModificationTime() == timeBeforeMerge.longValue()) {
                                stateBeforeMerge = states[j];
                                break;
                            }
                        }
                        //
                        if (stateBeforeMerge != null
                                && InputStreamComparator.compare(stateBeforeMerge.getContents(), ((IFile) member).getContents(),
                                        true)) {
                            getBaseTree().flushVariants(member, IResource.DEPTH_ZERO);
                            if (!unrefreshed.contains(member)) {
                                unrefreshed.add(member);
                            }
                        }
                    } catch (CoreException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        /**
         * Mark the resource as merged by making it's base equal the remote
         */
        public void merged(IResource resource, byte[] remoteBytes) throws TeamException {
            if (remoteBytes == null) {
                getByteStore().deleteBytes(resource);
            } else {
                getByteStore().setBytes(resource, remoteBytes);
            }
        }

        /**
         * Return true if the remote has already been merged
         * (i.e. the base equals the remote).
         */
        public boolean isMerged(IResource resource, byte[] remoteBytes) throws TeamException {
            byte[] mergedBytes = getByteStore().getBytes(resource);
            return TeamUtils.equals(mergedBytes, remoteBytes);
        }

        @Override
        protected IDMRemoteResource getCachedRemoteResource(IResource resource) {
            return null; // disable caching as we only refresh once
        }
    }

    public static class InputStreamComparator {
        public static boolean compare(InputStream is1, InputStream is2, boolean ignoreWhitespace) {
            try {
                if (is1 == is2) {
                    return true;
                }

                if (is1 == null && is2 == null) {
                    return true;
                }

                if (is1 == null || is2 == null) {
                    return false;
                }

                while (true) {
                    int c1 = is1.read();
                    while (ignoreWhitespace && isWhitespace(c1)) {
                        c1 = is1.read();
                    }
                    int c2 = is2.read();
                    while (ignoreWhitespace && isWhitespace(c2)) {
                        c2 = is2.read();
                    }
                    if (c1 == -1 && c2 == -1) {
                        return true;
                    }
                    if (c1 != c2) {
                        break;
                    }

                }
            } catch (IOException ex) {
            } finally {
                try {
                    try {
                        if (is1 != null) {
                            is1.close();
                        }
                    } finally {
                        if (is2 != null) {
                            is2.close();
                        }
                    }
                } catch (IOException e) {
                    // Ignore
                }
            }
            return false;
        }

        private static boolean isWhitespace(int c) {
            if (c == -1) {
                return false;
            }
            return Character.isWhitespace((char) c);
        }
    }

    /**
     * @param name
     */
    public DMMergeSubscriber(ProjectMergeDescriptor[] projectMerges) {
        this(getUniqueId(ID, MERGE_PREFIX), projectMerges);
    }

    public DMMergeSubscriber(String id, ProjectMergeDescriptor[] projectMerges) {
        this(new QualifiedName(ID, id), projectMerges);
    }

    private DMMergeSubscriber(QualifiedName id, ProjectMergeDescriptor[] projectMerges) {
        super(id, projectMerges);
        initialize();
    }

    @Override
    protected String getName(ProjectMergeDescriptor[] projectMerges) {
        if (projectMerges == null) {
            projectMerges = new ProjectMergeDescriptor[] {};
        }
        String[] pairs = new String[projectMerges.length];
        for (int i = 0; i < pairs.length; i++) {
            pairs[i] = NLS.bind(Messages.DMMergeSubscriber_ancestorAndSource, projectMerges[i].getAncestor().getId(),
                    projectMerges[i].getRemote().getId());
        }
        return Utils.toCsvString(pairs, true);
    }

    public DimensionsConnectionDetailsEx getConnection() {
        return connection;
    }

    @Override
    public void dispose() {
        super.dispose();
        ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
        DMTeamPlugin.getWorkspace().getSubscriber().removeListener(this);
        baseTree.dispose();
        sourceTree.dispose();
    }

    private void initialize() {
        // ensure merge all participants are from 1 connection
        for (Iterator iter = getDescriptorList().iterator(); iter.hasNext();) {
            ProjectMergeDescriptor aMerge = (ProjectMergeDescriptor) iter.next();
            if (connection == null) {
                connection = aMerge.getAncestor().getConnection();
            } else {
                String msg = "cross-connection merge is unsupported"; //$NON-NLS-1$
                Assert.isLegal(connection.equals(aMerge.getAncestor().getConnection()), msg);
                Assert.isLegal(connection.equals(aMerge.getRemote().getConnection()), msg);
                try {
                    IDMProject targetSharing = DMTeamPlugin.getWorkspace().getProject(aMerge.getLocal());
                    Assert.isNotNull(targetSharing, aMerge.getLocal().getName() + " is not shared with Dimensions"); //$NON-NLS-1$
                    Assert.isLegal(connection.equals(targetSharing.getConnection()), msg);
                } catch (CoreException e) {
                    DMTeamPlugin.log(e.getStatus());
                }
            }
        }

        String syncKeyPrefix = getId();
        PersistantResourceVariantByteStore baseSynchronizer = new PersistantResourceVariantByteStore(new QualifiedName(
                SYNC_KEY_QUALIFIER, syncKeyPrefix + BASE_TREE_SUFFIX));
        this.baseTree = new MergeBaseTree(baseSynchronizer);
        PersistantResourceVariantByteStore sourceSynchronizer = new PersistantResourceVariantByteStore(new QualifiedName(
                SYNC_KEY_QUALIFIER, syncKeyPrefix + REMOTE_TREE_SUFFIX));
        this.sourceTree = new MergeSourceTree(sourceSynchronizer);

        // add DM workspace and resource listeners
        ResourcesPlugin.getWorkspace().addResourceChangeListener(this);
        DMTeamPlugin.getWorkspace().getSubscriber().addListener(this);
    }

    @Override
    protected IResourceVariantTree getBaseTree() {
        return baseTree;
    }

    @Override
    protected IResourceVariantTree getRemoteTree() {
        return sourceTree;
    }

    @Override
    public boolean isSupervised(IResource resource) throws TeamException {
        return getBaseTree().hasResourceVariant(resource) || getRemoteTree().hasResourceVariant(resource);
    }

    @Override
    protected SyncInfo getSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote) throws TeamException {
        try {
            DMMergeSyncInfo syncInfo = new DMMergeSyncInfo(local, base, remote, getResourceComparator(), this,
                    getConnectionForResource(local, base, remote));
            syncInfo.init();
            return syncInfo;
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
    }

    @Override
    public IStatus merged(IResource[] locals, IDMRemoteResource[] remotes, IProgressMonitor monitor) throws CoreException {
        Assert.isLegal(locals != null && remotes != null && locals.length == remotes.length);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, locals.length);
        ArrayList others = new ArrayList(); // resources we couldn't mark as merged
        try {
            for (int i = 0; i < locals.length; i++) {
                IResource local = locals[i];
                assert local != null;
                IDMRemoteResource remote = remotes[i];
                baseTree.merged(local, remote != null ? remote.asBytes() : null); // re-base
                boolean metadataUpdated = false; // metadata updates will be reported as events from dmworkspce
                if (local.getType() == IResource.FILE && local.exists() && remote != null
                        && remote.getType() == IDMRemoteResource.FILE) {
                    IDMRemoteFile base = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
                    IDMRemoteFile remoteFile = (IDMRemoteFile) remote;
                    // skip file without metadata and those from different pedigrees, also avoid storing
                    // same revision as base in case of confirmed pseudo-conflicting additions
                    if (isSameItem(base, remoteFile) && !base.getRevision().equals(remoteFile.getRevision())) {
                        BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(local);
                        if (metadata instanceof ItemMetadata) {
                            ItemMetadata itemMetadata = (ItemMetadata) metadata;
                            String mergeString = itemMetadata.getRevisionListAsString();
                            boolean change = false; // anything changed?
                            if (Utils.isNullEmpty(mergeString)) {
                                mergeString = remoteFile.getRevision();
                                change = true;
                            } else {
                                Set revisions = TeamUtils.parseRevisionList(mergeString);
                                if (revisions.add(remoteFile.getRevision())) {
                                    mergeString = Utils.toCsvString(revisions.toArray(new String[revisions.size()]), false);
                                    change = true;
                                }
                            }
                            if (change) {
                                itemMetadata.setRevisionListAsString(mergeString);
                                WorkspaceMetadataManager.getInstance().updateMetadata(local, itemMetadata);
                                metadataUpdated = true;
                            }
                        }
                    }
                    IFileState[] states = ((IFile) local).getHistory(new NullProgressMonitor());

                    // Save modification time of the last file from history, i.e. just before merge
                    modificationTimeBeforeMerge.put(local, states != null && states.length > 0 && states[0] != null ? new Long(
                            states[0].getModificationTime()) : null);
                }
                if (!metadataUpdated) {
                    others.add(local);
                }
                monitor.worked(1);
            }
            // only need to fire changes for those resources whose metadata wasn't updated as metadata updates
            // will be reported by dmworkspace, caught by this subscriber and forwarded onto its listeners;
            // while not always necessary we do this as a safety measure to ensure listeners do not miss any changes
            if (!others.isEmpty()) {
                fireTeamResourceChange(SubscriberChangeEvent.asSyncChangedDeltas(this,
                        (IResource[]) others.toArray(new IResource[others.size()])));
            }

        } finally {
            monitor.done();
        }
        return Status.OK_STATUS;
    }

    public boolean isMerged(IResource resource) throws TeamException {
        byte[] remoteBytes = sourceTree.getByteStore().getBytes(resource);
        return baseTree.isMerged(resource, remoteBytes);
    }

    private void checkAlreadyMerged(IResource[] refreshed, IProgressMonitor monitor) throws CoreException {
        monitor.beginTask(null, refreshed.length);
        try {
            for (int i = 0; i < refreshed.length; i++) {
                IResource resource = refreshed[i];
                if (resource.getType() == IResource.FILE) {
                    IDMWorkspaceFile dmFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(resource);
                    IDMRemoteFile workspaceBase = null;
                    if (dmFile != null) {
                        workspaceBase = dmFile.getBaseFile();
                    }
                    IDMRemoteFile mergeSource = (IDMRemoteFile) sourceTree.getResourceVariant(resource);
                    if (isSameItem(workspaceBase, mergeSource)) {
                        String[] mergedFrom = workspaceBase.getMergedFromRevisions();
                        if (Arrays.binarySearch(mergedFrom, mergeSource.getRevision()) >= 0) {
                            baseTree.merged(resource, mergeSource.asBytes());
                        }
                    }
                }
                monitor.worked(1);
            }
        } finally {
            monitor.done();
        }
    }

    // checks if 2 items have the same item spec id, i.e. checks if 2 item revisions one pedigree
    private boolean isSameItem(IDMRemoteFile file1, IDMRemoteFile file2) {
        return file1 != null && file2 != null && file1.getItemSpecId().equals(file2.getItemSpecId());
    }

}

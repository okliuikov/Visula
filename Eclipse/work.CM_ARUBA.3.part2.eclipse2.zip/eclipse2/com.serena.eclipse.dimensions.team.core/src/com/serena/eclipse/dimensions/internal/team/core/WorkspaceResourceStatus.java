/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.IResourceVariantComparator;

import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class WorkspaceResourceStatus { 
    /** no flags are set - 0 */
    public static final int NONE = 0x00000000;
    /** base info present */
    public static final int MANAGED = 0x00000001;
    /** base info missing */
    public static final int UNMANAGED = 0x00000002;
    /** base info present and resource is extracted into local */
    public static final int EXTRACTED = 0x00000004;
    /** base info present and resource is not extracted into local */
    public static final int NOT_EXTRACTED = 0x00000008;
    /** base info is present and resource is locally modified */
    public static final int MODIFIED = 0x00000010;
    /** base info is present and resource is locally unmodified */
    public static final int UNMODIFIED = 0x00000020;
    /** base info is present, resource is writable and not checked out */
    public static final int OPTIMISTIC = 0x00000040;
    /** base info is present, resource is read-only and not checked out */
    public static final int PESSIMISTIC = 0x00000080;
    /** resource is ignored */
    public static final int IGNORED = 0x00000100;
    /** resource has base info and is moved */
    public static final int MOVED = 0x00000200;
    /** resource has base info and not moved */
    public static final int NOT_MOVED = 0x00000400;
    /** resource is marked as extracted in the repo but not locally */
    public static final int REMOTE_EXTRACTED = 0x00000800;
    /** remote revision differs from base */
    public static final int REMOTE_MODIFIED = 0x00001000;
    /** remote variant is present */
    public static final int REMOTE_PRESENT = 0x00002000;
    /** remote variant is missing */
    public static final int REMOTE_MISSING = 0x00004000;
    /** remote variant is locked */
    public static final int LOCKED_FILE = 0x00008000;
    /** remote variant is locked by user different from the current one */
    public static final int LOCKED_FILE_OTHER = 0x00010000;
    /** remote variant is not locked */
    public static final int UNLOCKED_FILE = 0x00020000;

    // composite statuses
    public static final int MANAGED_NO_REMOTE_NOT_MOVED = 0x00100000;
    public static final int UNMANAGED_NO_REMOTE_NOT_IGNORED = 0x00200000;

    private static final int ALL = MANAGED | UNMANAGED | EXTRACTED | NOT_EXTRACTED | MODIFIED | UNMODIFIED | OPTIMISTIC
            | PESSIMISTIC | IGNORED | MOVED | NOT_MOVED | REMOTE_EXTRACTED | REMOTE_MODIFIED | REMOTE_PRESENT
            | REMOTE_MISSING | MANAGED_NO_REMOTE_NOT_MOVED | UNMANAGED_NO_REMOTE_NOT_IGNORED | LOCKED_FILE | UNLOCKED_FILE
            | LOCKED_FILE_OTHER;

    protected int status;

    WorkspaceResourceStatus() {
        this(NONE);
    }

    WorkspaceResourceStatus(int status) {
        this.status = status & ALL;
    }

    static WorkspaceResourceStatus createStatus(IResource local, IDMRemoteFile base, IDMRemoteFile remote,
            MetadataProvider provider) throws TeamException {
        int status = 0;
        if (local != null) {
            if (base != null) {
                status |= DMWorkspace.isFileModified(local, base) ? MODIFIED : UNMODIFIED;
                if (local.exists() && !base.isExtracted()) {
                    ResourceAttributes attributes = local.getResourceAttributes();
                    status |= attributes == null ? OPTIMISTIC : attributes.isReadOnly() ? PESSIMISTIC : OPTIMISTIC;
                }
            }
            if (DMTeamPlugin.getWorkspace().isIgnored(local, provider)) {
                status |= IGNORED;
            }
        }
        if (base != null) {
            status |= MANAGED;
            status |= base.isExtracted() ? EXTRACTED : NOT_EXTRACTED;
            try {
                status |= base.isMoved()
                        ? MOVED : DMTeamPlugin.getWorkspace().getMovedFrom(local) != null ? MOVED : NOT_MOVED;
            } catch (CoreException e) {
                throw TeamException.asTeamException(e);
            }
        } else {
            status |= UNMANAGED;
        }
        if (remote != null) {
            status |= REMOTE_PRESENT;
            if (remote.isExtracted()) {
                status |= REMOTE_EXTRACTED;
            }

            if (remote.isLockedOther()) {
                status |= LOCKED_FILE_OTHER;
                status |= LOCKED_FILE;
            } else if (remote.isLocked()) {
                status |= LOCKED_FILE;
            } else {
                status |= UNLOCKED_FILE;
            }

        } else {
            status |= REMOTE_MISSING;
        }
        IResourceVariantComparator comparator = DMTeamPlugin.getWorkspace().getSubscriber().getResourceComparator();
        if (!comparator.compare(base, remote)) {
            status |= REMOTE_MODIFIED;
        }
        if (local != null && local.exists()
                && (status & (MANAGED | REMOTE_MISSING | NOT_MOVED)) == (MANAGED | REMOTE_MISSING | NOT_MOVED)) {
            status |= MANAGED_NO_REMOTE_NOT_MOVED;
        }
        if (local != null && local.exists() && (status & (UNMANAGED | REMOTE_MISSING)) == (UNMANAGED | REMOTE_MISSING)
                && (status & IGNORED) == 0) {
            status |= UNMANAGED_NO_REMOTE_NOT_IGNORED;
        }
        return new WorkspaceResourceStatus(status);
    }

    static WorkspaceResourceStatus createStatus(IResource local, IDMRemoteFile base, IDMRemoteFile remote)
            throws TeamException {
        return createStatus(local, base, remote, null);
    }

    public boolean matchAll(int mask) {
        return (status & mask) == mask;
    }

    public boolean matchAny(int mask) {
        return (status & mask) != 0;
    }

    @Override
    public int hashCode() {
        return status;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof WorkspaceResourceStatus) {
            return status == ((WorkspaceResourceStatus) obj).status;
        }
        return false;
    }

    static boolean testFlag(int status, int flag) {
        return (status & flag) == flag;
    }

    static char getChar(int status, int flag) {
        return testFlag(status, flag) ? 'Y' : 'N';
    }

    static String getStatusString(int status, String prefix, String suffix) {
        if (prefix == null) {
            prefix = Utils.EMPTY_STRING;
        }
        if (suffix == null) {
            suffix = Utils.EMPTY_STRING;
        }
        StringBuffer buf = new StringBuffer(prefix);
        buf.append(" managed=").append(getChar(status, MANAGED));
        buf.append(" unmanaged=").append(getChar(status, UNMANAGED));
        buf.append(" extracted=").append(getChar(status, EXTRACTED));
        buf.append(" not_extracted=").append(getChar(status, NOT_EXTRACTED));
        buf.append(" modified=").append(getChar(status, MODIFIED));
        buf.append(" unmodified=").append(getChar(status, UNMODIFIED));
        buf.append(" optimistic=").append(getChar(status, OPTIMISTIC));
        buf.append(" pessimistic=").append(getChar(status, PESSIMISTIC));
        buf.append(" ignored=").append(getChar(status, IGNORED));
        buf.append(" moved=").append(getChar(status, MOVED));
        buf.append(" not_moved=").append(getChar(status, NOT_MOVED));
        buf.append(" rmt_extracted=").append(getChar(status, REMOTE_EXTRACTED));
        buf.append(" rmt_modified=").append(getChar(status, REMOTE_MODIFIED));
        buf.append(" rmt_present=").append(getChar(status, REMOTE_PRESENT));
        buf.append(" locked_file=").append(getChar(status, LOCKED_FILE));
        buf.append(" locked_file_other=").append(getChar(status, LOCKED_FILE_OTHER));
        buf.append(" unlocked_file=").append(getChar(status, UNLOCKED_FILE));
        buf.append(suffix);
        return buf.toString();
    }

    /**
     * @return a string representation of this status, usable for debugging
     */
    @Override
    public String toString() {
        return getStatusString(status, "STATUS={", "}");
    }

}

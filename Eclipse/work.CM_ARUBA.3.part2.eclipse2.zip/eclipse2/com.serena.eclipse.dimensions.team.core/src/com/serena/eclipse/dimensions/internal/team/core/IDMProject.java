/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.UploadItemDetails;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IMappedObjectDetails;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;

/**
 * Dimensions-managed project sub-tree. Provides methods for remote resource
 * traversal and invocation of source-control operations.
 *
 * @author V.Grishchenko
 */
public interface IDMProject extends IMappedObjectDetails {
    // project types --------------------------
    /** workset project type */
    int WORKSET = 1;
    /** baseline project type */
    int BASELINE = 2;

    // workspace resource filters -------------
    /** selects resources eligible for checkout */
    IDMWorkspaceResourceFilter CHECKOUT_FILTER = new StatusFilter(WorkspaceResourceStatus.NOT_EXTRACTED
            | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);
    /** selects resources eligible for checkin */
    IDMWorkspaceResourceFilter PESSIMISTIC_CHECKIN_FILTER = new StatusFilter(WorkspaceResourceStatus.EXTRACTED
            | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);
    /** selects resources eligible for upload */
    IDMWorkspaceResourceFilter OPTIMISTIC_CHECKIN_FILTER = new StatusFilter(WorkspaceResourceStatus.NOT_EXTRACTED
            | WorkspaceResourceStatus.MODIFIED | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);
    /** selects resources eligible for checkin or upload */
    IDMWorkspaceResourceFilter CHECKIN_FILTER = new IDMWorkspaceResourceFilter.OrFilter(new IDMWorkspaceResourceFilter[] {
            PESSIMISTIC_CHECKIN_FILTER, OPTIMISTIC_CHECKIN_FILTER });
    /** selects resources eligible for undo checkout */
    IDMWorkspaceResourceFilter UNDO_CHECKOUT_FILTER = new StatusFilter(WorkspaceResourceStatus.EXTRACTED
            | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);
    /** selects resources eligible for add to source control */
    IDMWorkspaceResourceFilter ADD_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED_NO_REMOTE_NOT_MOVED
            | WorkspaceResourceStatus.UNMANAGED_NO_REMOTE_NOT_IGNORED, StatusFilter.OR);
    /** selects resource eligible for deletion from source control */
    IDMWorkspaceResourceFilter DELETE_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED
            | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);
    IDMWorkspaceResourceFilter SWITCH_TO_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED, StatusFilter.AND);

    /**
     * @return the IDE tag or <code>null</code> if none
     */
    String getIdeTag();

    /**
     * UID used for querying upload rules (project, baseline, or item)
     * @see com.serena.dmclient.api.SystemAttributes#IDE_DM_UID
     */
    long getIdeProjectUid();

    /**
     * @return real project or baseline UID
     */
    long getDmUid();

    /**
     * @return the ide project name workset/baseline property or <code>null</code> if none.
     */
    String getIdeProjectName();

    /**
     * @return <code>true</code> for initial worksets in the context of the
     *         Dimensions IDE project concept, returns <code>false</code> otherwise
     *         and for baselines
     */
    boolean isInitial();

    /**
     * @return <code>PROJECT</code> or <code>BASELINE</code>
     */
    int getType();

    /**
     * @return product name
     */
    String getProduct();

    /**
     * @return dimensions project group name or <code>null</code> if this
     *         project was not added to workspace in the context of a project group
     */
    String getProjectGroup();

    /**
     * @return locally cached default request ID
     */
    String getDefaultRequest();

    /**
     * Returns a default request id for this project, optionally querying the db.
     * Last obtained value is cached and persisted across IDE restarts.
     *
     * @param query if <code>true</code> will fetch current request from the server,
     *            otherwise just returns locally cached value.
     * @return default request id or <code>null</code> if none or if a baseline
     * @throws CoreException if there are any errors running server query
     */
    String getDefaultRequest(boolean query) throws CoreException;

    /**
     * @return <code>true</code> if this project is a part of project group,
     *         returns <code>false</code> otherwise
     */
    boolean isPartOfGroup();

    /**
     * @return <code>true</code> if this project is a workset, returns <code>false</code> otherwise
     */
    boolean isWorkset();

    /**
     * @return <code>true</code> if this project is a baseline, returns <code>false</code> otherwise
     */
    boolean isBaseline();

    /**
     * @return underlying dmclient object representing remote project, can
     *         be <code>Project</code> or <code>Baseline</code>
     * @throws DMException
     */

    /**
     * @return <code>true</code> if this project is SCC Style, returns <code>false</code> otherwise
     */
    boolean isSccStyle();

    /**
     * @return <code>true</code> if this project expects SBM requests for associations
     */
    boolean isSBMEnabled();

    /**
     * @return underlying dmclient object wrapped into eclipse adapter
     */
    VersionManagementProject getDimensionsObjectAdapter() throws DMException;

    /**
     * @return root of the managed subtree in a local project
     */
    IContainer getRoot();

    /**
     * @return relative path to the root of the managed subtree in a local project
     */
    IPath getProjectRelativePath();

    /**
     * @return <code>true</code> if the supplied resource is located under local
     *         managed root for this project, returns <code>false</code> otherwise
     */
    boolean isManaged(IResource resource);

    /**
     * @return remote relative path for local resource, returns <code>null</code> if resource is not part of the managed local
     *         project or is outside of managed
     *         subtree within the project
     */
    IPath getRemotePathForLocalResource(IResource resource);

    /**
     * @param path local project relative path
     * @return
     */
    IPath getRemotePathForLocalPath(IPath path);

    /**
     * @param path full remote relative path including offset, if any
     * @return local project relative path
     */
    IPath getLocalPathForRemotePath(IPath path);

    /**
     * @return the remote tree for this project
     */
    IDMRemoteTree getRemoteTree();

    RepositoryFolder getRemoteRoot() throws DMException;

    RepositoryFolder getRemoteFolder(IContainer container, IProgressMonitor monitor) throws DMException;

    RepositoryFolder getRemoteFolder(IPath remotePath, IProgressMonitor monitor) throws DMException;

    /**
     * Obtains a list of member resources for the specified container.
     *
     * @param container parent for which to fetch members
     * @param types member type mask using <code>IResource.File</code> and <code>IResource.Folder</code>
     * @param attrs item attributes to query
     * @param recursive <code>true</code> to fetch members recursively
     * @param monitor
     * @return list of members or empty list if none
     * @throws DMException
     * @see IResource#FILE
     * @see IResource#FOLDER
     */
    List<DimensionsArObject> fetchMembers(IContainer container, int types, int[] attrs, boolean recursive, IProgressMonitor monitor)
            throws DMException;

    /**
     * Obtains a list of member resources for the specified folder.
     *
     * @param folder parent for which to fetch members
     * @param types member type mask using <code>IResource.File</code> and <code>IResource.Folder</code>
     * @param attrs item attributes to query
     * @param recursive <code>true</code> to fetch members recursively
     * @param monitor
     * @return list of members or empty list if none
     * @throws DMException
     * @see IResource#FILE
     * @see IResource#FOLDER
     */
    List<DimensionsArObject> fetchMembers(RepositoryFolder folder, int types, int[] itemAttrs, boolean recursive,
            IProgressMonitor monitor) throws DMException;

    /**
     * Obtains a handle to an item using remote path.
     *
     * @param paths
     *            remote path
     * @param attrs
     * @param fetchTypeProject
     *            fetch files with project type (includes scc project marker
     *            files)
     * @param monitor
     * @return revision, if a remote resource could not be found for a remote
     *         path then revision at a corresponding path will be <code>null</code>
     * @throws DMException
     */
    ItemRevision fetchFile(IPath path, int[] attrs, boolean fetchTypeProject, IProgressMonitor monitor) throws DMException;

    /**
     * Obtains a handle to an item using remote path.
     *
     * @param paths
     *            remote paths
     * @param attrs
     * @param monitor
     * @return map of remote path -> revision, if a remote resource could not
     *         be found for a remote path then revision at a corresponding path
     *         will be <code>null</code>
     * @throws DMException
     */
    Map<IPath, ItemRevision> fetchFiles(Set<IPath> paths, int[] attrs, IProgressMonitor monitor) throws DMException;

    /**
     * Obtains a handle to an item using remote path, optionally including
     * project type files
     *
     * @param paths
     *            remote paths
     * @param attrs
     * @param fetchTypeProject
     *            fetch files with project type (includes scc project marker
     *            files)
     * @param monitor
     * @return map of remote path -> revision, if a remote resource could not
     *         be found for a remote path then revision at a corresponding path
     *         will be <code>null</code>
     * @throws DMException
     */
    Map<IPath, ItemRevision> fetchFiles(Set<IPath> paths, int[] attrs, boolean fetchTypeProject, IProgressMonitor monitor)
            throws DMException;

    /**
     * Gets a remote item's revision contents as stream, the contents is first
     * copied to a temporary location on the local file system.
     *
     * @param path
     *            remote path
     * @param monitor
     * @return stream that can be used to read item revision as bytes
     * @throws DMException
     */
    InputStream getContents(IPath path, IProgressMonitor monitor) throws DMException;

    /**
     * Copies a remote item revision to a temporary location.
     *
     * @param path remote path
     * @param monitor
     * @return created temporary file handle
     * @throws DMException
     */
    File getTempCopy(IPath path, IProgressMonitor monitor) throws DMException;

    /**
     * @param spec item revision spec
     * @return item revision, the returned object is a local proxy for remote
     *         item revision that may not actually exist
     */
    ItemRevision getItemRevisionProxy(String spec) throws DMException;

    /**
     * @param itemMetadata metadata, must have spec and uid values
     * @param monitor
     * @return item revision, the returned object is a local proxy for remote
     *         item revision that may not actually exist
     * @throws DMException
     */
    ItemRevision getItemRevisionProxy(ItemMetadata itemMetadata, IProgressMonitor monitor) throws DMException;

    /**
     * @param path remote path
     * @return repository folder, the returned object is a local proxy for remote folder
     *         that may not actually exist
     */
    RepositoryFolder getRepositoryFolderProxy(IPath path) throws DMException;

    /**
     * Copies this project contents entirely to local workspace.
     * @param monitor
     * @param options
     *
     * @throws CoreException
     */
    IStatus copyToWorkspace(IProgressMonitor monitor) throws CoreException;

    /**
     * Copies directory contents entirely to local workspace.
     * @param monitor
     * @param options
     *
     * @throws CoreException
     */
    IStatus copyDirToWorkspace(IProgressMonitor monitor) throws CoreException;

    /**
     * Copies latest revisions to local workspace.
     * @param resources
     * @param monitor
     * @param options
     *
     * @return
     * @throws CoreException
     */
    IStatus copyToWorkspace(IResource[] resources, IProgressMonitor monitor) throws CoreException;

    /**
     * Copies specified revisions to workspace.
     * @param requests
     * @param monitor
     *
     * @return
     * @throws CoreException
     */
    IStatus copyToWorkspace(GetRevisionRequest[] requests, IProgressMonitor monitor) throws CoreException;

    /**
     * Adds files to source control
     * @param files
     * @param monitor
     * @return
     * @throws CoreException
     */
    IStatus add(CreateItemRequest[] files, IProgressMonitor monitor) throws CoreException;

    IStatus delete(DeleteItemRevisionRequest[] files, IProgressMonitor monitor) throws CoreException;

    /**
     * @param files
     * @param monitor
     * @return
     * @throws CoreException
     */
    IStatus checkout(CheckoutRequest[] files, IProgressMonitor monitor) throws CoreException;

    /**
     * Performs a pessimistic checkin.
     * @param files
     * @param monitor
     *
     * @return
     * @throws CoreException
     */
    IStatus checkin(CheckinRequest[] files, IProgressMonitor monitor) throws CoreException;

    /**
     * Cancels checkout for the specified files.
     * @param files
     * @param monitor
     *
     * @return
     * @throws CoreException
     */
    IStatus undoCheckout(UndoCheckoutRequest[] files, IProgressMonitor monitor) throws CoreException;

    /**
     * Uploads the files supplied. Any conflicts detected are skipped unless <code>UploadRequest.FORCE_TIP</code> is used and
     * reported in the
     * returned status. Additionally the status returned may contain
     * information about failed checkouts with CHECKOUT_FAILED code.
     *
     * @param commandData contains requests for upload
     * @param monitor
     * @return upload status
     * @throws CoreException
     * @see {@link DMTeamStatus#CHECKOUT_FAILED}
     */
    IStatus upload(OperationData commandData, IProgressMonitor monitor) throws CoreException;

    /**
     * Delivers the resources supplied to a Stream
     *
     * @param commandData contains requests for deliver and additional information about shape and excluded resources
     * @param monitor
     * @return deliver status
     * @throws CoreException
     * @see {@link DMTeamStatus#CHECKOUT_FAILED}
     */
    IStatus deliver(TransferToStreamOperationData commandData, IProgressMonitor monitor) throws CoreException;

    /**
     * <p>
     * Downloads incoming non-conflicting changes to workspace (a.k.a. update).
     *
     * <p>
     * This method does not refresh workspace state, to get accurate update results the callers are responsible for proper refresh.
     *
     * @param resources
     * @param overwrite controls whether or not to overwrite local changes
     * @param deleteUnmanaged whether or not delete new local resources, considered only when overwrite=true
     * @param monitor
     * @return if any conflicts prevented downloading they will be reported as SyncStatus
     *         children in the returned multi-status.
     * @throws CoreException
     */
    IStatus download(DownloadRequest[] resources, boolean overwrite, boolean deleteUnmanaged, IProgressMonitor monitor)
            throws CoreException;

    /**
     * <p>
     * Downloads incoming non-conflicting changes to workspace (a.k.a. update) using custom subscriber as remote counterparts source
     *
     */
    IStatus download(CustomSubscriber subscriber, DownloadRequest[] resources, boolean overwrite, boolean deleteUnmanaged,
            IProgressMonitor monitor) throws CoreException;

    /**
     * Execute three way merge based on the xml resolutions. Descriptor contains one of the possible merge modes:
     * {@link MERGEMODE#DETECT_RESOLUTIONS} {@link MERGEMODE#EXECUTE_RESOLUTIONS} {@link MERGEMODE#NON_INTERACTIVE}
     */
    IStatus download(XMLMergeDescriptor descriptor, IProgressMonitor monitor) throws CoreException;

    /**
     * Queries dimensions upload rules for the specified filenames.
     *
     * @param filenames relative paths
     * @param attrs wanted attributes
     * @return array of revision details or <code>null</code> if no appropriate
     *         ruleset was found. The returned array elements may be <code>null</code> if server failed to match an inclusion rule
     *         for supplied filenames
     * @throws DMException
     * @see DimensionsObjectFactory
     */
    UploadItemDetails[] queryUploadRules(String[] filenames, String[] attrs, IProgressMonitor monitor) throws DMException;

    /**
     * @param revisions list of latest ItemRevision objects
     * @param attrs attributes to query on the expanded revisions or <code>null</code>
     * @return map: item_spec -> {expanded_revisions}
     */
    Map<String, List<ItemRevision>> expandItemRevisions(List<ItemRevision> revisions, int[] attrs, IProgressMonitor monitor)
            throws DMException;

    /**
     * Creates workset directories.
     *
     * @param dirs
     * @param monitor
     * @return
     * @throws DMException
     */
    IStatus createDirectories(CreateFolderRequest[] dirs, IProgressMonitor monitor) throws CoreException;

    /**
     * Deletes workset directories.
     *
     * @param dirs
     * @param monitor
     * @return
     * @throws DMException
     */
    IStatus deleteDirectories(DeleteFolderRequest[] dirs, boolean deleteLocal, IProgressMonitor monitor) throws CoreException;

    /**
     * Sets workset filenames.
     *
     * @param files
     * @param monitor
     * @return
     * @throws CoreException
     */
    IStatus updateFilename(UpdateFilenameRequest[] files, IProgressMonitor monitor) throws CoreException;

    /**
     * Imports items from the global project to this project and sets
     * appropriate project filenames.
     *
     * @param files
     * @param monitor
     * @return status which will contain chidren of type <code>ITeamStatus</code> for failed import if the revision is missing from
     *         the global workset
     * @throws CoreException
     */
    IStatus importFiles(ImportRequest[] files, IProgressMonitor monitor) throws CoreException;

    IStatus resolveConflicts(ResolveConflictRequest[] conflicts, IProgressMonitor monitor) throws CoreException;

    /**
     * Commits move for resources moved in the local workspace. Handles files
     * and folders. The caller has to make sure resources are not overlapping.
     * Cross-projects moves are also handled by this method. Performs best-effort
     * move of resources, any failures will be reported in the returned status.
     *
     * @param files
     * @param monitor
     * @return
     * @throws CoreException
     */
    IStatus move(IMoveRequest[] movedResources, IProgressMonitor monitor) throws CoreException;
    
    /**
     * @return user directory - the path of the project
     */
    IPath getUserDirectory();

    /**
     * @return relative location for this project
     */
    IPath getRelativeLocation();

    /**
     * Projects are equal if their local projects, connections, remote ids,
     * types, and remote offsets match.
     *
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj);

    /**
     * Convenience method to test if remote id for the supplied
     * project matches this projects remote id (connection, type, object id).
     *
     * @param otherProject
     * @param offset if <code>true</code> the test will consider remote offset,
     *            otherwise only connection, type, and object id are checked
     * @return
     */
    boolean remoteEquals(IDMProject otherProject, boolean offset);

    /**
     * This method indicates whether this project is a Stream or not
     * @return - boolean value which indicates whether the project is a Stream or not
     */

    boolean getIsStream();

    /**
     * The method returns work area root.
     *
     * @return work area root IPath
     */
    IPath getWorkAreaPath();

    /**
     * The method checks whether the project is shared with full work area root or not.
     *
     * @return <code>true</code> for the project shared with full work area root, returns <code>false</code> otherwise
     */
    boolean isFullWorkArea();

    /**
     * @return true if project is a SEP
     */
    boolean isSingleEclipseProject();

    /**
     * @return true if project is a contained project
     */
    boolean isContainedEclipseProject();
}

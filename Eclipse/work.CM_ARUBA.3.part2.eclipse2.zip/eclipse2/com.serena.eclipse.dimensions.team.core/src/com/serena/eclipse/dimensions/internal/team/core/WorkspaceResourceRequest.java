/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IConsoleOperation;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Request to perform an operation on a resource in the workspace.
 *
 * @author V.Grishchenko
 */
public abstract class WorkspaceResourceRequest {
    private static final String SUFFIX = "_message"; //$NON-NLS-1$

    public static final int UNKNOWN = 0;
    /** this request is to create a new resource */
    public static final int CREATE = 1;
    /** this request is to delete an existent resource */
    public static final int DELETE = 2;
    /** this is a request to modify an existent resource */
    public static final int MODIFY = 4;
    /** this is a request to import a resource */
    public static final int IMPORT = 8;
    /** this is a namespace operation */
    public static final int MOVE = 16;

    private IResource resource;
    private DimensionsConnectionDetailsEx connection;
    private String message;

    private Session session;
    private IProgressMonitor progress;

    private boolean requestSupported;
    private boolean requestMandatory;
    private List<String> requests;

    /**
     * Creates a new request for the supplied resource.
     *
     * @param resource
     *            request's resource
     * @throws CoreException
     */
    public WorkspaceResourceRequest(IResource resource) throws CoreException {
        this(resource, false, false);
    }

    /**
     * Creates a new request for the supplied resource.
     *
     * @param resource
     * @param requestSupported
     *            indicates if this request is for an operation supports change
     *            request associations
     * @param requestMandatory
     *            indicates if a change request is mandatory by the operation
     *            that processes this request
     * @throws CoreException
     */
    public WorkspaceResourceRequest(IResource resource, boolean requestSupported, boolean requestMandatory) throws CoreException {
        Assert.isNotNull(resource);
        this.resource = resource;
        this.connection = DMTeamPlugin.getWorkspace().getProject(resource).getConnection();
        this.requestSupported = requestSupported;
        this.requestMandatory = requestMandatory;
    }

    /**
     * @return a bit mask describing the nature of this request
     */
    public abstract int getKind();

    /**
     * @return the underlying resource
     */
    public IResource getResource() {
        return resource;
    }

    /**
     * @return Returns the connection.
     */
    public DimensionsConnectionDetailsEx getConnection() {
        return connection;
    }

    /**
     * Sets this request to require a change request if <code>true</code> or
     * not if <code>false</code>
     *
     * @param requestMandatory
     */
    public void setRequestMandatory(boolean requestMandatory) {
        this.requestMandatory = requestMandatory;
    }

    /**
     * @return <code>true</code> if this request is for an operation that
     *         supports change requests
     */
    public boolean isRequestSupported() {
        return requestSupported;
    }

    /**
     * Sets if this request should support a change request
     *
     * @param requestSupported
     */
    public void setRequestSupported(boolean requestSupported) {
        this.requestSupported = requestSupported;
    }

    /**
     * The list contains String-typed ids in case of native Dimensions
     * integrations, or instances of <code>ISBMRequest</code> when SBM
     * integration is in place.
     *
     * @return the (potentially immutable) list of change request ids associated
     *         with this request
     */
    public List<String> getChangeRequests() {
        if (requests == null) {
            return Collections.emptyList();
        }
        return requests;
    }

    /**
     * The list should String-typed ids in case of native Dimensions
     * integrations, or instances of <code>ISBMRequest</code> when SBM
     * integration is in place.
     *
     * @return the (potentially immutable) list of change request ids associated
     *         with this request
     */
    public void setChangeRequests(List<String> reqs) {
        this.requests = reqs;
    }

    /**
     * Associates a change request with this resource request. Shouldn't be
     * called when SBM is active.
     *
     * @param id
     */
    public void addChangeRequest(String id) {
        if (getConnection().getSBMConnection() != null) {
            throw new IllegalStateException(Messages.methodUnsupported_error);
        }
        if (requests == null) {
            requests = new ArrayList<String>();
        }
        if (!requests.contains(id)) {
            requests.add(id);
        }
    }

    /**
     * Removes a change request from this resource request. Shouldn't be called
     * when SBM is active.
     *
     * @param id
     */
    public void removeChangeRequest(String id) {
        if (getConnection().getSBMConnection() != null) {
            throw new IllegalStateException(Messages.methodUnsupported_error);
        }
        if (requests != null) {
            requests.remove(id);
        }
    }

    /**
     * Removes all associated change requests
     */
    public void clearChangeRequests() {
        if (requests != null) {
            requests.clear();
        }
    }

    protected void process(IProgressMonitor monitor) throws DMException {
        session = getConnection().openSession(null);
        progress = Utils.monitorFor(monitor);
        try {
            String subtask = getMessage();
            if (subtask != null) {
                progress.subTask(subtask);
            }
            session.run(getRunnable(), progress);
        } finally {
            session = null;
            progress = null;
            try {
                if (modifiesLocal()) {
                    TeamUtils.refreshLocal(getResource(), null);
                }
                if (modifiesMetadata()) {
                    WorkspaceMetadataManager.refreshMetadata(getResource(), null);
                }
            } catch (CoreException e) {
                throw DMException.asDMException(e);
            }
        }
    }

    protected boolean modifiesMetadata() {
        return true;
    }

    protected boolean modifiesLocal() {
        return true;
    }

    protected ISessionRunnable getRunnable() {
        return new IConsoleOperation() {
            IStatus status;

            @Override
            public String getMessage() {
                return WorkspaceResourceRequest.this.getMessage();
            }

            @Override
            public IStatus getStatus() {
                return status;
            }

            @Override
            public void run() throws Exception {
                DimensionsResult result = execute(session, progress);
                status = new Status(IStatus.OK, DMTeamPlugin.ID, 0, result.getMessage(), null);
            }
        };
    }

    protected String getMessage() {
        if (message == null) {
            String key = WorkspaceResourceRequest.this.getClass().getName();
            int lastDot = key.lastIndexOf('.');
            if (lastDot != -1) {
                key = key.substring(lastDot + 1);
            }
            Field kField = null;
            String msg = null;
            try {
                kField = Messages.class.getDeclaredField(key + SUFFIX);
                msg = (String) kField.get(String.class);
            } catch (NoSuchFieldException e) {
            } catch (IllegalAccessException e) {
            }
            message = NLS.bind((msg != null) ? msg : "", getResourceMessage());
        }
        return message;
    }

    protected String getResourceMessage() {
        return resource.getFullPath().toString();
    }

    protected abstract DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception;

    /**
     * @return if a change request association is mandatory for this request
     */
    public boolean isRequestsMandatory() {
        return requestMandatory;
    }

}

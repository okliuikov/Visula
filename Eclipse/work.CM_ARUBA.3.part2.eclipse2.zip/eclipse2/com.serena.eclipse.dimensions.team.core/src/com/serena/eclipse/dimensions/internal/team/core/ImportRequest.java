/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.ITeamStatus;
import org.eclipse.team.core.TeamStatus;

import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class ImportRequest extends UpdateFilenameRequest {
    private ITeamStatus status;

    /**
     * @param file
     * @param itemRevision
     * @throws CoreException
     */
    public ImportRequest(IFile file, ItemRevision itemRevision) throws CoreException {
        super(file, itemRevision);
    }

    /**
     * @return import status
     */
    public ITeamStatus getStatus() {
        return status;
    }

    private ITeamStatus getOkStatus() {
        return new TeamStatus(IStatus.OK, DMTeamPlugin.ID, 0, Status.OK_STATUS.getMessage(), null, getResource());
    }

    /**
     * @param file
     * @param itemRevision
     * @param newPath
     * @throws CoreException
     */
    public ImportRequest(IFile file, ItemRevision itemRevision, String newPath) throws CoreException {
        super(file, itemRevision, newPath);
    }

    @Override
    protected String getResourceMessage() {
        return getItemSpec();
    }

    @Override
    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
        String spec = getItemSpec();
        Project globalWorkset = _session.getObjectFactory().getGlobalProject();
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, spec, Filter.Criterion.EQUALS));

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 30);
        try {
            globalWorkset.flushRelatedObjects(ItemRevision.class, true);
            List rels = globalWorkset.getChildItems(filter);
            globalWorkset.flushRelatedObjects(ItemRevision.class, true);
            monitor.worked(10);
            DimensionsResult result = null;
            if (!rels.isEmpty()) {
                ItemRevision revision = (ItemRevision) ((DimensionsRelatedObject) rels.get(0)).getObject();
                String[] requestIds = null;
                if (!getChangeRequests().isEmpty()) {
                    requestIds = (String[]) getChangeRequests().toArray(new String[getChangeRequests().size()]);
                }
                DimensionsResult exportResult = revision.exportToProject((Project) project.getDimensionsObject(), requestIds);
                monitor.worked(10);
                DimensionsResult setFileNameResult = super.execute(_session, Utils.subMonitorFor(monitor, 10));
                result = new DimensionsResult(exportResult.getMessage() + "/n" + setFileNameResult.getMessage()); //$NON-NLS-1$
                status = getOkStatus();
            } else {
                String message = "Item revision '" + spec + "' cannot be found"; //$NON-NLS-1$ //$NON-NLS-2$
                status = new TeamStatus(IStatus.ERROR, DMTeamPlugin.ID, 0, message, null, getResource());
                result = new DimensionsResult(message);
            }
            return result;
        } finally {
            monitor.done();
        }
    }

}

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;

public interface IDMWorkspaceExecutable {

    /**
     * Answers a scheduling rule for running this command on the current Eclipse
     * workspace, this implementation combines the closest ancestors of the
     * command's resources that have metadata.
     *
     * @return scheduling rule
     * @throws CoreException
     */
    ISchedulingRule getSchedulingRule() throws CoreException;

    /**
     * @return true if command runs on a project shared with the workspace
     */
    boolean isValidSharing() throws CoreException;

    /**
     * Executes this command and updates workspace local, base, and remote state
     * as needed.
     *
     * @param monitor
     * @return
     * @throws CoreException
     */
    void workspaceRun(IProgressMonitor monitor) throws CoreException;

    /**
     * @return <code>true</code> if this command modifies base resources,
     *         returns <code>false</code> otherwise
     */
    boolean modifiesBase();

    /**
     * @return <code>true</code> if this command modifies remote resources,
     *         returns <code>false</code> otherwise
     */
    boolean modifiesRemote();

    /**
     * Normally all resource state deltas are determined automatically via
     * variant tree refresh after a command finishes. Occasionally a command may
     * want to obtain the latest state and detect deltas during its execution.
     * This method should report any discovered resource state changes detected
     * during the course of command execution, they will be forwarded onto
     * interested parties upon command completion.
     *
     * @return any state changes that need to be reported to workspace listeners
     *         upon command completion
     */
    IResource[] getChanges();

    /**
     * Set additional changes to report to workspace listeners upon command
     * execution
     *
     * @param changes
     */
    void setChanges(IResource[] changes);

    /**
     * @return resources for which to refresh base tree
     */
    IResource[] getBaseResourcesToRefresh() throws CoreException;

    /**
     * @return resources for which to refresh remote tree
     */
    IResource[] getResourcesToRefresh() throws CoreException;

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.team.core.synchronize.SyncInfo;

/**
 * Status represinting a sync kind. A conflicting sync kind is considered
 * as severity <code>IStatus.ERROR</code>, others are <code>IStatus.OK</code>.
 *
 * @author V.Grishchenko
 * @see org.eclipse.team.core.synchronize.SyncInfo
 */
public class SyncStatus extends DMTeamStatus {

    static int getSeverityFromKind(int kind) {
        if ((SyncInfo.DIRECTION_MASK & kind) == SyncInfo.CONFLICTING) {
            return IStatus.ERROR;
        }
        return IStatus.OK;
    }

    public SyncStatus(IResource resource, int kind) {
        super(getSeverityFromKind(kind), kind, SyncInfo.kindToString(kind), null, resource);
    }

    public SyncStatus(IResource resource, int kind, String message) {
        super(getSeverityFromKind(kind), kind, message, null, resource);
    }

    public SyncStatus(IResource resource, int severity, int kind, String message) {
        super(severity, kind, message, null, resource);
    }

    public int getSyncKind() {
        return getCode();
    }

}

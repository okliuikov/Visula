/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005-2009 Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TreeSet;

import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileInfo;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceStatus;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IScopeContext;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.osgi.service.environment.Constants;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.variants.IResourceVariant;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.MetadataStrings;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.WorkAreaMetadata;
import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataException;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.dmfile.xml.ObjectAttributes;
import com.serena.dmfile.xml.Resolution;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.SessionRunnableWithProgress;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;

import merant.adm.dimensions.util.Debug;

/**
 * Collection of team utils.
 *
 * @author V.Grishchenko
 */
public final class TeamUtils { 
    public static final boolean debugResources = DMTeamPlugin.getDefault().isDebuggingResources();

    /** key for saving the mod stamp for each written file */
    public static final QualifiedName MODSTAMP_KEY = new QualifiedName(DMTeamPlugin.ID, "file-modtime"); //$NON-NLS-1$

    /** prefix for temporary files, value is "dmt" */
    public static final String TEMP_FILE_PREFIX = "dmt"; //$NON-NLS-1$

    public static final String METADATA_VERSION_10_2 = "10.2"; //$NON-NLS-1$

    public static final String CURRENT_METADATA_VERSION = METADATA_VERSION_10_2;

    public static final String[] INVALID_RESOURCE_NAMES;

    public static final String METADATA_OF_DELETED_FOREIGN_RESOURCE = "metadata-of-deleted-foreign-resource"; //$NON-NLS-1$

    public static final String CONFLICT_FILE = "conflict-file"; //$NON-NLS-1$

    public static final String TEAM_UI_PLUGIN_PREFERENCE = "com.serena.eclipse.dimensions.team.ui"; //$NON-NLS-1$

    public static final String COMPARE_CONSIDER_FILE_CONTENTS = "compare_consider_file_contents"; //$NON-NLS-1$

    public static final String EXPAND_SUBSTITUTION = "expand_substitution"; //$NON-NLS-1$

    public static final String IGNORE_DERIVED_RESOURCES = "ignore_derived_resources"; //$NON-NLS-1$

    public static final String YES = "yes"; //$NON-NLS-1$

    public static final String NO = "no"; //$NON-NLS-1$

    public static final String MERGED_FROM_FOREIGN_STREAM = MetadataStrings.MERGED_FROM_FOREIGN_STREAM;

    public static final char[] INVALID_RESOURCE_CHARACTERS;

    // are we a mac
    public static boolean isMac = Platform.OS_MACOSX.equals(Platform.getOS());

    public static boolean isWin = Platform.OS_WIN32.equals(Platform.getOS());

    // set of connection details for which fetch from global project failed
    private static final Set<DimensionsConnectionDetailsEx> globalFetchFailures = Collections
            .synchronizedSet(new HashSet<DimensionsConnectionDetailsEx>());

    private static final String INSTALLED_PLATFORM;

    static {
        // find out the OS being used
        // setup the invalid names
        char[] chars = null;
        String[] names = null;
        INSTALLED_PLATFORM = Platform.getOS();
        if (INSTALLED_PLATFORM.equals(Constants.OS_WIN32)) {
            // list taken from http://support.microsoft.com/support/kb/articles/q177/5/06.asp
            chars = new char[] { '\\', '/', ':', '*', '?', '"', '<', '>', '|' };

            // list taken from http://support.microsoft.com/support/kb/articles/Q216/6/54.ASP
            names = new String[] { "aux", "clock$", "com1", "com2", "com3", "com4", //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
                    "com5", "com6", "com7", "com8", "com9", "con", "lpt1", "lpt2", //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
                    "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9", "nul", "prn" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
        } else {
            // only front slash and null char are invalid on UNIXes
            // taken from http://www.faqs.org/faqs/unix-faq/faq/part2/section-2.html
            // backslash and colon are illegal path segments regardless of filesystem.
            chars = new char[] { '\\', '/', ':', '\0', };
        }
        INVALID_RESOURCE_CHARACTERS = chars == null ? new char[0] : chars;
        INVALID_RESOURCE_NAMES = names == null ? new String[0] : names;
    }

    public static final Comparator<IResource> resourceComparator = new Comparator<IResource>() {
        @Override
        public boolean equals(Object obj) {
            return false;
        }

        @Override
        public int compare(IResource o1, IResource o2) {
            return o1.getFullPath().toString().compareTo(o2.getFullPath().toString());
        }
    };

    public enum ExpandMode {
        EXPANDED,
        UNEXPANDED;
    }

    private TeamUtils() {
    }
    
	public static VersionManagementProject getWorksetAdapter(IResource resource) throws CoreException {
		DMProject dmProject = getDmProject(resource);
		VersionManagementProject versionManagementProject = dmProject.getDimensionsObjectAdapter();
		return versionManagementProject;
	}

    /**
     * @return the Dimensions project mapping for the give resource. If resource is pointing to the virtual project
     *         then the main(parent) project is returned.
     */
    public static DMProject getDmProject(IResource resource) throws CoreException {
        IDMProject project = DMTeamPlugin.getWorkspace().getProject(resource);
        DMProject dmProject = null;
        if (project instanceof VirtualIdmProject) {
            VirtualIdmProject vProject = (VirtualIdmProject) project;
            dmProject = (DMProject) vProject.getRootProject();
        } else {
            dmProject = (DMProject) project;
        }
        return dmProject;
    }

    /**
     * @return If given resource is pointing to the virtual project then the original resource is returned.
     *         Otherwise returns same resource
     */
    public static IResource getResource(IResource resource) throws CoreException {
        IDMProject project = DMTeamPlugin.getWorkspace().getProject(resource);
        if (project instanceof VirtualIdmProject) {
            VirtualIdmProject vProject = (VirtualIdmProject) project;
            return vProject.getOriginalResource(resource);
        }
        return resource;
    }

    /**
     * @return If given container is pointing to the virtual project then the original resource is returned.
     *         Otherwise returns same resource
     */
    public static IContainer getContainer(IContainer resource) throws CoreException {
        IDMProject project = DMTeamPlugin.getWorkspace().getProject(resource);
        if (project instanceof VirtualIdmProject) {
            VirtualIdmProject vProject = (VirtualIdmProject) project;
            return vProject.getOriginalContainer(resource);
        }
        return resource;
    }

    /**
     * @return If given file is pointing to the virtual project then the original file is returned.
     *         Otherwise returns same resource
     */
    public static IFile getFile(IFile resource) throws CoreException {
        IDMProject project = DMTeamPlugin.getWorkspace().getProject(resource);
        if (project instanceof VirtualIdmProject) {
            VirtualIdmProject vProject = (VirtualIdmProject) project;
            return vProject.getOriginalFile(resource);
        }
        return resource;
    }

    /**
     * @return If given folder is pointing to the virtual project then the original resource is returned.
     *         Otherwise returns same resource
     */
    public static IFolder getFolder(IFolder resource) throws CoreException {
        IDMProject project = DMTeamPlugin.getWorkspace().getProject(resource);
        if (project instanceof VirtualIdmProject) {
            VirtualIdmProject vProject = (VirtualIdmProject) project;
            return vProject.getOriginalFolder(resource);
        }
        return resource;
    }

    /**
     * @param c
     *            character to test
     * @return <code>true</code> if the given character can be used in a
     *         resource name on this operating system
     */
    public static boolean isValidResourceNameCharacter(char c) {
        for (int i = 0; i < INVALID_RESOURCE_CHARACTERS.length; i++) {
            if (c == INVALID_RESOURCE_CHARACTERS[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Check if file modified. Force timestamps cleaning
     *
     * @param file
     * @return true if file modified
     * @throws CoreException
     */
    public static boolean isFileModified(IFile file) throws CoreException {
        IDMWorkspaceResource workspaceResource = DMTeamPlugin.getWorkspace().getWorkspaceResource(file);
        DMTeamPlugin.getWorkspace().cleanTimestamps(new IFile[] { file }, IResource.DEPTH_INFINITE, null);
        if (workspaceResource == null) {
            return false;
        }
        return workspaceResource.isModified();
    }

    /**
     * @param name
     *            name to test
     * @param testChars
     *            if <code>false</code> will only check against reserved
     *            resource name on this operating system
     * @return <code>true</code> if the given name is a valid resource name on
     *         this operating system, returns <code>false</code> otherwise
     */
    public static boolean isValidResourceName(String name, boolean testChars) {
        if (name == null || name.length() == 0) {
            return false;
        }
        if (INSTALLED_PLATFORM.equals(Constants.OS_WIN32)) {
            // on windows, filename suffixes are not relevant to name validity
            int dot = name.indexOf('.');
            name = dot == -1 ? name : name.substring(0, dot);
            return Arrays.binarySearch(INVALID_RESOURCE_NAMES, name.toLowerCase()) < 0;
        }
        if (testChars) {
            for (int i = 0; i < name.length(); i++) {
                if (!isValidResourceNameCharacter(name.charAt(i))) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Uses underscore characters to synthesize a valid name if the given
     * name is invalid or a resource in this location already exists.
     *
     * @param name
     *            name to convert
     * @param parent
     *            resource parent to check filesystem name collisions, or <code>null</code> to skip
     * @return new name valid for this operating system based on the given
     *         name, the given name if it is already valid
     * @see org.eclipse.core.resources.IWorkspace#validateName(java.lang.String, int)
     */
    public static String toValidResourceName(String name, File parent) {
        Assert.isLegal(name != null && (name = name.trim()).length() > 0);

        // filesystem
        StringBuffer buf = new StringBuffer(name.length());
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (!isValidResourceNameCharacter(c)) {
                c = '_';
            }
            buf.append(c);
        }

        String candidateName = buf.toString();
        if (!isValidResourceName(candidateName, false)) {
            candidateName = '_' + candidateName;
        }

        // workspace does not allow dot suffix
        if (candidateName.endsWith(".")) { //$NON-NLS-1$
            candidateName = candidateName + '_';
        }

        if (parent != null) {
            while ((new File(parent, candidateName)).exists()) {
                candidateName = '_' + candidateName;
            }
        }

        return candidateName;
    }

    public static File createTempFile() throws IOException {
        return createTempFile(null);
    }

    public static File createTempFile(String suffix) throws IOException {
        return File.createTempFile(TEMP_FILE_PREFIX, suffix);
    }

    /**
     * Obtains a stream for remote contents via a local temp file. Temp file
     * is deleted when the stream is closed.
     */
    public static InputStream getContents(final ItemRevision repositoryFile, DimensionsConnectionDetailsEx connection)
            throws DMException {

        File tempCopy = getTempCopy(repositoryFile, connection);
        try {
            return new TempFileInputStream(tempCopy);
        } catch (FileNotFoundException e) {
            throw new DMException(DMTeamStatus.createErrorStatus(0, "failed to create stream", e)); //$NON-NLS-1$
        }
    }

    public static InputStream getContents(final ItemRevision repositoryFile, DimensionsConnectionDetailsEx connection,
            ExpandMode[] expandModeHolder) throws DMException {

        Assert.isNotNull(repositoryFile);
        try {
            File tempCopy = createTempFile();
            getTempCopy(tempCopy, repositoryFile, connection, false, expandModeHolder);
            return new TempFileInputStream(tempCopy);
        } catch (FileNotFoundException e) {
            throw new DMException(DMTeamStatus.createErrorStatus(0, "failed to create stream", e)); //$NON-NLS-1$
        } catch (IOException e) {
            throw new DMException(DMTeamStatus.createErrorStatus(0, "failed to create temporary file file", e)); //$NON-NLS-1$
        }
    }

    /**
     * Copies remote contents to a local temp file without metadata
     */
    public static File getTempCopy(final ItemRevision repositoryFile, DimensionsConnectionDetailsEx connection)
            throws DMException {
        return getTempCopy(repositoryFile, connection, null);
    }

    /**
     * Copies remote contents to a local temp file without metadata
     */
    public static File getTempCopy(final ItemRevision repositoryFile, DimensionsConnectionDetailsEx connection,
            final String suffix) throws DMException {

        Assert.isNotNull(repositoryFile);
        try {
            File target = createTempFile(suffix);
            getTempCopy(target, repositoryFile, connection, false);
            return target;
        } catch (IOException e) {
            throw new DMException(DMTeamStatus.createErrorStatus(0, "failed to create temporary file file", e)); //$NON-NLS-1$
        }
    }

    /**
     * Fetches file with metadata into the plugin fetch location. Call this
     * method if need to get hold of item metadata.
     */
    public static File getTempCopy(IFile ifile, final ItemRevision repositoryFile, DimensionsConnectionDetailsEx connection)
            throws DMException {

        File target = DMTeamPlugin.getDefault().getFetchLocationFor(ifile).toFile();
        if (target.exists()) {
            target.delete(); // avoid dmnet failures when file is r/o
        }
        getTempCopy(target, repositoryFile, connection, true);
        return target;
    }

    private static final void getTempCopy(final File target, final ItemRevision source,
            final DimensionsConnectionDetailsEx connection, final boolean metadata, final ExpandMode[] expandModeHolder)
            throws DMException {

        final Session session = connection.openSession(null);
        session.run(new ISessionRunnable() {

            @Override
            public void run() throws Exception {
                // try to fetch from $G:$G to save on server-side initialization
                String spec = (String) source.getAttribute(SystemAttributes.OBJECT_SPEC);
                Project project = source.getProject();
                // ensure we have filename
                if (source.getAttribute(SystemAttributes.ITEMFILE_FILENAME) == null) {
                    source.queryAttribute(SystemAttributes.ITEMFILE_FILENAME);
                }
                boolean alreadyGlobal = project != null && IDMConstants.GLOBAL_WORKSET
                        .equalsIgnoreCase((String) project.getAttribute(SystemAttributes.OBJECT_SPEC));
                ItemRevision source1;
                boolean fetchGlobal;
                if (/* true || */alreadyGlobal || Utils.isNullEmpty(spec) || globalFetchFailures.contains(connection)) {
                    source1 = source;
                    fetchGlobal = false;
                } else {
                    Project generic = session.getObjectFactory().getGlobalProject();
                    source1 = generic.createItemRevisionFromSpec(spec);
                    source1.setAttribute(SystemAttributes.ITEMFILE_FILENAME,
                            source.getAttribute(SystemAttributes.ITEMFILE_FILENAME));
                    source1.setAttribute(SystemAttributes.FULL_PATH_NAME,
                            source.getAttribute(SystemAttributes.FULL_PATH_NAME));
                    fetchGlobal = true;
                }
                boolean done = false;
                while (!done) {
                    setFilename(source1, null); // try to make darius happy so it won't query for filename
                    try {
                        boolean expandSubst = TeamUtils.isExpandSubstitution();
                        if (expandModeHolder != null && expandModeHolder.length > 0) {
                            if (expandModeHolder[0] == null) { // no force mode, use preferences, save value used in the same
                                                               // holder
                                expandModeHolder[0] = expandSubst ? ExpandMode.EXPANDED : ExpandMode.UNEXPANDED;
                            } else {
                                expandSubst = ExpandMode.EXPANDED.equals(expandModeHolder[0]) ? true : false;
                            }
                        }

                        if (metadata) {
                            source1.getCopy(target.getAbsolutePath(), expandSubst, true, false);
                        } else {
                            source1.getCopyNoMetadata(target.getAbsolutePath(), expandSubst, true, false);
                        }
                        done = true;
                    } catch (Exception e) {
                        if (fetchGlobal) {
                            // try once more from actual project and remember the failure
                            source1 = source;
                            globalFetchFailures.add(connection);
                            fetchGlobal = false;
                        } else {
                            target.delete(); // it was us who created the file, delete it
                            throw e;
                        }
                    }
                }
            }
        }, new NullProgressMonitor());
    }

    private static final void getTempCopy(final File target, final ItemRevision source,
            final DimensionsConnectionDetailsEx connection, final boolean metadata) throws DMException {
        getTempCopy(target, source, connection, metadata, null);
    }

    /**
     * Collects files from the specified resources. Will not go into
     * non-existent resources or include files that do not exist.
     *
     * @param resources
     * @return list of files
     */
    public static List<IFile> collectFiles(IResource[] resources) {
        return collectFiles(resources, IResource.DEPTH_INFINITE);
    }

    /**
     * Collects files from the specified resources up to the specified depth.
     * Will not go into non-existent resources or include files that do not exist.
     *
     * @param resources
     * @param depth
     *            one of <code>IResource.DEPTH_ZERO</code>, <code>IResource.DEPTH_ONE</code>,
     *            <code>IResource.DEPTH_INFINITE</code>
     * @return list of files
     */
    public static List<IFile> collectFiles(IResource[] resources, final int depth) {
        final Set<IResource> set = (depth == IResource.DEPTH_ONE) ? new HashSet<IResource>(Arrays.asList(resources)) : null;
        final List<IFile> result = new ArrayList<IFile>();
        IResourceVisitor fileCollector = new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                if (resource.getType() == IResource.FILE) {
                    result.add((IFile) resource);
                }
                switch (depth) {
                case IResource.DEPTH_ZERO:
                    return false;
                case IResource.DEPTH_ONE:
                    return set.contains(resource);
                default:
                    return true;
                }
            }
        };
        for (int i = 0; i < resources.length; i++) {
            if (resources[i].exists()) {
                try {
                    resources[i].accept(fileCollector);
                } catch (CoreException ignore) {
                    // shouldn't happen as we check if exists and visitor doesn't throw
                }
            }
        }
        return result;
    }

    /**
     * Return true if the resource is part of a link (i.e. a linked resource or
     * one of it's children.
     *
     * @param container
     * @return boolean
     */
    public static boolean isLinkedResource(IResource resource) {
        // use the CHECK_ANCESTORS variant of isLinked
        // projects and root cannot be links
        if (resource.getType() == IResource.PROJECT || resource.getType() == IResource.ROOT) {
            return false;
        } else {
            return resource.isLinked(IResource.CHECK_ANCESTORS);
        }

    }

    public static IResource[] findResourcesForLocationFile(File resourceFile) {
        URI resourceURI = resourceFile.toURI();
        IWorkspaceRoot workspaceRoot = ResourcesPlugin.getWorkspace().getRoot();
        IResource[] resources = null;
        if (resourceFile.isFile()) {
            resources = workspaceRoot.findFilesForLocationURI(resourceURI);
        } else {
            resources = workspaceRoot.findContainersForLocationURI(resourceURI);
        }
        return resources;
    }

    public static IContainer getProject(IContainer resource) {
        IContainer result = resource;
        URI resourceURI = resource.getLocationURI();
        IWorkspaceRoot workspaceRoot = resource.getWorkspace().getRoot();
        IResource[] resources = workspaceRoot.findContainersForLocationURI(resourceURI);
        if (resources != null) {
            for (IResource currentResource : resources) {
                if (currentResource.getType() == IResource.PROJECT) {
                    result = (IContainer) currentResource;
                    break;
                }
            }
        }
        return result;
    }

    public static Set<IProject> getAllProjectsForLocation(IResource rootResource) {
        final Set<IProject> projects = new HashSet<IProject>();
        if (rootResource.getType() != IResource.FILE) {
            try {
                rootResource.accept(new IResourceVisitor() {
                    @Override
                    public boolean visit(IResource resource) {
                        if (resource.getType() == IResource.PROJECT) {
                            projects.add((IProject) resource);
                        } else if (resource.getType() == IResource.FOLDER) {
                            IContainer container = getProject((IContainer) resource);
                            if (container.getType() == IResource.PROJECT) {
                                projects.add((IProject) container);
                            }
                        }
                        return true;
                    }
                }, IResource.DEPTH_INFINITE, false);
            } catch (CoreException e) {
                DMTeamPlugin.log(e.getStatus());
            }
        }
        return projects;
    }

    public static IFile[] getFiles(IResource[] resources, final IDMWorkspaceResourceFilter filter, boolean includePhantoms)
            throws CoreException {
        Assert.isNotNull(resources);
        if (resources.length == 0) {
            return new IFile[0];
        }
        final ArrayList<IResource> files = new ArrayList<IResource>();
        for (int i = 0; i < resources.length; i++) {
            resources[i].accept(new IResourceVisitor() {
                @Override
                public boolean visit(IResource resource) throws CoreException {
                    if (filter != null) {
                        IDMWorkspaceResource dmResource = DMTeamPlugin.getWorkspace().getWorkspaceResource(resource);
                        if (!filter.select(dmResource)) {
                            return false;
                        }
                    }
                    if (resource.getType() == IResource.FILE) {
                        files.add(resource);
                    }
                    return true;
                }
            }, IResource.DEPTH_INFINITE, includePhantoms);
        }
        return files.toArray(new IFile[files.size()]);
    }

    /**
     * Create .metadata folder for the directory and its parents and mark them as private.
     *
     * @param container
     *            - directory for which directory metadata is to be written
     * @param writeMetadataOnlyForThisFolder
     *            -- Whether to create metadata for this folder or not.
     * @throws CoreException
     */
    public static void ensureReacheable(IContainer container, boolean writeMetadataOnlyForThisFolder) throws CoreException {
        if (writeMetadataOnlyForThisFolder) {
            MetadataHelper.writeMetadataForContainer(container);
            return;
        }
        // work from top to bottom so that any prematurely emitted resource deltas do not flag an orphan subtree
        ArrayList<IContainer> ancestors = new ArrayList<IContainer>();
        IContainer tmpContainer = container;
        IContainer metadataContainer;
        while (tmpContainer.getType() != IResource.PROJECT) {
            ancestors.add(tmpContainer);
            tmpContainer = tmpContainer.getParent();
        }
        for (int i = ancestors.size() - 1; i >= 0; i--) {
            tmpContainer = ancestors.get(i);
            metadataContainer = WorkspaceMetadataManager.getMetadataContainer(tmpContainer.getParent());
            TeamUtils.ensureContainerExists(metadataContainer);
            if (!metadataContainer.isTeamPrivateMember()) {
                metadataContainer.setTeamPrivateMember(true);
            }
        }
    }

    /**
     * Search for parent folder or project with "moved-from" metadata
     *
     * @param resource
     * @return parent or null if resource does not have parents with "moved-from" metadata
     * @throws CoreException
     */
    public static IResource getParentWithMovedFromMetadata(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        IContainer parent = resource.getParent();
        while (parent.getType() != IResource.PROJECT) {
            BaseMetadata metadata;
            metadata = WorkspaceMetadataManager.getInstance().getMetadata(parent);
            String movedFrom = null;
            if (metadata instanceof DirectoryMetadata) {
                movedFrom = ((DirectoryMetadata) metadata).getMovedFrom();
                if (movedFrom != null && movedFrom.length() > 0) {
                    return parent;
                }
            }
            parent = parent.getParent();
        }

        if (parent.getType() == IResource.PROJECT) {
            String movedFrom = ((IProject) parent).getPersistentProperty(DMRepositoryProvider.DM_PROJECT_MOVED_PROP);
            if (movedFrom != null) {
                return parent;
            }
        }

        return null;
    }

    /**
     * Creates repository item path from the supplied path's segments.
     *
     * @return workset or baseline item path
     */
    public static String getItemFullPath(IPath remotePath) {
        return getFullPath(remotePath, true);
    }

    /**
     * Creates repository directory path, i.e. with a trailing separator, from the
     * supplied path's segments.
     *
     * @return workset or baseline directory path
     */
    public static String getFolderFullPath(IPath remotePath) {
        return getFullPath(remotePath, false);
    }

    private static String getFullPath(IPath remotePath, boolean item) {
        if (remotePath.isEmpty()) {
            return Utils.EMPTY_STRING;
        }
        StringBuffer result = new StringBuffer();
        for (int i = 0; i < remotePath.segmentCount(); i++) {
            result.append(remotePath.segment(i));
            result.append('/');
        }
        if (item) {
            result.setLength(result.length() - 1); // strip last /
        }
        return result.toString();
    }

    /**
     * Finds a common ancestor baseline for 2 objects. Objects must come
     * from the same connection.
     *
     * @param o1
     *            project or baseline
     * @param o2
     *            project or baseline
     * @return common ancestor baseline or <code>null</code> if none
     */
    public static Baseline findCommonAncestorBaseline(DimensionsLcObject o1, DimensionsLcObject o2,
            DimensionsObjectFactory factory, DimensionsConnectionDetailsEx con, IProgressMonitor monitor) {
        Assert.isLegal(o1 instanceof Project || o1 instanceof Baseline, "arg1 - project or baseline expected"); //$NON-NLS-1$
        Assert.isLegal(o2 instanceof Project || o2 instanceof Baseline, "arg2 - project or baseline expected"); //$NON-NLS-1$
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.FindAncestorBaseline_message, 2);
        try {
            List<Baseline> ancestors1 = collectBaselines(o1, factory, con);
            monitor.worked(1);
            List<Baseline> ancestors2 = collectBaselines(o2, factory, con);
            monitor.worked(1);

            if (ancestors1.isEmpty() || ancestors2.isEmpty()) {
                return null;
            }

            Baseline[] barr1 = ancestors1.toArray(new Baseline[ancestors1.size()]);
            Baseline[] barr2 = ancestors2.toArray(new Baseline[ancestors2.size()]);

            int idx2 = 0; // initial index for scanning 2nd history

            for (int i = 0; i < barr1.length; i++) {
                Baseline b1 = barr1[i];
                String spec1 = (String) b1.getAttribute(SystemAttributes.OBJECT_SPEC);
                Date createDate1 = con.getDateTimeHelper().getDate((String) b1.getAttribute(SystemAttributes.CREATION_DATE),
                        SystemAttributes.CREATION_DATE);
                for (int j = idx2; j < barr2.length; j++) {
                    Baseline b2 = barr2[j];
                    String spec2 = (String) b2.getAttribute(SystemAttributes.OBJECT_SPEC);
                    Date createDate2 = con.getDateTimeHelper().getDate(
                            (String) b2.getAttribute(SystemAttributes.CREATION_DATE), SystemAttributes.CREATION_DATE);
                    if (spec1.equalsIgnoreCase(spec2)) {
                        return b1; // found the one
                    }
                    if (createDate1.compareTo(createDate2) > 0) {
                        // 1st baseline created after 2nd, remember where we were in the 2nd history
                        // and proceed to previous baseline in the 1st history
                        idx2 = j;
                        break;
                    }
                    // 2nd baseline created at the same time or after the 1st, just
                    // step back in time for 2nd history
                }
            }
            return null;
        } finally {
            monitor.done();
        }

    }

    /*
     * Collects all baselines in the pedigree of the supplied object, returned
     * list is sorted by creation date in descending order (newest first)
     */
    private static List<Baseline> collectBaselines(DimensionsLcObject lcObject, DimensionsObjectFactory factory,
            DimensionsConnectionDetailsEx con) {
        Assert.isLegal(lcObject instanceof Project || lcObject instanceof Baseline, "project or baseline expected"); //$NON-NLS-1$
        ArrayList<Baseline> result = new ArrayList<Baseline>();
        if (lcObject instanceof Project) {
            result.addAll(getBaselines((Project) lcObject, null, factory, con));
        }
        DimensionsLcObject parent = null;
        while ((parent = getParent(lcObject)) != null) {
            Project stream = null;
            DimensionsArObject stopPoint = null; // interested in baselines created no later than this
            if (parent instanceof Project) {
                stream = (Project) parent;
                stopPoint = lcObject;
            } else if (parent instanceof Baseline) {
                DimensionsLcObject p = getParent(parent);
                if (p instanceof Project) {
                    stream = (Project) p;
                    stopPoint = parent;
                }
            } else {
                assert false;
            }
            if (stream == null) {
                break; // hit a baseline with no parent project, abort traversal
            }
            List<Baseline> baselines = getBaselines(stream, stopPoint, factory, con);
            result.addAll(baselines);
            lcObject = stream;
        }
        return result;
    }

    /**
     * Obtains a parent for a workset or baseline. This method must be called
     * within session runnable.
     *
     * @param arObject
     * @return
     */
    @SuppressWarnings("unchecked")
    public static DimensionsLcObject getParent(DimensionsArObject arObject) {
        Assert.isNotNull(arObject);
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(FilterOptions.DERIVED_RELATIONSHIP, Boolean.TRUE, 0));
        DimensionsLcObject result = null;
        arObject.flushRelatedObjects(Project.class, false);
        List<DimensionsRelatedObject> basedOnWorksets = arObject.getParentProjects(filter);
        arObject.flushRelatedObjects(Project.class, false);
        if (!basedOnWorksets.isEmpty()) {
            result = (Project) basedOnWorksets.get(0).getObject();
        } else if (arObject instanceof Project) { // baseline cannot be based on a baseline
            arObject.flushRelatedObjects(Baseline.class, false);
            List<DimensionsRelatedObject> basedOnBaselines = arObject.getParentBaselines(filter);
            arObject.flushRelatedObjects(Baseline.class, false);
            if (!basedOnBaselines.isEmpty()) {
                result = (Baseline) basedOnBaselines.get(0).getObject();
            }
        }
        if (result == null) {
            return null;
        }
        if (result.getAttribute(SystemAttributes.OBJECT_SPEC) == null) {
            result.queryAttribute(SystemAttributes.OBJECT_SPEC);
            if (result.getAttribute(SystemAttributes.OBJECT_SPEC) == null) {
                return null; // deleted object
            }
        }
        return result;
    }

    /**
     * Obtains a list of baselines derived from the supplied project ordered
     * by their creation date, newest first. Additionally caches the creation date attribute.
     *
     * @param project
     * @param until
     *            do not include baseline pass creation date of this object, optional
     * @return a list of <code>Baseline</code>
     */
    @SuppressWarnings("unchecked")
    private static List<Baseline> getBaselines(Project project, DimensionsArObject until, DimensionsObjectFactory factory,
            DimensionsConnectionDetailsEx con) {
        Assert.isNotNull(project);
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(FilterOptions.DERIVED_RELATIONSHIP, Boolean.TRUE, 0));
        filter.orders().add(new Filter.Order(SystemAttributes.CREATION_DATE, Filter.ORDER_DESCENDING));

        project.flushRelatedObjects(Baseline.class, true);
        List<DimensionsRelatedObject> rels = project.getChildBaselines(filter);
        project.flushRelatedObjects(Baseline.class, true);
        if (rels.isEmpty()) {
            return Collections.emptyList();
        }
        List<Baseline> result = new LinkedList<Baseline>(); // use a linked list for faster element removal
        for (Iterator<DimensionsRelatedObject> iter = rels.iterator(); iter.hasNext();) {
            result.add((Baseline) iter.next().getObject());
        }

        // client-site filtering to overcome mssql date filtering problem
        if (!result.isEmpty()) {
            BulkOperator bo = factory.getBulkOperator(result);
            bo.queryAttribute(SystemAttributes.CREATION_DATE);
            if (until != null) {
                if (until.getAttribute(SystemAttributes.CREATION_DATE) == null) {
                    until.queryAttribute(SystemAttributes.CREATION_DATE);
                }
                String untilDateStr = (String) until.getAttribute(SystemAttributes.CREATION_DATE);
                Date untilDate = con.getDateTimeHelper().getDate(untilDateStr, SystemAttributes.CREATION_DATE);

                for (Iterator<Baseline> iter = result.iterator(); iter.hasNext();) {
                    Baseline aBaseline = iter.next();
                    String creationDateStr = (String) aBaseline.getAttribute(SystemAttributes.CREATION_DATE);
                    Date creationDate = con.getDateTimeHelper().getDate(creationDateStr, SystemAttributes.CREATION_DATE);
                    if (creationDate.compareTo(untilDate) > 0) {
                        iter.remove();
                    }
                }
            }
        }
        return result;
    }

    public static String convertSelection(IResource[] resources) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < resources.length; i++) {
            IResource resource = resources[i];
            if (i > 0) {
                buffer.append(", "); //$NON-NLS-1$
            }
            buffer.append(resource.getFullPath());
        }
        return buffer.toString();
    }

    /**
     * Sets <code>SystemAttributes.ITEMFILE_FILENAME</code> attribute of
     * the supplied item revision to the supplied filename. If the supplied
     * filename is <code>null</code> and the <code>SystemAttributes.FULL_PATH_NAME</code> attribute is not <code>null</code> then
     * sets item filename to the last
     * segment of the full path.
     *
     * @param revision
     * @param filename
     *            filename to set or <code>null</code>
     */
    public static void setFilename(ItemRevision revision, String filename) {
        if (revision.getAttribute(SystemAttributes.ITEMFILE_FILENAME) != null) {
            return; // nothing to do
        }
        if (filename == null) {
            // extract from full path as the last resort
            String fullPath = (String) revision.getAttribute(SystemAttributes.FULL_PATH_NAME);
            if (fullPath != null) {
                int idx = fullPath.lastIndexOf('/');
                if (idx != -1 && idx != fullPath.length() - 1) {
                    filename = fullPath.substring(idx + 1);
                }
            }
        }
        if (filename != null) {
            revision.setAttribute(SystemAttributes.ITEMFILE_FILENAME, filename);
        }
    }

    /**
     * Parses a comma-delimited revisions string into a sorted set.
     *
     * @param revisions
     * @return
     */
    public static SortedSet<String> parseRevisionList(String revisions) {
        TreeSet<String> revisionSet = new TreeSet<String>();
        StringTokenizer st = new StringTokenizer(revisions, ","); //$NON-NLS-1$
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            revisionSet.add(token);
        }
        return revisionSet;
    }

    /**
     * Method equals.
     *
     * @param syncBytes
     * @param oldBytes
     * @return boolean
     */
    public static boolean equals(byte[] syncBytes, byte[] oldBytes) {
        if (syncBytes == null || oldBytes == null) {
            return syncBytes == oldBytes;
        }
        if (syncBytes.length != oldBytes.length) {
            return false;
        }
        for (int i = 0; i < oldBytes.length; i++) {
            if (oldBytes[i] != syncBytes[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Creates a folder and its parents as necessary. Container's project
     * must already exist prior to calling this method
     */
    public static void ensureContainerExists(IContainer container) throws CoreException {
        ensureContainerExists(container, null);
    }

    /**
     * Creates a folder and its parents as necessary. Container's project
     * must already exist prior to calling this method
     */
    public static void ensureContainerExists(IContainer container, MetadataProvider provider) throws CoreException {
        if (!container.exists()) {
            container.refreshLocal(IResource.DEPTH_INFINITE, null); // try to sync up with filesystem
        }

        if (container.exists()) {
            return;
        }

        if (container.getType() == IResource.PROJECT) {
            Assert.isLegal(false, "Oops... non-existing project!!!"); //$NON-NLS-1$
        }
        ensureContainerExists(container.getParent(), provider);
        ((IFolder) container).create(false /* force */, true/* local */, null /* Utils.subMonitorFor(monitor, 100) */);

        MetadataProvider mdSession = null;
        if (provider == null) {
            mdSession = MetadataProviderFactory.providerFor(container);
        } else {
            mdSession = provider;
        }
        try {
            // Set hidden attribute for .metadata directories
            if (mdSession.metadataDirname().equals(container.getName())) {
                ResourceAttributes resAttributes = container.getResourceAttributes();
                if (resAttributes != null) {
                    resAttributes.setHidden(true);
                    container.setResourceAttributes(resAttributes);
                }
            }
        } finally {
            if (provider == null && mdSession != null) {
                mdSession.close();
            }
        }
    }

    public static class ForeignInfo {

        public ForeignInfo(IDMProject project, String foreignStream) {
            this.project = project;
            this.foreignStream = foreignStream;
        }

        public IDMProject getProject() {
            return project;
        }

        public String getForeignStream() {
            return foreignStream;
        }

        private IDMProject project;
        private String foreignStream;
    }

    /**
     * Checks whether the resource in your workspace has come from a foreign stream or not.
     *
     * @param local
     * @return
     */
    public static boolean isResourceFromForeignStream(IResource local) {
        return isResourceFromForeignStreamEx(local, null);
    }

    /**
     * Checks whether the resource in your workspace has come from a foreign stream or not and
     * sets the holder value if true
     *
     * @param local
     * @param foreignStreamHolder
     * @return
     */
    public static boolean isResourceFromForeignStreamEx(IResource local, ForeignInfo[] foreignStreamHolder) {
        try {
            if (debugResources) {
                System.out.println("TU irffs " + local.toString()); //$NON-NLS-1$
            }
            if (local.getType() == IResource.PROJECT) {
                return false;
            }

            DMProject dmProject;
            try {
                dmProject = TeamUtils.getDmProject(local);
                local = TeamUtils.getResource(local);
            } catch (CoreException e) {
                throw TeamException.asTeamException(e);
            }

            String projID = dmProject.getId();
            // Check for Global workset is added because when you do a "Mark as merged" the project in the metadata file is set as
            // $GLOBAL:$GENERAL and not the actual project of the item being marked as merged
            // So we need to exclude $GLOBAL:$GENERAL from the list of foreign streams
            if (projID.equals(IDMConstants.GLOBAL_WORKSET)) {
                return false;
            }
            BaseMetadata metaData = WorkspaceMetadataManager.getInstance().getMetadata(local);
            if (metaData == null) {
                return false;
            }
            DMRemoteResource remote = (DMRemoteResource) DMTeamPlugin.getWorkspace().getRemoteResource(local);

            if (local.getType() == IResource.FILE) {
                // Item exists in the repository
                if (remote != null && (((DMRemoteFile) remote).getUid() == ((ItemMetadata) metaData).getItemUid())) {
                    return false;
                }
                String filesProject = ((ItemMetadata) metaData).getProject();
                if (!projID.equals(filesProject)) {
                    if (foreignStreamHolder != null && foreignStreamHolder.length > 0) {
                        foreignStreamHolder[0] = new ForeignInfo(dmProject, filesProject);
                    }
                    return true;
                }
            } else if (local.getType() == IResource.FOLDER) {
                String foldersProject = ((DirectoryMetadata) metaData).getProject();
                if (!projID.equals(foldersProject)) {
                    if (foreignStreamHolder != null && foreignStreamHolder.length > 0) {
                        foreignStreamHolder[0] = new ForeignInfo(dmProject, foldersProject);
                        ;
                    }
                    return true;
                }
            }
        } catch (CoreException ce) {
            return false;
        }

        return false;
    }

    /**
     * This method checks whether the resource falls under the following use case.
     * The use case is as follows:
     * A file has been deleted ( file alone or along with its parent folder ) from a Child Stream. Now you want to apply this
     * deletion back to Parent Stream.
     * As per the best practices you will update your local workspace with the contents from Parent Stream.Then you switch your
     * workspace to
     * Child Stream and do a sync. The deleted file will be shown as an outgoing addition. Do an Override and Update to delete the
     * file
     * on disk.Under normal situation the metadata is deleted along with the file/folder. We do not delete the metadata as this
     * will result in the file deletion being shown as incoming addition instead of an outgoing deletion when you switch back to
     * Parent Stream and do a sync. But at the same time the presence of metadata will cause another problem, ie, if we do a
     * resync
     * with the Child Stream this deleted file/folder will be shown as
     * an outgoing deletion due to the presence of metadata.In order to get around this issue we add
     * "metadata-of-deleted-foreign-resource=yes"
     * tag to the metadata ,which is used not to show the file in sync view when you do a resync with the Child Stream
     *
     * @param resource
     * @return
     * @throws CoreException
     */
    public static boolean isSpecialCaseOfFolderAndFileDeletion(IResource resource, boolean inForeignStream)
            throws CoreException {
        BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
        String foreignItemDeletionTagValue = null;

        if ((TeamUtils.isLocalWorksetAStream(resource) != null
                && TeamUtils.isLocalWorksetPointingToForeignStream(resource) == inForeignStream)
                || (TeamUtils.isLocalWorksetAProject(resource) != null
                        && TeamUtils.isLocalWorksetPointingToForeignProject(resource) == inForeignStream)) {
            if (metadata != null) {
                foreignItemDeletionTagValue = metadata.get(TeamUtils.METADATA_OF_DELETED_FOREIGN_RESOURCE);
                if (foreignItemDeletionTagValue != null && foreignItemDeletionTagValue.equals("yes")) { //$NON-NLS-1$
                    return true;
                }
            } else if (resource.getType() == IResource.FOLDER) {
                // check whether its parent is deleted
                IResource parent = resource.getParent();
                while (parent != null && parent.getType() != IResource.PROJECT) {
                    metadata = WorkspaceMetadataManager.getInstance().getMetadata(parent);
                    if (metadata != null) {
                        foreignItemDeletionTagValue = metadata.get(TeamUtils.METADATA_OF_DELETED_FOREIGN_RESOURCE);
                        if (foreignItemDeletionTagValue != null && foreignItemDeletionTagValue.equals("yes")) { //$NON-NLS-1$
                            return true;
                        }
                    }
                    parent = parent.getParent();
                }
            }
        }
        return false;
    }

    /**
     * Refreshes the resource and any non-existent parents.
     */
    public static long refreshLocal(IResource resource, IProgressMonitor monitor) throws CoreException {
        return refreshLocal(resource, IResource.DEPTH_INFINITE, monitor);
    }

    /**
     * Refreshes the resource up to the specified depth, if any parents up the
     * hierarchy are missing they are refreshed with depth one to the level of
     * the specified resource,
     */
    public static long refreshLocal(IResource resource, int depth, IProgressMonitor monitor) throws CoreException {
        if (debugResources) {
            System.out.println("TU refreshLocal " + resource.toString() + " depth " + depth); //$NON-NLS-1$ //$NON-NLS-2$
        }
        ArrayList<IContainer> missingParents = null;
        IContainer parent = resource.getParent();
        while (parent != null && !parent.exists()) {
            if (missingParents == null) {
                missingParents = new ArrayList<IContainer>();
            }
            missingParents.add(parent);
            parent = parent.getParent();
        }
        monitor = Utils.monitorFor(monitor);
        if (missingParents != null && !missingParents.isEmpty()) {
            try {
                monitor.beginTask(null, 10 * missingParents.size() + 10);
                for (int i = missingParents.size() - 1; i >= 0; i--) { // refresh top->down
                    IContainer aMissingParent = missingParents.get(i);
                    aMissingParent.refreshLocal(IResource.DEPTH_ONE, Utils.subMonitorFor(monitor, 10));
                }
                resource.refreshLocal(depth, Utils.subMonitorFor(monitor, 10));
            } finally {
                monitor.done();
            }
        } else {
            resource.refreshLocal(depth, monitor);
        }
        return resource.getModificationStamp();
    }

    /**
     * Copies remote contents to local file creating the local file and its
     * parent folders if necessary.
     */
    public static void copy(IDMRemoteFile remote, IFile local, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        try {
            monitor.beginTask(null, 100);
            if (local.exists()) {
                local.setContents(remote.getStorage(Utils.subMonitorFor(monitor, 90)).getContents(), IResource.KEEP_HISTORY,
                        Utils.subMonitorFor(monitor, 10));
            } else {
                ensureContainerExists(local.getParent()/* , Utils.subMonitorFor(monitor, 10) */);
                ItemRevision itemRevision = remote.getItemRevision();
                itemRevision.getCopy(local.getLocation().toOSString(), false, true, false);
                local.refreshLocal(IResource.DEPTH_ZERO, Utils.subMonitorFor(monitor, 10));
            }
        } finally {
            monitor.done();
        }
    }

    /**
     * @return item spec id as a part of item spec without the revision, if
     *         revision suffix cannot be found returns the supplied sped
     */
    public static String getItemSpecId(String itemSpec) {
        int idx = itemSpec.lastIndexOf(';');
        if (idx < 0) {
            return itemSpec;
        }
        return itemSpec.substring(0, idx);

    }

    /**
     * @return revision or <code>null</code> if revision cannot be extracted
     *         from the supplied spec
     */
    public static String extractRevisionFromSpec(String itemSpec) {
        int idx = itemSpec.lastIndexOf(';');
        if (idx < 0) {
            return null;
        }
        return itemSpec.substring(idx + 1);
    }

    /**
     * Method getNonOverlapping ensures that a resource is not covered more than
     * once.
     *
     * @param resources
     * @return IResource[]
     */
    public static IResource[] getNonOverlapping(IResource[] resources) {
        Assert.isLegal(resources != null);
        if (resources.length == 0 || resources.length == 1) {
            return resources.clone();
        }

        // Sort the resources so the shortest paths are first
        SortedSet<IResource> sorted = new TreeSet<IResource>(new ContainmentComparator());
        sorted.addAll(Arrays.asList(resources));

        return collectNonOverlapping(sorted, null);
    }

    /**
     * Method getNonOverlapping ensures that a resource is not covered more than
     * once.
     *
     * @param resources
     *            already sorted tree by {@link ContainmentComparator}
     * @return IResource[]
     */
    public static IResource[] getNonOverlapping(SortedSet<IResource> resources) {
        Assert.isLegal(resources != null);
        if (resources.size() == 0 || resources.size() == 1) {
            return resources.toArray(new IResource[resources.size()]);
        }
        return collectNonOverlapping(resources, null);
    }

    interface OverlappingStatsCallback {
        boolean fileAdded();

        boolean isStatsLimitReached();
    }

    /**
     * Method getNonOverlapping ensures that a resource is not covered more than
     * once.
     *
     * @param resources
     *            already sorted tree by {@link ContainmentComparator}
     * @param stats
     *            callback that increases files counter if single
     *            non-overlapping file was found
     * @return IResource[] if resources were found or null if operation was
     *         cancelled by callback
     */
    public static IResource[] getNonOverlappingWithStats(SortedSet<IResource> resources, OverlappingStatsCallback stats) {
        Assert.isLegal(resources != null);
        if (resources.size() == 0 || resources.size() == 1) {
            return resources.toArray(new IResource[resources.size()]);
        }
        return collectNonOverlapping(resources, stats);
    }

    private static IResource[] collectNonOverlapping(SortedSet<IResource> resources, OverlappingStatsCallback stats) {
        if (stats != null && stats.isStatsLimitReached()) {
            return null;
        }
        // Collect all non-overlapping resources
        List<IPath> coveredPaths = new ArrayList<IPath>();
        for (Iterator<IResource> iter = resources.iterator(); iter.hasNext();) {
            IResource resource = iter.next();
            IPath resourceFullPath = resource.getFullPath();
            boolean covered = false;
            for (Iterator<IPath> it = coveredPaths.iterator(); it.hasNext();) {
                IPath path = it.next();
                if (path.isPrefixOf(resourceFullPath)) {
                    covered = true;
                }
            }
            if (covered) {
                // if the resource is covered by a parent, remove it
                iter.remove();
            } else {
                // if the resource is a non-covered folder, add it to the
                // covered paths
                if (resource.getType() != IResource.FILE) {
                    coveredPaths.add(resource.getFullPath());
                } else if (stats != null) {
                    // if resource is a non-covered file increase stats
                    if (!stats.fileAdded()) {
                        // if stats can't be increased stop analyze
                        return null;
                    }
                }
            }
        }
        return resources.toArray(new IResource[resources.size()]);
    }

    /**
     * Method getNonOverlapping ensures that a resource is not covered more than once.
     *
     * @param resources
     * @param depth
     *            depth context
     * @return IResource[]
     * @see IResource#DEPTH_INFINITE
     * @see IResource#DEPTH_ONE
     * @see IResource#DEPTH_ZERO
     */
    public static IResource[] getNonOverlapping(IResource[] resources, int depth) {
        if (depth == IResource.DEPTH_INFINITE) {
            return getNonOverlapping(resources);
        }

        Assert.isLegal(resources != null);
        if (resources.length == 0 || resources.length == 1) {
            return resources.clone();
        }

        // Sort the resources so the shortest paths are first
        Set<IResource> sorted = new TreeSet<IResource>(new ContainmentComparator());
        if (depth == IResource.DEPTH_ONE) {
            Set<IResource> containers = new HashSet<IResource>();
            for (int i = 0; i < resources.length; i++) {
                if (resources[i].getType() != IResource.FILE) {
                    containers.add(resources[i]);
                }
            }
            for (int i = 0; i < resources.length; i++) {
                if (!containers.contains(resources[i].getParent())) {
                    sorted.add(resources[i]);
                }
            }
        } else if (depth == IResource.DEPTH_ZERO) {
            sorted.addAll(Arrays.asList(resources));
        } else {
            assert false;
            return resources;
        }
        return sorted.toArray(new IResource[sorted.size()]);
    }

    public static void deltree(File root) {
        if (!root.exists()) {
            return;
        }
        if (root.isDirectory()) {
            // delete any children as only empty dirs can be deleted
            File[] children = root.listFiles();
            if (children != null) {
                for (int i = 0; i < children.length; i++) {
                    deltree(children[i]);
                }
            }
        }
        if (!root.delete()) {
            // not a bid deal but log it anyway
            DMTeamPlugin.log(DMTeamStatus.createErrorStatus(0, "failed to delete file: " + root.getAbsolutePath())); //$NON-NLS-1$
        }
    }

    /**
     * @return appropriate buffer size for reading a file of the specified size
     */
    public static int getReadBufferSize(long fileSize) {
        // use 10KB buffer for small files
        int bufferSize = 10 * 1024;
        if (fileSize > 100 * 1024) {
            // use 100KB buffer for medium-sized files
            bufferSize = 100 * 1024;
        }
        if (fileSize > 1000 * 1024) {
            // use 1MB buffer for large files
            bufferSize = 1000 * 1024;
        }
        return bufferSize;
    }

    /**
     * <p>
     * Provides a hint if a file was modified since it was written or read by us in the same session.
     * <p>
     * Note that the value returned is a hint so plan for false positives.
     */
    public static boolean isExternallyModified(IResource file) {
        if (!file.exists()) {
            return true;
        }
        Long storedTimestamp = null;
        try {
            storedTimestamp = (Long) file.getSessionProperty(MODSTAMP_KEY);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
        if (storedTimestamp == null) {
            return true;
        }
        return storedTimestamp.longValue() != file.getModificationStamp();
    }

    /**
     * Reads all lines of the specified file.
     * Returns null if the file does not exist.
     */
    public static String[] readLines(IFile file, boolean cacheTimestamp) throws CoreException {
        try {
            if (!file.exists()) {
                return null;
            }
            // Perform a forced read (ignoring out-of-sync)
            BufferedReader reader = new BufferedReader(new InputStreamReader(file.getContents(true)),
                    getReadBufferSize(file.getLocation().toFile().length()));
            List<String> fileContentStore = new ArrayList<String>();
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    fileContentStore.add(line);
                }
                if (cacheTimestamp) {
                    file.setSessionProperty(MODSTAMP_KEY, new Long(file.getModificationStamp()));
                }
                return fileContentStore.toArray(new String[fileContentStore.size()]);
            } finally {
                reader.close();
            }
        } catch (IOException e) {
            throw new DMException("File I/O failed", e); //$NON-NLS-1$
        } catch (CoreException e) {
            // If the IFile doesn't exist or the underlying File doesn't exist,
            // just return null to indicate the absence of the file
            if (e.getStatus().getCode() == IResourceStatus.RESOURCE_NOT_FOUND
                    || e.getStatus().getCode() == IResourceStatus.FAILED_READ_LOCAL) {
                return null;
            }
            throw e;
        }
    }

    /**
     * Writes all lines to the specified file, using platform specific line terminators.
     */
    public static void writeLines(final IFile file, final String[] contents) throws CoreException {
        // Write file in a runnable in order for the resulting delta to be fired when
        // the MODSTAMP value has been already set. If not in a runnable then create/setContents
        // may trigger a delta before the property is set. Note that it is still possible
        // that deltas will be fired prior to the completion so this
        // is not a reliable mechanism but is still ok for our purposes
        ResourcesPlugin.getWorkspace().run(new IWorkspaceRunnable() {
            @Override
            public void run(IProgressMonitor monitor) throws CoreException {
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                try {
                    writeLinesToStreamAndClose(os, contents);
                } catch (IOException ioe) {
                    throw new DMException("IO error", ioe); //$NON-NLS-1$
                }
                if (!file.exists()) {
                    file.create(new ByteArrayInputStream(os.toByteArray()),
                            IResource.FORCE /* don't keep history but do force */, null);
                } else {
                    file.setContents(new ByteArrayInputStream(os.toByteArray()),
                            IResource.FORCE /* don't keep history but do force */, null);
                }
                file.setSessionProperty(MODSTAMP_KEY, new Long(file.getModificationStamp()));
            }
        }, ResourcesPlugin.getWorkspace().getRuleFactory().createRule(file), IWorkspace.AVOID_UPDATE, null);
    }

    private static void writeLinesToStreamAndClose(OutputStream os, String[] contents) throws IOException {
        byte[] lineEnd = getLineDelimiter();
        try {
            for (int i = 0; i < contents.length; i++) {
                os.write(contents[i].getBytes());
                os.write(lineEnd);
            }
        } finally {
            os.close();
        }
    }

    private static byte[] getLineDelimiter() {
        if (DMTeamPlugin.getDefault().isUsePlatformLineend()) {
            String property = System.getProperty("line.separator"); //$NON-NLS-1$
            if (property != null) {
                return property.getBytes();
            }
        }
        return new byte[] { 0x0A };
    }

    /**
     * Creates resource variants for the supplied revisions.
     *
     * @return variants
     */
    public static IDMRemoteFile[] getVariants(DimensionsConnectionDetailsEx connection, final ItemRevision[] revs,
            IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            final Session session = connection.openSession(Utils.subMonitorFor(monitor, 1));
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    Utils.queryAttributes(revs, DMRemoteFile.RESOURCE_VARIANT_ATTRS_FILE); // DEF168449 fix
                }
            }, monitor);
            IDMRemoteFile[] result = new IDMRemoteFile[revs.length];
            for (int i = 0; i < revs.length; i++) {
                Path path = new Path(""); //$NON-NLS-1$
                Object attr = revs[i].getAttribute(SystemAttributes.FULL_PATH_NAME);
                if (attr != null) {
                    path = new Path((String) attr);
                }
                result[i] = new DMRemoteFile(path, connection, revs[i]);
            }
            return result;
        } finally {
            monitor.done();
        }
    }

    /**
     * Creates remote folder.
     *
     * @return remote folder
     */
    public static IDMRemoteFolder createRemoteFolder(DMRemoteFolder parent, IPath path, IDMProject project,
            IDMRemoteTree tree) {
        DMRemoteFolder remoteFolder = new DMRemoteFolder(parent, path, project, tree);
        return remoteFolder;
    }

    /**
     * This will cache remote contents locally in the resource variant cache
     *
     * @param v1
     * @param v2
     * @param monitor
     * @throws TeamException
     */
    public static void cacheContents(IDMRemoteFile v1, IDMRemoteFile v2, IProgressMonitor monitor) throws TeamException {
        int work = Math.max((v2 == null ? 0 : 50) + (v1 == null ? 0 : 50), 10);
        monitor.beginTask(null, work);
        try {
            if (v1 != null) {
                v1.getStorage(Utils.subMonitorFor(monitor, 50));
            }
            if (v2 != null) {
                v2.getStorage(Utils.subMonitorFor(monitor, 50));
            }
        } finally {
            monitor.done();
        }
    }

    /**
     * "Cancels" checkout on resources whose metadata contains stale
     * checkout information.
     *
     * @param resources
     * @param monitor
     * @throws CoreException
     */
    public static IDMWorkspaceResource[] cleanInvalidCheckouts(IDMWorkspaceResource[] resources, IProgressMonitor monitor)
            throws CoreException {
        ArrayList<IDMWorkspaceFile> result = new ArrayList<IDMWorkspaceFile>();
        try {
            HashMap<IDMProject, ArrayList<IDMWorkspaceFile>> checkoutsByProject = new HashMap<IDMProject, ArrayList<IDMWorkspaceFile>>();
            for (int i = 0; i < resources.length; i++) {
                IDMWorkspaceResource resource = resources[i];
                if (resource instanceof IDMWorkspaceFile) {
                    IDMWorkspaceFile dmFile = (IDMWorkspaceFile) resource;
                    if (dmFile.isExtracted()) {
                        IDMProject dmProject = dmFile.getProject();
                        ArrayList<IDMWorkspaceFile> checkouts = checkoutsByProject.get(dmProject);
                        if (checkouts == null) {
                            checkouts = new ArrayList<IDMWorkspaceFile>();
                            checkoutsByProject.put(dmProject, checkouts);
                        }
                        checkouts.add(dmFile);
                    }
                }
            }

            monitor = Utils.monitorFor(monitor);
            monitor.beginTask(null, 1000 * checkoutsByProject.size());

            for (Iterator<Entry<IDMProject, ArrayList<IDMWorkspaceFile>>> entryIter = checkoutsByProject.entrySet()
                    .iterator(); entryIter.hasNext();) {
                Entry<IDMProject, ArrayList<IDMWorkspaceFile>> entry = entryIter.next();
                ArrayList<IDMWorkspaceFile> checkouts = entry.getValue();

                if (!checkouts.isEmpty()) {
                    IDMProject dmProject = entry.getKey();

                    final ArrayList<ItemRevision> revisions = new ArrayList<ItemRevision>(checkouts.size());
                    for (Iterator<IDMWorkspaceFile> iter = checkouts.iterator(); iter.hasNext();) {
                        IDMWorkspaceFile dmFile = iter.next();
                        IDMRemoteFile base = dmFile.getBaseFile();
                        revisions.add(base.getItemRevision());
                    }

                    final Session session = dmProject.getConnection().openSession(null);
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            Utils.queryAttributes(revisions, new int[] { SystemAttributes.IS_EXTRACTED },
                                    session.getObjectFactory(), false);
                        }
                    }, monitor);

                    monitor.worked(200);

                    ArrayList<UndoCheckoutRequest> undoCheckoutRequests = new ArrayList<UndoCheckoutRequest>();
                    ArrayList<IResource> remoteRefresh = new ArrayList<IResource>();
                    for (int i = 0; i < checkouts.size(); i++) {
                        IDMWorkspaceFile dmFile = checkouts.get(i);
                        ItemRevision rev = revisions.get(i);
                        Boolean b = (Boolean) rev.getAttribute(SystemAttributes.IS_EXTRACTED);

                        UndoCheckoutRequest ucr = null;
                        if (b == null) { // extracted revision is missing - replace with latest md
                            if (dmFile.hasRemote()) {
                                ucr = new UndoCheckoutRequest(dmFile.getLocalFile(), rev);
                                ucr.setMetadataReplace(UndoCheckoutRequest.REPLACE_LATEST);
                                result.add(dmFile);
                                remoteRefresh.add(dmFile.getLocalResource());
                            }
                        } else if (!b.booleanValue()) { // revision is no longer extracted - replace with md corresponding to base
                            ucr = new UndoCheckoutRequest(dmFile.getLocalFile(), rev);
                            ucr.setMetadataReplace(UndoCheckoutRequest.REPLACE_BASE);
                            result.add(dmFile);
                        }
                        if (ucr != null) {
                            ucr.setReplace(UndoCheckoutRequest.REPLACE_METADATA_ONLY);
                            ucr.setMakeReadOnly(dmFile.getLocalFile().isReadOnly());
                            undoCheckoutRequests.add(ucr);
                        }

                    }

                    if (!undoCheckoutRequests.isEmpty()) {
                        IProgressMonitor undoMonitor = Utils.subMonitorFor(monitor, 800);
                        int refreshUnits = remoteRefresh.size() * 10;
                        undoMonitor.beginTask(null, (undoCheckoutRequests.size() * 10) + refreshUnits);
                        if (!remoteRefresh.isEmpty()) {
                            ((DMWorkspace) DMTeamPlugin.getWorkspace()).refreshRemoteTree(
                                    remoteRefresh.toArray(new IResource[remoteRefresh.size()]), IResource.DEPTH_INFINITE,
                                    Utils.subMonitorFor(undoMonitor, refreshUnits));
                        }
                        for (Iterator<UndoCheckoutRequest> iter = undoCheckoutRequests.iterator(); iter.hasNext();) {
                            UndoCheckoutRequest request = iter.next();
                            request.processReplace(Utils.subMonitorFor(undoMonitor, 10));
                        }
                        undoMonitor.done();
                    } else {
                        monitor.worked(800);
                    }
                }
            }
        } finally {
            monitor.done();
        }
        return result.toArray(new IDMWorkspaceResource[result.size()]);
    }

    /**
     * @param theFile
     *            file to check for variant
     * @return an IFile for the variant or null if no match or error
     */
    public static IFile findVariantFile(IFile theFile) throws CoreException {
        IResource[] resources = theFile.getParent().members();
        for (int i = 0; i < resources.length; i++) {
            if (resources[i].getType() == IResource.FILE) {
                if (theFile.getName().equalsIgnoreCase(resources[i].getName())) {
                    return (IFile) resources[i];
                }
            }
        }
        return null;
    }

    /**
     * Obtains a value for project-level cm rules, must be called from a session
     * runnable.
     *
     * @param project
     * @param forceQuery
     *            pass <code>true</code> to force query even if the supplied
     *            project already has the attribute
     * @return
     * @see IDMConstants#PROJECT_CM_RULES_DEFAULT
     * @see IDMConstants#PROJECT_CM_RULES_ON
     * @see IDMConstants#PROJECT_CM_RULES_OFF
     */
    public static char getProjectCmRulesSetting(Project project, boolean forceQuery) {
        Assert.isNotNull(project);
        String s = (String) project.getAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
        if (s == null || forceQuery) {
            project.queryAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
            s = (String) project.getAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
        }
        if (s != null && s.length() == 1) {
            switch (Character.toUpperCase(s.charAt(0))) {
            case IDMConstants.PROJECT_CM_RULES_ON:
                return IDMConstants.PROJECT_CM_RULES_ON;
            case IDMConstants.PROJECT_CM_RULES_OFF:
                return IDMConstants.PROJECT_CM_RULES_OFF;
            }
        }
        return IDMConstants.PROJECT_CM_RULES_DEFAULT;
    }

    /**
     * Convenience method to return the parent of the given resource,
     * or the resource itself for projects and the workspace root.
     *
     * @param resource
     *            the resource to compute the parent of
     * @return the parent resource for folders and files, and the
     *         resource itself for projects and the workspace root.
     */
    public static IResource parent(IResource resource) {
        switch (resource.getType()) {
        case IResource.ROOT:
        case IResource.PROJECT:
            return resource;
        default:
            return resource.getParent();
        }
    }

    /**
     * Finds the deepest resource with metadata on the path to the supplied
     * resource. If no resources are found returns project, if workspace root or
     * project is supplied it is immediately returned back.
     *
     * @param resource
     * @return
     * @throws TeamException
     */
    public static IResource findDeepestManagedResource(IResource resource) throws TeamException {
        if (resource.getType() == IResource.ROOT || resource.getType() == IResource.PROJECT
                || DMTeamPlugin.getWorkspace().isManaged(resource)) {
            return resource;
        }
        return findDeepestManagedResource(resource.getParent());
    }

    /**
     * Constructs base filename string that is to be stored in
     * TS_VCACTIONS.TS_FILENAME as <code>project-spec/project-path</code>.
     *
     * @param project
     * @param relativePath
     * @return
     */
    public static String getBaseSbmFilename(String project, String relativePath) {
        StringBuffer buf = new StringBuffer();
        buf.append(project);
        relativePath = relativePath.replace('\\', '/');
        if (relativePath.charAt(relativePath.length() - 1) == '/') {
            relativePath = relativePath.substring(0, relativePath.length() - 1);
        }
        if (relativePath.charAt(0) != '/') {
            buf.append('/');
        }
        buf.append(relativePath);
        return buf.toString();
    }

    /**
     * Constructs full filename string that is to be stored in
     * TS_VCACTIONS.TS_FILENAME as <code>base-filename {itemspec)</code>.
     *
     * @param baseFilename
     * @param itemSpec
     * @param asItemSpecId
     * @return
     */
    public static String getFullSbmFilename(String baseFilename, String itemSpec, boolean asItemSpecId) {
        if (baseFilename == null) {
            baseFilename = Utils.EMPTY_STRING;
        }
        if (itemSpec == null) {
            itemSpec = Utils.EMPTY_STRING;
        }
        String spec = asItemSpecId ? getItemSpecId(itemSpec) : itemSpec;
        return baseFilename + " (" + spec + ")"; //$NON-NLS-1$ //$NON-NLS-2$
    }

    /**
     * Constructs a string that can be used to get the associations from
     * TS_VCACTIONS.TS_FILENAME using the spec.
     *
     * @param itemSpec
     * @param asItemSpecId
     * @return
     */
    public static String getSbmFilenameQuery(String itemSpec, boolean asItemSpecId) {
        if (itemSpec == null) {
            itemSpec = Utils.EMPTY_STRING;
        }
        String spec = asItemSpecId ? getItemSpecId(itemSpec) : itemSpec;
        return "%(" + spec + ")"; //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static String parseHexString(String val) {
        String ret = null;
        byte[] rby = parseHexBytes(val);
        if (rby != null) {
            try {
                ret = new String(rby, encoding());
            } catch (UnsupportedEncodingException e) {
                /* do nothing. */
            }
        }
        return ret;
    }

    public static byte[] parseHexBytes(String val) {
        byte[] ret = null;
        if (val != null && val.length() % 2 == 0) {
            int len = val.length() / 2;
            ret = new byte[len];
            for (int i = 0; i < len; ++i) {
                char d1 = val.charAt(i * 2);
                char d2 = val.charAt(i * 2 + 1);
                int h1 = Character.digit(d1, 16);
                int h2 = Character.digit(d2, 16);
                int by = 0;
                if (h1 >= 0 && h2 >= 0) {
                    by = 16 * h1 + h2;
                } else {
                    ret = null;
                    break;
                }
                ret[i] = (byte) by;
            }
        }
        return ret;
    }

    static String encoding() {
        return "UTF-8"; //$NON-NLS-1$
    }

    /**
     * This method returns true if the workset on the local disk is pointing to a foreign Stream
     *
     * @param resource
     *            - Any local resource
     * @return
     * @throws CoreException
     */
    public static boolean isLocalWorksetPointingToForeignStream(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        if (debugResources) {
            System.out.println("TU ilwptfs " + resource.toString()); //$NON-NLS-1$
        }

        IDMRemoteResource remoteResource = DMTeamPlugin.getWorkspace().getRemoteResource(resource.getProject());
        if (remoteResource == null) {
            return false;
        }

        String remoteStreamName = remoteResource.getProject().getId();
        String streamName = null;
        streamName = isLocalWorksetAStream(resource);
        if (streamName == null) {
            return false;
        }
        return !streamName.equals(remoteStreamName);
    }

    /**
     * This method returns true if the workset on the local disk is pointing to a foreign Project
     *
     * @param resource
     *            - Any local resource
     * @return
     * @throws CoreException
     */
    public static boolean isLocalWorksetPointingToForeignProject(IResource resource) throws CoreException {
        resource = TeamUtils.getResource(resource);
        IDMRemoteResource remoteResource = DMTeamPlugin.getWorkspace().getRemoteResource(resource.getProject());
        if (remoteResource == null) {
            return false;
        }

        String remoteProjectName = remoteResource.getProject().getId();
        String projectName = null;
        projectName = isLocalWorksetAProject(resource);
        if (projectName == null) {
            return false;
        }
        return !projectName.equals(remoteProjectName);
    }

    /**
     * This method will return the Stream Name ,retrieved from .WorkArea.metadata-config , if the local workset is a Stream.
     * If it is not a Stream then it will return null
     *
     * @param resource
     * @return
     * @throws CoreException
     */
    public static String isLocalWorksetAStream(IResource resource) throws CoreException {
        DMProject dmProject;
        try {
            resource = TeamUtils.getResource(resource);
            dmProject = TeamUtils.getDmProject(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        if (dmProject == null) {
            return null;
        }

        String waLocation = dmProject.isFullWorkArea()
                ? dmProject.getWorkAreaPath().toOSString() : dmProject.getProject().getLocation().toOSString();

        LocalWorksetSpecHolder localWorksetSpec = getLocalWorksetSpecHolder(waLocation);
        if (localWorksetSpec.isStream()) {
            return localWorksetSpec.getProjectName();
        } else {
            return null;
        }
    }

    /**
     * This method will return the Project Name, retrieved from .WorkArea.metadata-config, if the local workset is a Project.
     * If it is not a Project then it will return null
     *
     * @param resource
     * @return
     * @throws CoreException
     */
    public static String isLocalWorksetAProject(IResource resource) throws CoreException {
        DMProject dmProject;
        try {
            resource = TeamUtils.getResource(resource);
            dmProject = TeamUtils.getDmProject(resource);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        if (dmProject == null) {
            return null;
        }

        String waLocation = dmProject.isFullWorkArea()
                ? dmProject.getWorkAreaPath().toOSString() : dmProject.getProject().getLocation().toOSString();

        LocalWorksetSpecHolder localWorksetSpec = getLocalWorksetSpecHolder(waLocation);
        if (!localWorksetSpec.isStream()) {
            return localWorksetSpec.getProjectName();
        } else {
            return null;
        }
    }

    public static String getLocalWorksetSpec(String workAreaLocation) throws CoreException {
        LocalWorksetSpecHolder localWorksetSpecHolder = getLocalWorksetSpecHolder(workAreaLocation);
        return localWorksetSpecHolder.getProjectName();
    }

    private static LocalWorksetSpecHolder getLocalWorksetSpecHolder(String workAreaLocation) throws CoreException {
        // Read .WorkArea.metadata-config file. If the "project" and "project-home" entries in the .WorkArea.metadata-config file
        // are non empty then it is a Stream
        if (debugResources) {
            System.out.println("TU ilwas " + workAreaLocation); //$NON-NLS-1$
        }
        MetadataProvider mdProvider = MetadataProviderFactory.providerFor(workAreaLocation, false);

        String streamName = null;
        String streamHome = null;
        try {
            WorkAreaMetadata metadata = mdProvider.getWorkAreaMetadata(workAreaLocation);
            if (metadata != null) {
                streamName = metadata.getProject();
                streamHome = metadata.getProjectHome();
            }
        } catch (MetadataException e) {
            Debug.println(e);
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }

        return new LocalWorksetSpecHolder(streamName, streamHome);
    }

    private static class LocalWorksetSpecHolder {
        private String projectName;
        private boolean isStream;

        public LocalWorksetSpecHolder(String projectName, String projectHome) {
            if (projectName != null && projectHome != null) {
                this.isStream = true;
            } else {
                this.isStream = false;
            }
            this.projectName = projectName;
        }

        public String getProjectName() {
            return projectName;
        }

        public boolean isStream() {
            return isStream;
        }

    }

    /**
     * An aborted offline merge by DM command line client (SVN like client) could leave files (names ending with ".cm.latest" and
     * ".cm.ancestor") in the workspace which should not be shown to the user.
     * If the "conflict-file" tag in the metadata of these files has any value other than -- merged-uid-xxxx , accepted-repository
     * ,
     * accepted-local -- then
     * these files should not be shown to the user.
     *
     * @param resource
     * @return
     */
    public static boolean ignoreResourceLeftByDMCommandLineClient(IResource resource) {
        try {
            if (resource.getType() == IResource.FILE
                    && (resource.getName().endsWith(".cm.latest") || resource.getName().endsWith(".cm.ancestor"))) { //$NON-NLS-1$ //$NON-NLS-2$
                BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
                String conflictResolutionStatus = metadata.get(TeamUtils.CONFLICT_FILE);
                if (conflictResolutionStatus != null) {
                    if (!(conflictResolutionStatus.equals("accepted-repository") //$NON-NLS-1$
                            || conflictResolutionStatus.equals("accepted-local") //$NON-NLS-1$
                            || conflictResolutionStatus.startsWith("merged-uid-"))) { //$NON-NLS-1$
                        return true;
                    }
                }
            }
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
        return false;
    }

    /**
     * This method checks whether there is at least one file inside the folder or its subfolders.
     * Metadata for those folders which has at least a file in it or its subfolders will be written
     * by the dmnet api. dmnet api will not write metadata for empty folders. So when we want to know
     * whether a folder has at least one file in it or its subfolders we call this method.
     *
     * @param folder
     *            - Folder for which the check is to be made.
     * @return - returns true if the folder or its subfolders has at least one file in it.
     * @throws CoreException
     */
    public static boolean hasFolderGotFileInItOrItsSubfolders(IResource folder) throws CoreException {
        final List<IResource> files = new ArrayList<IResource>();
        folder.accept(new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) throws CoreException {
                if (resource.getType() == IResource.FILE) {
                    files.add(resource);
                    return false;
                } else {
                    return true;
                }
            }
        }, IResource.DEPTH_INFINITE, true);
        return (files.size() > 0);
    }

    public static boolean isConsiderContentsForComparison() {
        String value = null;
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            value = instanceNode.get(COMPARE_CONSIDER_FILE_CONTENTS, NO);
        }
        if (value.equals(YES)) {
            return true;
        }
        return false;
    }

    public static boolean isExpandSubstitution() {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            return instanceNode.getBoolean(EXPAND_SUBSTITUTION, false);
        }
        return false;
    }

    public static boolean isDerivedResourcesIgnored() {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            return instanceNode.getBoolean(IGNORE_DERIVED_RESOURCES, true);
        }
        return true;
    }

    public static boolean areContentsEqual(IResource local, IResourceVariant remote) {
        try {
            if (local instanceof IFile && local.exists() && remote != null && remote instanceof DMRemoteFile
                    && ((DMRemoteFile) remote).exists()) {
                return contentsEqual(((IFile) local).getContents(), ((DMRemoteFile) remote).getContents(null));
            }
        } catch (TeamException e1) {
            DMTeamPlugin.getDefault().getLog().log(e1.getStatus());
        } catch (CoreException e1) {
            DMTeamPlugin.getDefault().getLog().log(e1.getStatus());
        }
        return false;
    }

    /**
     * Performs a content compare on the two given InputStreams.
     *
     * @param is1
     *            first input to contents compare
     * @param is2
     *            second input to contents compare
     * @return <code>true</code> if content is equal
     */
    private static boolean contentsEqual(InputStream is1, InputStream is2) {

        if (is1 == null && is2 == null) {
            return true;
        }

        try {
            if (is1 == null || is2 == null) {
                return false;
            }

            while (true) {
                int c1 = is1.read();
                int c2 = is2.read();
                if (c1 == -1 && c2 == -1) {
                    return true;
                }
                if (c1 != c2) {
                    break;
                }

            }
        } catch (IOException ex) {
            // NeedWork
        } finally {
            if (is1 != null) {
                try {
                    is1.close();
                } catch (IOException ex) {
                    // silently ignored
                }
            }
            if (is2 != null) {
                try {
                    is2.close();
                } catch (IOException ex) {
                    // silently ignored
                }
            }
        }
        return false;
    }

    public static void fetchReplaceContents(IResourceVariant remote, ExpandMode[] expandModeHolder, IProgressMonitor monitor)
            throws TeamException {
        Assert.isLegal(expandModeHolder != null && expandModeHolder.length > 0);
        if (remote instanceof DMRemoteFile) {
            monitor = Utils.monitorFor(monitor);
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            try {
                ItemRevision rev = ((DMRemoteFile) remote).getItemRevision();
                TeamUtils.setFilename(rev, ((DMRemoteFile) remote).getName());
                monitor.subTask(NLS.bind(Messages.DMRemoteFile_0, ((DMRemoteFile) remote).getItemSpec()));
                InputStream contents = TeamUtils.getContents(rev, ((DMRemoteFile) remote).getConnection(), expandModeHolder);
                ((DMRemoteFile) remote).replaceContents(contents, expandModeHolder[0]);
            } catch (DMException e) {
                throw TeamException.asTeamException(e);
            } finally {
                monitor.done();
            }
        }
    }

    public static IPath queryCompatibleWorkAreaRoot(IPath forPath, String projectSpec) {
        return queryCompatibleWorkAreaRoot(forPath, projectSpec, false);
    }

    public static IPath queryCompatibleWorkAreaRoot(IPath forPath, String projectSpec, boolean isBaseline) {
        return queryCompatibleWorkAreaRoot(forPath, projectSpec, isBaseline, null);
    }

    // basic holder class
    public static class WaRootInfo {
        public IPath path;
        public String project;
    }

    // Returns the metadata root for a given path, checking to ensure it is owned by the specified
    // project/baseline, or:
    // - null if multiple (List out contains 2 entries of wa roots) or incompatible WA (List out contains 1 wa root entry);
    // - empty Path if no root metadata config exists up the hierarchy.
    public static IPath queryCompatibleWorkAreaRoot(IPath forPath, String projectSpec, boolean isBaseline,
            List<WaRootInfo> out) {
        // Walk the path hierarchy and when we find a workarea config file, inspect for matching
        // project. If no match, step one folder back up and try again.
        Assert.isNotNull(forPath);
        MetadataProvider mdp = MetadataProviderFactory.providerFor(forPath);

        IPath currentPath = forPath;
        IPath retPath = null;
        boolean first = true;

        try {
            do {
                WaRootInfo outData = null;
                if (out != null) {
                    outData = new WaRootInfo();
                }
                // step back one
                if (!first) {
                    // step back one
                    currentPath = currentPath.removeLastSegments(1);
                } else {
                    first = false;
                }

                // md folder with .WorkArea.metadata-config is under currentPath
                if (mdp.metadataExists(MetadataTypes.MT_WORKAREACONFIG, currentPath.toOSString())) {
                    WorkAreaMetadata wam = null;
                    try {
                        wam = mdp.getWorkAreaMetadata(currentPath.toOSString());
                    } catch (MetadataException e) {
                        return null; // don't want to end up with WA path we don't validate with current workset
                        // break;
                    }

                    if (wam != null) {

                        String owningProject = null;
                        if (!isBaseline) {
                            owningProject = wam.getProject();
                        } else {
                            owningProject = wam.getBaseline();
                        }

                        if (retPath != null) {
                            // multiple upper WAs
                            if (out != null) {
                                outData.path = currentPath;
                                outData.project = owningProject;
                                out.add(outData);
                            }
                            return null;
                        }
                        if (out != null) {
                            outData.path = currentPath;
                            outData.project = owningProject;
                            out.add(outData);
                        }
                        if (projectSpec != null && projectSpec.equalsIgnoreCase(owningProject)) {
                            retPath = currentPath;
                        } else {
                            // non-compatible WA
                            return null;
                        }
                    }
                }
            } while (!pathIsRoot(currentPath));
        } finally {
            if (mdp != null) {
                mdp.close();
            }
        }

        return retPath != null ? retPath : Path.EMPTY; // if no WA found return empty Path
    }

    // determine if at root - IPath.isRoot() returns false if path recognized as UNC even if
    // segment count is 0
    public static boolean pathIsRoot(IPath path) {
        // for c:\\ c:\ /
        return path.segmentCount() == 0 && path.isAbsolute();
    }

    /**
     * Returns the first nested work area found,
     * null otherwise
     */
    public static IPath queryNestedWorkAreaRoot(IPath forPath) {
        Assert.isNotNull(forPath);

        File pathFile = forPath.toFile();
        if (!pathFile.exists()) {
            return null;
        }
        MetadataProvider mdp = MetadataProviderFactory.providerFor(forPath);
        try {
            File resFile = TeamUtils.innerQueryNestedWorkAreaRoot(pathFile, mdp);
            return resFile != null ? Path.fromOSString(resFile.getAbsolutePath()) : null;
        } finally {
            if (mdp != null) {
                mdp.close();
            }
        }
    }

    private static File innerQueryNestedWorkAreaRoot(File file, MetadataProvider mdp) {
        if (mdp.metadataExists(MetadataTypes.MT_WORKAREACONFIG, file.getAbsolutePath())) {
            return file;
        }
        File[] fileArray = file.listFiles();
        if (fileArray != null && fileArray.length > 0) {
            for (File f : fileArray) {
                File result = TeamUtils.innerQueryNestedWorkAreaRoot(f, mdp);
                if (result != null) {
                    return result;
                }
            }
        }
        return null;
    }

    /**
     * Checks project work area location, returns:
     * work area path - project is under compatible work area outside the workspace;
     * null - project is outside the workspace under incompatible or multiple work areas/contains nested work areas down the
     * hierarchy;
     * empty path - project is not under any work area outside the workspace.
     */
    public static IPath validateProjectWorkArea(IProject project, String projectSpec) {
        Assert.isNotNull(project != null);
        IPath resPath = null;

        resPath = TeamUtils.queryCompatibleWorkAreaRoot(project.getLocation(), projectSpec);
        if (resPath != null && resPath.isEmpty()) { // check the hierarchy down if there were no WA above
            if (queryNestedWorkAreaRoot(project.getLocation()) != null) {
                return null;
            }
        }
        return resPath;
    }

    // for debug / trace
    public static String myThread() {
        return Thread.currentThread().toString() + " "; //$NON-NLS-1$

    }

    public static String resourceProperties(IResource res) {
        IDMWorkspace idmWorkspace = DMTeamPlugin.getWorkspace();
        StringBuffer sb = new StringBuffer();
        if (res.isPhantom()) {
            sb.append("PHANTOM "); //$NON-NLS-1$
        }
        if (idmWorkspace.isDerived(res)) {
            sb.append("DERIVED "); //$NON-NLS-1$
        }
        if (res.exists()) {
            sb.append("EXISTS "); //$NON-NLS-1$
        }
        if (res.isTeamPrivateMember()) {
            sb.append("TEAM_PRIV "); //$NON-NLS-1$
        }
        if (res.isLinked()) {
            sb.append("LINKED "); //$NON-NLS-1$
        }
        return sb.toString();
    }

    public static void setReadOnly(IResource res, boolean value) {
        // call the IResource version
        ResourceAttributes resourceAttributes = new ResourceAttributes();
        resourceAttributes.setReadOnly(value);
        try {
            res.setResourceAttributes(resourceAttributes);
            // clobber immutable if setting readonly
            if (value) {
                makeMutable(res);
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
    }

    static void makeMutable(IResource res) {
        if (isMac && res.getType() == IResource.FILE) {
            IFileStore fs = EFS.getLocalFileSystem().getStore(res.getLocation());
            IFileInfo fi = fs.fetchInfo();
            fi.setAttribute(EFS.ATTRIBUTE_IMMUTABLE, false);
            try {
                fs.putInfo(fi, EFS.SET_ATTRIBUTES, null);
            } catch (CoreException e) {
            }
        }
    }

    // returns true if any component of path from wapath to pathToProject
    // is not writable. Returns on first non writable and sets holder to that path.
    // if pathtoProject == null just check work area

    // returns true if can write a temp file
    private static boolean winWriteCheck(IPath p) {
        boolean retval = true;
        File tmp1 = null;
        try {
            tmp1 = File.createTempFile(TEMP_FILE_PREFIX, "canwrite", p.toFile()); // NON-NLS-1$ //$NON-NLS-1$
        } catch (IOException e) {
            retval = false;
        } finally {
            if (tmp1 != null) {
                tmp1.delete();
            }
        }
        return retval;
    }

    public static boolean projectPathNotWritable(IPath pathToProject, IPath waPath, String[] holder) {
        boolean retval = false; // default to false
        if (pathToProject == null) {
            if (isWin) {
                if (waPath != null && waPath.toFile().exists() && !winWriteCheck(waPath)) {
                    retval = true;
                }
            } else {
                if (waPath != null && waPath.toFile().exists() && !waPath.toFile().canWrite()) {
                    retval = true;
                }
            }
            if (retval && holder != null) {
                holder[0] = waPath.toOSString();
            }
        } else {
            if (waPath != null && waPath.isPrefixOf(pathToProject) && waPath.toFile().exists()) {
                // only check if part of project path and exists
                int matching = pathToProject.matchingFirstSegments(waPath);
                int toRemoveSeg = pathToProject.segmentCount() - matching;
                // don't bother checking project folder
                IPath testPath = null;
                while (toRemoveSeg > 0) {
                    testPath = pathToProject.removeLastSegments(toRemoveSeg);
                    if (isWin) {
                        if (!winWriteCheck(testPath)) {
                            retval = true;
                            break;
                        }
                    } else {
                        if (!testPath.toFile().canWrite()) {
                            retval = true;
                            break;
                        }
                    }
                    toRemoveSeg--;
                }
                if (retval && testPath != null && holder != null) {
                    holder[0] = testPath.toOSString();
                }
            }
        }
        return retval;
    }

    /**
     * @return resource relative to project from xml object attributes
     */
    public static IResource constructRelativeResource(ObjectAttributes attr, IDMProject project) {
        return TeamUtils.constructRelativeResource(attr.getRelPath(), attr.isFileAttributes(), project);
    }

    public static IResource constructRelativeResource(Resolution resolution, XMLMergeDescriptor descriptor)
            throws CoreException {
        IDMProject project = descriptor.getTarget();
        String relPath = "";
        if (!StringPath.isNullorEmpty(resolution.getRelPath())) {
            relPath = resolution.getRelPath();
        } else if (resolution.getTgt() != null && !StringPath.isNullorEmpty(resolution.getTgt().getRelPath())) {
            relPath = resolution.getTgt().getRelPath();
        } else {
            throw new CoreException(new Status(IStatus.ERROR, DMTeamPlugin.ID, Messages.DMXMLMergeInfo_invalidPath));
        }
        return TeamUtils.constructRelativeResource(relPath, resolution.isFileResolution(), project);
    }

    /**
     * @return resource relative to project
     */
    public static IResource constructRelativeResource(String strPath, boolean isFile, IDMProject project) {
        Assert.isNotNull(strPath);
        Assert.isLegal(!strPath.isEmpty());

        IPath fullPath = new Path(strPath);
        IPath relPath = null;

        // @formatter:off
        if (!isFile && ((project.isSccStyle() && project.getRemoteOffset().equals(fullPath))
                        || (!project.isSccStyle() && fullPath.segmentCount() == 1))) {
            // check if a project path and return project
            // if offset equals path for contained or path is a root for uncontained
            return project.getProject();
        }
        // @formatter:on

        // create relpath
        relPath = fullPath;
        if (project.isSccStyle()) {
            if (project.getRemoteOffset().isPrefixOf(fullPath)) {
                relPath = fullPath.removeFirstSegments(project.getRemoteOffset().segmentCount());
            }
        }

        IResource result = null;
        if (isFile) {
            result = project.getProject().getFile(relPath);
        } else {
            result = project.getProject().getFolder(relPath);
        }

        return result;
    }

    public static IFileStore copyResourceToTemp(XMLSyncInfo xnode) throws IOException, CoreException {
        File dst = File.createTempFile("mergedfile", null);//$NON-NLS-1$
        IResource local = xnode.getLocalResource();
        File src = new File(local.getLocationURI());

        if (!src.exists() || !dst.exists()) {
            return null;
        }

        FileInputStream is = null;
        FileOutputStream os = null;

        FileChannel source = null;
        FileChannel destination = null;
        IFileStore store = null;
        try {
            is = new FileInputStream(src);
            source = is.getChannel();
            os = new FileOutputStream(dst);
            destination = os.getChannel();
            destination.transferFrom(source, 0, source.size());
            store = EFS.getStore(dst.toURI());
        } finally {
            IOException ex = null;
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                ex = e;
            }

            try {
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
                ex = e;
            }

            if (ex != null) {
                throw ex;
            }
        }

        return store;
    }

    public static boolean copyResourceToTarget(IFileStore target, IResource resource) throws IOException, CoreException {
        boolean result = false;
        File src = new File(resource.getLocationURI());
        File dst = new File(target.toURI());

        if (!src.exists() || !dst.exists()) {
            return false;
        }

        FileInputStream is = null;
        FileOutputStream os = null;

        FileChannel source = null;
        FileChannel destination = null;
        try {
            is = new FileInputStream(src);
            source = is.getChannel();
            os = new FileOutputStream(dst);
            destination = os.getChannel();
            destination.transferFrom(source, 0, source.size());
            result = true;
        } finally {
            IOException ex = null;
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                ex = e;
            }

            try {
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
                ex = e;
            }

            if (ex != null) {
                throw ex;
            }
        }

        return result;
    }

    public static boolean isAnyResourceFromStream(IResource[] selectedResources) {
        try {
            IDMWorkspace dmWorkspace = DMTeamPlugin.getWorkspace();
            for (int i = 0; i < selectedResources.length; i++) {
                if (dmWorkspace.getProject(selectedResources[i].getProject()).getIsStream()) {
                    return true;
                }
            }
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
        return false;
    }
    
    public static Map<Project, Set<Request>> getRelatedProjectsForRequests(final List<? extends DimensionsArObject> requests,
            DimensionsConnectionDetailsEx conn, IProgressMonitor monitor) throws DMException {
        //@formatter:off
        final int[] PROJECT_ATTRS = new int[] {
                SystemAttributes.OBJECT_SPEC,
                SystemAttributes.DESCRIPTION,
                SystemAttributes.CREATION_DATE,
                SystemAttributes.WSET_IS_STREAM
        };
        //@formatter:on

        final Session session = conn.openSession(null);
        final List<Map<Project, Set<Request>>> resultHolder = new ArrayList<Map<Project, Set<Request>>>();
        resultHolder.add(new HashMap<Project, Set<Request>>());

        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                Map<Request, Set<Project>> queryResult = session.getObjectFactory()
                        .getRequestProjectRelationsFromDimensionsArObjects(new HashSet<DimensionsArObject>(requests));

                Map<Project, Set<Request>> result = resultHolder.get(0);

                for (Entry<Request, Set<Project>> queryEntry : queryResult.entrySet()) {
                    for (Project relatedProject : queryEntry.getValue()) {
                        if (!result.containsKey(relatedProject)) {
                            result.put(relatedProject, new HashSet<Request>());
                        }
                        result.get(relatedProject).add(queryEntry.getKey());
                    }
                }

                Utils.queryAttributes(new ArrayList<Project>(resultHolder.get(0).keySet()), PROJECT_ATTRS,
                        session.getObjectFactory(), true);
            }
        }, monitor);
        return resultHolder.get(0);
    }

    public static Project getSingleStreamRelatedToRequests(final List<Request> requests,
            final DimensionsConnectionDetailsEx connection) throws InvocationTargetException, InterruptedException {
        final Project[] result = new Project[1];
        BusyIndicator.showWhile(Display.getDefault(), new Runnable() {

            @Override
            public void run() {
                try {
                    Map<Project, Set<Request>> projects = getRelatedProjectsForRequests(requests, 
                            connection, new NullProgressMonitor());
                    if (projects == null) {
                        return;
                    }
                    for (Iterator<Project> iterator = projects.keySet().iterator(); iterator.hasNext();) {
                        Project project = iterator.next();
                        if (!(Boolean) project.getAttribute(SystemAttributes.WSET_IS_STREAM)) {
                            iterator.remove();
                        }
                    }

                    // one is related so can use it later
                    if (projects.size() == 1) {
                        result[0] = projects.keySet().iterator().next();
                    }
                } catch (DMException e) {
                    DMTeamPlugin.log(e.getStatus());
                }
            }
        });
        return result[0];
    }

    public static ItemRevision getItemRevisionBySpec(final Project project, final DimensionsConnectionDetailsEx connection,
            final String targetSpec) throws DMException {
        final ItemRevision[] itemRevisionHolder = new ItemRevision[1];
        final Session session = connection.openSession(null);
        session.run(new SessionRunnableWithProgress(null) {
            @Override
            public void run() throws Exception {
                progress.beginTask(null, 100);
                try {
                    itemRevisionHolder[0] = project.createItemRevisionFromSpec(targetSpec);
                } finally {
                    progress.done();
                }
            }
        }, null);

        return itemRevisionHolder[0];
    }

    public static boolean hasReplaceWithRepositoryMetadata(final IResource resource) throws CoreException {
        boolean retval = false;
        BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
        if (metadata instanceof ItemMetadata) {
            retval = ((ItemMetadata) metadata).hasReplaceRepositoryItem();
        }
        return retval;
    }

    public static boolean isReadOnly(IResource resource) {
        ResourceAttributes resourceAttributes = resource.getResourceAttributes();
        if (resourceAttributes == null) {
            return false;
        }
        return resourceAttributes.isReadOnly();
    }

    public static IPath getFolderPath(RepositoryFolder repositoryFolder) {
        String spec = (String) repositoryFolder.getAttribute(SystemAttributes.OBJECT_SPEC);
        if (Utils.isNullEmpty(spec)) {
            return Path.EMPTY;
        }
        if (spec.charAt(spec.length() - 1) == '/') {
            spec = spec.substring(0, spec.length() - 1); // remove trailing sep
        }
        return new Path(spec);
    }

    public static IDMProject findProjectInWorkspace(IProject project) throws CoreException {
        if (project == null) {
            return null;
        }
        IDMProject[] projects = DMTeamPlugin.getWorkspace().getProjects();
        for (int i = 0; i < projects.length; i++) {
            IDMProject dmProject = projects[i];
            if (dmProject != null) {
                if (project.equals(dmProject.getProject())) {
                    return dmProject;
                }
            }
        }
        return null;
    }

    public static IDMProject findProjectInWorkspace(String name) throws CoreException {
        if (StringPath.isNullorEmpty(name)) {
            return null;
        }
        IDMProject[] projects = DMTeamPlugin.getWorkspace().getProjects();
        for (int i = 0; i < projects.length; i++) {
            IDMProject dmProject = projects[i];
            if (dmProject != null) {
                IProject project = dmProject.getProject();
                if (project != null) {
                    if (name.equals(project.getName())) {
                        return dmProject;
                    }
                }
            }
        }
        return null;
    }

    public static Set<IResource> getAllNestedChanges(Set<IResource> originalChanges) throws CoreException {
        return getAllNestedChanges(originalChanges.toArray(new IResource[originalChanges.size()]));
    }

    public static Set<IResource> getAllNestedChanges(IResource[] originalChanges) throws CoreException {
        Set<IResource> allChanges = new HashSet<IResource>();
        for (IResource change : originalChanges) {
            allChanges.add(change);
            IProject project = change.getProject();
            IDMProject idmProject = findProjectInWorkspace(project);
            if (idmProject instanceof RootIdmProject) {
                List<VirtualIdmProject> childProjects = ((RootIdmProject) idmProject).getVirtualChildProjects();
                for (VirtualIdmProject virtualIdmProject : childProjects) {
                    IResource virtualChange = virtualIdmProject.makeRelativeResourceFromOriginal(change);
                    allChanges.add(virtualChange);
                }
            }
        }
        return allChanges;

    }

    public static IResource[] getAllNestedChangesArr(IResource[] originalChanges) throws CoreException {
        Set<IResource> allChanges = getAllNestedChanges(originalChanges);
        return new ArrayList<IResource>(allChanges).toArray(new IResource[allChanges.size()]);
    }

    /**
     * Deletes resource keeping its history
     */
    public static void deleteResource(IResource resourceToDelete, IProgressMonitor monitor) throws CoreException {
        // Get all similar changes if this resource has linked resources in the m2e projects
        Set<IResource> allDeletions = getAllNestedChanges(new IResource[] { resourceToDelete });
        SortedSet<IResource> deletions = new TreeSet<IResource>(new Comparator<IResource>() {

            @Override
            public int compare(IResource o1, IResource o2) {
                if (o1.getFullPath().segmentCount() > o2.getFullPath().segmentCount()) {
                    return 1;
                } else if (o1.getFullPath().segmentCount() < o2.getFullPath().segmentCount()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });

        deletions.addAll(allDeletions);

        // deepest file is first in the collection
        IResource del = deletions.iterator().next();

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 10);
        try {
            DMTeamPlugin.getWorkspace().unmanage(del, Utils.subMonitorFor(monitor, 5));

            boolean skipException = false;
            if (del.getParent().getType() == IResource.PROJECT && del.getName().equals(".project")) {//$NON-NLS-1$
                // if file is a project descriptor stop propagation of exceptions
                skipException = true;
            }

            try {
                resourceToDelete.delete(IResource.KEEP_HISTORY, Utils.subMonitorFor(monitor, 5));
            } catch (CoreException e) {
                if (!skipException) {
                    throw e;
                }
            }
        } finally {
            monitor.done();
        }
    }

    /**
     * Removes mapping for all virtual child projects
     */
    public static void unmanageVirtualChildren(IProject project, IProgressMonitor monitor) throws CoreException {
        IDMProject[] projects = DMTeamPlugin.getWorkspace().getProjects();
        for (int i = 0; i < projects.length; i++) {
            IDMProject dmProject = projects[i];
            if (dmProject instanceof VirtualIdmProject) {
                VirtualIdmProject virtual = (VirtualIdmProject) dmProject;
                RootIdmProject rootProject = virtual.getRootProject();
                IProject parentProject = rootProject.getProject();
                if (parentProject.equals(project)) {
                    DMTeamPlugin.getWorkspace().unmanageVirtual(dmProject.getProject(), monitor);
                }
            }
        }
    }
    
    public static String calculateCommonOffset(List<IDMProject> projects) {
		IPath commonOffset = null;
		int matchingFirstSegments = 0;
		for (IDMProject project : projects) {
			IPath projectRemoteOffset = project.getRemoteOffset();
			if (commonOffset == null) {
				commonOffset = projectRemoteOffset;
			}
			matchingFirstSegments = commonOffset.matchingFirstSegments(projectRemoteOffset);
			commonOffset = commonOffset.removeLastSegments(commonOffset.segmentCount() - matchingFirstSegments);
		}
		return commonOffset.toOSString();
	}

}
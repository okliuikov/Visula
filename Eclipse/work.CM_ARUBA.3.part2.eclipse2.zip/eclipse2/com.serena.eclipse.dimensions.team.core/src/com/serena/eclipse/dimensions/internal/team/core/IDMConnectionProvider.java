package com.serena.eclipse.dimensions.internal.team.core;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

public interface IDMConnectionProvider {

    /**
     * Force ui plugin to start
     *
     * @return false is a failure
     */
    boolean poke();

    DimensionsConnectionDetailsEx getConnection(DimensionsConnectionDetailsEx[] inputs);
}

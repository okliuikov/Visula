package com.serena.eclipse.dimensions.internal.team.core;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.serena.dmclient.api.Project;
import com.serena.dmfile.sync.WorkareaType;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Data for multiple projects deliver operation
 */
public class TransferToStreamMultipleCommandData {

    private Map<IDMProject, TransferToStreamOperationData> dataMap = new LinkedHashMap<IDMProject, TransferToStreamOperationData>();
    private WorkareaType type;
    private int requestsSize = 0;
    private IDMProject anyProject;
    private Boolean isShelving;

    public void addData(DMRepositoryProvider provider, List<WorkspaceResourceRequest> requests, Set<IResource> excluded,
            TransferShape shape) throws CoreException {
        IDMProject dmProject = provider.getIdmProject();
        Assert.isLegal(dmProject.getDimensionsObject() instanceof Project);

        if (anyProject == null) {
            this.anyProject = dmProject;
        } else {
            if (!anyProject.getDimensionsObject().getName().equals(dmProject.getDimensionsObject().getName())) {
                throw new IllegalArgumentException(Messages.DeliverMultipleCommandData_0deliveryToMultipleProjectsError);
            }
        }

        boolean isRelative = dmProject.isContainedEclipseProject() && !dmProject.isFullWorkArea();
        if (type != null) {
            if (type == WorkareaType.RELATIVE && !isRelative) {
                throw new IllegalArgumentException(Messages.DeliverMultipleCommandData_0differentWorkareaTypesError);
            }
        } else {
            if (isRelative) {
                this.type = WorkareaType.RELATIVE;
            } else {
                this.type = WorkareaType.COMMON;
            }
        }

        if (!dataMap.containsKey(dmProject)) {
            dataMap.put(dmProject, new TransferToStreamOperationData(provider, requests, excluded, shape));
        } else {
            TransferToStreamOperationData commandData = dataMap.get(dmProject);
            commandData.getRequests().addAll(requests);
            commandData.getExcludedResources().addAll(excluded);
        }

        requestsSize += requests.size();
    }

    /**
     * @return deliver operations mapping
     */
    public Map<IDMProject, TransferToStreamOperationData> getDeliverOpeartions() {
        return dataMap;
    }

    /**
     * @return workarea type for deliver
     */
    public WorkareaType getWorkareaType() {
        return type;
    }

    /**
     * @return the requestsSize
     */
    public int getRequestsSize() {
        return requestsSize;
    }

    /**
     * @return requests mapping
     */
    public Map<IDMProject, WorkspaceResourceRequest[]> getRequests() {
        Map<IDMProject, WorkspaceResourceRequest[]> result = new LinkedHashMap<IDMProject, WorkspaceResourceRequest[]>();
        for (Map.Entry<IDMProject, TransferToStreamOperationData> ell : dataMap.entrySet()) {
            result.put(ell.getKey(), ell.getValue().getRequestsArray());
        }
        return result;
    }

    /**
     * @return the apiProject
     */
    public IDMProject getAnyProject() {
        return anyProject;
    }

    /**
     * @return the isShelving
     */
    public boolean isShelving() {
        if (isShelving == null) {
            throw new IllegalArgumentException(Messages.DeliverMultipleCommandData_0differentCommandUndefinedError);
        }
        return isShelving;
    }

    /**
     * @param isShelving the isShelving to set
     */
    public void setShelving(boolean isShelving) {
        if (this.isShelving != null && !this.isShelving.equals(isShelving)) {
            throw new IllegalArgumentException(Messages.DeliverMultipleCommandData_0differentCommandsError);
        }
        this.isShelving = isShelving;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.util.Collection;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;

import com.serena.dmclient.api.ItemRevision;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;

/**
 * Dimensions workspace. Defines source-control centric view on Eclipse workspace
 *
 * @author V.Grishchenko
 * @see com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin#getWorkspace()
 */
public interface IDMWorkspace {

    /**
     * Adds a resource state change listener to this workspace.
     *
     * @param listener
     */
    void addResourceStateChangeListener(IResourceStateChangeListener listener);

    /**
     * Removes a resource state change listener from this workspace.
     *
     * @param listener
     */
    void removeResourceStateChangeListener(IResourceStateChangeListener listener);

    /**
     * @return workspace subscriber
     */
    DMSyncTreeSubscriber getSubscriber();

    /**
     * @return a "preview" subscriber for the local workspace rooted at the
     *         specified project
     */

    /**
     * Associates given project to a dimensions repository provider. If
     * project is already shared the sharing is changed according to the
     * supplied parameters.
     *
     * Workarea will be refreshed and both base and remote tree will be populated.
     *
     * @param project local workbench project
     * @param root managed root within the given project, can be <code>null</code>
     * @param remoteObject workset or baseline adapter
     * @return repository provider corresponding to the new sharing
     * @throws CoreException
     */
    DMRepositoryProvider manage(IProject project, IContainer root, APIObjectAdapter remoteObject) throws CoreException;

    /**
     * Associates given project to a dimensions repository provider. If
     * project is already shared the sharing is changed according to the
     * supplied parameters.
     *
     * Workarea will be refreshed and both base and remote tree will be populated.
     *
     * @param project local workbench project
     * @param root managed root within the given project, can be <code>null</code>
     * @param remoteObject workset or baseline adapter
     * @param workAreaPath the path where project is stored
     * @return repository provider corresponding to the new sharing
     * @throws CoreException
     */
    DMRepositoryProvider manage(IProject project, IContainer root, APIObjectAdapter remoteObject, IPath workAreaPath)
            throws CoreException;

    /**
     * Associates given project to a dimensions repository provider. If
     * project is already shared the sharing is changed according to the
     * supplied parameters.
     *
     * @param project local workbench project
     * @param root managed root within the given project, can be <code>null</code>
     * @param remoteObject workset or baseline adapter
     * @param workAreaPath the path where project is stored
     * @param doRefresh if true refreshes base and local trees, populates sync statuses.
     *            Be careful and do not force refresh against empty workarea as this could
     *            degrade performance.
     *
     * @return repository provider corresponding to the new sharing
     * @throws CoreException
     */
    DMRepositoryProvider manage(IProject project, IContainer root, APIObjectAdapter remoteObject, IPath workAreaPath,
            boolean doRefresh) throws CoreException;

    DMRepositoryProvider manageVirtual(IProject project, IProject toProject) throws CoreException;

    void unmanageVirtual(IProject project, IProgressMonitor monitor) throws CoreException;

    /**
     * Unmaps the project from DM provider and optionally purges the metadata.
     *
     * @param project
     * @throws CoreException
     */
    void unmanage(IProject project, boolean deleteMeta, IProgressMonitor monitor) throws CoreException;

    /**
     * Purges metadata for the specified resource.
     *
     * @param resource
     * @param monitor
     * @throws CoreException
     */
    void unmanage(IResource resource, IProgressMonitor monitor) throws CoreException;

    /**
     * @return projects shared with dimensions repository provider, guaranteed
     *         not to return <code>null</code>
     */
    IDMProject[] getProjects() throws CoreException;

    /**
     * @return Dimensions project instance for the supplied resource, returns <code>null</code> if resource's project is not
     *         shared
     *         via dimensions
     *         provider
     */
    IDMProject getProject(IResource resource) throws CoreException;

    /**
     * @return dimensions resource for the supplied resource, returns <code>null</code> if the resources's project is not shared
     *         via
     *         dimensions
     *         or the resource is outside of the managed root folder for its project
     */
    IDMWorkspaceResource getWorkspaceResource(IResource resource) throws CoreException;

    /**
     * Metadata side resource for local resource.
     *
     * @param resource
     * @return
     * @throws TeamException
     */
    IDMRemoteResource getBaseResource(IResource resource) throws TeamException;

    /**
     * Repository side resource for local resource.
     *
     * @param resource
     * @return resource constructed from the locally cached information or <code>null</code> if none
     * @throws TeamException
     */
    IDMRemoteResource getRemoteResource(IResource resource) throws TeamException;

    /**
     * The following resources are ignored:
     * <ul>
     * <li>derived resources
     * <li>linked resources
     * <li>.metadata containers
     * <li>resources that match patterns in the global ignore registry as per <code>Team.isIgnoredHint()</code>
     * <li>child resources whose parents are ignored
     * <li>resources whose name match patterns stored in <code>.dmignore</code> maintained by their parents
     * </ul>
     *
     * Note that projects, workspace root, and managed resources are never ignored
     *
     * @param resource the resource to check
     *
     * @return <code>true</code> if supplied resource is ignored, returns <code>false</code> otherwise
     */
    boolean isIgnored(IResource resource) throws TeamException;

    /**
     * The following resources are ignored:
     * <ul>
     * <li>derived resources
     * <li>linked resources
     * <li>.metadata containers
     * <li>resources that match patterns in the global ignore registry as per <code>Team.isIgnoredHint()</code>
     * <li>child resources whose parents are ignored
     * <li>resources whose name match patterns stored in <code>.dmignore</code> maintained by their parents
     * </ul>
     *
     * Note that projects, workspace root, and managed resources are never ignored
     *
     * @param resource the resource to check
     * @param provider the existing metadata provider to check
     *
     * @return <code>true</code> if supplied resource is ignored, returns <code>false</code> otherwise
     */
    boolean isIgnored(IResource resource, MetadataProvider provider) throws TeamException;

    boolean isDerivedAndUnmanaged(File resourceFile);

    boolean isDerived(IResource resource);

    /**
     * Adds an ignore pattern to container. Any resource whose name matches
     * at least one of the ignore patterns maintained by its parent will be
     * considered as ignored.
     *
     * @param parent
     * @param pattern
     * @param isRecursive
     * @throws CoreException
     */
    void addIgnorePattern(IContainer parent, String pattern, boolean isRecursive) throws CoreException;

    boolean isManaged(IResource resource) throws TeamException;

    boolean hasRemote(IResource resource) throws TeamException;

    boolean updateRemote(IResource resource, IResourceVariant remote) throws TeamException;

    boolean updateBase(IResource resource, IResourceVariant remote) throws TeamException;

    /**
     * @return <code>true</code> if the supplied resource is modified, if
     *         resource is a container its deep modification status is used
     */
    boolean isModified(IResource resource) throws CoreException;

    /**
     * @return <code>true</code> if folder is not a project, not a linked
     *         resource but contains dm meta folder is itself unmanaged.
     */
    boolean isOrphanedSubtree(IContainer container) throws CoreException;

    /**
     * Puts managed files into optimistic or pessimistic mode.
     *
     * @param resources
     * @param pessimistic
     *            <code>true</code> for pessimistic, <code>false</code> for optimistic
     * @param monitor
     * @throws CoreException
     */
    void setMode(IResource[] resources, boolean pessimistic, IProgressMonitor monitor) throws CoreException;

    void makeIncoming(IResource resource) throws CoreException;

    /**
     * Constructs a file variant for the supplied local/remote pair. The returned
     * handle is initialized according to the current sharing of the local resource.
     * No checks are done by this method to verify if the specified revision is actually
     * owned by the remote project that the local file's project is currently
     * mapped to.
     *
     * @param local
     * @param remote
     * @return created variant or <code>null</code> if local file's project
     *         is not shared with Dimensions
     * @throws DMException
     */
    IDMRemoteFile getRemoteFile(IFile local, ItemRevision remote) throws CoreException;

    /**
     * @return <code>true</code> if the supplied resource has been locally moved,
     *         returns <code>false</code> otherwise
     */
    boolean isMoved(IResource resource) throws CoreException;

    /**
     * @return the move destination of the supplied resource or <code>null</code> if the resource has not been not moved or is a
     *         move destination
     */
    IResource getMovedTo(IResource resource) throws CoreException;

    /**
     * @return the move source of the supplied resource or <code>null</code> if the resource has not been moved or is a move
     *         source
     */
    IResource getMovedFrom(IResource resource) throws CoreException;

    /**
     * @return the move destination of the supplied resource or <code>null</code> if the resource has not been not moved or is a
     *         move destination
     */
    IResource getMovedInRepositoryTo(IResource resource) throws CoreException;

    /**
     * @return the move source of the supplied resource or <code>null</code> if the resource has not been moved or is a move
     *         source
     */
    IResource getMovedInRepositoryFrom(IResource resource) throws CoreException;

    /**
     * This method stores the metadata of the item being moved locally in the following use case:
     * Create StreamA with two folder(Folder1 and Folder2) and a file in each of these folders( file1 and file2 respectively ).
     * Create a StreamB from StreamA.
     * User1 adds StreamA to workspace. Modifies file1 locally and delivers it to StreamA.
     * User2 adds StreamB to workspace. Moves file1 locally and moves to Folder2 and delivers it toStreamB.
     * User1 switches to StreamB , does a sync and Updates the repository move. Switches back to StreamA and does a syn. Sync view
     * shows local move.
     * Do a deliver.
     * In this scenario ,during Update of repository move ,we need some part of the metadata of Folder1/File1 to use in the
     * metadata
     * of Folder2/File1 during Update of repository move and we store
     * the metadata here for future use.
     *
     * @param movedFromSyncInfoList
     * @param movedToSyncInfoList
     * @param monitor
     */
    void retainMetadataOfTheResourceBeingMoved(List<SyncInfo> movedFromSyncInfoList, List<SyncInfo> movedToSyncInfoList,
            IProgressMonitor monitor) throws CoreException;

    /**
     * For resources whose modtime is different from metadata checks checksums and
     * resets modtime to match metadata if checksums are the same.
     *
     * @param resources
     * @param depth
     * @param monitor
     * @return
     * @throws CoreException
     */
    List<IResource> cleanTimestamps(IResource[] resources, int depth, IProgressMonitor monitor) throws CoreException;

    void markStaleAndProcess(Collection<IContainer> folders, boolean doFiles) throws CoreException;

    boolean markStale(IContainer cont, boolean doFiles, List<IResource> processed);
    
    boolean handlePossibleWorkAreaRehome(Collection<IContainer> filesOrFolders);
}

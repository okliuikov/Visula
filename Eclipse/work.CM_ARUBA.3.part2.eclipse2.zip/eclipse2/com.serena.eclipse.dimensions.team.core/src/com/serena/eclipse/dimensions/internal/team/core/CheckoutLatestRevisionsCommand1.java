/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Performs a checkout.
 * @author V.Grishchenko
 */
// TODO VG on Jan 25, 2006: must be renamed as the name is misleading,
// specific revisions are checked out by this command, not latest!
class CheckoutLatestRevisionsCommand1 extends DMWorkspaceCommand1 {

    /**
     * @param dmProject
     * @param requests
     */
    public CheckoutLatestRevisionsCommand1(DMProject dmProject, CheckoutRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    protected void execute(IProgressMonitor progress) throws CoreException {
        progress = Utils.monitorFor(progress);
        progress.beginTask(null, requests.length);
        try {
            for (int i = 0; i < requests.length; i++) {
                CheckoutRequest checkoutRequest = (CheckoutRequest) requests[i];
                checkoutRequest.process(progress);
                progress.worked(1);
                Utils.checkCanceled(progress);
            }
        } finally {
            progress.done();
        }
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

}

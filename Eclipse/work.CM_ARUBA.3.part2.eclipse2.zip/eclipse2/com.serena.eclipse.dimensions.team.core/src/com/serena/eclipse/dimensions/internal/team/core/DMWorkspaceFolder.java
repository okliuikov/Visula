/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;

import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * @author V.Grishchenko
 */
class DMWorkspaceFolder extends DMWorkspaceResource implements IDMWorkspaceFolder { 
    private WorkspaceFolderStatus status;

    /**
     * @param resource
     *            the resource from workspace project
     * @param project
     *            the dimensions project which is mapped to the workspace project
     * @param virtualResource
     *            the original resource that is relative to the {@link VirtualIdmProject} or null
     */
    public DMWorkspaceFolder(IResource resource, IDMProject project, WorkspaceFolderStatus folderStatus,
            IResource virtualResource) {
        super(resource, project, virtualResource);
        this.status = folderStatus;
    }

    @Override
    public WorkspaceResourceStatus getStatus() {
        return status;
    }

    @Override
    public WorkspaceResourceStatus getStatus(MetadataProvider provider) {
        return status;
    }

    @Override
    public void delete(IProgressMonitor monitor) throws CoreException {
        IContainer localFolder = getLocalFolder();
        if (localFolder.exists()) {
            localFolder.delete(false /* force */, monitor);
            return;
        }
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1);
        monitor.worked(1);
        monitor.done();
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public void accept(IDMResourceVisitor visitor) throws CoreException {
        accept(visitor, null);
    }

    @Override
    public void accept(IDMResourceVisitor visitor, IDMWorkspaceResourceFilter filter) throws CoreException {
        Assert.isNotNull(visitor);
        if (visitor.visit(this)) {
            IDMWorkspaceResource[] members = getMembers(filter);
            for (int i = 0; i < members.length; i++) {
                if (members[i].isContainer()) {
                    ((IDMWorkspaceFolder) members[i]).accept(visitor, filter);
                } else {
                    members[i].accept(visitor);
                }
            }
        }
    }

    @Override
    public IDMResource[] getMembers() throws CoreException {
        return getMembers(null);
    }

    @Override
    public IDMWorkspaceResource[] getMembers(IDMWorkspaceResourceFilter filter) throws TeamException {
        List<IDMWorkspaceResource> result = new ArrayList<IDMWorkspaceResource>();
        try {
            IResource[] members = getLocalFolder().members(true);
            for (int i = 0; i < members.length; i++) {
                IDMWorkspaceResource dmMember = DMTeamPlugin.getWorkspace().getWorkspaceResource(members[i]);
                if (filter == null || filter.select(dmMember)) {
                    result.add(dmMember);
                }
            }
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
        return result.toArray(new IDMWorkspaceResource[result.size()]);
    }

    @Override
    public IContainer getLocalFolder() {
        return (IContainer) getLocalResource();
    }

    @Override
    public IDMRemoteFolder getRemoteFolder() throws TeamException {
        return (IDMRemoteFolder) getRemoteResource();
    }

    @Override
    public IDMRemoteFolder getBaseFolder() throws TeamException {
        return (IDMRemoteFolder) getBaseResource();
    }

    @Override
    public boolean hasAddedOrDeletedMembers() {
        return status.hasAddedOrDeletedMembers();
    }

    @Override
    public boolean containsPessimistic(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.PESSIMISTIC, deep);
    }

    @Override
    public boolean containsOptimistic(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.OPTIMISTIC, deep);
    }

    @Override
    public boolean containsRemotelyModified(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.REMOTE_MODIFIED, deep);
    }

    @Override
    public boolean containsModified(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.MODIFIED, deep);
    }

    @Override
    public boolean containsExtracted(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.EXTRACTED, deep);
    }

    @Override
    public boolean isRemoteExtracted(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.REMOTE_EXTRACTED, deep);
    }

    @Override
    public boolean containsNotExtracted(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.NOT_EXTRACTED, deep);
    }

    @Override
    public boolean containsManaged(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.MANAGED, deep);
    }

    @Override
    public boolean containsUnmanaged(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.UNMANAGED, deep);
    }

    @Override
    public boolean containsMoved(boolean deep) {
        return status.matchAll(WorkspaceResourceStatus.MOVED, deep);
    }

    @Override
    public boolean isDMFolder() {
        return WorkspaceMetadataManager.hasMetadata((IContainer) getLocalResource());
    }

    @Override
    public void makeUnmodified() {
    }

    @Override
    public boolean isModified() throws TeamException {
        if (status == null) {
            return false;
        }
        return status.matchAll(WorkspaceResourceStatus.MODIFIED, true) || status.hasAddedOrDeletedMembers();
    }

    @Override
    public boolean containsLocked(boolean deep) {
        if (status == null) {
            return false;
        }
        return status.matchAll(WorkspaceResourceStatus.LOCKED_FILE, deep)
                || status.matchAll(WorkspaceResourceStatus.LOCKED_FILE_OTHER, deep);
    }

}

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

import com.serena.dmfile.FileToTransfer;
import com.serena.dmfile.ObjectToTransfer;
import com.serena.dmfile.sync.Shape;
import com.serena.dmfile.xml.OutgoingMergePoint;
import com.serena.dmfile.xml.Workarea;
import com.serena.dmfile.xml.ide.OutgoingIdeProject;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Bucket represents one ide project for delivery operation
 */
public class IdeProjectDeliverBucket extends OutgoingIdeProject {
    private List<WorkspaceResourceRequest> contents = new ArrayList<WorkspaceResourceRequest>();
    private boolean sawCreate;
    private boolean sawUpdate;
    private boolean all;
    private TransferToStreamOperationData opData;
    private WorksetProject project;
    private List<IResource> scopes;
    private String comment;
    private Map<Integer, Object> amap = Collections.<Integer, Object>emptyMap();

    public IdeProjectDeliverBucket(List<WorkspaceResourceRequest> resourceRequests, TransferToStreamOperationData opData) {
        Assert.isLegal(opData.getProject() instanceof WorksetProject);
        TransferShape transferShape = opData.getTransferShape();
        Assert.isNotNull(transferShape);
        setShape(transferShape.getShape());
        this.scopes = transferShape.getScopes();
        this.opData = opData;
        this.project = (WorksetProject) opData.getProject();
        init(resourceRequests);
    }

    private void init(List<WorkspaceResourceRequest> resourceRequests) {
        setLabel(project.getProject().getName());
        setOffset(project.getRemoteOffset().isEmpty() ? "" : project.getRemoteOffset().toOSString());
        setWorkareaRoot(project.getUserDirectory().toOSString());
        setUploadRuleset(project.getUploadRuleId() + ':' + String.valueOf(project.getIdeProjectUid()));

        Workarea workarea = ObjectToTransfer.scanWorkAreaMetadata(project.getUserDirectory().toOSString());
        List<OutgoingMergePoint> mergePoints = ObjectToTransfer.scanMergePointsMetadata(project.getUserDirectory().toOSString());
        DeliverBucketHelper.addIgnoredContributors(mergePoints, opData);

        setWorkarea(workarea);
        setMergePoints(mergePoints);

        List<ObjectToTransfer> filesToUpload = new ArrayList<ObjectToTransfer>();
        for (WorkspaceResourceRequest req : resourceRequests) {
            internalAdd(req, filesToUpload);
        }
        setFilesToTransfer(filesToUpload);

    }

    /**
     * @return the all
     */
    public boolean isAll() {
        return all;
    }

    /**
     * @param all the all to set
     */
    public void setAll(boolean all) {
        this.all = all;
    }

    /**
     * @return requests for delivery
     */
    public List<WorkspaceResourceRequest> getContents() {
        return contents;
    }

    /**
     * @return the attribute map
     */
    public Map<Integer, Object> getAttributeMap() {
        return amap;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @return set the comment
     */
    @Override
    public void setComment(String comment) {
        super.setComment(comment);
        this.comment = comment;
    }

    private IResource findScopeForResource(IResource resource) {
        for (Iterator<IResource> iterator = scopes.iterator(); iterator.hasNext();) {
            IResource scope = iterator.next();
            IPath scopePath = scope.getProjectRelativePath();
            IPath resourcePath = resource.getProjectRelativePath();

            if (scopePath.isPrefixOf(resourcePath)) {
                iterator.remove();
                return scope;
            }
        }

        return null;
    }

    private static void addTypeToTransferObject(FileToTransfer transferObject, IResource resource) {
        if (resource.getType() == IResource.FILE) {
            transferObject.setResourceType("file");
        } else if (resource.getType() == IResource.FOLDER) {
            transferObject.setResourceType("folder");
        }
    }

    private void internalAdd(WorkspaceResourceRequest request, List<ObjectToTransfer> filesToUpload) {
        contents.add(request);
        initParameters(request);

        String resPath = request.getResource().getLocation().toOSString();
        if (request instanceof DeleteItemRevisionRequest) {
            // check if container folder was moved (renamed)
            // if so, path will be a new renamed folder for deleted item
            IResource parentRes = request.getResource().getParent();
            try {
                IResource movedToRes = DMTeamPlugin.getWorkspace().getMovedTo(parentRes);
                if (movedToRes != null) {
                    resPath = movedToRes.getLocation().append(request.getResource().getName()).toOSString();
                }
            } catch (CoreException e) {
                DMTeamPlugin.log(e.getStatus());
            }
        }

        boolean addStartPath = false;
        if (getShape() == Shape.MULTISELECT) {
            IResource scope = findScopeForResource(request.getResource());
            if (scope != null) {
                if (scope.equals(request.getResource())) {
                    addStartPath = true; // add start path to current change
                } else {
                    // add scope as a separate change
                    String scopePath = scope.getLocation().toOSString();
                    FileToTransfer fileToUpload = ObjectToTransfer.scanSingleFileEx(scopePath);
                    fileToUpload.setStartPath(true);
                    addTypeToTransferObject(fileToUpload, scope);
                    filesToUpload.add(fileToUpload);
                }
            }
        }

        FileToTransfer fileToUpload = ObjectToTransfer.scanSingleFileEx(resPath);
        fileToUpload.setStartPath(addStartPath);
        addTypeToTransferObject(fileToUpload, request.getResource());

        if (!fileToUpload.isFolder() && request instanceof UploadRequest) {
            UploadRequest uploadRequest = (UploadRequest) request;
            IUploadRequestParameters parameters = uploadRequest.getParameters();
            if (parameters != null) {
                fileToUpload.setFileEncoding(parameters.getCharset());
            }
        }

        // Needed as the metadata scans returns this as an addition if there is no file and no metadata
        if (request instanceof DeleteItemRevisionRequest || request instanceof DeleteFolderRequest) {
            fileToUpload.setDiffType(ObjectToTransfer.DELETION);
            fileToUpload.setDeletionType("from-project");
        }

        filesToUpload.add(fileToUpload);

        String foreignStream = DeliverBucketHelper.getStream(request.getResource());
        // Check for Global workset is added in the below if clause because when you do a "Mark as merged" the project in the
        // metadata file is set as $GLOBAL:$GENERAL and not the actual project of the item being marked as merged
        // So we need to exclude $GLOBAL:$GENERAL from the list of foreign streams

        // KB> DEF211040 fix - enable delivering baseline contents by using /ALL instead of /CONTRIB=()
        // KB> We use /ALL as a shortcut to deliver resources from all the streams except those deselected on
        // RunAndProcessStreamSelectDialog and all the baselines.
        if (!isAll() && foreignStream != null && !foreignStream.equals(project.getId())) {
            setAll(true);
        } else if (!isAll() && DeliverBucketHelper.isBaseline(request.getResource())) {
            setAll(true);
        }

    }

    private void initParameters(WorkspaceResourceRequest request) {
        if (request instanceof UploadRequest) {
            UploadRequest uploadRequest = (UploadRequest) request;
            IUploadRequestParameters parameters = uploadRequest.getParameters();
            setComment(Utils.getString(parameters.getComment()));

            if (!(sawCreate || sawUpdate) && (uploadRequest.isCreateItem() || uploadRequest.isUpdate())) {
                setDescription(parameters.getDescription());
                setRelatedRequests(parameters.getRelatedRequests());
            }

            if (!sawCreate && uploadRequest.isCreateItem()) {
                setPart(DeliverBucketHelper.getOwningPart(uploadRequest));
            }

            if (amap.isEmpty()) {
                int[] attrs = parameters.getAttributes();
                if (attrs != null && attrs.length == 0) {
                    this.amap = new HashMap<Integer, Object>(attrs.length);
                    for (int i = 0; i < attrs.length; i++) {
                        amap.put(new Integer(attrs[i]), parameters.getAttribute(attrs[i]));
                    }
                }
            }

            sawCreate |= uploadRequest.isCreateItem();
            sawUpdate |= uploadRequest.isUpdate();
        } else if (request instanceof FolderRequest || request instanceof ItemRevisionRequest) {
            if (request.isRequestSupported()) {
                setRelatedRequests(request.getChangeRequests());
            }
            if (request instanceof IMoveRequest) {
                setComment(Utils.getString(((IMoveRequest) request).getComment()));
            }
        }
    }

    public String assembleResult() {
        List<ObjectToTransfer> results = getTransferResults();
        StringBuffer buf = new StringBuffer();

        for (Iterator<ObjectToTransfer> rIter = results.iterator(); rIter.hasNext();) {
            ObjectToTransfer fileResult = rIter.next();
            List<String> commands = fileResult.getCommands();
            if (commands != null) {
                for (Iterator<String> cIter = commands.iterator(); cIter.hasNext();) {
                    String command = cIter.next();
                    if (!Utils.isNullEmpty(command)) {
                        buf.append(command);
                        if (command.charAt(command.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
            List<String> messages = fileResult.getMessages();
            if (messages != null) {
                for (Iterator<String> mIter = messages.iterator(); mIter.hasNext();) {
                    String message = mIter.next();
                    if (!Utils.isNullEmpty(message)) {
                        buf.append(message);
                        if (message.charAt(message.length() - 1) != '\n') {
                            buf.append('\n');
                        }
                    }
                }
            }
        }
        return buf.toString();
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer("[IdeProject Deliver Bucket]\n"); //$NON-NLS-1$
        buf.append(contents.size() + " files:\n"); //$NON-NLS-1$
        for (int i = 0; i < contents.size(); i++) {
            WorkspaceResourceRequest request = contents.get(i);
            IResource res = request.getResource();
            if (i > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(res.getLocation().toOSString());
        }

        setLabel(project.getProject().getName());
        setOffset(project.getRemoteOffset().isEmpty() ? "" : project.getRemoteOffset().toOSString());
        setWorkareaRoot(project.getUserDirectory().toOSString());
        setUploadRuleset(project.getUploadRuleId() + ':' + String.valueOf(project.getIdeProjectUid()));
        setShape(opData.getTransferShape().getShape());
        buf.append("\nLabel=").append(getLabel()).append('\n'); //$NON-NLS-1$
        buf.append("Offset=").append(getOffset()).append('\n'); //$NON-NLS-1$
        buf.append("WorkareaRoot=").append(getWorkareaRoot()).append('\n'); //$NON-NLS-1$
        buf.append("Shape=").append(getShape()).append('\n'); //$NON-NLS-1$
        buf.append("CommandParameters=").append(getCommandParameters().toString()).append('\n'); //$NON-NLS-1$

        buf.append("Attributes:\n"); //$NON-NLS-1$
        Map<?, ?> attrMap = getAttributeMap();
        int cnt = 0;
        for (Iterator<?> iter = attrMap.entrySet().iterator(); iter.hasNext();) {
            Map.Entry<?, ?> entry = (Entry<?, ?>) iter.next();
            if (cnt > 0) {
                buf.append('\n');
            }
            buf.append('\t').append(entry.getKey()).append('=').append(entry.getValue());
            cnt++;
        }
        buf.append("\n[/IdeProject Deliver Bucket]"); //$NON-NLS-1$
        return buf.toString();
    }
}

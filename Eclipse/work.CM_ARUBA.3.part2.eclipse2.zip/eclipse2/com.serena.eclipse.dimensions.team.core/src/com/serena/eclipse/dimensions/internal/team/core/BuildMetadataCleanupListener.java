/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.RepositoryProvider;

import com.serena.dmfile.metadb.MetadataProvider;

/**
 * @author V.Grishchenko
 */
public class BuildMetadataCleanupListener implements IResourceChangeListener, IResourceDeltaVisitor { 

    static IResource getResourceFor(IProject container, IResource destination, IPath originating) {
        switch (destination.getType()) {
        case IResource.FILE:
            return container.getFile(originating);
        case IResource.FOLDER:
            return container.getFolder(originating);
        case IResource.PROJECT:
            return ResourcesPlugin.getWorkspace().getRoot().getProject(originating.toString());
        }
        return destination;
    }

    public BuildMetadataCleanupListener() {
    }

    @Override
    public void resourceChanged(IResourceChangeEvent event) {
        try {
            IResourceDelta root = event.getDelta();
            IResourceDelta[] projectDeltas = root.getAffectedChildren();
            for (int i = 0; i < projectDeltas.length; i++) {
                final IResourceDelta delta = projectDeltas[i];
                IResource resource = delta.getResource();

                if (resource.getType() == IResource.PROJECT) {
                    // If the project is not accessible, don't process it
                    if (!resource.isAccessible()) {
                        continue;
                        // if ((delta.getFlags() & IResourceDelta.OPEN) != 0) continue;
                    }
                }

                RepositoryProvider provider = DMRepositoryProvider.getDMProvider(resource);// RepositoryProvider.getProvider(resource.getProject(),
                                                                                           // CVSProviderPlugin.getTypeId());

                // if a project is moved the originating project will not be associated with the DM provider
                // however listeners will probably still be interested in the move delta.
                if ((delta.getFlags() & IResourceDelta.MOVED_TO) > 0) {
                    IResource destination = getResourceFor(resource.getProject(), resource, delta.getMovedToPath());
                    provider = RepositoryProvider.getProvider(destination.getProject());
                }

                if (provider != null) {
                    ResourcesPlugin.getWorkspace().run(new IWorkspaceRunnable() {
                        @Override
                        public void run(IProgressMonitor monitor) throws CoreException {
                            try {
                                delta.accept(BuildMetadataCleanupListener.this, IContainer.INCLUDE_TEAM_PRIVATE_MEMBERS);
                            } catch (CoreException e) {
                                DMTeamPlugin.getDefault().getLog().log(e.getStatus());
                            }
                        }
                    }, resource, 0, null);
                }
            }
        } catch (CoreException e) {
            DMTeamPlugin.getDefault().getLog().log(e.getStatus());
        }
    }

    @Override
    public boolean visit(IResourceDelta delta) throws CoreException {
        IResource resource = delta.getResource();
        boolean movedFrom = (delta.getFlags() & IResourceDelta.MOVED_FROM) > 0;
        switch (delta.getKind()) {
        case IResourceDelta.ADDED:
            // make sure the added resource isn't a phantom
            if (resource.exists()) {
                if (resource.getType() == IResource.FOLDER) {
                    String name = resource.getName();
                    MetadataProvider mdp = MetadataProviderFactory.providerFor(resource);
                    try {
                        if (mdp.isMetadataDir(name)) {
                            handleOrphanedSubtree(resource.getParent());
                            return false;
                        }
                        return !handleOrphanedSubtree((IContainer) resource);
                    } finally {
                        if (mdp != null) {
                            mdp.close();
                        }
                    }
                }
            }
            break;
        case IResourceDelta.CHANGED:
            // This state means there is a resource before and after but changes were made by deleting and moving.
            // For files, we shouldn'd do anything.
            // For folders, we should purge the dm info
            if (movedFrom && resource.getType() == IResource.FOLDER && resource.exists()) {
                // When folders are moved, purge the .metadata folders
                return !handleOrphanedSubtree((IContainer) resource);
            }
            break;
        }
        return true;
    }

    /*
     * Determine if the container is an orphaned subtree.
     * If it is, handle it and return true.
     * Otherwise, return false
     */
    private boolean handleOrphanedSubtree(IContainer container) {
        try {
            if (DMTeamPlugin.getWorkspace().isOrphanedSubtree(container)) {
                IDMWorkspaceFolder mFolder = (IDMWorkspaceFolder) DMTeamPlugin.getWorkspace()
                        .getWorkspaceResource(container);
                mFolder.unmanage(null);
                return true;
            }
        } catch (CoreException e) {
            DMTeamPlugin.getDefault().getLog().log(e.getStatus());
        }
        return false;
    }

}

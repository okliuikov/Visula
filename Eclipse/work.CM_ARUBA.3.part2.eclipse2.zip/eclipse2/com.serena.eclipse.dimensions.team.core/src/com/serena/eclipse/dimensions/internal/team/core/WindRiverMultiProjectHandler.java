package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * This is a handler for windriver recursive project structure. Since 14.2 it isn't supported.
 */
public class WindRiverMultiProjectHandler implements IMultiProjectOperation {

    private static final String WR_PROJECT_FILE = ".wrproject"; //$NON-NLS-1$

    private static final String WR_ROOT_ELEMENT = "wrxml"; //$NON-NLS-1$
    private static final String WR_SUBPROJECTS_ELEMENT = "subprojects"; //$NON-NLS-1$
    private static final String WR_SUBPROJECT_ELEMENT = "subproject"; //$NON-NLS-1$
    private static final String WR_PROJECT_ATTRIBUTE = "project"; //$NON-NLS-1$

    private Set<IProject> theProjects = new HashSet<IProject>();

    @Override
    public IProject[] getProjectsToOperateOn(IProject[] topProjects) {
        // reset
        theProjects.clear();
        // Set Projects = new HashSet();
        // process list of projects
        for (int projs = 0; projs < topProjects.length; projs++) {
            theProjects.add(topProjects[projs]);
            processProject(topProjects[projs]);
        }
        IProject[] projectsToReturn = theProjects.toArray(new IProject[theProjects.size()]);
        return projectsToReturn;
    }

    private void processProject(IProject in) {
        List<String> pnames = subProjects(in);
        if (pnames != null && pnames.size() > 0) {
            IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
            for (Iterator<String> pit = pnames.iterator(); pit.hasNext();) {
                IProject proj = root.getProject(pit.next());
                if (proj != null && proj.exists() && proj.isOpen()) {
                    boolean b = theProjects.add(proj);
                    if (b) {
                        // if not already there recurse - if already there has been processed
                        processProject(proj);
                    }
                }
            }
        }
    }

    private List<String> subProjects(IProject in) {
        List<String> ret = null;
        IFile wrProject = (IFile) in.findMember(WR_PROJECT_FILE);
        if (wrProject != null && wrProject.exists()) {
            // we have a .wrrproject
            File wrProjectFile = new File(wrProject.getLocation().toOSString());
            ret = parseDocument(wrProjectFile);
        }
        return ret;
    }

    private static class WrHandler extends DefaultHandler {
        boolean inWr;
        boolean inSubp;
        List<String> projectNames;

        private WrHandler() {
            inWr = false;
            inSubp = false;
            projectNames = new ArrayList<String>();
        }

        @Override
        public void startElement(String nsURI, String strippedName, String tagName, Attributes attributes) throws SAXException {
            if (WR_ROOT_ELEMENT.equalsIgnoreCase(tagName)) {
                inWr = true;
            }
            if (inWr && WR_SUBPROJECTS_ELEMENT.equalsIgnoreCase(tagName)) {
                inSubp = true;
            }
            if (inSubp && WR_SUBPROJECT_ELEMENT.equalsIgnoreCase(tagName)) {
                // add to list
                projectNames.add(attributes.getValue(WR_PROJECT_ATTRIBUTE).substring(1));
            }

        }

        private List<String> getSubProjectList() {
            return projectNames;
        }

    }

    private List<String> parseDocument(File doc) {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        WrHandler wrh = new WrHandler();
        try {
            SAXParser sp = spf.newSAXParser();

            sp.parse(doc, wrh);

        } catch (SAXException se) {
        } catch (ParserConfigurationException pce) {
        } catch (IOException ioe) {
        }
        return wrh.getSubProjectList();
    }

}

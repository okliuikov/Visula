/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFileModificationValidator;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceStatus;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.resources.team.IMoveDeleteHook;
import org.eclipse.core.resources.team.IResourceTree;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ILock;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsRuntimeException;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.DirectoryMetadata;
import com.serena.dmfile.ItemDirMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.metadb.IMetadataStorage;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProject;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

class MoveDeleteHook implements IMoveDeleteHook { 
    private static final String FROM_PROJECT = WorkspaceMetadataManager.FROM_PROJECT;
    private static final String FROM_BASELINE = WorkspaceMetadataManager.FROM_BASELINE;

    private ILock lock;

    private static final boolean DEBUG_MOV_DEL = DMTeamPlugin.getDefault().isDebuggingMoveDelete();

    /**
     * Creates a new hook instance.
     */
    MoveDeleteHook() {
        lock = Job.getJobManager().newLock();
    }

    // notify workspace of file deletion
    @Override
    public boolean deleteFile(IResourceTree tree, IFile file, int updateFlags, IProgressMonitor monitor) {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        if (DEBUG_MOV_DEL) {
            System.out.println("MDH delete file " + file.toString());
        }
        try {
            lock.acquire();
            if (file.isTeamPrivateMember()) {
                return false; // no special handling needed
            }
            DMWorkspace workspace = getWorkspace();
            if (workspace.isIgnored(file)) {
                return false; // no special handling needed
            }
            tree.standardDeleteFile(file, updateFlags, Utils.subMonitorFor(monitor, 50));
        } catch (CoreException e) {
            tree.failed(e.getStatus());
        } finally {
            lock.release();
            monitor.done();
        }
        return true;
    }

    @Override
    public boolean deleteFolder(IResourceTree tree, IFolder folder, int updateFlags, IProgressMonitor monitor) {
        if (DEBUG_MOV_DEL) {
            System.out.println("MDH deleteFolder " + folder.toString());
        }
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        try {
            lock.acquire();
            if (folder.isTeamPrivateMember()) {
                return false; // no special handling needed
            }
            DMWorkspace workspace = getWorkspace();
            if (workspace.isIgnored(folder)) {
                return false;
            }
            // TODO VG on May 9, 2006: to be correct need to handle deletions ourselves here!
            if (workspace.isMoved(folder)) {
                if (workspace.getMovedFrom(folder) != null) { // if file is a move destination get rid of moved metadata
                    workspace.releaseBase(folder);
                    workspace.unmanage(folder, null);
                }
            }

            folder.accept(new IResourceVisitor() {
                @Override
                public boolean visit(IResource resource) throws CoreException {
                    getWorkspace().unregisterMove(resource);
                    return true;
                }
            }, IResource.DEPTH_INFINITE, true);
            tree.standardDeleteFolder(folder, updateFlags, Utils.subMonitorFor(monitor, 50));
        } catch (CoreException e) {
            tree.failed(e.getStatus());
        } finally {
            lock.release();
            monitor.done();
        }
        return true;
    }

    @Override
    public boolean deleteProject(IResourceTree tree, IProject project, int updateFlags, IProgressMonitor monitor) {
        try {
            // if this project is a virtual remove it from root
            IDMProject idmProject = TeamUtils.findProjectInWorkspace(project);
            if (idmProject instanceof VirtualIdmProject) {
                VirtualIdmProject virtual = (VirtualIdmProject) idmProject;
                RootIdmProject root = virtual.getRootProject();
                root.removeVirtualChildProject(project);
            } else {
                // if this is a regular project we need to remove all virtual child projects
                TeamUtils.unmanageVirtualChildren(project, monitor);
                IPath workAreaPath = idmProject.getWorkAreaPath();

                if (workAreaPath != null && !workAreaPath.isEmpty()) {
                    MetadataProviderFactory.removeProvider(workAreaPath.toOSString());
                } else {
                    MetadataProviderFactory.removeProvider(project.getLocation().toOSString());
                }

            }
        } catch (CoreException e) {
            tree.failed(e.getStatus());
        }
        return false;
    }

    @Override
    public boolean moveFile(IResourceTree tree, IFile source, IFile destination, int updateFlags, IProgressMonitor monitor) {
        if (DEBUG_MOV_DEL) {
            System.out.println("MDH moveFile " + source.toString() + " " + destination.toString());
        }

        boolean markerFileMoved = false;
        if (source.getFileExtension() != null) {
            markerFileMoved = source.getFileExtension().equals(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);
        }

        if (!validateMoveStatus(source.getProject(), false) && !markerFileMoved) {
            IContainer srcParent = source.getParent();
            IContainer dstParent = destination.getParent();
            if (!srcParent.getFullPath().equals(dstParent.getFullPath()) && dstParent.exists()) {
                try {
                    dstParent.delete(true, null); // force, null monitor
                } catch (CoreException e) {
                    DMTeamPlugin.log(e.getStatus());
                }
            }
            String warning = "Resource renaming is disallowed if parent project rename was not committed to Dimensions";
            displayWarning(warning);
            throw new IllegalArgumentException(warning); // disallow move operation
        }

        // Given: source exists in workspace resource tree
        // Given: destination does not exist in workspace resource tree
        // Given: destination parent exists and is open in workspace resource tree
        if (!source.exists() || destination.exists() || !destination.getParent().isAccessible()) {
            throw new IllegalArgumentException();
        }

        if (source.isTeamPrivateMember() && !markerFileMoved) {
            return false;
        }

        DMWorkspace workspace = getWorkspace();

        try {
            IDMWorkspaceFile dmFile = (IDMWorkspaceFile) workspace.getWorkspaceResource(source);
            if (dmFile == null || dmFile.isIgnored()) {
                return false;
            }
        } catch (CoreException e) {
            tree.failed(e.getStatus());
            return true;
        }

        IFile[] filesToValidate;
        if (destination.exists()) {
            filesToValidate = new IFile[] { source, destination };
        } else {
            filesToValidate = new IFile[] { source };
        }
        if (!validateEdit(tree, filesToValidate)) {
            // Return that the move was handled because the validate
            // will have reported the error to the IResourceTree
            return true;
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask("Moving: " + source.getFullPath().toString(), 1000);
        boolean deferred = DMWorkspace.setupDeferredMdListener();
        try {
            lock.acquire();
            // if FORCE is not specified, fail if the workspace resource tree is
            // not in sync at source file in the local file system
            boolean force = (updateFlags & IResource.FORCE) != 0;
            if (!force && !tree.isSynchronized(source, IResource.DEPTH_ZERO)) {
                // report failure
                Status status = DMTeamStatus.createErrorStatus(IResourceStatus.OUT_OF_SYNC_LOCAL,
                        "File " + source.getFullPath() + " is out of sync with the local file system", null);
                tree.failed(status);
                return true; // return true to say that the operation has been done
            }

            // capture the current state of the source file in the local history if
            // KEEP_HISTORY is specified
            boolean keepHistory = (updateFlags & IResource.KEEP_HISTORY) != 0;
            if (keepHistory) {
                tree.addToLocalHistory(source);
            }
            monitor.worked(100);

            boolean isDeep = (updateFlags & IResource.SHALLOW) == 0;
            // for shallow move of linked resources, nothing needs to be moved in the file system
            if (!isDeep && source.isLinked()) {
                tree.movedFile(source, destination);
                return true;
            }

            // try to move the source file in the local file system
            java.io.File lfsSource = source.getLocation().toFile();
            java.io.File lfsDestination = destination.getLocation().toFile();
            boolean moveSuccess = moveLocalFile(lfsSource, lfsDestination, Utils.subMonitorFor(monitor, 700));
            if (moveSuccess) {
                // update the workspace resource tree to match
                tree.movedFile(source, destination);
                // moveLocalFile may have affected timestamp
                // update timestamp to avoid having out of sync destination
                tree.updateMovedFileTimestamp(destination, tree.computeTimestamp(destination));

                // move and update metadata
                fileMoved(source, destination);

                // return true to say that the operation has been done
                return true;
            }
            // report an unexpected failure
            Status status = DMTeamStatus.createErrorStatus(0,
                    "Unable to move file " + source.getFullPath() + " in the local file system", null);
            tree.failed(status);
            // return true to say that the operation has been done
            return true;
        } finally {
            lock.release();
            monitor.done();
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }

    }

    @Override
    public boolean moveFolder(IResourceTree tree, IFolder source, IFolder destination, int updateFlags,
            IProgressMonitor monitor) {
        if (DEBUG_MOV_DEL) {
            System.out.println("MDH moveFolder " + source.toString() + " " + destination.toString());
        }
        if (!validateMoveStatus(source.getProject(), false)) {
            String warning = "Resource renaming is disallowed if parent project rename was not committed to Dimensions";
            displayWarning(warning);
            throw new IllegalArgumentException(warning); // disallow move operation
        }

        // Given: source exists in workspace resource tree
        // Given: destination does not exist in workspace resource tree
        // Given: destination parent exists and is open in workspace resource tree
        if (!source.exists() || destination.exists() || !destination.getParent().isAccessible()) {
            throw new IllegalArgumentException();
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask("Moving: " + source.getFullPath().toString(), 1000);
        boolean deferred = DMWorkspace.setupDeferredMdListener();
        try {
            lock.acquire();
            // if FORCE is not specified, fail if the workspace resource tree is
            // not in sync at source folder and its descendants in the local file system
            boolean force = (updateFlags & IResource.FORCE) != 0;
            if (!force) {
                boolean inSync = tree.isSynchronized(source, IResource.DEPTH_INFINITE);
                if (!inSync) {
                    // report failure
                    Status status = DMTeamStatus.createErrorStatus(IResourceStatus.OUT_OF_SYNC_LOCAL,
                            "Folder " + source.getFullPath() + " is out of sync with the local file system", null);
                    tree.failed(status);
                    // return true to say that the operation has been done
                    return true;
                }
            }

            // capture the current state of all files in the local history if
            // KEEP_HISTORY is specified
            boolean keepHistory = (updateFlags & IResource.KEEP_HISTORY) != 0;
            if (keepHistory) {
                addAllFilesToHistory(tree, source);
            }
            monitor.worked(100);

            // for linked resources, nothing needs to be moved in the file system
            boolean isDeep = (updateFlags & IResource.SHALLOW) == 0;
            if (!isDeep && source.isLinked()) {
                tree.movedFolderSubtree(source, destination);
                return true;
            }

            // try to move the subtree in the local file system
            java.io.File lfsSource = source.getLocation().toFile();
            java.io.File lfsDestination = destination.getLocation().toFile();
            boolean lfsSuccess = moveLocalSubtree(lfsSource, lfsDestination, Utils.subMonitorFor(monitor, 400));
            if (lfsSuccess) {
                // update the workspace resource tree to match
                tree.movedFolderSubtree(source, destination);
                // moveLocalSubtree may have affected file timestamps
                // update file timestamps to avoid having out of sync destination
                updateTimestamps(tree, destination, isDeep);

                folderMoved(source, destination, Utils.subMonitorFor(monitor, 400));

                // return true to say that the operation has been done
                return true;
            }
            // report an unexpected failure
            Status status = DMTeamStatus.createErrorStatus(0,
                    "Unable to move folder " + source.getFullPath() + " in the local file system", null);
            tree.failed(status);
            // return true to say that the operation has been done
            return true;
        } finally {
            lock.release();
            monitor.done();
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }
    }

    /**
     * Helper method to update all the timestamps in the tree to match
     * those in the file system. Used after a #move.
     */
    private void updateTimestamps(final IResourceTree tree, IResource root, final boolean isDeep) {
        IResourceVisitor visitor = new IResourceVisitor() {
            @Override
            public boolean visit(IResource resource) {
                boolean isLinked = resource.isLinked();
                if (isLinked && !isDeep) {
                    // don't need to visit children because they didn't move
                    return false;
                }
                if (resource.getType() == IResource.FILE) {
                    IFile file = (IFile) resource;
                    tree.updateMovedFileTimestamp(file, tree.computeTimestamp(file));
                }
                return true;
            }
        };
        try {
            root.accept(visitor, IResource.DEPTH_INFINITE, IContainer.INCLUDE_TEAM_PRIVATE_MEMBERS);
        } catch (CoreException e) {
            // No exception should be thrown.
        }
    }

    /**
     * This <code>IMoveDeleteHook</code> method implements <code>IResource.move(IProjectDescrition,int,IProgressMonitor)</code>
     * where the receiver is a project. This example implementation illustrates
     * the steps involved (except for progress monitoring). The general approach
     * illustrated here relocates the entire project content are in the local
     * file system and then fixes up the workspace resource tree to match using <code>IResourceTree.movedProject</code>.
     *
     * @param tree
     *            the workspace resource tree; this object is only valid
     *            for the duration of the invocation of this method, and must not be
     *            used after this method has completed
     * @param source
     *            the handle of the project to move; the receiver of
     *            <code>IResource.move(IProjectDescription,int,IProgressMonitor)</code> or
     *            <code>IResource.move(IPath,int,IProgressMonitor)</code>;
     *            guaranteed to exist and be open in the workspace resource tree
     * @param description
     *            the new description of the project; the first
     *            parameter to <code>IResource.move(IProjectDescription,int,IProgressMonitor)</code>, or
     *            a copy of the project's description with the location changed to the
     *            path given in the first parameter to <code>IResource.move(IPath,int,IProgressMonitor)</code>
     * @param updateFlags
     *            bit-wise or of update flag constants as per
     *            <code>IResource.move(IProjectDescription,int,IProgressMonitor)</code> or
     *            <code>IResource.move(IPath,int,IProgressMonitor)</code>
     * @param monitor
     *            the progress monitor, or <code>null</code> as per
     *            <code>IResource.move(IProjectDescription,int,IProgressMonitor)</code> or
     *            <code>IResource.move(IPath,int,IProgressMonitor)</code>
     * @return <code>false</code> if this method declined to assume
     *         responsibility for this operation, and <code>true</code> if this method
     *         attempted to carry out the operation
     * @see IResource#move(IPath,int,IProgressMonitor)
     * @see IResource#move(IProjectDescription,int,IProgressMonitor)
     * @see IMoveDeleteHook#moveProject(IResourceTree,IProject,IProjectDescription,int,IProgressMonitor)
     */
    @Override
    public boolean moveProject(IResourceTree tree, IProject project, IProjectDescription description, int updateFlags,
            IProgressMonitor monitor) {
        if (DEBUG_MOV_DEL) {
            System.out.println("MDH moveProject " + project.toString() + " " + description.getName() + " "
                    + (description.getLocation() == null ? "null" : description.getLocation().toOSString()));
        }
        // are we changing the name of the project?
        // this affects the workspace resource tree
        String oldProjectName = project.getName();
        String newProjectName = description.getName();
        boolean renaming = !newProjectName.equals(oldProjectName);

        boolean isFullWorkArea;
        IDMProject dmProject = null;
        try {
            dmProject = getWorkspace().getProject(project);
        } catch (CoreException ignored) {
        }
        if (dmProject != null) {
            isFullWorkArea = dmProject.isFullWorkArea();
        } else {
            // old 'inWorkspace' check
            isFullWorkArea = !ResourcesPlugin.getWorkspace().getRoot().getLocation().isPrefixOf(project.getLocation());
        }
        // are we changing the location of the project content area?
        // this affects the files in the local file system
        // and the workspace resource tree
        IPath oldProjectContentArea = project.getLocation();
        // not null means new location is outside current ws
        IPath newProjectContentArea = description.getLocation();
        if (newProjectContentArea == null) {
            // compute path of new default project content area
            newProjectContentArea = Platform.getLocation().append(newProjectName);
        } else if (isFullWorkArea && renaming) {
            newProjectContentArea = newProjectContentArea.removeLastSegments(1).append(description.getName());
            description.setLocation(newProjectContentArea);
        }
        boolean relocating = !newProjectContentArea.equals(oldProjectContentArea);
        // this situation occurs when we try to add a project to the ws with the same name
        // as existing one but with different remote project
        if (!renaming && !relocating) {
            // delegate handling to a built-in handler
            return false;
        }

        if (!validateMoveStatus(project, true)) {
            String warning = "Project renaming is disallowed if child resource rename was not committed to Dimensions";
            displayWarning(warning);
            throw new IllegalArgumentException(warning); // disallow move operation
        }

        // Given: source exists and is open in workspace resource tree
        if (!project.exists() || !project.isOpen()) {
            throw new IllegalArgumentException();
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask("Moving project: " + project.getName() + " to " + description.getName(), 100);
        // bracket with deferred md listener
        boolean deferred = DMWorkspace.setupDeferredMdListener();
		try {
			lock.acquire();

			DMRepositoryProvider dmProvider = DMRepositoryProvider.getDMProvider(project);
			dmProvider.projectMoved(description.getName()); // let our provider know the expected project name

			IProject newProject = project.getWorkspace().getRoot().getProject(newProjectName);

			// fail we are renaming to project that exists in workspace resource tree
			if (renaming && newProject.exists()) {
				// report failure
				Status status = new Status(IStatus.ERROR, "com.example.movedeletehook", 0,
						"Project " + newProject.getFullPath() + " already exists", null);
				tree.failed(status);
				// return true to say that the operation has been done
				return true;
			}

			// relocate the project content area
			if (relocating) {
				// need to move files in local file system
				boolean lfsMoveSuccess = moveLocalSubtree(oldProjectContentArea.toFile(),
						newProjectContentArea.toFile(), monitor);
				if (!lfsMoveSuccess) {
					// report failure
					Status status = new Status(IStatus.ERROR, "com.example.movedeletehook", 0,
							"Unable to move project contents for " + newProject.getFullPath(), null);
					tree.failed(status);
					// return true to say that the operation has been done
					return true;
				}
			}
			// metadata of project folder(for full work area project) should be renamed
			if (isFullWorkArea && renaming) {
				File metadataFile = WorkspaceMetadataManager.getMetadataFile(oldProjectContentArea,
						IMetadataStorage.MetadataTypes.MT_DIR);
				if (metadataFile.exists()) {
					metadataFile.renameTo(WorkspaceMetadataManager.getMetadataFile(newProjectContentArea,
							IMetadataStorage.MetadataTypes.MT_DIR));
				}
			}
			monitor.worked(40);

			// set DM_PROJECT_MOVED_PROP property, based on that we do repository-side
			// renaming further down the workflow
			IDMProject srcProject = null;
			try {
				srcProject = getWorkspace().getProject(project);
				// for non-Scc project rename ends with the end of current function
				if (srcProject.isSccStyle()) {
					// do this to indicate project was moved
					// we get status for the project folder based on this property (as we could not
					// get it from metadata)
					// the property have to be flushed on Commit Move
					IPath dstRmtOffset = srcProject.getRemoteOffset();
					assert dstRmtOffset != null;
					String movedFrom = dstRmtOffset.toString();
					String oldMovedFrom = project.getPersistentProperty(DMRepositoryProvider.DM_PROJECT_MOVED_PROP);
					boolean previouslyMoved = !Utils.isNullEmpty(oldMovedFrom);
					if (!previouslyMoved) { // preserve original move information
						project.setPersistentProperty(DMRepositoryProvider.DM_PROJECT_MOVED_PROP, movedFrom);
					} else {
						getWorkspace().releaseBase(project); // release transient metadata cache entry
					}
				}
			} catch (CoreException e) {
				tree.failed(e.getStatus());
				return true;
			}

			// update project in workspace resource tree
			boolean treeMoveSuccess = tree.movedProjectSubtree(project, description);
			if (!treeMoveSuccess) {
				// report failure
				Status status = new Status(IStatus.ERROR, "com.example.movedeletehook", 0,
						"Unable to move project " + project.getFullPath(), null);
				tree.failed(status);
				// return true to say that the operation has been done
				return true;
			}
			monitor.worked(10);

			if (relocating) {
				boolean isDeep = (updateFlags & IResource.SHALLOW) == 0;
				// moveLocalSubtree may have affected file timestamps
				// update file timestamps to avoid having out of sync destination
				updateTimestamps(tree, newProject, isDeep);
			}
			monitor.worked(10);

			// update metadata of child resources if they referenced to the old project name
			// projectMoved(project, newProject, Utils.subMonitorFor(monitor, 40));
			if (srcProject.isSccStyle()) {
				projectMoved(project, srcProject, newProject, Utils.subMonitorFor(monitor, 30));
			} else {
				// For non-Scc projects end up with renamed project root folder and changed
				// .project file on the disk.
				// No need to update metadata as moved.
				try {
					Long uid = (Long) null;

					Project proj = (Project) srcProject.getDimensionsObject();
					// Update WS_IDE_INFO table with new project name and refresh UI.
					proj.deleteIdeInfo();
					boolean initial = srcProject.isInitial() || "Y".equalsIgnoreCase( //$NON-NLS-1$
							(String) srcProject.getDimensionsObject().getAttribute(SystemAttributes.IDE_INITIAL));
					if (initial == false) {
						final String parentSpec = getParentSpec(srcProject);

						if (parentSpec != null) {
							final Session session = srcProject.getConnection()
									.openSession(Utils.subMonitorFor(monitor, 30));

							final Long[] result = { (Long) null };
							session.run(new ISessionRunnable() {

								@Override
								public void run() throws Exception {
									DimensionsObjectFactory factory = session.getObjectFactory();
									Project parent = factory.getProject((String) parentSpec);
									result[0] = (Long) parent.getAttribute(SystemAttributes.OBJECT_UID);
								}
							}, null);
							uid = result[0];
						}
					}
					proj.setIdeInfo(srcProject.getIdeTag(), newProjectName, uid, initial);

					WorksetList lst = WorksetList.getDimensionsIDEProjectsList(srcProject.getConnection(), false,
							false);
					WorksetAdapter adapter = lst.findWorkset(srcProject.getId());
					if (adapter instanceof DimensionsIDEProject) {
						((DimensionsIDEProject) adapter).setName(newProjectName); // updates Serena Explorer tree
					}
					lst.update(Utils.subMonitorFor(monitor, 30)); // query updated attributes, affects UI
				} catch (CoreException e) {
					DMTeamPlugin.log(e.getStatus());
				} 
				catch (DimensionsRuntimeException e) {
					DMTeamPlugin.log(DMTeamStatus.createErrorStatus(DMTeamStatus.ERROR, e.getMessage()));
				}
			}
			// update local project in Dimensions entity field
			((DMProject) srcProject).setProject(newProject);

			// return true to say that the operation has been done
			return true;
		} finally {
            lock.release();
            monitor.done();
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }
    }

    /**
     * Captures local history for all files in the subtree rooted at the
     * given container. The given container must exist and be accessible.
     *
     * @param tree
     *            the workspace resource tree
     * @param container
     *            the root container
     */
    private void addAllFilesToHistory(final IResourceTree tree, IContainer container) {

        // Resource visitor for keeping local history for files it visits
        class KeepVisitor implements IResourceVisitor {
            @Override
            public boolean visit(IResource resource) {
                if (resource.getType() == IResource.FILE) {
                    // capture current state of file in local history
                    tree.addToLocalHistory((IFile) resource);
                }
                return true;
            }
        }

        try {
            // only save history for regular members as there is little point
            // in saving history for team-private members
            container.accept(new KeepVisitor(), IResource.DEPTH_INFINITE, IResource.NONE);
        } catch (CoreException e) {
            // We want to ignore any exceptions thrown by the history store because
            // they aren't enough to fail the operation as a whole.
            DMTeamPlugin.log(e.getStatus());
            // throw new RuntimeException();
        }
    }

    /**
     * Deletes the given directory subtree in the local file system.
     * Returns <code>true</code> immediately if the given folder does
     * not exist.
     *
     * @param lfsFolder
     *            the folder in the local file system
     * @return <code>true</code> if the given folder no longer exists,
     *         and <code>false</code> if it was not deleted
     */
    private boolean deleteLocalSubtree(java.io.File lfsFolder) {
        java.io.File[] lfsChildren = lfsFolder.listFiles();
        if (lfsChildren == null) {
            if (lfsFolder.exists()) {
                // folder does exists (I/O error or not a directory)
                return false;
            }
            // folder does not exist
            return true;
        }
        // delete all children first
        for (int i = 0; i < lfsChildren.length; i++) {
            java.io.File lfsChild = lfsChildren[i];
            if (lfsChild.isFile()) {
                lfsChild.delete();
            } else if (lfsChild.isDirectory()) {
                deleteLocalSubtree(lfsChild);
            }
        }
        lfsFolder.delete();
        // we're happy as long as folder is gone
        return !lfsFolder.exists();
    }

    /**
     * Copies the given source file in the local file system to the given
     * destination file. The operation fails rather than overwriting an
     * existing destination file. The destination parent folder will be
     * created if required.
     *
     * @param lfsSource
     *            the source file in the local file system; this is
     *            the file to be copied
     * @param lfsDestination
     *            the destination file in the local file system;
     *            this is where the file is to be copied to
     * @return <code>true</code> if the copy was successful,
     *         and <code>false</code> if the copy failed
     */
    private boolean copyLocalFile(java.io.File lfsSource, java.io.File lfsDestination, IProgressMonitor monitor) {

        // create the destination parent folder if required
        java.io.File lfsDestinationParent = lfsDestination.getParentFile();
        if (lfsDestinationParent != null && !lfsDestinationParent.exists()) {
            boolean mkdirSuccess = lfsDestinationParent.mkdirs();
            if (!mkdirSuccess) {
                // fail if unable to create destination parent folder
                return false;
            }
        }

        if (lfsDestination.exists()) {
            // so that we do not overwrite an existing file
            return false;
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, (int) lfsSource.length());

        InputStream in = null;
        OutputStream out = null;
        try {
            in = new FileInputStream(lfsSource);
            out = new FileOutputStream(lfsDestination);
            int bufferSize = TeamUtils.getReadBufferSize(lfsSource.length());
            byte[] buffer = new byte[bufferSize];
            while (true) {
                int bytesRead = in.read(buffer);
                if (bytesRead < 0) {
                    break;
                }
                out.write(buffer, 0, bytesRead);
                monitor.worked(bytesRead);
            }
            return true;
        } catch (FileNotFoundException e) {
            DMTeamPlugin.log(DMTeamStatus.createErrorStatus(0, "File not found", e));
            // unable to open the source file for input
            // or unable to open the destination file for output
            // fail in either case
            return false;
        } catch (IOException e) {
            DMTeamPlugin.log(DMTeamStatus.createErrorStatus(0, "Error copying file", e));
            // fail
            return false;
        } finally {
            // close both streams in all cases
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException closeException) {
                // ignore
            }
            try {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            } catch (IOException closeException) {
                DMTeamPlugin.log(DMTeamStatus.createErrorStatus(0, "Error closing destination file", closeException));
                // better safe than sorry
                // fail if we have problems closing the output stream
                return false;
            }
            monitor.done();
        }
    }

    /**
     * Copies the given folder subtree in the local file system to the given
     * destination folder. The operation fails rather than overwriting an
     * existing file. The destination parent folder will be created if required.
     *
     * @param lfsSource
     *            the source folder in the local file system; this is
     *            the folder to be copied
     * @param lfsDestination
     *            the destination folder in the local file system;
     *            this is where the folder is to be copied to
     * @return <code>true</code> if the copy was successful,
     *         and <code>false</code> if the copy failed
     */
    private boolean copyLocalSubtree(java.io.File lfsSource, java.io.File lfsDestination, IProgressMonitor monitor) {

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);

        try {
            java.io.File[] lfsChildren = lfsSource.listFiles();
            if (lfsChildren == null) {
                // folder does not exist, I/O error, or not a directory
                // fail since no source to copy
                return false;
            }

            // create the destination folder if required
            if (!lfsDestination.exists()) {
                boolean mkdirSuccess = lfsDestination.mkdirs();
                if (!mkdirSuccess) {
                    // fail if unable to create destination folder
                    return false;
                }
            }
            monitor.worked(50);

            List<FileToCopy> filesToCopy = new ArrayList<FileToCopy>();
            collectFilesToCopy(lfsSource, lfsDestination, filesToCopy);
            monitor.worked(50);

            IProgressMonitor copyMonitor = Utils.subMonitorFor(monitor, 900);
            copyMonitor.beginTask(null, filesToCopy.size() * 100);
            for (Iterator<FileToCopy> iter = filesToCopy.iterator(); iter.hasNext();) {
                FileToCopy fileToCopy = iter.next();
                if (!copyLocalFile(fileToCopy.source, fileToCopy.destination, Utils.subMonitorFor(copyMonitor, 100))) {
                    return false;
                }
            }
            copyMonitor.done();
        } finally {
            monitor.done();
        }

        // succeed since all children were successfully copied
        return true;
    }

    private class FileToCopy {
        File source, destination;

        FileToCopy(File src, File dst) {
            source = src;
            destination = dst;
        }
    }

    private void collectFilesToCopy(java.io.File lfsSource, java.io.File lfsDestination, List<FileToCopy> container) {
        java.io.File[] lfsChildren = lfsSource.listFiles();
        for (int i = 0; i < lfsChildren.length; i++) {
            java.io.File lfsChild = lfsChildren[i];
            java.io.File lfsDestinationChild = new java.io.File(lfsDestination, lfsChild.getName());
            if (lfsChild.isFile()) {
                container.add(new FileToCopy(lfsChild, lfsDestinationChild));
            } else {
                collectFilesToCopy(lfsChild, lfsDestinationChild, container);
            }
        }
    }

    /**
     * Moves the given source file in the local file system to the given
     * destination file. The destination's parent folder will be created
     * if required. The timestamp of the file may change in the process.
     *
     * @param lfsSource
     *            the source file in the local file system; this is
     *            the file to be moved
     * @param lfsDestination
     *            the destination file in the local file system;
     *            this is where the file is to be moved to
     * @return <code>true</code> if the move was successful,
     *         and <code>false</code> if the move failed
     */
    private boolean moveLocalFile(java.io.File lfsSource, java.io.File lfsDestination, IProgressMonitor monitor) {

        // create the destination parent (and ancestors) if required
        java.io.File lfsDestinationParent = lfsDestination.getParentFile();
        if (lfsDestinationParent != null && !lfsDestinationParent.exists()) {
            boolean mkdirsSuccess = lfsDestinationParent.mkdirs();
            if (!mkdirsSuccess) {
                // fail because destination parent cannot be created
                return false;
            }
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);

        try {
            // attempt to rename the file
            boolean renameSuccess = lfsSource.renameTo(lfsDestination);
            if (renameSuccess) {
                // that was easy
                return true;
            }

            // plan B: copy the file and delete the original
            boolean copySuccess = copyLocalFile(lfsSource, lfsDestination, Utils.subMonitorFor(monitor, 1000));
            if (!copySuccess) {
                // fail if unable to make copy
                return false;
            }

            // delete the source file
            boolean deleteSuccess = lfsSource.delete();
            // operation succeeds iff we copied source and successfully deleted it
            return deleteSuccess;
        } finally {
            monitor.done();
        }

    }

    /**
     * Moves the given subtree in the local file system to the given
     * destination. The destination's parent folder will be created
     * if required.
     *
     * @param lfsSource
     *            the source folder in the local file system; this is
     *            the folder to be moved
     * @param lfsDestination
     *            the destination folder in the local file system;
     *            this is where the folder is to be moved to
     * @return <code>true</code> if the move was successful,
     *         and <code>false</code> if the move failed
     */
    private boolean moveLocalSubtree(java.io.File lfsSource, java.io.File lfsDestination, IProgressMonitor monitor) {

        // create the destination parent (and ancestors) if required
        java.io.File lfsDestinationParent = lfsDestination.getParentFile();
        if (lfsDestinationParent != null && !lfsDestinationParent.exists()) {
            boolean mkdirsSuccess = lfsDestinationParent.mkdirs();
            if (!mkdirsSuccess) {
                // fail because destination parent cannot be created
                return false;
            }
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            // attempt to rename the folder
            boolean renameSuccess = lfsSource.renameTo(lfsDestination);
            if (renameSuccess) {
                // that was easy
                return true;
            }

            // plan B: copy the folder and then delete the original
            boolean copySuccess = copyLocalSubtree(lfsSource, lfsDestination, Utils.subMonitorFor(monitor, 900));
            if (!copySuccess) {
                // fail if unable to make copy
                return false;
            }

            // delete the source folder
            boolean deleteSuccess = deleteLocalSubtree(lfsSource);
            // operation succeeds iff we copied source and successfully deleted it
            return deleteSuccess;
        } finally {
            monitor.done();
        }
    }

    private boolean validateEdit(IResourceTree tree, IFile files[]) {
        IFileModificationValidator validator = getFileModificationValidator(files);
        IStatus status = validator.validateEdit(files, null);
        if (status.isOK()) {
            return true;
        }
        tree.failed(status);
        return false;
    }

    private IFileModificationValidator getFileModificationValidator(IFile[] files) {
        return getProvider(files[0]).getFileModificationValidator();
    }

    private DMRepositoryProvider getProvider(IFile file) {
        return DMRepositoryProvider.getDMProvider(file);
    }

    private DMWorkspace getWorkspace() {
        return (DMWorkspace) DMTeamPlugin.getWorkspace();
    }

    // return true if success
    private boolean fileMoved(IFile source, IFile destination) {
        try {
            source = TeamUtils.getFile(source);
            destination = TeamUtils.getFile(destination);
            TeamUtils.refreshLocal(source, null);
            TeamUtils.refreshLocal(destination, null);
            IDMProject srcProject = DMTeamPlugin.getWorkspace().getProject(source);
            IDMProject dstProject = DMTeamPlugin.getWorkspace().getProject(destination);
            // nothing to do if at least one is unshared or if shared via 2 connections
            if (srcProject == null || dstProject == null || !srcProject.getConnection().equals(dstProject.getConnection())) {
                return true;
            }
            resourceMoved(source, srcProject, destination, dstProject);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
            return false;
        }
        return true;
    }

    // return true if success
    private boolean projectMoved(final IProject source, IDMProject srcProject, IProject destination,
            IProgressMonitor monitor) {
        monitor = Utils.monitorFor(monitor);
        try {
            IDMProject dstProject = getWorkspace().getProject(destination);
            // just in case
            if (srcProject == null || dstProject == null || !srcProject.getConnection().equals(dstProject.getConnection())) {
                return true;
            }

            final List<IResource[]> list = new ArrayList<IResource[]>();
            final MetadataProvider mdProvider = MetadataProviderFactory.providerFor(destination);
            // visit renamed resource
            try {
                destination.accept(new IResourceVisitor() {
                    @Override
                    public boolean visit(IResource resource) throws CoreException {
                        // skip visiting md containers at all
                        if (resource.getType() != IResource.FILE
                                && mdProvider.metadataDirname().equals(resource.getName())) {
                            return false;
                        }
                        // get paths from renamed resource
                        IPath dstRelPath = resource.getProjectRelativePath();
                        IResource srcResource = null;
                        if (resource.getType() == IResource.FOLDER) {
                            // obtain the same paths from original resource
                            srcResource = source.getFolder(dstRelPath);
                            list.add(new IResource[] { srcResource, resource });
                        } else if (resource.getType() == IResource.FILE) {
                            // obtain the same paths from original resource
                            srcResource = source.getFile(dstRelPath);
                            list.add(new IResource[] { srcResource, resource });
                        }
                        return true; // true means we gonna look into this visited resource
                    }
                });
            } finally {
                if (mdProvider != null) {
                    mdProvider.close();
                }
            }

            IResource[][] movedPairs = list.toArray(new IResource[list.size()][]);
            monitor.beginTask(null, movedPairs.length);
            for (int i = 0; i < movedPairs.length; i++) {
                IResource srcResource = movedPairs[i][0];
                IResource dstResource = movedPairs[i][1];

                monitor.subTask("Updating resources data: " + dstResource.getFullPath().toString());
                BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(dstResource);
                if (metadata != null) {
                    updateCascadeMovedResourceData(srcProject, srcResource, metadata, dstProject, dstResource);
                    TeamUtils.ensureReacheable(dstResource.getParent(), false);
                    WorkspaceMetadataManager.getInstance().updateMetadata(dstResource, metadata);
                }
                monitor.worked(1);
            }
            // Notify to execute Commit Move after SCC project renaming
            if (srcProject.isSccStyle() && !source.getName().equals(destination.getName())) {
                displayWarning(true, Messages.MoveDeleteHook_sccProjectWarning);
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
            return false;
        } finally {
            monitor.done();
        }

        return true;
    }

    // return true if success
    private boolean folderMoved(IFolder source, IFolder destination, IProgressMonitor monitor) {
        monitor = Utils.monitorFor(monitor);
        try {
            source = TeamUtils.getFolder(source);
            destination = TeamUtils.getFolder(destination);
            TeamUtils.refreshLocal(source, monitor);
            TeamUtils.refreshLocal(destination, monitor);
            DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
            final IDMProject srcProject = workspace.getProject(source);
            final IDMProject dstProject = workspace.getProject(destination);
            // nothing to do if at least one is unshared or if shared via 2 connections
            if (srcProject == null || dstProject == null || !srcProject.getConnection().equals(dstProject.getConnection())) {
                return true;
            }

            resourceMoved(source, srcProject, destination, dstProject);

            final IPath dstPath = destination.getProjectRelativePath();
            final List<IResource[]> list = new ArrayList<IResource[]>();
            final MetadataProvider mdProvider = MetadataProviderFactory.providerFor(destination);

            try {
                final IFolder fSource = source;
                IResourceVisitor visitor = new IResourceVisitor() {
                    @Override
                    public boolean visit(IResource resource) throws CoreException {
                        if (resource.getType() != IResource.FILE
                                && mdProvider.metadataDirname().equals(resource.getName())) {
                            return false;
                        }
                        IPath path = resource.getProjectRelativePath();
                        IPath destRelPath = path.removeFirstSegments(dstPath.segmentCount());
                        IResource srcResource = null;
                        if (resource.getType() == IResource.FILE) {
                            srcResource = fSource.getFile(destRelPath);
                        } else {
                            srcResource = fSource.getFolder(destRelPath);
                        }
                        list.add(new IResource[] { srcResource, resource });
                        return true;
                    }
                };
                IResource[] members = destination.members();
                for (int i = 0; i < members.length; i++) {
                    members[i].accept(visitor);
                }
            } finally {
                if (mdProvider != null) {
                    mdProvider.close();
                }
            }

            IResource[][] movedPairs = list.toArray(new IResource[list.size()][]);
            monitor.beginTask(null, movedPairs.length);

            for (int i = 0; i < movedPairs.length; i++) {
                IResource srcResource = movedPairs[i][0];
                IResource dstResource = movedPairs[i][1];
                monitor.subTask("Updating resources data: " + dstResource.getFullPath().toString());
                BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(dstResource);
                if (metadata != null) {
                    updateCascadeMovedResourceData(srcProject, srcResource, metadata, dstProject, dstResource);
                    TeamUtils.ensureReacheable(dstResource.getParent(), false);
                    WorkspaceMetadataManager.getInstance().updateMetadata(dstResource, metadata);
                }
                monitor.worked(1);

                IContainer mdCont = WorkspaceMetadataManager.getMdContainer(dstResource);
                if (mdCont != null) {
                    TeamUtils.refreshLocal(mdCont, null);
                }
            }
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
            return false;
        } finally {
            monitor.done();
        }
        return true;
    }

    // return true if success
    private void resourceMoved(IResource source, IDMProject srcProject, IResource destination, IDMProject dstProject)
            throws CoreException {

        if (DEBUG_MOV_DEL) {
            System.out.println("MDH resource moved " + source.toString() + " prj " + srcProject.getId() + " "
                    + destination.toString() + " prj " + dstProject.getId());
        }
        assert srcProject != null;
        assert dstProject != null;
        WorkspaceMetadataManager metaMan = WorkspaceMetadataManager.getInstance();
        BaseMetadata sourceMetadata = metaMan.getMetadata(source);
        BaseMetadata targetMetadata = metaMan.getMetadata(destination);
        if (sourceMetadata != null) {
            if (targetMetadata != null) { // we had an outgoing deletion in the destination, discard old metadata
                metaMan.deleteMetadata(destination, WorkspaceMetadataManager.DELETE_ALL);
            }
            updateMovedResourceMetadata(srcProject, source, sourceMetadata, dstProject, destination);
            // delete src md first to avoid issues with case-insensitive filename collisions
            metaMan.deleteMetadata(source, WorkspaceMetadataManager.DELETE_ALL);

            // this will handle renames too
            metaMan.updateMetadata(destination, sourceMetadata);

            IContainer mdCont = WorkspaceMetadataManager.getMdContainer(source);
            if (mdCont != null) {
                TeamUtils.refreshLocal(mdCont, null);
            }
            if (!source.getParent().equals(destination.getParent())) { // the same hierarchy means the same md container
                mdCont = WorkspaceMetadataManager.getMdContainer(destination);
                if (mdCont != null) {
                    TeamUtils.refreshLocal(mdCont, null);
                }
            }
        }
    }

    private void updateCascadeMovedResourceData(IDMProject srcProject, IResource source, BaseMetadata sourceMetadata,
            IDMProject dstProject, IResource destination) throws CoreException {
        DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
        DimensionsConnectionDetailsEx connection = dstProject.getConnection();

        int movedToProjectType = dstProject.getType();
        String movedToProjectId = dstProject.getId();

        String oldMovedFrom = getMovedFrom(sourceMetadata);
        boolean previousMoveInMetadata = !Utils.isNullEmpty(oldMovedFrom);

        IResource previouslyCachedMove = workspace.getMovedFrom(source);
        boolean previousMoveCached = previouslyCachedMove != null;
        boolean cascadeMoveOfDirectMoved = previousMoveInMetadata && previousMoveCached;
        boolean cascadeMoveOfCascadeMoved = !previousMoveInMetadata && previousMoveCached;
        boolean cascadeMoveOfNotMoved = !previousMoveInMetadata && !previousMoveCached;
        boolean cascadeMoveOfStrange = previousMoveInMetadata && !previousMoveCached;

        Assert.isTrue(!cascadeMoveOfStrange, "Metadata and move caches should contain the same move information");

        int movedFromProjectType = 0;
        String movedFromProjectId = null;
        IPath movedFromPath = null;
        String movedFromForRegister = null; // for registration full repo path
        boolean returned = false;
        boolean crossProject = false;
        if (cascadeMoveOfCascadeMoved || cascadeMoveOfDirectMoved) {
            IResource origin = workspace.unregisterMove(source);
            if (origin.equals(destination)) {
                returned = true;
                if (cascadeMoveOfDirectMoved) {
                    discardMovedState(sourceMetadata);
                }
            } else {
                IDMProject firstSrcProject = workspace.getProject(origin);
                crossProject = !firstSrcProject.remoteEquals(dstProject, false);

                String firstSrcProjectId = firstSrcProject.getId();
                int firstSrcProjectType = firstSrcProject.getType();
                if (crossProject && !dstProject.getId().equals(firstSrcProjectId)) {
                    movedFromProjectType = firstSrcProjectType;
                    movedFromProjectId = firstSrcProjectId;
                }

                movedFromPath = firstSrcProject.getRemotePathForLocalResource(origin);
                movedFromForRegister = movedFromPath.toString();

                if (cascadeMoveOfDirectMoved) {
                    int oldMovedFromProjectType = 0;
                    String oldMovedFromProjectId = sourceMetadata.get(FROM_PROJECT);
                    if (!Utils.isNullEmpty(oldMovedFromProjectId)) {
                        oldMovedFromProjectType = IDMProject.WORKSET;
                    } else {
                        oldMovedFromProjectId = sourceMetadata.get(FROM_BASELINE);
                        if (!Utils.isNullEmpty(oldMovedFromProjectId)) {
                            oldMovedFromProjectType = IDMProject.BASELINE;
                        }
                    }
                    boolean previouslyCrossMovedInMetadata = !Utils.isNullEmpty(oldMovedFromProjectId);
                    boolean returnedProjectInMetadata = previouslyCrossMovedInMetadata
                            && oldMovedFromProjectType == movedToProjectType
                            && movedToProjectId.equals(oldMovedFromProjectId);

                    if (crossProject) {
                        if (returnedProjectInMetadata) {
                            sourceMetadata.put(FROM_PROJECT, Utils.EMPTY_STRING);
                            sourceMetadata.put(FROM_BASELINE, Utils.EMPTY_STRING);
                        } else if (!previouslyCrossMovedInMetadata) {
                            String key = movedFromProjectType == IDMProject.WORKSET ? FROM_PROJECT : FROM_BASELINE;
                            sourceMetadata.put(key, movedFromProjectId);
                        }
                    }
                }

            }
        } else if (cascadeMoveOfNotMoved) {
            crossProject = !srcProject.remoteEquals(dstProject, false);
            if (crossProject) {
                movedFromProjectType = srcProject.getType();
                movedFromProjectId = srcProject.getId();
            }
            movedFromForRegister = srcProject.getRemotePathForLocalResource(source).toString();
        }

        // resource moved between eclipse projects
        boolean crossEclipseProject = !srcProject.getProject().equals(dstProject.getProject());
        if (!crossProject && !dstProject.isFullWorkArea() && srcProject.getIsStream() && crossEclipseProject
                && (source.getType() == IResource.FOLDER || source.getType() == IResource.FILE)) {
            String movedFromRelRoot = srcProject.getRemoteOffset().toOSString();
            if (Utils.isNullEmpty(getMovedFromRelRoot(sourceMetadata))) {
                setMovedFromRelRoot(sourceMetadata, movedFromRelRoot);
            } else if ((getMovedFromRelRoot(sourceMetadata)).equals(dstProject.getRemoteOffset().toOSString())) {
                setMovedFromRelRoot(sourceMetadata, Utils.EMPTY_STRING);
            }
        }

        if (!returned) {
            Assert.isNotNull(movedFromForRegister);
            workspace.registerMove(destination, movedFromForRegister, movedFromProjectId, movedFromProjectType, connection);
        }

        if (previousMoveInMetadata) {
            workspace.releaseBase(source);
        }
    }

    private void updateMovedResourceMetadata(IDMProject srcProject, IResource source, BaseMetadata sourceMetadata,
            IDMProject dstProject, IResource destination) throws CoreException {
        DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
        DimensionsConnectionDetailsEx connection = dstProject.getConnection();

        int movedToProjectType = dstProject.getType();
        String movedToProjectId = dstProject.getId();

        String oldMovedFrom = getMovedFrom(sourceMetadata);
        boolean fullWorkArea = srcProject.isFullWorkArea();
        boolean previousMoveInMetadata = !Utils.isNullEmpty(oldMovedFrom);
        IResource previouslyCachedMove = workspace.getMovedFrom(source);
        boolean previousMoveCached = previouslyCachedMove != null;
        boolean directMoveOfCascadeMoved = !previousMoveInMetadata && previousMoveCached;
        boolean directMoveOfNotMoved = !previousMoveInMetadata && !previousMoveCached;
        boolean directMoveOfDirectMoved = previousMoveInMetadata && previousMoveCached;
        boolean directMoveOfStrange = previousMoveInMetadata && !previousMoveCached;

        Assert.isTrue(!directMoveOfStrange, "Metadata and move caches should contain the same move information");

        boolean crossProject = false;
        boolean returned = false;
        boolean previouslyCrossMovedInMetadata = false;
        boolean returnedProjectInMetadata = false;
        IPath movedFromPath = null;
        String movedFromForRegister = null; // for registration full repository path
        // for metadata workarea (project if relative wa ) relative path so for full wa is full repository path
        String movedFromForMd = null;
        int movedFromProjectType = 0;
        String movedFromProjectId = null;
        if (directMoveOfCascadeMoved || directMoveOfDirectMoved) {
            IResource origin = workspace.unregisterMove(source);
            if (origin.equals(destination)) {
                returned = true;
            } else {
                IDMProject firstSrcProject = workspace.getProject(origin);
                crossProject = !firstSrcProject.remoteEquals(dstProject, false);

                String firstSrcProjectId = firstSrcProject.getId();
                int firstSrcProjectType = firstSrcProject.getType();
                if (crossProject && !dstProject.getId().equals(firstSrcProjectId)) {
                    movedFromProjectType = firstSrcProjectType;
                    movedFromProjectId = firstSrcProjectId;
                }

                movedFromPath = firstSrcProject.getRemotePathForLocalResource(origin);
                movedFromForRegister = movedFromPath.toString(); // with / e.g repository separator
                if (fullWorkArea) {
                    movedFromForMd = movedFromForRegister;
                } else {
                    movedFromForMd = origin.getProjectRelativePath().toString();
                }

                if (directMoveOfDirectMoved) {
                    int oldMovedFromProjectType = 0;
                    String oldMovedFromProjectId = sourceMetadata.get(FROM_PROJECT);
                    if (!Utils.isNullEmpty(oldMovedFromProjectId)) {
                        oldMovedFromProjectType = IDMProject.WORKSET;
                    } else {
                        oldMovedFromProjectId = sourceMetadata.get(FROM_BASELINE);
                        if (!Utils.isNullEmpty(oldMovedFromProjectId)) {
                            oldMovedFromProjectType = IDMProject.BASELINE;
                        }
                    }
                    previouslyCrossMovedInMetadata = !Utils.isNullEmpty(oldMovedFromProjectId);
                    returnedProjectInMetadata = previouslyCrossMovedInMetadata
                            && oldMovedFromProjectType == movedToProjectType
                            && movedToProjectId.equals(oldMovedFromProjectId);
                }
            }
        } else if (directMoveOfNotMoved) {
            crossProject = !srcProject.remoteEquals(dstProject, false);
            if (crossProject) {
                movedFromProjectType = srcProject.getType();
                movedFromProjectId = srcProject.getId();
            }
            movedFromForRegister = srcProject.getRemotePathForLocalResource(source).toString();
            if (fullWorkArea) {
                movedFromForMd = movedFromForRegister;
            } else {
                movedFromForMd = source.getProjectRelativePath().toString();
            }
        }

        // resource moved between eclipse projects
        boolean crossEclipseProject = !srcProject.getProject().equals(dstProject.getProject());
        if (returned) { // if file is returned to its original location discard all move info
            discardMovedState(sourceMetadata);
        } else if (returnedProjectInMetadata) {
            // if file is returned to the original project discard project move info but keep the path
            sourceMetadata.put(FROM_PROJECT, Utils.EMPTY_STRING);
            sourceMetadata.put(FROM_BASELINE, Utils.EMPTY_STRING);
        } else if (previousMoveInMetadata && crossProject && !previouslyCrossMovedInMetadata) {
            // if 1st time cross move an already moved file set project
            String key = movedFromProjectType == IDMProject.WORKSET ? FROM_PROJECT : FROM_BASELINE;
            sourceMetadata.put(key, movedFromProjectId);
        } else if (!previousMoveInMetadata) { // preserve original move information
            setMovedFrom(sourceMetadata, movedFromForMd);
            if (crossProject) {
                String key = movedFromProjectType == IDMProject.WORKSET ? FROM_PROJECT : FROM_BASELINE;
                sourceMetadata.put(key, movedFromProjectId);
            }
        }

        // check if we move between eclipse projects now
        if (!crossProject && crossEclipseProject && !dstProject.isFullWorkArea()
                && (source.getType() == IResource.FOLDER || source.getType() == IResource.FILE)) {
            if (Utils.isNullEmpty(getMovedFromRelRoot(sourceMetadata))) {
                String movedFromRelRoot = srcProject.getRemoteOffset().toOSString();
                setMovedFromRelRoot(sourceMetadata, movedFromRelRoot);
            } else if ((getMovedFromRelRoot(sourceMetadata)).equals(dstProject.getRemoteOffset().toOSString())) {
                setMovedFromRelRoot(sourceMetadata, Utils.EMPTY_STRING);
            }
        }

        if (!returned) {
            Assert.isNotNull(movedFromForRegister);
            workspace.registerMove(destination, movedFromForRegister, movedFromProjectId, movedFromProjectType, connection);
        }

        if (previousMoveInMetadata) {
            workspace.releaseBase(source); // release transient metadata cache entry
        }
    }

    static boolean discardMovedState(BaseMetadata metadata) {
        boolean hasMoveState = !Utils.isNullEmpty(getMovedFrom(metadata)) || !Utils.isNullEmpty(metadata.get(FROM_PROJECT))
                || !Utils.isNullEmpty(metadata.get(FROM_BASELINE));
        if (hasMoveState) {
            setMovedFrom(metadata, Utils.EMPTY_STRING);
            metadata.put(FROM_PROJECT, Utils.EMPTY_STRING);
            metadata.put(FROM_BASELINE, Utils.EMPTY_STRING);
        }
        return hasMoveState;
    }

    static String getMovedFrom(BaseMetadata metadata) {
        if (metadata instanceof ItemMetadata) {
            return ((ItemMetadata) metadata).getMovedFrom();
        }
        return ((DirectoryMetadata) metadata).getMovedFrom();
    }

    static void setMovedFrom(BaseMetadata sourceMetadata, String s) {
        if (sourceMetadata instanceof ItemMetadata) {
            ((ItemMetadata) sourceMetadata).setMovedFrom(s);
        } else {
            ((DirectoryMetadata) sourceMetadata).setMovedFrom(s);
        }
    }

    static String getMovedFromRelRoot(BaseMetadata metadata) {
        if (metadata instanceof ItemDirMetadata) {
            return ((ItemDirMetadata) metadata).getMovedFromRelRoot();
        }
        return null;
    }

    static void setMovedFromRelRoot(BaseMetadata sourceMetadata, String s) {
        if (sourceMetadata instanceof ItemDirMetadata) {
            ((ItemDirMetadata) sourceMetadata).setMovedFromRelRoot(s);
        }
    }

    public boolean validateMoveStatus(IProject project, boolean deep) {
        IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
        try {
            IDMWorkspaceFolder dmProjectFolder = (IDMWorkspaceFolder) workspace.getWorkspaceResource(project);
            return !dmProjectFolder.containsMoved(deep);
        } catch (CoreException e) {
            DMTeamPlugin.log(e.getStatus());
        }
        return false;
    }

    private void displayWarning(String message) {
        displayWarning(false, message);
    }

    private void displayWarning(boolean async, final String message) {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                MessageDialog.openWarning(null, Messages.MessageDialog_warningTitle, message);
            }
        };
        if (async) {
            Display.getDefault().asyncExec(runnable);
        } else {
            Display.getDefault().syncExec(runnable);
        }
    }
    
	private String getParentSpec(IDMProject srcProject) throws DMException {
		Object parentSpec = srcProject.getDimensionsObject().getAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
		if (parentSpec == null) {
			srcProject.getDimensionsObject().queryAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
			parentSpec = srcProject.getDimensionsObject().getAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
		}
		return (String) parentSpec;
	}
}

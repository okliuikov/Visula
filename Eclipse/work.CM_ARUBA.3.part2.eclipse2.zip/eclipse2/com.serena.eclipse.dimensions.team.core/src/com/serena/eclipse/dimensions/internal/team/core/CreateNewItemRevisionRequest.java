/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2006 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;

import com.serena.dmclient.api.ItemRevisionDetails;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public abstract class CreateNewItemRevisionRequest extends CMRulesSensitiveRequest implements IUploadRequestParameters {

    private ItemRevisionDetails newRevisionDetails;
    private boolean readOnly = true;

    public CreateNewItemRevisionRequest(IFile file, ItemType itemType, int cmRuleDetails, boolean requestRequired,
            boolean anyRequest) throws CoreException {
        super(file, itemType, cmRuleDetails, requestRequired, anyRequest);
    }

    /**
     * @return Returns the newRevisionDetails.
     */
    public ItemRevisionDetails getNewRevisionDetails() {
        if (newRevisionDetails == null) {
            newRevisionDetails = new ItemRevisionDetails();
        }
        return newRevisionDetails;
    }

    /**
     * @param newRevisionDetails The newRevisionDetails to set.
     */
    public void setNewRevisionDetails(ItemRevisionDetails newRevisionDetails) {
        this.newRevisionDetails = newRevisionDetails;
    }

    @Override
    public void addChangeRequest(String id) {
        List<String> changeReqs = getChangeRequests(true);
        if (!changeReqs.contains(id)) {
            changeReqs.add(id);
        }
    }

    @Override
    public void clearChangeRequests() {
        getChangeRequests(false).clear();
    }

    @Override
    public List<String> getChangeRequests() {
        if (getConnection().isIdmRequestProvider()) {
            return super.getChangeRequests();
        }
        return getChangeRequests(true);
    }

    @Override
    public void removeChangeRequest(String id) {
        getChangeRequests(false).remove(id);
    }

    @SuppressWarnings("unchecked")
    private List<String> getChangeRequests(boolean create) {
        List<String> changeReqs = getNewRevisionDetails().getRelatedRequests();
        if (changeReqs == null) {
            if (create) {
                changeReqs = new ArrayList<String>(5);
                newRevisionDetails.setRelatedRequests(changeReqs);
            } else {
                changeReqs = Collections.emptyList();
            }
        }
        return changeReqs;
    }

    // upload parameters delegation
    @Override
    public int[] getAttributes() {
        Map<?, ?> map = getNewRevisionDetails().getAttributeMap();
        ArrayList<Integer> userAttrs = new ArrayList<Integer>();
        for (Iterator<?> iter = map.keySet().iterator(); iter.hasNext();) {
            Integer attr = (Integer) iter.next();
            if (Utils.isUserAttribute(attr.intValue())) {
                userAttrs.add(attr);
            }
        }
        int[] result = new int[userAttrs.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = userAttrs.get(i).intValue();
        }
        return result;
    }

    @Override
    public Object getAttribute(int attrNum) {
        return getNewRevisionDetails().getAttribute(attrNum);
    }

    @Override
    public String getComment() {
        return getNewRevisionDetails().getComment();
    }

    @Override
    public void setComment(String comment) {
        getNewRevisionDetails().setComment(comment);
    }

    @Override
    public void setAttributes(int[] attrs) {
        // nothing to do - new revision details should only have the attributes to be set on the new revision
    }

    @Override
    public String getDescription() {
        return getNewRevisionDetails().getDescription();
    }

    @Override
    public String getPart() {
        return getNewRevisionDetails().getOwningPartSpecification();
    }

    @Override
    public List<String> getRelatedRequests() {
        if (getConnection().isIdmRequestProvider()) { 
            return super.getChangeRequests();
        }
        return getNewRevisionDetails().getRelatedRequests();
    }

    @Override
    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }

    @Override
    public boolean isReadOnly() {
        return readOnly;
    }

    @Override
    public String getCharset() {
        return DMTeamPlugin.getDefault().getCharset(getFile());
    }

}

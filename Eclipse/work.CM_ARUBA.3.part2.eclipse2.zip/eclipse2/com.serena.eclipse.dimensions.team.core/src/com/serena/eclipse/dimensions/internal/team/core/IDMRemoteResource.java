/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.IPath;
import org.eclipse.team.core.variants.IResourceVariant;

/**
 * Dimensions resource reperesenting base or tip revision.
 *
 * @author V.Grishchenko
 */
public interface IDMRemoteResource extends IDMResource, IResourceVariant {
    /** remote resource of type file */
    byte FILE = 1;
    /** remote resource of type folder */
    byte FOLDER = 2;

    IDMRemoteTree getRemoteTree();

    /** the remote relative path */
    IPath getPath();

    /** returns <code>true</code> if resource is moved, <code>false</code> otherwise */
    public boolean isMoved();

    /** path this resource is moved from or <code>null</code> if none, base resource only */
    String getMovedFromPath();

    /** id of dimensions project or baseline this resource is moved from or <code>null</code> if none */
    String getMovedFromProject();

    /** <code>IDMProject.WORKSET</code> or <code>IDMProject.BASELINE</code> */
    int getMovedFromProjectType();

    /** <code>FILE</code> or <code>FOLDER</code> */
    byte getType();

    /** answers if this resource is not up to date, applies to base resources only */
    boolean isStale();

    /** marks this remote resource as stale */
    void markStale();

}

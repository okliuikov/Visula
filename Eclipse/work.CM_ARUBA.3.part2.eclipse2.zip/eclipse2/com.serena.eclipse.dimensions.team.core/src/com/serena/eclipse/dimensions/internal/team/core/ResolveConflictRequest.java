/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.util.Collections;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ILock;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Runs UEI for extracted files or replaces local metadata with metadata
 * corresponding to remote revision.
 * @author V.Grishchenko
 */
public class ResolveConflictRequest extends SimpleItemRevisionRequest {
    private boolean checkoutUpdated = false;
    private IStatus status = Status.OK_STATUS;

    /**
     * @param file
     * @param itemRevision
     * @throws CoreException
     */
    public ResolveConflictRequest(IFile file, ItemRevision itemRevision) throws CoreException {
        super(file, itemRevision);
    }

    @Override
    public int getKind() {
        return MODIFY;
    }

    boolean isCheckoutUpdated() {
        return checkoutUpdated;
    }

    @Override
    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            IFile local = getFile();
            ItemRevision newBase = getItemRevision();
            IDMRemoteFile base = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
            DimensionsResult result = null;
            if (base != null && base.isExtracted()) {
                ItemRevision baseRevision = base.getItemRevision();
                // have to detect if tip changed on the client
                DMTeamPlugin.getWorkspace().getSubscriber().refresh(new IResource[] { local }, IResource.DEPTH_INFINITE, null);
                IDMRemoteFile tip = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getRemoteResource(local);
                if (tip != null) {
                    Utils.queryAttributes(Collections.singletonList(newBase), DMRemoteFile.RESOURCE_VARIANT_ATTRS_FILE,
                            _session.getObjectFactory(), true);
                    IDMRemoteFile newBaseVariant = TeamUtils.getVariants(_session.getConnectionDetails(),
                            new ItemRevision[] { newBase }, Utils.subMonitorFor(monitor, 1))[0];
                    if (tip.equals(newBaseVariant)) {
                        String newRevision;
                        ILock changeCurrentProjectLock = getConnection().getChangeDefaultProjectLock();
                        try {
                            changeCurrentProjectLock.acquire();
                            _session.getObjectFactory().setCurrentProject(tip.getProject().getId(), false, null, null, null, true);
                            String[] branchAndRev = tip.getItemRevision().getNextRevision(null);
                            if (!Utils.isNullEmpty(branchAndRev[0])) {
                                newRevision = branchAndRev[0] + '#' + branchAndRev[1];
                            } else {
                                newRevision = branchAndRev[1];
                            }
                        } finally {
                            changeCurrentProjectLock.release();
                        }

                        result = baseRevision.updateExtractedRevision(local.getLocation().toOSString(), newRevision);
                        checkoutUpdated = true;
                    } else {
                        status = new SyncStatus(local, getKind(local), NLS.bind(Messages.ResolveConflictRequest_tipChanged,
                                new Object[] { local.getFullPath().toString(), tip.getItemSpec(), newBaseVariant.getItemSpec() }));
                    }
                } else {
                    status = new SyncStatus(local, getKind(local), NLS.bind(Messages.ResolveConflictRequest_noRemote,
                            local.getFullPath().toString()));
                }
            } else { // either optimistic mode or conflicting add - copy meta
                File temp = TeamUtils.getTempCopy(local, newBase, _session.getConnectionDetails());
                BaseMetadata oldMetadata = WorkspaceMetadataManager.getInstance().getMetadata(local);
                BaseMetadata metadata = WorkspaceMetadataManager.getLfsMetadata(temp);
                if (metadata != null) {
                    if (oldMetadata != null && oldMetadata instanceof ItemMetadata && metadata instanceof ItemMetadata) {
                        ItemMetadata itemMD = (ItemMetadata) metadata;
                        ItemMetadata itemMD_OLD = (ItemMetadata) oldMetadata;
                        itemMD.setProject(itemMD_OLD.getProject());
                        itemMD.setProjectUid(itemMD_OLD.getProjectUid());
                        itemMD.setRelPath(itemMD_OLD.getRelPath());
                    }
                    TeamUtils.ensureReacheable(local.getParent(), false);
                    WorkspaceMetadataManager.getInstance().updateMetadata(local, metadata);
                }
            }
            return result == null ? new DimensionsResult(status.getMessage()) : result;
        } finally {
            monitor.done();
        }
    }

    IStatus getStatus() {
        return status;
    }

    private int getKind(IResource local) throws TeamException {
        SyncInfo syncInfo = DMTeamPlugin.getWorkspace().getSubscriber().getSyncInfo(local);
        if (syncInfo == null) {
            return SyncInfo.CONFLICTING;
        }
        return syncInfo.getKind();
    }

}

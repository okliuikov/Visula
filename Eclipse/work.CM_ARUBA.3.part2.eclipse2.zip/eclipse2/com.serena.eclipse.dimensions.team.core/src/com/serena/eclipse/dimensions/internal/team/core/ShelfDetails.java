package com.serena.eclipse.dimensions.internal.team.core;

import com.serena.dmclient.api.ProjectDetails;

public class ShelfDetails extends ProjectDetails {

    private boolean isFavourite;
    private boolean isReset;

    public ShelfDetails(String product, String name, String description, String typeName, boolean flagIsStream) {
        super(product, name, description, typeName, flagIsStream);
    }

    /**
     * @return the isFavourite
     */
    public boolean isFavourite() {
        return isFavourite;
    }

    /**
     * @param isFavourite the isFavourite to set
     */
    public void setFavourite(boolean isFavourite) {
        this.isFavourite = isFavourite;
    }

    /**
     * @return the isReset
     */
    public boolean isReset() {
        return isReset;
    }

    /**
     * @param isReset the isReset to set
     */
    public void setReset(boolean isReset) {
        this.isReset = isReset;
    }

}

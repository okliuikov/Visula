/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.SortedSet;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantComparator;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Workspace subscriber specific sync info.
 *
 * @author V.Grishchenko
 */
public class DMWorkspaceSyncInfo extends DMSyncInfo {

    public static final QualifiedName KEY_SYNC_REMOTE_METADATA = new QualifiedName("com.serena.eclipse.dimensions.team.core",
            "sync.remote.metadata");
    public static final QualifiedName KEY_SYNC_REPOSITORY_MOVE = new QualifiedName("com.serena.eclipse.dimensions.team.core",
            "sync.repository.move");
    public static final QualifiedName KEY_SYNC_REPOSITORY_MOVE_AND_LOCAL_HAVE_COMMON_ANCESTOR = new QualifiedName(
            "com.serena.eclipse.dimensions.team.core", "repository_move_and_local_have_common_ancestor");

    static final int NOT_VALID_SYNC_KIND = -1;
    static boolean debug = DMTeamPlugin.getDefault().isDebuggingSyncState();

    public DMWorkspaceSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote,
            IResourceVariantComparator comparator, Subscriber subscriber, DimensionsConnectionDetailsEx connection) {
        super(local, base, remote, comparator, subscriber, connection);
    }

    /**
     * considers moved resources in calculations
     */
    @Override
    protected int calculateKind() throws TeamException {
        IResource local = getLocal();
        if (debug) {
            System.out.println("dwssi ck " + local.toString());
        }

        DMProject dmProject;
        try {
            dmProject = TeamUtils.getDmProject(local);
            local = TeamUtils.getResource(local);
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        int retval = 0;
        boolean returned = false;
        // change implementation to allow returns to be logged
        do {
            // return verified foreign update status because it has more priority
            int kind = ((DMWorkspace) DMTeamPlugin.getWorkspace()).getForeignUpdateSyncKind(local);
            if (debug) {
                System.out.println("dwssi ck.fusk kind = " + kind);
            }
            if (kind != NOT_VALID_SYNC_KIND) {
                if (kind == (CONFLICTING | CHANGE) || kind == (CONFLICTING | ADDITION) || kind == (CONFLICTING | DELETION)
                        || kind == (OUTGOING | ADDITION) || kind == (INCOMING | ADDITION)) {
                    try {
                        // ignore merged and registered inc additions (remote parts of rename/moves)
                        if (isMergedFromForeignStream(local)
                                || ((DMWorkspace) DMTeamPlugin.getWorkspace()).isMovedInRepoMerged(local)) {
                            if (debug) {
                                System.out.println("dwssi ck merged foreign or moved in repo merged");
                            }
                            retval = IN_SYNC;
                            returned = true;
                            break;
                        }
                    } catch (CoreException e) {
                        DMPlugin.log(e.getStatus());
                    }
                }
                retval = kind;
                returned = true;
                break;
            }

            if (local != null) {
                IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
                if (workspace.isManaged(getLocal())) {
                    if (debug) {
                        System.out.println("dwssi ck local managed");
                    }
                    // An aborted offline merge by DM command line client (SVN like client) could leave files (names ending with
                    // ".cm.latest" and ".cm.ancestor") in the workspace which should not be shown to the user.
                    // If the "conflict-file" tag in the metadata of these files has any value other than -- merged-uid-xxxx ,
                    // accepted-repository , accepted-local -- then
                    // these files should not be shown to the user.
                    if (TeamUtils.ignoreResourceLeftByDMCommandLineClient(local)) {
                        retval = IN_SYNC;
                        returned = true;
                        break;
                    }

                    IDMRemoteResource base = workspace.getBaseResource(local);
                    IResourceVariant remote = getRemote();
                    try {
                        if ((remote == null) && (base.isMoved() || workspace.getMovedFrom(local) != null)) {
                            // check movedDstSrc cache only because new-name resource is the key for this
                            // cache(filter old-name)
                            if (debug) {
                                System.out.println("dwssi ck local null base.isMoved && remote null");
                            }
                            retval = OUTGOING | ADDITION;
                            returned = true;
                            break;
                        }
                    } catch (CoreException e1) {
                        throw TeamException.asTeamException(e1);
                    }
                    if (local.getType() != IResource.FILE && getRemote() == null) {
                        try {
                            IDMWorkspaceFolder dmFolder = (IDMWorkspaceFolder) workspace.getWorkspaceResource(local);
                            if (dmFolder != null && dmFolder.containsMoved(true)) {
                                if (debug) {
                                    System.out.println("dwssi ck !FILE remote null, contains moved");
                                }
                                retval = OUTGOING | ADDITION;
                                returned = true;
                                break;
                            }
                            if (dmFolder != null && dmFolder.isModified()) {
                                if (isSpecialCaseOfFolderAndFileDeletion(local)) {
                                    if (debug) {
                                        System.out.println("dwssi ck fold modified and isspecialcase");
                                    }
                                    retval = IN_SYNC;
                                    returned = true;
                                    break;
                                }
                                retval = CONFLICTING | CHANGE; // play safe
                                returned = true;
                                break;
                            }
                        } catch (CoreException e) {
                            throw TeamException.asTeamException(e);
                        }
                    }
                    if (dmProject != null && TeamUtils.isResourceFromForeignStream(local)) {
                        if (debug) {
                            System.out.println("dwssi ck and isForeign - dkfc");
                        }
                        retval = deriveKindForForeignContent(local, dmProject);
                        returned = true;
                        break;
                    }
                    if (local.getType() == IResource.FILE && !local.exists() && getRemote() == null) {
                        try {
                            if ((TeamUtils.isLocalWorksetPointingToForeignStream(local)
                                    || TeamUtils.isLocalWorksetPointingToForeignProject(local))
                                    && super.calculateKind() == (CONFLICTING | DELETION | PSEUDO_CONFLICT)) {
                                // Refer to the use case mentioned in the method comment for the method
                                // isSpecialCaseOfFolderAndFileDeletion(IResource) in this java file. If a folder and a file in it
                                // is involved in the use case, then once you do the Override and Update,
                                // in the sync view the file and folder will be shown as having conflicts instead of disappearing
                                // from the sync view.
                                retval = IN_SYNC;
                                returned = true;
                                break;
                            }
                        } catch (CoreException ce) {
                            throw TeamException.asTeamException(ce);
                        }
                    }
                } else {
                    // not managed
                    try {
                        // ignore registered remote parts of rename/moves
                        if (((DMWorkspace) DMTeamPlugin.getWorkspace()).isMovedInRepoMerged(local)) {
                            if (debug) {
                                System.out.println("ignore registered remote parts of rename/moves");
                            }
                            retval = IN_SYNC;
                            returned = true;
                            break;
                        }
                    } catch (CoreException e) {
                        DMPlugin.log(e.getStatus());
                    }
                }
            }
        } while (false);
        if (!returned) {
            retval = getSyncKind();
        }
        if (debug) {
            System.out.println("dmwwsi ck = " + SyncInfo.kindToString(retval));
        }
        return retval;
    }

    private int getSyncKind() throws TeamException {
        int sync = super.calculateKind();
        if (debug) {
            System.out.println("dmwssi gsk super.ck = " + SyncInfo.kindToString(sync));
        }
        boolean returned = false;
        int retval = 0;
        do {
            try {
                if (DMTeamPlugin.getWorkspace().getWorkspaceResource(getLocal()) instanceof IDMWorkspaceFile) {
                    IDMWorkspaceFile localFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(getLocal());
                    if (TeamUtils.isConsiderContentsForComparison()) {
                        if (sync == (CONFLICTING | CHANGE) || sync == (CONFLICTING | ADDITION)
                                || sync == (CONFLICTING | ADDITION | PSEUDO_CONFLICT) || sync == (INCOMING | CHANGE)
                                || sync == (OUTGOING | CHANGE)) {
                            DMRemoteFile remoteFile = (DMRemoteFile) localFile.getRemoteFile();
                            if (TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {

                                retval = IN_SYNC;
                                returned = true;
                                break;
                            }
                        }
                    }
                    if (TeamUtils.isLocalWorksetPointingToForeignStream(localFile.getLocalResource())) {
                        // If a conflict was "Marked as Merged" against a foreign Stream then we should not show this file against
                        // that Stream.
                        // Outgoing change is included in the if clause below because if you "mark as merged" a conflicting
                        // addition (of which local file is unmanaged) it will show as an outgoing change
                        if (sync == (CONFLICTING | CHANGE) || sync == (CONFLICTING | ADDITION)
                                || sync == (CONFLICTING | ADDITION | PSEUDO_CONFLICT) || sync == (OUTGOING | CHANGE)
                                || sync == (OUTGOING | DELETION)) {
                            if (isMergedFromForeignStream(localFile.getLocalResource())) {
                                if (debug) {
                                    System.out.println("dmwwsi gsk merged fs");
                                }
                                retval = IN_SYNC;
                                returned = true;
                                break;
                            }
                        }
                    }
                } else
                    if (getLocal().getType() == IResource.FOLDER && !TeamUtils.isLocalWorksetPointingToForeignStream(getLocal())) {
                    BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(getLocal());
                    if (metadata != null) {
                        String foreignItemDeletionTagValue = metadata.get(TeamUtils.METADATA_OF_DELETED_FOREIGN_RESOURCE);
                        if (foreignItemDeletionTagValue != null && foreignItemDeletionTagValue.equals("yes")) {
                            retval = OUTGOING | DELETION;
                            returned = true;
                            break;
                        }
                    }
                }
            } catch (CoreException e) {
                DMPlugin.log(e.getStatus());
            }
        } while (false);
        if (!returned) {
            retval = sync;
        }
        if (debug) {
            System.out.println("dmwwsi gsk = " + SyncInfo.kindToString(retval));
        }
        return retval;
    }

    private int deriveKindForForeignFolder(IResource local, DMProject dmProject) throws TeamException {
        try {
            IDMWorkspaceFolder localFolder = (IDMWorkspaceFolder) DMTeamPlugin.getWorkspace().getWorkspaceResource(local);
            DMRemoteFolder remoteFolder = null;
            if (localFolder != null) {
                remoteFolder = (DMRemoteFolder) localFolder.getRemoteFolder();
            }
            if (TeamUtils.isSpecialCaseOfFolderAndFileDeletion(local, false)) {
                // if the folder was deleted as inc del from foreign and ws is home now
                return OUTGOING | DELETION;
            }
            if (isSpecialCaseOfFolderAndFileDeletion(local)) {
                return IN_SYNC;
            }
            if (remoteFolder == null && dmProject.isBaseline()) {
                return INCOMING | DELETION;
            }
            if (remoteFolder == null) {
                return OUTGOING | ADDITION;
            }
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
        return super.calculateKind();
    }

    private int deriveKindForForeignContent(IResource local, DMProject dmProject) throws TeamException {
        int retval = 0;
        boolean returned = false;

        do {
            try {
                if (local.getType() == IResource.FOLDER) {
                    if (debug) {
                        System.out.println("dkfc - folder");
                    }
                    retval = deriveKindForForeignFolder(local, dmProject);
                    returned = true;
                    break;
                }

                IDMWorkspaceFile localFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(local);
                DMRemoteFile remoteFile = null;
                if (localFile != null) {
                    remoteFile = (DMRemoteFile) localFile.getRemoteFile();
                }
                ItemMetadata localMetadata = (ItemMetadata) WorkspaceMetadataManager.getInstance().getMetadata(local);
                if (remoteFile == null) {
                    if (isSpecialCaseOfFolderAndFileDeletion(local)) {
                        retval = IN_SYNC;
                        returned = true;
                        break;
                    }
                    if (isMergedFromForeignStream(local)) {
                        retval = IN_SYNC;
                        returned = true;
                        break;
                    }

                    if (!local.exists()) {
                        break;
                    }

                    Object obj = local.getSessionProperty(KEY_SYNC_REPOSITORY_MOVE);
                    Object obj1 = local.getSessionProperty(KEY_SYNC_REPOSITORY_MOVE_AND_LOCAL_HAVE_COMMON_ANCESTOR);
                    if ((obj instanceof Boolean && ((Boolean) obj).booleanValue()) || dmProject.isBaseline()) {
                        if (super.calculateKind() == (CONFLICTING | CHANGE)
                                || (obj1 != null && obj1 instanceof Boolean && ((Boolean) obj1).booleanValue())) {
                            // Local file is modified and hence we need to show it as a conflicting change
                            retval = CONFLICTING | CHANGE;
                            returned = true;
                            break;
                        } else {
                            retval = INCOMING | DELETION;
                            returned = true;
                            break;
                        }
                    }
                    retval = OUTGOING | ADDITION;
                    returned = true;
                    break;
                }
                if (localMetadata == null) {
                    retval = INCOMING | CHANGE;
                    returned = true;
                    break;
                }

                if (!remoteFile.exists()) {
                    retval = OUTGOING | ADDITION;
                    returned = true;
                    break;
                } else {// Remote file exists in repository

                    if (!local.exists()) {
                        break;
                    }

                    ItemMetadata remoteMetadata = remoteFile.getMetadata();
                    ItemMetadata syncMetadata = (ItemMetadata) local.getSessionProperty(KEY_SYNC_REMOTE_METADATA);
                    if (syncMetadata == null) { // do double-check
                        ((DMWorkspace) DMTeamPlugin.getWorkspace()).queryContentStatus(new IResource[] { local.getProject() },
                                IResource.DEPTH_INFINITE, null, new NullProgressMonitor());
                        syncMetadata = (ItemMetadata) local.getSessionProperty(KEY_SYNC_REMOTE_METADATA);
                    }
                    if (syncMetadata != null && localMetadata.getItemUid() != remoteMetadata.getItemUid()) {
                        // diff type is a metadata item status, '1' means that item is absent in current project but exists in
                        // generic global so file was imported
                        if (syncMetadata.getDiffType() == 1) {
                            if (localFile.isModified()) {
                                if (TeamUtils.isConsiderContentsForComparison()
                                        && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                    retval = IN_SYNC;
                                    returned = true;
                                    break;
                                }
                                if (isMergedFromForeignStream(localFile.getLocalResource())) {
                                    retval = IN_SYNC;
                                    returned = true;
                                    break;
                                }
                                if (TeamUtils.hasReplaceWithRepositoryMetadata(localFile.getLocalResource())) {
                                    retval = OUTGOING | ADDITION;
                                    returned = true;
                                    break;
                                }

                                if (TeamUtils.isLocalWorksetAStream(local) != null) {
                                    // for streams conflict has been resolved already by merge operation
                                    // but if item has been changed in the repository we would show it as a conflict
                                    if (syncMetadata.getItemUid() == remoteMetadata.getItemUid()) {
                                        // Asset is common ancestor (changed locally)

                                        // We can be confident that this should be seen as a non-conflicting change
                                        retval = OUTGOING | CHANGE;
                                    } else {
                                        retval = CONFLICTING | CHANGE;
                                    }
                                } else {
                                    // for projects this is a conflict by default because user resolves it using mark as merged
                                    retval = CONFLICTING | CHANGE;
                                }

                                returned = true;
                                break;
                            } else {
                                // The local file is unchanged but was fetched from a different
                                // workset. The workset file is initially detected as a
                                // modification as the item does not precisely match that
                                // specified within the metadata.
                                if (syncMetadata.getItemUid() == localMetadata.getItemUid()) {
                                    // Metadata is common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // We can be certain that this should be seen as a
                                    // non-foreign non-conflicting workset modification.
                                    retval = INCOMING | CHANGE;
                                    returned = true;
                                    break;
                                } else if (syncMetadata.getItemUid() == remoteMetadata.getItemUid()) {
                                    // Asset is common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // We can be confident that this should be seen as a
                                    // non-conflicting outgoing local item revision import.
                                    // >KB changed with OUTGOING CHANGE
                                    retval = OUTGOING | CHANGE;
                                    returned = true;
                                    break;
                                } else if (syncMetadata.getItemUid() == -1) {
                                    // no common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }

                                    if (isMergedFromForeignStream(localFile.getLocalResource())) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }

                                    if (TeamUtils.hasReplaceWithRepositoryMetadata(localFile.getLocalResource())) {
                                        retval = OUTGOING | ADDITION;
                                        returned = true;
                                        break;
                                    }

                                    // if they do not descend from a common ancestor:
                                    // Assuming the item specified in metadata is not elsewhere in the workset (i.e. moved),
                                    // we can report that this is an addition conflict where the item they fetched conflicts with
                                    // the one currently in the workset.
                                    retval = CONFLICTING | ADDITION;
                                    returned = true;
                                    break;
                                } else {
                                    // Has a true common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }

                                    if (isMergedFromForeignStream(localFile.getLocalResource())) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // If both items descend from another common ancestor:
                                    // We can report this as a modification conflict as we have detected a branch in the item
                                    // pedigree.
                                    // Since the local copy hasn't really been modified, we should be really clear in the detail as
                                    // to why we are marking it as a conflict and that it would be desirable to merge when fetching
                                    // the latest item revision. However, the user would be free to 'Use Repository' or 'Use Local'
                                    // at their discretion.
                                    retval = CONFLICTING | CHANGE; // play safe
                                    returned = true;
                                    break;
                                }
                            }
                        } else if (syncMetadata.getDiffType() == 2) {
                            // diff type is a metadata item status, '2' means that item exists in current project
                            if (localFile.isModified()) {
                                // The local file has been modified and was fetched from a
                                // different workset. The workset file is also initially
                                // detected as a modification as the item does not precisely
                                // match that specified within the metadata. This defines the
                                // file as a modification conflict.
                                if (syncMetadata.getItemUid() == remoteMetadata.getItemUid()) {
                                    // Asset is common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // We can be confident that this should be seen as a
                                    // non-conflicting local modification.
                                    retval = OUTGOING | CHANGE;
                                    returned = true;
                                    break;
                                } else if (syncMetadata.getItemUid() == localMetadata.getItemUid()) {
                                    // Metadata is common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    if (isMergedFromForeignStream(localFile.getLocalResource())) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // We can be certain that this should be seen as a
                                    // modification conflict.
                                    retval = CONFLICTING | CHANGE; // play safe
                                    returned = true;
                                    break;
                                } else {
                                    // Has a true common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    if (isMergedFromForeignStream(localFile.getLocalResource())) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // We can report this as a modification conflict as we have
                                    // detected a branch in the item pedigree.
                                    retval = CONFLICTING | CHANGE; // play safe
                                    returned = true;
                                    break;
                                }

                            } else {
                                // The local file is unchanged but was fetched from a different
                                // workset. The workset file is initially detected as a
                                // modification as the item does not precisely match that
                                // specified within the metadata.
                                if (syncMetadata.getItemUid() == remoteMetadata.getItemUid()) {
                                    // Asset is common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // We can be confident that this should be seen as a
                                    // non-conflicting outgoing local item revision import.
                                    retval = OUTGOING | CHANGE;
                                    returned = true;
                                    break;
                                } else if (syncMetadata.getItemUid() == localMetadata.getItemUid()) {
                                    // Metadata is common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }
                                    // We can be certain that this should be seen as a
                                    // non-foreign non-conflicting workset modification.
                                    retval = INCOMING | CHANGE;
                                    returned = true;
                                    break;
                                } else {
                                    // Has a true common ancestor
                                    if (TeamUtils.isConsiderContentsForComparison()
                                            && TeamUtils.areContentsEqual(localFile.getLocalResource(), remoteFile)) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }

                                    if (isMergedFromForeignStream(localFile.getLocalResource())) {
                                        retval = IN_SYNC;
                                        returned = true;
                                        break;
                                    }

                                    // XXX - Floz: TODO - custom detail text
                                    // We can report this as a modification conflict as we have
                                    // detected a branch in the item pedigree. Since the local
                                    // copy hasn't really been modified, we should be really
                                    // clear in the detail as to why we are marking it as a
                                    // conflict and that it would be desirable to merge when
                                    // fetching the latest item revision. However, the user
                                    // would be free to 'Use Repository' or 'Use Local' at
                                    // their discretion.
                                    retval = CONFLICTING | CHANGE; // play safe
                                    returned = true;
                                    break;
                                }
                            }
                        } else {
                            // item revision no longer exists in repository
                            // do nothing ???
                        }
                    }
                }
            } catch (CoreException ce) {
                DMPlugin.log(ce.getStatus());
            }
        } while (false);
        if (!returned) {
            retval = getSyncKind();
        }
        if (debug) {
            System.out.println("dmwwsi dkfc = " + SyncInfo.kindToString(retval));
        }
        return retval;
    }

    /**
     * This method checks whether the resource falls under the following use case.
     * The use case is as follows:
     * A file has been deleted ( file alone or along with its parent folder ) from a Child Stream. Now you want to apply this
     * deletion back to Parent Stream.
     * As per the best practices you will update your local workspace with the contents from Parent Stream.Then you switch your
     * workspace to
     * Child Stream and do a sync. The deleted file will be shown as an outgoing addition. Do an Override and Update to delete the
     * file
     * on disk.Under normal situation the metadata is deleted along with the file/folder. We do not delete the metadata as this
     * will result in the file deletion being shown as incoming addition instead of an outgoing deletion when you switch back to
     * Parent Stream and do a sync. But at the same time the presence of metadata will cause another problem, ie, if we do a resync
     * with the Child Stream this deleted file/folder will be shown as
     * an outgoing deletion due to the presence of metadata.In order to get around this issue we add
     * "metadata-of-deleted-foreign-resource=yes"
     * tag to the metadata ,which is used not to show the file in sync view when you do a resync with the Child Stream
     *
     * @param resource
     * @return
     * @throws CoreException
     */

    private boolean isSpecialCaseOfFolderAndFileDeletion(IResource resource) throws CoreException {
        return TeamUtils.isSpecialCaseOfFolderAndFileDeletion(resource, true);
    }

    /**
     * This method checks whether resource was "Marked as Merged" against the remote Stream.
     *
     * @param resource
     * @return
     * @throws CoreException
     */
    public static boolean isMergedFromForeignStream(IResource resource) throws CoreException {
        boolean retval = false;
        if (TeamUtils.isLocalWorksetPointingToForeignStream(resource)) {
            BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
            String mergedFromForeignStreamTagValue = null;
            String remoteStreamName = DMTeamPlugin.getWorkspace().getRemoteResource(resource.getProject()).getProject().getId();

            if (metadata != null) {
                mergedFromForeignStreamTagValue = metadata.get(TeamUtils.MERGED_FROM_FOREIGN_STREAM);
                if (mergedFromForeignStreamTagValue != null) {
                    SortedSet<String> mergedFromStreams = TeamUtils.parseRevisionList(mergedFromForeignStreamTagValue);
                    if (!mergedFromStreams.isEmpty() && mergedFromStreams.contains(remoteStreamName)) {
                        retval = true;
                    }
                }
            }
        }
        if (debug) {
            System.out.println("ismffs " + resource.toString() + " " + retval);
        }
        return retval;
    }

}

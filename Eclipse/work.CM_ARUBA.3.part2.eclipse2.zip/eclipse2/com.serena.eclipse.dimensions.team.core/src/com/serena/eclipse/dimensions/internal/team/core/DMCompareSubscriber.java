/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.core.variants.IResourceVariantTree;
import org.eclipse.team.core.variants.ResourceVariantByteStore;
import org.eclipse.team.core.variants.SessionResourceVariantByteStore;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Subscriber that handles 2-way compare between workspace resources
 * and resources in a remote project or baseline.
 *
 * @author V.Grishchenko
 */
public class DMCompareSubscriber extends DMBaseCompareSubscriber {
    private static final String ID = "com.serena.eclipse.dimensions.team.compare-subscriber"; //$NON-NLS-1$
    private static final String COMPARE_PREFIX = "compare-"; //$NON-NLS-1$

    private DMRemoteTree remoteTree;

    private class CompareRemoteTree extends DMRemoteTree {
        public CompareRemoteTree(ResourceVariantByteStore store) {
            super(store, DMCompareSubscriber.this);
        }

        @Override
        protected IDMProject getDMProject(IResource resource) throws CoreException {
            return getRemoteProject(resource);
        }
    }

    /**
     * @param name
     */
    public DMCompareSubscriber(ProjectMergeDescriptor[] descriptors) {
        super(getUniqueId(ID, COMPARE_PREFIX), descriptors);
        this.remoteTree = new CompareRemoteTree(new SessionResourceVariantByteStore());
        for (int i = 0; i < descriptors.length; i++) {
            try {
                // register roots, doing this upfront avoids weird problems in the sync view
                this.remoteTree.newManagedProject(descriptors[i].getRemote());
            } catch (TeamException e) { // shouldn't happen but log just in case
                DMTeamPlugin.log(e.getStatus());
            }
        }
        registerListeners();
    }

    private void registerListeners() {
        DMTeamPlugin.getWorkspace().getSubscriber().addListener(this);
    }

    @Override
    public void dispose() {
        DMTeamPlugin.getWorkspace().getSubscriber().removeListener(this);
        remoteTree.dispose();
        super.dispose();
    }

    @Override
    public IStatus merged(IResource[] locals, IDMRemoteResource[] remotes, IProgressMonitor monitor) throws CoreException {
        // do nothing
        return Status.OK_STATUS;
    }

    @Override
    protected String getName(ProjectMergeDescriptor[] projectMerges) {
        if (projectMerges == null) {
            projectMerges = new ProjectMergeDescriptor[] {};
        }
        String[] remotes = new String[projectMerges.length];
        for (int i = 0; i < remotes.length; i++) {
            remotes[i] = projectMerges[i].getRemote().getId();
        }
        return Utils.toCsvString(remotes, true);
    }

    @Override
    protected IResourceVariantTree getBaseTree() {
        return null; // compare is 2-way only
    }

    @Override
    protected IResourceVariantTree getRemoteTree() {
        return remoteTree;
    }

    @Override
    public boolean isSupervised(IResource resource) throws TeamException {
        if (super.isSupervised(resource)) {
            if (!resource.exists() && !getRemoteTree().hasResourceVariant(resource)) {
                return false; // Exclude conflicting deletions
            }
            IResource[] resources = roots();
            for (int i = 0; i < resources.length; i++) {
                IResource root = resources[i];
                if (root.getFullPath().isPrefixOf(resource.getFullPath())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected SyncInfo getSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote) throws TeamException {
        try {
            DMSyncInfo syncInfo = new DMSyncInfo(local, base, remote, getResourceComparator(), this, getConnectionForResource(
                    local, base, remote));
            syncInfo.init();
            return syncInfo;
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.objects.ItemType;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * Request to create a new item in Dimensions repository and optionally
 * check it out upon successful creation.
 *
 * @author V.Grishchenko
 */
public class CreateItemRequest extends CreateNewItemRevisionRequest {

    private boolean checkout;
    private Project workset;
    private ItemRevision createdRevision;
    private boolean partUpdated;

    public CreateItemRequest(IFile file, ItemType itemType, boolean enforceRequest, boolean anyRequest) throws CoreException {
        super(file, itemType, NEW_ITEM, enforceRequest, anyRequest);
    }

    @Override
    public int getKind() {
        return CREATE;
    }

    public void setCheckout(boolean value) {
        this.checkout = value;
    }

    /**
     * @return <code>true</code> if the just created item is to be checked
     *         out to local workspace
     */
    public boolean isCheckout() {
        return checkout;
    }

    public void setOwningPartSpecification(String spec) {
        getNewRevisionDetails().setOwningPartSpecification(spec);
        partUpdated = true;
    }

    // Returns true if owning part was changed
    boolean isPartUpdated() {
        return partUpdated;
    }

    void setWorkset(Project workset) {
        this.workset = workset;
    }

    @Override
    protected void process(IProgressMonitor monitor) throws DMException {
        monitor.beginTask(null, 50);
        int addWork = checkout ? 25 : 50;
        super.process(Utils.subMonitorFor(monitor, addWork));
        try {
            if (checkout) {
                if (createdRevision != null) {
                    try {
                        CheckoutRequest checkoutRequest = new CheckoutRequest(getFile(), getType(), createdRevision,
                                isRequestsMandatory(), isAnyRequest());
                        checkoutRequest.setNewRevisionDetails(getCheckoutDetails());
                        checkoutRequest.process(Utils.subMonitorFor(monitor, 25));
                    } catch (CoreException e) {
                        throw DMException.asDMException(e);
                    }
                } else {
                    DMTeamPlugin.log(DMTeamStatus.createErrorStatus(0, "cannot checkout: no revision handle")); //$NON-NLS-1$
                }
            } else {
                monitor.worked(1);
            }
        } finally {
            createdRevision = null; // conserve memory - can be an issue during massive add
        }
    }

    private ItemRevisionDetails getCheckoutDetails() {
        // copy documents and attributes
        ItemRevisionDetails addDetails = getNewRevisionDetails();
        ItemRevisionDetails checkoutDetails = new ItemRevisionDetails();
        Map attributes = addDetails.getAttributeMap();
        if (attributes == null) {
            attributes = Collections.EMPTY_MAP;
        }
        for (Iterator iter = attributes.entrySet().iterator(); iter.hasNext();) {
            Map.Entry entry = (Map.Entry) iter.next();
            int attrNum = ((Integer) entry.getKey()).intValue();
            if (Utils.isUserAttribute(attrNum)) {
                checkoutDetails.setAttribute(attrNum, entry.getValue());
            }
        }
        checkoutDetails.setRelatedRequests(addDetails.getRelatedRequests());
        return checkoutDetails;
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        try {
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            IFile local = getFile();
            getNewRevisionDetails().setUserFileName(local.getLocation().toOSString());
            DimensionsResult result = session.getObjectFactory().createItem(getNewRevisionDetails(), workset, true, getCharset());
            TeamUtils.setReadOnly(local, isReadOnly());
            TeamUtils.ensureReacheable(getFile().getParent(), false);

            WorkspaceMetadataManager.refreshMetadata(local, null); // refresh workspace state
            ItemMetadata itemMetadata = (ItemMetadata) WorkspaceMetadataManager.getInstance().getMetadata(local);
            if (itemMetadata != null) {
                String createdSpec = itemMetadata.getItemSpec();
                createdRevision = workset.createItemRevisionFromSpec(createdSpec);
            }
            return result;
        } finally {
            monitor.done();
        }
    }

}

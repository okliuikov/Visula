/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author S.Korniychuk
 */
public class UpdateAutoMergeRevisionRequest extends SimpleItemRevisionRequest {
    private ItemRevision baseRevision;

    private IStatus resultStatus;

    public UpdateAutoMergeRevisionRequest(IFile file, ItemRevision remoteRevision, ItemRevision baseRevision) throws CoreException {
        super(file, remoteRevision);
        this.baseRevision = baseRevision;
    }

    @Override
    public int getKind() {
        if (getResource().exists()) {
            return MODIFY;
        }
        return CREATE;
    }

    @Override
    protected DimensionsResult execute(Session session, IProgressMonitor monitor) throws Exception {
        Utils.checkCanceled(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            return automerge(session.getConnectionDetails(), monitor);
        } finally {
            monitor.done();
        }

    }

    /*
     * copies remote revision to local, must be called in session runnable
     */
    DimensionsResult automerge(DimensionsConnectionDetailsEx connection, IProgressMonitor monitor) throws Exception {
        if (connection.isItemRevisionInTextFormat(getItemRevision(), monitor)) {
            UpdateAutoMerger uam = new UpdateAutoMerger(getFile(), getItemRevision(), baseRevision);
            resultStatus = uam.merge(connection, monitor);
        } else {
            resultStatus = new DMTeamStatus(IStatus.ERROR, 1, NLS.bind(Messages.UpdateAutoMerger_conflict_binary,
                    getFile().getName()), null, getFile());
        }
        return new DimensionsResult(resultStatus.getMessage());
    }

    public IStatus getResultStatus() {
        return resultStatus;
    }

}

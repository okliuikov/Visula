/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import merant.adm.dimensions.util.Encoding;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;

/**
 * @author V.Grishchenko
 */
public class UpdateFilenameRequest extends SimpleItemRevisionRequest {
    protected IDMProject project;
    private String newPath;
    private boolean clearMoveState;

    /**
     * @param file
     * @param itemRevision
     * @throws CoreException
     */
    public UpdateFilenameRequest(IFile file, ItemRevision itemRevision) throws CoreException {
        super(file, itemRevision);
    }

    public UpdateFilenameRequest(IFile file, ItemRevision itemRevision, String newPath) throws CoreException {
        super(file, itemRevision);
        this.newPath = newPath;
    }

    @Override
    public int getKind() {
        return MOVE;
    }

    public void setClearMoveState(boolean b) {
        clearMoveState = b;
    }

    void setProject(IDMProject project) {
        this.project = project;
    }

    protected String getItemSpec() {
        return (String) getItemRevision().getAttribute(SystemAttributes.OBJECT_SPEC);
    }

    @Override
    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
        String _newPath = newPath;
        if (newPath == null) {
            IPath remotePath = project.getRemotePathForLocalResource(getFile());
            _newPath = TeamUtils.getItemFullPath(remotePath);
        }
        String spec = getItemSpec();
        // run as a command to make sure filename is set on proper object
        StringBuffer cmdLine = new StringBuffer("SWF ") //$NON-NLS-1$
        .append(Encoding.escapeDMCLI(spec))
                .append(" /WS_FILENAME=").append(Encoding.escapeDMCLI(_newPath)) //$NON-NLS-1$
                .append(" /WORKSET=").append(Encoding.escapeDMCLI(project.getId())); //$NON-NLS-1$
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            DimensionsResult result = _session.getObjectFactory().runCommand(cmdLine.toString());
            if (clearMoveState) {
                ItemMetadata metadata = (ItemMetadata) WorkspaceMetadataManager.getInstance().getMetadata(getFile());
                if (metadata != null) {
                    metadata.setMovedFrom(Utils.EMPTY_STRING);
                    metadata.put(WorkspaceMetadataManager.FROM_PROJECT, Utils.EMPTY_STRING);
                    metadata.put(WorkspaceMetadataManager.FROM_BASELINE, Utils.EMPTY_STRING);
                    WorkspaceMetadataManager.getInstance().updateMetadata(getFile(), metadata);
                }
            }
            return result;
        } finally {
            monitor.done();
        }
    }

}

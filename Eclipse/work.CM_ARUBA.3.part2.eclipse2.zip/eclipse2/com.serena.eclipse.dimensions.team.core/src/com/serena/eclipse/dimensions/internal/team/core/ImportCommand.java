/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.jobs.ILock;
import org.eclipse.team.core.ITeamStatus;

import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class ImportCommand extends DMWorkspaceCommand1 implements ISessionRunnable {

    private Session session;
    private boolean restore;

    /**
     * @param dmProject
     * @param requests
     */
    public ImportCommand(DMProject dmProject, WorkspaceResourceRequest[] requests) {
        super(dmProject, requests);
    }

    @Override
    public boolean modifiesRemote() {
        return true;
    }

    @Override
    protected String getErrorMessage(IStatus[] errors) {
        boolean missingRevisions = false;
        for (int i = 0; i < errors.length; i++) {
            if (errors[i] instanceof ITeamStatus) {
                missingRevisions = true;
                break;
            }
        }
        if (missingRevisions) {
            return "Failed to locate item revisions.";
        }
        return super.getErrorMessage(errors);
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException {
        // set default workset to global as AIWS uses default to export from,
        // we restore the original default at the end
        DMException error = null;
        ILock changeDefaultProjectLock = dmProject.getConnection().getChangeDefaultProjectLock();
        monitor = Utils.monitorFor(monitor);
        try {
            changeDefaultProjectLock.acquire();
            prepareImport(monitor);
            monitor.beginTask(null, requests.length * 100);
            for (int i = 0; i < requests.length; i++) {
                ImportRequest request = (ImportRequest) requests[i];
                request.setProject(dmProject);
                request.process(Utils.subMonitorFor(monitor, 100));
                ITeamStatus importStatus = request.getStatus();
                if (!importStatus.isOK()) {
                    addError(importStatus);
                }
                Utils.checkCanceled(monitor);
            }
        } catch (DMException e1) {
            error = e1;
        } finally {
            try {
                restore(monitor); // restore default project
            } catch (DMException e2) {
                if (error == null) {
                    throw e2;
                }
                MultiStatus status = new MultiStatus(DMTeamPlugin.ID, 0, new IStatus[] { error.getStatus(), e2.getStatus() },
                        "Error during revision export", null); //$NON-NLS-1$
                throw new DMException(status);
            } finally {
                changeDefaultProjectLock.release();
                monitor.done();
            }
        }
    }

    private void prepareImport(IProgressMonitor monitor) throws DMException {
        restore = false;
        session = dmProject.getConnection().openSession(null);
        session.run(this, monitor);
    }

    private void restore(IProgressMonitor monitor) throws DMException {
        restore = true;
        session.run(this, monitor);
    }

    @Override
    public void run() throws Exception {
        if (!restore) {
            DimensionsObjectFactory factory = session.getObjectFactory();
            factory.setCurrentProject(IDMConstants.GLOBAL_WORKSET, false, null, null, null, true);
        }
    }

}

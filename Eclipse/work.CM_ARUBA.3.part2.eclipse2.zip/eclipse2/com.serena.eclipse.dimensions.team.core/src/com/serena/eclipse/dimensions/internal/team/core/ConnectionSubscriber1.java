/*
 * @ConnectionSubscriber1.java, created on 03-Feb-2006
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, 2006 Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IConnectionSubscriber;
import com.serena.eclipse.dimensions.core.IMappedObjectDetails;

/**
 * @author BStephenson
 */
public class ConnectionSubscriber1 implements IConnectionSubscriber {

    @Override
    public IStatus validateConnectionDeletion(DimensionsConnectionDetailsEx con) {
        return null;
    }

    @Override
    public void preDeleteConnection(DimensionsConnectionDetailsEx con) throws CoreException {

    }

    @Override
    public void postDeleteConnection(DimensionsConnectionDetailsEx con) {

    }

    @Override
    public List<? extends IMappedObjectDetails> getMappedObjectDetails(DimensionsConnectionDetailsEx con) throws CoreException {
        return getProjects(con);
    }

    private static List<? extends IMappedObjectDetails> getProjects(DimensionsConnectionDetailsEx con) throws CoreException {
        IDMProject[] allProjects = DMTeamPlugin.getWorkspace().getProjects();
        if (con == null) {
            return Arrays.asList(allProjects);
        }
        List<IMappedObjectDetails> result = new ArrayList<IMappedObjectDetails>();
        for (int i = 0; i < allProjects.length; i++) {
            if (con.equals(allProjects[i].getConnection())) {
                result.add(allProjects[i]);
            }
        }
        return result;
    }

}

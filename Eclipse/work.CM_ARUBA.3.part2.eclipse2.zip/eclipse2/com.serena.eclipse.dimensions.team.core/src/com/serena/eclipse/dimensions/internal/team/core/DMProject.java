/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.RepositoryPathStatus;
import com.serena.dmclient.api.RepositoryPathStatusHandler;
import com.serena.dmclient.api.RepositoryVersion;
import com.serena.dmclient.api.RepositoryVersionFile;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.VersionedRepository;
import com.serena.dmclient.objects.VersionedRepositoryOptions;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionListener;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.SessionRunnableWithProgress;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLWorkspaceMergeCommand;

/**
 * @author V.Grishchenko
 */
abstract class DMProject implements RootIdmProject {
    // @formatter:off
    // since 14.1 performs inefficient query for getting latest revisions using file version information
    static final Filter.Criterion LATEST_CRITERION = new Filter.Criterion(SystemAttributes.IS_LATEST_REVFV, Utils.EMPTY_STRING, 0);
    // since 14.1 performs query to the db view (ws_files table before 14.1) using 'latest==Y' condition
    static final Filter.Criterion FAST_LATEST_CRITERION = new Filter.Criterion(SystemAttributes.IS_LATEST_REV, Boolean.TRUE, 0);
    static final Filter.Criterion FAST_RECURSIVE_CRITERION = new Filter.Criterion(FilterOptions.RECURSIVE, Boolean.TRUE, 0);
    static final Filter.Criterion USAGE_RELATIONSHIP_CRITERION = new Filter.Criterion(
            FilterOptions.USAGE_RELATIONSHIP,
            Boolean.TRUE,
            0);

    // exclude scc project marker files
    static final Filter.Criterion NOT_TYPE_PROJECT_CRITERION = new Filter.Criterion(
            SystemAttributes.TYPE_NAME,
            IDMConstants.TYPE_PROJECT,
            Filter.Criterion.NOT);
    // @formatter:on

    static final int MAX_PATHS_PER_REVISION_QUERY = 512;

    static final int DM_VIRTUAL_CHILDREN_MAXLENGTH = 2048;

    static final String DM_VIRTUAL_CHILDREN = "dm_virtual_children";//$NON-NLS-1$

    static QualifiedName createVirtualChildrenQualifiedName(int index) {
        return new QualifiedName(DMRepositoryProvider.QUALIFIER, DM_VIRTUAL_CHILDREN + index);
    }

    private String id;
    private int type;
    private boolean sccStyle;
    private DimensionsConnectionDetailsEx connection;
    private IPath localOffset;
    private IPath remoteOffset;
    private IPath workAreaPath; // work area path, null/empty means no full work area
    private IProject project;
    private IDMRemoteTree remoteTree;
    private String ideProjectName;
    private String ideTag;
    private long uid; // durules uid
    private long mainUid; // ide project UID
    private long dmUid; // real uid of project/baseline
    private String product;
    private String projectGroup;
    protected boolean initial;
    protected String defaultRequest;
    private ISessionListener sessionListener;
    private boolean sbmEnabled;

    static DMProject createProject(APIObjectAdapter projectWrapper, IProject project, IPath localOffset, IPath workAreaPath,
            IDMRemoteTree remoteTree) throws DMException {
        if (!(projectWrapper instanceof WorksetAdapter || projectWrapper instanceof BaselineAdapter
                || projectWrapper instanceof SccProject)) {
            Assert.isLegal(false, "workset, baseline, or legacy project expected"); //$NON-NLS-1$
        }

        APIObjectAdapter actualProject = projectWrapper;
        APIObjectAdapter uidObject;
        IPath remoteOffset = null;
        String ideProjectName = null;

        int[] attrs = null;

        // @formatter:off
        if (projectWrapper instanceof WorksetAdapter) {
            uidObject = projectWrapper;
            attrs = new int[] {
                    SystemAttributes.IDE_TAG,
                    SystemAttributes.IDE_PROJECT_NAME,
                    SystemAttributes.IDE_INITIAL,
                    SystemAttributes.IDE_DM_UID,
                    SystemAttributes.DEFAULT_REQUEST,
                    SystemAttributes.WSET_IS_STREAM,
                    SystemAttributes.OBJECT_UID
            };
        } else if (projectWrapper instanceof BaselineAdapter) {
            uidObject = projectWrapper;
            attrs = new int[] {
                    SystemAttributes.IDE_TAG,
                    SystemAttributes.IDE_PROJECT_NAME,
                    SystemAttributes.IDE_DM_UID,
                    SystemAttributes.OBJECT_UID
            };
        } else { // legacy project
            SccProject legacyPrj = (SccProject) projectWrapper;
            actualProject = legacyPrj.getProjectContainer();
            uidObject = legacyPrj;
            remoteOffset = new Path(legacyPrj.getOffset());
            ideProjectName = legacyPrj.getName(); // use marker filename as name of project
            if (actualProject instanceof WorksetAdapter) {
                attrs = new int[] {
                        SystemAttributes.IDE_TAG,
                        SystemAttributes.IDE_PROJECT_NAME,
                        SystemAttributes.IDE_INITIAL,
                        SystemAttributes.IDE_DM_UID,
                        SystemAttributes.DEFAULT_REQUEST,
                        SystemAttributes.WSET_IS_STREAM,
                        SystemAttributes.OBJECT_UID
                };
            } else if (actualProject instanceof BaselineAdapter) {
                attrs = new int[] {
                        SystemAttributes.IDE_TAG,
                        SystemAttributes.IDE_PROJECT_NAME,
                        SystemAttributes.IDE_DM_UID,
                        SystemAttributes.OBJECT_UID
                };
            }
            // @formatter:on

            // get marker file uid
            final int[] finalItmAttrs = new int[] { SystemAttributes.IDE_DM_UID };
            final DimensionsArObject actualItmApiProject = legacyPrj.getAPIObject();
            final Session session = projectWrapper.getConnectionDetails().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    Utils.queryAttributes(Collections.singletonList(actualItmApiProject), finalItmAttrs,
                            session.getObjectFactory(), true);
                }
            }, new NullProgressMonitor());
        }

        // cache required attributes on the workset/bl
        if (attrs != null) {
            final int[] finalAttrs = attrs;
            final DimensionsArObject actualApiProject = actualProject.getAPIObject();
            final Session session = projectWrapper.getConnectionDetails().openSession(null);
            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    Utils.queryAttributes(Collections.singletonList(actualApiProject), finalAttrs,
                            session.getObjectFactory(), true);
                }

            }, new NullProgressMonitor());
        }

        DMProject result;
        if (actualProject instanceof WorksetAdapter) {
            result = new WorksetProject((WorksetAdapter) actualProject, uidObject, project, localOffset, remoteOffset,
                    workAreaPath, remoteTree);
        } else {
            result = new BaselineProject((BaselineAdapter) actualProject, uidObject, project, localOffset, remoteOffset,
                    workAreaPath, remoteTree);
        }

        if (ideProjectName != null) {
            // set legacy ide project name
            result.setIdeProjectName(ideProjectName);
        }

        return result;

    }

    static DMProject createProject(String id, int type, DimensionsConnectionDetailsEx connection, IProject project,
            IPath localOffset, IPath remoteOffset, IPath workAreaRoot, IDMRemoteTree remoteTree) {
        DMProject result = null;
        if (type == IDMProject.WORKSET) {
            result = new WorksetProject(id, connection, project, localOffset, remoteOffset, workAreaRoot, remoteTree);
        } else if (type == IDMProject.BASELINE) {
            result = new BaselineProject(id, connection, project, localOffset, remoteOffset, workAreaRoot, remoteTree);
        } else {
            Assert.isLegal(false, "workset or baseline expected"); //$NON-NLS-1$
        }
        return result;
    }

    private static String getProjectId(APIObjectAdapter object) {
        return (String) object.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
    }

    private static int getProjectType(APIObjectAdapter object) {
        if (object instanceof WorksetAdapter) {
            return WORKSET;
        }
        if (object instanceof BaselineAdapter) {
            return BASELINE;
        }
        Assert.isLegal(false, "workset or baseline expected"); //$NON-NLS-1$
        return 0;
    }

    public DMProject(APIObjectAdapter object, APIObjectAdapter uidObject, IProject project, IPath localOffset,
            IPath remoteOffset, IPath workAreaPath, IDMRemoteTree remoteTree) {
        this(getProjectId(object), getProjectType(object), object.getConnectionDetails(), project, localOffset, remoteOffset,
                workAreaPath, remoteTree);
        // initial project UID, if any
        Long longUid = (Long) object.getAPIObject().getAttribute(SystemAttributes.IDE_DM_UID);
        if (longUid != null) {
            mainUid = longUid.longValue();
        }
        // real uid
        longUid = (Long) object.getAPIObject().getAttribute(SystemAttributes.OBJECT_UID);
        if (longUid != null) {
            dmUid = longUid.longValue();
        }
        // durules UID - either the ws/bl or the marker item
        longUid = (Long) uidObject.getAPIObject().getAttribute(SystemAttributes.IDE_DM_UID);
        if (longUid != null) {
            uid = longUid.longValue();
        }

        String s = (String) object.getAPIObject().getAttribute(SystemAttributes.IDE_PROJECT_NAME);
        if (s != null && s.length() > 0) {
            ideProjectName = s;
        }
        s = (String) object.getAPIObject().getAttribute(SystemAttributes.IDE_TAG);
        if (s != null && s.length() > 0) {
            ideTag = s;
        }
        this.projectGroup = null;
    }

    public DMProject(String id, int type, DimensionsConnectionDetailsEx connection, IProject project, IPath localOffset,
            IPath remoteOffset, IPath workAreaPath, IDMRemoteTree remoteTree) {
        this.id = id;
        int idx = id.indexOf(':');
        Assert.isLegal(idx != -1, "project id must be of form product:object_id"); //$NON-NLS-1$
        this.product = id.substring(0, idx);
        this.type = type;
        this.connection = connection;
        this.project = project;
        this.localOffset = localOffset == null ? Path.EMPTY : localOffset.removeTrailingSeparator();
        this.remoteOffset = remoteOffset == null ? Path.EMPTY : remoteOffset.removeTrailingSeparator();
        this.workAreaPath = workAreaPath == null ? Path.EMPTY : workAreaPath.removeTrailingSeparator();
        // is scc style if remote offset not null or empty
        if (remoteOffset != null && !remoteOffset.isEmpty()) {
            sccStyle = true;
        }
        this.remoteTree = remoteTree;
        if (remoteTree instanceof RemoteProjectTree) {
            ((RemoteProjectTree) remoteTree).setDMProject(this);
        }
        this.sessionListener = new ISessionListener() {

            @Override
            public void sessionCreated(DimensionsConnectionDetailsEx con) {
            }

            @Override
            public void sessionDestroyed(DimensionsConnectionDetailsEx con) {
                if (DMProject.this.connection.equals(con)) {
                    DMProject.this.sessionDestroyed();
                }
            }

        };
        DimensionsConnectionDetailsEx.addSessionListener(sessionListener);
    }

    @Override
    protected void finalize() {
        // cleanup in finalize as explicit dispose of a project is undefined
        DimensionsConnectionDetailsEx.removeSessionListener(sessionListener);
    }

    @Override
    public IDMRemoteTree getRemoteTree() {
        return remoteTree;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnection() {
        return connection;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public int getType() {
        return type;
    }

    @Override
    public String getIdeTag() {
        return ideTag;
    }

    void setIdeTag(String tag) {
        this.ideTag = tag;
    }

    @Override
    public String getIdeProjectName() {
        return ideProjectName;
    }

    public void setIdeProjectName(String name) {
        this.ideProjectName = name;
    }

    @Override
    public long getIdeProjectUid() {
        return uid;
    }

    void setIdeProjectUid(long uid) {
        this.uid = uid;
    }

    @Override
    public long getMainUid() {
        return mainUid;
    }

    void setMainUid(long mainUid) {
        this.mainUid = mainUid;
    }

    @Override
    public long getDmUid() {
        return dmUid;
    }

    void setDmUid(long dmUid) {
        this.dmUid = dmUid;
    }

    @Override
    public boolean isInitial() {
        return initial;
    }

    void setInitial(boolean initial) {
        this.initial = initial;
    }

    @Override
    public String getDefaultRequest() {
        return defaultRequest;
    }

    void setDefaultRequest(String spec, boolean persist) throws CoreException {
        if (spec != null && spec.length() == 0) {
            spec = null;
        }
        this.defaultRequest = spec;
        if (persist) {
            DMRepositoryProvider.persistDefaultRequest(this, spec);
        }
    }

    @Override
    public synchronized String getProduct() {
        return product;
    }

    @Override
    public boolean isWorkset() {
        return type == WORKSET;
    }

    @Override
    public boolean isBaseline() {
        return type == BASELINE;
    }

    @Override
    public boolean isSccStyle() {
        return sccStyle;
    }

    @Override
    public boolean isSBMEnabled() {
        return sbmEnabled;
    }

    public void setSBMEnabled(boolean sbmEnabled) {
        this.sbmEnabled = sbmEnabled;
    }

    @Override
    public IPath getProjectRelativePath() {
        return localOffset;
    }

    @Override
    public IProject getProject() {
        return project;
    }

    public void setProject(IProject project) {
        assert project != null;
        this.project = project;
    }

    @Override
    public IContainer getRoot() {
        if (localOffset.isEmpty()) {
            return project;
        }
        if (project != null) {
            return project.getFolder(localOffset);
        }
        return null;
    }

    @Override
    public boolean isManaged(IResource resource) {
        return localOffset.isPrefixOf(resource.getProjectRelativePath());
    }

    @Override
    public IPath getRemotePathForLocalResource(IResource resource) {
        if (resource == null) {
            return null;
        }
        return getRemotePathForLocalPath(resource.getProjectRelativePath());
    }

    @Override
    public IPath getRemotePathForLocalPath(IPath path) {
        if (!localOffset.isPrefixOf(path)) {
            return null;
        }
        return remoteOffset.append(path.removeFirstSegments(localOffset.segmentCount()));
    }

    @Override
    public IPath getLocalPathForRemotePath(IPath path) {
        IPath remoteRelativePath = path.removeFirstSegments(remoteOffset.segmentCount());
        return localOffset.append(remoteRelativePath);
    }

    @Override
    public List<DimensionsArObject> fetchMembers(IContainer container, int types, int[] attrs, boolean recursive,
            IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        int workRemaining = 1000;
        monitor.beginTask(null, workRemaining);
        try {
            final RepositoryFolder remoteRoot = getRemoteRoot();
            monitor.worked(50);
            workRemaining -= 50;
            RepositoryFolder remoteFolder = null;
            if (container.equals(getRoot())) {
                remoteFolder = remoteRoot;
            } else {
                IPath remotePath = getRemotePathForLocalResource(container);
                if (remotePath != null) {
                    Session session = getConnection().openSession(null);

                    final Unit<List<RepositoryFolder>> listHolder = new Unit<List<RepositoryFolder>>();
                    session.run(new ISessionRunnable() {

                        @SuppressWarnings("unchecked")
                        @Override
                        public void run() throws Exception {
                            listHolder.setValue(remoteRoot.getAllChildFolders());
                        }

                    }, monitor);

                    remoteFolder = findFolder(listHolder.getValue(), remotePath);
                    monitor.worked(50);
                    workRemaining -= 50;
                }
            }
            if (remoteFolder == null) {
                return Collections.emptyList();
            }
            return fetchMembers(remoteFolder, types, attrs, recursive, Utils.subMonitorFor(monitor, workRemaining));
        } finally {
            monitor.done();
        }
    }

    @Override
    public List<DimensionsArObject> fetchMembers(final RepositoryFolder folder, final int types, final int[] itemAttrs,
            final boolean recursive, IProgressMonitor monitor) throws DMException {
        final boolean includeFiles = (IResource.FILE & types) != 0;
        final boolean includeFolders = (IResource.FOLDER & types) != 0;
        if (!includeFiles && !includeFolders) {
            return Collections.emptyList();
        }
        monitor = Utils.monitorFor(monitor);
        final Session session = getConnection().openSession(null);

        final Unit<List<DimensionsArObject>> fetchedMembersHolder = new Unit<List<DimensionsArObject>>();

        session.run(new SessionRunnableWithProgress(monitor) {

            @Override
            public void run() throws Exception {
                progress.beginTask(null, 500);
                try {
                    Project project = folder.getProject();

                    // get latest(tip) repository version
                    VersionedRepository vrs = session.getObjectFactory().getVersionedRepository();
                    RepositoryVersion tip = vrs.getTreeVersion(project.getUid());
                    long tipVersion = tip.getForestVersion();

                    // get vrs directory
                    RepositoryVersionFile vFolder;
                    if (folder.isRootFolder()) {
                        vFolder = tip.getRootDirectory();
                    } else {
                        vFolder = tip.getFile((String) folder.getAttribute(SystemAttributes.OBJECT_SPEC));
                    }

                    List<RepositoryVersionFile> children;
                    if (recursive) {
                        children = vFolder.getAllChildren(tipVersion,
                                VersionedRepositoryOptions.VERSIONFILE_INCLUDE_EXTRACTED);
                    } else {
                        children = vFolder.getImmediateChildren(tipVersion,
                                VersionedRepositoryOptions.VERSIONFILE_INCLUDE_EXTRACTED);
                    }

                    // query for latest items and repository folders
                    List<DimensionsArObject> members = new ArrayList<DimensionsArObject>();
                    List<ItemRevision> items = new ArrayList<ItemRevision>();
                    List<RepositoryFolder> folders = new ArrayList<RepositoryFolder>();
                    if (includeFiles && !includeFolders) {
                        items = vrs.toItems(children);
                        members.addAll(items);
                    } else if (!includeFiles && includeFolders) {
                        folders = vrs.toRepositoryFolders(children);
                        members.addAll(folders);
                    } else {
                        for (RepositoryVersionFile rFile : children) {
                            if (rFile.isFile()) {
                                ItemRevision irev = rFile.getItemRevision();
                                if (irev != null) {
                                    members.add(irev);
                                    items.add(irev);
                                }
                            } else if (rFile.isDirectory()) {
                                RepositoryFolder folder = rFile.getRepositoryFolder();
                                if (folder != null) {
                                    members.add(folder);
                                    folders.add(folder);
                                }
                            }
                        }
                    }

                    if (!items.isEmpty()) {
                        // query items attributes
                        Utils.queryAttributes(items, initDefaultAttributes(itemAttrs), session.getObjectFactory(), true);
                    }

                    if (!folders.isEmpty()) {
                        // query folders attributes
                        Utils.queryAttributes(folders,
                                new int[] { SystemAttributes.OBJECT_ID, SystemAttributes.OBJECT_SPEC },
                                session.getObjectFactory(), true);
                    }
                    fetchedMembersHolder.setValue(members);
                } finally {
                    progress.done();
                }
            }
        }, monitor);
        return fetchedMembersHolder.getValue();
    }

    @Override
    public ItemRevision fetchFile(IPath path, int[] attrs, boolean fetchTypeProject, IProgressMonitor monitor)
            throws DMException {
        Set<IPath> paths = new HashSet<IPath>(1);
        paths.add(path);
        Map<IPath, ItemRevision> result = fetchFiles(paths, attrs, fetchTypeProject, monitor);

        Assert.isLegal(result.size() == 1);
        Set<Entry<IPath, ItemRevision>> entries = result.entrySet();
        Assert.isLegal(entries.size() == 1);

        return entries.iterator().next().getValue();
    }

    @Override
    public Map<IPath, ItemRevision> fetchFiles(Set<IPath> paths, int[] attrs, IProgressMonitor monitor) throws DMException {
        return fetchFiles(paths, attrs, false, monitor);
    }

    @Override
    public Map<IPath, ItemRevision> fetchFiles(final Set<IPath> paths, final int[] attrs, final boolean fetchTypeProject,
            IProgressMonitor monitor) throws DMException {
        class Holder {
            // default result
            Map<IPath, ItemRevision> result = new HashMap<IPath, ItemRevision>(paths == null ? 0 : paths.size());
        }
        final Holder resultHolder = new Holder();
        if (paths == null || paths.size() == 0) {
            return resultHolder.result;
        }

        final Session session = getConnection().openSession(null);
        session.run(new SessionRunnableWithProgress(monitor) {

            @Override
            public void run() throws Exception {
                progress.beginTask(null, 100);
                try {
                    resultHolder.result = findItemRevisionsByPath(paths, fetchTypeProject, attrs, session,
                            Utils.subMonitorFor(progress, 100));
                } finally {
                    progress.done();
                }
            }

        }, monitor);

        return resultHolder.result;
    }

    // return true if could satisfy all requested attributes from paths
    boolean setNameOrPathOrDir(ItemRevision[] revisions, IPath[] paths, int[] attrs) {
        if (attrs == null || attrs.length < 1 || attrs.length > 3) {
            return false;
        }
        boolean nameFound = find(SystemAttributes.ITEMFILE_FILENAME, attrs) != -1;
        boolean pathFound = find(SystemAttributes.FULL_PATH_NAME, attrs) != -1;
        boolean dirFound = find(SystemAttributes.ITEMFILE_DIR, attrs) != -1;
        if ((attrs.length == 3 && nameFound && pathFound && dirFound)
                || (attrs.length == 1 && (nameFound || pathFound || dirFound))
                || (attrs.length == 2 && ((nameFound && pathFound) || (pathFound && dirFound) || (nameFound && dirFound)))) {
            for (int i = 0; i < revisions.length; i++) {
                if (revisions[i] != null) {
                    if (nameFound) {
                        revisions[i].setAttribute(SystemAttributes.ITEMFILE_FILENAME, paths[i].lastSegment());
                    }
                    if (pathFound) {
                        revisions[i].setAttribute(SystemAttributes.FULL_PATH_NAME, TeamUtils.getItemFullPath(paths[i]));
                    }
                    if (dirFound) {
                        revisions[i].setAttribute(SystemAttributes.ITEMFILE_DIR,
                                TeamUtils.getFolderFullPath(paths[i].removeLastSegments(1)));
                    }
                }
            }
            return true;
        }
        return false;
    }

    /**
     * @return index of first occurrence of the supplied val int the supplied arr
     */
    int find(int val, int[] arr) {
        if (arr != null) {
            for (int i = 0; i < arr.length; i++) {
                if (val == arr[i]) {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * Find revision by path. Must be called from session runnable, subclasses
     * may override. null result in map value {@link ItemRevision} indicates
     * that file was not found from the corresponding input path.
     *
     * @param remotePaths
     *            the set of interesting paths
     * @param fetchTypeProject
     *            do we need to process marker files
     * @param attrs
     *            array of attributes
     * @param session
     * @param monitor
     * @return
     * @throws Exception
     */
    protected Map<IPath, ItemRevision> findItemRevisionsByPath(Set<IPath> remotePaths, final boolean fetchTypeProject,
            int[] attrs, Session session, IProgressMonitor monitor) throws Exception {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, remotePaths.size());

        final Map<IPath, ItemRevision> result = new HashMap<IPath, ItemRevision>(remotePaths.size());
        final List<ItemRevision> revisions = new ArrayList<ItemRevision>(remotePaths.size());

        try {
            DimensionsObjectFactory factory = session.getObjectFactory();
            VersionedRepository vrs = factory.getVersionedRepository();
            final DimensionsLcObject apiObject = getDimensionsObject();

            List<String> paths = new ArrayList<String>(remotePaths.size());
            for (IPath remotePath : remotePaths) {
                paths.add(TeamUtils.getItemFullPath(remotePath));
            }

            // to skip extracted, pass VersionedRepositoryOptions.PATH_STATUS_SKIP_EXTRACTED via options
            final int options = 0;

            vrs.queryPathStatuses(apiObject.getUid(), paths.toArray(new String[paths.size()]),
                    new RepositoryPathStatusHandler() {

                        @Override
                        public void handleRepositoryPathStatus(RepositoryPathStatus pathStatus) {
                            if (!pathStatus.isFile() || pathStatus.getLatestItemRevisionUid() == -1) {
                                result.put(new Path(pathStatus.getPath()), null);
                                return;
                            }

                            if (!fetchTypeProject && pathStatus.isIdeProjectMarker()) {
                                result.put(new Path(pathStatus.getPath()), null);
                                return;
                            }

                            ItemRevision rev = null;
                            if (apiObject instanceof Project) {
                                Project project = (Project) apiObject;
                                rev = project.createItemRevisionFromUid(pathStatus.getLatestItemRevisionUid());
                            } else {
                                Baseline baseline = (Baseline) apiObject;
                                rev = baseline.createItemRevisionFromUid(pathStatus.getLatestItemRevisionUid());
                            }

                            result.put(new Path(pathStatus.getPath()), rev);
                            revisions.add(rev);
                        }
                    }, options);

            // query all necessary attributes
            Utils.queryAttributes(revisions, initDefaultAttributes(attrs), session.getObjectFactory(), true);
        } finally {
            monitor.done();
        }
        return result;
    }

    /**
     * Adds default attributes to given attributes
     *
     * @param attrs
     * @return
     */
    protected int[] initDefaultAttributes(int[] attrs) {
        // add default attrs
        if (attrs != null) {
            if (find(SystemAttributes.ITEMFILE_FILENAME, attrs) == -1) {
                int[] attrsCopy = new int[attrs.length + 1];
                System.arraycopy(attrs, 0, attrsCopy, 0, attrs.length);
                attrsCopy[attrsCopy.length - 1] = SystemAttributes.ITEMFILE_FILENAME;
                attrs = attrsCopy;
            }

            if (find(SystemAttributes.FULL_PATH_NAME, attrs) == -1) {
                int[] attrsCopy = new int[attrs.length + 1];
                System.arraycopy(attrs, 0, attrsCopy, 0, attrs.length);
                attrsCopy[attrsCopy.length - 1] = SystemAttributes.FULL_PATH_NAME;
                attrs = attrsCopy;
            }

            if (find(SystemAttributes.ITEMFILE_DIR, attrs) == -1) {
                int[] attrsCopy = new int[attrs.length + 1];
                System.arraycopy(attrs, 0, attrsCopy, 0, attrs.length);
                attrsCopy[attrsCopy.length - 1] = SystemAttributes.ITEMFILE_DIR;
                attrs = attrsCopy;
            }
        } else {
            // @formatter:off
            attrs = new int[] {
                    SystemAttributes.ITEMFILE_FILENAME,
                    SystemAttributes.FULL_PATH_NAME,
                    SystemAttributes.ITEMFILE_DIR
                };
            // @formatter:on
        }
        return attrs;
    }

    @Override
    public InputStream getContents(IPath path, IProgressMonitor monitor) throws DMException {
        Assert.isNotNull(path);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        try {
            ItemRevision repositoryFile = fetchFile(path, null, false, Utils.subMonitorFor(monitor, 40));
            if (repositoryFile == null) {
                return null;
            }
            return TeamUtils.getContents(repositoryFile, getConnection());
        } finally {
            monitor.done();
        }
    }

    @Override
    public File getTempCopy(IPath path, IProgressMonitor monitor) throws DMException {
        Assert.isNotNull(path);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        monitor.subTask(path.toString());
        try {
            ItemRevision revision = fetchFile(path, new int[] { SystemAttributes.ITEMFILE_FILENAME }, false,
                    Utils.subMonitorFor(monitor, 40));
            if (revision == null) {
                return null;
            }
            return TeamUtils.getTempCopy(revision, getConnection());
        } finally {
            monitor.done();
        }
    }

    @Override
    public IStatus copyToWorkspace(IProgressMonitor monitor) throws CoreException {
        return copyToWorkspace(new IResource[] { getRoot() }, monitor);
    }

    @Override
    public IStatus copyDirToWorkspace(IProgressMonitor monitor) throws CoreException {
        return copyDirToWorkspace(new IResource[] { getRoot() }, monitor);
    }

    @Override
    public IStatus copyToWorkspace(IResource[] resources, IProgressMonitor monitor) throws CoreException {
        if (resources == null || resources.length == 0) {
            return Status.OK_STATUS;
        }
        // refresh workspace to get the latest info
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        DMTeamPlugin.getWorkspace().getSubscriber().refresh(resources, IResource.DEPTH_INFINITE,
                Utils.subMonitorFor(monitor, 20));
        DownloadRequest[] downloadRequests = new DownloadRequest[resources.length];
        for (int i = 0; i < resources.length; i++) {
            downloadRequests[i] = new DownloadRequest(resources[i]);
        }
        return download(downloadRequests, true, false, Utils.subMonitorFor(monitor, 80));
    }

    public IStatus copyDirToWorkspace(IResource[] resources, IProgressMonitor monitor) throws CoreException {
        if (resources == null || resources.length == 0) {
            return Status.OK_STATUS;
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        DownloadRequest[] downloadRequests = new DownloadRequest[resources.length];
        for (int i = 0; i < resources.length; i++) {
            downloadRequests[i] = new DownloadRequest(resources[i]);
        }
        return dirDownload(downloadRequests, true, false, Utils.subMonitorFor(monitor, 80));
    }

    @Override
    public IStatus copyToWorkspace(GetRevisionRequest[] requests, IProgressMonitor monitor) throws CoreException {
        GetRevisionsCommand cmd = new GetRevisionsCommand(this, requests);
        return cmd.run(monitor);
    }

    protected RepositoryFolder findFolder(List<RepositoryFolder> list, IPath folderPath) {
        for (Iterator<RepositoryFolder> folderIter = list.iterator(); folderIter.hasNext();) {
            RepositoryFolder aFolder = folderIter.next();
            IPath aFolderPath = TeamUtils.getFolderPath(aFolder);
            if (folderPath.equals(aFolderPath)) {
                return aFolder;
            }
        }
        return null;
    }

    /*
     * Returns path or <code>null</code> if the supplied object does not have
     * SystemAttributes.FULL_PATH_NAME system attribute
     */
    static IPath getFilePath(ItemRevision revision) {
        String fullPath = (String) revision.getAttribute(SystemAttributes.FULL_PATH_NAME);
        if (Utils.isNullEmpty(fullPath)) {
            return null;
        }
        return new Path(fullPath);
    }

    static boolean removeFolderFromList(RepositoryFolder folderToRemove, List<RepositoryFolder> list) {
        IPath pathToRemove = TeamUtils.getFolderPath(folderToRemove);
        for (Iterator<RepositoryFolder> folderIter = list.iterator(); folderIter.hasNext();) {
            RepositoryFolder aFolder = folderIter.next();
            IPath aPath = TeamUtils.getFolderPath(aFolder);
            if (pathToRemove.equals(aPath)) {
                folderIter.remove();
                return true;
            }
        }
        return false;
    }

    @Override
    public RepositoryFolder getRemoteFolder(IContainer container, IProgressMonitor monitor) throws DMException {
        final IPath remotePath = getRemotePathForLocalResource(container);
        if (remotePath == null) {
            return null;
        }
        return getRemoteFolder(remotePath, monitor);
    }

    @Override
    public RepositoryFolder getRemoteFolder(final IPath remotePath, IProgressMonitor monitor) throws DMException {
        Assert.isLegal(remotePath != null);
        final RepositoryFolder[] resultHolder = new RepositoryFolder[1];
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 3);
        try {
            final RepositoryFolder remoteRoot = getRemoteRoot();
            monitor.worked(1);
            if (remoteOffset.equals(remotePath)) {
                return remoteRoot;
            }
            Session session = getConnection().openSession(null);
            monitor.worked(1);
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    List<RepositoryFolder> allFolders = remoteRoot.getAllChildFolders();
                    resultHolder[0] = findFolder(allFolders, remotePath);
                }

            }, monitor);
            monitor.worked(1);
        } finally {
            monitor.done();
        }
        return resultHolder[0];
    }

    /**
     * equality is based on local project, connection, remote id, and type
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof DMProject) {
            DMProject otherProject = (DMProject) obj;
            if (project.equals(otherProject.project) && connection.equals(otherProject.connection)
                    && id.equals(otherProject.id) && type == otherProject.type
                    && remoteOffset.equals(otherProject.remoteOffset)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return project.hashCode() ^ connection.hashCode() ^ id.hashCode() ^ type ^ remoteOffset.hashCode();
    }

    @Override
    public String getProjectGroup() {
        return projectGroup;
    }

    void setProjectGroup(String group) {
        this.projectGroup = group;
    }

    @Override
    public boolean isPartOfGroup() {
        return projectGroup != null;
    }

    @Override
    public IStatus download(DownloadRequest[] resources, boolean overwrite, boolean deleteUnmanaged,
            IProgressMonitor monitor) throws CoreException {
        DownloadCommand cmd = new DownloadCommand(this, resources, overwrite, deleteUnmanaged);
        return cmd.run(monitor);
    }

    @Override
    public IStatus download(CustomSubscriber subscriber, DownloadRequest[] resources, boolean overwrite,
            boolean deleteUnmanaged, IProgressMonitor monitor) throws CoreException {
        DownloadCustomCommand cmd = new DownloadCustomCommand(subscriber, this, resources, overwrite, deleteUnmanaged);
        return cmd.run(monitor);
    }

    @Override
    public IStatus download(XMLMergeDescriptor descriptor, IProgressMonitor monitor) throws CoreException {
        XMLWorkspaceMergeCommand cmd = new XMLWorkspaceMergeCommand(descriptor);
        return cmd.run(monitor);
    }

    private IStatus dirDownload(DownloadRequest[] resources, boolean overwrite, boolean deleteUnmanaged,
            IProgressMonitor monitor) throws CoreException {
        DownloadDirCommand cmd = new DownloadDirCommand(this, resources, overwrite, deleteUnmanaged);
        return cmd.run(monitor);
    }

    /**
     * For non-zero remote offsets we remove last segments from the local root path
     * assuming this will yield a valid path that can be used by download and upload
     * to resolve to project attachments.
     *
     * @return user directory for this project usable for download and upload
     */
    @Override
    public IPath getUserDirectory() {
        IPath userDirectory = isFullWorkArea() ? getWorkAreaPath() : getRoot().getLocation();
        return userDirectory;
    }

    /**
     * value for the /RELATIVE_LOCATION parameter for UPLOAD or DOWNLOAD
     *
     * @return workset offset this project usable for download and upload
     * @see com.serena.eclipse.dimensions.internal.team.core.IDMProject#getRemoteOffset()
     *      This value will be passed as the /RELATIVE_LOCATION parameter which is now
     *      supported for upload and download for file when the /USER_FILELIST parameter
     *      is also supplied
     */
    @Override
    public IPath getRemoteOffset() {
        return remoteOffset;
    }

    public void setRemoteOffset(IPath remoteOffset) {
        this.remoteOffset = remoteOffset == null ? Path.EMPTY : remoteOffset.removeTrailingSeparator();
        // is scc style if remote offset not null or empty
        if (remoteOffset != null && !remoteOffset.isEmpty()) {
            sccStyle = true;
        }
    }

    @Override
    public boolean remoteEquals(IDMProject otherProject, boolean offset) {
        Assert.isNotNull(otherProject);
        if (this == otherProject) {
            return true;
        }
        if (type == otherProject.getType() && id.equalsIgnoreCase(otherProject.getId())
                && connection.equals(otherProject.getConnection())) {
            return !offset || remoteOffset.equals(otherProject.getRemoteOffset());
        }
        return false;
    }

    @Override
    public IPath getRelativeLocation() {
        if (!isFullWorkArea()) {
            return getRemoteOffset();
        }
        return null;
    }

    @Override
    public DMTypeScope getTypeScope() {
        return isWorkset() ? DMTypeScope.PROJECT : DMTypeScope.BASELINE;
    }

    // cleanup any connection sensitive caches, do nothing - subclasses to override
    protected void sessionDestroyed() {
    }

    public void setIsStream(boolean b) {
    }

    public List<ItemMetadata> queryForeignContentStatus(List<ItemMetadata> localMetadatas,
            List<ItemMetadata> remoteMetadatas, IProgressMonitor pMonitor) throws CoreException {
        return null;
    }

    public void flushRemoteRoot() {
    }

    @Override
    public IPath getWorkAreaPath() {
        return workAreaPath;
    }

    @Override
    public boolean isFullWorkArea() {
        return workAreaPath != null && !workAreaPath.isEmpty();
    }

    @Override
    public boolean isSingleEclipseProject() {
        String tag = getIdeTag();
        if (tag != null) {
            return tag.equals(IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG);
        }
        return false;
    }

    @Override
    public boolean isContainedEclipseProject() {
        String tag = getIdeTag();
        if (tag != null) {
            return tag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1 && !getRemoteOffset().isEmpty();
        }
        return false;
    }

    @Override
    public List<VirtualIdmProject> getVirtualChildProjects() throws CoreException {
        List<VirtualIdmProject> result = new ArrayList<VirtualIdmProject>();
        IProject project = getProject();
        for (int i = 0;; i++) {
            QualifiedName qualifier = createVirtualChildrenQualifiedName(i);
            String children = project.getPersistentProperty(qualifier);
            if (children == null) {
                return result;
            }
            List<String> names = Utils.stringToList(children);
            IDMProject[] projects = DMTeamPlugin.getWorkspace().getProjects();
            for (String name : names) {
                for (IDMProject idmProject : projects) {
                    if (idmProject instanceof VirtualIdmProject && idmProject.getProject().getName().equals(name)) {
                        result.add((VirtualIdmProject) idmProject);
                    }
                }
            }
        }
    }

    @Override
    public void removeVirtualChildProject(IProject project) throws CoreException {
        IProject thisProject = getProject();

        for (int i = 0;; i++) {
            QualifiedName qualifier = createVirtualChildrenQualifiedName(i);
            String children = project.getPersistentProperty(qualifier);
            if (children == null) {
                return;
            }

            List<String> names = Utils.stringToList(children);
            for (Iterator<String> iterator = names.iterator(); iterator.hasNext();) {
                String name = iterator.next();
                if (name.equals(project.getName())) {
                    iterator.remove();
                }
            }
            String childList = Utils.listToString(names, false);
            thisProject.setPersistentProperty(qualifier, childList);
        }
    }

    @Override
    public void addVirtualChildProject(IProject project) throws CoreException {
        IProject thisProject = getProject();
        for (int i = 0;; i++) {
            QualifiedName qualifier = createVirtualChildrenQualifiedName(i);
            String children = thisProject.getPersistentProperty(qualifier);
            if (children == null || children.length() + project.getName().length() + 1 < DM_VIRTUAL_CHILDREN_MAXLENGTH) {
                List<String> childList = Utils.stringToList(children);
                childList.add(project.getName());
                thisProject.setPersistentProperty(qualifier, Utils.listToString(childList, false));
                return;
            }
        }
    }
}

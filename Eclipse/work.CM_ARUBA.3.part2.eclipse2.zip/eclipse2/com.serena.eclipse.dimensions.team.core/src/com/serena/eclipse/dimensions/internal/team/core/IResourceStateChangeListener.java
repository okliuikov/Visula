/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core;

import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;

import com.serena.eclipse.dimensions.core.WorksetAdapter;

/**
 * @author V.Grishchenko
 */
public interface IResourceStateChangeListener {

    /**
     * Notifies this listener that the project has just been configured
     * to be a Dimensions project.
     *
     * @param project The project that has just been configured
     */
    void projectConfigured(IProject project);

    /**
     * Notifies this listener that the project has just been deconfigured
     * and no longer has the Dimensions nature.
     *
     * @param project The project that has just been configured
     */
    void projectDeconfigured(IProject project);

    /**
     * <p>
     * Notifies this listener that some resource state changes have already happened. For example, a resource's base revision,
     * extraction status, read-only state, managed state may have changed.
     * <p>
     * Implementors should assume that the resource tree is closed for modifications when this method is called.
     *
     * @param changedResources that have state changes
     */
    void resourceStateChanged(IResource[] resources);

    /**
     * Notifies this listener that the resource's have been modified. This
     * doesn't necessarily mean that the resource state isModified. The listener
     * must check the state.
     *
     * @param changedResources that have changed state
     */
    public void resourceModified(IResource[] resources);
    
    void workAreaRehomeDetected(List<IDMProject> projectsToRehome, WorksetAdapter targetProject);
}

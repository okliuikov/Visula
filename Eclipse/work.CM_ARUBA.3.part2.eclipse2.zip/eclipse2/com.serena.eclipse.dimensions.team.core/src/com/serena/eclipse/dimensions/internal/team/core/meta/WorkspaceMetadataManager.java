/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.core.meta;

import java.io.File;
import java.net.URI;
import java.util.HashSet;
import java.util.Iterator;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.jobs.MultiRule;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.metadb.IMetadataStorage.MetadataTypes;
import com.serena.dmfile.metadb.MetadataException;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.MetadataProviderFactory;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;

/**
 * Maintains a timestamp-based cache for metadata entries.
 *
 * @author V.Grishchenko
 */
public final class WorkspaceMetadataManager { 
    /** deletes metadata file for the actual resource type */
    public static final int DELETE = 0;
    /** deletes metadata file for the opposite resource type */
    public static final int DELETE_CONFLICTING = 1;
    /** deletes file and folder metadata for the resource */
    public static final int DELETE_ALL = 2;
    public static final String FROM_PROJECT = "from-project"; //$NON-NLS-1$
    public static final String FROM_BASELINE = "from-baseline"; //$NON-NLS-1$

    // key for the mod stamp seen by as
    public static final QualifiedName MODSTAMP_KEY = new QualifiedName("com.serena.eclipse.dimensions.core", //$NON-NLS-1$
            "meta-file-modtime"); //$NON-NLS-1$

    private static final boolean debugMd = DMTeamPlugin.getDefault().isDebuggingMetadata();
    private static final WorkspaceMetadataManager INSTANCE = new WorkspaceMetadataManager();

    public static WorkspaceMetadataManager getInstance() {
        return INSTANCE;
    }

    private WorkspaceMetadataManager() {
    }

    /**
     * <p>
     * Obtains container member handles corresponding to the existing metadata entries. The ordering of the returned array is not
     * specified.
     *
     * <p>
     * <b>Note:</b> The resources returned may not necessarily exist in the filesystem and even if they do the actual metadata may
     * be of different gender (file vs. folder)
     *
     * @param container
     *            container for which to query members
     * @param includeLocal
     *            if <code>true</code> existing
     *            actual local members of this container will be included in the result
     * @return container members as recorded in the metadata
     * @throws CoreException
     */
    public static IResource[] getMembers(IContainer container, boolean includeLocal) throws CoreException {
        return WorkspaceMetadataEntry.getMembers(container, includeLocal);
    }

    /**
     * This gets the metadata using <code>java.io.File</code>, note that
     * this method always reads the metadata as opposed to the other method
     * which attempts to return a cached entry.
     *
     * It is intended to be used only for cases when metadata has to be
     * accessed outside of workspace.
     */
    public static BaseMetadata getLfsMetadata(File file) throws MetadataException {
        MetadataProvider mdProvider = null;
        if (debugMd) {
            System.out.println("WMM getLfsMetadata " + file.toString()); //$NON-NLS-1$
        }
        try {
            BaseMetadata metadata = null;
            if (file.isFile()) {
                mdProvider = MetadataProviderFactory.providerFor(file);
                metadata = mdProvider.getItemMetadata(file.getAbsolutePath());
            } else if (file.isDirectory()) {
                mdProvider = MetadataProviderFactory.providerFor(file);
                metadata = mdProvider.getDirectoryMetadata(file.getAbsolutePath());
            } else {
                return null;
            }
            return metadata;
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
    }

    /**
     * Deletes local metadata for the passed in resource. Note that this
     * method will not trigger resource deltas as the file is deleted
     * bypassing Eclipse workspace. Intended to be used for metadata deletions
     * outside of workspace.
     *
     * @return <code>true</code> if metadata does not exist when this method
     *         returns, returns <code>false</code> otherwise
     */
    public static boolean deleteLfsMetadata(final File file) {
        if (debugMd) {
            System.out.println("WMM deleteLfsMetadata " + file.toString());//$NON-NLS-1$
        }
        boolean result = false;
        if (!file.exists()) {
            return false;
        }
        boolean deferring = DMWorkspace.setupDeferredMdListener();
        final MetadataProvider mdProvider = MetadataProviderFactory.providerFor(file);
        try {
            if (mdProvider.metadataExists(MetadataTypes.MT_ITEM, file.getAbsolutePath())) {
                mdProvider.removeMetadata(MetadataTypes.MT_ITEM, file.getAbsolutePath());
            }
            if (mdProvider.metadataExists(MetadataTypes.MT_DIR, file.getAbsolutePath())) {
                mdProvider.removeMetadata(MetadataTypes.MT_DIR, file.getAbsolutePath());
            }
            result = !mdProvider.metadataExists(MetadataTypes.MT_ITEM, file.getAbsolutePath())
                    && !mdProvider.metadataExists(MetadataTypes.MT_DIR, file.getAbsolutePath());
        } catch (MetadataException e) {
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
            if (deferring) {
                DMWorkspace.processDeferredMdListener();
            }
        }
        return result;
    }

    /**
     * @return <code>true</code> if the specified container contains a <code>.metadata</code> folder
     */
    public static boolean hasMetadata(IContainer container) {
        return WorkspaceMetadataEntry.getMetadataContainer(container).exists();
    }

    /**
     * Checks if exists and creates if necessary a .metadata folder under the specified container
     *
     * @return metadata container
     */
    public static IContainer ensureHasMetadata(IContainer container) throws CoreException {
        return ensureHasMetadata(container, null);
    }

    /**
     * Checks if exists and creates if necessary a .metadata folder under the specified container
     *
     * @return metadata container
     */
    public static IContainer ensureHasMetadata(IContainer container, MetadataProvider provider) throws CoreException {
        IContainer metaContainer = WorkspaceMetadataEntry.getMetadataContainer(container, provider);
        TeamUtils.ensureContainerExists(metaContainer, provider);
        if (!metaContainer.isTeamPrivateMember()) {
            metaContainer.setTeamPrivateMember(true);
        }
        return metaContainer;
    }

    public BaseMetadata getMetadata(IResource resource) throws CoreException {
        if (resource == null) {
            throw new IllegalArgumentException("null resource"); //$NON-NLS-1$
        }
        WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(resource);
        if (resource.getType() == IResource.FILE) {
            return entry.readFileRecord();
        } else {
            return entry.readDirRecord();
        }
    }

    public BaseMetadata getMetadata(IPath path) throws CoreException {
        if (path == null) {
            throw new IllegalArgumentException("null path"); //$NON-NLS-1$
        }
        WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(path);
        if (path.toFile().isFile()) {
            return entry.readFileRecord();
        } else {
            return entry.readDirRecord();
        }
    }

    public void updateMetadata(final IPath path, final BaseMetadata metadata) throws CoreException {
        if (path == null) {
            throw new IllegalArgumentException("null path"); //$NON-NLS-1$
        }
        if (metadata == null) {
            throw new IllegalArgumentException("null metadata"); //$NON-NLS-1$
        }

        final MetadataProvider mdHolder = MetadataProviderFactory.providerFor(path);
        boolean deferred = false;
        try {
            WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(path);
            deferred = DMWorkspace.setupDeferredMdListener();
            entry.writeRecord(metadata, mdHolder);
        } finally {
            if (mdHolder != null) {
                mdHolder.close();
            }
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }

    }

    public void updateMetadata(final IResource resource, final BaseMetadata metadata) throws CoreException {
        if (resource == null) {
            throw new IllegalArgumentException("null resource"); //$NON-NLS-1$
        }
        if (metadata == null) {
            throw new IllegalArgumentException("null metadata"); //$NON-NLS-1$
        }
        final MetadataProvider mdHolder = MetadataProviderFactory.providerFor(resource);
        WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(resource);
        boolean deferred = DMWorkspace.setupDeferredMdListener();
        try {
            entry.writeRecord(metadata, mdHolder);
        } finally {
            if (mdHolder != null) {
                mdHolder.close();
            }
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }
    }

    public void createDirectoryMetadata(final IPath path, final BaseMetadata metadata) throws CoreException {
        if (path == null) {
            throw new IllegalArgumentException("null path"); //$NON-NLS-1$
        }
        if (metadata == null) {
            throw new IllegalArgumentException("null metadata"); //$NON-NLS-1$
        }

        final MetadataProvider mdHolder = MetadataProviderFactory.providerFor(path);
        boolean deferred = false;
        try {
            WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(path);
            deferred = DMWorkspace.setupDeferredMdListener();
            entry.createDirectoryMetadata(metadata, mdHolder);
        } finally {
            if (mdHolder != null) {
                mdHolder.close();
            }
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }
    }

    public void createDirectoryMetadata(final IResource resource, final BaseMetadata metadata) throws CoreException {
        if (metadata == null) {
            throw new IllegalArgumentException("null metadata"); //$NON-NLS-1$
        }

        final MetadataProvider mdHolder = MetadataProviderFactory.providerFor(resource);
        WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(resource);
        boolean deferred = DMWorkspace.setupDeferredMdListener();
        try {
            entry.createDirectoryMetadata(metadata, mdHolder);
        } finally {
            if (mdHolder != null) {
                mdHolder.close();
            }
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }
    }

    /**
     * Deletes metadata file for the specified resource.
     *
     * @param resource
     *            resource for which to delete metadata
     * @return <code>false</code> if metadata file still exists upon exist
     * @throws CoreException
     */
    public boolean deleteMetadata(final IResource resource, final int mode) throws CoreException {
        if (resource == null) {
            throw new IllegalArgumentException("null resource"); //$NON-NLS-1$
        }
        if (!(mode == DELETE || mode == DELETE_CONFLICTING || mode == DELETE_ALL)) {
            throw new IllegalArgumentException("invalid delete mode"); //$NON-NLS-1$
        }

        final MetadataProvider mdHolder = MetadataProviderFactory.providerFor(resource);
        boolean deleted = false;
        WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(resource);
        boolean deferred = DMWorkspace.setupDeferredMdListener();
        try {
            switch (mode) {
            case DELETE:
                deleted = entry.delete(false, mdHolder);
                break;
            case DELETE_CONFLICTING:
                deleted = entry.delete(true, mdHolder);
                break;
            case DELETE_ALL:
                deleted = entry.deleteAll(mdHolder);
                break;
            }

        } finally {
            if (mdHolder != null) {
                mdHolder.close();
            }
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }
        return deleted;
    }

    public boolean deleteMetadata(final IPath path, final int mode) throws CoreException {
        if (path == null) {
            throw new IllegalArgumentException("null path"); //$NON-NLS-1$
        }
        if (!(mode == DELETE || mode == DELETE_CONFLICTING || mode == DELETE_ALL)) {
            throw new IllegalArgumentException("invalid delete mode"); //$NON-NLS-1$
        }

        final MetadataProvider mdHolder = MetadataProviderFactory.providerFor(path);
        boolean deleted = false;
        boolean deferred = false;
        try {
            WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(path);
            deferred = DMWorkspace.setupDeferredMdListener();
            switch (mode) {
            case DELETE:
                deleted = entry.delete(false, mdHolder);
                break;
            case DELETE_CONFLICTING:
                deleted = entry.delete(true, mdHolder);
                break;
            case DELETE_ALL:
                deleted = entry.deleteAll(mdHolder);
                break;
            }

        } finally {
            if (mdHolder != null) {
                mdHolder.close();
            }
            if (deferred) {
                DMWorkspace.processDeferredMdListener();
            }
        }

        return deleted;
    }

    /**
     * Recursively deletes contained .metadata folders starting from the supplied
     * container
     */
    public void deleteMetadataFolders(IContainer container) throws CoreException {
        if (!container.exists()) {
            return;
        }
        IContainer metadataFolder = WorkspaceMetadataEntry.getMetadataContainer(container);
        if (metadataFolder.exists()) {
            metadataFolder.delete(true, null);
        }
        IResource[] members = container.members();
        for (int i = 0; i < members.length; i++) {
            IResource resource = members[i];
            if (members[i].getType() != IResource.FILE) {
                deleteMetadataFolders((IContainer) resource);
            }
        }
    }

    /**
     * Refreshes metadata file for the specified resource, sets <code>MODSTAMP_KEY</code> session property to contain current mod
     * stamp of the md file.
     *
     * @param resource
     * @param progress
     * @throws CoreException
     */
    public static void refreshMetadata(IResource resource, IProgressMonitor progress) throws CoreException {
        if (resource.getType() != IResource.PROJECT) {
            IFile metadataFile = getMdFile(resource);
            if (metadataFile == null) {
                if (debugMd) {
                    System.out.println(TeamUtils.myThread() + " refreshMd mdres mdfile null for " + resource.getLocation());//$NON-NLS-1$
                }
                return;
            }
            long tstamp = TeamUtils.refreshLocal(metadataFile, progress);
            if (debugMd) {
                System.out
                        .println(TeamUtils.myThread() + " refreshMd mdres " + metadataFile.getLocation() + " ts " + tstamp);//$NON-NLS-1$//$NON-NLS-2$
            }
            cacheModstamp(metadataFile, tstamp, (resource.getType() == IResource.FILE));
        }
    }

    public static IFile getMdFile(IResource res) {
        // only folder and file
        IFile ret = null;
        String mdfilename = null;
        MetadataProvider mdp = MetadataProviderFactory.providerFor(res);
        try {
            mdfilename = mdp.metadataFilename(res.getType() == IResource.FILE ? MetadataTypes.MT_ITEM : MetadataTypes.MT_DIR,
                    res.getLocation().toOSString());
        } finally {
            if (mdp != null) {
                mdp.close();
            }
        }
        URI mfUri = new File(mdfilename).toURI();
        IFile[] mdFile = ResourcesPlugin.getWorkspace().getRoot().findFilesForLocationURI(mfUri,
                IContainer.INCLUDE_TEAM_PRIVATE_MEMBERS | IContainer.INCLUDE_HIDDEN);
        if (mdFile.length == 1) {
            ret = mdFile[0];
        } else if (mdFile.length > 1) {
            IResource parent = res.getParent();
            // find match of input resource parent
            for (int f = 0; f < mdFile.length; f++) {
                // grandfather of md location should match parent of resource
                IResource toMatch = mdFile[f].getParent().getParent();
                if (parent.getFullPath().equals(toMatch.getFullPath())) {
                    ret = mdFile[f];
                    break;
                }
            }
        }
        return ret;
    }

    public static File getMetadataFile(IPath path, MetadataTypes type) {
        String mdfilename = null;
        MetadataProvider mdp = MetadataProviderFactory.providerFor(path);
        try {
            mdfilename = mdp.metadataFilename(type, path.toOSString());
        } finally {
            if (mdp != null) {
                mdp.close();
            }
        }
        return new File(mdfilename);
    }

    private static void cacheModstamp(IFile metadataFile, long tstamp, boolean doFiles) throws CoreException {
        if (metadataFile != null && metadataFile.exists()) {
            Long prev = (Long) metadataFile.getSessionProperty(MODSTAMP_KEY);
            if (prev == null || prev.longValue() != tstamp) {
                // if we are writing a different or new value invalidate
                IContainer grandparentOfMd = metadataFile.getParent().getParent();
                if (grandparentOfMd.exists()) {
                    DMTeamPlugin.getWorkspace().markStale(grandparentOfMd, doFiles, null);
                }
                if (debugMd) {
                    System.out.println(TeamUtils.myThread() + " cache modstamp " + metadataFile.getLocation().toOSString() //$NON-NLS-1$
                            + " ts " + tstamp);//$NON-NLS-1$
                }
                metadataFile.setSessionProperty(MODSTAMP_KEY, tstamp != IResource.NULL_STAMP ? new Long(tstamp) : null);
            }
        }
    }

    /**
     * Refreshes the metadata for the specified resources.
     *
     * @param resources
     * @param monitor
     * @throws CoreException
     */
    public static void refreshMetadata(final IResource[] resources, IProgressMonitor monitor) throws CoreException {
        if (resources == null || resources.length == 0) {
            return;
        }
        if (debugMd) {
            System.out.println(TeamUtils.myThread() + " refreshMd [] " + resources.length + "resources");//$NON-NLS-1$//$NON-NLS-2$
        }
        final HashSet<IContainer> mdContainers = new HashSet<IContainer>();
        HashSet<IResource> parents = new HashSet<IResource>();
        for (int i = 0; i < resources.length; i++) {
            IResource aResource = resources[i];
            if (aResource.getType() != IResource.PROJECT) {
                mdContainers.add(WorkspaceMetadataEntry.getMetadataContainer(aResource.getParent()));
            }
            parents.add(TeamUtils.parent(aResource));
        }

        MultiRule rule = new MultiRule(parents.toArray(new IResource[parents.size()]));
        ResourcesPlugin.getWorkspace().run(new IWorkspaceRunnable() {
            @Override
            public void run(IProgressMonitor monitor) throws CoreException {
                monitor = Utils.monitorFor(monitor);
                monitor.beginTask(null, mdContainers.size() * 10);
                try {
                    for (Iterator<IContainer> iterator = mdContainers.iterator(); iterator.hasNext();) {
                        IContainer aContainer = iterator.next();
                        TeamUtils.refreshLocal(aContainer, Utils.subMonitorFor(monitor, 10));
                        if (aContainer.exists() && !aContainer.isTeamPrivateMember()) {
                            aContainer.setTeamPrivateMember(true);
                        }
                    }
                } finally {
                    monitor.done();
                }
                for (int i = 0; i < resources.length; i++) {
                    IFile metadataFile = getMdFile(resources[i]);
                    // don't try for null locations
                    if (metadataFile != null) {
                        cacheModstamp(metadataFile, metadataFile.getModificationStamp(),
                                (resources[i].getType() == IResource.FILE));
                    }
                }

            }
        }, rule, IWorkspace.AVOID_UPDATE, monitor);
    }

    public static IContainer getMetadataContainer(IContainer directory) {
        return WorkspaceMetadataEntry.getMetadataContainer(directory);
    }

    public boolean hasMetadataRecord(IResource resource) throws CoreException {
        if (resource == null) {
            throw new IllegalArgumentException("null resource"); //$NON-NLS-1$
        }
        WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(resource);
        return entry.exists();
    }

    public boolean hasMetadataRecord(IPath path) throws CoreException {
        if (path == null) {
            throw new IllegalArgumentException("null path"); //$NON-NLS-1$
        }
        WorkspaceMetadataEntry entry = new WorkspaceMetadataEntry(path);
        return entry.exists();
    }

    /**
     * Gets metadata container for the specified resource.
     *
     * @param resource
     * @param mdProvider
     * @return metadata container or null if no metadata container was found (resource is IProject or IWorkspaceRoot)
     */
    private static IContainer internalGetMdContainer(IResource resource, MetadataProvider mdProvider) {
        if (resource == null) {
            throw new IllegalArgumentException("null resource"); //$NON-NLS-1$
        }
        if (mdProvider == null) {
            throw new IllegalArgumentException("null metadata provider"); //$NON-NLS-1$
        }
        Assert.isLegal(resource.getType() != IResource.PROJECT && resource.getType() != IResource.ROOT,
                "Wrong type for " + resource.getName()); //$NON-NLS-1$

        IContainer parent = resource.getParent();
        return (parent != null) ? WorkspaceMetadataEntry.getMetadataContainer(parent, mdProvider) : null;
    }

    /**
     * Holder-parameterized public version
     *
     * @param resource
     * @return
     */
    public static IContainer getMdContainer(IResource resource) {
        if (resource == null) {
            throw new IllegalArgumentException("null resource"); //$NON-NLS-1$
        }
        Assert.isLegal(resource.getType() != IResource.PROJECT && resource.getType() != IResource.ROOT,
                "Wrong type for " + resource.getName());//$NON-NLS-1$

        MetadataProvider mdProvider = MetadataProviderFactory.providerFor(resource);
        try {
            IContainer resultingContainer = WorkspaceMetadataManager.internalGetMdContainer(resource, mdProvider);
            return resultingContainer;
        } finally {
            if (mdProvider != null) {
                mdProvider.close();
            }
        }
    }

}

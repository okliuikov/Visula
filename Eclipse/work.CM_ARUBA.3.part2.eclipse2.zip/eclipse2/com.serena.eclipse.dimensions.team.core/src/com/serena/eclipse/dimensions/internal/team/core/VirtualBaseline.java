package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.resources.IProject;

/**
 * Implementation of virtual project for case when it is mapped for a baseline. Most of methods are unsupported
 */
public class VirtualBaseline extends VirtualDmProject {

    public VirtualBaseline(BaselineProject parent, IProject project) {
        super(parent, project);
    }

}

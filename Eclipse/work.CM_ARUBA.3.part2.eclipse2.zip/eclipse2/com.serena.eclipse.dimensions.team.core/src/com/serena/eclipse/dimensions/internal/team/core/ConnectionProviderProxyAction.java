/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

class ConnectionProviderProxyAction implements IDMConnectionProvider {
    IConfigurationElement ce;
    IDMConnectionProvider action;

    ConnectionProviderProxyAction(IConfigurationElement ce) {
        this.ce = ce;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnection(DimensionsConnectionDetailsEx[] inputs) {
        if (getAction() == null) {
            return null;
        }
        return action.getConnection(inputs);
    }

    @Override
    public boolean poke() {
        if (getAction() == null) {
            return false;
        }
        return action.poke();
    }

    private IDMConnectionProvider getAction() {
        if (action == null) {
            try {
                action = (IDMConnectionProvider) ce.createExecutableExtension("class"); //$NON-NLS-1$
            } catch (CoreException e) {
                return null;
            }
        }
        return action;
    }

}
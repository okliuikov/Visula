package com.serena.eclipse.dimensions.internal.team.core;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.internal.resources.Workspace;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.UploadItemDetails;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;

@SuppressWarnings("restriction")
public class VirtualDmProject implements VirtualIdmProject {

    private DMProject parent;
    private IProject parentProject;
    private IProject project;
    private IPath virtualOffset;
    private IPath parentLocation;

    public VirtualDmProject(DMProject parent, IProject project) {
        Assert.isNotNull(parent);
        Assert.isNotNull(project);
        Assert.isLegal(parent.getProject().getLocation().isPrefixOf(project.getLocation()));
        this.parent = parent;
        this.project = project;
        this.parentProject = parent.getProject();

        IProject parentProject = parent.getProject();
        this.parentLocation = parentProject.getLocation();
        IPath location = project.getLocation();
        this.virtualOffset = location.removeFirstSegments(parentLocation.segmentCount());
        this.virtualOffset = virtualOffset.setDevice(null).makeRelative();
    }

    @Override
    public boolean isManaged(IResource resource) {
        if (resource == null) {
            return false;
        }
        IResource member = getOriginalResource(resource);
        return parent.isManaged(member);
    }

    @Override
    public IPath getRemotePathForLocalResource(IResource resource) {
        if (resource == null) {
            return null;
        }
        IResource member = getOriginalResource(resource);
        return parent.getRemotePathForLocalResource(member);
    }

    @Override
    public IPath getRemotePathForLocalPath(IPath path) {
        if (path == null) {
            return null;
        }
        IResource member = getParentResource(path);
        return parent.getRemotePathForLocalPath(member.getProjectRelativePath());
    }

    @Override
    public RepositoryFolder getRemoteFolder(IContainer container, IProgressMonitor monitor) throws DMException {
        if (container == null) {
            return null;
        }
        IContainer member = getOriginalContainer(container);
        return parent.getRemoteFolder(member, monitor);
    }

    @Override
    public List<DimensionsArObject> fetchMembers(IContainer container, int types, int[] attrs, boolean recursive,
            IProgressMonitor monitor) throws DMException {
        if (container == null) {
            return null;
        }
        IContainer member = getOriginalContainer(container);
        return parent.fetchMembers(member, types, attrs, recursive, monitor);
    }

    @Override
    public IFile getOriginalFile(IFile file) {
        IPath projectRelativePath = file.getProjectRelativePath();
        IPath path = parentProject.getFullPath().append(virtualOffset).append(projectRelativePath);
        Workspace workspace = (Workspace) ResourcesPlugin.getWorkspace();
        return (IFile) workspace.newResource(path, file.getType());
    }

    @Override
    public IFolder getOriginalFolder(IFolder folder) {
        IPath projectRelativePath = folder.getProjectRelativePath();
        IPath path = parentProject.getFullPath().append(virtualOffset).append(projectRelativePath);
        Workspace workspace = (Workspace) ResourcesPlugin.getWorkspace();
        return (IFolder) workspace.newResource(path, folder.getType());
    }

    @Override
    public IContainer getOriginalContainer(IContainer resource) {
        IPath path = null;
        IPath projectRelativePath = resource.getProjectRelativePath();
        path = parentProject.getFullPath().append(virtualOffset).append(projectRelativePath);
        Workspace workspace = (Workspace) ResourcesPlugin.getWorkspace();

        return (IContainer) workspace.newResource(path, IResource.FOLDER);
    }

    @Override
    public IResource getOriginalResource(IResource resource) {
        IPath path = null;
        IPath projectRelativePath = resource.getProjectRelativePath();
        path = parentProject.getFullPath().append(virtualOffset).append(projectRelativePath);
        Workspace workspace = (Workspace) ResourcesPlugin.getWorkspace();

        if (resource.getType() == IResource.PROJECT) {
            return workspace.newResource(path, IResource.FOLDER);
        } else {
            return workspace.newResource(path, resource.getType());
        }
    }

    @Override
    public IResource makeRelativeResourceFromOriginal(IResource resource) {
        IPath projectRelativePath = resource.getProjectRelativePath();
        if (virtualOffset.isPrefixOf(projectRelativePath)) {
            IPath newPath = projectRelativePath.removeFirstSegments(virtualOffset.segmentCount());
            newPath = getProject().getFullPath().append(newPath);
            Workspace workspace = (Workspace) ResourcesPlugin.getWorkspace();
            if (newPath.segmentCount()  == 1) {
                return workspace.newResource(newPath, IResource.PROJECT);
            } else {
                return workspace.newResource(newPath, resource.getType());
            }

        }
        return resource;
    }

    private IResource getParentResource(IPath pathLocal) {
        IPath projectRelativePath = pathLocal.makeRelative();
        IPath path = virtualOffset.append(projectRelativePath);
        IResource member = parentProject.findMember(path);
        return member;
    }

    @Override
    public RootIdmProject getRootProject() {
        return parent;
    }

    @Override
    public IProject getProject() {
        return project;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnection() {
        return parent.getConnection();
    }

    @Override
    public String getId() {
        return parent.getId();
    }

    @Override
    public DMTypeScope getTypeScope() {
        return parent.getTypeScope();
    }

    @Override
    public long getMainUid() {
        return parent.getMainUid();
    }

    @Override
    public IPath getRemoteOffset() {
        return parent.getRemoteOffset();
    }

    @Override
    public DimensionsLcObject getDimensionsObject() throws DMException {
        return parent.getDimensionsObject();
    }

    @Override
    public String getIdeTag() {
        return parent.getIdeTag();
    }

    @Override
    public long getIdeProjectUid() {
        return parent.getIdeProjectUid();
    }

    @Override
    public long getDmUid() {
        return parent.getDmUid();
    }

    @Override
    public String getIdeProjectName() {
        return parent.getIdeProjectName();
    }

    @Override
    public boolean isInitial() {
        return parent.isInitial();
    }

    @Override
    public int getType() {
        return parent.getType();
    }

    @Override
    public String getProduct() {
        return parent.getProduct();
    }

    @Override
    public String getProjectGroup() {
        return parent.getProjectGroup();
    }

    @Override
    public String getDefaultRequest() {
        return parent.getDefaultRequest();
    }

    @Override
    public String getDefaultRequest(boolean query) throws CoreException {
        return parent.getDefaultRequest(query);
    }

    @Override
    public boolean isPartOfGroup() {
        return parent.isPartOfGroup();
    }

    @Override
    public boolean isWorkset() {
        return parent.isWorkset();
    }

    @Override
    public boolean isBaseline() {
        return parent.isBaseline();
    }

    @Override
    public boolean isSccStyle() {
        return parent.isSccStyle();
    }

    @Override
    public boolean isSBMEnabled() {
        return parent.isSBMEnabled();
    }

    @Override
    public VersionManagementProject getDimensionsObjectAdapter() throws DMException {
        return parent.getDimensionsObjectAdapter();
    }

    @Override
    public IContainer getRoot() {
        return parent.getRoot();
    }

    @Override
    public IPath getProjectRelativePath() {
        return parent.getProjectRelativePath();
    }

    @Override
    public IDMRemoteTree getRemoteTree() {
        return parent.getRemoteTree();
    }

    @Override
    public IPath getLocalPathForRemotePath(IPath path) {
        return parent.getLocalPathForRemotePath(path);
    }

    @Override
    public RepositoryFolder getRemoteRoot() throws DMException {
        return parent.getRemoteRoot();
    }

    @Override
    public RepositoryFolder getRemoteFolder(IPath remotePath, IProgressMonitor monitor) throws DMException {
        return parent.getRemoteFolder(remotePath, monitor);
    }

    @Override
    public List<DimensionsArObject> fetchMembers(RepositoryFolder folder, int types, int[] itemAttrs, boolean recursive,
            IProgressMonitor monitor) throws DMException {
        return parent.fetchMembers(folder, types, itemAttrs, recursive, monitor);
    }

    @Override
    public ItemRevision fetchFile(IPath path, int[] attrs, boolean fetchTypeProject, IProgressMonitor monitor) throws DMException {
        return parent.fetchFile(path, attrs, fetchTypeProject, monitor);
    }

    @Override
    public Map<IPath, ItemRevision> fetchFiles(Set<IPath> paths, int[] attrs, IProgressMonitor monitor) throws DMException {
        return parent.fetchFiles(paths, attrs, monitor);
    }

    @Override
    public Map<IPath, ItemRevision> fetchFiles(Set<IPath> paths, int[] attrs, boolean fetchTypeProject, IProgressMonitor monitor)
            throws DMException {
        return parent.fetchFiles(paths, attrs, fetchTypeProject, monitor);
    }

    @Override
    public InputStream getContents(IPath path, IProgressMonitor monitor) throws DMException {
        return parent.getContents(path, monitor);
    }

    @Override
    public File getTempCopy(IPath path, IProgressMonitor monitor) throws DMException {
        return parent.getTempCopy(path, monitor);
    }

    @Override
    public ItemRevision getItemRevisionProxy(String spec) throws DMException {
        return parent.getItemRevisionProxy(spec);
    }

    @Override
    public ItemRevision getItemRevisionProxy(ItemMetadata itemMetadata, IProgressMonitor monitor) throws DMException {
        return parent.getItemRevisionProxy(itemMetadata, monitor);
    }

    @Override
    public RepositoryFolder getRepositoryFolderProxy(IPath path) throws DMException {
        return parent.getRepositoryFolderProxy(path);
    }

    @Override
    public Map<String, List<ItemRevision>> expandItemRevisions(List<ItemRevision> revisions, int[] attrs, IProgressMonitor monitor)
            throws DMException {
        return parent.expandItemRevisions(revisions, attrs, monitor);
    }

    @Override
    public IPath getUserDirectory() {
        return parent.getUserDirectory();
    }

    @Override
    public IPath getRelativeLocation() {
        return parent.getRelativeLocation();
    }

    @Override
    public boolean remoteEquals(IDMProject otherProject, boolean offset) {
        return parent.remoteEquals(otherProject, offset);
    }

    @Override
    public boolean getIsStream() {
        return parent.getIsStream();
    }

    @Override
    public IPath getWorkAreaPath() {
        return parent.getWorkAreaPath();
    }

    @Override
    public boolean isFullWorkArea() {
        return parent.isFullWorkArea();
    }

    @Override
    public boolean isSingleEclipseProject() {
        return parent.isSingleEclipseProject();
    }

    @Override
    public boolean isContainedEclipseProject() {
        return parent.isContainedEclipseProject();
    }

    @Override
    public IStatus copyToWorkspace(IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus copyDirToWorkspace(IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus copyToWorkspace(IResource[] resources, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus copyToWorkspace(GetRevisionRequest[] requests, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus add(CreateItemRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus delete(DeleteItemRevisionRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus checkout(CheckoutRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus checkin(CheckinRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus undoCheckout(UndoCheckoutRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus upload(OperationData commandData, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus deliver(TransferToStreamOperationData commandData, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus download(DownloadRequest[] resources, boolean overwrite, boolean deleteUnmanaged, IProgressMonitor monitor)
            throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus download(CustomSubscriber subscriber, DownloadRequest[] resources, boolean overwrite, boolean deleteUnmanaged,
            IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus download(XMLMergeDescriptor descriptor, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public UploadItemDetails[] queryUploadRules(String[] filenames, String[] attrs, IProgressMonitor monitor) throws DMException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus createDirectories(CreateFolderRequest[] dirs, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus deleteDirectories(DeleteFolderRequest[] dirs, boolean deleteLocal, IProgressMonitor monitor)
            throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus updateFilename(UpdateFilenameRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus importFiles(ImportRequest[] files, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus resolveConflicts(ResolveConflictRequest[] conflicts, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IStatus move(IMoveRequest[] movedResources, IProgressMonitor monitor) throws CoreException {
        throw new UnsupportedOperationException();
    }
}
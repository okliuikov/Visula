/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TreeColumn;

/*
 * Listen for column resize events and updates the settings.
 *
 * @author V.Grishchenko
 */
class TableColumnListener extends ControlAdapter {
    private String columnName;
    private IDialogSettings settings;

    public TableColumnListener(String columnName, IDialogSettings settings) {
        this.columnName = columnName;
        this.settings = settings;
    }

    @Override
    public void controlResized(ControlEvent e) {
        int width = 5;
    	if (e.getSource() instanceof TreeColumn) {
        	width = ((TreeColumn) e.getSource()).getWidth();
        } else {
        	width = ((TableColumn) e.getSource()).getWidth();
        }
    	settings.put(columnName, width);	
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.CmRulesDetails;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DeleteFolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.DeleteItemRevisionRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFolder;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.Option;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;

/**
 * @author V.Grishchenko
 */
public class RemoveHelper extends TeamOperationWizardHelper {
    private static final String DELETE_LOCAL = "delete_local"; //$NON-NLS-1$
    private boolean deleteLocal;

    public RemoveHelper(IResource[] initialResources, IDMWorkspaceResourceFilter filter, IProgressMonitor monitor)
            throws CoreException {
        this(initialResources, filter, monitor, false); // do not delete local by default
    }

    public RemoveHelper(IResource[] initialResources, IDMWorkspaceResourceFilter filter, IProgressMonitor monitor,
            boolean deleteLocal) throws CoreException {
        super(initialResources, filter, monitor);
        this.deleteLocal = deleteLocal;
        initialize(monitor);
    }

    public boolean isDeleteLocal() {
        return deleteLocal;
    }

    @Override
    protected void populateMaps(Map<IResource, WorkspaceResourceRequest> requests,
            Map<IResource, IAttributeModel> attributes, IDMWorkspaceResource[] resources, IProgressMonitor monitor)
            throws CoreException {
        monitor = Utils.monitorFor(monitor);
        ArrayList<IDMWorkspaceFile> files = new ArrayList<IDMWorkspaceFile>();
        ArrayList<ItemRevision> revisions = new ArrayList<ItemRevision>();
        ArrayList<IDMWorkspaceResource> folders = new ArrayList<IDMWorkspaceResource>();
        for (int i = 0; i < resources.length; i++) {
            IDMWorkspaceResource res = resources[i];
            if (res.isContainer()) {
                folders.add(res);
            } else {
                IDMWorkspaceFile dmFile = (IDMWorkspaceFile) res;
                files.add(dmFile);
                revisions.add(dmFile.getRemoteFile().getItemRevision());
            }
        }

        try {
            DimensionsConnectionDetailsEx connection = getConnection();
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            //          monitor.subTask(Messages.CheckinHelper_1); //$NON-NLS-1$
            primeAttributesForCache(revisions, Utils.subMonitorFor(monitor, 10));

            // hit structure rules
            ArrayList<IDMWorkspaceResource> filesThenFolders = new ArrayList<IDMWorkspaceResource>(files.size() + folders.size());
            filesThenFolders.addAll(files);
            filesThenFolders.addAll(folders);
            int[] cmRulesResult = queryCmRules(CmRulesDetails.CMRULES_STRUCTURE, filesThenFolders, null, monitor);

            for (int i = 0; i < files.size(); i++) {
                IDMWorkspaceFile dmFile = files.get(i);
                ItemRevision revision = revisions.get(i);
                ItemType itemType = (ItemType) connection.getType(revision, Utils.subMonitorFor(monitor, 10)); // 10
                boolean requestReqd = cmRulesResult[i] > 0;
                DeleteItemRevisionRequest deleteRequest = new DeleteItemRevisionRequest(dmFile.getLocalFile(), itemType, revision,
                        requestReqd);
                deleteRequest.setDeleteLocal(deleteLocal);
                requests.put(dmFile.getLocalFile(), deleteRequest);
            }

            for (int i = 0; i < folders.size(); i++) {
                IDMWorkspaceFolder dmFold = (IDMWorkspaceFolder) folders.get(i);
                boolean requestReqd = cmRulesResult[files.size() + i] > 0;
                DeleteFolderRequest deleteRequest = new DeleteFolderRequest(dmFold.getLocalFolder(), requestReqd);
                // deleteRequest.setDeleteLocal(deleteLocal);
                requests.put(dmFold.getLocalResource(), deleteRequest);
            }
        } finally {
            monitor.done();
        }

    }

    @Override
    public void commit() throws CoreException {
        super.commit();
        Option[] removeOptions = getOptions();
        for (int j = 0; j < removeOptions.length; j++) {
            if (removeOptions[j].option == DELETE_LOCAL) {
                this.deleteLocal = removeOptions[j].getSelectedValue() == Option.YES;
            }
        }
        IFile[] files = getOperationFiles();
        for (int i = 0; i < files.length; i++) {
            DeleteItemRevisionRequest request = (DeleteItemRevisionRequest) getFileRequest(files[i]);
            request.setDeleteLocal(deleteLocal);
        }
    }

    @Override
    protected Option[] createOptions() {
        Option deleteLocalOption = new Option(DELETE_LOCAL, Messages.RemoveHelper_0, new Option.Value[] { Option.YES, Option.NO },
                (deleteLocal ? 0 : 1));
        return new Option[] { deleteLocalOption };
    }

    @Override
    public boolean includePhantoms() {
        return true;
    }

}

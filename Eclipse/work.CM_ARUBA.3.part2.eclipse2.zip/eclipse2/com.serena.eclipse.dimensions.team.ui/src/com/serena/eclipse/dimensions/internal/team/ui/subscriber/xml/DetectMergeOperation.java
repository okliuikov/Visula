/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.HashSet;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.MessageDialogWithToggle;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeManager;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantReference;
import org.eclipse.team.ui.synchronize.ISynchronizeView;
import org.eclipse.team.ui.synchronize.ResourceScope;
import org.eclipse.team.ui.synchronize.SyncInfoCompareInput;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.sync.SyncMode;
import com.serena.dmfile.xml.DetectedResolutions;
import com.serena.dmfile.xml.DetectedResolutionsContainer;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandOptions;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandOptions.MergeRequestsOptions;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandOptions.MergeWorksetOptions;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer.MergeType;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeSubscriber;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamPreferences;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.xml.XMLMergeSummaryDialog;
import com.serena.eclipse.dimensions.internal.team.ui.operations.DMOperation;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Operation that invokes merge command using a set of merge descriptors.
 */
public class DetectMergeOperation extends DMOperation {
    /**
     * do we need to show sync view with detected changes
     */
    private boolean showSyncView = false;

    private MergeDescriptorsContainer container;
    private XMLMergeParticipant participant;
    private XMLMergeSummaryDialog summary;

    /**
     * Opens dialog about switching to the interactive mode and resolve conflicts manually
     */
    private Runnable interactiveModePrompt = new Runnable() {

        @Override
        public void run() {
            StringBuilder fails = new StringBuilder();
            List<XMLMergeDescriptor> interactives = container.getAllInteractives();

            if (interactives.size() == 1) {
                fails.append(interactives.get(0).getTarget().getProject().getName());
            } else {
                for (Iterator<XMLMergeDescriptor> iterator = interactives.iterator(); iterator.hasNext();) {
                    fails.append(iterator.next().getTarget().getProject().getName());
                    if (iterator.hasNext()) {
                        fails.append(", "); //$NON-NLS-1$
                    }
                }
            }

            IPreferenceStore store = DMTeamUiPlugin.getDefault().getPreferenceStore();
            MessageDialogWithToggle dialog = MessageDialogWithToggle.openYesNoQuestion(getShell(),
                    Messages.DMXMLMergeOperation_silent_mode_failed_title, NLS.bind(interactives.size() == 1
                            ? Messages.DMXMLMergeOperation_silent_mode_failed_projects_single
                            : Messages.DMXMLMergeOperation_silent_mode_failed_projects_multiple, fails.toString()),
                    Messages.DMXMLMergeOperation_show_switch_always,
                    !store.getBoolean(IDMTeamPreferences.MERGE3W_SHOW_INTERACTIVE_SWITCH_PROMPT), store,
                    IDMTeamPreferences.MERGE3W_SHOW_INTERACTIVE_SWITCH_PROMPT);

            DetectMergeOperation.this.setShowSyncView(dialog.getReturnCode() == IDialogConstants.YES_ID ? true : false);
        }
    };

    public DetectMergeOperation(IWorkbenchPart part, MergeDescriptorsContainer container) {
        super(part);
        Assert.isNotNull(container);
        this.container = container;
        setShowSyncView(container.getBaseMode() == SyncMode.DETECT_RESOLUTIONS);
    }

    @Override
    protected ISchedulingRule getSchedulingRule() {
        Set<IResource> rulesSet = new HashSet<IResource>();
        for (XMLMergeDescriptor desc : container.getMergeDescriptors()) {
            IProject rootProject = desc.getTarget().getProject();
            Set<IProject> projects = TeamUtils.getAllProjectsForLocation(rootProject);
            rulesSet.addAll(projects);
        }
        return new MultiRule(rulesSet.toArray(new IResource[rulesSet.size()]));
    }

    /**
     * Download for every project in merge scope
     *
     * @param monitor
     * @param work
     * @throws CoreException
     */
    private void download(IProgressMonitor monitor) throws CoreException {
        if (container == null) {
            return;
        }
        if (container.getMergeDescriptors() == null) {
            return;
        }

        monitor.beginTask(null, container.getMergeDescriptors().size() * 100);

        try {
            List<XMLMergeDescriptor> descrs = container.getMergeDescriptors();
            for (XMLMergeDescriptor descr : descrs) {
                descr.getTarget().download(descr, Utils.subMonitorFor(monitor, 100));
                if (monitor.isCanceled()) {
                    break;
                }
            }

            if (container.getBaseMode() == SyncMode.NON_INTERACTIVE) {
                processSilentMergeResults(monitor);
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
        ISchedulingRule rule = getSchedulingRule();
        try {
            Job.getJobManager().beginRule(rule, monitor);

            int total = 100;
            int worked = 0;

            monitor.beginTask(null, total);

            if (!validateInput(Utils.subMonitorFor(monitor, worked += 5))) {
                return;
            }

            if (container.getBaseMode() == SyncMode.NON_INTERACTIVE) {
                // download in silent mode, reserve 10 ticks for possible sync view refresh
                download(Utils.subMonitorFor(monitor, worked += 85));
            } else if (container.getBaseMode() == SyncMode.DETECT_RESOLUTIONS) {
                // download in detect mode and reserve 40 ticks for possible workarea update and/or
                // sync view refresh
                download(Utils.subMonitorFor(monitor, worked += 55));
                if (isAnyWorkareaNeedsUpgrade()) {
                    if (!isWorkareaUpgradeConfirmed()) {
                        return;
                    }
                    setShowSyncView(false);
                    container.setBaseModeSilent();
                    // download in silent mode
                    download(Utils.subMonitorFor(monitor, worked += 30));
                }
            }

            if (monitor.isCanceled()) {
                return;
            }

            if (isShowSyncView()) {
                openSynchronizeView(Utils.subMonitorFor(monitor, Math.abs(total - worked)));
            }
        } finally {
            Job.getJobManager().endRule(rule);
            monitor.done();
        }
    }

    /**
     * Process non-interactive merge results if non-interactive merge was executed
     *
     * @throws TeamException
     */
    private void processSilentMergeResults(IProgressMonitor monitor) throws TeamException {
        if (container.getBaseMode() != SyncMode.NON_INTERACTIVE) {
            return;
        }

        ISynchronizeManager manager = TeamUI.getSynchronizeManager();
        try {
            // remove stale merge view
            ISynchronizeParticipantReference[] participants = manager.getSynchronizeParticipants();
            for (int i = 0; i < participants.length; i++) {
                if (participants[i].getId().equals(XMLMergeParticipant.ID)) {
                    manager.removeSynchronizeParticipants(new ISynchronizeParticipant[] { participants[i].getParticipant() });
                }
            }

            // show summary if needed
            if (DMTeamUiPlugin.getDefault().isShowMergeSummary() && (container.hasAppliedChanges() || container.isInSync())) {
                this.summary = new XMLMergeSummaryDialog(getShell(), container, getTaskName() + "\n\n", !isDoUpdate());//$NON-NLS-1$

                Display.getDefault().asyncExec(new Runnable() {

                    @Override
                    public void run() {
                        summary.open();
                    }
                });

            }

            if (monitor.isCanceled()) {
                return;
            }

            // show prompt if conflicts were detected
            IPreferenceStore store = DMTeamUiPlugin.getDefault().getPreferenceStore();
            if (container.isSilentModeFailed()) {
                setShowSyncView(true);
                boolean prompt = store.getBoolean(IDMTeamPreferences.MERGE3W_SHOW_INTERACTIVE_SWITCH_PROMPT);
                if (prompt) {
                    Display.getDefault().syncExec(interactiveModePrompt);
                }

                if (isShowSyncView()) {
                    prepareResultsForDisplay();
                }
            }
        } finally {
            XMLMergeUIUtils.syncWithHome(container, null, !isShowSyncView());
        }
    }

    /**
     * Switch general result to DETECT mode
     */
    private void prepareResultsForDisplay() {
        if (container == null) {
            return;
        }
        if (container.getMergeDescriptors() == null) {
            return;
        }

        List<XMLMergeDescriptor> descrs = container.getMergeDescriptors();
        for (XMLMergeDescriptor descr : descrs) {
            descr.setCurrentMode(SyncMode.DETECT_RESOLUTIONS);

            DetectedResolutionsContainer con = descr.getDetectedResolutionsContainer();
            DetectedResolutions detected = descr.getDetectedResolutions();

            if (con == null) {
                continue;
            }

            if (detected != null) {
                if (con.hasFailedExecutions()) {
                    detected.setResolutions(con.getFailedResolutions());
                } else if (con.getExecutedResolutions() != null) {
                    detected.setResolutions(null);
                }
            }

            con.setExecutedResolutions(null);
        }
    }

    /**
     * Opens synchronize view with results that were obtained from server
     *
     * @param monitor
     */
    private void openSynchronizeView(IProgressMonitor monitor) {
        if (container == null) {
            return;
        }
        if (container.getMergeDescriptors() == null) {
            return;
        }

        final XMLMergeSubscriber subscriber = new XMLMergeSubscriber(container);

        IResource[] scope = container.getResourceScope();
        participant = new XMLMergeParticipant(subscriber, new ResourceScope(scope), ISynchronizePageConfiguration.INCOMING_MODE);

        String name = ""; //$NON-NLS-1$
        if (isDoUpdate()) {
            name = Messages.DMXMLUpdateParticipant_short_name;
        } else {
            name = Messages.DMXMLMergeParticipant_short_name;
        }

        monitor.beginTask(null, 100);

        try {
            IStatus status = participant.refreshNow(scope, name, Utils.subMonitorFor(monitor, 100));
            if (!status.isOK()) {
                DMTeamUiPlugin.log(status);
                return;
            }

            final ISynchronizeManager manager = TeamUI.getSynchronizeManager();
            XMLMergeParticipantListener listener = new XMLMergeParticipantListener();

            manager.addSynchronizeParticipantListener(listener);
            subscriber.addListener(listener);
            ResourcesPlugin.getWorkspace().addResourceChangeListener(subscriber, IResourceChangeEvent.POST_CHANGE);

            Display.getDefault().syncExec(new Runnable() {

                @Override
                public void run() {
                    manager.addSynchronizeParticipants(new ISynchronizeParticipant[] { participant });
                    ISynchronizeView view = manager.showSynchronizeViewInActivePage();
                    if (view != null) {
                        view.display(participant);
                    }

                    IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
                    if (page != null) {
                        page.closeEditors(findStaleCompareEditors(subscriber, page), true);
                    }
                }
            });
        } finally {
            monitor.done();
        }
    }

    private IEditorReference[] findStaleCompareEditors(XMLMergeSubscriber subscriber, IWorkbenchPage page) {
        List<IDMProject> projects = subscriber.getDescriptorsContainer().getAllTargetProjects();
        Map<SyncInfo, IEditorReference> infos = findSyncInfoInCompare(page);
        List<IEditorReference> result = new ArrayList<IEditorReference>();

        for (Entry<SyncInfo, IEditorReference> e : infos.entrySet()) {
            SyncInfo info = e.getKey();
            for (IDMProject project : projects) {
                if (project.getProject().getFullPath().isPrefixOf(info.getLocal().getFullPath())) {
                    if ((info.getKind() & SyncInfo.DIRECTION_MASK) != SyncInfo.OUTGOING) {
                        result.add(e.getValue());
                    }
                }
            }
        }

        return result.toArray(new IEditorReference[result.size()]);
    }

    private Map<SyncInfo, IEditorReference> findSyncInfoInCompare(IWorkbenchPage page) {
        Map<SyncInfo, IEditorReference> result = new HashMap<SyncInfo, IEditorReference>();

        if (page != null) {
            IEditorReference[] editorReferences = page.getEditorReferences();
            for (IEditorReference ref : editorReferences) {
                IEditorInput input;
                try {
                    input = ref.getEditorInput();
                    if (input instanceof SyncInfoCompareInput) {
                        SyncInfoCompareInput syncInput = (SyncInfoCompareInput) input;
                        SyncInfo syncInfo = syncInput.getSyncInfo();
                        if (syncInfo != null) {
                            result.put(syncInfo, ref);
                        }
                    }
                } catch (PartInitException e) {
                    DMTeamUiPlugin.log(e.getStatus());
                }
            }
        }

        return result;
    }

    /**
     * Check if we have a scope dir in foreign stream/baseline
     *
     * @param monitor
     * @throws DMException
     * @return true if valid
     */
    private boolean validateInput(IProgressMonitor monitor) throws DMException {
        if (container == null) {
            return false;
        }
        if (container.getMergeDescriptors() == null) {
            return false;
        }

        List<XMLMergeDescriptor> descrs = container.getMergeDescriptors();
        monitor.beginTask(null, descrs.size() * 100);

        try {
            for (XMLMergeDescriptor descr : descrs) {
                IPath scopePath = getMergeScopePath(descr);
                if (scopePath != null && !isValidScope(descr, scopePath, Utils.subMonitorFor(monitor, 100))) {
                    final String msg = NLS.bind(descr.getMergeType() == MergeType.BASELINE
                            ? Messages.DMXMLMergeOperation_baseline_dir_miss_warning
                            : Messages.DMXMLMergeOperation_project_dir_miss_warning, descr.getSourceWorksetSpec(),
                            scopePath.toOSString());

                    DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamPlugin.ID, msg));

                    Display.getDefault().asyncExec(new Runnable() {

                        @Override
                        public void run() {
                            String name = (isDoUpdate() ? Messages.DMXMLUpdate_name : Messages.DMXMLMerge_name);
                            MessageDialog.openWarning(getShell(), name, msg);
                        }
                    });

                    return false;
                }

                if (monitor.isCanceled()) {
                    return false;
                }
            }
        } finally {
            monitor.done();
        }

        return true;
    }

    /**
     * Returns true if path exists in the remote project
     *
     * @param descriptor
     *            merge descriptor
     * @param scopePath
     *            path to check
     * @param monitor
     * @return true if valid
     * @throws DMException
     */
    private boolean isValidScope(final XMLMergeDescriptor descriptor, final IPath scopePath, final IProgressMonitor monitor)
            throws DMException {
        if (scopePath != null && descriptor.getSourceWorkset() != null) {
            if (descriptor.getTarget().getRemoteOffset().isEmpty() && descriptor.getScope().isEmpty()) {
                return true;
            }

            final Session session = descriptor.getTarget().getConnection().openSession(monitor);
            final boolean[] valid = new boolean[] { true, };
            MergeType type = descriptor.getMergeType();

            if (type == MergeType.PROJECT || type == MergeType.REQUEST) {
                final Long[] treeVersion = { null };
                if (type == MergeType.PROJECT && ((MergeWorksetOptions) descriptor.getMergeOptions()).getChangeSet() != null) {
                    treeVersion[0] = ((MergeWorksetOptions) descriptor.getMergeOptions()).getChangeSet()
                            .getRepositoryVersion()
                            .getTreeVersion();
                }

                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        DimensionsArObject apiObject = descriptor.getSourceWorkset().getAPIObject();
                        if (!(apiObject instanceof Project)) {
                            valid[0] = false;
                            return;
                        }

                        Project project = (Project) apiObject;
                        List<String> folderPaths = project.queryChildFolderPaths(treeVersion[0]);
                        valid[0] = containsScopePath(folderPaths, scopePath);
                    }
                }, monitor);
            } else if (type == MergeType.BASELINE) {
                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        DimensionsArObject apiObject = descriptor.getSourceWorkset().getAPIObject();
                        if (!(apiObject instanceof Baseline)) {
                            valid[0] = false;
                            return;
                        }

                        Baseline baseline = (Baseline) apiObject;
                        List<String> folderPaths = baseline.queryChildFolderPaths();
                        valid[0] = containsScopePath(folderPaths, scopePath);
                    }
                }, monitor);
            }

            return valid[0];
        }
        return true;
    }

    private boolean isWorkareaUpgradeConfirmed() {
        final boolean[] result = new boolean[] { false };
        Display.getDefault().syncExec(new Runnable() {

            @Override
            public void run() {
                result[0] = MessageDialog.openConfirm(getShell(), Messages.DMXMLUpdate_name,
                        Messages.DMXMLMergeOperation_upgrade_outdated_workareas);
            }
        });

        return result[0];
    }

    /**
     * @return true if any descriptor has information about outdated workarea metadata
     */
    private boolean isAnyWorkareaNeedsUpgrade() {
        if (container == null) {
            return false;
        }
        if (container.getMergeDescriptors() == null) {
            return false;
        }

        List<XMLMergeDescriptor> mergeDescriptors = container.getMergeDescriptors();
        for (XMLMergeDescriptor descr : mergeDescriptors) {
            DetectedResolutions resolutions = descr.getDetectedResolutions();
            if (resolutions != null && resolutions.isWorkareaNeedsUpgrade()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Calculates path of local directory aka scope that should be exist in the repository
     *
     * @param descriptor
     *            that contains scope information
     * @return path to check
     */
    private IPath getMergeScopePath(XMLMergeDescriptor descriptor) {
        IPath checkPath = null;
        IDMProject target = descriptor.getTarget();

        // set a root offset as a scope path if exists
        if (!target.getRemoteOffset().isEmpty()) {
            checkPath = descriptor.getTarget().getRemoteOffset();
        }

        // try to set a scope offset as a scope path if exists, if one and if folder scope (tree
        // shape)
        if (!descriptor.getScope().isEmpty() && descriptor.getScope().size() == 1) {
            IResource resource = descriptor.getScope().get(0);
            if (resource instanceof IFolder) {
                if (!target.getRemoteOffset().isEmpty()) {
                    checkPath = target.getRemoteOffset().append(resource.getProjectRelativePath());
                } else {
                    checkPath = resource.getProjectRelativePath();
                }
            }
        } else if (!descriptor.getScope().isEmpty()) {
            // drop scope path if scopes contain more than one resource (list shape)
            checkPath = null;
        }

        return checkPath;
    }

    /**
     * Check whether a given remote path exists in the list of all possible folder paths
     *
     * @param folderPaths
     *            - a list of all possible folder paths
     * @param remotePath
     *            - a path to check
     *
     * @return true if a path given is included in the list of all possible folder paths
     */
    private boolean containsScopePath(List<String> folderPaths, IPath remotePath) {
        IPath path = null;

        for (String folderPathStr : folderPaths) {
            if (Utils.isNullEmpty(folderPathStr)) {
                path = Path.EMPTY;
            } else {
                path = new Path(folderPathStr);
            }

            if (remotePath.equals(path)) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected String getTaskName() {
        String taskName = null;

        StringBuilder targets = new StringBuilder();
        List<IDMProject> allTargets = container.getAllTargetProjects();
        if (allTargets.size() == 1) {
            targets.append(allTargets.get(0).getProject().getName());
        } else {
            for (Iterator<IDMProject> iterator = allTargets.iterator(); iterator.hasNext();) {
                targets.append(iterator.next().getProject().getName());
                if (iterator.hasNext()) {
                    targets.append(", "); //$NON-NLS-1$
                }
            }
        }

        MergeCommandOptions opts = container.getMergeOptions();
        if (opts instanceof MergeWorksetOptions) {
            MergeWorksetOptions wopts = (MergeWorksetOptions) opts;
            String source = wopts.getSourceWorksetSpec();
            if (wopts.isBaseline()) {
                if (allTargets.size() == 1) {
                    taskName = NLS.bind(Messages.DMXMLMergeOperation_task_baseline_name_single, new String[] { targets.toString(),
                            source });
                } else {
                    taskName = NLS.bind(Messages.DMXMLMergeOperation_task_baseline_name_multiple, new String[] {
                            targets.toString(), source });
                }
            } else {
                if (allTargets.size() == 1) {
                    String name = (isDoUpdate()
                            ? Messages.DMXMLUpdateOperation_task_project_name_single
                            : Messages.DMXMLMergeOperation_task_project_name_single);
                    taskName = NLS.bind(name, new String[] { targets.toString(), source });
                } else {
                    String name = (isDoUpdate()
                            ? Messages.DMXMLUpdateOperation_task_project_name_multiple
                            : Messages.DMXMLMergeOperation_task_project_name_multiple);
                    taskName = NLS.bind(name, new String[] { targets.toString(), source });
                }
            }
        } else if (opts instanceof MergeRequestsOptions) {
            List<Request> requests = ((MergeRequestsOptions) opts).getSourceRequests();

            StringBuilder sb = new StringBuilder();
            if (requests != null) {
                for (Iterator<Request> iterator = requests.iterator(); iterator.hasNext();) {
                    Request request = iterator.next();
                    String spec = (String) request.getAttribute(SystemAttributes.OBJECT_SPEC);
                    sb.append(spec);
                    if (iterator.hasNext()) {
                        sb.append(", ");//$NON-NLS-1$
                    }
                }
            }

            if (allTargets.size() == 1) {
                String name = (isDoUpdate()
                        ? Messages.DMXMLUpdateOperation_task_request_name_single
                        : Messages.DMXMLMergeOperation_task_request_name_single);
                taskName = NLS.bind(name, new String[] { targets.toString(), sb.toString() });
            } else {
                String name = (isDoUpdate()
                        ? Messages.DMXMLUpdateOperation_task_request_name_multiple
                        : Messages.DMXMLMergeOperation_task_request_name_multiple);
                taskName = NLS.bind(name, new String[] { targets.toString(), sb.toString() });
            }
        }
        return taskName;
    }

    /**
     * @return the showMergeView
     */
    public boolean isShowSyncView() {
        return showSyncView;
    }

    /**
     * @param showSyncView
     *            the showMergeView to set
     */
    public void setShowSyncView(boolean showSyncView) {
        this.showSyncView = showSyncView;
    }

    /**
     * @return the doUpdate
     */
    public boolean isDoUpdate() {
        if (container != null && container.getMergeOptions() != null) {
            return container.getMergeOptions().isDoUpdate();
        }
        return false;
    }

}

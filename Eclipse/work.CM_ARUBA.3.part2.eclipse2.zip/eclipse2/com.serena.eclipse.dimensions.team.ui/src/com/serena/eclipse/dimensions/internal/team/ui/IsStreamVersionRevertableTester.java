package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;

import com.serena.dmclient.api.DimensionsChangeSet;

public class IsStreamVersionRevertableTester extends PropertyTester {
    public static final String IS_STREAM_VERSION_REVERTABLE = "isStreamVersionRevertable"; //$NON-NLS-1$

    public IsStreamVersionRevertableTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (!(receiver instanceof StructuredSelection)) {
            return false;
        }
        StructuredSelection ss = (StructuredSelection) receiver;
        Object selected = ss.getFirstElement();
        if (!(selected instanceof DimensionsChangeSet)) {
            return false;
        }
        DimensionsChangeSet cs = (DimensionsChangeSet) selected;
        if (property.equals(IS_STREAM_VERSION_REVERTABLE)) {
            return getIsStreamChangesetRevertable(cs.getOperationType());
        } else {
            return false;
        }
    }

    private boolean getIsStreamChangesetRevertable(int operationType) {
        // All real changes (deliveries, merges, undo's, promotions, demotions or build output collections) for streams are
        // revertable.
        switch (operationType) {
        case DimensionsChangeSet.OP_UNKNOWN: // Operation type is not known
        case DimensionsChangeSet.OP_DELIVER: // Deliver
        case DimensionsChangeSet.OP_MERGE: // Merge
        case DimensionsChangeSet.OP_PROMOTION: // Promotion
        case DimensionsChangeSet.OP_DEMOTION: // Demotion
        case DimensionsChangeSet.OP_BLD_COLLECTION: // Build output collection
        case DimensionsChangeSet.OP_SHELF: // Shelf
        case DimensionsChangeSet.OP_UNDO: // Undo
            return true;
        default:
            return false;
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.osgi.util.NLS;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Wizard to select a remote counter part for 2-way local to remote compare.
 *
 * @author V.Grishchenko
 */
public class CompareWizard extends DimensionsWizard {
    private static final String SELECT_REMOTE_PAGE = "sel_rmt"; //$NON-NLS-1$

    private IProject local;
    private IResource[] resources;
    private DimensionsConnectionDetailsEx connection;
    private ProjectSelectionPage selectRemotePage;
    private VersionManagementProject remote; // selected project
    private IPath defaultOffset;

    public CompareWizard(IProject local, IResource[] resources, DimensionsConnectionDetailsEx connection, boolean pin) {
        Assert.isNotNull(local);
        Assert.isNotNull(resources);
        Assert.isNotNull(connection);
        this.local = local;
        this.resources = resources;
        this.connection = connection;
        setWindowTitle(NLS.bind(Messages.CompareWizard_title, local.getName()));
        setNeedsProgressMonitor(true);
    }

    /**
     * Sets scc offset used when preselecting an scc project from a found project
     * or baseline.
     * @param defaultOffset The defaultOffset to set.
     */
    public void setDefaultOffset(IPath defaultOffset) {
        this.defaultOffset = defaultOffset;
    }

    @Override
    public void addPages() {
        selectRemotePage = new ProjectSelectionPage(SELECT_REMOTE_PAGE, Messages.CompareWizard_selectRmtPageTitle,
                Messages.CompareWizard_selectRmtPageTitleDesc, null, false, false);
        selectRemotePage.setAllowBaselines(true);
        selectRemotePage.setAllowWorksets(true);
        selectRemotePage.setAllowNull(false);
        selectRemotePage.setConnection(connection);
        selectRemotePage.setDefaultOffset(defaultOffset);
        addPage(selectRemotePage);
    }

    @Override
    public boolean performFinish() {
        remote = selectRemotePage.getSelection()[0];
        if (remote == null) {
            return false;
        }

        final IDMProject[] remoteProject = new IDMProject[1];
        try {
            getContainer().run(true, false, new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    monitor = Utils.monitorFor(monitor);
                    monitor.beginTask(Messages.CompareWizard_initializing, IProgressMonitor.UNKNOWN);
                    try {
                        remoteProject[0] = DMRepositoryProvider.createProject(remote, local, null);
                    } catch (CoreException e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e1) {
            DMTeamUiPlugin.getDefault().handle(e1);
            return false;
        } catch (InterruptedException e1) {
            return true;
        }

        DMTeamUiPlugin.getDefault().compare(new IProject[] { local }, new IResource[][] { resources }, remoteProject);
        return true;
    }

}

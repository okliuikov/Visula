/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ActionWizard;

/**
 * @author V.Grishchenko
 */
public class ActionItemAction extends DMWorkspaceAction {

    private static final IDMWorkspaceResourceFilter MY_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED
            | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);

    public ActionItemAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources = getSelectedResources();
        if (resources == null || resources.length == 0) {
            return;
        }

        try {
            List selectedItems = new ArrayList();
            for (int i = 0; i < resources.length; i++) {
                if (resources[i].getType() != IResource.FILE) {
                    continue;
                }
                IFile aFile = (IFile) resources[i];
                IDMRemoteFile baseRev = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(aFile);
                DimensionsConnectionDetailsEx conn = baseRev.getProject().getConnection();
                ItemRevision itemRevision = baseRev.getItemRevision();
                selectedItems.add(new ItemRevisionAdapter(itemRevision, conn));
            }

            if (!selectedItems.isEmpty()) {
                ItemRevisionAdapter[] adapters = (ItemRevisionAdapter[]) selectedItems.toArray(new ItemRevisionAdapter[selectedItems.size()]);
                ActionWizard wizard = new ActionWizard(adapters);
                WizardDialog dialog = new WizardDialog(getShell(), wizard);
                dialog.open();
            }
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return MY_FILTER;
    }

}

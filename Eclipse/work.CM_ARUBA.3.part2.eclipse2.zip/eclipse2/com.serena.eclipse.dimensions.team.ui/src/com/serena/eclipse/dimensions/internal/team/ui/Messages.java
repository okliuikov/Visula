/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.osgi.util.NLS;

/**
 * NLS convenience methods for the plugin.
 *
 * @author V.Grishchenko
 */
public class Messages extends NLS {
    private static final String BUNDLE_NAME = "com.serena.eclipse.dimensions.internal.team.ui.messages"; //$NON-NLS-1$

    static {
        NLS.initializeMessages(BUNDLE_NAME, Messages.class);
    }

    public static String common_noneText;

    public static String Dialog_title;

    public static String err_error;
    public static String err_genericMsg;
    public static String err_durulesNotFound;
    public static String err_durulesIncludeNotFound;
    public static String err_openObjEditor;
    public static String err_addEditorPage;

    public static String nameAndRevision;

    public static String SharingWizard_mavenProjectIsNotResolved;

    public static String SharingWizard_mavenProjectIsVirtual;

    // workset selection wizard page
    public static String SharingWizard_projectSelectPageDesc;
    public static String newWorkset_text;
    public static String newStreamBtn_text;
    public static String newTopicStreamBtn_text;
    public static String newWorkset_createInContainer;

    // new baseline wizard pages
    public static String newBaselinePage_productLabel;
    public static String newBaselinePage_wstTypeLabel;
    public static String newBaselinePage_blnLabel;
    public static String newBaselinePage_ideProject;
    public static String newBaselinePage_browse;
    public static String newBaselinePage_Base;
    public static String newBaselinePage_wsNameSep;
    public static String newBaselinePage_blNameSep;
    public static String newBaselinePage_productRequired;
    public static String newBaselinePage_typeRequired;
    public static String newBaselinePage_basedRequired;
    public static String newBaselinePage_scmRequired;
    public static String newBaselinePage_containerRequired;
    public static String newBaselinePage_badId;
    public static String newBaselinePage_noId;
    public static String newBaselinePage_selectBaseObject_title;

    // Relate page
    public static String newBaselineRelatePage_title;
    public static String newBaselineRelatePage_desc;
    public static String newBaselineRelatePage_desctip;
    public static String newBaselineRelatePage_relatedRequestsLabel;
    public static String newBaselineRelatePage_relatedRequestsLabel1;
    public static String newBaselineRelatePage_traverseLabel;
    public static String newBaselineRelatePage_includeClosedLabel;
    public static String newBaselineRelatePage_includeInfoLabel;
    public static String newBaselineRelatePage_norequests;

    // Template page
    public static String newBaselineTemplatePage_title;
    public static String newBaselineTemplatePage_desc;
    public static String newBaselineTemplatePage_templateLabel;
    public static String newBaselineTemplatePage_topPartLabel;
    public static String newBaselineTemplatePage_levelsTitle;
    public static String newBaselineTemplatePage_allLevels;
    public static String newBaselineTemplatePage_Levels;
    public static String newBaselineTemplatePage_validPart;

    // revise page
    public static String newBaselineRevisePage_title;
    public static String newBaselineRevisePage_desc;
    public static String newBaselineRevisePage_updateRequestsLabel;
    public static String newBaselineRevisePage_removeRequestsLabel;
    public static String newBaselineRevisePage_scope;
    public static String newBaselineRevisePage_norequests;

    // New Stream/Project/Baseline details page
    public static String NewStreamDetailsPage_btnSelectTitle;
    public static String NewStreamDetailsPage_checkSpecProjectVerTitle;
    public static String NewStreamDetailsPage_checkSpecStreamVerTitle;
    public static String NewStreamDetailsPage_dialogProjectVerTitle;
    public static String NewStreamDetailsPage_dialogStreamVerTitle;
    public static String NewStreamDetailsPage_incorrectProjectVerMessage;
    public static String NewStreamDetailsPage_incorrectStreamVerMessage;
    public static String NewStreamDetailsPage_enterProjectVerMessage;
    public static String NewStreamDetailsPage_enterStreamVerMessage;
    public static String NewStreamDetailsPage_latest_stream_ver;

    // new Stream or Project
    public static String NewStreamWizard_title_stream;
    public static String NewStreamWizard_title_project;
    public static String NewStreamWizard_dbOptError_streamDisallowed;
    public static String NewStreamWizard_dbOptError_projectDisallowed;
    public static String NewStreamWizard_welcome_title;
    public static String NewStreamWizard_welcome_description;
    public static String NewStreamWizard_welcome_btnStream;
    public static String NewStreamWizard_welcome_lblStream;
    public static String NewStreamWizard_welcome_btnProject;
    public static String NewStreamWizard_stream_general_title;
    public static String NewStreamWizard_stream_general_description;
    public static String NewStreamWizard_stream_general_lblProject_1;
    public static String NewStreamWizard_stream_general_lblProjectName;
    public static String NewStreamWizard_stream_general_lblType;
    public static String NewStreamWizard_stream_general_lblDescription;
    public static String NewStreamWizard_stream_general_lblBranchName;
    public static String NewStreamWizard_stream_general_lblBranchExample;
    public static String NewStreamWizard_stream_general_lblOffset;
    public static String NewStreamWizard_stream_general_lblWork_area_root;
    public static String NewStreamWizard_stream_general_lblPart;
    public static String NewStreamWizard_stream_general_btnAdvanced_show;
    public static String NewStreamWizard_stream_general_btnAdvanced_hide;
    public static String NewStreamWizard_stream_general_chkAddStream2favoritesList;

    public static String NewStreamWizard_stream_general_chkResetWorkarea;
    public static String NewStreamWizard_stream_general_err1;
    public static String NewStreamWizard_stream_general_name_is_required;
    public static String NewStreamWizard_stream_general_err3;
    public static String NewStreamWizard_stream_general_err4;
    public static String NewStreamWizard_stream_general_err5;
    public static String NewStreamWizard_stream_general_err6;
    public static String NewStreamWizard_stream_general_err7;
    public static String NewStreamWizard_stream_general_err8;
    public static String NewStreamWizard_stream_general_err9;
    public static String NewStreamWizard_stream_general_err10;
    public static String NewStreamWizard_stream_general_err11;
    public static String NewStreamWizard_stream_details_title;
    public static String NewStreamWizard_stream_details_description;
    public static String NewStreamWizard_stream_details_lblBasedOn;
    public static String NewStreamWizard_stream_details_btnBasedOnBaseline;
    public static String NewStreamWizard_stream_details_btnNothing;
    public static String NewStreamWizard_stream_details_lblRules;
    public static String NewStreamWizard_stream_details_chkValidReq;
    public static String NewStreamWizard_stream_details_err1;
    public static String NewStreamWizard_stream_details_err2;
    public static String NewStreamWizard_stream_details_err3;
    public static String NewStreamWizard_stream_offset_err1;
    public static String NewStreamWizard_stream_offset_err2;
    public static String NewStreamWizard_stream_offset_err3;
    public static String NewStreamWizard_stream_offset_err4;
    public static String NewStreamWizard_stream_offset_err5;
    public static String NewStreamWizard_stream_offset_err6;
    public static String NewStreamWizard_stream_attr_title;
    public static String NewStreamWizard_stream_attr_description;
    public static String NewStreamWizard_project_general_title;
    public static String NewStreamWizard_project_general_description;
    public static String NewStreamWizard_project_general_lblProject_1;
    public static String NewStreamWizard_project_general_lblProjectName;
    public static String NewStreamWizard_project_general_lblDescription;
    public static String NewStreamWizard_project_general_lblPrjGroupName;
    public static String NewStreamWizard_project_general_chkAddProject2favoritesList;
    public static String NewStreamWizard_project_details_title;
    public static String NewStreamWizard_project_details_lblBasedOnStreamOrProject;
    public static String NewStreamWizard_project_details_btnBasedOnBaseline;
    public static String NewStreamWizard_project_details_btnNothing;
    public static String NewStreamWizard_project_details_description;
    public static String NewStreamWizard_project_options_title;
    public static String NewStreamWizard_project_options_description;
    public static String NewStreamWizard_project_options_lblVMOptions;
    public static String NewStreamWizard_project_options_lblVMDescr;
    public static String NewStreamWizard_project_options_btnBranch;
    public static String NewStreamWizard_project_options_btnNotBranch;
    public static String NewStreamWizard_project_options_btnOverrideRevNum;
    public static String NewStreamWizard_project_options_lblCMRules;
    public static String NewStreamWizard_project_options_lblCMDescr;
    public static String NewStreamWizard_project_options_btnUseItem;
    public static String NewStreamWizard_project_options_btnAlwaysEnable;
    public static String NewStreamWizard_project_options_btnAlwaysDisable;
    public static String NewStreamWizard_project_options_chkRequestRequired;
    public static String NewStreamWizard_project_branches_title;
    public static String NewStreamWizard_project_branches_description;
    public static String NewStreamWizard_project_branches_lblValidBranches;
    public static String NewStreamWizard_project_branches_lblDefaultBranch;
    public static String NewStreamWizard_project_attr_title;
    public static String NewStreamWizard_project_attr_description;
    public static String NewStreamWizard_generic_request_err1;
    public static String NewStreamWizard_summary_title;
    public static String NewStreamWizard_summary_description;
    public static String NewStreamWizard_summary_lblClickToFinish;
    public static String NewStreamWizard_summary_stream1;
    public static String NewStreamWizard_summary_stream2;
    public static String NewStreamWizard_summary_basedOnInfo;
    public static String NewStreamWizard_summary_stream3_stream;
    public static String NewStreamWizard_summary_stream3_baseline;
    public static String NewStreamWizard_summary_stream4;
    public static String NewStreamWizard_summary_stream5;
    public static String NewStreamWizard_summary_stream5_enabled;
    public static String NewStreamWizard_summary_stream5_disabled;
    public static String NewStreamWizard_summary_stream6;
    public static String NewStreamWizard_summary_project1;
    public static String NewStreamWizard_summary_project2;
    public static String NewStreamWizard_summary_project3_project;
    public static String NewStreamWizard_summary_project3_baseline;
    public static String NewStreamWizard_summary_project4;
    public static String NewStreamWizard_summary_project4_not;
    public static String NewStreamWizard_summary_project5;
    public static String NewStreamWizard_summary_project5_not;
    public static String NewStreamWizard_summary_project6;
    public static String NewStreamWizard_summary_project6_inherited;
    public static String NewStreamWizard_summary_project6_enabled;
    public static String NewStreamWizard_summary_project6_disabled;
    public static String NewStreamWizard_summary_project7;
    public static String NewStreamWizard_summary_project7_require;
    public static String NewStreamWizard_summary_project7_notrequire;
    public static String NewStreamWizard_summary_project10;
    public static String NewStreamWizard_summary_project11;
    public static String NewStreamWizard_summary_project12;

    // new group wizard
    public static String NewGroupWizard_title;
    public static String NewGroupWizard_members_title;
    public static String NewGroupWizard_members_description;
    public static String NewGroupWizard_groupcontents_selected;
    public static String NewGroupWizard_groupcontents_title;
    public static String NewGroupWizard_containercontents_title;
    // new baseline wizard
    public static String NewBaselineWizard_title;
    public static String NewBaselineWizard_tip_title;
    public static String NewBaselineWizard_tip_description;
    public static String NewBaselineWizard_template_title;
    public static String NewBaselineWizard_template_description;
    public static String NewBaselineWizard_revised_title;
    public static String NewBaselineWizard_revised_description;

    public static String NewBaselineWizard_attr_title;
    public static String NewBaselineWizard_attr_description;

    // disconnect provider action
    public static String unmapProvider_message;
    public static String unmapProvider_messageMulti;
    public static String unmapProvider_keepMeta;
    public static String unmapProvider_nokeepMeta;
    public static String unmapProvider_title;
    public static String unmapProvider_titleMulti;

    // project string
    public static String projectString_project;
    public static String projectString_baseline;
    public static String projectString_multi;

    // DM operation
    public static String DMOperation_msg;
    public static String DMOperation_errSep;

    // add to wsp operation
    public static String markersSearch_msg;
    public static String addSingleProjectOperation_taskName;
    public static String addMultipleProjectsOperation_taskName;
    public static String addConfirmOverwrite_prompt;
    public static String addConfirmOverwriteExtFolder_prompt;
    public static String addScrubProject_msg;
    public static String addGroupToWorkspace_title;
    public static String addGroupToWorkspace_description;
    public static String addToWorkspaceOperation_connectionLost;
    public static String couldNotMoveProject;
    public static String movingProjectError;

    // disconnect provider operation
    public static String unmapProviderOp_task;
    public static String unmapProviderOp_providerTask;

    // preferences
    // main page
    public static String teamPrefPage_descr;
    public static String teamPrefPage_deleteOnReplace;
    public static String teamPrefPage_ignoreDerivedResources;
    public static String teamPrefPage_considerContents;
    public static String teamPrefPage_findAncestor;
    public static String teamPrefPage_syncOnSwithingForeign;
    public static String teamPrefPage_preselectDefaultRequests;
    public static String teamPrefPage_cleanTimestamps;
    public static String teamPrefPage_undoCoutCinUmod;
    public static String teamPrefPage_showProjectCommit;
    public static String teamPrefPage_useActivated;
    public static String teamPrefPage_deactivateRequests;
    public static String teamPrefPage_expandVariables;
    public static String teamPrefPage_autoShare;

    // appearance page
    public static String appearancePrefPage_descr;
    public static String appearancePrefPage_saveDirtyGroup;
    public static String appearancePrefPage_saveDirtyNever;
    public static String appearancePrefPage_saveDirtyPrompt;
    public static String appearancePrefPage_saveDirtyAuto;
    public static String appearancePrefPage_projShowIn;
    public static String appearancePrefPage_projShowInEditor;
    public static String appearancePrefPage_projShowInView;
    public static String appearancePrefPage_projUseMultipage;
    public static String appearancePrefPage_projAutoDefault;
    public static String appearancePrefPage_maxCommentHistory;
    public static String appearancePrefPage_maxCommentErrMsg;

    // automerge page
    public static String projectPrefPage_descr;
    public static String projectPrefPage_allowUpdateAutoMerge;

    // decorator page
    public static String decoratorPrefPage_descr;
    public static String decoratorPrefPage_fldDeep;
    public static String decoratorPrefPage_prjDeepForce;
    public static String decoratorPrefPage_prjRemoteInfo;
    public static String decoratorPrefPage_fileBase;
    public static String decoratorPrefPage_fileRemote;
    public static String decoratorPrefPage_modified;
    public static String decoratorPrefPage_modifiedImage;
    public static String decoratorPrefPage_localMode;

    // decorator
    public static String decorator_prjWorksetInfo;
    public static String decorator_prjStreamInfo;
    public static String decorator_prjBaselineInfo;
    public static String decorator_fileBase;
    public static String decorator_fileRemote;
    public static String decorator_fileBaseRemote;
    public static String decorator_movedFrom;
    public static String decorator_movedTo;
    public static String decorator_movedPath;
    public static String decorator_movedCrossProjectPath;
    public static String decorator_movedInRepositoryFrom;
    public static String decorator_movedInRepositoryTo;
    public static String decorator_movedInRepositoryPath;

    // project mapping dialog
    public static String prjMapDialog_title;
    public static String prjMapDialog_message;
    public static String prjMapDialog_duplicate;

    // misc
    public static String confirm_overwrite;
    public static String locChangeOverwrite_prompt;

    public static String addToWorkspaceAsSelectMappingTypePage_description;

    public static String addToWorkspaceAsSelectMappingTypePage_title;

    public static String addToWorkspaceAsSelectMappingTypePage_childTypeDescription;

    public static String addToWorkspaceAsSelectMappingTypePage_childTypeLabel;

    public static String addToWorkspaceAsSelectMappingTypePage_containerTypeDescription;

    public static String addToWorkspaceAsSelectMappingTypePage_conteinerTypeLabel;

    // add as wizard
    public static String AddToWorkspaceAsWizard_title;

    // add as main page
    public static String AddToWorkspaceAsMainPage_title;
    public static String AddToWorkspaceAsMainPage_configure;
    public static String AddToWorkspaceAsMainPage_asProject;
    public static String AddToWorkspaceAsMainPage_asProjects;
    public static String AddToWorkspaceAsMainPage_description;

    // add as location selection wizard page
    public static String AddToWorkspaceAsLocationSelectionPage_title;
    public static String AddToWorkspaceAsLocationSelectionPage_description;
    public static String AddToWorkspaceAsLocationSelectionPage_useDefault;
    public static String AddToWorkspaceAsLocationSelectionPage_location;
    public static String AddToWorkspaceAsLocationSelectionPage_directory;
    public static String AddToWorkspaceAsLocationSelectionPage_browse;
    public static String AddToWorkspaceAsLocationSelectionPage_emptyLocation;
    public static String AddToWorkspaceAsLocationSelectionPage_invalidLocation;
    public static String AddToWorkspaceAsLocationSelectionPage_browseMsgSingle;
    public static String AddToWorkspaceAsLocationSelectionPage_browseMsgMulti;
    public static String AddToWorkspaceAsLocationSelectionPage_sccLocMsg;

    public static String AddToWorkspaceOperationCommonWarningTitle;

    public static String AddToWorkspaceOperationCommonWarning;
    public static String addToWorkspaceAsLocationSelectionPage_invalidwa;
    public static String addToWorkspaceAsLocationSelectionPage_multiplewa;
    public static String addToWorkspaceAsLocationSelectionPage_resetpathSingle;
    public static String addToWorkspaceAsLocationSelectionPage_resetpathMultiple;
    public static String addToWorkspaceAsLocationSelectionPage_usingpath;
    public static String addToWorkspaceAsLocationSelectionPage_rootNotWritable;
    public static String ProjectMappingPanel_remoteCol;
    public static String ProjectMappingPanel_localCol;

    public static String AddProjectToWorkspaceOperation_0;

    public static String TeamOperationWizard_1;
    public static String TeamOperationWizard_2;
    public static String TeamOperationWizard_3;
    public static String TeamOperationWizard_4;
    public static String TeamOperationWizard_5;
    public static String TeamOperationWizard_6;

    public static String TeamOperationWizardMainPage_1;
    public static String TeamOperationWizardMainPage_2;
    public static String TeamOperationWizardMainPage_3;
    public static String TeamOperationWizardMainPage_4;
    public static String TeamOperationWizardMainPage_5;
    public static String TeamOperationWizardMainPage_6;
    public static String TeamOperationWizardMainPage_7;
    public static String TeamOperationWizardMainPage_8;
    public static String TeamOperationWizardMainPage_9;
    public static String TeamOperationWizardMainPage_10;
    public static String TeamOperationWizardMainPage_11;

    public static String TeamOperationWizardRequestPage_0;
    public static String TeamOperationWizardRequestPage_1;
    public static String TeamOperationWizardRequestPage_2;
    public static String TeamOperationWizardRequestPage_3;
    public static String TeamOperationWizardRequestPage_4;
    public static String TeamOperationWizardRequestPage_5;
    public static String TeamOperationWizardRequestPage_6;
    public static String TeamOperationWizardRequestPage_7;
    public static String TeamOperationWizardRequestPage_9;
    public static String TeamOperationWizardRequestPage_10;
    public static String TeamOperationWizardRequestPage_11;
    public static String TeamOperationWizardRequestPage_12;
    public static String TeamOperationWizardRequestPage_13;
    public static String TeamOperationWizardRequestPage_14;
    public static String TeamOperationWizardRequestPage_15;
    public static String TeamOperationWizardRequestPage_16;
    public static String TeamOperationWizardRequestPage_18;
    public static String TeamOperationWizardRequestPage_19;
    public static String TeamOperationWizardRequestPage_20;
    public static String TeamOperationWizardRequestPage_21;
    public static String TeamOperationWizardRequestPage_22;
    public static String TeamOperationWizardRequestPage_23;
    public static String TeamOperationWizardRequestPage_24;
    public static String TeamOperationWizardRequestPage_25;
    public static String TeamOperationWizardRequestPage_26;
    public static String TeamOperationWizardRequestPage_27;
    public static String TeamOperationWizardRequestPage_28;
    public static String TeamOperationWizardRequestPage_29;
    public static String TeamOperationWizardRequestPage_30;
    public static String TeamOperationWizardRequestPage_31;
    public static String TeamOperationWizardRequestPage_32;
    public static String TeamOperationWizardRequestPage_33;
    public static String TeamOperationWizardRequestPage_34;
    public static String TeamOperationWizardRequestPage_35;
    public static String TeamOperationWizardRequestPage_36;
    public static String TeamOperationWizardRequestPage_37;
    public static String TeamOperationWizardRequestPage_38;
    public static String TeamOperationWizardRequestPage_39;
    public static String TeamOperationWizardRequestPage_Favorites;
    public static String TeamOperationWizardRequestPage_41;

    public static String TeamOperationWizardAttributesPage_0;
    public static String TeamOperationWizardAttributesPage_1;
    public static String TeamOperationWizardAttributesPage_2;
    public static String TeamOperationWizardAttributesPage_3;
    public static String TeamOperationWizardAttributesPage_copyAll;
    public static String TeamOperationWizardAttributesPage_copyOne;
    public static String TeamOperationWizardAttributesPage_copySome;
    public static String TeamOperationWizardAttributesPage_confirmCopyAllTitle;
    public static String TeamOperationWizardAttributesPage_confirmCopyAllMsg;
    public static String TeamOperationWizardAttributesPage_copySomeTitle;
    public static String TeamOperationWizardAttributesPage_copySomeMsg;
    public static String TeamOperationWizardAttributesPage_noneSelected;
    public static String TeamOperationWizardAttributesPage_okToCopy;
    public static String TeamOperationWizardAttributesPage_dirtyPrefix;

    public static String CheckoutWizard_title;
    public static String CheckoutWizard_mainPageTitle;
    public static String CheckoutWizard_mainPageDescription;
    public static String CheckoutWizard_attrPageTitle;
    public static String CheckoutWizard_attrPageDdescription;

    public static String UpdateFromRemoteOperation_0;
    public static String UpdateFromRemoteOperation_1;

    public static String ReplaceWithRemoteOperation_0;
    public static String ReplaceWithRemoteOperation_1;

    public static String AddToRemoteHelper_1;
    public static String AddToRemoteHelper_4;
    public static String AddToRemoteHelper_5;

    // Lock/Unlock wizard
    public static String LockWizard_lock_title;
    public static String LockWizard_lock_mainPageTitle;
    public static String LockWizard_lock_mainPageDescription;
    public static String LockWizard_unlock_title;
    public static String LockWizard_unlock_mainPageTitle;
    public static String LockWizard_unlock_mainPageDescription;

    public static String Option_yes;
    public static String Option_no;
    public static String Option_prompt;

    public static String CheckoutHelper_0;
    public static String CheckoutHelper_1;
    public static String CheckoutHelper_2;
    public static String CheckoutHelper_3;
    public static String CheckoutHelper_4;
    public static String CheckoutHelper_5;

    public static String CheckinHelper_1;
    public static String CheckinHelper_2;

    public static String UndoCheckoutHelper_2;
    public static String UndoCheckoutHelper_3;
    public static String UndoCheckoutHelper_4;
    public static String UndoCheckoutHelper_5;
    public static String UndoCheckoutHelper_6;
    public static String UndoCheckoutWizard_0;
    public static String UndoCheckoutWizard_1;
    public static String UndoCheckoutWizard_2;

    // Undo Stream\Project version
    public static String UndoStreamProjectVersionTask;
    public static String UndoStreamProjectVersionErrorDialogTitle;
    public static String UndoStreamProjectVersionErrorDialogMessage;
    public static String UndoFailedDueToChangesOutOfScope;

    public static String UpdateHelper_0;
    public static String UpdateHelper_1;

    public static String MoveHelper_1;
    public static String MoveWizard_0;
    public static String MoveWizard_1;
    public static String MoveWizard_2;

    // Default Request
    public static String defaultRequest_workingOn;
    public static String defaultBranch_devbranch;
    public static String defaultRequest_title;
    public static String defaultRequest_status;
    public static String defaultRequest_workingOn_title;
    public static String defaultRequest_noContext_title;
    public static String defaultRequest_notWorkingOn_title;
    public static String defaultRequest_noneSelected;
    public static String defaultRequest_setSelected;
    public static String defaultBranch_setSelected;
    public static String defaultRequest_removeSelected;
    public static String defaultBranch_removeSelected;
    public static String defaultRequest_newDefault_tooltip;
    public static String defaultRequest_removeDefault_tooltip;
    public static String defaultRequest_setActive;
    public static String defaultRequest_setActive_tooltip;

    public static String defaultRequest_setActive_onlyworkspace_title;
    public static String defaultRequest_setActive_onlyworkspace_tooltip;
    public static String setAsDefaultRequestFor_title;
    public static String setAsDefaultRequestFor_multiquestion;
    public static String setAsDefaultRequestFor_progressTask;

    // Sharing wizard
    public static String SharingWizard_title;
    public static String SharingWizard_Project;
    public static String SharingWizard_project;

    public static String SharingWizard_projectNotFound;
    public static String SharingWizard_Stream;
    public static String SharingWizard_stream;
    public static String SharingWizard_projectSelectPageTitle;
    public static String SharingWizard_offsetPageTitle;
    public static String Sharingwizard_offsetPageDescrFull;
    public static String Sharingwizard_offsetPageDescrPart;
    public static String SharingWizard_requestPageTitle;
    public static String SharingWizard_requestPageDescr;
    public static String SharingWizard_summaryPageTitle;
    public static String SharingWizard_summaryPageDescr;
    public static String SharingWizard_streamSummaryPageDescr;
    public static String SharingWizard_wizardDescr;
    public static String SharingWizard_nothingToAddTitle;
    public static String SharingWizard_nothingToAddMessage;
    public static String SharingWizard_addJobName;
    public static String SharingWizard_addJobSubtask;
    public static String SharingWizard_errorTitle;
    public static String sharingWizard_markerComment;
    public static String sharingWizard_markerDescription;
    // Sharing wizard summary page
    public static String SharingSummaryPage_true;
    public static String SharingSummaryPage_false;
    public static String SharingSummaryPage_none;
    public static String SharingSummaryPage_createNewConnectionLabel;
    public static String SharingSummaryPage_createNewProjectlabel;
    public static String SharingSummaryPage_createNewStreamlabel;
    public static String SharingSummaryPage_optionsGroupText;
    public static String SharingSummaryPage_openSyncButtonText;
    public static String SharingSummaryPage_projectLabel;
    public static String SharingSummaryPage_streamLabel;
    public static String SharingSummaryPage_connectionLabel;
    public static String SharingSummaryPage_ideProjectLabel;
    public static String SharingSummaryPage_createdInContainerLabel;
    public static String SharingSummaryPage_containerOffsetLabel;
    public static String SharingSummaryPage_defaultBranch;
    public static String SharingSummaryPage_noDefaultBranch;
    public static String SharingSummaryPage_noOffset;
    public static String SharingSummaryPage_validBranches;
    public static String SharingSummaryPage_noValidBranches;
    public static String SharingSummaryPage_addButtonText;
    public static String SharingSummaryPage_reqMan;
    public static String SharingSummaryPage_reqManSBM;
    public static String SharingSummaryPage_reqManDM;
    public static String SharingWizard_noTypeMessage;
    // Sharing offset page
    public static String SharingOffsetPage_offset;
    public static String SharingOffsetPage_work_area_root;
    public static String SharingOffsetPage_work_area_dlg_title;
    public static String SharingOffsetPage_work_area_dlg_message;
    public static String SharingOffsetPage_part;
    public static String SharingOffsetPage_selectFolder_title;
    // Sharing request page
    public static String SharingRequestPage_selectAllButtonText;
    public static String SharingRequestPage_clearAllButtonText;

    // remote resource compare editor input
    public static String DMCompareEditorInput_titleAncestor;
    public static String DMCompareEditorInput_titleAncestorSameFile;
    public static String DMCompareEditorInput_titleNoAncestor;
    public static String DMCompareEditorInput_titleNoAncestorSameFile;
    public static String DMCompareEditorInput_fileProgress;
    public static String DMCompareEditorInput_comparing;
    public static String DMCompareEditorInput_internalError;
    public static String DMCompareEditorInput_ancestorP;
    public static String DMCompareEditorInput_leftP;
    public static String DMCompareEditorInput_rightP;

    // remote to local resource compare editor input
    public static String DMCompareRevAndLocalEditorInput_titleNoAncestor;
    public static String DMCompareRevAndLocalEditorInput_titleAncestor;
    public static String DMCompareRevToLocalEditorInput_internalError;

    // file resource variant labels
    public static String SyncInfoCompareInput_localLabel;
    public static String SyncInfoCompareInput_localLabelExists;

    public static String SyncInfoCompareInput_localLabelExistsAndPath;
    public static String SyncInfoCompareInput_remoteLabel;
    public static String SyncInfoCompareInput_remoteLabelExists;
    public static String SyncInfoCompareInput_baseLabel;
    public static String SyncInfoCompareInput_baseLabelExists;

    public static String SyncInfoCompareInput_tempLabelExistsAndPath;

    // document editor strings
    public static String detailsPage_title;
    public static String detailsPage_item_text;
    public static String attPage_title;
    public static String attPage_text;
    public static String historyPage_title;
    public static String historyPage_text;
    public static String delegatesPage_title;
    public static String delegatesPage_text;
    public static String usersAndRoles_title;
    public static String usersAndRoles_text;
    public static String privilegesPage_title;
    public static String privilegesPage_text;

    public static String itemEditor_tooltip;
    public static String itemEditor_tooltip_short;

    // details section titles
    public static String itemDetailsSection_title;

    public static String itemDetailsPnl_id;
    public static String itemDetailsPnl_revision;
    public static String itemDetailsPnl_state;
    public static String itemDetailsPnl_desc;
    public static String itemDetailsPnl_filename;
    public static String itemDetailsPnl_itemFormat;
    public static String itemDetailsPnl_itemType;
    public static String itemDetailsPnl_creationDate;
    public static String itemDetailsPnl_updateDate;
    public static String itemDetailsPnl_revisedDate;
    public static String itemDetailsPnl_lastUpdater;
    public static String itemDetailsPnl_stage;
    public static String itemDetailsPnl_locked;
    public static String itemDetailsPnl_lockedBy;
    public static String itemDetailsPnl_lockedDate;
    public static String itemDetailsPnl_true;
    public static String itemDetailsPnl_false;

    // merge wizard
    public static String MergeWizard_title;
    public static String MergeWizard_selectSrcPageTitle;
    public static String MergeWizard_selectSrcPageDesc;

    public static String ThreeWayWizard_0resetWarning;

    public static String ThreeWayWizard_mergeBaselineDefaultDescr;

    public static String ThreeWayWizard_mergeRequestDefaultDescr;

    public static String ThreeWayWizard_mergeSreamDefaultDescr;

    public static String ThreeWayWizard_selectSrcPageTitleStream;
    public static String ThreeWayWizard_selectSrcPageTitleBaseline;

    public static String MergeWizard_selectAncPageTitle;
    public static String MergeWizard_selectAncPageDesc;
    public static String MergeWizard_selectAncPageMessage;
    public static String MergeWizard_selectAncPageMessageManual;
    public static String MergeWizard_summaryPageTitle;
    public static String MergeWizard_summaryPageDesc;
    public static String MergeWizard_initializing;

    public static String ThreeWayWizard_updateRequestDefaultDescr;

    public static String ThreeWayWizard_updateStreamDefaultDescr;

    public static String ThreeWayMergeWizard_MergeBaseline;

    public static String ThreeWayMergeWizard_MergeBaselineDesc;

    public static String ThreeWayMergeWizard_MergeRequest;

    public static String ThreeWayMergeWizard_MergeRequestDesc;

    public static String ThreeWayMergeWizard_MergeStreamOrFolder;

    public static String ThreeWayMergeWizard_MergeStreamOrFolderDesc;

    public static String ThreeWayMergeWizard_optionsBrowseButton;

    public static String ThreeWayMergeWizard_optionsPreferencesDatetime;

    public static String ThreeWayMergeWizard_optionsFindButton;

    public static String ThreeWayMergeWizard_optionsIntercativeMerge;

    public static String ThreeWayMergeWizard_optionsPreferencesLogging;

    public static String ThreeWayMergeWizard_optionsPreferencesLoggingDirectory;

    public static String ThreeWayMergeWizard_optionsPreferencesLoggingDirectoryDescription;

    public static String ThreeWayMergeWizard_optionsMergeWith;

    public static String ThreeWayMergeWizard_optionsMergeWithLatestBaselineVersion;

    public static String ThreeWayMergeWizard_optionsMergeWithLatestStreamVersion;

    public static String ThreeWayMergeWizard_optionsMergeWithRequests;

    public static String ThreeWayMergeWizard_optionsMergeFromStream;

    public static String ThreeWayMergeWizard_optionsMergeIntoStream;

    public static String ThreeWayMergeWizard_optionsMergeTableProjectsTitle;

    public static String ThreeWayMergeWizard_optionsMergeTableOffsetTitle;

    public static String ThreeWayMergeWizard_optionsMergeTablePathTitle;

    public static String ThreeWayMergeWizard_optionsMergeTableStreamsTitle;

    public static String ThreeWayMergeWizard_optionsPreferences;

    public static String ThreeWayMergeWizard_optionsPreferencesAutoMerge;

    public static String ThreeWayMergeWizard_optionsRequestCherryPick;

    public static String ThreeWayMergeWizard_optionsRequestRelatedItems;

    public static String ThreeWayMergeWizard_optionsPreferencesShowSummary;

    public static String ThreeWayMergeWizard_optionsPageTitle;

    public static String ThreeWayMergeWizard_optionsPreferencesDesc;

    public static String ThreeWayMergeWizard_optionsPreferencesHide;

    public static String ThreeWayMergeWizard_optionsPreferencesPathEmptyError;

    public static String ThreeWayMergeWizard_optionsPreferencesPathInvalidError;

    public static String ThreeWayMergeWizard_optionsPreferencesPathCreatedInfo;

    public static String ThreeWayMergeWizard_optionsPreferencesTitle;

    public static String ThreeWayMergeWizard_selectModePageDescr;

    public static String ThreeWayMergeWizard_selectModePageTitle;

    public static String ThreeWayMergeWizard_streamVersionPageTitle;

    public static String ThreeWayMergeWizard_Title;

    public static String ThreeWayMergeWizard_Title_baseline;

    public static String ThreeWayMergeWizard_Title_requests;

    public static String ThreeWayMergeWizard_Title_streams;

    public static String ThreeWayMergeWizardAction_MergeNotAllowed;

    public static String ThreeWayUpdateWizard_optionsIntercativeUpdate;

    public static String ThreeWayUpdateWizard_optionsMergeWithRequests;

    public static String ThreeWayUpdateWizard_optionsPageTitle;

    public static String ThreeWayUpdateWizard_optionsUpdateIntoStream;

    public static String ThreeWayUpdateWizard_optionsUpdateWithLatestStreamVersion;

    public static String ThreeWayUpdateWizard_Title_requests;

    public static String ThreeWayUpdateWizard_Title_streams;

    public static String RevertStreamVersionWizard_Title;

    public static String RevertStreamVersionWizard_optionsPageTitle;

    public static String RevertStreamVersionWizard_revertStreamVersionDefaultDescr;

    public static String RevertStreamVersionWizard_optionsRevertToStreamVersion;

    public static String RevertStreamVersion_nothingToRevert;

    public static String ThreeWayUpdateWizardAction_UpdateNotAllowed;

    // merge scope selection wizard
    public static String MergeScopeSelectionWizard_worksetsStreamsTitle;
    public static String MergeScopeSelectionWizard_worksetsProjectsTitle;
    public static String MergeScopeSelectionWizard_projectsProjectsTitle;
    public static String MergeScopeSelectionWizard_projectsOffsetTitle;
    public static String MergeScopeSelectionWizard_projectsStreamsTitle;
    public static String MergeScopeSelectionWizard_mergeGroupsTitle;
    public static String MergeScopeSelectionWizard_wsProjectsTitle;
    public static String MergeScopeSelectionWizard_descTitle;
    public static String MergeScopeSelectionWizard_creatDateTitle;

    public static String RevertScopeSelectionWizard_revertGroupsDescription;

    // merge summary page
    public static String MergeSummaryPage_0;
    public static String MergeSummaryPage_1;
    public static String MergeSummaryPage_2;
    public static String MergeSummaryPage_3;
    public static String MergeSummaryPage_4;
    public static String MergeSummaryPage_5;
    public static String MergeSummaryPage_6;
    public static String MergeSummaryPage_7;

    // switch action
    public static String SwitchAction_IncompatibleTypes;
    // vm project selection panel
    public static String ProjectSelectionPanel_defaultNullText;
    public static String ProjectSelectionPanel_find;
    public static String ProjectSelectionPanel_browse;
    public static String ProjectSelectionPanel_idLabelTxt;
    public static String ProjectSelectionPanel_launchFind;
    public static String ProjectSelectionPanel_useContainer;
    public static String ProjectSelectionPanel_useContained;
    public static String ProjectSelectionPanel_containedProject;

    public static String ProjectSelectionPanel_stream;

    // merge participant
    public static String DMMergeParticipant_namePattern;
    public static String DMMergeParticipant_ancestorAndSource;
    public static String DMMergeParticipant_unableInitialize;
    public static String DMMergeParticipant_noConnection;
    public static String DMMergeParticipant_noProjectMerges;
    public static String DMMergeParticipant_noAncestorSource;
    public static String DMMergeParticipant_noRoots;
    public static String DMMergeParticipant_missingRoot;
    public static String DMMergeParticipant_shortTask;
    public static String DMMergeParticipant_updateActionTooltip;

    // compare participant
    public static String DMCompareParticipant_namePattern;
    public static String DMCompareParticipant_shortTask;

    // compare wizard
    public static String CompareWizard_title;
    public static String CompareWizard_selectRmtPageTitle;
    public static String CompareWizard_selectRmtPageTitleDesc;
    public static String CompareWizard_initializing;

    // subscriber part. wizard
    public static String SubscriberParticipantWizard_title;
    public static String SubscriberParticipantWizard_noResources;
    public static String SubscriberParticipantWizard_noResourcesDesc;
    public static String SubscriberParticipantWizard_selPageTitle;
    public static String SubscriberParticipantWizard_selPageMessage;

    // subscriber part wizard page
    public static String GlobalRefreshResourceSelectionPage_0;
    public static String GlobalRefreshResourceSelectionPage_1;
    public static String GlobalRefreshResourceSelectionPage_2;
    public static String GlobalRefreshResourceSelectionPage_3;
    public static String GlobalRefreshResourceSelectionPage_4;
    public static String GlobalRefreshResourceSelectionPage_5;
    public static String GlobalRefreshResourceSelectionPage_6;
    public static String GlobalRefreshResourceSelectionPage_7;
    public static String GlobalRefreshResourceSelectionPage_8;
    public static String GlobalRefreshResourceSelectionPage_9;
    public static String GlobalRefreshResourceSelectionPage_10;
    public static String GlobalRefreshResourceSelectionPage_11;

    public static String DMConfirmMergedOperation_jobName;
    public static String DMConfirmMergedOperation_failure;
    public static String DMConfirmMergedOperation_failureMsg;
    public static String DMConfirmMergedAction_0;

    // file modification validator settings
    public static String FileModificationPreferencePage_0;
    public static String FileModificationPreferencePage_1;
    public static String FileModificationPreferencePage_2;
    public static String FileModificationPreferencePage_3;
    public static String FileModificationPreferencePage_4;
    public static String FileModificationPreferencePage_5;
    public static String FileModificationPreferencePage_6;
    public static String FileModificationPreferencePage_7;
    public static String FileModificationPreferencePage_8;
    public static String FileModificationPreferencePage_9;
    public static String FileModificationPreferencePage_10;

    public static String ModificationValidationDialog_0;
    public static String ModificationValidationDialog_1;
    public static String ModificationValidationDialog_2;

    public static String DMFileModificationValidator_0;
    public static String DMFileModificationValidator_1;
    public static String DMFileModificationValidator_2;
    public static String DMFileModificationValidator_3;
    public static String DMFileModificationValidator_4;
    public static String DMFileModificationValidator_5;
    public static String DMFileModificationValidator_6;
    public static String DMFileModificationValidator_7;
    public static String DMFileModificationValidator_8;
    public static String DMFileModificationValidator_9;

    public static String DMSynchronizeModelOperation_confirmOverwriteTitle;
    public static String DMSynchronizeModelOperation_confirmOverwriteMessage;

    public static String DMRepositoryMoveUpdateOperation_confirmDiscardChangesTitle;
    public static String DMRepositoryMoveUpdateOperation_confirmDiscardChangesMessage;

    public static String DMRepositoryMoveOverrideAndUpdateOperation_confirmDiscardChangesTitle;
    public static String DMRepositoryMoveOverrideAndUpdateOperation_confirmDiscardChangesMessage;

    public static String DMSafeUpdateOperation_0;
    public static String DMSafeUpdateOperation_1;
    public static String DMSafeUpdateOperation_2;
    public static String DMSafeUpdateOperation_3;
    public static String DMSafeUpdateOperation_8;
    public static String DMSafeUpdateOperation_9;
    public static String DMSafeUpdateOperation_10;
    public static String DMSafeUpdateOperation_11;

    public static String DMParticipantLabelDecorator_suffix;
    // DMParticipantLabelDecorator.textAndSuffix={0} ({1})

    // Item history view
    public static String itemHistory_newRevision;
    public static String itemHistory_prevRevision;
    public static String itemHistory_status;
    public static String itemHistory_dateTime;
    public static String itemHistory_user;
    public static String itemHistory_description;

    public static String itemHistory_action_getContent_label;
    public static String itemHistory_action_getContent_tooltip;
    public static String itemHistory_action_getRevision_label;
    public static String itemHistory_action_getRevision_tooltip;
    public static String itemHistory_action_compare_label;
    public static String itemHistory_action_compare_tooltip;
    public static String itemHistory_action_compareLocal_label;
    public static String itemHistory_action_compareLocal_tooltip;
    public static String itemHistory_action_checkout_label;
    public static String itemHistory_action_checkout_tooltip;
    public static String itemHistory_action_open_label;
    public static String itemHistory_action_open_tooltip;
    public static String itemHistory_action_openProperties_label;
    public static String itemHistory_action_openProperties_tooltip;
    public static String itemHistory_action_action_label;
    public static String itemHistory_action_action_tooltip;

    public static String itemHistory_action_blame_label;
    public static String itemHistory_action_blame_tooltip;
    public static String itemHistory_action_refresh_label;
    public static String itemHistory_action_refresh_tooltip;
    public static String itemHistory_action_merge_label;
    public static String itemHistory_action_merge_tooltip;

    public static String itemHistory_undoCO_text;
    public static String itemHistory_undoCO_tooltip;
    public static String itemHistory_undoCO_errTitle;
    public static String itemHistory_undoCO_errMsg;
    public static String itemHistory_undoCO_task;
    public static String itemHistory_undoCO_consoleMsg;
    public static String itemHistory_undoCO_undoOtherMsg;
    public static String itemHistory_undoCO_undoOtherConfirm1;
    public static String itemHistory_undoCO_undoOtherConfirm2;
    public static String itemHistory_undoCO_confirmTitle;

    public static String DMWorkspaceShelveOperation_1;

    public static String DMWorkspaceShelveWizard_0;

    public static String DMWorkspaceStreamUpdateAction_0;

    public static String DMWorkspaceStreamUpdateOperation_0;

    // sync participant
    public static String DMWorkspaceSynchronizeParticipant_0;
    public static String DMWorkspaceSynchronizeParticipant_1;

    public static String DMWorkspaceSynchronizeParticipant_2;

    public static String DMWorkspaceSynchronizeParticipant_3;

    // checkout operation
    public static String CheckoutOperation_taskName;
    public static String CheckoutOperation_taskNameProvider;
    public static String CheckoutOperation_concurrentCheckoutPromptTitle;
    public static String CheckoutOperation_concurrentCheckoutPrompt;

    // Lock/Unlock operation
    public static String LockOperation_lock_taskName;
    public static String LockOperation_lock_taskNameProvider;
    public static String LockOperation_unlock_taskName;
    public static String LockOperation_unlock_taskNameProvider;

    // IFile property page
    public static String FilePropertyPage_repoPath;
    public static String FilePropertyPage_baseRev;
    public static String FilePropertyPage_remtRev;
    public static String FilePropertyPage_baseId;
    public static String FilePropertyPage_remtId;
    public static String FilePropertyPage_baseTstamp;
    public static String FilePropertyPage_modified;
    public static String FilePropertyPage_co;
    public static String FilePropertyPage_coMultiple;
    public static String FilePropertyPage_coOther;
    public static String FilePropertyPage_coExclusive;
    public static String FilePropertyPage_movedFromPath;
    public static String FilePropertyPage_movedFromProj;
    public static String FilePropertyPage_mergedFrom;
    public static String FilePropertyPage_locked;
    public static String FilePropertyPage_lockedBy;
    public static String FilePropertyPage_lockedDate;
    public static String FilePropertyPage_refresh;
    public static String FilePropertyPage_true;
    public static String FilePropertyPage_false;
    public static String FilePropertyPage_unmanaged;
    public static String FilePropertyPage_ignored;

    // IFolder property page
    public static String FolderPropertyPage_unmanaged;
    public static String FolderPropertyPage_ignored;
    public static String FolderPropertyPage_repoPath;

    // IProject property page
    public static String ProjectPropertyPage_connection;
    public static String ProjectPropertyPage_projId;
    public static String ProjectPropertyPage_streamId;
    public static String ProjectPropertyPage_streamParent;
    public static String ProjectPropertyPage_ideProj;
    public static String ProjectPropertyPage_offset;
    public static String ProjectPropertyPage_changeSharingProject;
    public static String ProjectPropertyPage_changeSharingStream;

    public static String SynchronizeAction_0;
    public static String SynchronizeAction_1;
    public static String SynchronizeAction_2;
    public static String SynchronizeAction_3;

    public static String DMCompareReplaceAction_name;
    public static String DMCompareReplaceOperation_jobName;

    public static String decorator_parent;

    public static String DMLocalFileNotExist_warning;

    public static String IgnoreResourcesDialog_titleSingle;
    public static String IgnoreResourcesDialog_titleMany;
    public static String IgnoreResourcesDialog_prompt;
    public static String IgnoreResourcesDialog_addNameEntryButton;
    public static String IgnoreResourcesDialog_addNameEntryExample;
    public static String IgnoreResourcesDialog_addExtensionEntryButton;
    public static String IgnoreResourcesDialog_addExtensionEntryExample;
    public static String IgnoreResourcesDialog_addCustomEntryButton;
    public static String IgnoreResourcesDialog_addCustomEntryExample;
    public static String IgnoreResourcesDialog_patternMustNotBeEmpty;
    public static String IgnoreResourcesDialog_patternDoesNotMatchFile;

    public static String IgnoreAction_0;

    // project set import handler
    public static String ProjectSetImportHandler_0;
    public static String ProjectSetImportHandler_1;
    public static String ProjectSetImportHandler_2;
    public static String ProjectSetImportHandler_3;
    public static String ProjectSetImportHandler_4;
    public static String ProjectBranchWizard_0;
    public static String ProjectBranchWizard_1;
    public static String ProjectBranchWizard_2;
    public static String ProjectBranchWizard_3;
    public static String ProjectBranchWizard_4;
    public static String ProjectBranchWizard_5;
    public static String ProjectBranchWizard_6;
    public static String ProjectBranchWizardGeneralPage_0;
    public static String ProjectBranchWizardGeneralPage_1;
    public static String ProjectBranchWizardGeneralPage_2;
    public static String ProjectBranchWizardGeneralPage_3;
    public static String ProjectBranchWizardGeneralPage_4;
    public static String ProjectBranchWizardGeneralPage_5;
    public static String ProjectBranchWizardGeneralPage_6;
    public static String ProjectBranchWizardGeneralPage_7;
    public static String ProjectBranchWizardGeneralPage_8;

    public static String ItemRevisionEditHandler_0;
    public static String ItemRevisionEditHandler_1;

    // baseline lists
    public static String BaselineListConfiguration_otherBaselines;
    public static String BaselineListConfiguration_prjBaselines;

    // project lists
    public static String ProjectListConfiguration_ideProjects;
    public static String ProjectListConfiguration_ideProjectGroups;
    public static String ProjectListConfiguration_otherProjects;

    public static String ProjectListConfiguration_favouriteProjects;
    public static String ProjectListConfiguration_members;

    public static String ProjectListConfiguration_recentProjects;

    // Project Import Wizard
    public static String ProjectImportWizard_Window_title;
    public static String ProjectImportWizard_SelectionPage_title;
    public static String ProjectImportWizard_SelectionPage_description;
    public static String ProjectImportWizard_SelectionPage_col1_title;
    public static String ProjectImportWizard_SelectionPage_col2_title;
    public static String ProjectImportWizard_SelectionPage_col3_title;
    public static String ProjectImportWizard_SelectionPage_findProjects;
    public static String ProjectImportWizard_SelectionPage_findBaselines;
    public static String ProjectImportWizard_SelectionPage_browse;
    public static String ProjectImportWizard_SelectionPage_remove;
    public static String ProjectImportWizard_SelectionPage_dupsErr;
    public static String ProjectImportWizard_SelectionPage_useContainer;

    public static String ProjectImportWizard_SelectionPage_removeall;
    public static String ProjectImportWizard_SelectionPage_selectedfrom;
    public static String ProjectImportWizard_SelectionPage_selected;
    public static String ProjectImportWizard_SelectionPage_browsedialog_title;

    public static String CompareVMObjectsAction_0;
    public static String CompareVMObjectsAction_1;
    public static String CompareVMObjectsAction_2;
    public static String CompareVMObjectsAction_3;
    public static String CompareVMObjectsAction_4;
    public static String CompareVMObjectsAction_5;

    public static String DMTeamAction_0;
    public static String DMTeamAction_1;
    public static String DMTeamAction_2;
    public static String DMTeamAction_3;
    public static String DMTeamUiPlugin_1;
    public static String DMTeamUiPlugin_0;
    public static String DMTeamUiPlugin_2;
    public static String DMTeamUiPlugin_3;

    public static String EditProjectAction_1;
    public static String EditProjectAction_2;
    public static String EditProjectAction_3;

    public static String UploadOperation_0;
    public static String UploadOperation_1;
    public static String UploadOperation_2;
    public static String UploadOperation_3;
    public static String UploadOperation_4;
    public static String UploadOperation_5;
    public static String UploadOperation_6;

    public static String DeliverOperation_0;
    public static String DeliverOperation_1;

    public static String UploadHelper_0;
    public static String UploadHelper_1;
    public static String UploadHelper_2;
    public static String UploadHelper_3;
    public static String UploadHelper_4;
    public static String UploadHelper_5;
    public static String UploadHelper_6;
    public static String UploadHelper_7;
    public static String UploadHelper_8;
    public static String UploadHelper_9;
    public static String UploadHelper_10;
    public static String UploadHelper_11;

    public static String MoveOperation_0;
    public static String MoveOperation_1;

    public static String AddToRemoteMainPage_0;
    public static String AddToRemoteMainPage_1;
    public static String AddToRemoteMainPage_2;
    public static String AddToRemoteMainPage_3;
    public static String AddToRemoteMainPage_5;
    public static String AddToRemoteMainPage_6;
    public static String AddToRemoteMainPage_7;
    public static String AddToRemoteMainPage_8;

    public static String RemoveOperation_0;
    public static String RemoveOperation_1;
    public static String RemoveWizard_0;
    public static String RemoveWizard_1;
    public static String RemoveWizard_2;
    public static String RemoveHelper_0;

    public static String UndoCheckoutOperation_0;
    public static String UndoCheckoutOperation_1;
    public static String UndoCheckoutOperation_2;
    public static String UndoCheckoutOperation_3;

    public static String RefreshStatusOperation_0;

    public static String DMOverrideAndUpdateAction_0;

    public static String DMOverrideAndUpdateAction_1;
    public static String DMOverrideAndCommitAction_0;
    public static String DMWorkspaceCommitWizard_0;
    public static String DMWorkspaceCommitWizard_1;

    public static String DMWorkspaceCommitWizard_10ShelvingDescription;
    public static String DMWorkspaceCommitWizard_2;
    public static String DMWorkspaceCommitWizard_3;

    public static String DMWorkspaceCommitWizard_4;

    public static String DMWorkspaceCommitWizard_5;

    public static String DMWorkspaceCommitWizard_9ShelvingTitle;
    public static String DMWorkspaceCommitAction_0;

    public static String DMWorkspaceCommitAction_1;
    public static String DMWorkspaceCommitHelper_4;
    public static String DMWorkspaceCommitHelper_5;
    public static String DMWorkspaceCommitOperation_0;
    public static String DMWorkspaceCommitOperation_1;

    public static String DMWorkspaceCommitOperation_2NewShelfDescription;

    public static String DMWorkspaceDeliverOperation_1;

    public static String DMWorkspaceDeliverWizard_0;

    public static String DMWorkspaceUpdateAction_0;
    public static String DMWorkspaceUpdateOperation_0;
    public static String DMSynchronizeWizard_0;
    public static String DMMergeUpdateAction_0;

    public static String DMXMLMergeOperation_assert_access;

    public static String DMXMLMergeOperation_baseline_dir_miss_warning;

    public static String DMXMLMergeOperation_error;

    public static String DMXMLMergeOperation_errorMsg;

    public static String DMXMLMergeOperation_silent_mode_failed_projects_multiple;

    public static String DMXMLMergeOperation_silent_mode_failed_projects_single;

    public static String DMXMLMergeOperation_silent_mode_failed_title;

    public static String DMXMLMergeOperation_nochanges;

    public static String DMXMLMergeOperation_summary_dialog;

    public static String DMXMLMergeOperation_task_baseline_name_multiple;

    public static String DMXMLMergeOperation_task_baseline_name_single;

    public static String DMXMLMergeOperation_task_project_name_multiple;

    public static String DMXMLMergeOperation_task_project_name_single;

    public static String DMXMLMergeOperation_task_request_name_multiple;

    public static String DMXMLMergeOperation_task_request_name_single;

    public static String DMXMLMerge_name;

    public static String DMXMLMergeAction_pattern_long;

    public static String DMXMLMergeAction_pattern_short;

    public static String DMXMLMergeParticipant_baseline_merge_name;

    public static String DMXMLMergeParticipant_details_action;

    public static String DMXMLMergeParticipant_menu_apply_selected_action;

    public static String DMXMLMergeParticipant_menu_revert_merge_action;

    public static String DMXMLMergeParticipant_prop_action_content;

    public static String DMXMLMergeParticipant_prop_action_path;

    public static String DMXMLMergeParticipant_prop_action_item;

    public static String DMXMLMergeParticipant_prop_ancestor;

    public static String DMXMLMergeParticipant_prop_details;

    public static String DMXMLMergeParticipant_prop_infocategory;

    public static String DMXMLMergeParticipant_prop_local;

    public static String DMXMLMergeParticipant_prop_pathcategory;

    public static String DMXMLMergeParticipant_prop_remote;

    public static String DMXMLMergeParticipant_prop_speccategory;

    public static String DMXMLMergeParticipant_prop_usercategory;

    public static String DMXMLMergeParticipant_request_merge_name;

    public static String DMXMLMergeParticipant_short_name;

    public static String DMXMLMergeOperation_show_switch_always;

    public static String DMXMLMergeOperation_switch_to_update;

    public static String DMXMLMergeOperation_switch_to_update_info;

    public static String DMXMLMergeParticipant_stale_view_warning;

    public static String DMXMLMergeParticipant_stream_merge_name;

    public static String DMXMLMergeParticipant_toolbar_apply_action;

    public static String DMXMLMergeOperation_dont_show_message;

    public static String DMXMLMergeOperation_project_dir_miss_warning;

    public static String DMXMLMergeOperation_update_summary_dialog;

    public static String DMXMLMergeOperation_upgrade_outdated_workareas;

    public static String DMXMLMergeParticipantLabelDecorator_move_accept_right;

    public static String DMXMLMergeParticipantLabelDecorator_move_accept_left;

    public static String DMXMLMergeParticipantLabelDecorator_move_unresoved;

    public static String DMXMLMergeParticipantLabelDecorator_movedPath;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_short;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_stale;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_stale_pattern;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_accept;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ignore;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_merge;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_merge_content;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_local;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_local_content;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_local_path;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_long_1option;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_long_3options;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_long_2options;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_remote;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_remote_content;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_remote_path;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_unresolved_path;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_unresolved;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_use_local_content;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_use_remote_content;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_multi;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_multi;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_full;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_multi_full;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_full;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_multi_full;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_RepositoryItem;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_LocalItem;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_hiderevisions;

    public static String DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_hiderevisions;

    public static String DMXMLMergeParticipantLabelDecorator_suffix;

    public static String DMXMLMergeParticipantLabelDecorator_suffix_single;

    public static String streamPrefPage_allowUpdateAutoMerge;

    public static String streamPrefPage_auto_homesync;

    public static String streamPrefPage_descr;

    public static String streamPrefPage_switch_dialog;

    public static String streamPrefPage_user_changes_dialog;

    public static String DMXMLMergeSummary_add;

    public static String DMXMLMergeSummary_conflict_lc;

    public static String DMXMLMergeSummary_conflict_lclp;

    public static String DMXMLMergeSummary_conflict_lcrp;

    public static String DMXMLMergeSummary_conflict_lp;

    public static String DMXMLMergeSummary_conflict_mc;

    public static String DMXMLMergeSummary_conflict_mclp;

    public static String DMXMLMergeSummary_conflict_mcrp;

    public static String DMXMLMergeSummary_conflict_rc;

    public static String DMXMLMergeSummary_conflict_rclp;

    public static String DMXMLMergeSummary_conflict_rcrp;

    public static String DMXMLMergeSummary_conflict_rp;

    public static String DMXMLMergeSummary_delete;

    public static String DMXMLMergeSummary_errors;

    public static String DMXMLMergeSummary_ignore;

    public static String DMXMLMergeSummary_modify;

    public static String DMXMLMergeSummary_move;

    public static String DMXMLMergeSummary_movemodify;

    public static String DMXMLMergeSummary_upgrade;

    public static String DMXMLUpdate_name;

    public static String DMXMLUpdateOperation_error;

    public static String DMXMLUpdateOperation_errorMsg;

    public static String DMXMLUpdateOperation_switch_to_merge;

    public static String DMXMLUpdateOperation_switch_to_merge_info;

    public static String DMXMLUpdateOperation_task_project_name_multiple;

    public static String DMXMLUpdateOperation_task_project_name_single;

    public static String DMXMLUpdateOperation_task_request_name_multiple;

    public static String DMXMLUpdateOperation_task_request_name_single;

    public static String DMXMLUpdateParticipant_request_update_name;

    public static String DMXMLUpdateParticipant_short_name;

    public static String DMXMLUpdateParticipant_stale_view_warning;

    public static String DMXMLUpdateParticipant_stream_update_name;
    public static String ItemHistoryLabelProvider_currentRevMarker;
    public static String ItemHistoryContentProvider_0;
    public static String ItemHistoryContentProvider_1;
    public static String ItemHistoryContentProvider_2;
    public static String ItemHistoryContentProvider_3;
    public static String ItemHistoryContentProvider_4;
    public static String ItemHistoryContentProvider_5;

    public static String AddToGroup_title;
    public static String AddToGroup_label;
    public static String AddToGroup_SameProject_question;
    public static String AddToGroup_removingSameProject_console_message;
    public static String AddToProjectGroup_console_message;

    public static String remFromGroup_title;
    public static String remFromGroup_question;
    public static String remFromGroup_consoleMessage;

    public static String BranchAction_0;
    public static String BranchAction_1;
    public static String BranchAction_2;

    public static String ChangeSetAction_0;
    public static String ChangeSetAction_1;

    public static String ChangeSharingWizard_0;
    public static String ChangeSharingWizard_00;
    public static String ChangeSharingWizard_1;
    public static String ChangeSharingWizard_10;
    public static String ChangeSharingWizard_2;
    public static String ChangeSharingWizard_2m;

    public static String ChangeSharingWizard_20;
    public static String ChangeSharingWizard_20m;
    public static String ChangeSharingWizard_3;

    public static String ProjectHistoryAction_0;
    public static String ProjectHistoryAction_1;

    public static String CompareWithLocalAction_0;
    public static String CompareWithLocalAction_2;
    public static String CompareWithLocalAction_3;

    public static String UploadWizard_0;
    public static String UploadWizard_10;
    public static String UploadWizard_11;
    public static String UploadWizard_12;

    public static String CommitWizard_1;
    public static String CommitWizard_2;
    public static String CommitWizard_3;
    public static String CommitWizard_4;
    public static String CommitWizard_5;
    public static String CommitWizard_6;
    public static String CommitWizard_7;
    public static String CommitWizard_8;
    public static String CommitWizard_9;
    public static String CommitWizard_10;
    public static String CommitWizard_11;

    // SyncSelectForeignStreamDialog
    public static String SyncSelectForeignDialogStream_title;
    public static String SyncSelectForeignDialogProject_title;
    public static String SyncSelectForeignDialogStreamProject_title;
    public static String SyncSelectForeignDialogStream_description;
    public static String SyncSelectForeignDialogProject_description;
    public static String SyncSelectForeignDialogStreamProject_description;
    public static String SyncSelectForeignStreamDialog_selectAll;
    public static String SyncSelectForeignStreamDialog_deselectAll;

    public static String SynchAgainstRequestAction_updRecursive_title;
    public static String SynchAgainstRequestAction_updRecursive_confirm;
    public static String SynchAgainstRequestAction_updRecursive_conflict_title;
    public static String SynchAgainstRequestAction_updRecursive_conflict_messagePath;
    public static String SynchAgainstRequestAction_updRecursive_conflict_messageItem;
    public static String SynchAgainstRequestAction_nonWSProjects_title;
    public static String SynchAgainstRequestAction_nonWSProjects_message1;
    public static String SynchAgainstRequestAction_nonWSProjects_message2;

    public static String SwitchProjectAction_wsPointingToForeignStream;
    public static String SwitchProjectAction_wsNotInSyncWithHome;

    public static String ConnectionSelector_title;

    public static String ConnectionSelector_desc;

    public static String WorksetSelectionPage_browse;

    public static String WorksetSelectionPage_find;

    public static String WorksetSelectionPage_launchFind;

    public static String WorksetSelectionPage_shareExisting;

    public static String WorksetSelectionPage_shareNew;

    public static String WorksetUpdateOptionsPage_0resetButton;

    public static String WorksetUpdateOptionsPage_1cleanButton;

    public static String IgnoreResourcesDialog_addRecursivelyCheckBox;

    public static String DelegateDialog_title;
    public static String DelegateDialog_okText;
    public static String RebaseDialog_title;
    public static String RebaseDialog_okText;

    public static String SelectWithThreeDots;
    public static String StreamOrProjectDoesNotExistInProduct;
    public static String ProductDoesNotMatch;
    public static String RequestDoesNotExist;
    public static String ParentIsRequired;
    public static String RequestToMergeChanges;
    public static String RehomeExistingProjectsIn;
    public static String AddToWorkspace;
    public static String DoNotAddToWorkspace;
    public static String WorkWillBeMergedInto;
    public static String TopicStreamEmptyBasedOnDescription;
    public static String TopicStreamBasedOnDescription;

    public static String Originator;
    public static String ProjectsCount;
    public static String TargetProjectIsEmpty;
    public static String SourceAndTargetAreTheSame;
    public static String TargetProject;
    public static String SelectSpecificVersion;
    public static String StreamNameContainsInvalidCharacters;
    public static String ProjectsInTargetStreamHaveSameNamesInWorkspace;
    public static String DoYouWantRemoveProjectsFromWorkspace;
    public static String SelectProjectsToRemoveFromWorkspace;
    public static String ProjectName;
    public static String Project;
    public static String Projects;
    public static String MoreProjectsWillBeAlsoRehomed;
    public static String Rehome;
    public static String CannotFindWorkAreaToRehome;
    public static String RehomingWorkspaceProjects;
}

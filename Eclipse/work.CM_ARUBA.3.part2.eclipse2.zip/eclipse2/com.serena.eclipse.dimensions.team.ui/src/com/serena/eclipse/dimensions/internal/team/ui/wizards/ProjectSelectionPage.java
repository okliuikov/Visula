/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectSelectionPanel;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * Allows to find or browse to a project or baseline.
 *
 * @author V.Grishchenko
 */
public class ProjectSelectionPage extends DimensionsWizardPage {
    private boolean allowWorksets = true;
    private boolean allowBaselines = true;
    private boolean allowNull = false;
    private String panelMessage;
    private String nullSelectionText;
    private ProjectSelectionPanel projectSelectionPanel;
    private DimensionsConnectionDetailsEx connection;
    private VersionManagementProject[] selection;
    private IPath[] defaultOffsets; // if more than one then called on multiple projects
    private boolean showOnlyStreams;// Show only Streams in the list
    private boolean showOnlyProjects;// Show only Projects in the list
    private String defaultProductSpec;

    // since 14.1 to support three way merge wizard
    private boolean mergeMode;
    private DimensionsArObject mergeTargetAPIObject;

    public ProjectSelectionPage(String pageName, String title, String description, ImageDescriptor titleImage,
            boolean showOnlyStreams, boolean showOnlyProjects) {
        super(pageName, title, titleImage, description);
        this.showOnlyProjects = showOnlyProjects;
        this.showOnlyStreams = showOnlyStreams;
        validate();
    }

    /**
     * Controls if this page will allow to select worksets.
     * @param allowWorksets
     */
    public void setAllowWorksets(boolean allowWorksets) {
        this.allowWorksets = allowWorksets;
    }

    /**
     * Controls if this page will allow to select baselines.
     * @param allowBaselines
     */
    public void setAllowBaselines(boolean allowBaselines) {
        this.allowBaselines = allowBaselines;
    }

    /**
     * Controls if this page will enforce selection.
     * @param allowNull
     */
    public void setAllowNull(boolean allowNull) {
        this.allowNull = allowNull;
        validate();
    }

    /**
     * Sets the optional message that will be displayed in the page body.
     * @param message
     */
    public void setPageMessage(String message) {
        this.panelMessage = message;
    }

    /**
     * Sets the null selection text.
     * @param nullSelectionText The nullSelectionText to set.
     */
    public void setNullSelectionText(String nullSelectionText) {
        this.nullSelectionText = nullSelectionText;
    }

    /**
     * @param connection The connection to set.
     */
    public void setConnection(DimensionsConnectionDetailsEx connection) {
        this.connection = connection;
        if (projectSelectionPanel != null) {
            projectSelectionPanel.setConnection(connection);
        }
    }

    /**
     * Sets scc offset used when preselecting an scc project from a found project
     * or baseline.
     * @param defaultOffset The defaultOffset to set.
     */
    public void setDefaultOffset(IPath defaultOffset) {
        if (this.defaultOffsets == null) {
            this.defaultOffsets = new IPath[1];
        }
        this.defaultOffsets[0] = defaultOffset;
    }

    // for multiple
    public void setDefaultOffsets(IPath[] defaultOffsets) {

        this.defaultOffsets = defaultOffsets;
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        composite.setLayout(new FillLayout());

        int mode = 0;
        if (allowWorksets) {
            mode |= ProjectSelectionPanel.WORKSET;
        }
        if (allowBaselines) {
            mode |= ProjectSelectionPanel.BASELINE;
        }
        if (defaultOffsets != null && defaultOffsets.length > 1) {
            mode |= ProjectSelectionPanel.MULTIPLE;
        }
        if (isMergeMode()) {
            mode |= ProjectSelectionPanel.THREE_WAY_MERGE_MODE;
        }

        int options = 0;
        if (allowNull) {
            options = ProjectSelectionPanel.SHOW_NULL_SELECTION;
        }

        projectSelectionPanel = new ProjectSelectionPanel(mode, composite, SWT.NONE, panelMessage, options, nullSelectionText,
                showOnlyStreams, showOnlyProjects);
        if (connection != null) {
            projectSelectionPanel.setConnection(connection);
        }
        projectSelectionPanel.setDefaultOffset(defaultOffsets);
        projectSelectionPanel.setDefaultProduct(getDefaultProductSpec());
        projectSelectionPanel.addPropertyChangeListener(new IPropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent event) {
                if (ProjectSelectionPanel.SELECTION.equals(event.getProperty())) {
                    selectionChanged();
                }
            }
        });

        setControl(composite);
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            validateSelection();
            validate();
        }
        super.setVisible(visible);
    }

    /**
     * @return selected project or <code>null</code> if none
     */
    public VersionManagementProject[] getSelection() {
        if (this.selection == null) {
            return null;
        } else {
            return this.selection;
        }
    }

    /**
     * Clears the selection, error message and makes this page complete.
     */
    public void reset() {
        this.selection = null;
        setErrorMessage(null);
        setPageComplete(true);
    }

    public void selectionChanged() {
        if (projectSelectionPanel != null) {
            validateSelection();
        }
        validate();
    }

    private void validateSelection() {
        VersionManagementProject[] selection = projectSelectionPanel.getSelection();
        this.selection = selection;
    }

    private void validate() {
        if (allowNull) {
            if (!isPageComplete()) {
                setErrorMessage(null);
                setPageComplete(true);
            }
        } else {
            if (selection == null) {
                setPageComplete(false);
            } else {
                if (selection.length > 0 && selection[0] == null) {
                    setErrorMessage(null);
                    setPageComplete(false);
                } else {
                    setErrorMessage(null);
                    setPageComplete(true);
                }
            }
        }
    }

    /**
     * @return if page is embedded to three way merge wizard
     */
    public boolean isMergeMode() {
        return mergeMode;
    }

    /**
     * @param mergeMode true if page should be embedded to three way merge wizard
     */
    public void setMergeMode(boolean mergeMode) {
        this.mergeMode = mergeMode;
    }

    /**
     * @return API object to validate user selection if merge mode was set to true
     */
    public DimensionsArObject getMergeTargetAPIObject() {
        return mergeTargetAPIObject;
    }

    /**
     * @param targetWorkset
     *            API object to validate user selection if merge mode was set to true
     */
    public void setMergeTargetAPIObject(DimensionsArObject targetWorkset) {
        this.mergeTargetAPIObject = targetWorkset;
    }

    /**
     * @return product that should be preselected
     */
    public String getDefaultProductSpec() {
        return defaultProductSpec;
    }

    /**
     * @param product
     *            that will be preselected
     */
    public void setDefaultProductSpec(String product) {
        this.defaultProductSpec = product;
    }

}

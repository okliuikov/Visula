/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;

import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UpdateFromRemoteOperation;

/**
 * Brings non-conflicting incoming changes down to workspace from repository.
 * User is notified of any conflicts and given an option to show them in
 * the synchronize view.
 *
 * @author V.Grishchenko
 */
public class UpdateAction extends DMWorkspaceAction {
    private static final IDMWorkspaceResourceFilter FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED, StatusFilter.AND);

    public UpdateAction() {
    }

    @Override
    protected boolean isEnabledForSelection() {
        if (isSelectedSccProjectsMoved()) {
            return false;
        } else {
            return super.isEnabledForSelection();
        }
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources;
        try {
            resources = getResources();
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        if (resources.length == 0) {
            return;
        }

        UpdateFromRemoteOperation operation = new UpdateFromRemoteOperation(getActivePart(), resources);
        operation.run();
    }

    @Override
    protected boolean isEnabledForMultipleConnections() {
        return true;
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return FILTER; // enable only if managed
    }

}

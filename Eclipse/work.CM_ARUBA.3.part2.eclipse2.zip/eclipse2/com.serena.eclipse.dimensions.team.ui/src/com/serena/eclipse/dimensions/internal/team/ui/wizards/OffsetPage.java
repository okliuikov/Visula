/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Part;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.Product;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.FolderSelectionDialog;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FileSystemSelectionDialog;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * Offset & design part page for Sharing Project Wizard.
 *
 * @author Artem Solod
 */
public class OffsetPage extends DimensionsWizardPage {
    private Text txtOffset;
    private Text txtWorkArea;
    private Combo cmbPart;
    private String productForParts;
    private String offset;
    private Button btnBrowseOffset;
    private Button btnBrowsePart;
    private Button btnBrowseWorkArea;
    private IProject project;

    private boolean initialized;
    private boolean inContainerInit;
    private String projectSpecInit;
    private int waCheckStatus;
    private IPath waPath;
    private boolean isValidWorkAreaPath;
    private Pattern pathPattern;

    public class ContainerFolderFilter extends ViewerFilter {

        @Override
        public boolean select(Viewer viewer, Object parentElement, Object element) {
            // if folder contains an eclipse project dont show it
            if (element instanceof RepositoryFolder) {
                RepositoryFolder folder = (RepositoryFolder) element;
                Filter markers = new Filter();
                Filter.Criterion crit1 = new Filter.Criterion();
                crit1.setAttribute(SystemAttributes.TYPE_NAME);
                crit1.setValue(IDMConstants.TYPE_PROJECT);
                crit1.setFlags(Filter.Criterion.EQUALS);
                markers.criteria().add(crit1);
                Filter.Criterion crit2 = new Filter.Criterion();
                crit2.setAttribute(SystemAttributes.ITEMFILE_FILENAME);
                crit2.setValue(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER_MASK);
                crit2.setFlags(Filter.Criterion.EQUALS);
                markers.criteria().add(crit2);
                folder.flushRelatedObjects(ItemRevision.class, true);
                List markerfiles = folder.getChildItems(markers);
                folder.flushRelatedObjects(ItemRevision.class, true);
                if (markerfiles != null && markerfiles.size() > 0) {
                    return false;
                }
            }
            return true; // always return true
        }

    }

    public OffsetPage(String pageName, String title, String description, ImageDescriptor titleImage, IProject project) {
        super(pageName, title, titleImage, description);
        this.project = project;
        if (project != null) {
            offset = project.getName();
        }
        if (File.separatorChar == '\\') {
            // Windows
            pathPattern = Pattern.compile("([a-zA-Z]:\\\\){1}([\\w.-]+\\\\?)*"); // use conservative pattern
        } else {
            // Unix
            pathPattern = Pattern.compile("/{1}([\\w.]+/?)*"); // use conservative pattern
        }
        setPageComplete(false);
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 2);

        UIUtils.createLabel(composite, Messages.SharingOffsetPage_work_area_root);
        UIUtils.createLabel(composite, Utils.EMPTY_STRING);
        txtWorkArea = new Text(composite, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(txtWorkArea, GridData.FILL_HORIZONTAL);
        txtWorkArea.setEditable(false);

        btnBrowseWorkArea = new Button(composite, SWT.PUSH);
        btnBrowseWorkArea.setText("...");
        btnBrowseWorkArea.setEnabled(false);
        UIUtils.setGridData(btnBrowseWorkArea, GridData.HORIZONTAL_ALIGN_END);

        txtWorkArea.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                // direct input only under these conditions, otherwise - programmatic
                if (waCheckStatus == SharingWizard.PROJECT_NOT_WA && inContainerInit) {
                    waPath = pathPattern.matcher(txtWorkArea.getText()).matches() ? Path.fromOSString(txtWorkArea.getText()) : null;
                    if (waPath == null || waPath.segmentCount() >= project.getLocation().segmentCount()
                            || !waPath.isPrefixOf(project.getLocation())) {
                        isValidWorkAreaPath = false;
                        txtOffset.setText(Utils.EMPTY_STRING); // rely on txtOffset invoking checkPage
                    } else {
                        isValidWorkAreaPath = true;
                        // rely on txtOffset invoking checkPage
                        txtOffset.setText(project.getLocation().makeRelativeTo(waPath).toString());
                    }
                } else {
                    checkPage();
                }
            }
        });
        btnBrowseWorkArea.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                FileSystemSelectionDialog dialog = new FileSystemSelectionDialog(btnBrowseWorkArea.getShell(), false,
                        FileSystemSelectionDialog.FOLDER);
                dialog.setTitle(Messages.SharingOffsetPage_work_area_dlg_title);
                dialog.setMessage(Messages.SharingOffsetPage_work_area_dlg_message);
                String rootPath = (project.getLocation().getDevice() != null)
                        ? project.getLocation().getDevice() + File.separator : File.separator;
                dialog.setInput(new File(rootPath));

                // this filter is invoked after folders only(FileSystemSelectionDialog.FOLDER) were filtered by a content provider
                dialog.addFilter(new ViewerFilter() {
                    private final IPath projectParentPath = project.getLocation().removeLastSegments(1);

                    @Override
                    public boolean select(Viewer viewer, Object parentElement, Object element) {
                        if (element instanceof File) {
                            try {
                                IPath filePath = Path.fromOSString(((File) element).getCanonicalPath());
                                if (filePath.isPrefixOf(projectParentPath)) {
                                    return true;
                                }
                            } catch (IOException e) {
                                setErrorMessage(e.getMessage());
                            }
                        }
                        return false;
                    }
                });
                if (txtWorkArea.getText() != null && txtWorkArea.getText().length() > 0) {
                    dialog.setInitialSelection(new File(txtWorkArea.getText()));
                }
                if (dialog.open() == Window.OK) {
                    try {
                        String waPath = ((File) dialog.getFirstResult()).getCanonicalPath();
                        txtWorkArea.setText(waPath);
                    } catch (IOException e1) {
                        setErrorMessage(e1.getMessage());
                    }
                }
            }
        });

        UIUtils.createLabel(composite, Messages.SharingOffsetPage_offset);
        UIUtils.createLabel(composite, Utils.EMPTY_STRING);
        txtOffset = new Text(composite, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(txtOffset, GridData.FILL_HORIZONTAL);
        txtOffset.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                offset = txtOffset.getText();
                checkPage();
            }
        });
        txtOffset.setEditable(false);
        btnBrowseOffset = new Button(composite, SWT.PUSH);
        btnBrowseOffset.setText("...");
        btnBrowseOffset.setEnabled(false);
        UIUtils.setGridData(btnBrowseOffset, GridData.HORIZONTAL_ALIGN_END);
        btnBrowseOffset.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                Project container = ((SharingWizard) getWizard()).getContainerProject();
                if (null == container) {
                    return;
                }

                FolderSelectionDialog dialog = new FolderSelectionDialog(getControl().getShell(),
                        Messages.SharingOffsetPage_selectFolder_title, container, new ContainerFolderFilter());

                if (Window.OK == dialog.open()) {
                    RepositoryFolder folder = dialog.getSelectedFolder();
                    offset = txtOffset.getText();
                    int idx = offset.lastIndexOf("/");
                    if (-1 != idx) {
                        offset = offset.substring(++idx);
                    }
                    IPath fpath = new Path(folder.getName());
                    if (!fpath.isRoot()) {
                        txtOffset.setText(offset = fpath.append(offset).toString());
                    } else {
                        txtOffset.setText(offset);
                    }
                }
            }
        });

        UIUtils.createLabel(composite, Messages.SharingOffsetPage_part);
        UIUtils.createLabel(composite, Utils.EMPTY_STRING);
        cmbPart = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
        UIUtils.setGridData(cmbPart, GridData.FILL_HORIZONTAL);
        cmbPart.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                checkPage();
            }
        });

        cmbPart.addPaintListener(new PaintListener() {
            @Override
            public void paintControl(PaintEvent e) {
                if (getWizard() instanceof SharingWizard && null != ((SharingWizard) getWizard()).getProductName()
                        && !((SharingWizard) getWizard()).getProductName().equals(productForParts)) {
                    List items = getAllProductPartsFromDM();
                    productForParts = ((SharingWizard) getWizard()).getProductName();
                    cmbPart.removeAll();
                    for (int i = 0; i < items.size(); i++) {
                        cmbPart.add((String) items.get(i));
                    }

                    // select default part. It is named as product
                    for (int i = 0; i < cmbPart.getItemCount(); i++) {
                        if (cmbPart.getItem(i).length() >= productForParts.length()
                                && cmbPart.getItem(i).substring(0, productForParts.length()).equals(productForParts)) {
                            cmbPart.select(i);
                            break;
                        }
                        cmbPart.select(0);
                    }

                    if (0 == cmbPart.getItemCount()) {
                        setPageComplete(false);
                        setErrorMessage(Messages.NewStreamWizard_stream_general_err10);
                    }
                    checkPage();
                }
            }
        });

        btnBrowsePart = new Button(composite, SWT.PUSH);
        btnBrowsePart.setText("...");
        btnBrowsePart.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                SharingWizard wiz = (SharingWizard) getWizard();
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.PART,
                        wiz.getConnection(), wiz.getProductName(), true, false);
                if (dialog.open() == Window.OK) {
                    List<String> parts = dialog.getSelectedNames();
                    int selection = -1;
                    for (int i = 0; i < parts.size(); i++) {
                        String part = parts.get(i);
                        int index = part.indexOf(":");
                        part = part.substring(index + 1);
                        for (int j = 0; j < cmbPart.getItemCount(); j++) {
                            if (cmbPart.getItem(j).equals(part)) {
                                selection = j;
                            }
                        }
                    }
                    cmbPart.select(selection);
                }
            }
        });
        setControl(composite);

        initializeValues(); // init on creation
        checkPage();

        // DEF217861 fix for MacOS
        getShell().layout(false, true);
        UIUtils.getDisplay().readAndDispatch();
    }

    public String getOffset() {
        return safeGetText(txtOffset);
    }

    public String getPart() {
        return safeGetText(cmbPart);
    }

    public String getWorkArea() {
        return safeGetText(txtWorkArea);
    }

    private List getAllProductPartsFromDM() {
        if (!(getWizard() instanceof SharingWizard) || null == ((SharingWizard) getWizard()).getProductName()) {
            return Collections.EMPTY_LIST;
        }
        SharingWizard wiz = (SharingWizard) getWizard();
        final ArrayList result = new ArrayList();
        try {
            final Product product = wiz.getConnection().getProduct(wiz.getProductName(), null);

            Session session = wiz.getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    Filter openFilter = new Filter();
                    openFilter.criteria().add(new Filter.Criterion(SystemAttributes.STATUS, "OPEN", Filter.Criterion.EQUALS)); //$NON-NLS-1$
                    List productParts = product.getParts(openFilter);
                    for (Iterator partIter = productParts.iterator(); partIter.hasNext();) {
                        Part part = (Part) partIter.next();
                        String spec = (String) part.getAttribute(SystemAttributes.OBJECT_SPEC);
                        String name = spec.substring(spec.indexOf(":") + 1); //$NON-NLS-1$
                        result.add(name);
                    }
                }
            }, null);
        } catch (DMException e) {
            setErrorMessage(e.getMessage());
            return Collections.EMPTY_LIST;
        }
        return result;
    }

    private void checkPage() {
        setMessage(null);
        setErrorMessage(null);
        setPageComplete(true);
        String[] holder = new String[1];
        if (waCheckStatus == SharingWizard.PROJECT_NOT_WA && inContainerInit && !isValidWorkAreaPath) {
            setErrorMessage(Messages.NewStreamWizard_stream_offset_err4);
            setPageComplete(false);
        } else if (TeamUtils.projectPathNotWritable(project.getLocation(), waPath, holder)) {
            setPageComplete(false);
            setErrorMessage(NLS.bind(Messages.NewStreamWizard_stream_offset_err6, holder[0]));
        } else if (waCheckStatus == SharingWizard.PROJECT_NOT_WA && inContainerInit && waPath.isRoot()) {
            // warn a user selecting disk root as wa root
            setMessage(Messages.NewStreamWizard_stream_offset_err5, IMessageProvider.WARNING);
        } else if (waCheckStatus == SharingWizard.PROJECT_INCOMPATIBLE_WA) { // fatal - cannot proceed further
            setErrorMessage(Messages.NewStreamWizard_stream_offset_err3);
            setPageComplete(false);
        } else if (null != txtOffset && txtOffset.getEditable() && Utils.isNullEmpty(txtOffset.getText())) {
            setErrorMessage(Messages.NewStreamWizard_stream_offset_err1);
            setPageComplete(false);
        } else if (null != cmbPart && Utils.isNullEmpty(cmbPart.getText())) {
            setErrorMessage(Messages.NewStreamWizard_stream_offset_err2);
            setPageComplete(false);
        }
    }

    private String safeGetText(final Text ctrl) {
        if (null == ctrl) {
            return null;
        }

        final String[] res = new String[1];
        ctrl.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                res[0] = ctrl.getText();
            }
        });
        return res[0];
    }

    private String safeGetText(final Combo ctrl) {
        if (null == ctrl) {
            return null;
        }

        final String[] res = new String[1];
        ctrl.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                res[0] = ctrl.getText();
            }
        });
        return res[0];
    }

    public void initializeValues() {
        if (getControl() == null) {
            return;
        }

        if ((WorksetSelectionPage) (getWizard().getPage(SharingWizard.WORKSET_PAGE_ID)) != null) {
            inContainerInit = ((WorksetSelectionPage) (getWizard().getPage(SharingWizard.WORKSET_PAGE_ID))).getCreateInContainer();
            VersionManagementProject projResult = ((WorksetSelectionPage) (getWizard().getPage(SharingWizard.WORKSET_PAGE_ID))).getResult();
            projectSpecInit = projResult != null ? projResult.getProjectSpec() : Utils.EMPTY_STRING;
        }
        IPath waResultingPath = null;
        // check wa in the hierarchy
        if (ResourcesPlugin.getWorkspace().getRoot().getLocation().isPrefixOf(project.getLocation())) {
            waCheckStatus = SharingWizard.PROJECT_WS; // project is in workspace
        } else {
            waResultingPath = TeamUtils.validateProjectWorkArea(project, projectSpecInit);
            if (waResultingPath == null) { // incompatible/multiple/nested wa
                waCheckStatus = SharingWizard.PROJECT_INCOMPATIBLE_WA;
            } else if (waResultingPath.isEmpty()) { // not under wa
                waCheckStatus = SharingWizard.PROJECT_NOT_WA;
            } else { // under compatible wa
                waCheckStatus = SharingWizard.PROJECT_COMPATIBLE_WA; // waResultingPath is valid here
            }
        }

        if (inContainerInit) {
            switch (waCheckStatus) {
            case SharingWizard.PROJECT_WS: // in workspace - work area's implicitly project folder
                txtOffset.setEditable(true);
                txtOffset.setText(offset);
                btnBrowseOffset.setEnabled(true);

                txtWorkArea.setEditable(false);
                txtWorkArea.setText(Utils.EMPTY_STRING);
                btnBrowseWorkArea.setEnabled(false);
                break;
            case SharingWizard.PROJECT_COMPATIBLE_WA:
                // wa path restricted to the compatible wa path, offset is relative to this path
                txtOffset.setEditable(false);
                txtOffset.setText(project.getLocation().makeRelativeTo(waResultingPath).toString());
                btnBrowseOffset.setEnabled(false);

                txtWorkArea.setEditable(false);
                txtWorkArea.setText(waResultingPath.toOSString());
                btnBrowseWorkArea.setEnabled(false);
                break;
            case SharingWizard.PROJECT_NOT_WA: // could select paths above the project folder as wa, change offset to path in wa
                txtOffset.setEditable(false);
                btnBrowseOffset.setEnabled(false);

                txtWorkArea.setEditable(true);
                txtWorkArea.setText(project.getLocation().removeLastSegments(1).removeTrailingSeparator().toOSString());
                btnBrowseWorkArea.setEnabled(true);
                break;
            case SharingWizard.PROJECT_INCOMPATIBLE_WA: // fatal: nothing to do here
                txtOffset.setEditable(false);
                txtOffset.setText(Utils.EMPTY_STRING);
                btnBrowseOffset.setEnabled(false);

                txtWorkArea.setEditable(false);
                txtWorkArea.setText(Utils.EMPTY_STRING);
                btnBrowseWorkArea.setEnabled(false);
                break;
            }
        } else { // not in container - no offset and work area's implicitly project folder
            txtOffset.setEditable(false);
            txtOffset.setText(Utils.EMPTY_STRING);
            btnBrowseOffset.setEnabled(false);

            txtWorkArea.setEditable(false);
            txtWorkArea.setText(Utils.EMPTY_STRING);
            btnBrowseWorkArea.setEnabled(false);
        }

        if (!btnBrowseOffset.isEnabled()) {
            setDescription(Messages.Sharingwizard_offsetPageDescrPart);
        } else {
            setDescription(Messages.Sharingwizard_offsetPageDescrFull);
        }

        initialized = true;
    }

    public boolean isInitialized() {
        return initialized;
    }

    public boolean isInContainerInit() {
        return inContainerInit;
    }

    public String getProjectSpecInit() {
        return projectSpecInit;
    }

}

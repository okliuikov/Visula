/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * Wizard for initiating a move operation.
 * @author V.Grishchenko
 */
public class MoveWizard extends TeamOperationWizard {

    public MoveWizard(MoveHelper helper) {
        super(helper, true);
        setWindowTitle(Messages.MoveWizard_0);
    }

    @Override
    protected int getMainPageOptions() {
        return TeamOperationWizardMainPage.SHOW_TREE;
    }

    @Override
    protected String getMainPageTitle() {
        return Messages.MoveWizard_1;
    }

    @Override
    protected String getMainPageDescription() {
        return Messages.MoveWizard_2;
    }

    @Override
    protected TeamOperationWizardAttributesPage createAttributesPage(String name) {
        return null;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.HashSet;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.TransferToStreamOperationData;
import com.serena.eclipse.dimensions.internal.team.core.TransferShape;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.UploadHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.UploadWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class DeliverOperation extends WizardOperation {

    public DeliverOperation(IWorkbenchPart part, IResource[] resources) {
        super(part, resources, null);
    }

    public DeliverOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    @Override
    protected void execute(OperationData commandData, IProgressMonitor monitor) throws CoreException, InterruptedException {
        TransferToStreamOperationData deliverData;
        if (!(commandData instanceof TransferToStreamOperationData)) {
            deliverData = new TransferToStreamOperationData(commandData.getProvider(), commandData.getRequests(), new HashSet<IResource>(),
                    new TransferShape.ListShape());
        } else {
            deliverData = (TransferToStreamOperationData) commandData;
        }

        execute(deliverData, monitor);
    }

    public void execute(TransferToStreamOperationData commandData, IProgressMonitor monitor) throws CoreException, InterruptedException {
        WorkspaceResourceRequest[] requests = commandData.getRequestsArray();

        if (requests == null || requests.length == 0) {
            return;
        }
        int totalWork = 1000 * (requests.length);
        monitor.beginTask(null, totalWork);

        try {
            commandData.getProject().deliver(commandData, Utils.subMonitorFor(monitor, 1000 * requests.length));
        } finally {
            monitor.done();
        }
    }

    @Override
    protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
        return new UploadHelper(getResources(), getFilter(), monitor);
    }

    @Override
    protected TeamOperationWizard createWizard(TeamOperationWizardHelper helper) {
        UploadHelper uploadHelper = (UploadHelper) helper;
        DMTeamUiPlugin.warnAboutCleanedCheckouts(uploadHelper.getCleanedCheckouts(), getShell());
        return new UploadWizard(uploadHelper);
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind(Messages.DeliverOperation_0, provider.getProject().getName());
    }

    @Override
    protected String getTaskName() {
        return Messages.DeliverOperation_1;
    }

}

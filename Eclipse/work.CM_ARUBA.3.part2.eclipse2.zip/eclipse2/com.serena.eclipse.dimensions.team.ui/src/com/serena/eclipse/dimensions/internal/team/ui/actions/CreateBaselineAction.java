/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewRevisedBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewTemplateBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewTipBaselineWizard;

/**
 * @author V.Grishchenko
 */
public class CreateBaselineAction extends DMWorkspaceAction {
    private static String idFirst = "com.serena.eclipse.dimensions.team.ui.actions."; // NON-NLS-1$
    private static String idTip = idFirst + "CreateTipBaseline"; // NON-NLS-1$
    private static String idTemplate = idFirst + "CreateTemplateBaseline"; // NON-NLS-1$
    private static String idRevised = idFirst + "CreateRevisedBaseline"; // NON-NLS-1$

    public CreateBaselineAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources = getSelectedResources();
        if (resources == null || resources.length == 0 || resources[0].getType() != IResource.PROJECT) {
            return;
        }
        IProject project = (IProject) resources[0];
        VersionManagementProject remoteProject = getRemoteProjectFor(project);
        NewBaselineWizard baselineWizard = null;
        String id = getAction().getId();
        if (remoteProject != null && remoteProject instanceof WorksetAdapter) {
            if (id.equals(idTip)) {
                baselineWizard = new NewTipBaselineWizard(remoteProject.getConnectionDetails(), remoteProject);
            } else if (id.equals(idTemplate)) {
                baselineWizard = new NewTemplateBaselineWizard(remoteProject.getConnectionDetails(), remoteProject);
            }
        } else if (remoteProject != null && remoteProject instanceof BaselineAdapter) {
            if (id.equals(idRevised)) {
                baselineWizard = new NewRevisedBaselineWizard(remoteProject.getConnectionDetails(), remoteProject);
            }
        }
        if (baselineWizard != null) {
            WizardDialog dialog2 = new WizardDialog(getShell(), baselineWizard);
            dialog2.open();
        }
    }

    @Override
    protected boolean isEnabledForMultipleResources() {
        return false;
    }

    @Override
    protected boolean needsToSaveDirtyEditors() {
        return false; // no need to save before creating baseline as local changes are not included anyway
    }

    @Override
    protected boolean isEnabledForBaseline() {
        String id = getAction().getId();
        if (id.equals(idTip) || id.equals(idTemplate)) {
            return false;
        } else if (id.equals(idRevised)) {
            return true;
        }
        return super.isEnabledForBaseline();
    }

    @Override
    protected boolean isEnabledForWorkset() {
        String id = getAction().getId();
        if (id.equals(idTip) || id.equals(idTemplate)) {
            return true;
        } else if (id.equals(idRevised)) {
            return false;
        }
        return super.isEnabledForWorkset();
    }

}

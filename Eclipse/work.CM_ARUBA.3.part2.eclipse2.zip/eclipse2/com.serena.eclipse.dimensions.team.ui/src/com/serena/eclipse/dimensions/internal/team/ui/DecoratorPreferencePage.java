/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class DecoratorPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage, IDMTeamPreferences {

    public DecoratorPreferencePage() {
        super(GRID);
        setDescription(Messages.decoratorPrefPage_descr);
        setPreferenceStore(DMTeamUiPlugin.getDefault().getPreferenceStore());
    }

    @Override
    protected void createFieldEditors() {
        addField(new BooleanFieldEditor(DECORATE_DEEP_STATUS_FOLDERS, Messages.decoratorPrefPage_fldDeep, getFieldEditorParent()));

        addField(new BooleanFieldEditor(DECORATE_FORCE_DEEP_STATUS_PROJECT, Messages.decoratorPrefPage_prjDeepForce,
                getFieldEditorParent()));

        addField(new BooleanFieldEditor(DECORATE_REMOTE_INFO_PROJECT, Messages.decoratorPrefPage_prjRemoteInfo,
                getFieldEditorParent()));

        addField(new BooleanFieldEditor(DECORATE_BASE_REVISION, Messages.decoratorPrefPage_fileBase, getFieldEditorParent()));

        addField(new BooleanFieldEditor(DECORATE_REMOTE_REVISION, Messages.decoratorPrefPage_fileRemote, getFieldEditorParent()));

        addField(new BooleanFieldEditor(DECORATE_LOCALLY_MODIFIED_TEXT, Messages.decoratorPrefPage_modified, getFieldEditorParent()));

        addField(new BooleanFieldEditor(DECORATE_LOCALLY_MODIFIED, Messages.decoratorPrefPage_modifiedImage, getFieldEditorParent()));

        addField(new BooleanFieldEditor(DECORATE_LOCAL_MODE, Messages.decoratorPrefPage_localMode, getFieldEditorParent()));

    }

    @Override
    public void init(IWorkbench workbench) {
    }

    @Override
    public boolean performOk() {
        boolean ok = super.performOk();
        DMTeamUiPlugin.getDefault().savePluginPreferences();
        return ok;
    }

}

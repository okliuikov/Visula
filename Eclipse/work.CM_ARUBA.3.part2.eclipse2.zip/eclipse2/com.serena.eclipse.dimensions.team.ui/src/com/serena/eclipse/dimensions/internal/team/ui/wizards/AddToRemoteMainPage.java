/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2007, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.dmclient.api.ItemRevisionDetails;
import com.serena.dmclient.api.Part;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.CreateItemRequest;
import com.serena.eclipse.dimensions.internal.team.core.FileRequest;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Adds an ability to select the owning design part for new items.
 *
 * @author V.Grishchenko
 */
public class AddToRemoteMainPage extends TeamOperationWizardMainPage {
    private static final int OK = 0;
    private static final int INVALID_PART = 1;
    private static final int MULTI_PRODUCTS = 2; // selection is from multiple products
    private static final int MULTI_PARTS = 3; // selection contains multiple parts
    private static final int NOT_ADDITION = 4; // selection contains files that are not "additions"

    private Combo partCmb;
    private Button findPartBtn;
    private FormToolkit formToolkit;

    private List<Part> allParts;
    private Map partsByProduct; // productName -> {part}

    private IFile[] selectedFiles;
    private String productFromSelection;
    private int comboState;
    private boolean processEvents = true;

    public AddToRemoteMainPage(String pageName, String title, String description, ImageDescriptor titleImage, int options) {
        super(pageName, title, description, titleImage, options);
    }

    @Override
    public void dispose() {
        if (formToolkit != null) {
            formToolkit.dispose();
        }
        super.dispose();
    }

    @Override
    public void setHelper(TeamOperationWizardHelper helper) {
        super.setHelper(helper);
        allParts = helper.getParts();
        partsByProduct = new HashMap();

        // separate by product
        for (Iterator<Part> iter = allParts.iterator(); iter.hasNext();) {
            Part part = iter.next();
            String partSpec = (String) part.getAttribute(SystemAttributes.OBJECT_SPEC);
            String product = (String) part.getAttribute(SystemAttributes.PRODUCT_NAME);
            List productParts = (List) partsByProduct.get(product);
            if (productParts == null) {
                productParts = new ArrayList();
                partsByProduct.put(product, productParts);
            }
            productParts.add(partSpec);
        }

        // sort parts and convert to string arrays
        for (Iterator iter = partsByProduct.entrySet().iterator(); iter.hasNext();) {
            Map.Entry entry = (Map.Entry) iter.next();
            List specList = (List) entry.getValue();
            String[] specArr = (String[]) specList.toArray(new String[specList.size()]);
            Arrays.sort(specArr);
            entry.setValue(specArr);
        }
    }

    @Override
    protected CTabItem[] createExtraTabs(CTabFolder cTabFolder) {
        CTabItem addSettingsItem = new CTabItem(cTabFolder, SWT.NONE);
        addSettingsItem.setText(Messages.AddToRemoteMainPage_0);
        formToolkit = new FormToolkit(getShell().getDisplay());
        Composite composite = formToolkit.createComposite(cTabFolder); // new Composite(cTabFolder, SWT.NONE);
        UIUtils.setGridLayout(composite, 3);
        addSettingsItem.setControl(composite);
        formToolkit.createLabel(composite, Messages.AddToRemoteMainPage_1);
        partCmb = new Combo(composite, SWT.DROP_DOWN);
        partCmb.setEnabled(false);
        formToolkit.adapt(partCmb);
        findPartBtn = formToolkit.createButton(composite, Messages.AddToRemoteMainPage_2, SWT.PUSH);
        findPartBtn.setToolTipText(Messages.AddToRemoteMainPage_3);
        findPartBtn.setEnabled(false);
        UIUtils.setGridData(partCmb, GridData.FILL_HORIZONTAL);
        hookListeners();
        return new CTabItem[] { addSettingsItem };
    }

    private void hookListeners() {
        partCmb.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                if (!processEvents) {
                    return;
                }
                comboState = INVALID_PART; // presume invalid
                validate(true);
                if (comboState == OK) {
                    setPartOnSelected(partCmb.getText().trim());
                }
            }
        });

        findPartBtn.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (productFromSelection != null) {
                    String foundPart = findPart(productFromSelection);
                    if (foundPart != null) {
                        partCmb.setText(foundPart);
                    }
                }
            }
        });
    }

    private void setPartOnSelected(String partText) {
        for (int i = 0; i < selectedFiles.length; i++) {
            IFile file = selectedFiles[i];
            FileRequest fileRequest = getHelper().getFileRequest(file);
            if (fileRequest instanceof CreateItemRequest) {
                ((CreateItemRequest) fileRequest).setOwningPartSpecification(partText);
            }
        }
    }

    protected String findPart(String product) {
        FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), IDMConstants.PART, getHelper().getConnection(),
                product, true, false);
        if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {
            List<String> found = dialog.getSelectedNames();
            return found.get(0);
        }
        return null;
    }

    @Override
    protected void validate(boolean showError) {

        // validate basic data is ok, stop if not
        super.validate(showError);
        if (!isPageComplete() || productFromSelection == null) {
            return;
        }

        // check have valid part or in any special states
        boolean complete = true;
        String errorMsg = null;

        if (comboState != MULTI_PRODUCTS && comboState != MULTI_PARTS && comboState != NOT_ADDITION) {
            String[] productParts = (String[]) partsByProduct.get(productFromSelection);
            String partText = partCmb.getText().trim();
            boolean strict = partText.lastIndexOf(';') != -1; // consider PCS when cross checking
            boolean foundPart = false;
            for (int i = 0; i < productParts.length; i++) {
                String aPart = productParts[i];
                if (!strict) {
                    int idx = aPart.lastIndexOf(';');
                    if (idx != -1) {
                        aPart = aPart.substring(0, idx);
                    }
                }
                if (aPart.equalsIgnoreCase(partText)) {
                    foundPart = true;
                    break;
                }
            }

            if (!foundPart) {
                complete = false;
                errorMsg = NLS.bind(Messages.AddToRemoteMainPage_8, partText);
            }
        }

        setPageComplete(complete);
        setErrorMessage(errorMsg);
        comboState = complete ? OK : INVALID_PART;
    }

    @Override
    protected void resourceSelectionChanged(IResource[] newSelection) {
        super.resourceSelectionChanged(newSelection);

        selectedFiles = getSelectedFiles(newSelection);

        HashSet<String> products = new HashSet<String>();
        HashSet<String> currentParts = new HashSet<String>();

        for (int i = 0; i < selectedFiles.length; i++) {
            IFile file = selectedFiles[i];
            FileRequest fileRequest = getHelper().getFileRequest(file);
            if (!(fileRequest instanceof CreateItemRequest)) { // prevent mixed selections
                currentParts.clear();
                break;
            }
            ItemRevisionDetails ird = ((CreateItemRequest) fileRequest).getNewRevisionDetails();
            String product = ird.getProductName();
            String part = ird.getOwningPartSpecification();
            products.add(product);
            currentParts.add(part);
        }

        String comboTxt = Utils.EMPTY_STRING;
        boolean enable = false;
        String[] selectableParts = Utils.ZERO_LENGTH_STRING_ARRAY;

        if (currentParts.isEmpty()) {
            productFromSelection = null;
            comboTxt = Messages.AddToRemoteMainPage_5;
            comboState = NOT_ADDITION;
        } else {
            if (products.size() != 1) {
                comboTxt = Messages.AddToRemoteMainPage_6;
                productFromSelection = null;
                comboState = MULTI_PRODUCTS;
            } else {
                enable = true;
                productFromSelection = products.iterator().next();
                String[] productParts = (String[]) partsByProduct.get(productFromSelection);
                if (productParts != null) {
                    selectableParts = productParts;
                }
                if (currentParts.size() > 1) {
                    comboTxt = Messages.AddToRemoteMainPage_7;
                    comboState = MULTI_PARTS;
                } else {
                    comboTxt = currentParts.iterator().next();
                }
            }
        }

        processEvents = false;
        partCmb.setItems(selectableParts);
        partCmb.setText(comboTxt); // note that durules do not return PCS
        partCmb.setEnabled(enable);
        findPartBtn.setEnabled(enable);
        processEvents = true;
        validate(true);
    }

    private IFile[] getSelectedFiles(IResource[] newSelection) {
        IResource[] selected = TeamUtils.getNonOverlapping(newSelection);
        final ArrayList<IResource> files = new ArrayList<IResource>();
        ArrayList<IContainer> containers = new ArrayList<IContainer>();
        for (int i = 0; i < selected.length; i++) {
            IResource res = selected[i];
            if (res.getType() == IResource.FILE) {
                files.add(res);
            } else {
                containers.add((IContainer) res);
            }
        }

        for (Iterator<IContainer> iter = containers.iterator(); iter.hasNext();) {
            IContainer container = iter.next();
            try {
                container.accept(new IResourceVisitor() {
                    @Override
                    public boolean visit(IResource resource) throws CoreException {
                        if (resource.getType() == IResource.FILE && getHelper().showResource(resource)) {
                            files.add(resource);
                        }
                        return true;
                    }
                }, IResource.DEPTH_INFINITE, true);
            } catch (CoreException e) {
                DMTeamUiPlugin.getDefault().handle(e, getShell());
            }
        }

        return files.toArray(new IFile[files.size()]);
    }

}

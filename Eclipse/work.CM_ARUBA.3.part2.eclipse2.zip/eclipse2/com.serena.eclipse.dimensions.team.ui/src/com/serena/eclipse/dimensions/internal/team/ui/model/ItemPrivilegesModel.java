/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.model;

import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.ui.model.PrivilegesModel;

/**
 * Deals with specifics of getting of privileges from item.
 * @author V.Grishchenko
 */
public class ItemPrivilegesModel extends PrivilegesModel {

    /**
     * @param object
     */
    public ItemPrivilegesModel(ItemRevisionAdapter object) {
        super(object);
    }

    // currently the only way to ensure we get project-specific privileges is to set the current
    // project to the desired project, assume the context project of the underlying revision is
    // the project we want, if no project context available assume global
    @Override
    protected void beforePrivilegeFetch(Session session) throws Exception {
        session.getConnectionDetails().getChangeDefaultProjectLock().acquire();
        ItemRevision itemRevision = ((ItemRevisionAdapter) getUnderlyingObject()).getItemRevision();
        String projectId = IDMConstants.GLOBAL_WORKSET;
        Project project = itemRevision.getProject();
        if (project != null) {
            if (Utils.isNullEmpty((String) project.getAttribute(SystemAttributes.OBJECT_SPEC))) {
                project.queryAttribute(SystemAttributes.OBJECT_SPEC);
            }
            projectId = (String) project.getAttribute(SystemAttributes.OBJECT_SPEC);
        }
        session.getObjectFactory().setCurrentProject(projectId, false, null, null, null, true);
    }

    @Override
    protected void afterPrivilegeFetch(Session session) {
        session.getConnectionDetails().getChangeDefaultProjectLock().release();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.util.Iterator;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsCategoryElement;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsProjectsCategory;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;
import com.serena.eclipse.internal.ui.ServicesView;

/**
 * @author V.Grishchenko
 */
public class AddToGroupAction extends DimensionsAction {

    private APIObjectAdapter[] groups;

    private class MyDialog extends ResizableDialog {
        private DimensionsIDEProjectGroup selectedGroup;
        private Combo comboBox;

        public MyDialog(Shell parent) {
            super(parent);
        }

        @Override
        protected Control createDialogArea(Composite _parent) {

            getShell().setText(Messages.AddToGroup_title);

            Composite composite = (Composite) super.createDialogArea(_parent);
            GridLayout gridLayout = new GridLayout();
            gridLayout.numColumns = 1;
            GridData gridData = new GridData(GridData.FILL_BOTH | GridData.GRAB_HORIZONTAL);
            composite.setLayout(gridLayout);
            composite.setLayoutData(gridData);

            Label label = new Label(composite, SWT.NONE);

            label.setText(Messages.AddToGroup_label);

            comboBox = new Combo(composite, SWT.NONE);
            for (int i = 0; i < groups.length; i++) {
                comboBox.add(groups[i].getAPIObject().getName());
            }
            return composite;
        }

        @Override
        protected void okPressed() {
            int index = comboBox.getSelectionIndex();
            if (index >= 0) {
                selectedGroup = (DimensionsIDEProjectGroup) groups[index];
            }
            super.okPressed();
        }

        public DimensionsIDEProjectGroup getSelectedGroup() {
            return selectedGroup;
        }
    }

    @Override
    public void run(IAction action) {
        if (getSelection().isEmpty()) {
            return;
        }
        final DimensionsConnectionDetailsEx con = ((APIObjectAdapter) getSelection().getFirstElement()).getConnectionDetails();

        try {

            // Get The Groups
            WorksetList gpList = WorksetList.getDimensionsIDEProjectGroupsList(con, false, false);
            gpList.fetch(null);
            groups = gpList.getObjects();
            MyDialog dialog = new MyDialog(getShell());
            int ret = dialog.open();
            if (ret == Window.OK) {
                DimensionsIDEProjectGroup theGroup = dialog.getSelectedGroup();
                if (theGroup != null) {
                    // need to iterate
                    for (Iterator objit = getSelection().iterator(); objit.hasNext();) {
                        final VersionManagementProject toAdd = (VersionManagementProject) objit.next();

                        if (theGroup.groupContains(toAdd)) {
                            continue;
                        }
                        // get the projectName if an ide project
                        String pName = null;
                        if (!(toAdd instanceof SccProjectContainerWorkset)) {
                            toAdd.getAPIObject().queryAttribute(SystemAttributes.IDE_PROJECT_NAME);
                            pName = (String) toAdd.getAPIObject().getAttribute(SystemAttributes.IDE_PROJECT_NAME);
                        }
                        final String relLoc = pName; // ide project name or null

                        VersionManagementProject[] sameP = theGroup.groupContainsSameProject(toAdd);
                        // now get array
                        if (sameP != null && sameP.length >= 1) {
                            for (int same = 0; same < sameP.length; same++) {
                                // same project
                                String ideproject = toAdd.getAPIObject().getName();
                                String inGroup = sameP[same].getAPIObject().getName();
                                if (MessageDialog.openQuestion(getShell(), Messages.AddToGroup_title,
                                        NLS.bind(Messages.AddToGroup_SameProject_question, ideproject, inGroup))) {
                                    // replace it
                                    theGroup.removeMember(sameP[same], Messages.AddToGroup_removingSameProject_console_message);
                                    theGroup.addMember(toAdd, relLoc, Messages.AddToProjectGroup_console_message);
                                }

                            } // for the same projects
                        } else {
                            // just add it
                            theGroup.addMember(toAdd, relLoc, Messages.AddToProjectGroup_console_message);
                        }
                    }
                    refreshTree(con);

                }
            }
        } catch (DMException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        }
    }

    /**
     * @return <code>true</code> if action should be enabled for the current
     *         selection, returns <code>false</code> otherwise
     */
    @Override
    protected boolean isEnabledForSelection() {
        return isSameConnection();
    }

    protected void refreshTree(final DimensionsConnectionDetailsEx conn) throws DMException {
        ServicesView explorer = ServicesView.getCurrentView();
        if (explorer != null) {
            final TreeViewer treeViewer = explorer.getServiceTree();
            final DimensionsCategoryElement parent;
            parent = DimensionsCategoryElement.getCategory(conn, DimensionsProjectsCategory.class);
            if (parent instanceof DimensionsProjectsCategory) {
                ((DimensionsProjectsCategory) parent).setShowOnlyProjects(false);
                ((DimensionsProjectsCategory) parent).setShowOnlyStreams(false);
            }
            treeViewer.refresh(parent);

        }
    }

}

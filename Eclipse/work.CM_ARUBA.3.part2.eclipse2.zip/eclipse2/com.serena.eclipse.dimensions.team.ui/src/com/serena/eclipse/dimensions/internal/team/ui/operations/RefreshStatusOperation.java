/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * @author V.Grishchenko
 */
public class RefreshStatusOperation extends DMOperation {
    private IResource[] resources;

    public RefreshStatusOperation(IWorkbenchPart part, IResource[] resources) {
        super(part);
        this.resources = resources == null ? new IResource[0] : resources;
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
        IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
        // TODO VG on Nov 22, 2005: scheduling rules ?
        workspace.getSubscriber().refresh(resources, IResource.DEPTH_INFINITE, monitor);
    }

    @Override
    protected String getTaskName() {
        return Messages.RefreshStatusOperation_0;
    }

}

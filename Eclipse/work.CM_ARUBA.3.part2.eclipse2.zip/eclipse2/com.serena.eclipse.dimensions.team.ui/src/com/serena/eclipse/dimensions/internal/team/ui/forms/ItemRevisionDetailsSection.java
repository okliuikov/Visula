/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.forms;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorPage;
import com.serena.eclipse.dimensions.internal.ui.forms.FormEntry;
import com.serena.eclipse.dimensions.internal.ui.forms.ObjectDetailsSection;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsItemRevisionModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;

/**
 * @author A.Bollmann
 */
public class ItemRevisionDetailsSection extends ObjectDetailsSection {
    private FormEntry fileName;
    private FormEntry id;
    private FormEntry revision;
    private FormEntry format;
    private FormEntry itemType;
    private FormEntry creationDate;
    private FormEntry updateDate;
    private FormEntry revisedDate;
    private FormEntry lastUpdater;
    private FormEntry state;
    private FormEntry description;
    private FormEntry stage;
    private FormEntry isLocked;
    private FormEntry lockUser;
    private FormEntry lockedDate;

    public ItemRevisionDetailsSection(DimensionsObjectEditorPage page, IDimensionsArObjectModel model, Composite parent,
            String title, int style) {
        super(page, model, parent, style, title);
    }

    @Override
    protected void createClient(Section section, FormToolkit toolkit) {
        Composite panel = toolkit.createComposite(section);
        UIUtils.setGridLayout(panel, 2).verticalSpacing = 6;

        fileName = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_filename, SWT.SINGLE);
        fileName.getText().setEditable(false);

        id = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_id, SWT.SINGLE);
        id.getText().setEditable(false);

        revision = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_revision, SWT.SINGLE);
        revision.getText().setEditable(false);

        Label emptyLabel = new Label(panel, SWT.NONE);
        emptyLabel.setText(""); //$NON-NLS-1$
        GridData data = new GridData();
        data.horizontalSpan = 2;
        emptyLabel.setLayoutData(data);

        format = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_itemFormat, SWT.SINGLE);
        format.getText().setEditable(false);

        itemType = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_itemType, SWT.SINGLE);
        itemType.getText().setEditable(false);

        emptyLabel = new Label(panel, SWT.NONE);
        emptyLabel.setText(""); //$NON-NLS-1$
        data = new GridData();
        data.horizontalSpan = 2;
        emptyLabel.setLayoutData(data);

        creationDate = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_creationDate, SWT.SINGLE);
        creationDate.getText().setEditable(false);

        updateDate = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_updateDate, SWT.SINGLE);
        updateDate.getText().setEditable(false);

        revisedDate = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_revisedDate, SWT.SINGLE);
        revisedDate.getText().setEditable(false);

        lastUpdater = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_lastUpdater, SWT.SINGLE);
        lastUpdater.getText().setEditable(false);

        emptyLabel = new Label(panel, SWT.NONE);
        emptyLabel.setText(""); //$NON-NLS-1$
        data = new GridData();
        data.horizontalSpan = 2;
        emptyLabel.setLayoutData(data);

        description = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_desc, SWT.SINGLE);
        description.getText().setEditable(false);

        state = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_state, SWT.SINGLE);
        state.getText().setEditable(false);

        stage = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_stage, SWT.SINGLE);
        stage.getText().setEditable(false);

        isLocked = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_locked, SWT.SINGLE);
        isLocked.getText().setEditable(false);

        lockUser = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_lockedBy, SWT.SINGLE);
        lockUser.getText().setEditable(false);

        lockedDate = new FormEntry(panel, toolkit, Messages.itemDetailsPnl_lockedDate, SWT.SINGLE);
        lockedDate.getText().setEditable(false);

        toolkit.paintBordersFor(panel);
        section.setClient(panel);
    }

    @Override
    public void refresh() {
        DimensionsItemRevisionModel model = (DimensionsItemRevisionModel) getModel();
        id.setValue(model.getObjectId(), true);
        revision.setValue(model.getRevision(), true);
        state.setValue(model.getStatus(), true);
        description.setValue(model.getDescription(), true);
        creationDate.setValue(model.getCreationDate(), true);
        updateDate.setValue(model.getLastUpdatedDate(), true);
        fileName.setValue(model.getFileName(), true);
        format.setValue(model.getFormat(), true);
        itemType.setValue(model.getTypeName(), true);
        lastUpdater.setValue(model.getLastUpdatedBy(), true);
        revisedDate.setValue(model.getUTCModifiedDate(), true);
        stage.setValue(model.getStage(), true);
        isLocked.setValue(getBooleanText(model.isLocked()), true);
        lockUser.setValue(model.getLockUser(), true);
        lockedDate.setValue(model.getLockedDatetime(), true);

        super.refresh();
    }

    private String getBooleanText(boolean b) {
        if (b) {
            return Messages.itemDetailsPnl_true;
        }
        return Messages.itemDetailsPnl_false;
    }
}

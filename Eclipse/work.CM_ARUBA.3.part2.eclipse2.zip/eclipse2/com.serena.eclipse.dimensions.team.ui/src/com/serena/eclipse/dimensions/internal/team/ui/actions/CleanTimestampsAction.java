/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;

/**
 * Resets modtime of "touched" resources so they don't considered to be locally modified.
 * @author V.Grishchenko
 */
public class CleanTimestampsAction extends DMWorkspaceAction {
    private static final IDMWorkspaceResourceFilter MY_FILTER = new StatusFilter(WorkspaceResourceStatus.MODIFIED, StatusFilter.AND);

    public CleanTimestampsAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        final IResource[] resources = getSelectedResources();
        if (resources == null || resources.length == 0) {
            return;
        }
        WorkspaceModifyOperation operation = new WorkspaceModifyOperation() {
            @Override
            protected void execute(IProgressMonitor monitor) throws CoreException, InvocationTargetException, InterruptedException {
                DMTeamPlugin.getWorkspace().cleanTimestamps(getNonOverlapping(resources), IResource.DEPTH_INFINITE, monitor);
            }
        };
        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(operation);
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return MY_FILTER;
    }

    @Override
    protected boolean isEnabledOffline() {
        return true;
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

    @Override
    protected boolean isEnabledForMultipleConnections() {
        return true;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.UploadHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.UploadWizard;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class UploadOperation extends WizardOperation {

    public UploadOperation(IWorkbenchPart part, IResource[] resources) {
        super(part, resources, null);
    }

    public UploadOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    @Override
    public void execute(OperationData data, IProgressMonitor monitor) throws CoreException, InterruptedException {
        WorkspaceResourceRequest[] requests = data.getRequestsArray();

        if (requests == null || requests.length == 0) {
            return;
        }

        int totalWork = 1000 * (data.getRequests().size());
        monitor.beginTask(null, totalWork);

        try {
            if (data.getRequests().isEmpty()) {
                return;
            }

            final IStatus status = data.getProject().upload(data, Utils.subMonitorFor(monitor, 1000 * data.getRequests().size()));

            if (!status.isOK()) {
                final List<IStatus> coerr = new ArrayList<IStatus>();
                IStatus[] errors = status.isMultiStatus() ? status.getChildren() : new IStatus[] { status };
                for (int i = 0; i < errors.length; i++) {
                    if (errors[i].getCode() == DMTeamStatus.CHECKOUT_FAILED) {
                        coerr.add(errors[i]);
                    }
                }

                UIUtils.getDisplay().asyncExec(new Runnable() {

                    @Override
                    public void run() {
                        if (status.getSeverity() == IStatus.ERROR) {
                            ErrorDialog.openError(getShell(), Messages.UploadOperation_2, Messages.UploadOperation_3, status);
                        }

                        if (!coerr.isEmpty()) {
                            if (MessageDialog.openQuestion(getShell(), Messages.UploadOperation_4, Messages.UploadOperation_5)) {
                                List<IResource> resToCout = new ArrayList<IResource>(coerr.size());
                                for (Iterator<IStatus> iter = coerr.iterator(); iter.hasNext();) {
                                    IStatus errStat = iter.next();
                                    if (errStat instanceof DMTeamStatus) {
                                        resToCout.add(((DMTeamStatus) errStat).getResource());
                                    }
                                }

                                CheckoutOperation operation = new CheckoutOperation(getPart(),
                                        resToCout.toArray(new IResource[resToCout.size()]), null);
                                try {
                                    if (operation.prompt()) {
                                        operation.run();
                                    }
                                } catch (InvocationTargetException e) {
                                    DMTeamUiPlugin.getDefault().handle(e, getShell(), Messages.err_error,
                                            Messages.UploadOperation_6);
                                } catch (InterruptedException e) {
                                }
                            }
                        }

                    }
                });
            } else {
                if (getHelper() != null && getHelper().getPostCommandExecuteProvider() != null) {
                    getHelper().getPostCommandExecuteProvider().postExecute(monitor);
                }
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
        return new UploadHelper(getResources(), getFilter(), monitor);
    }

    @Override
    protected TeamOperationWizard createWizard(TeamOperationWizardHelper helper) {
        UploadHelper uploadHelper = (UploadHelper) helper;
        DMTeamUiPlugin.warnAboutCleanedCheckouts(uploadHelper.getCleanedCheckouts(), getShell());
        return new UploadWizard(uploadHelper);
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind(Messages.UploadOperation_0, provider.getProject().getName());
    }

    @Override
    protected String getTaskName() {
        return Messages.UploadOperation_1;
    }

}

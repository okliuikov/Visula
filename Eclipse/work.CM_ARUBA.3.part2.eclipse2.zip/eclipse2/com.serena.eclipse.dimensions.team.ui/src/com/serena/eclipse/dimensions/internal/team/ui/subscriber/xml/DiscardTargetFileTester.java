/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import org.eclipse.compare.structuremergeviewer.DiffNode;
import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.SyncInfoCompareInput;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;

import com.serena.eclipse.dimensions.internal.team.core.xml.MergeTempStorage;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;

/**
 * Test do we need to enable context menu action that discards all changes in temporary file that
 * was used for merge results
 */
public class DiscardTargetFileTester extends PropertyTester {

    private final static String TEMPTARGET_PROP = "isTempTarget";//$NON-NLS-1$

    public DiscardTargetFileTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (receiver instanceof IEditorPart && property.equals(TEMPTARGET_PROP)) {
            IEditorPart part = (IEditorPart) receiver;
            IEditorInput editorInput = part.getEditorInput();

            if (editorInput instanceof SyncInfoCompareInput) {
                SyncInfoCompareInput sinput = (SyncInfoCompareInput) editorInput;
                SyncInfo syncInfo = sinput.getSyncInfo();
                if (syncInfo instanceof XMLSyncInfo) {
                    XMLSyncInfo xinfo = (XMLSyncInfo) syncInfo;
                    if (xinfo.getTempStore() != null) {
                        Object compareResult = sinput.getCompareResult();
                        if (compareResult instanceof DiffNode && ((DiffNode) compareResult).getLeft() instanceof MergeTempStorage) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

}

package com.serena.eclipse.dimensions.internal.team.ui.commands;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.handlers.HandlerUtil;

import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.views.DimensionsItemHistoryView;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotateRevision;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class SelectRevisionInHistoryCommandHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        StructuredSelection ssel = UIUtils.getStructuredSelectionFromRuler(HandlerUtil.getActiveEditor(event));
        Object selObj = null;
        if (ssel != null && ssel.size() > 0 && ((selObj = ssel.getFirstElement()) instanceof BlameAnnotateRevision)) {
            final BlameAnnotateRevision blameRevision = (BlameAnnotateRevision) selObj;
            IFile local = blameRevision.getLocal();

            String id = blameRevision.getId();
            final IDMRemoteFile baseResource = blameRevision.getBase();
            final String targetSpec = baseResource.getItemSpec().split(";")[0] + ";" + id;//$NON-NLS-1$//$NON-NLS-2$

            DimensionsConnectionDetailsEx conn = blameRevision.getConnection();

            ItemRevision itemRevision = null;
            IDMRemoteFile[] rmFiles = null;
            try {
                itemRevision = TeamUtils.getItemRevisionBySpec(baseResource.getItemRevision().getProject(), conn, targetSpec);
                rmFiles = TeamUtils.getVariants(conn, new ItemRevision[] { itemRevision }, null);
            } catch (DMException e) {
                DMTeamUiPlugin.getDefault().handle(e);
            }

            DimensionsItemHistoryView histView = null;
            try {
                histView = (DimensionsItemHistoryView) UIUtils.getActivePage().showView(DimensionsItemHistoryView.VIEW_ID);
            } catch (PartInitException pe) {
                DMTeamUiPlugin.getDefault().handle(pe);
            }
            if (histView != null) {
                histView.showHistory(rmFiles[0], local, id, conn);
            }
        }
        return null;
    }

}

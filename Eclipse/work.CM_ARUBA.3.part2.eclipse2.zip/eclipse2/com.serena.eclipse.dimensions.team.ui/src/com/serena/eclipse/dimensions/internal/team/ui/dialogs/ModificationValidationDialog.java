/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class ModificationValidationDialog extends Dialog {
    private static final String SECTION = "modificationValidationSettings"; //$NON-NLS-1$
    private static final String LAST_SELECTION = "lastSelection"; //$NON-NLS-1$
    private static final String OPTIMISTIC = "optimistic"; //$NON-NLS-1$
    private static final String CHECKOUT = "checkout"; //$NON-NLS-1$

    private String title;
    private String message;
    private IFile[] files;
    private boolean offerCheckout;

    private boolean checkout;
    private boolean makeOptimistic = true; // default to optimistic
    private boolean storePreference;

    private Button checkoutBtn;
    private Button optimisticBtn;
    private Button storePrefBtn;

    private IDialogSettings settings;

    /**
     * @param parentShell
     */
    public ModificationValidationDialog(Shell parentShell, String title, String message, IFile[] files, boolean offerCheckout) {
        super(parentShell);
        this.title = title;
        this.message = message;
        if (files == null) {
            files = new IFile[0];
        }
        this.files = files;
        this.offerCheckout = offerCheckout;
        this.settings = DMTeamUiPlugin.getDefault().getDialogSettings().getSection(SECTION);
        if (this.settings == null) {
            this.settings = DMTeamUiPlugin.getDefault().getDialogSettings().addNewSection(SECTION);
        }
        initialize();
    }

    public boolean checkoutFiles() {
        return checkout;
    }

    public boolean makeFilesOptimistic() {
        return makeOptimistic;
    }

    /**
     * @return <code>true</code> to store selected value in preference
     */
    public boolean storePreference() {
        return storePreference;
    }

    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        if (title != null) {
            newShell.setText(title);
        }
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite) super.createDialogArea(parent);
        if (message != null) {
            UIUtils.setGridData(UIUtils.createLabel(composite, message), GridData.FILL_HORIZONTAL);
        }
        List list = new List(composite, SWT.SINGLE | SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
        UIUtils.setGridData(list, GridData.FILL_BOTH);
        for (int i = 0; i < files.length; i++) {
            list.add(files[i].getFullPath().makeRelative().toString());
        }

        Listener listener = new Listener() {
            @Override
            public void handleEvent(Event event) {
                if (event.type != SWT.Selection) {
                    return;
                }
                if (checkoutBtn != null && event.widget == checkoutBtn) {
                    checkout = checkoutBtn.getSelection();
                }
                if (optimisticBtn != null && event.widget == optimisticBtn) {
                    makeOptimistic = optimisticBtn.getSelection();
                }
                if (storePrefBtn != null && event.widget == storePrefBtn) {
                    storePreference = storePrefBtn.getSelection();
                }
            }
        };

        if (offerCheckout) {
            optimisticBtn = createButton(composite, SWT.RADIO, Messages.ModificationValidationDialog_1);
            checkoutBtn = createButton(composite, SWT.RADIO, Messages.ModificationValidationDialog_0);
            optimisticBtn.setSelection(makeOptimistic);
            checkoutBtn.setSelection(checkout);

            optimisticBtn.addListener(SWT.Selection, listener);
            checkoutBtn.addListener(SWT.Selection, listener);
        } else {
            // just offer make writable
            optimisticBtn = createButton(composite, SWT.RADIO, Messages.ModificationValidationDialog_1);
            optimisticBtn.setSelection(makeOptimistic);
            optimisticBtn.addListener(SWT.Selection, listener);

        }
        storePrefBtn = createButton(composite, SWT.CHECK, Messages.ModificationValidationDialog_2);
        storePrefBtn.addListener(SWT.Selection, listener);

        return composite;
    }

    private Button createButton(Composite parent, int style, String text) {
        Button result = new Button(parent, style);
        result.setText(text);
        return result;
    }

    @Override
    protected void okPressed() {
        if (offerCheckout) {
            saveLastSelection();
        }
        super.okPressed();
    }

    private void saveLastSelection() {
        if (checkout) {
            settings.put(LAST_SELECTION, CHECKOUT);
        } else {
            settings.put(LAST_SELECTION, OPTIMISTIC);
        }
    }

    private void initialize() {
        String lastSelection = settings.get(LAST_SELECTION);
        if (!Utils.isNullEmpty(lastSelection)) {
            if (OPTIMISTIC.equals(lastSelection)) {
                makeOptimistic = true;
                checkout = false;
            } else {
                makeOptimistic = false;
                checkout = true;
            }
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.compare.CompareConfiguration;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;
import org.eclipse.team.ui.synchronize.SubscriberParticipant;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.ExpandMode;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Uses data from <code>ISynchronizeParticipantDescriptor</code> to
 * initialize this participant.
 *
 * @author V.Grishchenko
 */
public abstract class DMSynchronizeParticipant extends SubscriberParticipant {

    private static FastSyncInfoFilter TEAM_PRIVATE_FILTER = new FastSyncInfoFilter() {
        @Override
        public boolean select(SyncInfo info) {
            IResource resource = info.getLocal();
            if (resource != null && resource.isTeamPrivateMember()) {
                return false;
            }
            return true;
        }
    };

    public static void updateRemoteLabels(SyncInfo sync, CompareConfiguration config) {
        final IResourceVariant remote = sync.getRemote();
        if (remote instanceof IDMRemoteFile) {
            config.setRightLabel(NLS.bind(Messages.SyncInfoCompareInput_remoteLabelExists, ((IDMRemoteFile) remote).getRevision()));
        } else if (remote == null) {
            config.setRightLabel(Messages.SyncInfoCompareInput_remoteLabel);
        }

        final IResourceVariant base = sync.getBase();
        if (base instanceof IDMRemoteFile) {
            config.setAncestorLabel(NLS.bind(Messages.SyncInfoCompareInput_baseLabelExists, ((IDMRemoteFile) base).getRevision()));
        } else if (base == null) {
            config.setAncestorLabel(Messages.SyncInfoCompareInput_baseLabel);
        }

        IResource local = sync.getLocal();
        IDMRemoteFile localres = null;
        try {
            localres = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);

        } catch (TeamException e) {
        }
        String lrev = localres != null ? localres.getRevision() : ""; //$NON-NLS-1$
        if (local != null && base != null) {
            config.setLeftLabel(NLS.bind(Messages.SyncInfoCompareInput_localLabelExists, lrev));
        } else {
            config.setLeftLabel(Messages.SyncInfoCompareInput_localLabel);
        }
    }

    /**
     * No-arg constructor to be invoked on registry creation
     */
    public DMSynchronizeParticipant() {
    }

    public DMSynchronizeParticipant(ISynchronizeScope scope) {
        super(scope);
    }

    @Override
    protected void setSubscriber(Subscriber subscriber) {
        super.setSubscriber(subscriber);
        try {
            ISynchronizeParticipantDescriptor descriptor = getDescriptor();
            setInitializationData(descriptor);
        } catch (CoreException e) {
            DMTeamUiPlugin.log(e.getStatus());
        }
        if (getSecondaryId() == null) {
            setSecondaryId(Long.toString(System.currentTimeMillis()));
        }
        setSyncInfoFilter(TEAM_PRIVATE_FILTER);
    }

    /**
     * @return the descriptor for this participant
     */
    protected abstract ISynchronizeParticipantDescriptor getDescriptor();

    @Override
    public void prepareCompareInput(ISynchronizeModelElement element, CompareConfiguration config, IProgressMonitor monitor)
            throws TeamException {
        if (element instanceof IAdaptable) {
            SyncInfo syncInfo = (SyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
            if (syncInfo != null) {
                updateRemoteLabels(syncInfo, config);
                // WORKAROUND: use our cacheContents as no super.prepareCompareInput()
                // prior to 3.1 and SyncInfoModelElement is internal
                cacheContents(syncInfo, monitor);
            }
        }
    }

    /*
     * For 3.1+ ensure contents is cached inside a progress monitor.
     */
    private void cacheContents(SyncInfo syncInfo, IProgressMonitor monitor) throws TeamException {
        IResourceVariant base = syncInfo.getBase();
        IResourceVariant remote = syncInfo.getRemote();
        int work = Math.max((remote == null ? 0 : 50) + (base == null ? 0 : 50), 10);
        monitor.beginTask(null, work);
        try {
            // Do this to reduce conflicts when ancestor/remote contents was cached expanded
            // Cache them unexpanded
            if (syncInfo.getKind() == (SyncInfo.CHANGE | SyncInfo.CONFLICTING)) {
                if (base != null
                        && (((IDMRemoteFile) base).isFetchedExpanded() == null || ((IDMRemoteFile) base).isFetchedExpanded()
                                .booleanValue())) {
                    TeamUtils.fetchReplaceContents(base, new ExpandMode[] { ExpandMode.UNEXPANDED },
                            Utils.subMonitorFor(monitor, 50));
                }
                if (remote != null
                        && (((IDMRemoteFile) remote).isFetchedExpanded() == null || ((IDMRemoteFile) remote).isFetchedExpanded()
                                .booleanValue())) {
                    TeamUtils.fetchReplaceContents(remote, new ExpandMode[] { ExpandMode.UNEXPANDED },
                            Utils.subMonitorFor(monitor, 50));
                }
            } else {
                if (base != null) {
                    base.getStorage(Utils.subMonitorFor(monitor, 50));
                }
                if (remote != null) {
                    remote.getStorage(Utils.subMonitorFor(monitor, 50));
                }
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);
        DMParticipantLabelDecorator decorator = new DMParticipantLabelDecorator(configuration);
        configuration.addLabelDecorator(decorator);
    }

}

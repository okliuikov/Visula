/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.model;

import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsItemRevisionModel;
import com.serena.eclipse.dimensions.internal.ui.model.EditableAggregateModel;
import com.serena.eclipse.dimensions.internal.ui.model.HistoryModel;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.IBaseDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsLcObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IHistoryModel;
import com.serena.eclipse.dimensions.internal.ui.model.IPreviewModel;
import com.serena.eclipse.dimensions.internal.ui.model.IPrivilegesModel;
import com.serena.eclipse.dimensions.internal.ui.model.IRelatedObjectsModel;
import com.serena.eclipse.dimensions.internal.ui.model.IUsersAndRolesModel;
import com.serena.eclipse.dimensions.internal.ui.model.ItemRevisionAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.UsersAndRolesModel;

/**
 * @author A.Bollmann
 */
public class ItemRevisionModel extends EditableAggregateModel implements IDimensionsLcObjectModel {

    private IDimensionsArObjectModel sysAttrModel;
    private IAttributeModel userAttrModel;
    private IHistoryModel historyModel;
    private IUsersAndRolesModel delegateModel;
    private IUsersAndRolesModel userAndRolesModel;
    private IPrivilegesModel privilegesModel;
    private IRelatedObjectsModel relatedObjectsModel;

    public ItemRevisionModel(ItemRevisionAdapter object) {
        super(object);
        sysAttrModel = new DimensionsItemRevisionModel(object);
        userAttrModel = new ItemRevisionAttributeModel(object);
        historyModel = new HistoryModel(object);
        delegateModel = new UsersAndRolesModel(object);
        userAndRolesModel = new UsersAndRolesModel(object, false);
        privilegesModel = new ItemPrivilegesModel(object);
        relatedObjectsModel = new ItemRelatedObjectsModel(object);
        setMembers(new IBaseDimensionsArObjectModel[] { sysAttrModel, userAttrModel, historyModel, delegateModel,
                userAndRolesModel, privilegesModel, relatedObjectsModel, });
    }

    @Override
    public IDimensionsArObjectModel getSystemAttributeModel() {
        return sysAttrModel;
    }

    @Override
    public IAttributeModel getUserAttributeModel() {
        return userAttrModel;
    }

    @Override
    public IHistoryModel getHistoryModel() {
        return historyModel;
    }

    @Override
    public IUsersAndRolesModel getDelegateModel() {
        return delegateModel;
    }

    @Override
    public IUsersAndRolesModel getUsersAndRolesModel() {
        return userAndRolesModel;
    }

    public IPrivilegesModel getPrivilegesModel() {
        return privilegesModel;
    }

    @Override
    public IRelatedObjectsModel getRelatedObjectsModel() {
        return relatedObjectsModel;
    }

    @Override
    public IPreviewModel getPreviewModel() {
        throw new UnsupportedOperationException();
    }

}

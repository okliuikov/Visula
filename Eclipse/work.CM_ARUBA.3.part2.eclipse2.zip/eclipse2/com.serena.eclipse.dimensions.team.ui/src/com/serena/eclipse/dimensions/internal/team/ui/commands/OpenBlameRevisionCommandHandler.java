package com.serena.eclipse.dimensions.internal.team.ui.commands;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.HandlerUtil;

import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.operations.BlameAnnotateRemoteOperation;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotateRevision;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class OpenBlameRevisionCommandHandler extends AbstractHandler {

    public static final String ACTION_TYPE_ID = "com.serena.eclipse.dimensions.team.ui.blameruler.actionType";//$NON-NLS-1$
    public static final String BLAME_ACTION = "blameRevision";//$NON-NLS-1$
    public static final String BROWSE_ACTION = "browseRevision";//$NON-NLS-1$

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        StructuredSelection ssel = UIUtils.getStructuredSelectionFromRuler(HandlerUtil.getActiveEditor(event));
        Object selObj = null;
        if (ssel != null && ssel.size() > 0 && ((selObj = ssel.getFirstElement()) instanceof BlameAnnotateRevision)) {
            BlameAnnotateRevision blameRevision = (BlameAnnotateRevision) selObj;
            String id = blameRevision.getId();
            final IDMRemoteFile baseResource = blameRevision.getBase();
            final String targetSpec = baseResource.getItemSpec().split(";")[0] + ";" + id;//$NON-NLS-1$//$NON-NLS-2$
            try {
                IDMProject project = baseResource.getProject();

                ItemRevision itemRevision = null;
                DimensionsConnectionDetailsEx connection = null;
                if (project == null) { // try to get item revision in another way
                    connection = blameRevision.getConnection();
                    itemRevision = TeamUtils.getItemRevisionBySpec(baseResource.getItemRevision().getProject(), connection,
                            targetSpec);
                } else {
                    itemRevision = project.getItemRevisionProxy(targetSpec);
                    connection = project.getConnection();
                }

                String actionType = event.getParameter(ACTION_TYPE_ID);
                if (actionType.equals(BLAME_ACTION)) {
                    openBlame(connection, itemRevision);
                } else if (actionType.equals(BROWSE_ACTION)) {
                    browseRevision(itemRevision, connection);
                }
            } catch (DMException e) {
                DMTeamUiPlugin.getDefault().handle(e);
            } catch (CoreException e) {
                DMTeamUiPlugin.getDefault().handle(e);
            } catch (InvocationTargetException e) {
                DMTeamUiPlugin.getDefault().handle(e);
            } catch (InterruptedException e) {
                DMTeamUiPlugin.getDefault().handle(e);
            }
        }
        return null;
    }

    private void browseRevision(ItemRevision itemRevision, DimensionsConnectionDetailsEx connection) throws CoreException {
        IDimensionsObjectEditHandler itemHandler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.ITEM);
        ItemRevisionAdapter adapter = new ItemRevisionAdapter(itemRevision, connection);
        itemHandler.browse(adapter);
    }

    private void openBlame(final DimensionsConnectionDetailsEx connection, final ItemRevision itemRevision)
            throws InvocationTargetException, InterruptedException, CoreException {
        final IDMRemoteFile[] files = new IDMRemoteFile[1];
        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                monitor.beginTask(Messages.blameAnnot_prefetch, IProgressMonitor.UNKNOWN);
                try {
                    IDMRemoteFile[] remoteFiles = TeamUtils.getVariants(connection, new ItemRevision[] { itemRevision, },
                            Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
                    if (remoteFiles != null && remoteFiles.length == 1 && remoteFiles[0] != null) {
                        files[0] = remoteFiles[0];
                        files[0].getStorage(Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
                    }
                } catch (CoreException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                } finally {
                    monitor.done();
                }
            }
        });
        if (files[0] != null) {
            BlameAnnotateRemoteOperation op = new BlameAnnotateRemoteOperation(files[0], UIUtils.getActivePage(), connection);
            op.execute();
        } else {
            throw new DMException(new Status(IStatus.ERROR, DMTeamPlugin.ID, Messages.blameAnnot_error));
        }
    }

}

/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 * Contributors:
 * IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.serena.eclipse.dimensions.internal.team.ui.compare;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import org.eclipse.compare.CompareUI;
import org.eclipse.compare.ITypedElement;
import org.eclipse.compare.ResourceNode;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.swt.graphics.Image;

import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * RemoteResourceTypedElement
 */
public class LocalResourceTypedElement extends ResourceNode {

    private IFile local;
    byte[] newContent;

    /**
     * Creates a new content buffer for the given team node.
     */
    public LocalResourceTypedElement(IFile local) {
        super(local);
        Assert.isNotNull(local);
        this.local = local;
    }

    @Override
    public Image getImage() {
        return CompareUI.getImage(getType());
    }

    @Override
    public String getName() {
        return local.getName();
    }

    @Override
    public String getType() {
        String name = getName();
        if (name != null) {
            int index = name.lastIndexOf('.');
            if (index == -1) {
                return ""; //$NON-NLS-1$
            }
            if (index == (name.length() - 1)) {
                return ""; //$NON-NLS-1$
            }
            return name.substring(index + 1);
        }
        return ITypedElement.FOLDER_TYPE;
    }

    /**
     * Returns true if this object can be modified.
     * If it returns <code>false</code> the other methods must not be called.
     *
     * @return <code>true</code> if this object can be modified.
     */
    @Override
    public boolean isEditable() {
        return true;
    }

    /**
     * This is not the definitive API!
     * This method is called on a parent to
     * - add a child,
     * - remove a child,
     * - copy the contents of a child
     *
     * What to do is encoded in the two arguments as follows:
     * add: child == null other != null
     * remove: child != null other == null
     * copy: child != null other != null
     */
    @Override
    public ITypedElement replace(ITypedElement child, ITypedElement other) {
        return null;
    }

    public IFile getLocal() {
        return local;
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof ITypedElement) {
            String otherName = ((ITypedElement) other).getName();
            return getName().equals(otherName);
        }
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return getName().hashCode();
    }

    @Override
    public void setContent(byte[] contents) {
        if (contents == null) {
            contents = new byte[0];
        }
        final InputStream is = new ByteArrayInputStream(contents);
        IRunnableWithProgress runnable = new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    IFile file = local;
                    if (is != null) {
                        if (!file.exists()) {
                            file.create(is, false, monitor);
                        } else {
                            file.setContents(is, false, true, monitor);
                        }
                    } else {
                        file.delete(false, true, monitor);
                    }
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                }
            }
        };
        try {
            new ProgressMonitorDialog(DMTeamUiPlugin.getDefault().getWorkbench().getDisplay().getActiveShell()).run(false, false,
                    runnable);
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        } catch (InterruptedException e) {
            // Ignore
        }
        fireContentChanged();
    }

    @Override
    public Object[] getChildren() {
        // There are no children
        return null;
    }

}

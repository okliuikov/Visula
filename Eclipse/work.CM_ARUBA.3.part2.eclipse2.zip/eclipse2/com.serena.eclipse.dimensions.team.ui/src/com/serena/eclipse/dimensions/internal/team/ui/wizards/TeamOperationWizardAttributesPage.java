/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabFolder2Adapter;
import org.eclipse.swt.custom.CTabFolderEvent;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.CheckedTreeSelectionDialog;
import org.eclipse.ui.dialogs.ISelectionStatusValidator;
import org.eclipse.ui.forms.AbstractFormPart;
import org.eclipse.ui.forms.DetailsPart;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IDetailsPageProvider;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.MasterDetailsBlock;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledPageBook;

import com.serena.eclipse.dimensions.core.TypeReference;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.ItemRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.atts.SFAttributeValue;
import com.serena.eclipse.dimensions.internal.ui.forms.AttributePanel;
import com.serena.eclipse.dimensions.internal.ui.forms.FormWizardPage;
import com.serena.eclipse.dimensions.internal.ui.forms.IAttributePanelContainer;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.IEditable;
import com.serena.eclipse.dimensions.internal.ui.model.IModel;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Wizard page with a master/details metaphor where master is items sorted
 * by type and details is item attributes.
 *
 * 1. group items by (product, type, state), this will ensure
 * that their attributes and corresponding attribute rules are the same.
 * This is displayed as a hierarchical structure:
 * All items
 * - product1:type1[:state1]
 * item1
 * item2
 * - product2:type2[:state2]
 * item1
 * item2
 * each node will have an attribute model associated with it
 * cases:
 * 1. checkout - attribute model is based on the existing revision and should copy
 * the attribute values if process model is configured so (similar to doc priming)
 * 2. checkin
 * 2.1 pessimistic checkin - revision goes from $TO_BE_DEFINED to the
 * first normal state, attribute model created using the new revision
 * and the first normal state (as in actioning)
 * 2.2 optimistic checkin - ?
 * 3. add to sc, similar to checkout except there is no original revision,
 * attribute model is created with a details and type objects
 *
 * @author V.Grishchenko
 */

public class TeamOperationWizardAttributesPage extends FormWizardPage implements IDetailsPageProvider, IPropertyChangeListener {

    private static final String COL_TREE_WIDTH = "tree_width"; //$NON-NLS-1$

    private static final int COL_TREE = 0;
    private static final int COL_STATUS = 1;

    private ItemInfo[] files;
    private Map itemGroups = new HashMap(); // status ref -> {IFile}
    private ItemInfo invalidItem;

    private TreeViewer itemViewer;
    private AttributeMasterDetailsBlock masterDetailsBlock;
    private IAction copyAllAttrsAction; // copies all attrs from selected file
    private IAction copyAttrsAction; // copies selected attrs from the selected file

    private IDialogSettings settings;

    private class ContentProvider implements ITreeContentProvider {
        @Override
        public Object[] getChildren(Object parentElement) {
            if (parentElement == itemGroups) {
                return itemGroups.keySet().toArray();
            }
            if (parentElement instanceof TypeReference) {
                return ((List) itemGroups.get(parentElement)).toArray();
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public Object getParent(Object element) {
            if (element == itemGroups) {
                return null;
            }
            if (element instanceof TypeReference) {
                return itemGroups;
            }
            if (element instanceof ItemInfo) {
                return ((ItemInfo) element).getRequest().getTypeReference();
            }
            return null;
        }

        @Override
        public boolean hasChildren(Object element) {
            if (element == itemGroups) {
                return !itemGroups.isEmpty();
            }
            if (element instanceof TypeReference) {
                return true;
            }
            return false;
        }

        @Override
        public Object[] getElements(Object inputElement) {
            return getChildren(inputElement);
        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        }
    }

    private class ItemLabelProvider extends LabelProvider implements ITableLabelProvider {

        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            if (element instanceof ItemInfo) {
                switch (columnIndex) {
                case COL_STATUS:
                    if (!((ItemInfo) element).getAttributeModel().isValid()) {
                        return PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_OBJS_ERROR_TSK);
                    }
                }
            }
            return null;
        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            if (element instanceof TypeReference && columnIndex == COL_TREE) {
                TypeReference typeReference = (TypeReference) element;
                return typeReference.getProduct() + ':' + typeReference.getTypeName();
            }
            if (element instanceof ItemInfo) {
                ItemInfo itemInfo = (ItemInfo) element;
                switch (columnIndex) {
                case COL_TREE:
                    String prefix = Utils.EMPTY_STRING;
                    if (itemInfo.getAttributeModel().isDirty()) {
                        prefix = Messages.TeamOperationWizardAttributesPage_dirtyPrefix;
                    }
                    return prefix + itemInfo.getRequest().getFile().getFullPath().toString();
                }
            }
            return Utils.EMPTY_STRING;
        }

    }

    private class ItemSorter extends ViewerSorter {
        @Override
        public int compare(Viewer viewer, Object o1, Object o2) {
            int result = 0;
            if (o1 instanceof TypeReference && o2 instanceof TypeReference) {
                // sort order: product, type
                TypeReference info1 = (TypeReference) o1;
                TypeReference info2 = (TypeReference) o2;
                String p1 = info1.getProduct();
                String p2 = info2.getProduct();
                result = collator.compare(p1, p2);
                if (result == 0) {
                    String t1 = info1.getTypeName();
                    String t2 = info2.getTypeName();
                    result = collator.compare(t1, t2);
                }
            } else if (o1 instanceof ItemInfo && o2 instanceof ItemInfo) {
                // sort by workspace paths
                IPath p1 = ((ItemInfo) o1).getRequest().getFile().getFullPath();
                IPath p2 = ((ItemInfo) o2).getRequest().getFile().getFullPath();
                result = p1.toFile().compareTo(p2.toFile());
            } else {
                result = super.compare(viewer, o1, o2);
            }
            return result;
        }
    }

    private class AttributeMasterDetailsBlock extends MasterDetailsBlock {

        public AttributeMasterDetailsBlock() {
        }

        @Override
        protected void createMasterPart(IManagedForm managedForm, Composite parent) {
            new ItemSelectionSection(parent, managedForm.getToolkit(), ExpandableComposite.TITLE_BAR);
            sashForm.setOrientation(SWT.VERTICAL);
        }

        @Override
        protected void registerPages(DetailsPart detailsPart) {
            sashForm.setWeights(new int[] { 40, 50 });
            detailsPart.setPageLimit(10);
            detailsPart.registerPage(TypeReference.class, new EmptyDetailsPage());
            detailsPart.setPageProvider(TeamOperationWizardAttributesPage.this);
        }

        @Override
        protected void createToolBarActions(IManagedForm managedForm) {
        }

        void maximizeDetails() {
            // unsafe! find a details part's page book amongst sash's children,
            // may break in the future if DetailsPart implementation is
            // changed, in such case will have to create a custom MasterDetailsBlock
            // equivalent and create a DetailPart with a page book that we can
            // hold a reference to.
            Control[] sashChildren = sashForm.getChildren();
            for (int i = 0; i < sashChildren.length; i++) {
                if (sashChildren[i] instanceof ScrolledPageBook) {
                    sashForm.setMaximizedControl(sashChildren[i]);
                    sashChildren[i].setFocus(); // avoid item selection changes while maximized
                    break;
                }
            }
        }

        void restoreDetails() {
            sashForm.setMaximizedControl(null);
        }

        DetailsPart getDetailsPart() {
            return detailsPart;
        }
    }

    private class EmptyDetailsPage extends AbstractFormPart implements IDetailsPage {
        @Override
        public void createContents(Composite parent) {
            GridLayout layout = UIUtils.setGridLayout(parent, 1);
            layout.marginHeight = layout.marginWidth = 0;
            Label separator = getToolkit().createLabel(parent, null, SWT.HORIZONTAL | SWT.SEPARATOR);
            UIUtils.setGridData(separator, GridData.FILL_HORIZONTAL);
            getToolkit().createLabel(parent, Messages.TeamOperationWizardAttributesPage_0, SWT.CENTER);
        }

        @Override
        public void selectionChanged(IFormPart part, ISelection selection) {
        }
    }

    /*
     * wrapper around AttributePanel and puts it into ctabfolder
     * with maximize/minimize button and also updates wiz. page messages
     * with info messages coming from the attr. panel
     */
    private class AttributeDetailsPage implements IDetailsPage, IAttributePanelContainer {
        private AttributePanel attributePanel;
        private IAttributeModel attributeModel;
        private String errorMsg;
        private String infoMsg;

        AttributeDetailsPage(IAttributeModel model) {
            this.attributeModel = model;
        }

        String getErrorMessage() {
            return errorMsg;
        }

        String getInfoMessage() {
            return infoMsg;
        }

        boolean isShowing() {
            return masterDetailsBlock.getDetailsPart().getCurrentPage() == this;
        }

        @Override
        public void createContents(Composite parent) {
            FillLayout fillLayout = new FillLayout(SWT.VERTICAL);
            parent.setLayout(fillLayout);
            final CTabFolder tabFolder = new CTabFolder(parent, SWT.TOP | SWT.FLAT | SWT.MULTI | SWT.BORDER);
            tabFolder.setMaximizeVisible(true);
            tabFolder.setData(FormToolkit.KEY_DRAW_BORDER, FormToolkit.TREE_BORDER);
            CTabItem tabItem = new CTabItem(tabFolder, SWT.NONE);
            tabItem.setText(Messages.TeamOperationWizardAttributesPage_1);
            IManagedForm managedForm = getManagedForm();
            attributePanel = new AttributePanel(managedForm, attributeModel, tabFolder, SWT.NONE);
            attributePanel.setContainer(this, true);
            tabItem.setControl(attributePanel.getPanel());
            tabFolder.setSelection(tabItem);
            tabFolder.addCTabFolder2Listener(new CTabFolder2Adapter() {
                @Override
                public void maximize(CTabFolderEvent event) {
                    tabFolder.setMaximized(true);
                    masterDetailsBlock.maximizeDetails();
                    tabFolder.setBorderVisible(false);
                }

                @Override
                public void restore(CTabFolderEvent event) {
                    tabFolder.setMaximized(false);
                    masterDetailsBlock.restoreDetails();
                    tabFolder.setBorderVisible(true);
                }
            });
        }

        @Override
        public void commit(boolean onSave) {
            if (attributePanel != null) {
                attributePanel.commit(onSave);
            }
        }

        @Override
        public void dispose() {
            if (attributePanel != null) {
                attributePanel.dispose();
            }
        }

        @Override
        public void initialize(IManagedForm form) {
            if (attributePanel != null) {
                attributePanel.initialize(form);
            }
        }

        @Override
        public boolean isDirty() {
            if (attributePanel != null) {
                return attributePanel.isDirty();
            }
            return false;
        }

        @Override
        public boolean isStale() {
            if (attributePanel != null) {
                return attributePanel.isStale();
            }
            return false;
        }

        @Override
        public void refresh() {
            if (attributePanel != null) {
                attributePanel.refresh();
            }
        }

        @Override
        public void selectionChanged(IFormPart part, ISelection selection) {
            if (attributePanel != null) {
                attributePanel.selectionChanged(part, selection);
            }
        }

        @Override
        public boolean setFormInput(Object input) {
            if (attributePanel != null) {
                return attributePanel.setFormInput(input);
            }
            return false;
        }

        @Override
        public void setFocus() {
            if (attributePanel != null) {
                attributePanel.setFocus();
            }
        }

        @Override
        public void validStateChanged(boolean newValidState) {
        }

        @Override
        public void setMessage(String msg) {
            setInfoMessage(msg);
        }

        @Override
        public void setInfoMessage(String msg) {
            infoMsg = msg;
            if (isShowing()) {
                TeamOperationWizardAttributesPage.this.setMessage(msg, INFORMATION);
            }
        }

        @Override
        public void setWarningMessage(String msg) {
        }

        @Override
        public void setErrorMessage(String msg) {
            errorMsg = msg;
            if (isShowing()) {
                TeamOperationWizardAttributesPage.this.setErrorMessage(msg);
            }
        }

        @Override
        public void run(boolean fork, boolean cancelable, IRunnableWithProgress runnable) throws InvocationTargetException,
                InterruptedException {
            getContainer().run(fork, cancelable, runnable);
        }
    }

    private class ItemSelectionSection extends AbstractFormPart {
        public ItemSelectionSection(Composite parent, FormToolkit toolkit, int style) {
            initialize(TeamOperationWizardAttributesPage.this.getManagedForm());
            TeamOperationWizardAttributesPage.this.getManagedForm().addPart(this);

            // create tree widget and columns
            Tree tableTree = new Tree(parent, SWT.SINGLE | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
            tableTree.setHeaderVisible(true);
            tableTree.setLinesVisible(true);
            UIUtils.setGridData(tableTree, GridData.FILL_BOTH);

            TreeColumn itemCol = new TreeColumn(tableTree, SWT.NONE);
            itemCol.setResizable(true);
            itemCol.setText(Messages.TeamOperationWizardAttributesPage_2);
            itemCol.setWidth(WizardHelper.getColumnWidth(settings, COL_TREE_WIDTH, 45));
            itemCol.addControlListener(new TableColumnListener(COL_TREE_WIDTH, settings));

            TreeColumn statusCol = new TreeColumn(tableTree, SWT.CENTER);
            statusCol.setResizable(false);
            statusCol.setWidth(18);

            tableTree.setSize(tableTree.computeSize(350, SWT.DEFAULT));
            tableTree.setFocus();

            // register tree context menu
            MenuManager menuMgr = new MenuManager();
            menuMgr.setRemoveAllWhenShown(true);
            menuMgr.addMenuListener(new IMenuListener() {
                @Override
                public void menuAboutToShow(IMenuManager manager) {
                    fillContextMenu(manager);
                }
            });
            Menu menu = menuMgr.createContextMenu(tableTree);
            tableTree.setMenu(menu);

            // create viewer
            itemViewer = new TreeViewer(tableTree);
            itemViewer.setContentProvider(new ContentProvider());
            itemViewer.setLabelProvider(new ItemLabelProvider());
            itemViewer.setSorter(new ItemSorter());
            itemViewer.addSelectionChangedListener(new ISelectionChangedListener() {
                @Override
                public void selectionChanged(SelectionChangedEvent event) {
                    getManagedForm().fireSelectionChanged(ItemSelectionSection.this, event.getSelection());
                    handleTreeSelectionChanged(event.getSelection());
                }
            });
        }
    }

    private class CopyAttributeAction extends Action {
        private SFAttributeValue attribute;
        private ItemInfo fromItem;

        CopyAttributeAction(SFAttributeValue attribute, ItemInfo fromItem) {
            super(attribute.getAttributeDefinition().getUserPrompt());
            this.attribute = attribute;
            this.fromItem = fromItem;
        }

        @Override
        public void run() {
            copyAttributes(fromItem, new SFAttributeValue[] { attribute });
        }
    }

    private class CopyAttributesAction extends Action {
        CopyAttributesAction() {
            super(Messages.TeamOperationWizardAttributesPage_copySome);
        }

        @Override
        public void run() {
            ItemInfo fromItem = getSelectedItem();
            if (fromItem != null) {
                IAttributeModel fromModel = fromItem.getAttributeModel();
                SFAttributeValue[] fromValues = fromModel.getAllValues();
                Arrays.sort(fromValues, new UserPromptComparator());
                AttributeSelectionDialog dialog = new AttributeSelectionDialog(getShell(), fromValues);
                if (dialog.open() == Window.OK) {
                    Object[] result = dialog.getResult();
                    SFAttributeValue[] selectedAttrs = new SFAttributeValue[result.length];
                    System.arraycopy(result, 0, selectedAttrs, 0, result.length);
                    copyAttributes(fromItem, selectedAttrs);
                }
            }
        }
    }

    private class CopyAllAttributesAction extends Action {
        CopyAllAttributesAction() {
            super(Messages.TeamOperationWizardAttributesPage_copyAll);
        }

        @Override
        public void run() {
            ItemInfo fromItem = getSelectedItem();
            if (fromItem != null) {
                boolean confirmation = MessageDialog.openQuestion(getShell(),
                        Messages.TeamOperationWizardAttributesPage_confirmCopyAllTitle,
                        Messages.TeamOperationWizardAttributesPage_confirmCopyAllMsg);
                if (confirmation) {
                    copyAttributes(fromItem, fromItem.getAttributeModel().getAllValues());
                }
            }
        }
    }

    private class AttributeSelectionDialog extends CheckedTreeSelectionDialog implements ISelectionStatusValidator {
        public AttributeSelectionDialog(Shell parent, SFAttributeValue[] fromValues) {
            super(parent, new AttrListLabelProvider(), new AttrListContentProvider());
            setInput(fromValues);
            setTitle(Messages.TeamOperationWizardAttributesPage_copySomeTitle);
            setMessage(Messages.TeamOperationWizardAttributesPage_copySomeMsg);
            setValidator(this);
        }

        @Override
        public IStatus validate(Object[] selection) {
            if (selection == null || selection.length == 0) {
                return new Status(IStatus.ERROR, DMTeamUiPlugin.ID, 0, Messages.TeamOperationWizardAttributesPage_noneSelected,
                        null);
            }
            return new Status(IStatus.OK, DMTeamUiPlugin.ID, 0, Messages.TeamOperationWizardAttributesPage_okToCopy, null);
        }
    }

    private class AttrListContentProvider implements ITreeContentProvider {
        @Override
        public Object[] getChildren(Object parentElement) {
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public Object getParent(Object element) {
            return null;
        }

        @Override
        public boolean hasChildren(Object element) {
            return false;
        }

        @Override
        public Object[] getElements(Object inputElement) {
            if (inputElement instanceof SFAttributeValue[]) {
                return (SFAttributeValue[]) inputElement;
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public void dispose() {
            // do nothing
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
            // do nothing
        }

    }

    private class AttrListLabelProvider extends LabelProvider {
        @Override
        public String getText(Object element) {
            if (element instanceof SFAttributeValue) {
                return ((SFAttributeValue) element).getAttributeDefinition().getUserPrompt();
            }
            return Utils.EMPTY_STRING;
        }
    }

    // compares attribute user prompts
    private class UserPromptComparator implements Comparator {
        @Override
        public int compare(Object o1, Object o2) {
            String p1 = ((SFAttributeValue) o1).getAttributeDefinition().getUserPrompt();
            String p2 = ((SFAttributeValue) o2).getAttributeDefinition().getUserPrompt();
            if (p1 == null) {
                p1 = Utils.EMPTY_STRING;
            }
            if (p2 == null) {
                p2 = Utils.EMPTY_STRING;
            }
            return p1.compareTo(p2);
        }
    }

    public TeamOperationWizardAttributesPage(String id, String title, String description, ImageDescriptor titleImage) {
        super(id, title, titleImage);
        setDescription(description);
        settings = DMTeamUiPlugin.getDefault().getDialogSettings().getSection(this.getClass().getName());
        if (settings == null) {
            settings = DMTeamUiPlugin.getDefault().getDialogSettings().addNewSection(this.getClass().getName());
        }
    }

    ItemInfo[] getFiles() {
        if (files == null) {
            return new ItemInfo[0];
        }
        return files;
    }

    void setFiles(ItemInfo[] files) {
        if (this.files != null) {
            for (int i = 0; i < this.files.length; i++) {
                this.files[i].getAttributeModel().removePropertyChangeListener(this);
            }
        }
        this.files = files;
        for (int i = 0; i < this.files.length; i++) {
            this.files[i].getAttributeModel().addPropertyChangeListener(this);
        }
        itemGroups.clear();
        validate(null);
    }

    private void validate(ItemInfo invalid) {
        if (invalid == null) {
            invalidItem = null;
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    if (!files[i].getAttributeModel().isValid()) {
                        invalidItem = files[i];
                        break;
                    }
                }
            }
        } else {
            this.invalidItem = invalid;
        }
        updatePage();
    }

    private ItemInfo findItemInfo(IAttributeModel model) {
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                if (files[i].getAttributeModel() == model) {
                    return files[i];
                }
            }
        }
        return null;
    }

    private void updatePage() {
        String errMsg = null;
        if (invalidItem != null) {
            errMsg = NLS.bind(Messages.TeamOperationWizardAttributesPage_3, invalidItem.getRequest()
                    .getFile()
                    .getFullPath()
                    .toString(), invalidItem.getRequest().getProductName() + ":" + invalidItem.getRequest().getTypeName()); //$NON-NLS-1$
        }
        setPageComplete(errMsg == null);
        setErrorMessage(errMsg);
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible && itemGroups.isEmpty() && files != null && files.length > 0) {
            for (int i = 0; i < files.length; i++) {
                ItemRequest itemRequest = files[i].getRequest();
                TypeReference typeReference = itemRequest.getTypeReference();
                List itemGroup = (List) itemGroups.get(typeReference);
                if (itemGroup == null) {
                    itemGroup = new ArrayList();
                    itemGroups.put(typeReference, itemGroup);
                }
                itemGroup.add(files[i]);
            }
            itemViewer.setInput(itemGroups);
        }
        super.setVisible(visible);
    }

    @Override
    public Object getPageKey(Object object) {
        if (object instanceof ItemInfo) {
            return ((ItemInfo) object).getAttributeModel();
        }
        return null;
    }

    @Override
    public IDetailsPage getPage(Object key) {
        if (key instanceof IAttributeModel) {
            // return new AttributePanel(getManagedForm(), (IAttributeModel)key);
            return new AttributeDetailsPage((IAttributeModel) key);
        }
        return null;
    }

    @Override
    protected void createFormContents(Composite form) {
        form.setLayout(new FillLayout());
        masterDetailsBlock = new AttributeMasterDetailsBlock();
        masterDetailsBlock.createContent(getManagedForm());
        copyAllAttrsAction = new CopyAllAttributesAction();
        copyAttrsAction = new CopyAttributesAction();
    }

    @Override
    public void propertyChange(PropertyChangeEvent event) {
        if (IModel.VALID.equals(event.getProperty())) {
            IAttributeModel model = (IAttributeModel) event.getSource();
            ItemInfo itemInfo = findItemInfo(model);
            if (itemInfo != null) {
                itemViewer.refresh(itemInfo);
            }
            if (invalidItem != null && model == invalidItem.getAttributeModel()) {
                if (Boolean.TRUE.equals(event.getNewValue())) {
                    validate(null); // check for others with problems
                }
            } else {
                if (Boolean.FALSE.equals(event.getNewValue())) {
                    validate(itemInfo);
                } else {
                    // do nothing as there must be another bad model if we got here
                }
            }
        } else if (IEditable.DIRTY.equals(event.getProperty())) {
            IAttributeModel model = (IAttributeModel) event.getSource();
            ItemInfo itemInfo = findItemInfo(model);
            if (itemInfo != null) {
                itemViewer.update(itemInfo, null);
            }
        }
    }

    @Override
    public void formDirtyStateChanged() {
        if (masterDetailsBlock != null && masterDetailsBlock.getDetailsPart() != null) {
            // commit current page to the model we're notified right away
            // about model valid state changes, if any
            masterDetailsBlock.getDetailsPart().commit(false);
        }
    }

    private ItemInfo getSelectedItem() {
        if (itemViewer != null) {
            ISelection selection = itemViewer.getSelection();
            if (!selection.isEmpty() && selection instanceof IStructuredSelection) {
                Object o = ((IStructuredSelection) selection).getFirstElement();
                if (o instanceof ItemInfo) {
                    return (ItemInfo) o;
                }
            }
        }
        return null;
    }

    private void fillContextMenu(IMenuManager manager) {
        copyAttrsAction.setEnabled(false);
        copyAllAttrsAction.setEnabled(false);
        ItemInfo itemInfo = getSelectedItem();
        if (itemInfo != null) {
            List ofTheSameType = (List) itemGroups.get(itemInfo.getRequest().getTypeReference());
            if (ofTheSameType.size() > 1) {
                IAttributeModel attributeModel = itemInfo.getAttributeModel();
                SFAttributeValue[] values = attributeModel.getAllValues();
                if (values.length > 0) {
                    copyAttrsAction.setEnabled(true);
                    copyAllAttrsAction.setEnabled(true);
                    MenuManager copySubMenu = new MenuManager(Messages.TeamOperationWizardAttributesPage_copyOne);
                    Arrays.sort(values, new UserPromptComparator());
                    for (int i = 0; i < values.length; i++) {
                        copySubMenu.add(new CopyAttributeAction(values[i], itemInfo));
                    }
                    manager.add(copySubMenu);
                }
                manager.add(copyAttrsAction);
                manager.add(copyAllAttrsAction);
            }
        }
    }

    private void handleTreeSelectionChanged(ISelection selection) {
        boolean findInvalid = true;
        IDetailsPage detailsPage = masterDetailsBlock.getDetailsPart().getCurrentPage();
        if (detailsPage instanceof AttributeDetailsPage) {
            AttributeDetailsPage attributePage = (AttributeDetailsPage) detailsPage;
            if (!Utils.isNullEmpty(attributePage.getErrorMessage())) {
                setErrorMessage(attributePage.getErrorMessage());
                findInvalid = false; // current is invalid
            }
            if (!Utils.isNullEmpty(attributePage.getInfoMessage())) {
                setMessage(attributePage.getInfoMessage(), INFORMATION);
            }
        }
        if (findInvalid) {
            validate(null);
        }
    }

    private void copyAttributes(ItemInfo fromItem, SFAttributeValue[] fromValues) {
        List otherItems = (List) itemGroups.get(fromItem.getRequest().getTypeReference());
        for (Iterator iterator = otherItems.iterator(); iterator.hasNext();) {
            ItemInfo otherItem = (ItemInfo) iterator.next();
            if (otherItem == fromItem) {
                continue;
            }
            IAttributeModel toModel = otherItem.getAttributeModel();
            SFAttributeValue[] toValues = toModel.getAllValues();
            HashMap lookupMap = new HashMap(); // in theory value order should be the same but play safe
            for (int i = 0; i < toValues.length; i++) {
                lookupMap.put(toValues[i].getAttributeDefinition().getName(), toValues[i]);
            }
            for (int i = 0; i < fromValues.length; i++) {
                SFAttributeValue toValue = (SFAttributeValue) lookupMap.get(fromValues[i].getAttributeDefinition().getName());
                if (toValue != null) {
                    toValue.setValue(fromValues[i].getValue());
                    toValue.commit();
                }
            }
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspace;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMSyncModelFilters.CrossProjectFilter;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMSyncModelFilters.OverlappingCrossProjectFilter;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Stores sync info for projects
 */
class ProjectsSyncInfoMapping {
    private Map<IProject, SyncInfoSet> crossInfoSets;
    private Map<IProject, SyncInfoSet> infoSets;

    private Map<IProject, Set<IResource>> excludedCrossResources;
    private Map<IProject, Set<IResource>> excludedResources;

    private ProjectsSyncInfoMapping(Map<IProject, SyncInfoSet> crossInfoSets, Map<IProject, SyncInfoSet> infoSets) {
        this.crossInfoSets = crossInfoSets;
        this.infoSets = infoSets;
    }

    // @formatter:off
    private ProjectsSyncInfoMapping(
            Map<IProject, SyncInfoSet> crossInfoSets,
            Map<IProject, SyncInfoSet> infoSets,
            Map<IProject, Set<IResource>> excludedCrossResources,
            Map<IProject, Set<IResource>> excludedResources) {
        this(crossInfoSets, infoSets);
        this.excludedCrossResources = excludedCrossResources;
        this.excludedResources = excludedResources;
    }
    // @formatter:on

    int getTotalProjectsLength() {
        int result = 0;
        if (getCrossInfoSets() != null) {
            result += getCrossInfoSets().size();
        }
        if (getInfoSets() != null) {
            result += getInfoSets().size();
        }
        return result;
    }

    /**
     * @return projects sync sets for cross project moves
     */
    Map<IProject, SyncInfoSet> getCrossInfoSets() {
        return crossInfoSets;
    }

    /**
     * @return projects sync sets
     */
    Map<IProject, SyncInfoSet> getInfoSets() {
        return infoSets;
    }

    /**
     * @param project to get info for
     * @return set of excluded cross project moves from delivery
     */
    Set<IResource> getExcludedCrossResources(IProject project) {
        Set<IResource> set = excludedCrossResources.get(project);
        if (set == null) {
            set = new HashSet<IResource>();
        }
        return set;
    }

    /**
     * @param project to get info for
     * @return set of excluded resources from delivery
     */
    Set<IResource> getExcludedResources(IProject project) {
        Set<IResource> set = excludedResources.get(project);
        if (set == null) {
            set = new HashSet<IResource>();
        }
        return set;
    }

    /**
     * Divide selected sync info by project, find cross project moves, find excluded changes for deliver case
     */
    static ProjectsSyncInfoMapping createSyncMapping(SyncInfoSet allSelected, SyncInfoSet allOutgoing, boolean isStreamOperation) {
        // Filter all infos that represents outgoing additions and incoming additions/deletions of cross project moves
        CrossProjectFilter rejectCrossMovesFilter = new CrossProjectFilter();
        allSelected.rejectNodes(rejectCrossMovesFilter);

        Map<IProject, SyncInfoSet> crossInfoSets = new HashMap<IProject, SyncInfoSet>();
        SyncInfoSet crossSyncInfoSet = null;
        if (!rejectCrossMovesFilter.isEmpty()) {
            // Filter addition of folders that covers cross project moves
            OverlappingCrossProjectFilter rejectOverlappingFilter = new OverlappingCrossProjectFilter(rejectCrossMovesFilter);
            allSelected.rejectNodes(rejectOverlappingFilter);

            // Fill map of cross project changes per project
            crossSyncInfoSet = rejectOverlappingFilter.getFilterResult().getCrossProjectInfos();
            crossInfoSets = fillProjectInfoMap(crossSyncInfoSet);
        }

        // Fill map of default changes per project
        Map<IProject, SyncInfoSet> infoSets = fillProjectInfoMap(allSelected);
        if (!isStreamOperation) {
            return new ProjectsSyncInfoMapping(crossInfoSets, infoSets);
        }

        Set<IResource> includedSet = createIncludedSet(allSelected.getResources(), allOutgoing);
        includedSet.addAll(findMovePairs(includedSet));
        Set<IResource> excludedSet = new HashSet<IResource>(Arrays.asList(allOutgoing.getResources()));

        Set<IResource> includedCrossSet = new HashSet<IResource>();
        Set<IResource> excludedCrossSet = new HashSet<IResource>();
        if (crossSyncInfoSet != null && !crossInfoSets.isEmpty()) {
            includedCrossSet.addAll(createIncludedSet(crossSyncInfoSet.getResources(), allOutgoing));
            includedCrossSet.addAll(findMovePairs(includedCrossSet));
            excludedCrossSet.addAll(Arrays.asList(allOutgoing.getResources()));
        }

        // create set of excluded resources for cross project move operation
        excludedCrossSet.removeAll(includedCrossSet);

        // create set of excluded resources for normal deliver operation
        excludedSet.removeAll(includedSet);
        excludedSet.removeAll(includedCrossSet);

        // Fill map of excluded changes per project
        Map<IProject, Set<IResource>> excludedResources = fillProjectResourceMap(excludedSet);

        // Fill map of excluded cross project changes per project
        Map<IProject, Set<IResource>> excludedCrossResources = fillProjectResourceMap(excludedCrossSet);

        return new ProjectsSyncInfoMapping(crossInfoSets, infoSets, excludedCrossResources, excludedResources);
    }

    /**
     * Divide selected sync info by project and find excluded changes for deliver case. Cross project moves will be packed along
     * with default changes
     */
    static ProjectsSyncInfoMapping createUnitedStreamSyncMapping(SyncInfoSet allSelected, SyncInfoSet allOutgoing) {
        // fill map of changes per project
        Map<IProject, SyncInfoSet> infoSets = fillProjectInfoMap(allSelected);
        Set<IResource> includedSet = createIncludedSet(allSelected.getResources(), allOutgoing);
        includedSet.addAll(findMovePairs(includedSet));

        // create set of excluded resources
        Set<IResource> excludedSet = new HashSet<IResource>(Arrays.asList(allOutgoing.getResources()));
        excludedSet.removeAll(includedSet);

        // Fill map of excluded changes per project
        Map<IProject, Set<IResource>> excludedResources = fillProjectResourceMap(excludedSet);

        return new ProjectsSyncInfoMapping(Collections.<IProject, SyncInfoSet>emptyMap(), infoSets,
                Collections.<IProject, Set<IResource>>emptyMap(), excludedResources);
    }

    /**
     * @return all corresponding sources for includedResources if exists
     */
    private static Set<IResource> findMovePairs(Set<IResource> includedResources) {
        Set<IResource> result = new HashSet<IResource>();
        DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
        for (IResource resource : includedResources) {
            try {
                IResource movedFrom = workspace.getMovedFrom(resource);
                if (movedFrom != null) {
                    result.add(movedFrom);
                }
            } catch (CoreException e) {
                DMTeamUiPlugin.log(e.getStatus());
            }
        }
        return result;
    }

    /**
     * @return set of resources and theirs parent resources that have corresponding sync info
     */
    private static Set<IResource> createIncludedSet(IResource[] targets, SyncInfoSet allOutgoing) {
        Set<IResource> result = new HashSet<IResource>();
        Set<IFolder> parents = new HashSet<IFolder>();

        for (int i = 0; i < targets.length; i++) {
            // add all targets as is
            result.add(targets[i]);

            IContainer parent = targets[i].getParent();
            // find all parents
            if (parent instanceof IFolder && !parents.contains(parent)) {
                parents.add((IFolder) parent);

                while (parent.getParent() instanceof IFolder) {
                    parent = parent.getParent();
                    parents.add((IFolder) parent);
                }
            }
        }

        // check if parent has sync info and add it to target set
        for (IFolder parent : parents) {
            if (allOutgoing.getSyncInfo(parent) != null) {
                result.add(parent);
            }
        }
        return result;
    }

    private static Map<IProject, Set<IResource>> fillProjectResourceMap(Set<IResource> resourceSet) {
        Map<IProject, Set<IResource>> result = new HashMap<IProject, Set<IResource>>();
        for (IResource resource : resourceSet) {
            IProject project = resource.getProject();
            Set<IResource> set = result.get(project);
            if (set == null) {
                set = new HashSet<IResource>();
                result.put(project, set);
            }
            set.add(resource);
        }
        return result;
    }

    private static Map<IProject, SyncInfoSet> fillProjectInfoMap(SyncInfoSet infoSet) {
        Map<IProject, SyncInfoSet> result = new HashMap<IProject, SyncInfoSet>();
        SyncInfo[] crossInfos = infoSet.getSyncInfos();
        for (int i = 0; i < crossInfos.length; i++) {
            SyncInfo info = crossInfos[i];
            IProject project = info.getLocal().getProject();
            SyncInfoSet set = result.get(project);
            if (set == null) {
                set = new SyncInfoSet();
                result.put(project, set);
            }
            set.add(info);
        }
        return result;
    }

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.Iterator;
import java.util.List;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.StreamInitialData;
import com.serena.dmclient.collections.Types;
import com.serena.dmclient.collections.VersionBranches;
import com.serena.dmclient.objects.Product;
import com.serena.dmclient.objects.Type;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewObjectWizard;

public class NewStreamGeneralPage extends DimensionsWizardPage {
    
    private boolean isStream = true;
    private Label lblBasedOn;
    private Combo cmbProduct;
    private Combo cmbProjectType;
    private Text txtStreamName;
    private Text txtStreamDescr;
    private Text txtPrjGrpName;
    private Text txtStreamBranch;

    private Button btnAdd2favoriteList;
    private boolean isAdd2FavoriteList;

    private List<Type> typeList;
    private String typeListProduct;
    private List<Project> projectList;
    private String[] versionBranches;

    // are all controls enabled on the page
    private boolean areControlsEnabled = true;
    private String staticErrorMessage;
    private boolean projectGroupCreationMode = false;

    private IProject project;
    StreamInitialData shelfInitials;
    Project shelfParent;
    private Button btnIsReset;
    private boolean isResetAfterShelve;

    private AdvancedWorkAreaSettings advancedSettings = new AdvancedWorkAreaSettings(false);

    public NewStreamGeneralPage(String pageName, String title, String description, ImageDescriptor titleImage, boolean isStream,
            boolean projectGroupCreationMode) {
        super(pageName, title, titleImage);
        setDescription(description);
        this.isStream = isStream;
        this.projectGroupCreationMode = projectGroupCreationMode;
        this.isAdd2FavoriteList = false;
        setPageComplete(false);
    }

    public NewStreamGeneralPage(String pageName, String title, String description, ImageDescriptor titleImage,
            StreamInitialData shelfInitials, Project shelfParent) {
        super(pageName, title, titleImage);
        setDescription(description);
        this.isStream = true;
        this.projectGroupCreationMode = false;
        this.isAdd2FavoriteList = false;
        this.shelfInitials = shelfInitials;
        this.shelfParent = shelfParent;
        setPageComplete(false);
    }

    public NewStreamGeneralPage(String pageName, String title, String description, ImageDescriptor titleImage, boolean isStream,
            boolean showAdvancedSettings, IProject project) { // used on sharing
        super(pageName, title, titleImage);
        advancedSettings.setAllowed(showAdvancedSettings);
        setDescription(description);
        this.isStream = isStream;
        this.project = project;
        this.isAdd2FavoriteList = false;
        setPageComplete(false);
    }
    
    DimensionsConnectionDetailsEx getConnection() {
        if (getWizard() instanceof NewStreamWizard) {
            return ((NewObjectWizard) getWizard()).getConnection();
        } else if (getWizard() instanceof TeamOperationWizard) {
            return ((TeamOperationWizard) getWizard()).getConnection();
        }
        return null;
    }

    private String getPreselectedProduct() {
        if (getWizard() instanceof NewStreamWizard) {
            NewStreamWizard wizard = (NewStreamWizard) getWizard();
            if (null != wizard.getBasedOnStream()) {
                return wizard.getBasedOnStream().substring(0, wizard.getBasedOnStream().indexOf(":")); //$NON-NLS-1$
            } else if (null != wizard.getBasedOnBaseLine()) {
                return wizard.getBasedOnBaseLine().substring(0, wizard.getBasedOnBaseLine().indexOf(":")); //$NON-NLS-1$
            }
        } else if (isShelve()) {
            if (shelfParent != null) {
                return shelfParent.getName().split(":")[0]; //$NON-NLS-1$
            }

        }
        return ""; //$NON-NLS-1$
    }

    private String getPreselectedStreamName() {
        if (shelfInitials != null) {
            return shelfInitials.getStreamId();
        }
        return ""; //$NON-NLS-1$
    }

    private boolean isShelve() {
        return shelfInitials != null && isStream;
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        Composite cmpStream = composite;
        UIUtils.setGridData(cmpStream, GridData.FILL_HORIZONTAL);

        lblBasedOn = new Label(cmpStream, SWT.NONE);
        UIUtils.setGridData(lblBasedOn, GridData.FILL_HORIZONTAL);
        lblBasedOn.setText(isStream
                ? Messages.NewStreamWizard_stream_general_lblProject_1 : Messages.NewStreamWizard_project_general_lblProject_1);

        String prod = getPreselectedProduct();

        cmbProduct = new Combo(cmpStream, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
        UIUtils.setGridData(cmbProduct, GridData.FILL_HORIZONTAL);
        try {
            for (String productName : Utils.getProductNames(getConnection())) {
                cmbProduct.add(productName);
            }
            if (!StringPath.isNullorEmpty(prod)) {
                cmbProduct.setText(prod);
            }

            if (cmbProduct.getText().equals(Utils.EMPTY_STRING) && 0 < cmbProduct.getItemCount()) {
                cmbProduct.select(0);
            }
        } catch (Exception e) {
            setErrorMessage(e.getMessage());
        }

        cmbProduct.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                getTypesFromDM();
                if (advancedSettings.getAllowed()) {
                    advancedSettings.fillPartCombo();
                }
                checkPage();
                loadOptionFromType();
            }
        });

        UIUtils.createLabel(cmpStream, (isStream
                ? Messages.NewStreamWizard_stream_general_lblProjectName : Messages.NewStreamWizard_project_general_lblProjectName));
        txtStreamName = new Text(cmpStream, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(txtStreamName, GridData.FILL_HORIZONTAL);
        String offset = getOffset();
        if (!Utils.isNullEmpty(offset)) {
            txtStreamName.setText(offset.toUpperCase());
        } else {
            String streamName = getPreselectedStreamName();
            if (!StringPath.isNullorEmpty(streamName)) {
                txtStreamName.setText(streamName);
            }
        }
        txtStreamName.addVerifyListener(new VerifyListener() {
            @Override
            public void verifyText(VerifyEvent e) {
                e.text = e.text.toUpperCase();
            }
        });
        txtStreamName.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                checkPage();
            }
        });

        if (!isStream) {
            UIUtils.createLabel(cmpStream, Messages.NewStreamWizard_stream_general_lblType);
            cmbProjectType = new Combo(cmpStream, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
            UIUtils.setGridData(cmbProjectType, GridData.FILL_HORIZONTAL);
            cmbProjectType.addSelectionListener(new SelectionAdapter() {
                @Override
                public void widgetSelected(SelectionEvent e) {
                    loadOptionFromType();
                }
            });
        }

        UIUtils.createLabel(cmpStream, (isStream
                ? Messages.NewStreamWizard_stream_general_lblDescription : Messages.NewStreamWizard_project_general_lblDescription));
        txtStreamDescr = new Text(cmpStream, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(txtStreamDescr, GridData.FILL_HORIZONTAL);

        if (isShelve()) {
            txtStreamDescr.setText(shelfInitials.getDescription());
        }

        txtStreamDescr.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                checkPage();
            }
        });

        if (projectGroupCreationMode) {
            UIUtils.createLabel(cmpStream, Messages.NewStreamWizard_project_general_lblPrjGroupName);
            txtPrjGrpName = new Text(cmpStream, SWT.SINGLE | SWT.BORDER);
            UIUtils.setGridData(txtPrjGrpName, GridData.FILL_HORIZONTAL);
            txtPrjGrpName.addModifyListener(new ModifyListener() {
                @Override
                public void modifyText(ModifyEvent e) {
                    checkPage();
                }
            });
        }

        if (isStream) {
            Composite cmpBranch = new Composite(cmpStream, SWT.NONE);

            GridLayout layout = UIUtils.setGridLayout(cmpBranch, 2);
            layout.marginHeight = 0;
            layout.marginWidth = 0;

            UIUtils.createLabel(cmpBranch, Messages.NewStreamWizard_stream_general_lblBranchName);
            UIUtils.createLabel(cmpBranch, Utils.EMPTY_STRING);

            txtStreamBranch = new Text(cmpBranch, SWT.SINGLE | SWT.BORDER);
            UIUtils.setGridData(txtStreamBranch, GridData.FILL_HORIZONTAL);
            txtStreamBranch.addVerifyListener(new VerifyListener() {
                @Override
                public void verifyText(VerifyEvent e) {
                    e.text = e.text.toLowerCase();
                }
            });
            txtStreamBranch.addModifyListener(new ModifyListener() {
                @Override
                public void modifyText(ModifyEvent e) {
                    checkPage();
                }
            });

            if (isShelve()) {
                txtStreamBranch.setText(shelfInitials.getBranchId());
            }

            UIUtils.createLabel(cmpBranch, Messages.NewStreamWizard_stream_general_lblBranchExample);

            GridData gr = UIUtils.setGridData(composite, GridData.FILL_HORIZONTAL);
            gr.verticalIndent = 2;

            if (isShelve()) {
                this.isResetAfterShelve = true;
                btnIsReset = new Button(cmpStream, SWT.CHECK);

                btnIsReset.setText(Messages.NewStreamWizard_stream_general_chkResetWorkarea);

                btnIsReset.addSelectionListener(new SelectionAdapter() {
                    @Override
                    public void widgetSelected(SelectionEvent e) {
                        Button button = (Button) e.getSource();
                        if (button.getSelection()) {
                            isResetAfterShelve = true;
                        } else {
                            isResetAfterShelve = false;
                        }
                    }
                });

                btnIsReset.setSelection(true);

                btnIsReset.setLayoutData(gr);
            }
        }

        btnAdd2favoriteList = new Button(cmpStream, SWT.CHECK);

        btnAdd2favoriteList.setText(isStream
                ? Messages.NewStreamWizard_stream_general_chkAddStream2favoritesList
                : Messages.NewStreamWizard_project_general_chkAddProject2favoritesList);

        btnAdd2favoriteList.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                Button button = (Button) e.getSource();
                if (button.getSelection()) {
                    isAdd2FavoriteList = true;
                } else {
                    isAdd2FavoriteList = false;
                }
            }
        });
        
        if (advancedSettings.getAllowed()) {
            advancedSettings.init(this, composite, project);
            advancedSettings.addChangeListener(new ChangeListener() {

                @Override
                public void stateChanged(ChangeEvent e) {
                    checkPage();
                }
            });
        }
        setControl(composite);
        getTypesFromDM();
        checkPage();
    }
    
    @Override
    public void setVisible (boolean visible) {
        if (visible && advancedSettings.getAllowed()) {
            advancedSettings.update();
        }
        super.setVisible(visible);
    }

    @Override
    public boolean canFlipToNextPage() {
        return areControlsEnabled ? super.canFlipToNextPage() : false;
    }

    public void setSuchProjectTypeAllowed(boolean allowed) {
        if (areControlsEnabled = allowed) {
            staticErrorMessage = null;
        } else {
            staticErrorMessage = (isStream
                    ? Messages.NewStreamWizard_dbOptError_streamDisallowed : Messages.NewStreamWizard_dbOptError_projectDisallowed);
        }
    }

    public String getProductName() {
        return UIUtils.safeGetCombo(cmbProduct);
    }

    public boolean isAdd2FavoriteList() {
        return isAdd2FavoriteList;
    }

    public String getStreamName() {
        return safeGetText(txtStreamName);
    }

    public String getProjectGroupName() {
        return safeGetText(txtPrjGrpName);
    }

    public String getStreamDescription() {
        return safeGetText(txtStreamDescr);
    }

    public String getStreamUniqueBranchName() {
        if (!isStream) {
            return null;
        }
        return safeGetText(txtStreamBranch);
    }

    public String getTypeName() {
        if (null == txtStreamName) {
            return null;
        }

        if (isStream) {
            return IDMConstants.STREAM_TYPE_NAME;
        }

        return UIUtils.safeGetCombo(cmbProjectType);
    }

    public String getOffset() {
        if (advancedSettings.getAllowed()) {
            return advancedSettings.getOffset();
        } else if (project != null) {
            return project.getName();
        }
        return "";
    }

    public String getPart() {
        if (advancedSettings.getAllowed()) {
            return advancedSettings.getPart(); 
        }
        return null;
    }

    public String getWorkArea() {
        if (advancedSettings.getAllowed()) {
            return advancedSettings.getWorkArea(); 
        }
        return "";
    }

    public Type getType() {
        for (int i = 0; i < typeList.size(); i++) {
            if (typeList.get(i).getName().equals(getTypeName())) {
                return typeList.get(i);
            }
        }
        return null;
    }

    private void getTypesFromDM() {
        DimensionsConnectionDetailsEx connection = getConnection();

        if (!cmbProduct.getText().equals(Utils.EMPTY_STRING) && !cmbProduct.getText().equals(typeListProduct)) {
            typeListProduct = cmbProduct.getText();
            try {
                typeList = connection.getTypes(DMTypeScope.PROJECT, typeListProduct, null);
                if (!isStream) {
                    cmbProjectType.removeAll();
                    for (int i = 0; i < typeList.size(); i++) {
                        String typeName = typeList.get(i).getName();
                        if (!IDMConstants.STREAM_TYPE_NAME.equals(typeName) 
                         && !IDMConstants.PERSONAL_TYPE_NAME.equals(typeName)
                         && !IDMConstants.TOPIC_TYPE_NAME.equals(typeName)) {
                            cmbProjectType.add(typeName);
                        }
                    }
                    if (0 < typeList.size()) {
                        cmbProjectType.select(0);
                    }
                } else {
                    VersionBranches vbs = connection.openSession(null).getObjectFactory().getBaseDatabaseAdmin().getBranches();
                    versionBranches = new String[vbs.size()];
                    int counter = 0;
                    for (Iterator<?> it = vbs.iterator(); it.hasNext();) {
                        versionBranches[counter++] = (String) it.next();
                    }
                }

                if (null == projectList) {
                    projectList = getProjects(connection);
                }
            } catch (DMException ex) {
                setErrorMessage(ex.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private List<Project> getProjects(DimensionsConnectionDetailsEx connection) throws DMException {
        return connection.openSession(null).getObjectFactory().getProjects(null);
    }

    private void checkPage() {
        setMessage(null);
        setErrorMessage(null);
        setPageComplete(true);

        if (staticErrorMessage != null) {
            setPageComplete(false);
            setErrorMessage(staticErrorMessage);
            return;
        } else if (Utils.isNullEmpty(cmbProduct.getText())) {
            setPageComplete(false);
            setErrorMessage(Messages.NewStreamWizard_stream_general_err1);
            return;
        } else if (Utils.isNullEmpty(txtStreamName.getText())) {
            setPageComplete(false);
            setErrorMessage(NLS.bind(Messages.NewStreamWizard_stream_general_name_is_required,
                    isStream ? Messages.SharingWizard_stream : Messages.SharingWizard_project));
            return;
        } else {
            if (projectList != null) {
                String spec = cmbProduct.getText() + ":" + txtStreamName.getText(); //$NON-NLS-1$
                for (int i = 0; i < projectList.size(); i++) {
                    if (projectList.get(i).getName().equals(spec)) {
                        setPageComplete(false);
                        setErrorMessage(spec + " " + Messages.NewStreamWizard_stream_general_err6); //$NON-NLS-1$
                        return;
                    }
                }
            }
        }

        if (!isStream && !projectGroupCreationMode && Utils.isNullEmpty(cmbProjectType.getText())) { // project type
            setPageComplete(false);
            setErrorMessage(Messages.NewStreamWizard_stream_general_err5);
            return;
        } else if (!isStream && !projectGroupCreationMode && Utils.isNullEmpty(txtStreamDescr.getText())) { // description
            setPageComplete(false);
            setErrorMessage(Messages.NewStreamWizard_stream_general_err3);
            return;
        } else if (projectGroupCreationMode && Utils.isNullEmpty(txtPrjGrpName.getText())) { // group name
            setPageComplete(false);
            setErrorMessage(Messages.NewStreamWizard_stream_general_err11);
            return;
        } else if (isStream && Utils.isNullEmpty(txtStreamBranch.getText())) { // stream branch
            setPageComplete(false);
            setErrorMessage(Messages.NewStreamWizard_stream_general_err4);
            return;
        } else if (isStream && (versionBranches != null)) { // check on existing stream branch
            for (int i = 0; i < versionBranches.length; i++) {
                if (txtStreamBranch.getText().equals(versionBranches[i])) {
                    setPageComplete(false);
                    setErrorMessage(versionBranches[i] + " " + Messages.NewStreamWizard_stream_general_err7); //$NON-NLS-1$
                    return;
                }
            }
        }
        // need to check irrespective of showing advanced
        String[] holder = new String[1];
        if (project != null && TeamUtils.projectPathNotWritable(project.getLocation(), advancedSettings.getWorkAreaPath(), holder)) {
            setPageComplete(false);
            setErrorMessage(NLS.bind(Messages.NewStreamWizard_stream_offset_err6, holder[0]));
            return;
        }

        if (advancedSettings.getAllowed()) {
            advancedSettings.checkPage();
        }
    }

    private String safeGetText(final Text ctrl) {
        if (null == ctrl) {
            return null;
        }

        final String[] res = new String[1];
        ctrl.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                res[0] = ctrl.getText();
            }
        });
        return res[0];
    }

    /*
     * Load options from type of a project/workset
     */
    private void loadOptionFromType() {
        if (!(getWizard() instanceof NewStreamWizard)) {
            return;
        }
        try {
            NewStreamWizard wiz = (NewStreamWizard) getWizard();
            Product product = wiz.getConnection().getProduct(wiz.getProductName(), null);
            Types types = product.getProjectTypes();
            if (types.size() == 0) {
                return;
            }
            /* Load stream options */
            Type type = types.get(IDMConstants.STREAM_TYPE_NAME);
            wiz.setOptionsFromType(type.getOptions());
        } catch (DMException e) {
            setErrorMessage(e.getMessage());
        }
    }

    public boolean isResetAfterShelve() {
        return isResetAfterShelve;
    }
}



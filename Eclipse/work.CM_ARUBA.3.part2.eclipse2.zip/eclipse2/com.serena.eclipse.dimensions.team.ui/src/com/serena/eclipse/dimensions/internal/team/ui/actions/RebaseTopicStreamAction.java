package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.RebaseTopicStreamDialog;

public class RebaseTopicStreamAction extends DimensionsAction {

	@Override
	public void run(IAction action) {
		final WorksetAdapter workset = (WorksetAdapter) getSelection().getFirstElement();
		final RebaseTopicStreamDialog dialog = new RebaseTopicStreamDialog(getShell(), workset);
		if (dialog.open() == Window.OK) {
			try {
				PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
					@Override
					public void run(final IProgressMonitor monitor)
							throws InvocationTargetException, InterruptedException {

						try {
							Session session = workset.getConnectionDetails().openSession(monitor);
							session.run(new ISessionRunnable() {
								@Override
								public void run() throws Exception {
									try {
										monitor.beginTask("Rebasing topic stream...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
										workset.getAPIObject().rebase(dialog.getTargetProject().getName(),
												dialog.getTargetProjectVersion());

									} finally {
										monitor.done();
									}
								}
							}, monitor);
						} catch (DMException e) {
							DMUIPlugin.getDefault().handle(e);
						} finally {
							monitor.setTaskName(Utils.EMPTY_STRING);
							monitor.subTask(Utils.EMPTY_STRING);
							monitor.done();
						}
					}
				});
			} catch (InvocationTargetException e) {
				DMUIPlugin.getDefault().handle(e);
			} catch (InterruptedException e) {
				DMUIPlugin.getDefault().handle(e);
			}
		}
	}
}

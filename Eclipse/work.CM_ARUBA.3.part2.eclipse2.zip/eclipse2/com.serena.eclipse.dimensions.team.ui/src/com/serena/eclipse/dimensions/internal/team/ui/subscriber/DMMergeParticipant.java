/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.ArrayList;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.SynchronizePageActionGroup;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.PartInitException;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMMergeSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.ProjectMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.actions.ItemHistoryAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Dimensions perge participant, can persist merge information and reconstruct
 * a merge subscriber.
 * @author V.Grishchenko
 */
public class DMMergeParticipant extends DMBaseCompareParticipant {
    /** my id */
    public static final String ID = "com.serena.eclipse.dimensions.team.dmmerge-participant"; //$NON-NLS-1$

    private static final String TOOLBAR_CONTRIBUTION_GROUP = "toolbar_group"; //$NON-NLS-1$
    private static final String CONTEXT_MENU_CONTRIBUTION_GROUP = "context_group_1"; //$NON-NLS-1$
    private static final String NON_MODAL_CONTEXT_MENU_CONTRIBUTION_GROUP = "context_group_2"; //$NON-NLS-1$

    // memento keys
    private static final String CONNECTION_KEY = "connection"; //$NON-NLS-1$
    private static final String PROJECT_MERGE_KEY = "project_merge"; //$NON-NLS-1$
    private static final String ANCESTOR_KEY = "ancestor"; //$NON-NLS-1$
    private static final String ANCESTOR_TYPE_KEY = "ancestor_type"; //$NON-NLS-1$
    private static final String ANCESTOR_OFFSET_KEY = "ancestor_offset"; //$NON-NLS-1$
    private static final String SOURCE_KEY = "source"; //$NON-NLS-1$
    private static final String SOURCE_TYPE_KEY = "source_type"; //$NON-NLS-1$
    private static final String SOURCE_OFFSET_KEY = "source_offset"; //$NON-NLS-1$
    private static final String ROOT_KEY = "root"; //$NON-NLS-1$
    private static final String ROOT_PATH_KEY = "root_resource"; //$NON-NLS-1$

    private String myName;

    private class MergeParticipantActionContribution extends SynchronizePageActionGroup {
        @Override
        public void initialize(ISynchronizePageConfiguration configuration) {
            super.initialize(configuration);

            DMMergeUpdateAction updateAction = new DMMergeUpdateAction(configuration, getVisibleRootsSelectionProvider());
            updateAction.setToolTipText(Messages.DMMergeParticipant_updateActionTooltip);
            updateAction.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.CHECKOUT_ACTION));
            updateAction.setDisabledImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.CHECKOUT_ACTION_D));
            updateAction.setPromptBeforeUpdate(true);

            appendToGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP, updateAction);

            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP, new DMMergeUpdateAction(
                    configuration));

            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP, new DMConfirmMergedAction(
                    configuration));

            if (!configuration.getSite().isModal()) {
                String historyLabel = "!history action key changed in plugin.properties!"; //$NON-NLS-1$
                try {
                    historyLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "ShowHistory.label"); //$NON-NLS-1$
                } catch (Exception e) {
                }
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, NON_MODAL_CONTEXT_MENU_CONTRIBUTION_GROUP,
                        new DMActionDelegateWrapper(historyLabel, new ItemHistoryAction(), configuration));
            }

        }
    }

    /**
     * No-arg constructor to be invoked on registry creation
     */
    public DMMergeParticipant() {
    }

    /**
     * @param scope
     */
    public DMMergeParticipant(DMMergeSubscriber mergeSubscriber) {
        super(mergeSubscriber);
    }

    @Override
    protected ISynchronizeParticipantDescriptor getDescriptor() {
        return TeamUI.getSynchronizeManager().getParticipantDescriptor(ID);
    }

    @Override
    public String getName() {
        if (myName == null) {
            DMMergeSubscriber mergeSubscriber = (DMMergeSubscriber) getSubscriber();
            ProjectMergeDescriptor[] elements = mergeSubscriber.getDescriptors();
            String[] pairs = new String[elements.length];
            for (int i = 0; i < pairs.length; i++) {
                pairs[i] = NLS.bind(Messages.DMMergeParticipant_ancestorAndSource, elements[i].getAncestor().getId(),
                        elements[i].getRemote().getId());
            }
            myName = NLS.bind(Messages.DMMergeParticipant_namePattern,
                    new String[] { configElement != null ? configElement.getAttribute("name") : super.getName(), //$NON-NLS-1$
                            Utils.toCsvString(pairs, true), TeamUtils.convertSelection(mergeSubscriber.roots()) });
        }
        return myName;
    }

    @Override
    protected void setSubscriber(Subscriber subscriber) {
        setSecondaryId(((DMMergeSubscriber) subscriber).getId());
        super.setSubscriber(subscriber);
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, NON_MODAL_CONTEXT_MENU_CONTRIBUTION_GROUP);
        configuration.addActionContribution(new MergeParticipantActionContribution());
        configuration.setSupportedModes(ISynchronizePageConfiguration.INCOMING_MODE
                | ISynchronizePageConfiguration.CONFLICTING_MODE);
        configuration.setMode(ISynchronizePageConfiguration.INCOMING_MODE);
    }

    @Override
    public void init(String secondaryId, IMemento memento) throws PartInitException {
        super.init(secondaryId, memento);
        try {
            setSubscriber(read(memento));
        } catch (DMException e) {
            throw new PartInitException(Messages.DMMergeParticipant_unableInitialize, e);
        }
    }

    @Override
    public void saveState(IMemento memento) {
        super.saveState(memento);
        write((DMMergeSubscriber) getSubscriber(), memento);
    }

    /*
     * store information necessary to reconstruct a merge subscriber
     */
    protected void write(DMMergeSubscriber subscriber, IMemento memento) {
        memento.putString(CONNECTION_KEY, subscriber.getConnection().getConnName());
        ProjectMergeDescriptor[] projectMerges = subscriber.getDescriptors();
        for (int i = 0; i < projectMerges.length; i++) {
            IMemento projectMergeNode = memento.createChild(PROJECT_MERGE_KEY);
            projectMergeNode.putString(ANCESTOR_KEY, projectMerges[i].getAncestor().getId());
            projectMergeNode.putInteger(ANCESTOR_TYPE_KEY, projectMerges[i].getAncestor().getType());
            projectMergeNode.putString(ANCESTOR_OFFSET_KEY, projectMerges[i].getAncestor().getRemoteOffset().toString());
            projectMergeNode.putString(SOURCE_KEY, projectMerges[i].getRemote().getId());
            projectMergeNode.putInteger(SOURCE_TYPE_KEY, projectMerges[i].getRemote().getType());
            projectMergeNode.putString(SOURCE_OFFSET_KEY, projectMerges[i].getRemote().getRemoteOffset().toString());
            IResource[] roots = projectMerges[i].getRoots();
            for (int j = 0; j < roots.length; j++) {
                IMemento rootNode = projectMergeNode.createChild(ROOT_KEY);
                rootNode.putString(ROOT_PATH_KEY, roots[j].getFullPath().toString());
            }
        }
    }

    protected DMMergeSubscriber read(IMemento memento) throws DMException {
        ArrayList projectMerges = new ArrayList();
        if (memento != null) {
            String connectionName = memento.getString(CONNECTION_KEY);
            DimensionsConnectionDetailsEx connection = DMPlugin.getDefault().getConnection(connectionName);
            if (connection == null) {
                throw new DMException(NLS.bind(Messages.DMMergeParticipant_noConnection, connectionName), null);
            }
            IMemento[] projectMergeNodes = memento.getChildren(PROJECT_MERGE_KEY);
            if (projectMergeNodes == null || projectMergeNodes.length == 0) {
                throw new DMException(NLS.bind(Messages.DMMergeParticipant_noProjectMerges, getSecondaryId()), null);
            }
            for (int i = 0; i < projectMergeNodes.length; i++) {
                String ancestorId = projectMergeNodes[i].getString(ANCESTOR_KEY);
                Integer ancestorType = projectMergeNodes[i].getInteger(ANCESTOR_TYPE_KEY);
                String ancestorOffset = projectMergeNodes[i].getString(ANCESTOR_OFFSET_KEY);
                String sourceId = projectMergeNodes[i].getString(SOURCE_KEY);
                Integer sourceType = projectMergeNodes[i].getInteger(SOURCE_TYPE_KEY);
                String sourceOffset = projectMergeNodes[i].getString(SOURCE_OFFSET_KEY);
                if (ancestorId == null || ancestorType == null || sourceId == null || sourceType == null) {
                    throw new DMException(NLS.bind(Messages.DMMergeParticipant_noAncestorSource, getSecondaryId()), null);
                }

                IMemento[] rootNodes = projectMergeNodes[i].getChildren(ROOT_KEY);
                if (rootNodes == null || rootNodes.length == 0) {
                    throw new DMException(NLS.bind(Messages.DMMergeParticipant_noRoots, getSecondaryId()), null);
                }
                IProject project = null;
                ArrayList resources = new ArrayList();
                for (int j = 0; j < rootNodes.length; j++) {
                    IPath path = new Path(rootNodes[j].getString(ROOT_PATH_KEY));
                    IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(path, true /* include phantoms */);
                    if (resource != null) {
                        if (project == null) {
                            project = resource.getProject();
                        }
                        resources.add(resource);
                    } else {
                        DMTeamUiPlugin.log(new DMTeamStatus(IStatus.INFO, DMTeamStatus.UNKNOWN, NLS.bind(
                                Messages.DMMergeParticipant_missingRoot, path.toString()), null));
                    }
                }
                if (project != null) {
                    IDMProject ancestor = DMRepositoryProvider.createProject(ancestorId, ancestorType.intValue(), connection,
                            project, null, getOffset(ancestorOffset));
                    IDMProject source = DMRepositoryProvider.createProject(sourceId, sourceType.intValue(), connection, project,
                            null, getOffset(sourceOffset));
                    IResource[] roots = (IResource[]) resources.toArray(new IResource[resources.size()]);
                    projectMerges.add(new ProjectMergeDescriptor(project, roots, ancestor, source));
                }
            }
        }
        return new DMMergeSubscriber(getSecondaryId(),
                (ProjectMergeDescriptor[]) projectMerges.toArray(new ProjectMergeDescriptor[projectMerges.size()]));
    }

    private IPath getOffset(String offset) {
        if (Utils.isNullEmpty(offset)) {
            return null;
        }
        return new Path(offset);
    }

    @Override
    protected String getShortTaskName() {
        return Messages.DMMergeParticipant_shortTask;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDimensionsServiceResource;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewGroupWizard;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;

/**
 * Launches new group wizard.
 * @author V.Grishchenko
 */
public class NewProjectGroupAction extends DimensionsAction {

    public NewProjectGroupAction() {
    }

    @Override
    public void run(IAction action) {
        IStructuredSelection selection = getSelection();
        if (selection.isEmpty()) {
            return;
        }

        DimensionsConnectionDetailsEx connection = null;
        ArrayList list = new ArrayList();
        for (Iterator iter = selection.iterator(); iter.hasNext();) {
            IDimensionsServiceResource resource = (IDimensionsServiceResource) iter.next();
            connection = resource.getConnectionDetails();
            if (resource instanceof APIObjectAdapter) {
                list.add(resource);
            }
        }
        APIObjectAdapter[] groupMembers = (APIObjectAdapter[]) list.toArray(new APIObjectAdapter[list.size()]);
        NewGroupWizard wizard = new NewGroupWizard(connection, groupMembers);
        WizardDialog dialog = new WizardDialog(getShell(), wizard);
        dialog.open();
    }

    // only enable if all from the same connection and all are worksets/baselines or single selection
    @Override
    protected boolean isEnabledForSelection() {
        IStructuredSelection selection = getSelection();

        // 1. always enable for a single IDimensionsServiceResource
        if (selection.size() == 1) {
            return true;
        }

        // 2. enable for worksets and baselines from 1 connection
        DimensionsConnectionDetailsEx connection = null;
        for (Iterator iter = selection.iterator(); iter.hasNext();) {
            IDimensionsServiceResource dmResource = (IDimensionsServiceResource) iter.next();
            boolean validGroupMember = dmResource.getClass() == WorksetAdapter.class || dmResource instanceof BaselineAdapter;
            if (!validGroupMember) {
                return false;
            }
            if (connection == null) {
                connection = dmResource.getConnectionDetails();
            } else {
                if (!connection.equals(dmResource.getConnectionDetails())) {
                    return false;
                }
            }
        }
        return true;
    }

}

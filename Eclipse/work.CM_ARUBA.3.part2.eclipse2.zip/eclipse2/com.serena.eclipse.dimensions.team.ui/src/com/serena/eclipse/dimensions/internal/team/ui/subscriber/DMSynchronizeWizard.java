/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;
import org.eclipse.team.ui.synchronize.SubscriberParticipant;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.TeamUIUtils;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.ProjectImportWizard;

/**
 * @author V.Grishchenko
 */
public class DMSynchronizeWizard extends SubscriberParticipantWizard {

    public DMSynchronizeWizard() {
    }

    @Override
    protected IResource[] getRootResources() {
        return DMTeamPlugin.getWorkspace().getSubscriber().roots();
    }

    @Override
    protected SubscriberParticipant createParticipant(ISynchronizeScope scope) throws TeamException {
        // First check if there is an existing matching participant
        IResource[] roots = scope.getRoots();
        if (roots == null) {
            roots = DMTeamPlugin.getWorkspace().getSubscriber().roots();
        }
        DMSynchronizeParticipant participant = (DMWorkspaceSynchronizeParticipant) SubscriberParticipant.getMatchingParticipant(
                DMWorkspaceSynchronizeParticipant.ID, roots);
        // If there isn't, create one and add to the manager
        if (participant == null) {
            if (TeamUtils.isAnyResourceFromStream(roots)) {
                TeamUIUtils.removeParticipantById(DMWorkspaceSynchronizeParticipant.ID);
                participant = new DMWorkspaceStreamCompareParticipant(scope);
            } else {
                TeamUIUtils.removeParticipantById(DMWorkspaceStreamOutgoingParticipant.ID);
                TeamUIUtils.removeParticipantById(DMWorkspaceStreamCompareParticipant.ID);
                participant = new DMWorkspaceSynchronizeParticipant(scope);
            }
        }
        return participant;
    }

    @Override
    protected String getName() {
        ISynchronizeParticipantDescriptor descriptor = TeamUI.getSynchronizeManager().getParticipantDescriptor(
                DMWorkspaceSynchronizeParticipant.ID);
        if (descriptor == null) {
            return Messages.DMSynchronizeWizard_0;
        }
        return descriptor.getName();
    }

    @Override
    protected IWizard getImportWizard() {
        return new ProjectImportWizard();
    }

}

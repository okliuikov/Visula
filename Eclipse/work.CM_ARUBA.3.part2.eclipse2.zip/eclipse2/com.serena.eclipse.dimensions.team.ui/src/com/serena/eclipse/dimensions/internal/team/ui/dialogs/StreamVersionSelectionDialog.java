/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import java.beans.PropertyChangeListener;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;

public class StreamVersionSelectionDialog extends Dialog {
    private VersionManagementProject project;
    private ChangeSetHistoryView view;
    private String title;

    private PropertyChangeListener listener;
    private boolean refresh = false;

    public StreamVersionSelectionDialog(Shell parentShell, String title, VersionManagementProject project) {
        super(parentShell);
        setShellStyle(getShellStyle() | SWT.RESIZE);
        setVersionManagementProject(project);
        this.title = title;
    }

    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        if (title != null) {
            newShell.setText(title);
        }
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite) super.createDialogArea(parent);

        view = new ChangeSetHistoryView();
        view.setEmbeddedToDialog(this);
        view.setShowChangeSteps(false);
        view.createPartControl(composite);

        GridData gd = UIUtils.setGridData(view.getMainControl(), GridData.FILL_BOTH);
        gd.widthHint = 685;
        gd.heightHint = 290;

        refresh();

        if (listener != null) {
            view.addEmbeddedSelectionChangeListener(listener);
        }
        return composite;
    }

    /**
     * @return current project context
     */
    public VersionManagementProject getVersionManagementProject() {
        return project;
    }

    /**
     * Set project context
     *
     * @param project
     *            is a context for querying stream versions
     */
    public void setVersionManagementProject(VersionManagementProject project) {
        Assert.isNotNull(project);
        if (!project.equals(getVersionManagementProject())) {
            refresh = true;
        }
        this.project = project;
    }

    /**
     * @param listener
     *            for selection events from the wrapped {@link ChangeSetHistoryView}
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        this.listener = listener;
        if (view != null) {
            view.addEmbeddedSelectionChangeListener(listener);
        }
    }

    /**
     * Performs refresh of embedded change set view using current project
     */
    public void refresh() {
        if (view != null && refresh) {
            view.showMe(new WorksetAdapter((Project) project.getAPIObject(), project.getConnectionDetails()), null, null);
            this.refresh = false;
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.compare.CompareUI;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.compare.DMCompareEditorInput;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectSelectionPanel;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Compares version management objects.
 * @author V.Grishchenko
 */
public class CompareVMObjectsAction extends DMTeamAction {

    public CompareVMObjectsAction() {
        super(true);
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {

        APIObjectAdapter[] vmObjects = getSelectedRemoteResources();
        if (vmObjects == null || vmObjects.length != 2) {
            MessageDialog.openError(getShell(), Messages.CompareVMObjectsAction_0, Messages.CompareVMObjectsAction_1);
            return;
        }

        VersionManagementProject left = (VersionManagementProject) vmObjects[0];
        VersionManagementProject right = (VersionManagementProject) vmObjects[1];
        VersionManagementProject ancestor = null;
        try {
            if (left.getConnectionDetails().equals(right.getConnectionDetails())) {
                Baseline ancestorBaseline = findCommonAncestor(left, right);
                if (ancestorBaseline == null) {
                    MyDialog dialog = new MyDialog(getShell(), left.getConnectionDetails());
                    if (dialog.open() == Window.CANCEL) {
                        return;
                    }
                    ancestor = dialog.selection;
                } else {
                    ancestor = new BaselineAdapter(ancestorBaseline, left.getConnectionDetails());
                }
            }
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e);
            return;
        } catch (InterruptedException e) {
            return;
        }
        CompareUI.openCompareEditor(new DMCompareEditorInput(left, right, ancestor));
    }

    private Baseline findCommonAncestor(final VersionManagementProject left, final VersionManagementProject right)
            throws InvocationTargetException, InterruptedException {
        final Baseline[] result = new Baseline[1];
        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    final Session session = left.getConnectionDetails().openSession(null);
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            DimensionsLcObject leftProject = (DimensionsLcObject) left.getAPIObject();
                            DimensionsLcObject rightProject = (DimensionsLcObject) right.getAPIObject();
                            if (leftProject instanceof ItemRevision || rightProject instanceof ItemRevision) {
                                // This is a SCC style project, therefore don't use an ancestor baseline
                                result[0] = null;
                            } else {
                                result[0] = DMTeamUiPlugin.getDefault().findCommonAncestorBaseline(
                                        (DimensionsLcObject) left.getAPIObject(), (DimensionsLcObject) right.getAPIObject(),
                                        session.getObjectFactory(), session.getConnectionDetails(), monitor);
                            }
                        }
                    });
                } catch (DMException e) {
                    throw new InvocationTargetException(e);
                }
            }
        });
        return result[0];
    }

    private class MyDialog extends Dialog implements IPropertyChangeListener {
        VersionManagementProject selection;
        DimensionsConnectionDetailsEx connection;
        ProjectSelectionPanel panel;

        protected MyDialog(Shell parentShell, DimensionsConnectionDetailsEx connection) {
            super(parentShell);
            setShellStyle(getShellStyle() | SWT.RESIZE);
            this.connection = connection;
        }

        @Override
        protected Control createDialogArea(Composite parent) {
            Composite composite = (Composite) super.createDialogArea(parent);

            String msg;
            if (DMTeamUiPlugin.getDefault().isAutoFindCommonAncestorBaseline()) {
                msg = Messages.CompareVMObjectsAction_2;
            } else {
                msg = Messages.CompareVMObjectsAction_5;
            }

            panel = new ProjectSelectionPanel(ProjectSelectionPanel.BASELINE, composite, SWT.NONE, msg,
                    Messages.CompareVMObjectsAction_3, false, false);
            panel.setConnection(connection);

            UIUtils.setGridData(panel.getPanel(), GridData.FILL_BOTH);
            panel.addPropertyChangeListener(this);

            return composite;
        }

        @Override
        protected void configureShell(Shell newShell) {
            super.configureShell(newShell);
            newShell.setText(Messages.CompareVMObjectsAction_4);
        }

        @Override
        public void propertyChange(PropertyChangeEvent event) {
            if (ProjectSelectionPanel.SELECTION.equals(event.getProperty())) {
                selection = (VersionManagementProject) event.getNewValue();
            }
            Button okBtn = getButton(IDialogConstants.OK_ID);
            okBtn.setEnabled(selection != null || panel.isNullSelection());
        }

    }

}

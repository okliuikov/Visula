/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;

import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * @author V.Grishchenko
 */
public class DMConfirmMergedOperation extends DMSynchronizeModelOperation {
    private IStatus status;

    public DMConfirmMergedOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        super(configuration, elements);
    }

    @Override
    protected String getJobName() {
        return NLS.bind(Messages.DMConfirmMergedOperation_jobName, String.valueOf(getSyncInfoSet().size()));
    }

    @Override
    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
        SyncInfoSet syncInfoSet = getSyncInfoSet();
        if (syncInfoSet.isEmpty()) {
            return;
        }
        try {
            SyncInfo[] nodes = syncInfoSet.getSyncInfos();
            IResource[] locals = new IResource[nodes.length];
            IDMRemoteResource[] remotes = new IDMRemoteResource[nodes.length];
            for (int i = 0; i < nodes.length; i++) {
                locals[i] = nodes[i].getLocal();
                remotes[i] = (IDMRemoteResource) nodes[i].getRemote();
            }
            status = getSubscriber().merged(locals, remotes, monitor);
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }

        if (!status.isOK()) {
            warnAboutFailures();
        }
    }

    @Override
    protected void run(SyncData data, IProgressMonitor monitor) throws CoreException {
    }

    private void warnAboutFailures() {
        UIUtils.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                ErrorDialog.openError(getShell(), Messages.DMConfirmMergedOperation_failure,
                        Messages.DMConfirmMergedOperation_failureMsg, status);
            }
        });
    }

}

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IWorkbenchPage;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;

public class ChangeSetSourceTypeTester extends PropertyTester {
    public static final String CHANGESET_SOURCE_TYPE = "changesetSourceType"; //$NON-NLS-1$

    public ChangeSetSourceTypeTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (!(receiver instanceof StructuredSelection)) {
            return false;
        }
        StructuredSelection ss = (StructuredSelection) receiver;
        Object selected = ss.getFirstElement();
        if (!(selected instanceof DimensionsChangeSet)) {
            return false;
        }
        String expectedChangesetSourceType = (String) expectedValue;
        if (property.equals(CHANGESET_SOURCE_TYPE)) {
            IWorkbenchPage activePage = UIUtils.getActivePage();
            ChangeSetHistoryView view = (ChangeSetHistoryView) activePage.findView(ChangeSetHistoryView.ID);
            String changesetSourceType = view.getChangesetSourceTypeName();
            return expectedChangesetSourceType.equals(changesetSourceType);
        } else {
            return false;
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.team.core.TeamException;

import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.operations.LockOperation;

/**
 *
 * @author kberezovchuk
 */
public class UnlockAction extends DMWorkspaceAction implements IDMWorkspaceResourceFilter {
    private static final IDMWorkspaceResourceFilter UNLOCK_FILTER = new StatusFilter(
            WorkspaceResourceStatus.MANAGED | WorkspaceResourceStatus.LOCKED_FILE, StatusFilter.AND);

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources;
        try {
            resources = getResources();
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        if (resources.length == 0) {
            return;
        }

        LockOperation operation = new LockOperation(getActivePart(), resources, getResourceFilter(), false);
        if (!operation.prompt()) {
            throw new InterruptedException();
        }
        operation.run();
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return this;
    }

    @Override
    public boolean select(IDMWorkspaceResource resource) throws TeamException {
        return UNLOCK_FILTER.select(resource);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.runtime.Assert;

import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.StreamInitialData;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.AddToRemoteMainPage;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.CommitWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewStreamGeneralPage;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardAttributesPage;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardMainPage;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;

/**
 * @author V.Grishchenko
 */
class DMWorkspaceCommitWizard extends CommitWizard {
    public static final String STREAM_GENERAL_PAGE = "stream_general_page"; // 2 stream //$NON-NLS-1$

    private boolean isShelve;
    private boolean isDeliver;

    private StreamInitialData shelfInitials;
    private Project shelfParent;

    public DMWorkspaceCommitWizard(DMWorkspaceCommitHelper helper) {
        super(helper, helper.isRequestsSupported());
        setWindowTitle(Messages.DMWorkspaceCommitWizard_0);
    }

    public DMWorkspaceCommitWizard(DMWorkspaceCommitHelper helper, boolean isDeliver, boolean isShelve) {
        super(helper, helper.isRequestsSupported());
        Assert.isLegal(isShelve != isDeliver || !isShelve && !isDeliver); // both false or different

        setDeliver(isDeliver);
        setShelve(isShelve);

        if (isDeliver()) {
            setWindowTitle(Messages.DMWorkspaceDeliverWizard_0);
        } else if (isShelve()) {
            setWindowTitle(Messages.DMWorkspaceShelveWizard_0);
        } else {
            setWindowTitle(Messages.DMWorkspaceCommitWizard_0);
        }
    }

    /**
     * @return the isShelve
     */
    public boolean isShelve() {
        return isShelve;
    }

    /**
     * @param isShelve the isShelve to set
     */
    public void setShelve(boolean isShelve) {
        this.isShelve = isShelve;
    }

    /**
     * @return the isDeliver
     */
    public boolean isDeliver() {
        return isDeliver;
    }

    /**
     * @param isDeliver the isDeliver to set
     */
    public void setDeliver(boolean isDeliver) {
        this.isDeliver = isDeliver;
    }

    @Override
    protected TeamOperationWizardMainPage createMainPage(String name) {
        if (getCommitHelper().hasAdditions()) {
            // return page that can specify additional add parameters
            AddToRemoteMainPage page = new AddToRemoteMainPage(name, getMainPageTitle(), getMainPageDescription(),
                    getMainPageImage(), getMainPageOptions());
            page.setHelper(getHelper());
            page.setOperationOptions(getOperationOptions());
            return page;
        }
        return super.createMainPage(name);
    }

    @Override
    protected NewStreamGeneralPage createNewStreamPage(String newStreamPageId) {
        if (isShelve()) {
            if (shelfInitials == null) {
                shelfInitials = new StreamInitialData("", "", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            }

            NewStreamGeneralPage page = new NewStreamGeneralPage(newStreamPageId, Messages.DMWorkspaceCommitWizard_9ShelvingTitle,
                    Messages.DMWorkspaceCommitWizard_10ShelvingDescription, DMUIPlugin.getDefault().getImageDescriptor(
                            IDMImages.LOGIN_WIZBAN), shelfInitials, shelfParent);
            return page;
        }
        return null;
    }

    @Override
    protected TeamOperationWizardAttributesPage createAttributesPage(String name) {
        // only need attributes page if add, opt. or pess. checkins.
        if (getCommitHelper().isCreateNewRevisions() || getCommitHelper().hasCheckins()) {
            return super.createAttributesPage(name);
        }
        return null;
    }

    @Override
    protected String getAttributePageTitle() {
        return Messages.DMWorkspaceCommitWizard_1;
    }

    @Override
    protected String getAttributePageDescription() {
        return Messages.DMWorkspaceCommitWizard_2;
    }

    @Override
    protected int getMainPageOptions() {
        int options = TeamOperationWizardMainPage.SHOW_TREE;
        if (getCommitHelper().hasCheckins() || getCommitHelper().hasOptimisticCheckins()) {
            options |= TeamOperationWizardMainPage.SHOW_COMPARE;
        }
        if (getCommitHelper().hasCheckins() || getCommitHelper().hasOptimisticCheckins() || getCommitHelper().hasAdditions()) {
            options |= TeamOperationWizardMainPage.SHOW_COMMENT;
        }
        return options;
    }

    @Override
    protected String getMainPageTitle() {
        if (isDeliver()) {
            return Messages.DMWorkspaceCommitWizard_4;
        } else if (isShelve()) {
            return Messages.DMWorkspaceCommitWizard_5;
        } else {
            return Messages.DMWorkspaceCommitWizard_3;
        }
    }

    private DMWorkspaceCommitHelper getCommitHelper() {
        return (DMWorkspaceCommitHelper) getHelper();
    }

    void setShelfInitialData(StreamInitialData shelfInitials, Project shelfParent) {
        this.shelfInitials = shelfInitials;
        this.shelfParent = shelfParent;
    }

}

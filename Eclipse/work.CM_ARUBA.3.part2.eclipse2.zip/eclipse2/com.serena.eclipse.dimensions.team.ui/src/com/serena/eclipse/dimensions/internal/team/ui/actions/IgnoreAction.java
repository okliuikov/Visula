/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.team.core.TeamException;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.IgnoreResourcesDialog;

/**
 * Adds ignore patterns to .dmignore file.
 * @author V.Grishchenko
 */
public class IgnoreAction extends DMWorkspaceAction implements IDMWorkspaceResourceFilter {

    public IgnoreAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources;
        try {
            resources = getResources();
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        if (resources.length == 0) {
            return;
        }

        final IResource[] toIgnore = resources;

        final IgnoreResourcesDialog dialog = new IgnoreResourcesDialog(getShell(), toIgnore);
        if (dialog.open() != Window.OK) {
            return;
        }
        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                monitor = Utils.monitorFor(monitor);
                monitor.beginTask(Messages.IgnoreAction_0, toIgnore.length);
                try {
                    for (int i = 0; i < toIgnore.length; i++) {
                        IResource resource = toIgnore[i];
                        String pattern = dialog.getIgnorePatternFor(resource);
                        boolean isRecursive = dialog.isRecursive();
                        DMTeamPlugin.getWorkspace().addIgnorePattern(resource.getParent(), pattern, isRecursive);
                        monitor.worked(1);
                    }
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                } finally {
                    monitor.done();
                }
            }
        });
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return this;
    }

    @Override
    protected boolean isEnabledOffline() {
        return true; // only updates local
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true; // ok for baselines
    }

    @Override
    protected boolean isEnabledForMultipleConnections() {
        return true; // ok for resources mapped to different connections
    }

    @Override
    public boolean select(IDMWorkspaceResource resource) throws TeamException {
        if (resource.getLocalResource().getType() == IResource.PROJECT) {
            return false; // projects cannot be ignore
        }

        if (resource.isManaged()) {
            return false; // managed resources are not ignored by definition
        }

        if (resource.isIgnored()) {
            return false; // disable if already ignored
        }

        return true;
    }

}

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;

import com.serena.dmclient.api.DimensionsChangeSet;

public class ChangeSetDetailsStatusTester extends PropertyTester {
	public static final String URL_AVAILABLE = "changesetDetailsUrlAvailable"; //$NON-NLS-1$

	public ChangeSetDetailsStatusTester() {
	}

	@Override
	public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
		if (!(receiver instanceof StructuredSelection)) {
			return false;
		}
		StructuredSelection ss = (StructuredSelection) receiver;
		Object selected = ss.getFirstElement();
		if (!(selected instanceof DimensionsChangeSet)) {
			return false;
		}
		DimensionsChangeSet cs = (DimensionsChangeSet) selected;
		if (property.equals(URL_AVAILABLE) && cs.isOrbiterStatusReady()) {
			return cs.getChangesetDetailsSuffix() != null && !cs.getChangesetDetailsSuffix().isEmpty();
		} else {
			return false;
		}
	}
}

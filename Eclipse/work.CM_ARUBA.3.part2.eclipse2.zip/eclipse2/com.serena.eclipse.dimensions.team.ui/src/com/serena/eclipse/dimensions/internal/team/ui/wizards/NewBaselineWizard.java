/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.dmclient.api.BaselineDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmclient.objects.Type;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.BaselineList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.model.BaselineAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.wizards.AttributesWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewObjectWizard;

/**
 * Wizard that creates a baseline.
 *
 * @author V.Grishchenko
 */
public class NewBaselineWizard extends NewObjectWizard {

    public static String BASELINE_TEMPLATE_PAGE = "baseline_template_page"; // NON-NLS-1$
    public static String BASELINE_REQUEST_PAGE = "baseline_request_page"; // NON-NLS-1$
    public static String BASELINE_REVISE_PAGE = "baseline_revise_page"; // NON-NLS-1$

    public static final int INVALID_MODE = -1;
    public static final int TIP_BASELINE = 1;
    public static final int TEMPLATE_BASELINE = 2;
    public static final int REVISED_BASELINE = 3;

    public NewBaselineWizard() {

        setWizardTitle();
    }

    public NewBaselineWizard(DimensionsConnectionDetailsEx connection) {
        super(connection);
        setWizardTitle();
    }

    public NewBaselineWizard(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn) {
        super(connection, basedOn);
        setWizardTitle();
    }

    public NewBaselineWizard(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn, FormToolkit toolkit) {
        super(connection, basedOn, toolkit);
        setWizardTitle();
    }

    // returns the title and description as 0th and 1st elements
    protected String[] getTitleDesc() {
        return new String[] { Utils.EMPTY_STRING, Utils.EMPTY_STRING };
    }

    protected int getBaselineCode() {
        return INVALID_MODE;
    }

    private void setWizardTitle() {
        setWindowTitle(Messages.NewBaselineWizard_title);
    }

    protected void addInternalPages(int options) {

    }

    @Override
    public void addPages() {
        super.addPages();
        int options = NewBaselineGeneralPage.SHOW_BASED_ON;
        if (getBaseOnObject() != null) {
            options |= NewBaselineGeneralPage.FIND_DISABLED;
        }

        String[] titleDesc = getTitleDesc();

        // @formatter:off
        addPage(new NewBaselineGeneralPage(
                        GENERAL_PAGE,
                        titleDesc[0],
                        titleDesc[1],
                        DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                        getConnection(),
                        getBaseOnObject(),
                        getBaselineCode(),
                        options));

        addInternalPages(options);

        addPage(new AttributesWizardPage(
                        ATTRIBUTES_PAGE,
                        Messages.NewBaselineWizard_attr_title,
                        Messages.NewBaselineWizard_attr_description,
                        DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));
        // @formatter:on
    }

    @Override
    protected APIObjectAdapter performCreate(final IProgressMonitor monitor) throws DMException {
        BaselineDetails blnDetails = (BaselineDetails) objectDetails;
        blnDetails = createBaselineDetails(blnDetails, (NewBaselineGeneralPage) getPage(GENERAL_PAGE));
        VersionManagementProject adapter = (VersionManagementProject) getBaseOnObject();
        assert adapter != null;
        BaselineList baselineList = adapter.getBaselineList();
        if (baselineList == null) {
            baselineList = BaselineList.getOtherBaselinesList(adapter.getConnectionDetails());
        }
        baselineList.createObject(blnDetails, monitor);
        String blId = DMTypeScope.BASELINE.getObjectId(blnDetails);
        APIObjectAdapter[] baselines = baselineList.getObjects();
        for (int i = 0; i < baselines.length; i++) {
            if (baselines[i].getObjectSpec().equals(blId)) {
                return baselines[i];
            }
        }
        return null;
    }

    @Override
    protected IAttributeModel createAttributeModel(String productName, String typeName, Type type, APIObjectAdapter base) {
        DimensionsObjectDetails details = createBaselineDetails(null, (NewBaselineGeneralPage) getPage(GENERAL_PAGE));
        objectDetails = details; // persist it
        return new BaselineAttributeModel((BaselineDetails) details, type, getConnection());
    }

    protected BaselineDetails createBaselineDetails(BaselineDetails baselineDetails, NewBaselineGeneralPage generalPage) {
        if (baselineDetails == null) {
            baselineDetails = new BaselineDetails(generalPage.getProductName(), generalPage.getObjectId());
        } else {
            // reset the project name / object ID for existing details object
            baselineDetails.setAttribute(SystemAttributes.PRODUCT_NAME, generalPage.getProductName());
            baselineDetails.setAttribute(SystemAttributes.OBJECT_ID, generalPage.getObjectId());
        }
        baselineDetails.setTypeName(generalPage.getTypeName());

        APIObjectAdapter adapter = generalPage.getBasedOnObject();
        assert adapter != null && (adapter instanceof WorksetAdapter || adapter instanceof BaselineAdapter);
        setBasedOnObject(adapter);
        String bo = (String) adapter.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
        if (adapter instanceof WorksetAdapter) {
            baselineDetails.setBasedOnProject(bo);
        } else {
            baselineDetails.setBasedOnBaseline(bo);
        }
        return baselineDetails;
    }

    public static boolean isBaseline(int mode) {
        return mode == TIP_BASELINE || mode == TEMPLATE_BASELINE || mode == REVISED_BASELINE;
    }

    public static boolean isTipBaseline(int mode) {
        return mode == TIP_BASELINE;
    }

    public static boolean isTemplateBaseline(int mode) {
        return mode == TEMPLATE_BASELINE;
    }

    public static boolean isRevisedBaseline(int mode) {
        return mode == REVISED_BASELINE;
    }

    public static boolean isWorksetBased(int mode) {
        return (mode == TIP_BASELINE || mode == TEMPLATE_BASELINE);
    }

}

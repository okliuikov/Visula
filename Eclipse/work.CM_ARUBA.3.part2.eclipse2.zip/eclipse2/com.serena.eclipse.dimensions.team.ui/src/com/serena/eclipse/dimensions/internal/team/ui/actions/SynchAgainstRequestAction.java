package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ResourceScope;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.DimensionsRuntimeException;
import com.serena.dmclient.api.DimensionsUtils;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.StructureHistoryRec;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFolder;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.VirtualIdmProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceCustomSynchParticipant;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Update from request for Dimensions Project
 *
 * @author kberezovchuk
 *
 */
public class SynchAgainstRequestAction extends SynchronizeAction {
    private static final int CONFLICT_SINGLE_PATH = 0;
    private static final int CONFLICT_SINGLE_ITEM = 1;

    @Override
    protected boolean isEnabledForSelection() {
        if (getSelection().size() != 1) {
            return false;
        }

        DimensionsConnectionDetailsEx connection = ((ChangeDocumentAdapter) getSelection().getFirstElement())
                .getConnectionDetails();
        List<IDMProject> projects = new ArrayList<IDMProject>();
        IDMProject[] allDmProjects = null;
        try {
            allDmProjects = DMTeamPlugin.getWorkspace().getProjects();
            for (IDMProject dmproject : allDmProjects) {
                if (dmproject == null || dmproject.isBaseline() || dmproject.getIsStream()
                        || !connection.equals(dmproject.getConnection()) || dmproject instanceof VirtualIdmProject) {
                    continue;
                }
                projects.add(dmproject);
            }
            if (projects.isEmpty()) {
                return false;
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
            return false;
        }

        return true;
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        final ChangeDocumentAdapter reqAdapter = (ChangeDocumentAdapter) getSelection().getFirstElement();
        DimensionsConnectionDetailsEx connection = reqAdapter.getConnectionDetails();

        DimensionsArObject reqObject = reqAdapter.getAPIObject();

        List<IDMProject> projects = new ArrayList<IDMProject>();
        IDMProject[] allDmProjects = null;
        try {
            allDmProjects = DMTeamPlugin.getWorkspace().getProjects();
            for (IDMProject dmproject : allDmProjects) {
                if (dmproject == null) {
                    continue;
                }

                if (dmproject.isBaseline() || dmproject.getIsStream()) {
                    continue;
                }

                if (dmproject instanceof VirtualIdmProject) {
                    continue;
                }

                if (!connection.equals(dmproject.getConnection())) {
                    continue;
                }

                projects.add(dmproject);
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
            return;
        }

        if (projects.isEmpty()) {
            return;
        }

        StringBuffer participantNameInfo = new StringBuffer();
        participantNameInfo.append(((Request) reqObject).getName());

        // IResource -> IDMRemoteFile/IDMRemoteFolder resulting map
        final Map<IResource, IDMRemoteResource> remoteResourcesMap = new HashMap<IResource, IDMRemoteResource>();

        Map<String, Map<Request, List<StructureHistoryRec>>> wsStructHistoryMap = null;
        // Recursive Update From request
        HashSet<Request> childChdocs = new HashSet<Request>();
        childChdocs = getChildChdocsRecursively(reqObject, childChdocs);
        if (!childChdocs.isEmpty()) {
            MessageBox messageBox = new MessageBox(getShell(), SWT.ICON_QUESTION | SWT.YES | SWT.NO);
            messageBox.setMessage(Messages.SynchAgainstRequestAction_updRecursive_confirm);
            messageBox.setText(Messages.SynchAgainstRequestAction_updRecursive_title);
            if (messageBox.open() == SWT.YES) {
                Request[] requests = new Request[childChdocs.size() + 1];
                requests[0] = (Request) reqObject;
                int i = 0;
                for (Iterator<Request> iterChDoc = childChdocs.iterator(); iterChDoc.hasNext();) {
                    Request chDoc = iterChDoc.next();
                    requests[++i] = chDoc;
                    participantNameInfo.append(", ").append(chDoc.getName());
                }

                try {
                    Session session = reqAdapter.getConnectionDetails()
                            .openSession(Utils.subMonitorFor(new NullProgressMonitor(), 10));
                    wsStructHistoryMap = loadStructureHistoryForWS(session, requests, projects);
                } catch (DMException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                    // rare case, don't want to end up with null further
                    wsStructHistoryMap = new HashMap<String, Map<Request, List<StructureHistoryRec>>>();
                }
            } else {
                wsStructHistoryMap = loadStructureHistoryForWS(reqAdapter, projects);
            }
        } else {
            wsStructHistoryMap = loadStructureHistoryForWS(reqAdapter, projects);
        }

        if (wsStructHistoryMap == null) {
            return;
        }

        if (!wsStructHistoryMap.isEmpty()) { // have unchecked resources
            Map<String, Map<Request, List<StructureHistoryRec>>> wsStructHistoryArrangedMap = new HashMap<String, Map<Request, List<StructureHistoryRec>>>();
            Map<String, List<StructureHistoryRec>> wsStructHistoryCheckedMap = new HashMap<String, List<StructureHistoryRec>>();

            // arrange structure history - gather the latest significant events
            arrangeStructureHistory(wsStructHistoryMap, wsStructHistoryArrangedMap);
            // pedigree check/single item check
            List<Object[]> conflictsList = checkStructureHistory(wsStructHistoryArrangedMap, wsStructHistoryCheckedMap);
            if (!conflictsList.isEmpty()) {
                Object[] firstConflict = conflictsList.get(0);
                assert firstConflict.length < 6;
                String message = null;
                if (((Integer) firstConflict[0]).intValue() == CONFLICT_SINGLE_PATH) {
                    message = NLS.bind(Messages.SynchAgainstRequestAction_updRecursive_conflict_messagePath, new Object[] {
                            firstConflict[1], firstConflict[2], firstConflict[3], firstConflict[4], firstConflict[5] });
                } else if (((Integer) firstConflict[0]).intValue() == CONFLICT_SINGLE_ITEM) {
                    message = NLS.bind(Messages.SynchAgainstRequestAction_updRecursive_conflict_messageItem, new Object[] {
                            firstConflict[1], firstConflict[2], firstConflict[3], firstConflict[4], firstConflict[5] });
                }
                MessageBox messageBox = new MessageBox(getShell(), SWT.ICON_WARNING | SWT.ABORT);
                messageBox.setMessage(message);
                messageBox.setText(Messages.SynchAgainstRequestAction_updRecursive_conflict_title);
                messageBox.open();
                return;
            }

            final List<ItemRevision> itemRevisionList = new ArrayList<ItemRevision>();
            final List<IResource> fileList = new ArrayList<IResource>();
            final List<IFolder> folderList = new ArrayList<IFolder>();

            final List<IResource> delFileList = new ArrayList<IResource>();
            final List<IResource> delFolderList = new ArrayList<IResource>();

            final Map<IResource, Integer> fileRevMap = new HashMap<IResource, Integer>();

            IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();

            for (Iterator<String> projIter = wsStructHistoryCheckedMap.keySet().iterator(); projIter.hasNext();) {
                String projectName = projIter.next();
                List<StructureHistoryRec> structureHistoryRecords = wsStructHistoryCheckedMap.get(projectName);

                IProject project = root.getProject(projectName);
                try {
                    IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(project);
                    Iterator<StructureHistoryRec> structHistoryRecIter = structureHistoryRecords.iterator();
                    while (structHistoryRecIter.hasNext()) {
                        StructureHistoryRec record = structHistoryRecIter.next();

                        String itemPathStr = (record.getChangeType() != StructureHistoryRec.DELETION
                                && record.getChangeType() != StructureHistoryRec.RENAME
                                && record.getChangeType() != StructureHistoryRec.MOVE) ? record.getNewPath() : record.getOldPath();
                        if (dmProject.isSccStyle()) { // if contained
                            int ind = itemPathStr.indexOf(projectName);
                            // make relative to the project
                            itemPathStr = itemPathStr.substring(ind + projectName.length() + 1);
                        }

                        if (record.getObjectType() == StructureHistoryRec.ITEM) { // file
                            IResource resource = project.getFile(itemPathStr);

                            if (record.getChangeType() == StructureHistoryRec.DELETION) {
                                // delete old path resource
                                delFileList.add(resource);
                            } else if (record.getChangeType() == StructureHistoryRec.RENAME
                                    || record.getChangeType() == StructureHistoryRec.MOVE) {
                                // delete old path resource
                                delFolderList.add(resource);
                                // get new path
                                String newItemPathStr = record.getNewPath();
                                int ind = record.getNewPath().indexOf(projectName);
                                if (dmProject.isSccStyle()
                                        && (ind > -1 && newItemPathStr.charAt(ind + projectName.length()) == '/')) {
                                    // make relative to the project
                                    newItemPathStr = newItemPathStr.substring(ind + projectName.length() + 1);
                                }

                                try {
                                    // Need to get item revision to get remote file content
                                    ItemRevision itemRevision = ((Project) dmProject.getDimensionsObject())
                                            .createItemRevisionFromSpec(record.getObjectSpec());
                                    Integer savedRev = fileRevMap.get(project.getFile(newItemPathStr));
                                    if (savedRev == null) {
                                        // parallel with itemRevisionList
                                        fileList.add(project.getFile(newItemPathStr));
                                        // parallel with resourceList
                                        itemRevisionList.add(itemRevision);
                                        fileRevMap.put(project.getFile(newItemPathStr), Integer.valueOf(record.getFileVersion()));
                                    } else if (savedRev.intValue() < record.getFileVersion()) {
                                        int delIndex = fileList.indexOf(project.getFile(newItemPathStr));
                                        fileList.remove(delIndex);
                                        itemRevisionList.remove(delIndex);

                                        fileList.add(project.getFile(newItemPathStr));
                                        itemRevisionList.add(itemRevision);
                                        fileRevMap.put(project.getFile(newItemPathStr), Integer.valueOf(record.getFileVersion()));
                                    }
                                } catch (DimensionsRuntimeException e) {
                                    DMTeamUiPlugin.getDefault().handle(e);
                                }
                            } else {
                                // CREATE | MODIFY | IMPORT
                                try {
                                    // Need to get item revision to get remote file content
                                    ItemRevision itemRevision = ((Project) dmProject.getDimensionsObject())
                                            .createItemRevisionFromSpec(record.getObjectSpec());
                                    Integer savedRev = fileRevMap.get(resource);
                                    if (savedRev == null) {
                                        // parallel with itemRevisionList
                                        fileList.add(resource);
                                        // parallel with resourceList
                                        itemRevisionList.add(itemRevision);
                                        fileRevMap.put(resource, Integer.valueOf(record.getFileVersion()));
                                    } else if (savedRev.intValue() < record.getFileVersion()) {
                                        int delIndex = fileList.indexOf(resource);
                                        fileList.remove(delIndex);
                                        itemRevisionList.remove(delIndex);

                                        fileList.add(resource);
                                        itemRevisionList.add(itemRevision);
                                        fileRevMap.put(resource, Integer.valueOf(record.getFileVersion()));
                                    }
                                } catch (DimensionsRuntimeException e) {
                                    DMTeamUiPlugin.getDefault().handle(e);
                                }
                            }
                        } else { // folder
                            IResource resource = project.getFolder(itemPathStr);

                            if (record.getChangeType() == StructureHistoryRec.DELETION) {
                                // delete old path resource
                                delFolderList.add(resource);
                            } else if (record.getChangeType() == StructureHistoryRec.RENAME
                                    || record.getChangeType() == StructureHistoryRec.MOVE) {
                                // delete old path resource
                                delFolderList.add(resource);
                                // get new path
                                String newItemPathStr = record.getNewPath();
                                int ind = record.getNewPath().indexOf(projectName);
                                if (dmProject.isSccStyle()
                                        && (ind > -1 && newItemPathStr.charAt(ind + projectName.length()) == '/')) {
                                    // make relative to the project
                                    newItemPathStr = newItemPathStr.substring(ind + projectName.length() + 1);
                                }
                                // add new path resource
                                folderList.add(project.getFolder(newItemPathStr));
                            } else {
                                // CREATE | IMPORT
                                folderList.add((IFolder) resource);
                            }
                        }
                    }
                } catch (CoreException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
            }

            // Add remote files contents
            if (!itemRevisionList.isEmpty()) {
                // should be parallel
                assert fileList.size() == itemRevisionList.size();
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            // TODO ticks, change the message
                            monitor.beginTask(Messages.ItemRevisionEditHandler_0, 10);
                            try {
                                ItemRevision[] itemRevisions = itemRevisionList.toArray(new ItemRevision[itemRevisionList.size()]);
                                IDMRemoteFile[] remoteFiles = TeamUtils.getVariants(reqAdapter.getConnectionDetails(),
                                        itemRevisions, Utils.subMonitorFor(monitor, 100)); // TODO ticks
                                for (int i = 0; i < remoteFiles.length; i++) {
                                    // Getting file contents, pre-cache
                                    remoteFiles[i].getStorage(Utils.subMonitorFor(monitor, 5));
                                    IResource file = fileList.get(i);
                                    // hack: remote file for renamed resource returns always
                                    // previous name!
                                    IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(file.getProject());
                                    if (dmProject.isSccStyle()) {
                                        remoteFiles[i].updatePath(file.getFullPath().makeRelative());
                                    } else {
                                        remoteFiles[i].updatePath(file.getProjectRelativePath().makeRelative());
                                    }
                                    remoteResourcesMap.put(file, remoteFiles[i]);
                                }
                            } catch (CoreException e) {
                                DMTeamUiPlugin.getDefault().handle(e);
                            } finally {
                                monitor.done();
                            }
                        }
                    });
                } catch (InvocationTargetException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
            }

            if (!folderList.isEmpty()) {
                for (Iterator<IFolder> folderIter = folderList.iterator(); folderIter.hasNext();) {
                    IFolder folder = folderIter.next();
                    try {
                        IDMProject dmProj = DMTeamPlugin.getWorkspace().getProject(folder.getProject());
                        IPath remoteRelativePath = dmProj.getRemotePathForLocalResource(folder);
                        IDMRemoteFolder remoteFolder = TeamUtils.createRemoteFolder(null, remoteRelativePath, dmProj, null);
                        remoteResourcesMap.put(folder, remoteFolder);
                    } catch (CoreException e) {
                        DMTeamUiPlugin.getDefault().handle(e);
                    }
                }
            }

            if (!delFileList.isEmpty()) {
                for (Iterator<IResource> delFileIter = delFileList.iterator(); delFileIter.hasNext();) {
                    remoteResourcesMap.put(delFileIter.next(), null);
                }
            }
            if (!delFolderList.isEmpty()) {
                for (Iterator<IResource> delFolderIter = delFolderList.iterator(); delFolderIter.hasNext();) {
                    remoteResourcesMap.put(delFolderIter.next(), null);
                }
            }
        }

        IProject[] allProjects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
        DMWorkspaceCustomSynchParticipant participant = new DMWorkspaceCustomSynchParticipant(new ResourceScope(allProjects),
                remoteResourcesMap);
        participant.setNameInfo(participantNameInfo.toString());
        TeamUI.getSynchronizeManager().addSynchronizeParticipants(new ISynchronizeParticipant[] { participant });
        participant.refresh(allProjects, Messages.SynchronizeAction_0,
                NLS.bind(Messages.SynchronizeAction_1, participant.getName()), getActivePart().getSite());
    }

    private Map<String, Map<Request, List<StructureHistoryRec>>> loadStructureHistoryForWS(final ChangeDocumentAdapter reqAdapter,
            final List<IDMProject> dmProjects) {
        assert reqAdapter != null;
        final Map<String, Map<Request, List<StructureHistoryRec>>> resultMap = new HashMap<String, Map<Request, List<StructureHistoryRec>>>();
        try {
            IDMProject[] projectsArray = dmProjects.toArray(new IDMProject[dmProjects.size()]);
            Request[] requestsArray = new Request[] { (Request) reqAdapter.getAPIObject() };
            List<String> nonWSProjectSpecs = checkWorksetRelationship(projectsArray, requestsArray);

            if (nonWSProjectSpecs.size() > 0) {
                MessageBox messageBox = new MessageBox(getShell(), SWT.ICON_WARNING | SWT.ABORT);
                String message = nonWSProjectSpecs.size() > 1
                        ? Messages.SynchAgainstRequestAction_nonWSProjects_message2
                        : NLS.bind(Messages.SynchAgainstRequestAction_nonWSProjects_message1, nonWSProjectSpecs.get(0));
                messageBox.setMessage(message);
                messageBox.setText(Messages.SynchAgainstRequestAction_nonWSProjects_title);
                messageBox.open();
                return null;
            }

            Session session = reqAdapter.getConnectionDetails().openSession(Utils.subMonitorFor(new NullProgressMonitor(), 10));
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    for (int i = 0; i < dmProjects.size(); i++) {
                        if (dmProjects.get(i).isBaseline()) {
                            continue;
                        }
                        if (dmProjects.get(i).getIsStream()) {
                            continue;
                        }

                        Project apiProject = (Project) dmProjects.get(i).getDimensionsObject();
                        @SuppressWarnings("unchecked")
                        List<StructureHistoryRec> structureHistory = ((Request) reqAdapter.getAPIObject())
                                .getStructureHistory(apiProject);

                        if (structureHistory != null && !structureHistory.isEmpty()) {
                            Map<Request, List<StructureHistoryRec>> requestStructHistoryRecMap = new HashMap<Request, List<StructureHistoryRec>>();
                            requestStructHistoryRecMap.put((Request) reqAdapter.getAPIObject(), structureHistory);
                            resultMap.put(dmProjects.get(i).getProject().getName(), requestStructHistoryRecMap);
                        }
                    }
                }
            }, new NullProgressMonitor());
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        }
        return resultMap;
    }

    /*
     * Recursive Update From request
     */
    private Map<String, Map<Request, List<StructureHistoryRec>>> loadStructureHistoryForWS(Session session,
            final Request[] requests, final List<IDMProject> dmProjects) {
        assert session != null;
        assert requests != null;
        final Map<String, Map<Request, List<StructureHistoryRec>>> resultMap = new HashMap<String, Map<Request, List<StructureHistoryRec>>>();
        try {

            IDMProject[] projectsArray = dmProjects.toArray(new IDMProject[dmProjects.size()]);
            List<String> nonWSProjectSpecs = checkWorksetRelationship(projectsArray, requests);

            if (nonWSProjectSpecs.size() > 0) {
                MessageBox messageBox = new MessageBox(getShell(), SWT.ICON_WARNING | SWT.ABORT);
                String message = nonWSProjectSpecs.size() > 1
                        ? Messages.SynchAgainstRequestAction_nonWSProjects_message2
                        : NLS.bind(Messages.SynchAgainstRequestAction_nonWSProjects_message1, nonWSProjectSpecs.get(0));
                messageBox.setMessage(message);
                messageBox.setText(Messages.SynchAgainstRequestAction_nonWSProjects_title);
                messageBox.open();
                return null;
            }

            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    for (int i = 0; i < dmProjects.size(); i++) {
                        if (dmProjects.get(i).isBaseline()) {
                            continue;
                        }
                        if (dmProjects.get(i).getIsStream()) {
                            continue;
                        }
                        for (int j = 0; j < requests.length; j++) {
                            Project apiProject = (Project) dmProjects.get(i).getDimensionsObject();
                            @SuppressWarnings("unchecked")
                            List<StructureHistoryRec> structureHistory = requests[j].getStructureHistory(apiProject);

                            if (structureHistory != null && !structureHistory.isEmpty()) {
                                Map<Request, List<StructureHistoryRec>> requestStructHistoryRecMap = resultMap
                                        .get(dmProjects.get(i).getProject().getName());
                                if (requestStructHistoryRecMap == null) {
                                    requestStructHistoryRecMap = new HashMap<Request, List<StructureHistoryRec>>();
                                    resultMap.put(dmProjects.get(i).getProject().getName(), requestStructHistoryRecMap);
                                }
                                requestStructHistoryRecMap.put(requests[j], structureHistory);
                            }
                        }
                    }
                }
            }, new NullProgressMonitor());
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        }
        return resultMap;
    }

    /*
     * Get request hierarchy recursively
     */
    private HashSet<Request> getChildChdocsRecursively(DimensionsArObject parentChdoc, HashSet<Request> childChdocs) {
        assert childChdocs != null;
        assert parentChdoc != null;
        // flush the cache
        parentChdoc.flushRelatedObjects(Request.class, true);
        @SuppressWarnings("unchecked")
        List<DimensionsRelatedObject> relatedObjects = parentChdoc.getChildRequests(null);
        parentChdoc.flushRelatedObjects(Request.class, true);

        for (int i = 0; i < relatedObjects.size(); i++) {
            DimensionsRelatedObject relObject = relatedObjects.get(i);
            Request request = (Request) relObject.getObject();
            if (request != null && childChdocs.add(request)) {
                // no duplicates, use admBaseId to check on duplication
                getChildChdocsRecursively(request, childChdocs);
            }
        }
        return childChdocs;
    }

    private List<Object[]> checkStructureHistory(Map<String, Map<Request, List<StructureHistoryRec>>> wsStructHistoryMapIn,
            Map<String, List<StructureHistoryRec>> wsStructHistoryMapOut) {
        assert wsStructHistoryMapIn != null;
        assert wsStructHistoryMapOut != null;
        List<Object[]> result = new ArrayList<Object[]>();

        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        for (Iterator<String> projIter = wsStructHistoryMapIn.keySet().iterator(); projIter.hasNext();) {
            String projectName = projIter.next();
            IProject project = root.getProject(projectName);
            IDMProject dmProject = null;
            try {
                dmProject = DMTeamPlugin.getWorkspace().getProject(project);
            } catch (CoreException e) {
                DMTeamUiPlugin.getDefault().handle(e);
                continue;
            }

            // Inside a project find paths covered twice and more in different requests on CREATE |
            // IMPORT | MODIFY, check if this a conflict find refactoring of the same item in different
            // requests (RENAME | MOVE), mark this as a conflict

            // newPath -> Object[]{Request, StructureHistoryRec}
            Map<String, Object[]> coveredPaths = new HashMap<String, Object[]>();
            // itemSpecUid -> Object[]{Request, StructureHistoryRec}
            Map<String, Object[]> itemRenMoves = new HashMap<String, Object[]>();

            Map<Request, List<StructureHistoryRec>> requestStructHistoryMap = wsStructHistoryMapIn.get(projectName);
            for (Iterator<Request> reqIter = requestStructHistoryMap.keySet().iterator(); reqIter.hasNext();) {
                Request request = reqIter.next();

                List<StructureHistoryRec> structureHistory = requestStructHistoryMap.get(request);
                for (Iterator<StructureHistoryRec> structHRecIter = structureHistory.iterator(); structHRecIter.hasNext();) {
                    StructureHistoryRec record = structHRecIter.next();

                    if (record.getChangeType() == StructureHistoryRec.CREATE || record.getChangeType() == StructureHistoryRec.MODIFY
                            || record.getChangeType() == StructureHistoryRec.IMPORT) {
                        String keyPath = record.getNewPath();
                        Object[] requestRecPair = coveredPaths.get(keyPath);
                        if (requestRecPair != null) {
                            StructureHistoryRec prevRecord = (StructureHistoryRec) requestRecPair[1];
                            ItemMetadata itemMD1 = new ItemMetadata();
                            itemMD1.setItemUid(prevRecord.getItemUid());
                            ItemMetadata itemMD2 = new ItemMetadata();
                            itemMD2.setItemUid(record.getItemUid());
                            ItemMetadata[] itemMDResult = null;
                            try {
                                itemMDResult = ((Project) dmProject.getDimensionsObject())
                                        .syncQueryItemInfo(new ItemMetadata[] { itemMD1 }, new ItemMetadata[] { itemMD2 });
                            } catch (DMException e) {
                                DMTeamUiPlugin.getDefault().handle(e);
                            }
                            if (itemMDResult != null && itemMDResult[0].getItemUid() == prevRecord.getItemUid()) {
                                // if returned ancestor is previously added item - new item is the latest modification
                                coveredPaths.put(keyPath, new Object[] { request, record });
                            } else if (itemMDResult != null && itemMDResult[0].getItemUid() == record.getItemUid()) {
                                // if returned ancestor is new item - the latest modification was added previously
                                // take in account the first covered
                                continue;
                            } else {
                                // contains another common ancestor UID - mark as conflict
                                Object[] conflictValues = new Object[6];
                                // type of conflict: 0 - single-path conflict, 1 - single-item conflict
                                conflictValues[0] = new Integer(CONFLICT_SINGLE_PATH);
                                conflictValues[1] = keyPath;
                                conflictValues[2] = prevRecord.getObjectSpec();
                                conflictValues[3] = record.getObjectSpec();
                                conflictValues[4] = ((Request) requestRecPair[0]).getName();
                                conflictValues[5] = request.getName();
                                result.add(conflictValues);
                                return result;
                            }
                        } else {
                            // just cover this
                            coveredPaths.put(keyPath, new Object[] { request, record });
                        }
                    } else if (record.getObjectType() == StructureHistoryRec.ITEM
                            && (record.getChangeType() == StructureHistoryRec.RENAME
                                    || record.getChangeType() == StructureHistoryRec.MOVE)) {
                        Object[] requestRecPair = itemRenMoves.get(String.valueOf(record.getItemSpecUid()));
                        if (requestRecPair != null) {
                            StructureHistoryRec prevRecord = (StructureHistoryRec) requestRecPair[1];
                            Object[] conflictValues = new Object[6];
                            // type of conflict: 0 - single-path conflict, 1 - single-item conflict
                            conflictValues[0] = new Integer(CONFLICT_SINGLE_ITEM);
                            conflictValues[1] = record.getObjectSpec().substring(0, record.getObjectSpec().indexOf(';'));
                            conflictValues[2] = prevRecord.getNewPath();
                            conflictValues[3] = record.getNewPath();
                            conflictValues[4] = ((Request) requestRecPair[0]).getName();
                            conflictValues[5] = request.getName();
                            result.add(conflictValues);
                            return result;
                        } else {
                            itemRenMoves.put(String.valueOf(record.getItemSpecUid()), new Object[] { request, record });
                        }
                    } else {
                        List<StructureHistoryRec> recList = wsStructHistoryMapOut.get(projectName);
                        if (recList == null) {
                            recList = new ArrayList<StructureHistoryRec>();
                            wsStructHistoryMapOut.put(projectName, recList);
                        }
                        recList.add(record);
                    }
                }
            }

            List<StructureHistoryRec> recList = wsStructHistoryMapOut.get(projectName);
            if (recList == null) {
                recList = new ArrayList<StructureHistoryRec>();
                wsStructHistoryMapOut.put(projectName, recList);
            }
            // add modification records
            for (Iterator<Object[]> objArrIter = coveredPaths.values().iterator(); objArrIter.hasNext();) {
                Object[] requestRecPair = objArrIter.next();
                recList.add((StructureHistoryRec) requestRecPair[1]);
            }
            // add renames/moves records
            for (Iterator<Object[]> objArrIter = itemRenMoves.values().iterator(); objArrIter.hasNext();) {
                Object[] requestRecPair = objArrIter.next();
                recList.add((StructureHistoryRec) requestRecPair[1]);
            }

        }

        return result;
    }

    private void arrangeStructureHistory(Map<String, Map<Request, List<StructureHistoryRec>>> wsStructHistoryMapIn,
            Map<String, Map<Request, List<StructureHistoryRec>>> wsStructHistoryMapOut) {
        assert wsStructHistoryMapIn != null;
        assert wsStructHistoryMapOut != null;
        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        for (Iterator<String> projIter = wsStructHistoryMapIn.keySet().iterator(); projIter.hasNext();) {
            String projectName = projIter.next();
            IProject project = root.getProject(projectName);
            IDMProject dmProject = null;
            try {
                dmProject = DMTeamPlugin.getWorkspace().getProject(project);
            } catch (CoreException e) {
                DMTeamUiPlugin.getDefault().handle(e);
                continue;
            }

            // ----------- requests iterator
            Map<Request, List<StructureHistoryRec>> requestStructHistoryMap = wsStructHistoryMapIn.get(projectName);
            for (Iterator<Request> reqIter = requestStructHistoryMap.keySet().iterator(); reqIter.hasNext();) {
                Request request = reqIter.next();

                Map<String, StructureHistoryRec> fileRecordsMap = new HashMap<String, StructureHistoryRec>();
                Map<String, StructureHistoryRec> folderRecordsMap = new HashMap<String, StructureHistoryRec>();
                Map<String, StructureHistoryRec[]> fileRecordsRMMap = new HashMap<String, StructureHistoryRec[]>();
                List<StructureHistoryRec> recordsRMList = new ArrayList<StructureHistoryRec>();

                // --------- structure history records iterator
                List<StructureHistoryRec> structureHistory = requestStructHistoryMap.get(request);
                for (Iterator<StructureHistoryRec> structHRecIter = structureHistory.iterator(); structHRecIter.hasNext();) {
                    StructureHistoryRec record = structHRecIter.next();

                    // check #1: for contained projects - does StructureHistoryRec item really
                    // belong to the project container ?
                    String itemPathToCheck = (record.getChangeType() != StructureHistoryRec.DELETION
                            && record.getChangeType() != StructureHistoryRec.RENAME
                            && record.getChangeType() != StructureHistoryRec.MOVE) ? record.getNewPath() : record.getOldPath();
                    int ind = -1;
                    if (dmProject.isSccStyle() && !((ind = itemPathToCheck.indexOf(projectName)) > -1
                            && itemPathToCheck.charAt(ind + projectName.length()) == '/')) {
                        continue;
                    }

                    // check #2: these events deal with only single path, we need to get the latest
                    // one as it images actual state in repository
                    // valid for files and folders both
                    if (record.getChangeType() == StructureHistoryRec.CREATE || record.getChangeType() == StructureHistoryRec.MODIFY
                            || record.getChangeType() == StructureHistoryRec.DELETION
                            || record.getChangeType() == StructureHistoryRec.IMPORT) {

                        if (record.getObjectType() == StructureHistoryRec.ITEM) {
                            String itemSpecUid = String.valueOf(record.getItemSpecUid());
                            if (fileRecordsMap.containsKey(itemSpecUid)) {
                                StructureHistoryRec prevRecord = fileRecordsMap.get(itemSpecUid);
                                // save the latest modification
                                if (compareStructRecTime(prevRecord, record) < 0) {
                                    fileRecordsMap.put(itemSpecUid, record);
                                }
                            } else {
                                fileRecordsMap.put(itemSpecUid, record);
                            }
                        } else {
                            // Save the latest folder modification
                            String keyPath = (record.getChangeType() == StructureHistoryRec.DELETION)
                                    ? record.getOldPath() : record.getNewPath();
                            if (!folderRecordsMap.containsKey(keyPath)
                                    || compareStructRecTime(folderRecordsMap.get(keyPath), record) < 0) {
                                folderRecordsMap.put(keyPath, record);
                            }
                        }
                    } else if (record.getChangeType() == StructureHistoryRec.RENAME
                            || record.getChangeType() == StructureHistoryRec.MOVE) {

                        // check #3: filter out the last rename/move of the resource
                        if (record.getObjectType() == StructureHistoryRec.ITEM) {
                            String itemSpecUid = String.valueOf(record.getItemSpecUid());
                            if (fileRecordsRMMap.containsKey(itemSpecUid)) {
                                StructureHistoryRec[] savedRecords = fileRecordsRMMap.get(itemSpecUid);
                                // Find the last with existing old path
                                boolean oldPathExists = isExistsInDMProject(dmProject, record.getOldPath());
                                if (savedRecords[0] != null && oldPathExists) {
                                    if (compareStructRecTime(savedRecords[0], record) < 0) {
                                        savedRecords[0] = record;
                                    }
                                } else if (oldPathExists) {
                                    savedRecords[0] = record;
                                }
                                // Find the last rename/move
                                if (compareStructRecTime(savedRecords[1], record) < 0) {
                                    savedRecords[1] = record;
                                }

                            } else {
                                StructureHistoryRec fromExRecord = isExistsInDMProject(dmProject, record.getOldPath())
                                        ? record : null;
                                fileRecordsRMMap.put(itemSpecUid, new StructureHistoryRec[] { fromExRecord, record });
                            }
                        } else {
                            // Don't handle move/rename of folders in special way, just add
                            recordsRMList.add(record);
                        }
                    }

                } // --------- structure history records iterator

                // Post-handling of rename/move: create StructureHistoryRec with existing old path
                // and final change
                // Select the latest one from events
                for (Iterator<String> itemSpecUidIter = fileRecordsRMMap.keySet().iterator(); itemSpecUidIter.hasNext();) {
                    String itemSpecUid = itemSpecUidIter.next();
                    StructureHistoryRec[] savedRecords = fileRecordsRMMap.get(itemSpecUid);
                    // New record contains the latest existing in ws path and the last new path
                    StructureHistoryRec newRecord = new StructureHistoryRec(savedRecords[1].getProjUid(),
                            savedRecords[1].getChangeType(), savedRecords[1].getObjectType(), savedRecords[1].getItemSpecUid(),
                            savedRecords[1].getUserUid(), savedRecords[1].getObjectSpec(),
                            savedRecords[0] != null ? savedRecords[0].getOldPath() : savedRecords[1].getOldPath(),
                            savedRecords[1].getNewPath(), savedRecords[1].getUser(), savedRecords[1].getUpdateTime(),
                            savedRecords[1].getStageId(), savedRecords[1].getItemUid(), savedRecords[1].getFileVersion(),
                            savedRecords[1].getIsExtracted());

                    StructureHistoryRec recToCheck = fileRecordsMap.get(itemSpecUid);
                    if (recToCheck != null) {
                        if (recToCheck.getChangeType() == StructureHistoryRec.CREATE
                                || recToCheck.getChangeType() == StructureHistoryRec.IMPORT) {
                            // Delete this event as it should be superseded with later rename/move
                            // event
                            fileRecordsMap.remove(itemSpecUid);
                            recordsRMList.add(newRecord);
                        } else if (recToCheck.getChangeType() == StructureHistoryRec.DELETION) {
                            // We don't want to rename, we just want to delete existing in ws
                            // resource
                            StructureHistoryRec delRecord = new StructureHistoryRec(recToCheck.getProjUid(),
                                    recToCheck.getChangeType(), recToCheck.getObjectType(), recToCheck.getItemSpecUid(),
                                    recToCheck.getUserUid(), recToCheck.getObjectSpec(), newRecord.getOldPath(),
                                    recToCheck.getNewPath(), recToCheck.getUser(), recToCheck.getUpdateTime(),
                                    recToCheck.getStageId(), recToCheck.getItemUid(), recToCheck.getFileVersion(),
                                    recToCheck.getIsExtracted());
                            fileRecordsMap.put(itemSpecUid, delRecord);
                        } else if (recToCheck.getChangeType() == StructureHistoryRec.MODIFY) {
                            // Disregard modifications on the old path i.e. before rename/move
                            if (compareStructRecTime(recToCheck, newRecord) < 0) {
                                fileRecordsMap.remove(itemSpecUid);
                            }
                            recordsRMList.add(newRecord);
                        }
                    } else {
                        recordsRMList.add(newRecord);
                    }
                }

                List<StructureHistoryRec> strucHistoryRecords = new ArrayList<StructureHistoryRec>();
                strucHistoryRecords.addAll(fileRecordsMap.values());
                strucHistoryRecords.addAll(folderRecordsMap.values());
                strucHistoryRecords.addAll(recordsRMList);

                Map<Request, List<StructureHistoryRec>> reqStructHistory = wsStructHistoryMapOut.get(projectName);
                if (reqStructHistory == null) {
                    reqStructHistory = new HashMap<Request, List<StructureHistoryRec>>();
                }
                reqStructHistory.put(request, strucHistoryRecords);
                wsStructHistoryMapOut.put(projectName, reqStructHistory);

            } // ----------- requests iterator

        } // ----------- projects iterator
    }

    protected int compareStructRecTime(StructureHistoryRec record1, StructureHistoryRec record2) {
        assert record1 != null;
        assert record2 != null;

        int result = 0;
        try {
            if (DimensionsUtils.parseDate(record1.getUpdateTime()).getTime() < DimensionsUtils.parseDate(record2.getUpdateTime())
                    .getTime()) {
                result = -1;
            } else if (DimensionsUtils.parseDate(record1.getUpdateTime()).getTime() > DimensionsUtils
                    .parseDate(record2.getUpdateTime()).getTime()) {
                result = 1;
            }
        } catch (ParseException e) {
            // last resort
            if (record1.getFileVersion() < record2.getFileVersion()) {
                result = -1;
            } else if (record1.getFileVersion() > record2.getFileVersion()) {
                result = 1;
            }
        }
        return result;
    }

    protected boolean isExistsInDMProject(IDMProject dmProject, String path) {
        IProject project = dmProject.getProject();
        if (dmProject.isSccStyle()) {
            int ind = path.indexOf(project.getName());
            if (ind > -1 && path.charAt(ind + project.getName().length()) == '/') {
                path = path.substring(ind + project.getName().length() + 1);
            }
        }
        return project.exists(new Path(path));
    }

    private List<String> checkWorksetRelationship(IDMProject[] dmProjects, Request[] requests) {
        assert requests != null;
        assert dmProjects != null;
        List<String> nonWSProjectSpecs = new ArrayList<String>();

        for (int i = 0; i < requests.length; i++) {
            Request request = requests[i];
            // flush the cache
            request.flushRelatedObjects(Project.class, true);
            @SuppressWarnings("unchecked")
            List<DimensionsRelatedObject> relatedObjects = request.getParentProjects(null);
            request.flushRelatedObjects(Project.class, true);
            if (relatedObjects != null && relatedObjects.size() > 0) {
                Project relProject = (Project) relatedObjects.get(0).getObject();
                boolean projectInWS = false;
                for (int j = 0; j < dmProjects.length; j++) {
                    try {
                        // exists in ws
                        if (dmProjects[j].getDimensionsObject().equals(relProject)) {
                            projectInWS = true;
                            break;
                        }
                    } catch (Exception e) {
                    }
                }
                if (!projectInWS && !nonWSProjectSpecs.contains(relProject.getName())) {
                    nonWSProjectSpecs.add(relProject.getName());
                }
            }
        }

        return nonWSProjectSpecs;
    }
}

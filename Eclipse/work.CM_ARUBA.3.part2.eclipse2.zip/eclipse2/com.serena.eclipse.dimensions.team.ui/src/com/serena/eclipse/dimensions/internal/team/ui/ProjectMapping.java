/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import java.io.File;

import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Associates workset or baseline with local project name.
 *
 * @author V.Grishchenko
 */
public class ProjectMapping {

    private VersionManagementProject remoteProject;
    private String ideProjectName;
    private IProjectDescription projectDescription;

    private String localProjectName;
    private boolean localNameAdjusted;
    private IPath workAreaRoot; // Empty for partial work area for a full

    /**
     * Creates a new mapping.
     *
     * @param remoteProject remote project
     * @param ideProjectName ide project name remote project property or <code>null</code> if none
     * @param projectDescription description or <code>null</code> if none
     */
    public ProjectMapping(VersionManagementProject remoteProject, String ideProjectName, IProjectDescription projectDescription,
            IPath workAreaRoot) {
        Assert.isNotNull(remoteProject);
        this.remoteProject = remoteProject;
        this.ideProjectName = ideProjectName;
        this.projectDescription = projectDescription;
        if (workAreaRoot == null || workAreaRoot == Path.EMPTY) {
            this.workAreaRoot = Path.EMPTY;
        } else {
            this.workAreaRoot = workAreaRoot;
        }

        // init local name
        String basedOnName = null;
        if (projectDescription != null) {
            basedOnName = projectDescription.getName();
        } else if (!Utils.isNullEmpty(ideProjectName)) {
            basedOnName = ideProjectName;// TeamUtils.toValidResourceName(ideTag, null);
        } else {
            basedOnName = (String) remoteProject.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
        }
        if (!Utils.isNullEmpty(basedOnName)) {
            localProjectName = TeamUtils.toValidResourceName(basedOnName, null);
            localNameAdjusted = !localProjectName.equals(basedOnName);
        }
    }

    /**
     * @return <code>true</code> if contained local project is valid
     */
    public boolean isLocalProjectNameValid() {
        return validateLocalProjectName().isOK();
    }

    /**
     * @return validation status for local project name
     * @see org.eclipse.core.resources.IWorkspace#validateName(java.lang.String, int)
     */
    public IStatus validateLocalProjectName() {
        return ResourcesPlugin.getWorkspace().validateName(localProjectName, IResource.PROJECT);
    }

    /**
     * @return <code>true</code> if local project name was somehow adjusted
     *         during mapping creation to make it valid for this platform
     */
    public boolean isLocalNameAdjusted() {
        return localNameAdjusted;
    }

    /**
     * @return project name for the project in the local workspace
     */
    public String getLocalProjectName() {
        return localProjectName;
    }

    /**
     * @return <code>SystemAttributes.OBJECT_SPEC</code>
     */
    public String getRemoteProjectName() {
        return remoteProject.getProjectSpec();
    }

    /**
     * Sets local project name
     */
    public void setLocalProjectName(String localProjectName) {
        this.localProjectName = localProjectName;
    }

    /**
     * @return the remoteProject.
     */
    public VersionManagementProject getRemoteProject() {
        return remoteProject;
    }

    /**
     * @return project description or <code>null</code> if none
     */
    public IProjectDescription getProjectDescription() {
        return projectDescription;
    }

    /**
     * @return IDE project name remote project property or <code>null</code> if none
     */
    public String getIdeProjectName() {
        return ideProjectName;
    }

    public IPath getWorkAreaRoot() {
        return workAreaRoot;
    }

    public void setWorkAreaRoot(IPath workAreaRoot) {
        this.workAreaRoot = workAreaRoot;
    }

    /**
     * Creates a new proper mapping for the specified remote project.
     *
     * @param remoteProject
     * @param monitor
     * @return
     */
    public static ProjectMapping createProjectMapping(VersionManagementProject remoteProject, IProgressMonitor monitor)
            throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100);
        try {
            IDMProject project = DMRepositoryProvider.createProject(remoteProject, null, null);
            monitor.worked(50);
            String ideProjectName = project.getIdeProjectName();
            IProjectDescription projectDescription = null;

            try {
                File tmpFile = project.getTempCopy(
                        project.getRemotePathForLocalPath(new Path(IProjectDescription.DESCRIPTION_FILE_NAME)),
                        Utils.subMonitorFor(monitor, 50));

                if (tmpFile != null) {
                    try {
                        projectDescription = ResourcesPlugin.getWorkspace().loadProjectDescription(
                                new Path(tmpFile.getAbsolutePath()));
                        projectDescription.setLocation(null);
                        if (Utils.isNullEmpty(projectDescription.getName())) {
                            projectDescription = null;
                        }
                    } finally {
                        tmpFile.delete();
                    }
                }
            } catch (CoreException e) {
                DMTeamUiPlugin.log(e.getStatus()); // silently ignore and log
            }
            return new ProjectMapping(remoteProject, ideProjectName, projectDescription, Path.EMPTY);
        } finally {
            monitor.done();
        }
    }

    /**
     * @param mappings list of mappings to check
     * @return true if all projects are from the same project/stream/baseline
     */
    public static boolean compatibleProjects(ProjectMapping[] mappings) {
        // are they all from the same project
        boolean allSameContainer = true;
        VersionManagementProject vmpToCheck = null;
        for (int i = 0; i < mappings.length; i++) {

            if (!(mappings[i].remoteProject instanceof SccProject)) {
                // only SCC projects
                allSameContainer = false;
                break;
            }
            if (vmpToCheck == null) {
                vmpToCheck = mappings[i].remoteProject;
                continue;
            }
            if (!vmpToCheck.getParentAdapter().equals(mappings[i].remoteProject.getParentAdapter())) {
                allSameContainer = false;
            }
        }
        return allSameContainer;
    }

    // set work area root on all mappings
    public static void updateMappings(ProjectMapping[] mappings, IPath newWorkArea) {
        for (ProjectMapping proj : mappings) {
            proj.setWorkAreaRoot(newWorkArea);
        }
    }

}

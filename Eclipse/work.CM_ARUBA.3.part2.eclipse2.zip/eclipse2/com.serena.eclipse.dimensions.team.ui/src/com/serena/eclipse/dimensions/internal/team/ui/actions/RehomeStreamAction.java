package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;

import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.RehomeCommand;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.RehomeStreamDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.WizardHelper;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class RehomeStreamAction extends DMTeamAction {
	
	@Override
	protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
		IDMProject selectedProject = null;
		IDMProject[] workspaceProjects = null;
		RehomeStreamDialog dialog = null;

		try {
			for (IProject project : getSelectedResourcesProjects()) {
				IDMWorkspaceResource dmResource = DMTeamPlugin.getWorkspace().getWorkspaceResource(project);
				workspaceProjects = DMTeamPlugin.getWorkspace().getProjects();
				selectedProject = dmResource.getProject();
				break;
			}
			
			dialog = new RehomeStreamDialog(UIUtils.findShell(), selectedProject, workspaceProjects);
		
		} catch (CoreException e) {
			DMTeamUiPlugin.getDefault().handle(e, getShell());
			return;
		}

		if (dialog.open() == Window.OK) {
			final WorksetAdapter target = new WorksetAdapter(dialog.getTargetProject(),
					selectedProject.getConnection());
			final List<IDMProject> projectsToRehome = dialog.getProjectsToRehome();
			try {
				new ProgressMonitorDialog(UIUtils.findShell()).run(true, true, new IRunnableWithProgress() {

					@Override
					public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
						try {
							RehomeCommand command = new RehomeCommand(projectsToRehome, target);
							command.run(monitor);
						} catch (CoreException e) {
							DMTeamUiPlugin.getDefault().handle(e, UIUtils.findShell());
						}
					}
				});
			} catch (InvocationTargetException e) {
				DMTeamUiPlugin.getDefault().handle(e, UIUtils.findShell());
				throw new OperationCanceledException();
			} catch (InterruptedException e) {
				return;
			}

			WizardHelper.rehomeWorkspaceProjects(projectsToRehome, target);
		}
	}
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.CheckoutRequest;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.Option;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.IPromptCondition;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.PromptingDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.CheckoutHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.CheckoutWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class CheckoutOperation extends WizardOperation {
    private boolean validatingEdit;

    public CheckoutOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    public void setValidatingEdit(boolean validatingEdit) {
        this.validatingEdit = validatingEdit;
    }

    @Override
    protected ISchedulingRule getSchedulingRule(DMRepositoryProvider provider) throws CoreException {
        if (validatingEdit) {
            return null; // avoid conflicts with validate edit rules
        }
        return super.getSchedulingRule(provider);
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind(Messages.CheckoutOperation_taskNameProvider, provider.getProject().getName());
    }

    @Override
    protected String getTaskName() {
        return Messages.CheckoutOperation_taskName;
    }

    @Override
    protected void execute(OperationData data, IProgressMonitor monitor) throws CoreException, InterruptedException {
        WorkspaceResourceRequest[] requests = data.getRequestsArray();

        if (data.getRequests() == null || data.getRequests().size() == 0) {
            return;
        }

        final ArrayList<IResource> excludedModified = new ArrayList<IResource>();
        final ArrayList<IResource> excludedExtracted = new ArrayList<IResource>();

        for (int i = 0; i < requests.length; i++) {
            IDMWorkspaceFile dmFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace()
                    .getWorkspaceResource(requests[i].getResource());
            if (dmFile != null && dmFile.isModified()) {
                excludedModified.add(requests[i].getResource());
            }
            if (dmFile != null && dmFile.getRemoteFile().isAnyExtracted()) {
                excludedExtracted.add(requests[i].getResource());
            }
        }

        HashSet<IResource> excludedResources = new HashSet<IResource>();
        processModified(excludedModified);
        excludedResources.addAll(excludedModified);
        excludedExtracted.removeAll(excludedModified); // do not prompt again if already excluded
        processExtracted(excludedExtracted);
        excludedResources.addAll(excludedExtracted);

        ArrayList<WorkspaceResourceRequest> checkoutRequests = new ArrayList<WorkspaceResourceRequest>(requests.length
                - excludedResources.size());
        for (int i = 0; i < requests.length; i++) {
            if (!excludedResources.contains(requests[i].getResource())) {
                checkoutRequests.add(requests[i]);
            }
        }

        CheckoutRequest[] checkoutReqs = checkoutRequests.toArray(new CheckoutRequest[checkoutRequests.size()]);
        CheckoutHelper myHelper = (CheckoutHelper) getHelper();
        Option.Value expandSubstVars = myHelper.getSelectedValue(CheckoutHelper.EXPAND_SUBST_VARS);
        if (Option.YES.equals(expandSubstVars)) {
            for (int i = 0; i < checkoutReqs.length; i++) {
                checkoutReqs[i].setExpandSubstVars(true);
            }
        }
        data.getProject().checkout(checkoutReqs, monitor);
    }

    // reduces modified resources to those to actually exclude
    private void processModified(List<IResource> modifiedResources) throws InterruptedException {
        if (modifiedResources.isEmpty()) {
            return; // nothing to do
        }
        CheckoutHelper myHelper = (CheckoutHelper) getHelper();
        Option.Value overwriteChanges = myHelper.getSelectedValue(CheckoutHelper.OVERWRITE);
        if (Option.NO.equals(overwriteChanges)) {
            return; // exclude all modified
        } else if (Option.PROMPT.equals(overwriteChanges)) {
            IResource[] dirtyArray = modifiedResources.toArray(new IResource[modifiedResources.size()]);
            PromptingDialog prompt = new PromptingDialog(getShell(), dirtyArray,
                    DMTeamUiPlugin.getOverwriteLocalChangesPrompt(dirtyArray), Messages.confirm_overwrite, false, 0);
            modifiedResources.removeAll(Arrays.asList(prompt.promptForMultiple()));
        } else if (Option.YES.equals(overwriteChanges)) {
            modifiedResources.clear(); // overwrite all
        } else {
            // shouldn't get here but if it does it is safe to exclude all
        }
    }

    // reduces extracted resources to those to actually exclude
    private void processExtracted(final List<IResource> extractedResources) throws InterruptedException {
        if (extractedResources.isEmpty()) {
            return; // nothing to do
        }
        CheckoutHelper myHelper = (CheckoutHelper) getHelper();
        Option.Value parallelExtract = myHelper.getSelectedValue(CheckoutHelper.CONCURRENT_CHECKOUT);
        if (Option.NO.equals(parallelExtract)) {
            return; // exclude all extracted
        } else if (Option.PROMPT.equals(parallelExtract)) {
            IPromptCondition condition = new IPromptCondition() {
                @Override
                public boolean needsPrompt(IResource resource) {
                    return true;
                }

                @Override
                public String promptMessage(IResource resource) {
                    return NLS.bind(Messages.CheckoutOperation_concurrentCheckoutPrompt, resource.getName());
                }
            };
            PromptingDialog prompt = new PromptingDialog(getShell(),
                    extractedResources.toArray(new IResource[extractedResources.size()]), condition,
                    Messages.CheckoutOperation_concurrentCheckoutPromptTitle, false, 0);
            extractedResources.removeAll(Arrays.asList(prompt.promptForMultiple()));
        } else if (Option.YES.equals(parallelExtract)) {
            extractedResources.clear(); // checkout all
        } else {
            // shouldn't get here but if it does it is safe to exclude all
        }
    }

    /**
     * Controls whether remote state should be refreshed prior to
     * checkout in order to get the most current latest revision data.
     * By default the state is refreshed if not validating edit.
     *
     * @return <code>true</code> if remote state has to be refreshed
     *         prior to running the operation, returns <code>false</code> otherwise
     */
    protected boolean needRefresh() {
        // will checkout base when validating - no need to update remote info
        return !validatingEdit;
    }

    @Override
    protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            // need to refresh workspace status to get the latest info in,
            // but even refreshing here is no guarantee that we will checkout
            // latest as there is no such concepts in dmclient (dimensions in general?)
            if (needRefresh()) {
                DMTeamPlugin.getWorkspace()
                        .getSubscriber()
                        .refresh(getResources(), IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, 500));
            }
            // Note: it is safer to checkout base revisions as opposed to latest when validating edit to avoid
            // overwriting changes present in the repository:
            // * workspace has rev 1
            // * remote has rev 2
            // * when validating 2 is checked out and potentially immediately overwritten with contents buffered
            // from rev1 - changes in 2 are not in the latest after a subsequent checkin
            return new CheckoutHelper(getResources(), getFilter(), validatingEdit, Utils.subMonitorFor(monitor, 500));
        } finally {
            monitor.done();
        }
    }

    @Override
    protected TeamOperationWizard createWizard(TeamOperationWizardHelper helper) {
        return new CheckoutWizard((CheckoutHelper) helper);
    }

}

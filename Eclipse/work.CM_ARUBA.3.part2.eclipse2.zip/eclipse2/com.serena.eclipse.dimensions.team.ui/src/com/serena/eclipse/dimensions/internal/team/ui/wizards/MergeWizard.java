/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMMergeSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.ProjectMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMBaseCompareParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMMergeParticipant;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Guides trough the selection of merge source and the common ancestor baseline.
 *
 * @author V.Grishchenko
 */
public class MergeWizard extends DimensionsWizard {
    private static final String SELECT_SOURCE_PAGE = "select_src_page"; //$NON-NLS-1$
    private static final String SELECT_ANCESTOR_PAGE = "select_anc_page"; //$NON-NLS-1$
    private static final String SUMMARY_PAGE = "summary_page"; //$NON-NLS-1$

    private VersionManagementProject target;
    private IProject localTarget;
    private IResource[] resources;
    private boolean pin;

    private ProjectSelectionPage selectSourcePage;
    private ProjectSelectionPage selectAncestorPage;
    private MergeSummaryPage summaryPage;

    private VersionManagementProject ancestor;
    private VersionManagementProject source;

    private IPath defaultOffset;

    public MergeWizard(VersionManagementProject target, IProject localTarget, IResource[] resources, boolean pin) {
        Assert.isNotNull(localTarget);
        Assert.isNotNull(target);
        this.target = target;
        this.localTarget = localTarget;
        this.resources = resources;
        this.pin = pin;
        setWindowTitle(NLS.bind(Messages.MergeWizard_title, localTarget.getName()));
        setNeedsProgressMonitor(true);
    }

    /**
     * Sets scc offset used when preselecting an scc project from a found project
     * or baseline.
     * @param defaultOffset The defaultOffset to set.
     */
    public void setDefaultOffset(IPath defaultOffset) {
        this.defaultOffset = defaultOffset;
    }

    @Override
    public void addPages() {
        selectSourcePage = new ProjectSelectionPage(SELECT_SOURCE_PAGE, Messages.MergeWizard_selectSrcPageTitle,
                Messages.MergeWizard_selectSrcPageDesc, DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), false,
                false);
        selectSourcePage.setAllowBaselines(true);
        selectSourcePage.setAllowWorksets(true);
        selectSourcePage.setAllowNull(false);
        selectSourcePage.setConnection(target.getConnectionDetails());
        selectSourcePage.setDefaultOffset(defaultOffset);
        addPage(selectSourcePage);

        selectAncestorPage = new ProjectSelectionPage(SELECT_ANCESTOR_PAGE, Messages.MergeWizard_selectAncPageTitle,
                Messages.MergeWizard_selectAncPageDesc, DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), false,
                false);
        selectAncestorPage.setAllowBaselines(true);
        selectAncestorPage.setAllowWorksets(false);
        selectAncestorPage.setAllowNull(false);
        selectAncestorPage.setPageMessage(DMTeamUiPlugin.getDefault().isAutoFindCommonAncestorBaseline()
                ? Messages.MergeWizard_selectAncPageMessage : Messages.MergeWizard_selectAncPageMessageManual);
        selectAncestorPage.setConnection(target.getConnectionDetails());
        selectAncestorPage.setDefaultOffset(defaultOffset);
        addPage(selectAncestorPage);

        summaryPage = new MergeSummaryPage(SUMMARY_PAGE, Messages.MergeWizard_summaryPageTitle,
                Messages.MergeWizard_summaryPageDesc, DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN));
        addPage(summaryPage);

    }

    private void prepareNextPage(IWizardPage page) {
        if (page == selectSourcePage) {
            if (selectSourcePage.getSelection() != null && (source == null || !source.equals(selectSourcePage.getSelection()))) {
                source = selectSourcePage.getSelection()[0];
                ancestor = findAncestor();
                if (ancestor != null) {
                    selectAncestorPage.reset();
                }
            }
        }
        if (page == selectAncestorPage) {
            this.ancestor = selectAncestorPage.getSelection()[0];
        }

    }

    @Override
    public IWizardPage getNextPage(IWizardPage page, boolean aboutToShow) {
        if (aboutToShow) {
            prepareNextPage(page);
        }
        if (page == selectSourcePage) {
            // jump to summary page if have ancestor and ancestor selection was never shown
            if (ancestor != null && selectAncestorPage.getSelection() == null) {
                return summaryPage;
            }
        }
        return super.getNextPage(page);
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page) {
        return getNextPage(page, true);
    }

    private BaselineAdapter findAncestor() {
        if ((defaultOffset != null && !defaultOffset.isEmpty()) || source.getAPIObject() instanceof ItemRevision) {
            return null; // no auto ancestor detection for scc projects same as compare from the tree for now but can be enhanced
        }
        final BaselineAdapter[] resultHolder = new BaselineAdapter[1];
        try {
            getContainer().run(true, false, new IRunnableWithProgress() {
                @Override
                public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    try {
                        final Session session = target.getConnectionDetails().openSession(null);
                        session.run(new ISessionRunnable() {
                            @Override
                            public void run() throws Exception {
                                Baseline result = DMTeamUiPlugin.getDefault().findCommonAncestorBaseline(
                                        (DimensionsLcObject) target.getAPIObject(), (DimensionsLcObject) source.getAPIObject(),
                                        session.getObjectFactory(), session.getConnectionDetails(), monitor);
                                if (result != null) {
                                    resultHolder[0] = new BaselineAdapter(result, target.getConnectionDetails());
                                }
                            }
                        }, monitor);
                    } catch (DMException e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        } catch (InterruptedException e) {
        }
        return resultHolder[0];
    }

    @Override
    public boolean performFinish() {
        // our merge subscriber supports multi-project set-up, but
        // the wizard can do only one project at a time for now
        // TODO VG on Mar 6, 2006: support multiple project per participant?
        if (ancestor == null) { // happens when finish is clicked on ancestor select page
            ancestor = selectAncestorPage.getSelection()[0];
        }
        final ProjectMergeDescriptor[] descriptor = new ProjectMergeDescriptor[1];
        try {
            getContainer().run(true, false, new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    monitor = Utils.monitorFor(monitor);
                    monitor.beginTask(Messages.MergeWizard_initializing, IProgressMonitor.UNKNOWN);
                    try {
                        IDMProject dmAncestor = DMRepositoryProvider.createProject(ancestor, localTarget, null);
                        IDMProject dmSource = DMRepositoryProvider.createProject(source, localTarget, null);
                        descriptor[0] = new ProjectMergeDescriptor(localTarget, resources, dmAncestor, dmSource);
                    } catch (CoreException e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e1) {
            DMTeamUiPlugin.getDefault().handle(e1);
            return false;
        } catch (InterruptedException e1) {
            return true;
        }

        // First check if there is an existing matching participant, if so then re-use it
        DMBaseCompareParticipant mergeParticipant = DMBaseCompareParticipant.getMatchingParticipant(DMMergeParticipant.ID,
                descriptor);
        if (mergeParticipant == null) {
            mergeParticipant = new DMMergeParticipant(new DMMergeSubscriber(descriptor));
            TeamUI.getSynchronizeManager().addSynchronizeParticipants(new ISynchronizeParticipant[] { mergeParticipant });
        }
        if (pin) {
            mergeParticipant.setPinned(true);
        }
        mergeParticipant.refresh(resources, Messages.DMMergeParticipant_shortTask, mergeParticipant.getName(), null);
        return true;
    }

    IProject getLocalTarget() {
        return localTarget;
    }

    VersionManagementProject getTarget() {
        return target;
    }

    VersionManagementProject getAncestor() {
        return ancestor;
    }

    VersionManagementProject getSource() {
        return source;
    }

}

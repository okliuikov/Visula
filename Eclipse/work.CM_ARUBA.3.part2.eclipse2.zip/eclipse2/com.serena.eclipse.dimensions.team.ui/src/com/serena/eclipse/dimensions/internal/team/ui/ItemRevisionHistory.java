/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui;

import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionHistoryRec;
import com.serena.dmclient.api.SystemAttributes;

/**
 * @author abollmann
 *
 *         Class to wrap the ItemRevisionHistoryRec from Dimensions and adding more information about
 *         the item revisions returned in the item revision history.
 */
public class ItemRevisionHistory {
    private String newRevision;
    private String previousRevision;
    private String author;
    private String status;
    private String modDate;
    private String checkedOutBy;
    private String description;
    private boolean isExtracted;
    private boolean isInCurrentProject;
    private ItemRevision itemRevision;
    private String historyDate;

    // Constructor taking the item revision history record from Dimensions
    public ItemRevisionHistory(ItemRevisionHistoryRec history, ItemRevision item, boolean isInCurrentProject) {
        // use history record user not item creation user
        this.author = history.getUser();
        this.description = history.getComment();
        this.modDate = (String) item.getAttribute(SystemAttributes.UTC_MODIFIED_DATE);
        this.newRevision = history.getNewRevision();
        this.previousRevision = history.getPreviousRevision();
        this.status = (String) item.getAttribute(SystemAttributes.STATUS);
        this.itemRevision = item;
        this.historyDate = history.getDate();
        this.isInCurrentProject = isInCurrentProject;

        String originator = (String) item.getAttribute(SystemAttributes.CREATION_USER);
        Boolean isExtracted = (Boolean) item.getAttribute(SystemAttributes.IS_EXTRACTED);
        if (Boolean.TRUE.equals(isExtracted)) {
            this.isExtracted = true;
            this.checkedOutBy = originator;
        }
    }

    public String getNewRevision() {
        return this.newRevision;
    }

    public String getPreviousRevision() {
        return this.previousRevision;
    }

    public String getAuthor() {
        return this.author;
    }

    public String getStatus() {
        return this.status;
    }

    public String getModDate() {
        return this.modDate;
    }

    public String getCheckedOutBy() {
        return this.checkedOutBy;
    }

    public String getDescription() {
        return this.description;
    }

    public boolean getIsExtracted() {
        return this.isExtracted;
    }

    public boolean getIsInCurrentProject() {
        return this.isInCurrentProject;
    }

    public ItemRevision getItemRevision() {
        return this.itemRevision;
    }

    public String getHistoryDate() {
        return this.historyDate;
    }

}

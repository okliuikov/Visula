package com.serena.eclipse.dimensions.internal.team.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.CompoundContributionItem;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;

import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotateRevision;

public class BlameRulerRequestMenuContribution extends CompoundContributionItem {

    public final static String REQUEST_NAME_PARAM = "com.serena.eclipse.dimensions.team.ui.blameruler.requestName";//$NON-NLS-1$
    public final static String COMMAND_ID = "com.serena.eclipse.dimensions.team.ui.blameruler.openRequestFromAnnotation";//$NON-NLS-1$

    public BlameRulerRequestMenuContribution() {
    }

    public BlameRulerRequestMenuContribution(String id) {
        super(id);
    }

    @Override
    protected IContributionItem[] getContributionItems() {
        IContributionItem[] result = new IContributionItem[0];
        IWorkbenchPage activePage = UIUtils.getActivePage();
        if (activePage != null) {
            StructuredSelection ssel = UIUtils.getStructuredSelectionFromRuler((IEditorPart) activePage.getActivePart());
            Object selObj = null;
            if (ssel != null && ssel.size() > 0 && ((selObj = ssel.getFirstElement()) instanceof BlameAnnotateRevision)) {
                BlameAnnotateRevision revision = (BlameAnnotateRevision) selObj;
                List<String> requests = revision.getRequests();
                Map<String, String> params = null;
                List<CommandContributionItem> contributions = new ArrayList<CommandContributionItem>();
                for (String requestName : requests) {
                    params = new HashMap<String, String>();
                    params.put(REQUEST_NAME_PARAM, requestName);
                    CommandContributionItemParameter param = new CommandContributionItemParameter(PlatformUI.getWorkbench(),
                            REQUEST_NAME_PARAM + requestName, COMMAND_ID, CommandContributionItem.STYLE_PUSH);
                    param.label = requestName;
                    param.parameters = params;
                    param.visibleEnabled = true;
                    contributions.add(new CommandContributionItem(param));
                }
                result = contributions.toArray(new IContributionItem[requests.size()]);
            }
        }
        return result;
    }

}

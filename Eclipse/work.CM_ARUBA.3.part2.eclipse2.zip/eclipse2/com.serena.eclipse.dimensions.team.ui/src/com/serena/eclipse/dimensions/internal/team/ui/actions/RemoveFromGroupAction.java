/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.util.Iterator;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.osgi.util.NLS;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsCategoryElement;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsProjectsCategory;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;
import com.serena.eclipse.internal.ui.ServicesView;

/**
 * @author V.Grishchenko
 */
public class RemoveFromGroupAction extends DimensionsAction {

    @Override
    public void run(IAction action) {
        if (getSelection().isEmpty()) {
            return;
        }
        final DimensionsConnectionDetailsEx con = ((APIObjectAdapter) getSelection().getFirstElement()).getConnectionDetails();
        try {
            for (Iterator objit = getSelection().iterator(); objit.hasNext();) {
                final VersionManagementProject toRemove = (VersionManagementProject) objit.next();
                DimensionsIDEProjectGroup grp = (DimensionsIDEProjectGroup) toRemove.getParentAdapter();
                if (grp != null) {
                    String togo = toRemove.getAPIObject().getName();
                    String from = grp.getAPIObject().getName();
                    if (MessageDialog.openQuestion(getShell(), Messages.remFromGroup_title,
                            NLS.bind(Messages.remFromGroup_question, togo, from))) {
                        // remove it
                        grp.removeMember(toRemove, Messages.remFromGroup_consoleMessage);
                    }
                }
            }
            refreshTree(con);
        } catch (DMException e) {
            DMTeamUiPlugin.getDefault().handle(e);
            return;
        }

    }

    /**
     * @return <code>true</code> if action should be enabled for the current
     *         selection, returns <code>false</code> otherwise
     */
    @Override
    protected boolean isEnabledForSelection() {
        return isSameConnection();
    }

    protected void refreshTree(final DimensionsConnectionDetailsEx conn) throws DMException {
        ServicesView explorer = ServicesView.getCurrentView();
        if (explorer != null) {
            final TreeViewer treeViewer = explorer.getServiceTree();
            final DimensionsCategoryElement parent;
            parent = DimensionsCategoryElement.getCategory(conn, DimensionsProjectsCategory.class);
            treeViewer.refresh(parent);
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.AddToWorkspaceAsWizard.SelectionType;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * Allows to change a type of selection for add to workspace operation. Supported types: {@link SelectionType#HASCHILD_SELECTION}
 * {@link SelectionType#DIRECT_SELECTION}
 */
public class AddToWorkspaceAsSwitchSelectionTypePage extends DimensionsWizardPage {
    public static final String ADD_TO_WORKSPACE_SWITCH_SELECTION_TYPE_PAGE_ID = "add_to_workspace_switch_selection_type_page_id"; //$NON-NLS-1$

    private Button btnChildSelection = null;
    private Button btnContainerSelection = null;
    private Font boldFont;

    public AddToWorkspaceAsSwitchSelectionTypePage(ImageDescriptor image) {
        super(ADD_TO_WORKSPACE_SWITCH_SELECTION_TYPE_PAGE_ID, Messages.addToWorkspaceAsSelectMappingTypePage_title, image);
        setDescription(Messages.addToWorkspaceAsSelectMappingTypePage_description);
    }

    public AddToWorkspaceAsSwitchSelectionTypePage() {
        this(null);
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);

        composite.setLayout(new GridLayout(2, false));

        Composite leftColumn = new Composite(composite, SWT.NONE);
        leftColumn.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, true, false, 0, 0));

        RowLayout rl = new RowLayout(SWT.VERTICAL);
        rl.marginLeft = 5;
        rl.wrap = true;
        rl.fill = true;
        rl.justify = false;
        rl.marginTop = 5;

        leftColumn.setLayout(rl);
        btnChildSelection = new Button(leftColumn, SWT.RADIO);
        btnChildSelection.setText(Messages.addToWorkspaceAsSelectMappingTypePage_childTypeLabel);
        btnChildSelection.setSelection(true);
        Font f = btnChildSelection.getFont();
        FontData[] fds = f.getFontData();
        for (FontData dat : fds) {
            dat.setStyle(SWT.BOLD);
        }
        boldFont = new Font(leftColumn.getDisplay(), fds);
        btnChildSelection.setFont(boldFont);
        btnChildSelection.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent event) {
                getContainer().updateButtons();
            }

        });

        Label l1 = new Label(leftColumn, SWT.NONE);
        l1.setText("      " + Messages.addToWorkspaceAsSelectMappingTypePage_childTypeDescription);//$NON-NLS-1$
        new Label(leftColumn, SWT.NONE);

        btnContainerSelection = new Button(leftColumn, SWT.RADIO);
        btnContainerSelection.setText(Messages.addToWorkspaceAsSelectMappingTypePage_conteinerTypeLabel);
        btnContainerSelection.setFont(boldFont);
        btnContainerSelection.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent event) {
                getContainer().updateButtons();
            }

        });

        Label l3 = new Label(leftColumn, SWT.NONE);
        l3.setText("      " + Messages.addToWorkspaceAsSelectMappingTypePage_containerTypeDescription);//$NON-NLS-1$

        new Label(leftColumn, SWT.NONE);

        Composite rightColumn = new Composite(composite, SWT.NONE);

        rightColumn.setLayout(new FillLayout(SWT.VERTICAL));
        setControl(composite);
    }

    @Override
    public void dispose() {
        if (!boldFont.isDisposed()) {
            boldFont.dispose();
        }
        super.dispose();
    }

    public SelectionType getSelectionType() {
        SelectionType type = SelectionType.HASCHILD_SELECTION;
        if (getControl() != null) {
            Boolean childBtn = UIUtils.safeGetButton(btnChildSelection);
            Boolean containerBtn = UIUtils.safeGetButton(btnContainerSelection);
            if (childBtn != null && childBtn == Boolean.TRUE) {
                type = SelectionType.HASCHILD_SELECTION;
            } else if (containerBtn != null && containerBtn == Boolean.TRUE) {
                type = SelectionType.DIRECT_SELECTION;
            }
        }
        return type;
    }

}

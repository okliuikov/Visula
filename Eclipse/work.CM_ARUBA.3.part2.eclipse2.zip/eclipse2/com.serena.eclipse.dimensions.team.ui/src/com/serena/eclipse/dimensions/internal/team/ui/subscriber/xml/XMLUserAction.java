/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.eclipse.compare.CompareUI;
import org.eclipse.compare.structuremergeviewer.IDiffContainer;
import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.AndSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SyncInfoCompareInput;
import org.eclipse.team.ui.synchronize.SynchronizeModelAction;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;

/**
 * Action that can be performed from tree way merge sync view. Generates from server results:
 * ignore, accept, merge, use local, use repository, etc.<br/>
 * When action is run the operation from {@link XMLUserAction#getSubscriberOperation(ISynchronizePageConfiguration, IDiffElement[])}
 * is executed.
 */
public class XMLUserAction extends SynchronizeModelAction {
    // id's were copied from org.eclipse.team.ui plugin. These id's are being used to check current
    // presentation model in the sync view by P_LAST_PROVIDER key
    private static final String FLAT_FOLDER_MODEL_ID = "org.eclipse.team.ui.modelprovider_flat"; //$NON-NLS-1$
    private static final String TREE_FOLDER_MODEL_ID = "org.eclipse.team.ui.modelprovider_hierarchical"; //$NON-NLS-1$
    private static final String COMPRESSED_FOLDER_MODEL_ID = "org.eclipse.team.ui.modelprovider_compressedfolders"; //$NON-NLS-1$
    private static final String P_LAST_PROVIDER = "org.eclipse.team.ui.P_LAST_MODELPROVIDER";

    private Integer action;
    private ActionFilter actionFilter;

    private XMLUserAction(String text, ISynchronizePageConfiguration configuration) {
        super(text, configuration);
    }

    XMLUserAction(String text, Integer action, ISynchronizePageConfiguration configuration) {
        super(text, configuration);
        this.action = action;
        this.actionFilter = new ActionFilter();
    }

    /**
     * Filter that pass sync info if it has current user action and his action different from
     * current
     */
    public class ActionFilter extends FastSyncInfoFilter {

        private ActionFilter() {
        }

        @Override
        public boolean select(SyncInfo info) {
            if (XMLUserActionFilters.XMLSyncInfoFilter.INSTANCE.select(info)) {
                XMLSyncInfo xinfo = (XMLSyncInfo) info;
                if (xinfo.getCurrentAction() != XMLUserAction.this.action.intValue()) {
                    return xinfo.hasAction(XMLUserAction.this.action.intValue());
                }
            }
            return false;
        }

    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        return new AndSyncInfoFilter(new FastSyncInfoFilter[] { actionFilter, XMLUserActionFilters.StaleFilter.INSTANCE });
    }

    /**
     * If child status is a resolution than parent node must drop ignore status and use previous
     */
    private void applyActionToParent(SyncInfo child, SyncInfo parent) {
        if (!(child instanceof XMLSyncInfo) || !(parent instanceof XMLSyncInfo)) {
            return;
        }

        XMLSyncInfo childInfo = (XMLSyncInfo) child;
        XMLSyncInfo parentInfo = (XMLSyncInfo) parent;

        if (parentInfo.getCurrentAction() == action.intValue() || XSyncUserAction.SUAL_IGNORE == XMLSyncInfo.getActionLabel(action)
                || parentInfo.getActions().size() == 0) {
            return;
        }

        if (parentInfo.getCurrentActionLabel() == XSyncUserAction.SUAL_IGNORE
                && childInfo.getCurrentActionLabel() != XSyncUserAction.SUAL_IGNORE) {
            parentInfo.setCurrentAction(parentInfo.getOldAction());
        }
    }

    /**
     * Node needs explicit action update or restoring of previous action if node currently ignored
     */
    private void applyAction(SyncInfo node) {
        if (!(node instanceof XMLSyncInfo)) {
            return;
        }

        XMLSyncInfo info = (XMLSyncInfo) node;
        if (info.getCurrentAction() == action.intValue() || info.getActions().size() == 0) {
            return;
        }

        if (info.hasAction(action)) {
            info.setCurrentAction(action);
        } else if (info.getCurrentActionLabel() == XSyncUserAction.SUAL_IGNORE
                && XSyncUserAction.SUAL_IGNORE != XMLSyncInfo.getActionLabel(action)) {
            // child is a ignored conflict
            info.setCurrentAction(info.getOldAction());
        }
    }

    private void applyActionToSelection(SyncInfo node) {
        applyAction(node);

        XMLSyncInfo xinfo = (XMLSyncInfo) node;
        boolean mergePrev = XMLSyncInfo.hasMergeOption(xinfo.getOldAction());

        boolean unresolvedMerge = false;
        if (!mergePrev && xinfo.getOldAction() == XSyncUserAction.SUAL_UNRESOLVED.value()) {
            unresolvedMerge = xinfo.getDescriptor().getTempStore(xinfo) != null ? true : false;
        }

        boolean mergeCur = XMLSyncInfo.hasMergeOption(action);

        boolean closed = false;
        if (mergePrev != mergeCur) {
            closed = XMLMergeUIUtils.closeMergeCompareEditors(xinfo);
        }

        if ((mergeCur && (!mergePrev || unresolvedMerge)) || closed) {
            // reopen if was closed or if merge was passed
            CompareUI.openCompareEditor(new SyncInfoCompareInput(getConfiguration().getParticipant(), node), true);
        }
    }

    private void propagateFlatListAction(IStructuredSelection sel) {
        List<IDiffElement> allNodes = null;

        for (Iterator<?> selIterator = sel.iterator(); selIterator.hasNext();) {
            Object element = selIterator.next();
            if (element instanceof ISynchronizeModelElement && element instanceof IAdaptable) {
                ISynchronizeModelElement selEll = (ISynchronizeModelElement) element;
                SyncInfo info = (SyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
                XMLSyncInfo selInfo = (XMLSyncInfo) info;
                IResource selLocal = selInfo.getLocal();

                if (allNodes == null) {
                    allNodes = new ArrayList<IDiffElement>(Arrays.asList(selEll.getParent().getChildren()));
                }

                for (Iterator<IDiffElement> nodeIterator = allNodes.iterator(); nodeIterator.hasNext();) {
                    IDiffElement next = nodeIterator.next();
                    if (!(next instanceof ISynchronizeModelElement) || !(next instanceof IAdaptable)) {
                        nodeIterator.remove();
                    }

                    SyncInfo otherCandidate = (SyncInfo) ((IAdaptable) next).getAdapter(SyncInfo.class);
                    if (!(otherCandidate instanceof XMLSyncInfo)) {
                        nodeIterator.remove();
                    }

                    XMLSyncInfo otherInfo = (XMLSyncInfo) otherCandidate;
                    IResource otherLocal = otherInfo.getLocal();

                    if (otherLocal.getFullPath().isPrefixOf(selLocal.getFullPath()) && !(otherLocal instanceof IFile)) {
                        // parent folder case
                        applyActionToParent(selInfo, otherInfo);
                        nodeIterator.remove();
                    } else if (selLocal.getFullPath().isPrefixOf(otherLocal.getFullPath())) {
                        // child file/folder case
                        applyAction(otherInfo);
                        nodeIterator.remove();
                    }
                }
            }

        }
    }

    private void propagateCompressedTreeAction(IDiffElement element, XMLSyncInfo selInfo, boolean fullDepth) {
        if (element instanceof ISynchronizeModelElement && element instanceof IAdaptable) {
            ISynchronizeModelElement otherEll = (ISynchronizeModelElement) element;
            SyncInfo otherInfo = (SyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
            IResource otherLocal = otherEll.getResource();
            IResource selLocal = selInfo.getLocal();
            if (otherLocal.getFullPath().isPrefixOf(selLocal.getFullPath()) && !(otherLocal instanceof IFile)) {
                applyActionToParent(selInfo, otherInfo);
            } else if (fullDepth && selLocal.getFullPath().isPrefixOf(otherLocal.getFullPath())) {
                applyAction(otherInfo);
            }
        }

        if (element instanceof IDiffContainer) {
            IDiffContainer container = (IDiffContainer) element;
            if (container.hasChildren()) {
                IDiffElement[] children = container.getChildren();
                for (int i = 0; i < children.length; i++) {
                    propagateCompressedTreeAction(children[i], selInfo, fullDepth);
                }
            }
        }
    }

    private void propagateCompressedTreeAction(IStructuredSelection sel) {
        for (Iterator<?> iterator = sel.iterator(); iterator.hasNext();) {
            Object selEll = iterator.next();
            if (selEll instanceof ISynchronizeModelElement && selEll instanceof IAdaptable) {
                ISynchronizeModelElement smEll = (ISynchronizeModelElement) selEll;
                SyncInfo syncInfo = (SyncInfo) ((IAdaptable) selEll).getAdapter(SyncInfo.class);

                if (!(syncInfo instanceof XMLSyncInfo)) {
                    continue;
                }

                XMLSyncInfo selInfo = (XMLSyncInfo) syncInfo;
                IResource selLocal = selInfo.getLocal();

                if (selLocal.getParent() instanceof IProject && !(selLocal instanceof IContainer)) {
                    continue;
                }

                boolean fullDepth = selLocal instanceof IContainer ? true : false;
                IDiffContainer root = selLocal instanceof IContainer ? smEll.getParent() : smEll.getParent().getParent();

                propagateCompressedTreeAction(root, selInfo, fullDepth);
            }
        }
    }

    private void propagateTreeAction(IStructuredSelection sel) {
        for (Iterator<?> iterator = sel.iterator(); iterator.hasNext();) {
            Object selEll = iterator.next();
            if (selEll instanceof ISynchronizeModelElement && selEll instanceof IAdaptable) {
                ISynchronizeModelElement smEll = (ISynchronizeModelElement) selEll;
                SyncInfo syncInfo = (SyncInfo) ((IAdaptable) selEll).getAdapter(SyncInfo.class);
                // for tree presentation only parent checking needed
                IDiffContainer parent = smEll.getParent();
                while (parent != null) {
                    if (parent instanceof ISynchronizeModelElement && parent instanceof IAdaptable) {
                        SyncInfo parentSyncInfo = (SyncInfo) ((IAdaptable) parent).getAdapter(SyncInfo.class);
                        applyActionToParent(syncInfo, parentSyncInfo);
                    }
                    parent = parent.getParent();
                }
            }
        }
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(final ISynchronizePageConfiguration configuration,
            final IDiffElement[] elements) {
        return new SynchronizeModelOperation(configuration, elements) {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                SyncInfo[] infos = getSyncInfoSet().getSyncInfos();

                // 1. Flat presentation returns only selected elements
                // 2. Compressed folder presentations returns selected elements and child files
                // if selected is a folder
                // 3. Tree presentation returns selected element and all children
                Arrays.sort(infos, new Comparator<SyncInfo>() {

                    @Override
                    public int compare(SyncInfo o1, SyncInfo o2) {
                        return o1.getLocal().getName().compareTo(o2.getLocal().getName());
                    }
                });

                for (int i = 0; i < infos.length; i++) {
                    if (infos[i] instanceof XMLSyncInfo) {
                        XMLSyncInfo info = (XMLSyncInfo) infos[i];
                        applyActionToSelection(info);
                    }
                }

                IStructuredSelection sel = getStructuredSelection();
                IDialogSettings pageSettings = getConfiguration().getSite().getPageSettings();
                String modelProviderId = pageSettings.get(P_LAST_PROVIDER);

                if (modelProviderId.equals(COMPRESSED_FOLDER_MODEL_ID)) {
                    propagateCompressedTreeAction(sel);
                } else if (modelProviderId.equals(FLAT_FOLDER_MODEL_ID)) {
                    propagateFlatListAction(sel);
                } else if (modelProviderId.equals(TREE_FOLDER_MODEL_ID)) {
                    propagateTreeAction(sel);
                }

                firePropertyChange(new PropertyChangeEvent(this, XMLMergeParticipant.PROPAGATE_CONTEXT_ACTION_EVENT, null, action));

                Display.getDefault().asyncExec(new Runnable() {

                    @Override
                    public void run() {
                        Viewer viewer = configuration.getPage().getViewer();
                        viewer.refresh();
                    }
                });
            }
        };
    }

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardPage;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectDetails;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroupDetails;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.wizards.AttributesWizardPage;

/**
 * Wizard that creates project groups.
 *
 * @author V.Grishchenko
 */
public class NewGroupWizard extends NewStreamWizard {
    public static final String MEMBERS_PAGE = "members_page"; //$NON-NLS-1$
    private APIObjectAdapter[] members;

    public NewGroupWizard() {
        isStream = false;
    }

    public NewGroupWizard(DimensionsConnectionDetailsEx connection, APIObjectAdapter[] members) {
        super(connection, null, false);
        this.members = members;
    }

    @Override
    protected void setWizardTitle() {
        setWindowTitle(Messages.NewGroupWizard_title);
    }

    @Override
    protected IWizardPage[] createPages() {
        IWizardPage[] pages = new IWizardPage[5];

        pages[0] = new NewStreamGeneralPage(PROJECT_GENERAL_PAGE, Messages.NewStreamWizard_project_general_title,
                Messages.NewStreamWizard_project_general_description, DMUIPlugin.getDefault().getImageDescriptor(
                        IDMImages.LOGIN_WIZBAN), false, true);

        pages[1] = new NewStreamDetailsPage(PROJECT_DETAILS_PAGE, Messages.NewStreamWizard_project_details_title,
                Messages.NewStreamWizard_project_details_description, DMUIPlugin.getDefault().getImageDescriptor(
                        IDMImages.LOGIN_WIZBAN), false);

        pages[2] = new NewWorksetGroupContentsPage<APIObjectAdapter>(MEMBERS_PAGE, Messages.NewGroupWizard_members_title,
                Messages.NewGroupWizard_members_description, DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                members, false);

        pages[3] = new NewProjectBranchPage(PROJECT_BRANCHES_PAGE, Messages.NewStreamWizard_project_branches_title,
                Messages.NewStreamWizard_project_branches_description, DMUIPlugin.getDefault().getImageDescriptor(
                        IDMImages.LOGIN_WIZBAN));

        pages[4] = new AttributesWizardPage(PROJECT_ATTR_PAGE, Messages.NewStreamWizard_project_attr_title,
                Messages.NewStreamWizard_project_attr_description, DMUIPlugin.getDefault().getImageDescriptor(
                        IDMImages.LOGIN_WIZBAN));

        return pages;
    }

    @Override
    public boolean canFinish() {
        return getPage(PROJECT_GENERAL_PAGE).isPageComplete();
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page, boolean aboutToShow) {
        IWizardPage nextPage = super.getNextPage(page, aboutToShow);
        // "miss attribute page when no attribute defined for this project type" workaround
        if (null != nextPage && nextPage.getName().equals(PROJECT_BRANCHES_PAGE)) {
            ((WizardPage) nextPage).setPageComplete(true);
        }
        if (null == nextPage && null != page && page.getName().equals(PROJECT_BRANCHES_PAGE)) {
            ((WizardPage) page).setPageComplete(false);
        }
        // -- end of workaround
        return nextPage;
    }

    @Override
    protected DimensionsIDEProjectDetails createInstance(String product, String name, String description) {
        return new DimensionsIDEProjectGroupDetails(product, name, description);
    }

    @Override
    protected WorksetList getWorksetList(DimensionsIDEProjectDetails worksetDetails) {
        return WorksetList.getDimensionsIDEProjectGroupsList(getConnection(), false, false);
    }

    @Override
    public APIObjectAdapter performCreate(IProgressMonitor monitor) throws CoreException {
        if (objectDetails == null) {
            objectDetails = createStreamDetails();
        }
        DimensionsIDEProjectGroupDetails details = (DimensionsIDEProjectGroupDetails) objectDetails;

        @SuppressWarnings("unchecked")
        NewWorksetGroupContentsPage<APIObjectAdapter> cont = (NewWorksetGroupContentsPage<APIObjectAdapter>) getPage(MEMBERS_PAGE);

        details.setMembers(cont.getContents());
        return super.performCreate(monitor);
    }
}

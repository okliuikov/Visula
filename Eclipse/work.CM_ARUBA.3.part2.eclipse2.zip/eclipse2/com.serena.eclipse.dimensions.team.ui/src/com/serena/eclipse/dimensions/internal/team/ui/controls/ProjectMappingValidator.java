/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.controls;

import java.util.HashSet;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.osgi.util.NLS;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;

/**
 * @author V.Grishchenko
 */
public abstract class ProjectMappingValidator implements ProjectMappingPanel.IMappingChangeListener {
    private ProjectMapping[] mappings;
    private IStatus errorStatus;

    public ProjectMappingValidator(ProjectMapping[] mappings, boolean validate) {
        this.mappings = mappings == null ? new ProjectMapping[0] : mappings;
        if (validate) {
            checkValid();
            setErrorMessage();
        }
    }

    @Override
    public void mappingChanged(ProjectMapping mapping) {
        IStatus status = mapping.validateLocalProjectName();
        if (!status.isOK()) {
            errorStatus = status;
        } else {
            checkValid();
        }
        setErrorMessage();
    }

    public boolean isMappingValid() {
        checkValid();
        return errorStatus == null;
    }

    private void checkValid() {
        HashSet names = new HashSet();
        String dup = null;
        for (int i = 0; i < mappings.length; i++) {
            if (dup == null && !names.add(mappings[i].getLocalProjectName())) {
                dup = mappings[i].getLocalProjectName();
            }
            IStatus status = mappings[i].validateLocalProjectName();
            if (!status.isOK()) {
                errorStatus = status;
                return;
            }
        }
        if (dup != null) {
            errorStatus = DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, NLS.bind(Messages.prjMapDialog_duplicate, dup));
            return;
        }
        errorStatus = null;
    }

    public String getErrorMessage() {
        if (errorStatus == null) {
            return null;
        }
        return errorStatus.getMessage();
    }

    private void setErrorMessage() {
        setErrorMessage(errorStatus == null ? null : errorStatus.getMessage());
    }

    /**
     * @param message <code>null</code> when ok, error message when not
     */
    protected abstract void setErrorMessage(String message);

}

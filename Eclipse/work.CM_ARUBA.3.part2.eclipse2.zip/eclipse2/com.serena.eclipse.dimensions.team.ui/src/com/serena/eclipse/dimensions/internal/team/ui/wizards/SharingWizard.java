/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.ui.IConfigurationWizard;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ISynchronizeView;
import org.eclipse.team.ui.synchronize.ResourceScope;
import org.eclipse.team.ui.synchronize.SubscriberParticipant;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.UIJob;

import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.Type;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.dto.Unit;
import com.serena.dmfile.metadb.MetadataProvider;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProject;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectDetails;
import com.serena.eclipse.dimensions.core.FavouriteProjectsList;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.IFavouriteObject;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.SccProjectList;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFolder;
import com.serena.eclipse.dimensions.internal.team.core.IMavenProjectStructureHelper;
import com.serena.eclipse.dimensions.internal.team.core.MetadataHelper;
import com.serena.eclipse.dimensions.internal.team.core.MetadataProviderFactory;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.TeamUIUtils;
import com.serena.eclipse.dimensions.internal.team.ui.operations.DeliverOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UploadOperation;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMSynchronizeParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceStreamOutgoingParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceSynchronizeParticipant;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.wizards.AttributesWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.ConnectionSelectionPage;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Shares local projects with remote.
 *
 * @author V.Grishchenko
 */
public class SharingWizard extends NewStreamWizard implements IConfigurationWizard { 
    public static final String OFFSET_PAGE = "offset_page"; //$NON-NLS-1$
    public static final String EXISTING_PROJECT_SUMMARY_PAGE = "existing_project_summary_page"; //$NON-NLS-1$
    public static final String GENERIC_REQUEST_PAGE = "generic_request_page"; //$NON-NLS-1$

    public static final int PROJECT_WS = 1; // eclipse project is in workspace
    public static final int PROJECT_INCOMPATIBLE_WA = 2; // eclipse project is outside the ws & under incompatible/multiple work
                                                         // area
    public static final int PROJECT_COMPATIBLE_WA = 4; // eclipse project is outside the ws & under compatible work area
    public static final int PROJECT_NOT_WA = 8; // eclipse project is outside the ws & not under any work area

    static final String WORKSET_PAGE_ID = "workset_page"; //$NON-NLS-1$
    static final String NEW_WORKSET_PAGE_ID = "new_workset_page"; //$NON-NLS-1$
    static final String SUMMARY_PAGE = "summary_page"; //$NON-NLS-1$

    private IProject project;

    // selected configuration
    private VersionManagementProject remoteProject;
    private APIObjectAdapter remoteProjectToManage;
    private boolean inContainer;
    private boolean createNewProject;
    private List<String> relatedRequest = new ArrayList<String>();
    private boolean showMavenWarning = true;

    /**
     * Creates a new sharing wizard.
     */
    public SharingWizard() {
        setNeedsProgressMonitor(true);
        setWizardTitle();
    }

    @Override
    protected void setWizardTitle() {
        setWindowTitle(Messages.SharingWizard_title);
    }

    @Override
    public IWizardPage[] createPages() {
        // create pages
        List<IWizardPage> pagesl = new ArrayList<IWizardPage>();
        pagesl.add(new WorksetSelectionPage(WORKSET_PAGE_ID, Utils.EMPTY_STRING, Utils.EMPTY_STRING, null)); // use dm default

        // New stream/project specific pages. Don�t change their sequence
        pagesl.add(new NewStreamGeneralPage(STREAM_GENERAL_PAGE, Messages.NewStreamWizard_stream_general_title,
                Messages.NewStreamWizard_stream_general_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), true, true, project));

        pagesl.add(new NewStreamDetailsPage(STREAM_DETAILS_PAGE, Messages.NewStreamWizard_stream_details_title,
                Messages.NewStreamWizard_stream_details_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), true));

        pagesl.add(new AttributesWizardPage(STREAM_ATTR_PAGE, Messages.NewStreamWizard_stream_attr_title,
                Messages.NewStreamWizard_stream_attr_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

        pagesl.add(new NewStreamGeneralPage(PROJECT_GENERAL_PAGE, Messages.NewStreamWizard_project_general_title,
                Messages.NewStreamWizard_project_general_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), false, true, project));

        pagesl.add(new NewStreamDetailsPage(PROJECT_DETAILS_PAGE, Messages.NewStreamWizard_project_details_title,
                Messages.NewStreamWizard_project_details_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), false));

        pagesl.add(new NewProjectOptionsPage(PROJECT_OPTIONS_PAGE, Messages.NewStreamWizard_project_options_title,
                Messages.NewStreamWizard_project_options_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

        pagesl.add(new NewProjectBranchPage(PROJECT_BRANCHES_PAGE, Messages.NewStreamWizard_project_branches_title,
                Messages.NewStreamWizard_project_branches_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

        pagesl.add(new AttributesWizardPage(PROJECT_ATTR_PAGE, Messages.NewStreamWizard_project_attr_title,
                Messages.NewStreamWizard_project_attr_description,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));
        
        pagesl.add(new NewStreamTopicWorkareaPage(STREAM_TOPIC_WORKAREA_PAGE, null, true, project));
        pagesl.add(new NewStreamTopicUsersPage(STREAM_TOPIC_USERS_PAGE));

        pagesl.add(new OffsetPage(OFFSET_PAGE, Messages.SharingWizard_offsetPageTitle,
                Messages.Sharingwizard_offsetPageDescrFull,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), project));

        pagesl.add(new GenericRequestPage(GENERIC_REQUEST_PAGE, Messages.SharingWizard_requestPageTitle,
                Messages.SharingWizard_requestPageDescr,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

        pagesl.add(new SharingSummaryPage(SUMMARY_PAGE, Messages.SharingWizard_summaryPageTitle,
                Messages.SharingWizard_summaryPageDescr,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

        IWizardPage[] pages = pagesl.toArray(new IWizardPage[pagesl.size()]);
        return pages;

    }

    @Override
    public void addPages() {
        super.addPages();
        String msg = Messages.SharingWizard_wizardDescr;
        ConnectionSelectionPage connectionSelectionPage = (ConnectionSelectionPage) getPage(SELECT_CONNECTION_PAGE);
        connectionSelectionPage.setDetailsMessage(msg);
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page) {
        if (null == page) {
            return null;
        }
        if (page.getName().equals(WORKSET_PAGE_ID)) {
            if (createNewProject) {
                if (mode == Mode.TOPIC_STREAM) {
                    return getPage(STREAM_TOPIC_WORKAREA_PAGE);
                } else if (!isStream) {
                    return getPage(PROJECT_GENERAL_PAGE);
                }
            } else {
                return getPage(OFFSET_PAGE);
            }
        } else if (page.getName().equals(STREAM_ATTR_PAGE) || page.getName().equals(PROJECT_ATTR_PAGE)
                || page.getName().equals(STREAM_TOPIC_USERS_PAGE)) {
            if (inContainer) {
                return getPage(GENERIC_REQUEST_PAGE);
            }
            return getPage(SUMMARY_PAGE);
        }
        if (page.getName().equals(SUMMARY_PAGE)) {
            return null;
        }

        IWizardPage[] pages = getPages();
        for (int i = 0; i < pages.length; i++) {
            if (pages[i].getName().equals(page.getName())) {
                if (pages.length - 1 > i) {
                    return pages[++i];
                } else {
                    break;
                }
            }
        }
        return null;
    }

    /*
     * copy to members only if leaving the page
     */
    @Override
    public IWizardPage getNextPage(IWizardPage page, boolean aboutToShow) {
        showMavenWarning();

        if (null != page && page.getName().equals(WORKSET_PAGE_ID)) {
            WorksetSelectionPage sp = (WorksetSelectionPage) getPage(WORKSET_PAGE_ID);
            inContainer = sp.getCreateInContainer();
            createNewProject = sp.getCreateNewProject() || sp.getCreateNewStream() || sp.getCreateNewTopicStream();
            if (createNewProject) {
                isStream = sp.getCreateNewStream();
                if (sp.getCreateNewStream()) {
                    setMode(Mode.COMMON_STREAM);
                } else if (sp.getCreateNewTopicStream()) {
                    setMode(Mode.TOPIC_STREAM);
                } else {
                    setMode(Mode.UNKNOWN);
                }
            }
            remoteProject = sp.getResult();
        } else if (null != page && page.getName().equals(STREAM_DETAILS_PAGE) && aboutToShow) {
            GenericRequestPage requestPage = (GenericRequestPage) getPage(GENERIC_REQUEST_PAGE);
            Boolean requestRequired = ((NewStreamDetailsPage) page).getRequestRequired();
            if (requestPage != null) {
                requestPage.setRequestRequired(requestRequired != null ? requestRequired.booleanValue() : false);
                requestPage.setProject(null);
                requestPage.setProductId(getProductName());
            }
        } else if (null != page && page.getName().equals(PROJECT_OPTIONS_PAGE) && aboutToShow) {
            GenericRequestPage requestPage = (GenericRequestPage) getPage(GENERIC_REQUEST_PAGE);
            char flagCM = ((NewProjectOptionsPage) page).getCMRulesFlag();
            if (requestPage != null) {
                boolean reqRequired = false;
                if (flagCM == ProjectDetails.PROJECT_CM_RULES_ON) {
                    reqRequired = true;
                } else if (flagCM == ProjectDetails.PROJECT_CM_RULES_DEFAULT) {
                    reqRequired = requestPage.checkMarkerCMRules(getConnection(), getProductName());
                }
                requestPage.setRequestRequired(reqRequired);
                requestPage.setProject(null);
                requestPage.setProductId(getProductName());
            }
        } else if (null != page && page.getName().equals(OFFSET_PAGE) && aboutToShow) {
            GenericRequestPage requestPage = (GenericRequestPage) getPage(GENERIC_REQUEST_PAGE);
            WorksetSelectionPage wsSelectPage = (WorksetSelectionPage) getPage(WORKSET_PAGE_ID);
            if (requestPage != null && wsSelectPage != null) {
                boolean reqRequired = requestPage.checkCMRules(getConnection(), wsSelectPage.getResult());
                requestPage.setRequestRequired(reqRequired);
                requestPage.setProject(wsSelectPage.getResult());
            }
        }

        IWizardPage nextPage = super.getNextPage(page, aboutToShow);
        if (null != nextPage && nextPage.getName().equals(SUMMARY_PAGE)) {
            if (remoteProject != null && remoteProject instanceof SccProject) {
                return null;
            }
            fillSummary();

        }

        return nextPage;
    }

    private void showMavenWarning() {
        if (showMavenWarning) {
            final IMavenProjectStructureHelper mavenHelper = DMTeamPlugin.getDefault().getMavenProjectStructureHelper();
            if (mavenHelper != null) {
                final Unit<Boolean> hasPom = new Unit<Boolean>();

                BusyIndicator.showWhile(getContainer().getShell().getDisplay(), new Runnable() {

                    @Override
                    public void run() {
                        hasPom.setValue(mavenHelper.hasParentPomInTree(project, new NullProgressMonitor()));
                    }
                });

                if (hasPom.getValue()) {
                    UIUtils.getDisplay().asyncExec(new Runnable() {

                        @Override
                        public void run() {
                            MessageDialog.openWarning(null, Messages.SharingWizard_title,
                                    Messages.SharingWizard_mavenProjectIsVirtual);
                        }
                    });
                } else if (mavenHelper.hasMavenNature(project)) {
                    if (!mavenHelper.isMavenProjectResolvedByWorkspace(project)) {
                        UIUtils.getDisplay().asyncExec(new Runnable() {

                            @Override
                            public void run() {
                                MessageDialog.openWarning(null, Messages.SharingWizard_title,
                                        Messages.SharingWizard_mavenProjectIsNotResolved);
                            }
                        });
                    }

                }

            }
            this.showMavenWarning = false;
        }
    }

    private void fillSummary() {
        SharingSummaryPage summaryPage = (SharingSummaryPage) getPage(SUMMARY_PAGE);

        String offset = ((OffsetPage) getPage(OFFSET_PAGE)).getOffset();
        if (createNewProject) {
            if (mode == Mode.TOPIC_STREAM) {
                offset = ((NewStreamTopicWorkareaPage) getPage(STREAM_TOPIC_WORKAREA_PAGE)).getOffset();
            }
            else {
                offset = ((NewStreamGeneralPage) getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE)).getOffset();
            }
        }

        summaryPage.setConnection(getConnection().getConnName());
        summaryPage.setNewConnection(isNewConnection());
        summaryPage.setInContainer(inContainer);
        summaryPage.setOffset(offset);
        summaryPage.setUseSbm(getConnection().getSBMConnection() != null);
        if (remoteProject != null) {
            Project workset = null;
            String ideProjectName = null;
            final Unit<List<String>> branchList = new Unit<List<String>>();
            if (remoteProject instanceof WorksetAdapter) {
                workset = (Project) remoteProject.getAPIObject();
                final Project finalWorkset = workset;
                // Get existing workset branch and branch list
                BusyIndicator.showWhile(getContainer().getShell().getDisplay(), new Runnable() {

                    @Override
                    public void run() {
                        try {
                            final Session session = getConnection().openSession(null);
                            session.run(new ISessionRunnable() {

                                @SuppressWarnings("unchecked")
                                @Override
                                public void run() throws Exception {
                                    Utils.queryAttributes(Collections.singletonList(finalWorkset),
                                            new int[] { SystemAttributes.IDE_PROJECT_NAME, SystemAttributes.DEFAULT_BRANCH },
                                            session.getObjectFactory(), true);
                                    branchList.setValue(finalWorkset.getBranchNames());
                                }

                            }, null);
                        } catch (DMException e) {
                            DMTeamUiPlugin.getDefault().handle(e, getShell());
                        }
                    }

                });
                if (inContainer) {
                    ideProjectName = project.getName();
                } else {
                    ideProjectName = (String) workset.getAttribute(SystemAttributes.IDE_PROJECT_NAME);
                }
            } else if (remoteProject instanceof SccProject) {
                SccProject sccProject = (SccProject) remoteProject;
                workset = ((WorksetAdapter) sccProject.getProjectContainer()).getWorkset();
                ideProjectName = sccProject.getName();
            }

            summaryPage.setWorkset((String) workset.getAttribute(SystemAttributes.OBJECT_SPEC));
            summaryPage.setProject(ideProjectName);
            summaryPage.setDefaultBranch((String) workset.getAttribute(SystemAttributes.DEFAULT_BRANCH));
            summaryPage.setValidBranches(branchList.getValue());
            summaryPage.setNewWorkset(false);
        }

        if (createNewProject) {
            DimensionsIDEProjectDetails det = isStream ? streamDetails : (DimensionsIDEProjectDetails) objectDetails;
            summaryPage.setWorkset(det.getName());
            if (inContainer) {
                summaryPage.setProject(project.getName());
            } else {
                summaryPage.setProject(det.getProject());
            }
            summaryPage.setDefaultBranch(det.getDefaultBranch());
            summaryPage.setValidBranches(det.getBranchList());
            summaryPage.setNewWorkset(true);
        }
    }

    @Override
    public boolean performFinish() {
        if (!runLateValidation()) {
            return false;
        }
        
        WorksetSelectionPage sp = (WorksetSelectionPage) getPage(WORKSET_PAGE_ID);
        remoteProject = sp.getResult();
        inContainer = sp.getCreateInContainer();
        
        final String offset;
        final String part;
        final String workArea;
        final String projName = getProjectName();
        if (createNewProject) {
            if (getMode() == Mode.TOPIC_STREAM) {
                NewStreamTopicWorkareaPage page = (NewStreamTopicWorkareaPage) getPage(STREAM_TOPIC_WORKAREA_PAGE);
                offset = page.getOffset();
                workArea = page.getWorkArea();
                part = page.getPart();
            }
            else {
                NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE);
                offset = gp.getOffset();
                part = gp.getPart();
                workArea = gp.getWorkArea();
            }
        } else { // for existing project access to the OffsetPage
            OffsetPage op = (OffsetPage) getPage(OFFSET_PAGE);
            offset = op.getOffset();
            part = op.getPart();
            workArea = op.getWorkArea();
        }
        if (inContainer) {
            // if in container we always show GenericRequestPage to fill in
            GenericRequestPage reqPage = (GenericRequestPage) getPage(GENERIC_REQUEST_PAGE);
            if (reqPage != null) {
                reqPage.saveSettings();
                String[] selectedRequestIDs = reqPage.getSelectedItems();
                relatedRequest.addAll(Arrays.asList(selectedRequestIDs));
            }
        }

        if (inContainer && !(remoteProject instanceof SccProject)) {
            String product = getProductName();
            Type t = null;
            try {
                t = getConnection().getType(DMTypeScope.ITEM, product, IDMConstants.TYPE_PROJECT);
            } catch (DMException e1) {
                DMTeamUiPlugin.getDefault().handle(e1);
                return false;
            }
            if (t == null) {
                MessageDialog.openError(getShell(), Messages.Dialog_title,
                        NLS.bind(Messages.SharingWizard_noTypeMessage, IDMConstants.TYPE_PROJECT));
                return false;
            }
        }
        final IResource[] resources = new IResource[] { project };
        final boolean[] canDismiss = new boolean[1]; // this wizard can be closed
        final boolean[] refreshOk = new boolean[1]; // refresh status was successful

        try {
            getContainer().run(true, false, new IRunnableWithProgress() {
                @Override
                public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {

                    try {
                        int workTodo = 100;
                        monitor.beginTask(null, workTodo);
                        // persist attribute model if new workset
                        AttributesWizardPage attrPage = (AttributesWizardPage) getPage(
                                isStream ? STREAM_ATTR_PAGE : PROJECT_ATTR_PAGE);
                        if (null != attrPage && (createNewProject)) {
                            IAttributeModel model = attrPage.getAttributeModel();
                            if (null != model) {
                                model.save(null); // commit to details object - no need to monitor
                            }
                        }

                        // fetch details from pages
                        DimensionsIDEProjectDetails det = null;
                        if (createNewProject) {
                            det = isStream ? streamDetails : (DimensionsIDEProjectDetails) objectDetails;
                            if (null == det) {
                                det = createStreamDetails();
                            } else {
                                refreshStreamDetails();
                            }
                            det.setInitial(true);
                            det.setProject(inContainer ? Utils.EMPTY_STRING : projName);
                            det.setPart(part);
                        } else {
                            remoteProjectToManage = remoteProject;
                        }

                        if (!isStream && getMode() != Mode.TOPIC_STREAM && det != null) {
                            // Set deployment model
                            int wsManualPromotion = 0x080;
                            int typeOption = getOptionsFromType();
                            if ((typeOption & wsManualPromotion) == wsManualPromotion) {
                                det.setManualDeploymentFlag(true);
                            } else {
                                det.setManualDeploymentFlag(false);
                            }
                        }

                        if (!inContainer) {
                            if (remoteProject == null) {
                                remoteProjectToManage = createNewProject(det, Utils.subMonitorFor(monitor, 60));
                                workTodo -= 60;
                            } else {
                                if (remoteProject.getClass() == WorksetAdapter.class) {
                                    Project dimProjectImpl = (Project) remoteProject.getAPIObject();
                                    dimProjectImpl.queryAttribute(SystemAttributes.IDE_TAG);
                                    String ideInfo = (String) dimProjectImpl.getAttribute(SystemAttributes.IDE_TAG);

                                    if (Utils.isNullEmpty(ideInfo) && dimProjectImpl.getChildItems(null).size() == 0) {
                                        dimProjectImpl.setIdeInfo(IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG, project.getName(),
                                                dimProjectImpl, true);

                                        int[] attrs = new int[] { SystemAttributes.IDE_PROJECT_NAME,
                                                SystemAttributes.IDE_DM_UID, };

                                        dimProjectImpl.queryAttribute(attrs);
                                        String ideProject = (String) dimProjectImpl
                                                .getAttribute(SystemAttributes.IDE_PROJECT_NAME);
                                        Long uid = (Long) dimProjectImpl.getAttribute(SystemAttributes.IDE_DM_UID);
                                        remoteProject = new DimensionsIDEProject(dimProjectImpl, getConnection(),
                                                IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG, ideProject, String.valueOf(uid));

                                        WorksetList.getOtherProjectsList(getConnection(), false, false)
                                                .fetch(Utils.subMonitorFor(monitor, 10));
                                        WorksetList.getDimensionsIDEProjectsList(getConnection(), false, false)
                                                .fetch(Utils.subMonitorFor(monitor, 10));
                                        workTodo -= 20;
                                    }
                                }
                                remoteProjectToManage = remoteProject;
                            }
                        } else { // we now have a container
                            if (remoteProject == null) {
                                // adding to new project create it as SccProjectContainer
                                remoteProject = createNewContainer(det, Utils.subMonitorFor(monitor, 30));
                                workTodo -= 30;
                            }
                            if (remoteProject.getClass() == WorksetAdapter.class) {
                                // wrong class - convert to container
                                // set ide info - no project name for container
                                // dbio error if already set DEF 106781
                                ((Project) remoteProject.getAPIObject()).queryAttribute(SystemAttributes.IDE_TAG);
                                String ideInfo = (String) ((Project) remoteProject.getAPIObject())
                                        .getAttribute(SystemAttributes.IDE_TAG);
                                // only add if nothing there
                                if (Utils.isNullEmpty(ideInfo)) {
                                    ((Project) remoteProject.getAPIObject()).setIdeInfo(
                                            IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG, Utils.EMPTY_STRING,
                                            (Project) remoteProject.getAPIObject(), true);
                                }
                                monitor.worked(10);
                                // refresh the all projects list to remove the converted
                                if (remoteProject.getObjectList() != null) {
                                    remoteProject.getObjectList().fetch(Utils.subMonitorFor(monitor, 10));
                                }
                                ((Project) remoteProject.getAPIObject()).queryAttribute(SystemAttributes.IDE_DM_UID);
                                monitor.worked(10);
                                workTodo -= 30;
                                remoteProject = new SccProjectContainerWorkset((Project) remoteProject.getAPIObject(),
                                        remoteProject.getConnectionDetails(),
                                        IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG);
                            }
                            if (remoteProject instanceof SccProject) { // connect to existing
                                remoteProjectToManage = remoteProject;
                            } else {
                                // remoteProject is going to be an item, check if already exists to avoid dup create
                                SccProjectContainerWorkset contWst = null;
                                if (remoteProject instanceof SccProjectContainerWorkset) {
                                    contWst = (SccProjectContainerWorkset) remoteProject;
                                } else { // DEF112090 convert top level container thingy to a container workset
                                    contWst = new SccProjectContainerWorkset((WorksetAdapter) remoteProject);
                                }
                                SccProjectList list = SccProjectList.getProjectList(contWst);
                                list.fetch(Utils.subMonitorFor(monitor, 10));
                                workTodo -= 10;
                                SccProject sccProject = list.findProject(offset);
                                if (sccProject == null) {
                                    // get the information
                                    ItemRevisionDetails newMarkerDetails = getMarkerDetails(offset, part,
                                            Utils.subMonitorFor(monitor, 10));
                                    newMarkerDetails.setAttribute(SccProjectList.IN_WORKAREA_ATTR, workArea);

                                    list.createObject(newMarkerDetails, Utils.subMonitorFor(monitor, 10));
                                    workTodo -= 20;
                                    // now find the created object
                                    sccProject = list.findProject(offset);
                                }
                                remoteProjectToManage = sccProject;
                            }
                        }

                        if (remoteProject instanceof WorksetAdapter) {
                            WorksetAdapter worksetAdapter = (WorksetAdapter) remoteProject;
                            if (isAdd2FavoriteList()) {
                                if (worksetAdapter instanceof IFavouriteObject) {
                                    List<IFavouriteObject> adding = Collections
                                            .singletonList((IFavouriteObject) worksetAdapter);
                                    DimensionsConnectionDetailsEx conn = adding.get(0).getConnectionDetails();
                                    FavouriteProjectsList list = WorksetList.getFavouriteProjectsList(conn,
                                            conn.isOnlyStreamsActive(), conn.isOnlyProjectsActive());
                                    list.addFavourites(adding, monitor);
                                }
                            }
                        }

                        Assert.isNotNull(remoteProjectToManage, Messages.SharingWizard_projectNotFound);

                        DMTeamPlugin.getWorkspace().manage(project, null, remoteProjectToManage,
                                Utils.isNullEmpty(workArea) ? null : new Path(workArea));

                        // hide metadata
                        if (remoteProjectToManage instanceof SccProject
                                && remoteProjectToManage.getAPIObject() instanceof ItemRevision) {

                            MetadataProvider mdProvider = MetadataProviderFactory.providerFor(project);
                            try {
                                if (!StringPath.isNullorEmpty(workArea)) {
                                    MetadataHelper.hideMetadataHierarchy(project.getLocation(), new Path(workArea),
                                            mdProvider);
                                } else {
                                    IFolder mdFolder = null;
                                    mdFolder = project.getFolder(new Path(mdProvider.metadataDirname()));

                                    if (mdFolder != null && mdFolder.exists()) {
                                        ResourceAttributes resAttributes = mdFolder.getResourceAttributes();
                                        if (resAttributes != null) {
                                            resAttributes.setHidden(true);
                                            mdFolder.setResourceAttributes(resAttributes);
                                        }
                                    }
                                }
                            } finally {
                                if (mdProvider != null) {
                                    mdProvider.close();
                                }
                            }
                        }

                        canDismiss[0] = true; // dismiss the wizard if mapping succeeded

                        DMTeamPlugin.getWorkspace().getSubscriber().refresh(resources, IResource.DEPTH_INFINITE,
                                Utils.subMonitorFor(monitor, workTodo, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK));

                        refreshOk[0] = true;
                    } catch (CoreException e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
            return canDismiss[0];
        } catch (InterruptedException e) {
            return false;
        }

        SharingSummaryPage summaryPage = (SharingSummaryPage) getPage(SUMMARY_PAGE);
        if (summaryPage.openSync()) {
            DMSynchronizeParticipant participant = (DMSynchronizeParticipant) SubscriberParticipant
                    .getMatchingParticipant(DMWorkspaceSynchronizeParticipant.ID, resources);
            ResourceScope scope = new ResourceScope(resources);
            if (participant == null) {
                try {
                    if (TeamUtils.isAnyResourceFromStream(resources)) {
                        TeamUIUtils.removeParticipantById(DMWorkspaceSynchronizeParticipant.ID);
                        participant = new DMWorkspaceStreamOutgoingParticipant(scope);
                    } else {
                        TeamUIUtils.removeParticipantById(DMWorkspaceStreamOutgoingParticipant.ID);
                        participant = new DMWorkspaceSynchronizeParticipant(scope);
                    }
                } catch (TeamException e) {
                    DMTeamUiPlugin.log(e.getStatus());
                    return false;
                }
                TeamUI.getSynchronizeManager().addSynchronizeParticipants(new ISynchronizeParticipant[] { participant });
            }
            // subscriber was just refreshed - simply show our participant
            ISynchronizeView view = TeamUI.getSynchronizeManager().showSynchronizeViewInActivePage();
            if (view != null) {
                view.display(participant);
            }
        }

        // avoid to open add wizard if failed to get latest status as it may suggest to add files which have remote
        if (refreshOk[0] && summaryPage.addFiles()) {
            try {
                IDMWorkspaceFolder dmFolder = (IDMWorkspaceFolder) DMTeamPlugin.getWorkspace().getWorkspaceResource(project);
                if (!dmFolder.containsUnmanaged(true)) {
                    MessageDialog.openInformation(getShell(), Messages.SharingWizard_nothingToAddTitle,
                            Messages.SharingWizard_nothingToAddMessage);
                    return true;
                }
            } catch (CoreException e1) {
                DMTeamUiPlugin.getDefault().handle(e1);
                return true;
            }
            openAddWizard(resources);
        }
        return true;
    }

    private String getProjectName() {
        if (project != null) {
            return project.getName();
        }
        if (getMode() == Mode.TOPIC_STREAM) {
            NewStreamTopicWorkareaPage page = (NewStreamTopicWorkareaPage) getPage(STREAM_TOPIC_WORKAREA_PAGE);
            return page.getStreamName();
        } 
        NewStreamGeneralPage page = (NewStreamGeneralPage) getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE);
        return page.getStreamName();
    }

    @Override
    public boolean canFinish() {
        if (hasValidConnection()) {
            // Added "WORKSET_PAGE_ID" page complete check as part of DEF173775 fix.
            return createNewProject
                    ? super.canFinish() : (getPage(OFFSET_PAGE).isPageComplete() && getPage(WORKSET_PAGE_ID).isPageComplete()
                            && getPage(GENERIC_REQUEST_PAGE).isPageComplete());
        }
        return false;
    }

    @Override
    public void init(IWorkbench workbench, IProject project) {
        this.project = project;
    }

    private void openAddWizard(final IResource[] resources) {
        // open add wizard asynchronously so that this wizard is closed
        UIJob openAddJob = new UIJob(Messages.SharingWizard_addJobName) {
            @Override
            public IStatus runInUIThread(IProgressMonitor monitor) {
                monitor.beginTask(null, IProgressMonitor.UNKNOWN);
                monitor.subTask(Messages.SharingWizard_addJobSubtask);
                IWorkbenchPart activePart = PlatformUI.getWorkbench()
                        .getActiveWorkbenchWindow()
                        .getActivePage()
                        .getActivePart();
                IDMProject dmProject;
                UploadOperation addToRemoteOperation;
                DeliverOperation addToStreamRemoteOperation;

                try {
                    dmProject = DMTeamPlugin.getWorkspace().getProject(resources[0]);
                    if (dmProject.getIsStream()) {
                        addToStreamRemoteOperation = new DeliverOperation(activePart, resources, IDMProject.ADD_FILTER);
                        if (addToStreamRemoteOperation.prompt()) {
                            addToStreamRemoteOperation.run();
                        }
                    } else {
                        addToRemoteOperation = new UploadOperation(activePart, resources, IDMProject.ADD_FILTER);
                        if (addToRemoteOperation.prompt()) {
                            addToRemoteOperation.run();
                        }
                    }

                } catch (InvocationTargetException e) {
                    return DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.SharingWizard_errorTitle,
                            e.getTargetException());
                } catch (InterruptedException ignore) {
                } catch (CoreException ce) {

                } finally {
                    monitor.done();
                }
                return Status.OK_STATUS;
            }
        };
        openAddJob.schedule();
    }

    private DimensionsIDEProject createNewProject(final ProjectDetails worksetDetails, final IProgressMonitor monitor)
            throws DMException {
        final DimensionsIDEProject[] result = new DimensionsIDEProject[1];
        try {
            monitor.beginTask(null, 100);
            final WorksetList worksetList = WorksetList.getDimensionsIDEProjectsList(getConnection(), false, false);
            worksetList.createObject(worksetDetails,
                    Utils.subMonitorFor(monitor, 60, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK));
            final Session session = getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    Project workset = session.getObjectFactory().getProject(DMTypeScope.PROJECT.getObjectId(worksetDetails));
                    monitor.worked(20);
                    int[] attrs = WorksetList.DEFAULT_ATTRIBUTES;
                    workset.queryAttribute(attrs);
                    monitor.worked(20);
                    String ideProject = (String) workset.getAttribute(SystemAttributes.IDE_PROJECT_NAME);
                    Long uid = (Long) workset.getAttribute(SystemAttributes.IDE_DM_UID);
                    result[0] = new DimensionsIDEProject(workset, getConnection(), IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG,
                            ideProject, String.valueOf(uid));
                }
            }, monitor);
        } finally {
            monitor.done();
        }
        return result[0];
    }

    private SccProjectContainerWorkset createNewContainer(final ProjectDetails worksetDetails,
            final IProgressMonitor monitor) throws DMException {
        final SccProjectContainerWorkset[] result = new SccProjectContainerWorkset[1];
        try {
            monitor.beginTask(null, 100);
            final WorksetList worksetList = WorksetList.getSccProjectContainerList(getConnection(), false, false);
            worksetList.createObject(worksetDetails,
                    Utils.subMonitorFor(monitor, 60, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK));
            final Session session = getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    Project workset = session.getObjectFactory().getProject(DMTypeScope.PROJECT.getObjectId(worksetDetails));
                    monitor.worked(20);
                    int[] attrs = WorksetList.DEFAULT_ATTRIBUTES;
                    workset.queryAttribute(attrs);
                    monitor.worked(20);
                    result[0] = new SccProjectContainerWorkset(workset, getConnection(),
                            IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG);
                }
            }, monitor);
        } finally {
            monitor.done();
        }
        return result[0];
    }

    private ItemRevisionDetails getMarkerDetails(String offset, String partId, IProgressMonitor monitor) throws DMException {
        final Session session = getConnection().openSession(null);
        final String product = getProductName();
        IPath offPath = new Path(offset);

        final IPath wsFilename = offPath.append(project.getName()).addFileExtension(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER);

        // part id is in format id.var
        String owningVariant = partId.substring(partId.indexOf('.') + 1, partId.indexOf(';'));
        String partSpec = product + ":" + partId; //$NON-NLS-1$

        final ItemRevisionDetails result = new ItemRevisionDetails();
        result.setProductName(product);
        result.setTypeName(IDMConstants.TYPE_PROJECT);
        result.setFormat(IDMConstants.SCC_ECLIPSE_PROJECT_MARKER.toUpperCase()); // force the format
        result.setOwningPartSpecification(partSpec);
        result.setVariant(owningVariant);
        result.setComment(Messages.sharingWizard_markerComment);
        result.setDescription(NLS.bind(Messages.sharingWizard_markerDescription, project.getName()));
        result.setProjectFileName(wsFilename.toOSString());
        result.setRelatedRequests(relatedRequest);

        result.setAttribute(SccProjectList.IN_USERDIR_ATTR, project.getLocation().toOSString());
        result.setAttribute(SccProjectList.IN_OFFSET_ATTR, offPath.toOSString());

        try {
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws DMException {
                    DimensionsObjectFactory fact = session.getObjectFactory();
                    // get the ItemId
                    // no seed
                    String cmd = "XDATA NEW_ITEMID /PARAM=(PRODUCT_ID=";//$NON-NLS-1$
                    cmd += product;
                    cmd += ",ITEM_TYPE="; //$NON-NLS-1$
                    cmd += IDMConstants.TYPE_PROJECT;
                    cmd += ",USER_FILENAME="; //$NON-NLS-1$
                    cmd += wsFilename.lastSegment();
                    cmd += ")"; //$NON-NLS-1$

                    DimensionsResult res = fact.runCommand(cmd);
                    if (res != null) {
                        String mess = res.getMessage();
                        int colonindex = mess.indexOf(':');
                        int nlindex = mess.indexOf('\n');
                        result.setItemId(mess.substring(colonindex + 2, nlindex));
                    }
                    // get the libfilename

                    cmd = "XDATA NEW_LIBFILENAME /PARAM=(IDE_UID="; //$NON-NLS-1$
                    cmd += Integer.toString(0); // TODO use real UID or 0
                    cmd += ",USER_FILENAME="; //$NON-NLS-1$
                    cmd += wsFilename.lastSegment();
                    cmd += ")"; //$NON-NLS-1$
                    res = fact.runCommand(cmd);
                    if (res != null) {
                        String mess = res.getMessage();
                        int colonindex = mess.indexOf(':');
                        int nlindex = mess.indexOf('\n');

                        result.setLibraryFileName(mess.substring(colonindex + 2, nlindex));
                    }
                }
            }, monitor);
        } finally {
            monitor.done();
        }

        return result;
    }

    @Override
    public String getProductName() {
        if (createNewProject) {
            return super.getProductName();
        }

        if (null != remoteProject) {
            String spec = remoteProject.getProjectSpec();
            int idx = spec.indexOf(":"); //$NON-NLS-1$
            if (-1 != idx) {
                return spec.substring(0, idx);
            }
        }
        return null;
    }

    public boolean isStream() {
        return isStream;
    }

    public Project getContainerProject() {
        return (!inContainer || null == remoteProject || remoteProject instanceof SccProject)
                ? null : (Project) remoteProject.getAPIObject();
    }
}

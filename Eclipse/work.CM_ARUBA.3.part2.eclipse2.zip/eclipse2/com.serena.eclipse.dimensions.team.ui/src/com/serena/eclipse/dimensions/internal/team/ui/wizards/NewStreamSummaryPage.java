/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.List;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectDetails;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.atts.AttributeEntry;
import com.serena.eclipse.dimensions.internal.ui.atts.MVAttributeEntry;
import com.serena.eclipse.dimensions.internal.ui.atts.SVAttributeEntry;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewStreamWizard;

public class NewStreamSummaryPage extends DimensionsWizardPage {
    private List lstList;

    public NewStreamSummaryPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(description);
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        UIUtils.createLabel(composite, Messages.NewStreamWizard_summary_lblClickToFinish);

        lstList = new List(composite, SWT.SINGLE | SWT.READ_ONLY | SWT.V_SCROLL | SWT.H_SCROLL | SWT.BORDER);
        UIUtils.setGridData(lstList, GridData.FILL_BOTH);

        setControl(composite);
    }

    public void initializeControlData(DimensionsIDEProjectDetails details, AttributeEntry[] attrEntries) {
        lstList.removeAll();
        String[] messArgs = new String[3];

        if (details.getIsStream()) {
            messArgs[0] = details.getProductName();
            messArgs[1] = details.getName();
            
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_stream1, messArgs));
            
            lstList.add(Utils.EMPTY_STRING);

            if (!Utils.isNullEmpty(details.getDescription())) {
                messArgs[0] = details.getDescription();
                lstList.add(NLS.bind(Messages.NewStreamWizard_summary_stream2, messArgs));
                lstList.add(Utils.EMPTY_STRING);
            }

            addBasedOnStreamOrProjectInfo(details, messArgs);

            messArgs[0] = details.getDefaultBranch();
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_stream4, messArgs));
            lstList.add(Utils.EMPTY_STRING);

            if (ProjectDetails.PROJECT_CM_RULES_ON == details.getCMRulesFlag()) {
                messArgs[0] = Messages.NewStreamWizard_summary_stream5_enabled;
            } else {
                messArgs[0] = Messages.NewStreamWizard_summary_stream5_disabled;
            }
            
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_stream5, messArgs));

        } else {
            messArgs[0] = details.getProductName();
            messArgs[1] = details.getTypeName();
            messArgs[2] = details.getName();
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project1, messArgs));
            lstList.add(Utils.EMPTY_STRING);

            messArgs[0] = details.getDescription();
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project2, messArgs));
            lstList.add(Utils.EMPTY_STRING);

            addBasedOnStreamOrProjectInfo(details, messArgs);

            messArgs[0] = details.getBranchFlag() ? Utils.EMPTY_STRING : Messages.NewStreamWizard_summary_project4_not + " ";
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project4, messArgs));
            lstList.add(Utils.EMPTY_STRING);

            messArgs[0] = details.getNewRevisionForcedFlag() ? Utils.EMPTY_STRING : Messages.NewStreamWizard_summary_project5_not
                    + " ";
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project5, messArgs));
            lstList.add(Utils.EMPTY_STRING);

            switch (details.getCMRulesFlag()) {
            case ProjectDetails.PROJECT_CM_RULES_DEFAULT:
                messArgs[0] = Messages.NewStreamWizard_summary_project6_inherited;
                break;
            case ProjectDetails.PROJECT_CM_RULES_ON:
                messArgs[0] = Messages.NewStreamWizard_summary_project6_enabled;
                break;
            case ProjectDetails.PROJECT_CM_RULES_OFF:
                messArgs[0] = Messages.NewStreamWizard_summary_project6_disabled;
            }
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project6, messArgs));
            lstList.add(Utils.EMPTY_STRING);

            messArgs[0] = details.getRequestRequiredToRefactorFlag()
                    ? Messages.NewStreamWizard_summary_project7_require : Messages.NewStreamWizard_summary_project7_notrequire;
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project7, messArgs));
            lstList.add(Utils.EMPTY_STRING);

            if (null != details.getBranchList() && null != details.getDefaultBranch()) {
                lstList.add(Utils.EMPTY_STRING);
                messArgs[0] = Utils.EMPTY_STRING;
                messArgs[1] = Utils.EMPTY_STRING;
                for (int i = 0; i < details.getBranchList().size(); i++) {
                    if (messArgs[0].equals(Utils.EMPTY_STRING)) {
                        messArgs[0] += details.getBranchList().get(i);
                    } else {
                        messArgs[0] += ", " + details.getBranchList().get(i);
                    }
                }
                lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project10, messArgs));

                messArgs[0] = details.getDefaultBranch();
                lstList.add(NLS.bind(Messages.NewStreamWizard_summary_project11, messArgs));
            }
        }

        if (null != attrEntries) {
            lstList.add(Utils.EMPTY_STRING);
            lstList.add(details.getIsStream()
                    ? Messages.NewStreamWizard_summary_stream6 : Messages.NewStreamWizard_summary_project12);

            for (int i = 0; i < attrEntries.length; i++) {
                if (attrEntries[i] instanceof SVAttributeEntry) {
                    SVAttributeEntry ent = (SVAttributeEntry) attrEntries[i];
                    if (!ent.getValue().getStringValue().equals(Utils.EMPTY_STRING)) {
                        lstList.add(ent.getName() + " = " + ent.getValue().getStringValue());
                    }
                }
                if (attrEntries[i] instanceof MVAttributeEntry) {
                    MVAttributeEntry ent = (MVAttributeEntry) attrEntries[i];
                    String val = ent.getName() + " = [";
                    boolean valFound = false;
                    for (int j = 0; j < ent.getValues().length; j++) {
                        String[] vals = ent.getValues()[j].getValues();
                        for (int z = 0; z < vals.length; z++) {
                            if (!vals[z].equals(Utils.EMPTY_STRING)) {
                                valFound = true;
                            }
                            val += "\"" + vals[z] + "\"";
                            if (z < vals.length - 1) {
                                val += ", ";
                            }
                        }
                        if (j < ent.getValues().length - 1) {
                            val += ", ";
                        }
                    }
                    val += "]";
                    if (valFound) {
                        lstList.add(val);
                    }
                }
            }
        }
    }

    private void addBasedOnStreamOrProjectInfo(DimensionsIDEProjectDetails details, String[] messArgs) {
        boolean hasBasedOn = false;
        
        if (null != details.getBasedOnProject()) {
            hasBasedOn = true;
            if (Boolean.TRUE.equals((Boolean) ((NewStreamWizard) getWizard()).getBaseOnObject().getAPIObject()
                    .getAttribute(SystemAttributes.WSET_IS_STREAM))) {
                messArgs[1] = Messages.NewStreamWizard_summary_stream3_stream;
            } else {
                messArgs[1] = Messages.NewStreamWizard_summary_project3_project;
            }
            messArgs[2] = details.getBasedOnProject();
        } else if (null != details.getBasedOnBaseline()) {
            hasBasedOn = true;
            messArgs[1] = Messages.NewStreamWizard_summary_stream3_baseline;
            messArgs[2] = details.getBasedOnBaseline();
        }
        
        if (hasBasedOn) {
            if (details.getIsStream()) {
                messArgs[0] = Messages.NewStreamWizard_summary_stream3_stream;
            } else {
                messArgs[0] = Messages.NewStreamWizard_summary_project3_project;
            }
            lstList.add(NLS.bind(Messages.NewStreamWizard_summary_basedOnInfo, messArgs));
            lstList.add(Utils.EMPTY_STRING);
        }
    }
}

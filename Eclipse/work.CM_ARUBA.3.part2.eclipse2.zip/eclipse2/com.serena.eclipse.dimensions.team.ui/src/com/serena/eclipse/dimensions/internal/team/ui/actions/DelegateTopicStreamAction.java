package com.serena.eclipse.dimensions.internal.team.ui.actions;

import org.eclipse.jface.action.IAction;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.DelegateTopicStreamDialog;

public class DelegateTopicStreamAction extends DimensionsAction {

    @Override
    public void run(IAction action) {
        WorksetAdapter workset = (WorksetAdapter) getSelection().getFirstElement();
        DelegateTopicStreamDialog dialog = new DelegateTopicStreamDialog(getShell(), workset);
        dialog.open();
    }
}

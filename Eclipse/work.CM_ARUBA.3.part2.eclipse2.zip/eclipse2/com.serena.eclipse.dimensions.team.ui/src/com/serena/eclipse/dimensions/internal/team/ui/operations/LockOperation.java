/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.ArrayList;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.LockHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.LockWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;

public class LockOperation extends WizardOperation {
    private boolean isLock = false; // true for locking, false otherwise

    public LockOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter, boolean isLock) {
        super(part, resources, filter);
        this.isLock = isLock;
    }

    @Override
    protected ISchedulingRule getSchedulingRule(DMRepositoryProvider provider) throws CoreException {
        return super.getSchedulingRule(provider);
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind((isLock ? Messages.LockOperation_lock_taskNameProvider : Messages.LockOperation_unlock_taskNameProvider),
                provider.getProject().getName());
    }

    @Override
    protected String getTaskName() {
        return (isLock ? Messages.LockOperation_lock_taskName : Messages.LockOperation_unlock_taskName);
    }

    @Override
    protected void execute(OperationData data, IProgressMonitor monitor) throws CoreException, InterruptedException {
        DMRepositoryProvider provider = data.getProvider();
        WorkspaceResourceRequest[] requests = data.getRequestsArray();

        if (requests == null || requests.length == 0) {
            return;
        }

        final ArrayList<IResource> includedResources = new ArrayList<IResource>();
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(getTaskName(provider), 10 * requests.length);
        try {
            for (int i = 0; i < requests.length; i++) {
                IDMWorkspaceFile dmFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(
                        requests[i].getResource());
                if (isLock) {
                    dmFile.getRemoteFile().getItemRevision().lockLatestRevision();
                } else {
                    dmFile.getRemoteFile().getItemRevision().unlockLatestRevision();
                }

                includedResources.add(requests[i].getResource());
                monitor.worked(10);
            }
        } catch (Exception e) {
            DMUIPlugin.getDefault().handle(e);
        } finally {
            monitor.done();
        }
        // Refreshing status for all successfully handled
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.RefreshStatusOperation_0, 100);
        try {
            DMTeamPlugin.getWorkspace()
                    .getSubscriber()
                    .refresh(includedResources.toArray(new IResource[includedResources.size()]), IResource.DEPTH_ZERO, monitor);
        } catch (Exception e) {
            DMUIPlugin.getDefault().handle(e);
        } finally {
            monitor.done();
        }
    }

    @Override
    protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            DMTeamPlugin.getWorkspace()
                    .getSubscriber()
                    .refresh(getResources(), IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, 500));
            return new LockHelper(getResources(), getFilter(), Utils.subMonitorFor(monitor, 500));
        } finally {
            monitor.done();
        }
    }

    @Override
    protected TeamOperationWizard createWizard(TeamOperationWizardHelper helper) {
        return new LockWizard((LockHelper) helper, isLock);
    }

}

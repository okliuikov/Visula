package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;

import com.serena.eclipse.dimensions.internal.team.core.CreateFolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.CreateItemRequest;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DeleteFolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.DeleteItemRevisionRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.IMoveRequest;
import com.serena.eclipse.dimensions.internal.team.core.MoveFolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.MoveItemRequest;
import com.serena.eclipse.dimensions.internal.team.core.UploadRequest;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.MoveHelper;

/**
 * Creates requests for commit operation
 */
abstract class CommitRequestsProcessor {
    private DMWorkspaceCommitHelper commitHelper;
    private boolean override;

    // note that additions will be empty as now they end up in changes
    private List<UploadRequest> changes = new ArrayList<UploadRequest>();
    private List<DeleteItemRevisionRequest> deletions = new ArrayList<DeleteItemRevisionRequest>();
    private List<CreateItemRequest> additions = new ArrayList<CreateItemRequest>();
    private List<CreateFolderRequest> folderAdditions = new ArrayList<CreateFolderRequest>();
    private List<DeleteFolderRequest> folderDeletions = new ArrayList<DeleteFolderRequest>();
    private List<IMoveRequest> moves = new ArrayList<IMoveRequest>();
    private List<MoveFolderRequest> folderMoves = new ArrayList<MoveFolderRequest>();
    private List<MoveItemRequest> itemMoves = new ArrayList<MoveItemRequest>();

    public CommitRequestsProcessor(DMWorkspaceCommitHelper commitHelper, boolean override) {
        super();
        this.commitHelper = commitHelper;
        this.override = override;
    }

    public List<WorkspaceResourceRequest> getRequestsForCommit(SyncData data) throws CoreException {
        DMRepositoryProvider provider = data.getProvider();
        SyncInfoSet set = data.getSyncInfoSet();
        if (set.isEmpty()) {
            return Collections.emptyList();
        }

        SyncInfo[] infos = set.getSyncInfos();
        for (int i = 0; i < infos.length; i++) {
            SyncInfo node = infos[i];
            WorkspaceResourceRequest request = getCommitHelper().getRequest(node.getLocal());
            if (request instanceof UploadRequest) {
                getChanges().add((UploadRequest) request);
                if (isOverride()) {
                    ((UploadRequest) request).setMode(UploadRequest.FORCE_TIP);
                }
            } else if (request instanceof DeleteItemRevisionRequest) {
                getDeletions().add((DeleteItemRevisionRequest) request);
            } else if (request instanceof CreateItemRequest) {
                getAdditions().add((CreateItemRequest) request);
            } else if (request instanceof CreateFolderRequest) {
                getFolderAdditions().add((CreateFolderRequest) request);
            } else if (request instanceof DeleteFolderRequest) {
                getFolderDeletions().add((DeleteFolderRequest) request);
            } else if (request instanceof IMoveRequest && request.getResource().exists()) {
                if (request instanceof MoveFolderRequest) {
                    getFolderMoves().add((MoveFolderRequest) request);
                }
                if (request instanceof MoveItemRequest) {
                    getItemMoves().add((MoveItemRequest) request);
                }
                getMoves().add((IMoveRequest) request);
            } else {
                throw new IllegalArgumentException();
            }
        }

        // add changed resources that are to be moved prior to upload, if any
        if (getCommitHelper().getChangeMoveHelper() != null) {
            MoveHelper chgMoveHelper = getCommitHelper().getChangeMoveHelper();
            IResource[] chgMoveResources = chgMoveHelper.getOperationResources();
            for (int j = 0; j < chgMoveResources.length; j++) {
                // filter out resources not in the project being delivered to
                if (!chgMoveResources[j].getProject().equals(provider.getProject())) {
                    continue;
                }
                WorkspaceResourceRequest moveRequest = chgMoveHelper.getRequest(chgMoveResources[j]);
                if (moveRequest instanceof IMoveRequest && moveRequest.getResource().exists()) {
                    if (moveRequest instanceof MoveFolderRequest) {
                        getFolderMoves().add((MoveFolderRequest) moveRequest);
                    }
                    if (moveRequest instanceof MoveItemRequest) {
                        getItemMoves().add((MoveItemRequest) moveRequest);
                    }
                    getMoves().add((IMoveRequest) moveRequest);
                }
            }
        }

        return getRequestsForCommit();
    }

    protected abstract List<WorkspaceResourceRequest> getRequestsForCommit() throws CoreException;

    public int getAllRequestsCount() {
        return getChanges().size() + getAdditions().size() + getDeletions().size() + getMoves().size()
                + getFolderAdditions().size() + getFolderDeletions().size();
    }

    /**
     * @return the changes
     */
    public List<UploadRequest> getChanges() {
        return changes;
    }

    /**
     * @param changes the changes to set
     */
    protected void setChanges(List<UploadRequest> changes) {
        this.changes = changes;
    }

    /**
     * @return the deletions
     */
    public List<DeleteItemRevisionRequest> getDeletions() {
        return deletions;
    }

    /**
     * @param deletions the deletions to set
     */
    protected void setDeletions(List<DeleteItemRevisionRequest> deletions) {
        this.deletions = deletions;
    }

    /**
     * @return the additions
     */
    public List<CreateItemRequest> getAdditions() {
        return additions;
    }

    /**
     * @param additions the additions to set
     */
    protected void setAdditions(List<CreateItemRequest> additions) {
        this.additions = additions;
    }

    /**
     * @return the folderAdditions
     */
    public List<CreateFolderRequest> getFolderAdditions() {
        return folderAdditions;
    }

    /**
     * @param folderAdditions the folderAdditions to set
     */
    protected void setFolderAdditions(List<CreateFolderRequest> folderAdditions) {
        this.folderAdditions = folderAdditions;
    }

    /**
     * @return the folderDeletions
     */
    public List<DeleteFolderRequest> getFolderDeletions() {
        return folderDeletions;
    }

    /**
     * @param folderDeletions the folderDeletions to set
     */
    protected void setFolderDeletions(List<DeleteFolderRequest> folderDeletions) {
        this.folderDeletions = folderDeletions;
    }

    /**
     * @return the moves
     */
    public List<IMoveRequest> getMoves() {
        return moves;
    }

    /**
     * @return the itemMoves
     */
    protected List<MoveItemRequest> getItemMoves() {
        return itemMoves;
    }

    /**
     * @return the folderMoves
     */
    protected List<MoveFolderRequest> getFolderMoves() {
        return folderMoves;
    }

    /**
     * @return the commitHelper
     */
    protected DMWorkspaceCommitHelper getCommitHelper() {
        return commitHelper;
    }

    /**
     * @param commitHelper the commitHelper to set
     */
    protected void setCommitHelper(DMWorkspaceCommitHelper commitHelper) {
        this.commitHelper = commitHelper;
    }

    /**
     * @return the override
     */
    protected boolean isOverride() {
        return override;
    }

    /**
     * @param override the override to set
     */
    protected void setOverride(boolean override) {
        this.override = override;
    }

    protected static void removeContentsOfParentFromMoveList(List<MoveFolderRequest> folderMoves, List<MoveItemRequest> itemMoves,
            List<IMoveRequest> moves) {

        List<IMoveRequest> tempResourcesMoved = new ArrayList<IMoveRequest>();
        IDMProject targetProject = null;

        for (int i = 0; i < folderMoves.size(); i++) {
            MoveFolderRequest folderRequest = folderMoves.get(i);
            // Get list of items of a parent being moved
            for (int j = 0; j < itemMoves.size(); j++) {
                MoveItemRequest itemRequest = itemMoves.get(j);
                IResource itemResource = itemRequest.getResource();

                // possible implicit move as result of parent move
                if (folderRequest.getResource().equals(itemResource.getParent())) {
                    try {
                        // check for imported items that were moved as a result of parent move
                        boolean modified = DMTeamPlugin.getWorkspace().isModified(itemResource);
                        if (!modified) {
                            // modified items will be processed like changes
                            if (targetProject == null) {
                                targetProject = DMTeamPlugin.getWorkspace().getProject(itemResource);
                            }

                            // applicable only for stream case
                            if (targetProject != null && targetProject.getIsStream()) {
                                long homeUid = targetProject.getDimensionsObject().getUid();
                                IDMRemoteResource baseResource = DMTeamPlugin.getWorkspace().getBaseResource(itemResource);
                                if (baseResource instanceof IDMRemoteFile) {
                                    IDMRemoteFile file = (IDMRemoteFile) baseResource;
                                    long projectUid = file.getProjectUid();

                                    // check if item was imported and skip such cases
                                    if (projectUid != -1 && projectUid != homeUid) {
                                        continue;
                                    }
                                }
                            }
                        }
                        // not equal 1 means child resource was moved inside moved hierarchy - this move should be preserved
                        // not equal 2 means child resource was renamed - this move should be preserved
                        if (!folderRequest.getSource().equals(itemRequest.getSource().getParent())
                                || !itemResource.getName().equals(itemRequest.getSource().getName())) {
                            continue;
                        }
                    } catch (CoreException swallow) {
                        // swallow exception
                    }
                    tempResourcesMoved.add(itemMoves.get(j));
                }
            }
            // Get list of subfolders of a parent being moved
            for (int k = 0; k < folderMoves.size(); k++) {
                MoveFolderRequest childFolderRequest = folderMoves.get(k);
                if (folderRequest.getResource().equals(childFolderRequest.getResource().getParent())) {
                    // possible implicit move as result of parent move

                    try {
                        // not equal 1 means child resource was moved inside moved hierarchy - this move should be preserved
                        // not equal 2 means child resource was renamed - this move should be preserved
                        if (!folderRequest.getSource().equals(childFolderRequest.getSource().getParent())
                                || !childFolderRequest.getResource().getName().equals(childFolderRequest.getSource().getName())) {
                            continue;
                        }
                    } catch (CoreException swallow) {
                        // swallow exception
                    }
                    tempResourcesMoved.add(folderMoves.get(k));
                }

            }
        }
        moves.removeAll(tempResourcesMoved);
    }

    protected static void removeMovedAndModifiedFilesFromChangeList(List<UploadRequest> changes, List<IMoveRequest> moves) {
        List<UploadRequest> tempChanges = new ArrayList<UploadRequest>();
        String movedFilePath = null;
        String modifiedFilePath = null;
        for (int i = 0; i < moves.size(); i++) {
            if (moves.get(i) instanceof MoveItemRequest) {
                for (int j = 0; j < changes.size(); j++) {
                    movedFilePath = null;
                    modifiedFilePath = null;
                    movedFilePath = (((MoveItemRequest) (moves.get(i))).getResource()).getLocation().toOSString();
                    modifiedFilePath = ((changes.get(j)).getResource()).getLocation().toOSString();
                    if (movedFilePath.equals(modifiedFilePath)) {
                        tempChanges.add(changes.get(j));
                        break;
                    }
                }
            }
        }
        changes.removeAll(tempChanges);
    }

    protected static void removeDeletedItemsFromDeleteList(List<DeleteItemRevisionRequest> deleteItemList,
            List<DeleteFolderRequest> deleteFolderList) {
        List<DeleteItemRevisionRequest> tempItemsDeleted = new ArrayList<DeleteItemRevisionRequest>();
        for (int i = 0; i < deleteFolderList.size(); i++) {
            for (int j = 0; j < deleteItemList.size(); j++) {
                if (((deleteFolderList.get(i)).getResource()).equals(((deleteItemList.get(j)).getResource()).getParent())) {
                    tempItemsDeleted.add(deleteItemList.get(j));
                }
            }
        }
        deleteItemList.removeAll(tempItemsDeleted);
    }

}
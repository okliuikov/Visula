package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.serena.eclipse.dimensions.internal.team.ui.UserInfo;

public class StringFilter extends ViewerFilter {

    private String searchString;
    private String userInput = "";

    public String getUserInput() {
        return userInput;
    }

    public void setSearchText(String s) {
        userInput = s;
        updateSearchString();
    }

    private void updateSearchString() {
        if (userInput == null || userInput.length() == 0)
            searchString = null;
        else
            searchString = "(?i:.*" + userInput + ".*)";
    }

    public void appendToSearchString(char character) {
        userInput += character;
        updateSearchString();
    }

    public void clearSearchString() {
        userInput = "";
        updateSearchString();
    }

    @Override
    public boolean select(Viewer viewer, Object parentElement, Object element) {
        if (searchString == null || searchString.length() == 0) {
            return true;
        }
        UserInfo info = (UserInfo) element;
        return info.displayText.matches(searchString);
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.operations.AddMultipleProjectsToWorkspaceOperation;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsNewWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Global new wizard that adds projects and baselines to workspace.
 * @author V.Grishchenko
 */
public class ProjectImportWizard extends DimensionsNewWizard {
    private static final String SELECTION_PAGE = "selection_page"; //$NON-NLS-1$
    private MultiProjectSelectionPage projectSelectionPage;

    public ProjectImportWizard() {
        setWindowTitle(Messages.ProjectImportWizard_Window_title);
    }

    public ProjectImportWizard(DimensionsConnectionDetailsEx connection) {
        super(connection);
        setWindowTitle(Messages.ProjectImportWizard_Window_title);
    }

    public ProjectImportWizard(DimensionsConnectionDetailsEx connection, FormToolkit toolkit) {
        super(connection, toolkit);
    }

    @Override
    public void addPages() {
        super.addPages();
        projectSelectionPage = new MultiProjectSelectionPage(SELECTION_PAGE, Messages.ProjectImportWizard_SelectionPage_title,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                Messages.ProjectImportWizard_SelectionPage_description);
        projectSelectionPage.setConnection(getConnection());
        addPage(projectSelectionPage);
    }

    @Override
    public boolean canFinish() {
        return hasValidConnection() && getContainer().getCurrentPage() == projectSelectionPage
                && projectSelectionPage.isPageComplete();
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page, boolean aboutToShow) {
        IWizardPage nextPage = super.getNextPage(page, aboutToShow);
        if (nextPage == projectSelectionPage && aboutToShow) {
            projectSelectionPage.setConnection(getConnection());
        }
        return nextPage;
    }

    @Override
    public boolean performFinish() {
        if (!super.performFinish()) {
            return false;
        }
        List selection = projectSelectionPage.getSelection();
        AddMultipleProjectsToWorkspaceOperation operation = new AddMultipleProjectsToWorkspaceOperation(null,
                (VersionManagementProject[]) selection.toArray(new VersionManagementProject[selection.size()]), null);
        try {
            if (!operation.prompt()) {
                return true;
            }
            operation.run();
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e);
            return false;
        } catch (InterruptedException e) {
        }
        return true;
    }

}

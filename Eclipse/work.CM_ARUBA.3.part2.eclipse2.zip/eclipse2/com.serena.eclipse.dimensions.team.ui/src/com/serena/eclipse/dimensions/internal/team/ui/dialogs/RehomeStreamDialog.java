package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolTip;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.WizardHelper;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.server.core.SpecialCharacters;
import merant.adm.dimensions.util.SpecUtils;

public class RehomeStreamDialog extends ResizableDialog {
	private Project targetProject;
	private List<String> invalidTargetProjectSpecs = new ArrayList<String>();
	private ToolTip toolTip;

	// UI
	private Label labelTargetProject;
	private Text txtTargetProjectSpec;
	private Button findWorksetButton;
	private Label imageLabel;
	private Label labelManyProjectsInfo;

	private IDMProject sourceProject;
	private IPath waToRehome;
	private List<IDMProject> projectsToRehome = new ArrayList<IDMProject>();
	private Label labelSourceProject;

	private Listener focusInlistener;
	private IDMProject[] workspaceProjects;

	public RehomeStreamDialog(Shell parent, IDMProject sourceProject, IDMProject[] workspaceProjects) throws DMException {
		super(parent);
		this.sourceProject = sourceProject;
		this.workspaceProjects = workspaceProjects;
		findMoreProjectsToRehome();
	}

	private String getFullTargetProjectSpec() {
		String spec = UIUtils.safeGetText(txtTargetProjectSpec);
		if (Utils.isNullEmpty(spec))
			return "";
		if (!Utils.isNullEmpty(SpecUtils.getProduct(spec))) {
			return spec;
		}
		return NLS.bind("{0}:{1}", sourceProject.getProduct(), spec);
	}
	
	public List<IDMProject> getProjectsToRehome() {
		return projectsToRehome;
	}

	public Project getTargetProject() {
		return targetProject;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		getShell().setText("Rehome Work Area");
		Composite composite = (Composite) super.createDialogArea(parent);

		labelSourceProject = new Label(composite, SWT.NONE);
		labelSourceProject.setText(NLS.bind("Rehome workspace project: {0}", sourceProject.getProject().getName()));

		Composite targetProjectComposite = new Composite(composite, SWT.NONE);

		GridLayout gridLayout = UIUtils.setGridLayout(targetProjectComposite, 3);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		UIUtils.setGridData(targetProjectComposite, GridData.FILL_HORIZONTAL);

		labelTargetProject = new Label(targetProjectComposite, SWT.NONE);
		labelTargetProject.setText(Messages.TargetProject);

		txtTargetProjectSpec = new Text(targetProjectComposite, SWT.BORDER);
		UIUtils.setGridData(txtTargetProjectSpec, GridData.FILL_HORIZONTAL);

		txtTargetProjectSpec.addVerifyListener(new VerifyListener() {
			@Override
			public void verifyText(VerifyEvent e) {
				e.text = e.text.toUpperCase();
			}
		});

		txtTargetProjectSpec.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				validateTargetProject(false);
			}
		});

		findWorksetButton = new Button(targetProjectComposite, SWT.NONE);
		findWorksetButton.setText(Messages.SelectWithThreeDots);
		findWorksetButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DimensionsConnectionDetailsEx connection = sourceProject.getConnection();
				FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), IDMConstants.PROJECT, connection,
						"", true, false, connection.isOnlyStreamsActive(), connection.isOnlyProjectsActive());
				if (dialog.open() != Window.OK || dialog.getFindResult().isEmpty()) {
					return;
				}
				List<?> objects = dialog.getFindResult().getObjects();
				targetProject = (Project) objects.get(0);
				txtTargetProjectSpec.setText(targetProject.getName());
				validateTargetProject(false);
			}
		});

		Composite infoComposite = new Composite(composite, SWT.NONE);
		UIUtils.setGridData(infoComposite, GridData.FILL_BOTH);
		gridLayout = UIUtils.setGridLayout(infoComposite, 2);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;

		imageLabel = new Label(infoComposite, SWT.LEFT | SWT.TOP);
		GridData gridData = new GridData(SWT.BEGINNING, SWT.BEGINNING, false, false);
		imageLabel.setLayoutData(gridData);
		imageLabel.setImage(JFaceResources.getImage(Dialog.DLG_IMG_MESSAGE_INFO));
		imageLabel.setVisible(false);

		labelManyProjectsInfo = new Label(infoComposite, SWT.WRAP | SWT.LEFT | SWT.TOP);
		gridData = new GridData();
		gridData.widthHint = 360;
		gridData.horizontalAlignment = GridData.FILL;
		gridData.grabExcessHorizontalSpace = true;

		labelManyProjectsInfo.setLayoutData(gridData);
		labelManyProjectsInfo.setVisible(false);

		toolTip = new ToolTip(getShell(), SWT.BALLOON | SWT.ICON_WARNING);
		toolTip.setAutoHide(false);
		
		if (projectsToRehome.size() > 1) {
			String projectWording = projectsToRehome.size() > 2 ? Messages.Projects : Messages.Project;
			String[] bindings = { Integer.toString(projectsToRehome.size() - 1), projectWording, sourceProject.getId(),
					waToRehome.toOSString() };
			labelManyProjectsInfo.setText(NLS.bind(Messages.MoreProjectsWillBeAlsoRehomed, bindings));
			labelManyProjectsInfo.setVisible(true);
			imageLabel.setVisible(true);
		}

		focusInlistener = new Listener() {
			@Override
			public void handleEvent(Event event) {
				hideTip();
			}
		};
		getShell().getParent().getDisplay().addFilter(SWT.FocusIn, focusInlistener);

		return composite;
	}

	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		super.createButtonsForButtonBar(parent);
		getButton(IDialogConstants.OK_ID).setText(Messages.Rehome);
	}

	@Override
	protected void okPressed() {
		if (!validateTargetProject()) {
			return;
		}
		super.okPressed();
	}

	@Override
	public boolean close() {
		hideTip();
		getShell().getParent().getDisplay().removeFilter(SWT.FocusIn, focusInlistener);
		return super.close();
	}

	private boolean validateTargetProject() {
		return validateTargetProject(/* allowQuery */ true);
	}

	private boolean validateTargetProject(boolean allowQuery) {
		final String targetFullSpec = getFullTargetProjectSpec();

		if (SpecUtils.hasInvalidCharacterInProjectName(targetFullSpec)) {
			showTargetProjectValidationTip(
					NLS.bind(Messages.StreamNameContainsInvalidCharacters, SpecialCharacters.INVALID_OBJ_NAME_CHARS));
			return false;
		}
		if (invalidTargetProjectSpecs.contains(targetFullSpec)) {
			showTargetProjectValidationTip(getProjectDoesNotExistMessage(targetFullSpec));
			return false;
		}
		if (targetFullSpec.equals(sourceProject.getId())) {
			showTargetProjectValidationTip(Messages.SourceAndTargetAreTheSame);
			return false;
		}
		if (Utils.isNullEmpty(targetFullSpec)) {
			showTargetProjectValidationTip(Messages.TargetProjectIsEmpty);
			return false;
		}
		hideTip();
		if (targetProject != null) {
			if (targetProject.getName().equals(targetFullSpec)) {
				return true;
			}
		}
		if (allowQuery == false) {
			return true;
		}

		final boolean[] result = { true };

		try {
			PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
				@Override
				public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
					try {
						monitor.beginTask("Validating project...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
						DimensionsObjectFactory factory = sourceProject.getConnection().openSession(monitor)
								.getObjectFactory();

						Project project = factory.getProject(targetFullSpec);
						if (project != null) {
							targetProject = project;
							result[0] = true;
						} else {
							result[0] = false;
						}
					} catch (NullPointerException e) {
					} catch (IllegalArgumentException e) {
					} catch (DMException e) {
						DMTeamUiPlugin.getDefault().handle(e, getShell());
					} finally {
						monitor.setTaskName(Utils.EMPTY_STRING);
						monitor.subTask(Utils.EMPTY_STRING);
						monitor.done();
					}
				}
			});
		} catch (InvocationTargetException e) {
		} catch (InterruptedException e) {
			DMTeamUiPlugin.getDefault().handle(e, getShell());
		}
		if (result[0] == false) {
			invalidTargetProjectSpecs.add(targetFullSpec);
			showTargetProjectValidationTip(getProjectDoesNotExistMessage(targetFullSpec));
		}
		return result[0];
	}

	private String getProjectDoesNotExistMessage(String fullSpec) {
		return NLS.bind(Messages.StreamOrProjectDoesNotExistInProduct, SpecUtils.getProjectName(fullSpec),
				SpecUtils.getProduct(fullSpec));
	}

	private void showTargetProjectValidationTip(String message) {
		setTipDetails(txtTargetProjectSpec, message, true);
	}

	private void hideTip() {
		toolTip.setVisible(false);
	}

	private void setTipDetails(Control control, String message, boolean visible) {
		WizardHelper.setToolTipDetails(control, toolTip, message, visible);
	}

	private void findMoreProjectsToRehome() throws DMException {
		String parentStreamSpec = sourceProject.getId();
		waToRehome = WizardHelper.queryWorkAreaToRehome(sourceProject, parentStreamSpec);
		if (waToRehome == null) {
			throw new DMException(new Status(IStatus.ERROR, DMTeamPlugin.ID, Messages.CannotFindWorkAreaToRehome));
		}
		projectsToRehome.add(sourceProject);

		for (int i = 0; workspaceProjects != null && i < workspaceProjects.length; i++) {
			IDMProject candidate = workspaceProjects[i];
			if (!candidate.getId().equals(parentStreamSpec) || !candidate.getIsStream()) {
				continue;
			}
			if (sourceProject.equals(candidate)) {
				continue;
			}
			IPath wa = WizardHelper.queryWorkAreaToRehome(candidate, parentStreamSpec);
			if (waToRehome.equals(wa)) {
				projectsToRehome.add(candidate);
			}
		}
	}
}

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Part;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.Product;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FileSystemSelectionDialog;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;

public class AdvancedWorkAreaSettings {
    
    Composite composite;
    WizardPage hostPage;
    Boolean inContainer;
    private IProject project;
    private int waCheckStatus;
    private IPath waPath;
    private boolean isValidWorkAreaPath;
    private Pattern pathPattern;
    private String productForParts;
    private boolean isAllowed;
    private List<ChangeListener> changeListeners = new ArrayList<ChangeListener>();
    
    // UI members
    private Label lblOffset;
    private Label lblWorkArea;
    private Label lblPart;
    private Text txtOffset;
    private Text txtWorkArea;
    private Combo cmbPart;
    private Button btnBrowseOffset;
    private Button btnBrowseWorkArea;
    private Button btnBrowsePart;
    private Button btnAdvSettings;
    
    public AdvancedWorkAreaSettings(boolean isAllowed) {
        this.isAllowed = isAllowed;
        if (File.separatorChar == '\\') {
            // Windows
            pathPattern = Pattern.compile("([a-zA-Z]:\\\\){1}([\\w.-]+\\\\?)*"); // use conservative pattern //$NON-NLS-1$
        } else {
            // Unix
            pathPattern = Pattern.compile("/{1}([\\w.]+/?)*"); // use conservative pattern //$NON-NLS-1$
        }
    }
    
    public boolean getAllowed() {
        return isAllowed;
    }
    
    public void setAllowed(boolean allowed) {
        isAllowed = allowed;
    }
    
    public void checkPage() {
        if (waCheckStatus == SharingWizard.PROJECT_NOT_WA && inContainer && !isValidWorkAreaPath) {
            hostPage.setErrorMessage(Messages.NewStreamWizard_stream_offset_err4);
            hostPage.setPageComplete(false);
        } else if (waCheckStatus == SharingWizard.PROJECT_NOT_WA && inContainer && waPath.isRoot()) {
            // warn a user selecting disk root as wa root
            hostPage.setMessage(Messages.NewStreamWizard_stream_offset_err5, IMessageProvider.WARNING);
        } else if (waCheckStatus == SharingWizard.PROJECT_INCOMPATIBLE_WA) { // fatal - cannot proceed further
            hostPage.setErrorMessage(Messages.NewStreamWizard_stream_offset_err3);
            hostPage.setPageComplete(false);
        } else if (txtOffset.getEditable() && Utils.isNullEmpty(txtOffset.getText())) {
            hostPage.setPageComplete(false);
            hostPage.setErrorMessage(Messages.NewStreamWizard_stream_general_err9);
        } else if (Utils.isNullEmpty(cmbPart.getText())) {
            hostPage.setPageComplete(false);
            hostPage.setErrorMessage(Messages.NewStreamWizard_stream_general_err8);
        }
    }

    public void init(WizardPage page, Composite parent, IProject project) {
        this.hostPage = page;
        this.project = project;
        createControl(parent);
        update();
    }
    
    public String getWorkArea() {
        return UIUtils.safeGetText(txtWorkArea);
    }
    
    public IPath getWorkAreaPath() {
        String path = getWorkArea();
        IPath result = pathPattern.matcher(path).matches() ? Path.fromOSString(path)
                : null;
        return result;
    }
    
    public void addChangeListener(ChangeListener listener) {
        if (!changeListeners.contains(listener)) {
            changeListeners.add(listener);
        }
    }

    public void removeChangeListener(ChangeListener listener) {
        changeListeners.remove(listener);
    }

    public void fireStateChanged() {
        for (Iterator<ChangeListener> iter = changeListeners.iterator(); iter.hasNext();) {
            ChangeListener listener = iter.next();
            listener.stateChanged(new ChangeEvent(this));
        }
    }
    
    private void createControl(Composite parent) {
        composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 4);
        UIUtils.setGridData(composite, GridData.FILL_HORIZONTAL);

        lblWorkArea = UIUtils.createLabel(composite, Messages.SharingOffsetPage_work_area_root);
        lblWorkArea.setVisible(false);
        txtWorkArea = new Text(composite, SWT.SINGLE | SWT.BORDER);
        txtWorkArea.setVisible(false);
        UIUtils.setGridData(txtWorkArea, GridData.FILL_HORIZONTAL);
        btnBrowseWorkArea = new Button(composite, SWT.PUSH);
        btnBrowseWorkArea.setText("..."); //$NON-NLS-1$
        btnBrowseWorkArea.setEnabled(false);
        btnBrowseWorkArea.setVisible(false);

        txtWorkArea.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                if (waCheckStatus == SharingWizard.PROJECT_NOT_WA && inContainer) {
                    // direct input only under these conditions, otherwise - programmatic
                    waPath = getWorkAreaPath();
                    if (waPath == null || waPath.segmentCount() >= project.getLocation().segmentCount()
                            || !waPath.isPrefixOf(project.getLocation())) {
                        isValidWorkAreaPath = false;
                        txtOffset.setText(Utils.EMPTY_STRING); // rely on txtOffset invoking checkPage
                    } else {
                        isValidWorkAreaPath = true;
                        // rely on txtOffset invoking checkPage
                        txtOffset.setText(project.getLocation().makeRelativeTo(waPath).toString());
                    }
                } else {
                    fireStateChanged();
                }
            }
        });
        btnBrowseWorkArea.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                FileSystemSelectionDialog dialog = new FileSystemSelectionDialog(btnBrowseWorkArea.getShell(), false,
                        FileSystemSelectionDialog.FOLDER);
                dialog.setTitle(Messages.SharingOffsetPage_work_area_dlg_title);
                dialog.setMessage(Messages.SharingOffsetPage_work_area_dlg_message);
                String rootPath = (project.getLocation().getDevice() != null)
                        ? project.getLocation().getDevice() + File.separator
                        : File.separator;
                dialog.setInput(new File(rootPath));
                dialog.addFilter(new ViewerFilter() {
                    // is invoked after folders only(FileSystemSelectionDialog.FOLDER) were filtered by a content provider
                    private final IPath projectParentPath = project.getLocation().removeLastSegments(1);

                    @Override
                    public boolean select(Viewer viewer, Object parentElement, Object element) {
                        if (element instanceof File) {
                            try {
                                IPath filePath = Path.fromOSString(((File) element).getCanonicalPath());
                                if (filePath.isPrefixOf(projectParentPath)) {
                                    return true;
                                }
                            } catch (IOException e) {
                                hostPage.setErrorMessage(e.getMessage());
                            }
                        }
                        return false;
                    }
                });
                if (txtWorkArea.getText() != null && txtWorkArea.getText().length() > 0) {
                    dialog.setInitialSelection(new File(txtWorkArea.getText()));
                }
                if (dialog.open() == Window.OK) {
                    try {
                        String waPath = ((File) dialog.getFirstResult()).getCanonicalPath();
                        txtWorkArea.setText(waPath);
                    } catch (IOException e1) {
                        hostPage.setErrorMessage(e1.getMessage());
                    }
                }
            }
        });

        btnAdvSettings = new Button(composite, SWT.PUSH);
        btnAdvSettings.setText(Messages.NewStreamWizard_stream_general_btnAdvanced_show);
        UIUtils.setGridData(btnAdvSettings, GridData.HORIZONTAL_ALIGN_END);

        lblOffset = UIUtils.createLabel(composite, Messages.NewStreamWizard_stream_general_lblOffset);
        lblOffset.setVisible(false);
        txtOffset = new Text(composite, SWT.SINGLE | SWT.BORDER);
        txtOffset.setVisible(false);
        UIUtils.setGridData(txtOffset, GridData.FILL_HORIZONTAL);
        txtOffset.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                fireStateChanged();
            }
        });
        btnBrowseOffset = new Button(composite, SWT.PUSH);
        btnBrowseOffset.setText("..."); //$NON-NLS-1$
        btnBrowseOffset.setEnabled(false);
        btnBrowseOffset.setVisible(false);

        Label placeholder = UIUtils.createLabel(composite, null);
        placeholder.setVisible(false);
        UIUtils.setGridData(placeholder, GridData.HORIZONTAL_ALIGN_END); // placeholder to fill the cell

        lblPart = UIUtils.createLabel(composite, Messages.NewStreamWizard_stream_general_lblPart);
        lblPart.setVisible(false);
        cmbPart = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
        cmbPart.setVisible(false);
        UIUtils.setGridData(cmbPart, GridData.FILL_HORIZONTAL);
        btnBrowsePart = new Button(composite, SWT.PUSH);
        btnBrowsePart.setText("..."); //$NON-NLS-1$
        btnBrowsePart.setVisible(false);
        btnBrowsePart.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                SharingWizard wiz = (SharingWizard) getWizard();
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(hostPage.getControl().getShell(), IDMConstants.PART,
                        wiz.getConnection(), wiz.getProductName(), true, false);
                if (dialog.open() == Window.OK) {
                    List<String> parts = dialog.getSelectedNames();
                    int selection = -1;
                    for (int i = 0; i < parts.size(); i++) {
                        String part = parts.get(i);
                        int index = part.indexOf(":"); //$NON-NLS-1$
                        part = part.substring(index + 1);
                        for (int j = 0; j < cmbPart.getItemCount(); j++) {
                            if (cmbPart.getItem(j).equals(part)) {
                                selection = j;
                            }
                        }
                    }
                    cmbPart.select(selection);
                }
            }
        });
        btnAdvSettings.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                txtOffset.setVisible(!txtOffset.getVisible());
                updateAdvancedSettings();
            }
        });
        fillPartCombo();
    }

    public void update() {
        boolean isContainer = ((WorksetSelectionPage) (getWizard().getPage(SharingWizard.WORKSET_PAGE_ID))).getCreateInContainer();
        
        if (inContainer != null) {
            if (inContainer.booleanValue() == isContainer) {
                return;
            }
        }
        inContainer = isContainer;

        // check wa in the hierarchy
        if (ResourcesPlugin.getWorkspace().getRoot().getLocation().isPrefixOf(project.getLocation())) {
            waCheckStatus = SharingWizard.PROJECT_WS; // project is in workspace
        } else {
            IPath resPath = TeamUtils.validateProjectWorkArea(project, null);
            if (resPath == null || !resPath.isEmpty()) {
                // incompatible/workset same-name/multiple/nested wa, no PROJECT_COMPATIBLE_WA for the stream to create
                waCheckStatus = SharingWizard.PROJECT_INCOMPATIBLE_WA;
            } else { // not under wa
                waCheckStatus = SharingWizard.PROJECT_NOT_WA;
            }
        }

        if (inContainer) {
            switch (waCheckStatus) {
            case SharingWizard.PROJECT_WS: // in workspace - work area's implicitly project folder
                txtOffset.setEditable(true);
                txtOffset.setText(project.getName());
                btnBrowseOffset.setEnabled(true);

                txtWorkArea.setEditable(false);
                txtWorkArea.setText(Utils.EMPTY_STRING);
                btnBrowseWorkArea.setEnabled(false);
                break;
            case SharingWizard.PROJECT_NOT_WA: // could select paths above the project folder as wa, change offset to path in wa
                txtOffset.setEditable(false);
                btnBrowseOffset.setEnabled(false);

                txtWorkArea.setEditable(true);
                txtWorkArea.setText(project.getLocation().removeLastSegments(1).removeTrailingSeparator().toOSString());
                btnBrowseWorkArea.setEnabled(true);
                break;
            case SharingWizard.PROJECT_INCOMPATIBLE_WA: // fatal: nothing to do here
                txtOffset.setEditable(false);
                txtOffset.setText(Utils.EMPTY_STRING);
                btnBrowseOffset.setEnabled(false);

                txtWorkArea.setEditable(false);
                txtWorkArea.setText(Utils.EMPTY_STRING);
                btnBrowseWorkArea.setEnabled(false);
                break;
            }
        } else { // not in container - no offset and work area's implicitly project folder
            txtOffset.setEditable(false);
            txtOffset.setText(Utils.EMPTY_STRING);
            btnBrowseOffset.setEnabled(false);

            txtWorkArea.setEditable(false);
            txtWorkArea.setText(Utils.EMPTY_STRING);
            btnBrowseWorkArea.setEnabled(false);
        }
    }

    public String getOffset() {
        return UIUtils.safeGetText(txtOffset);
    }

    public String getPart() {
        return UIUtils.safeGetCombo(cmbPart);
    }
    
    public void fillPartCombo() {
        IWizard wizard = getWizard();
        if (wizard instanceof SharingWizard == false) {
            return;
        }
        SharingWizard sharingWizard = (SharingWizard) wizard;
        
        if (sharingWizard.getProductName() != null
                && !sharingWizard.getProductName().equals(productForParts)) {
            List<String> items = getAllProductPartsFromDM();
            productForParts = sharingWizard.getProductName();
            cmbPart.removeAll();
            for (int i = 0; i < items.size(); i++) {
                cmbPart.add(items.get(i));
            }
            // select default part. It is named as product
            for (int i = 0; i < cmbPart.getItemCount(); i++) {
                if (cmbPart.getItem(i).length() >= productForParts.length()
                        && cmbPart.getItem(i).substring(0, productForParts.length()).equals(productForParts)) {
                    cmbPart.select(i);
                    break;
                }
                cmbPart.select(0);
            }

            if (0 == cmbPart.getItemCount()) {
                hostPage.setPageComplete(false);
                hostPage.setErrorMessage(Messages.NewStreamWizard_stream_general_err10);
            }
        }
    }
    
    private IWizard getWizard() {
        return hostPage.getWizard();
    }
    
    private List<String> getAllProductPartsFromDM() {
        if (!(getWizard() instanceof SharingWizard) || null == ((SharingWizard) getWizard()).getProductName()) {
            return Collections.emptyList();
        }
        SharingWizard wiz = (SharingWizard) getWizard();
        final List<String> result = new ArrayList<String>();
        try {
            final Product product = wiz.getConnection().getProduct(wiz.getProductName(), null);

            Session session = wiz.getConnection().openSession(null);
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    Filter openFilter = new Filter();
                    openFilter.criteria().add(new Filter.Criterion(SystemAttributes.STATUS, "OPEN", Filter.Criterion.EQUALS)); //$NON-NLS-1$
                    List<?> productParts = product.getParts(openFilter);
                    for (Iterator<?> partIter = productParts.iterator(); partIter.hasNext();) {
                        Part part = (Part) partIter.next();
                        String spec = (String) part.getAttribute(SystemAttributes.OBJECT_SPEC);
                        String name = spec.substring(spec.indexOf(":") + 1); //$NON-NLS-1$
                        result.add(name);
                    }
                }

            }, null);
        } catch (DMException e) {
            hostPage.setErrorMessage(e.getMessage());
            return Collections.emptyList();
        }
        return result;
    }
    
    private void updateAdvancedSettings() {
        boolean toShow = txtOffset.getVisible();
        cmbPart.setVisible(toShow);
        txtOffset.setVisible(toShow);
        txtWorkArea.setVisible(toShow);
        lblPart.setVisible(toShow);
        lblOffset.setVisible(toShow);
        lblWorkArea.setVisible(toShow);
        btnBrowseOffset.setVisible(toShow);
        btnBrowsePart.setVisible(toShow);
        btnBrowseWorkArea.setVisible(toShow);
        btnAdvSettings.setText((toShow ? Messages.NewStreamWizard_stream_general_btnAdvanced_hide
                : Messages.NewStreamWizard_stream_general_btnAdvanced_show));
    }
}

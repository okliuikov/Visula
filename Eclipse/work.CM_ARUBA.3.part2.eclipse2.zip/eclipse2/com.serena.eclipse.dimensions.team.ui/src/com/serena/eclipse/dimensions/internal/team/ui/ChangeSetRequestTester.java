package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;

import com.serena.dmclient.api.DimensionsChangeStep;

public class ChangeSetRequestTester extends PropertyTester {

    public static final String REQUEST_VISIBILITY_PROPERTY = "checkRequestVisibility";
    public static final String ANY_REQUESTS_PROPERTY = "anyRequests";

    public static final String ONE_REQUEST_VALUE = "oneRequest";
    public static final String SEVERAL_REQUESTS_VALUE = "severalRequests";

    public ChangeSetRequestTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (!(receiver instanceof StructuredSelection)) {
            return false;
        }
        StructuredSelection ss = (StructuredSelection) receiver;
        Object selected = ss.getFirstElement();
        if (!(selected instanceof DimensionsChangeStep)) {
            return false;
        }
        DimensionsChangeStep changeStep = (DimensionsChangeStep) selected;

        if (property.equals(REQUEST_VISIBILITY_PROPERTY)) {
            String reqsCount = (String) expectedValue;
            if (reqsCount.equals(ONE_REQUEST_VALUE)) {
                return changeStep.getRequestsIds() != null && changeStep.getRequestsIds().size() == 1;
            } else if (reqsCount.equals(SEVERAL_REQUESTS_VALUE)) {
                return changeStep.getRequestsIds() != null && changeStep.getRequestsIds().size() > 1;
            } else {
                return false;
            }
        } else if (property.equals(ANY_REQUESTS_PROPERTY)) {
            return changeStep.getRequestsIds() != null && changeStep.getRequestsIds().size() > 0;
        } else {
            return false;
        }
    }
}

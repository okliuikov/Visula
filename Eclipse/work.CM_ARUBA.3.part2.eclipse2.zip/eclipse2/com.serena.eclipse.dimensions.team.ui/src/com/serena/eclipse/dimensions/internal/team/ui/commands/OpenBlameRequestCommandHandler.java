/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2012 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.commands;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.HandlerUtil;

import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.api.IDMRequestIdentifier;
import com.serena.dmclient.api.IDMRequestV2;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.BlameRulerRequestMenuContribution;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.editors.ReportBrowserEditorInput;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotateRevision;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.util.StringUtils;

public class OpenBlameRequestCommandHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
       
        StructuredSelection ssel = UIUtils.getStructuredSelectionFromRuler(HandlerUtil.getActiveEditor(event));
        DimensionsConnectionDetailsEx connection = null;
        String requestName = null;
        Object selObj = null;
        String productId = "";
        if (ssel != null && ssel.size() > 0 && ((selObj = ssel.getFirstElement()) instanceof BlameAnnotateRevision)) {
            BlameAnnotateRevision revision = (BlameAnnotateRevision) selObj;
            IDMProject project = revision.getBase().getProject();
            productId = project.getProduct();
            connection = project != null ? project.getConnection() : revision.getConnection();
            requestName = event.getParameter(BlameRulerRequestMenuContribution.REQUEST_NAME_PARAM);
            // only one request associated with revision
            if (requestName == null) {
                List<String> requests = revision.getRequests();
                if (requests != null && requests.size() == 1) {
                    requestName = requests.get(0);
                }
            }
        }

        if (connection != null && requestName != null) {
            execute(connection, requestName, productId);
        }

        return null;
    }

    private void execute(final DimensionsConnectionDetailsEx conn, final String requestName, final String productId) {
        Job job = new Job(Messages.blameAnnot_open_request_job) {

            @Override
            protected IStatus run(IProgressMonitor monitor) {
                IStatus result = Status.OK_STATUS;
                try {
                    final Session session = conn.openSession(monitor);
                    if (conn.isIdmRequestProvider()) {
                        IDMHelper helper = session.getObjectFactory().getIDMHelper();
                        RequestProvider provider = StringUtils.isBlank(productId)
                                ? session.getObjectFactory().getRequestProvider(null)
                                : helper.getRequestProvider(productId);
                        List<IDMRequestIdentifier> identifiers = new ArrayList<IDMRequestIdentifier>();
                        identifiers.add(new IDMRequestIdentifier(provider.getUID(), requestName));

                        final List<IDMRequestV2> requests = helper.getIDMRequests(identifiers);
                        if (requests == null || requests.size() == 0) {
                            return result;
                        }
                        Display.getDefault().asyncExec(new Runnable() {

                            @Override
                            public void run() {
                                if (conn.isSbmRequestProvider()) {

                                    DMUIPlugin.showInBrowser(new ReportBrowserEditorInput(requests.get(0).getName(),
                                            requests.get(0).getUrl()));
                                } else {
                                    try {
                                        PlatformUI.getWorkbench().getBrowserSupport().getExternalBrowser()
                                                .openURL(new URL(requests.get(0).getUrl()));
                                    } catch (PartInitException e) {
                                        DMUIPlugin.getDefault().handle(e);
                                    } catch (MalformedURLException e) {
                                        DMUIPlugin.getDefault().handle(e);
                                    }
                                }

                            }
                        });
                        return result;
                    }
                    final ChangeDocumentAdapter[] resultHolder = new ChangeDocumentAdapter[1];
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            Request requestObj = session.getObjectFactory().findRequest(requestName);
                            if (requestObj != null) {
                                resultHolder[0] = new ChangeDocumentAdapter(requestObj, conn);
                            }
                        }
                    }, monitor);

                    if (resultHolder[0] != null) {
                        Display.getDefault().asyncExec(new Runnable() {

                            @Override
                            public void run() {
                                IDimensionsObjectEditHandler handler = DMUIPlugin.getDefault().getEditHandler(
                                        resultHolder[0].getTypeScope());
                                if (handler != null) {
                                    try {
                                        handler.openEditor(resultHolder[0]);
                                    } catch (CoreException e) {
                                        DMUIPlugin.getDefault().handle(e, UIUtils.findShell(), Messages.err_error,
                                                Messages.err_openObjEditor);
                                    }
                                }
                            }
                        });
                    }

                } catch (DMException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
                return result;
            }

        };
        job.schedule();
    }
}

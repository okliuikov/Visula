/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectBrowsePanel;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * @author V.Grishchenko
 */
public class WorksetSelectionDialog extends Dialog {
    private int browseOptions;
    protected ProjectBrowsePanel worksetSelectionPanel;
    private DimensionsConnectionDetailsEx connection;
    private String title;
    private List selection = new ArrayList();;
    private boolean multi;
    private boolean showOnlyStreams;// Show only Streams in the list
    private boolean showOnlyProjects;// Show only Projects in the list

    public WorksetSelectionDialog(Shell parentShell, String title, DimensionsConnectionDetailsEx connection, int browseOptions,
            boolean multi, boolean showOnlyStreams, boolean showOnlyProjects) {

        super(parentShell);
        setShellStyle(getShellStyle() | SWT.RESIZE);
        Assert.isNotNull(connection);
        this.connection = connection;
        this.browseOptions = browseOptions;
        this.title = title;
        this.multi = multi;
        this.showOnlyStreams = showOnlyStreams;
        this.showOnlyProjects = showOnlyProjects;
    }

    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        if (title != null) {
            newShell.setText(title);
        }
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite) super.createDialogArea(parent);
        worksetSelectionPanel = new ProjectBrowsePanel(composite, multi ? SWT.MULTI : SWT.SINGLE, browseOptions);
        GridData gd = UIUtils.setGridData(worksetSelectionPanel.getPanel(), GridData.FILL_BOTH);
        gd.widthHint = 300;
        gd.heightHint = 200;
        worksetSelectionPanel.setConnection(connection, showOnlyStreams, showOnlyProjects);

        worksetSelectionPanel.setSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                copySelection();
                updateButtons();
            }
        });

        worksetSelectionPanel.setDoubleClickListener(new IDoubleClickListener() {
            @Override
            public void doubleClick(DoubleClickEvent event) {
                if (!selection.isEmpty()) {
                    okPressed();
                }
            }
        });

        return composite;
    }

    private void copySelection() {
        selection.clear();
        selection.addAll(Arrays.asList(worksetSelectionPanel.getSelectedWorksets()));
        selection.addAll(Arrays.asList(worksetSelectionPanel.getSelectedBaselines()));
        selection.addAll(Arrays.asList(worksetSelectionPanel.getSelectedSccProjects()));
    }

    private void updateButtons() {
        Button okButton = getButton(IDialogConstants.OK_ID);
        okButton.setEnabled(!selection.isEmpty());
    }

    @Override
    protected void cancelPressed() {
        super.cancelPressed();
        selection.clear();
    }

    /**
     * @return selected objects, never <code>null</code>
     */
    public List getSelectedObjects() {
        return selection;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.HashSet;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.IMoveRequest;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.MoveHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.MoveWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class MoveOperation extends WizardOperation {

    public MoveOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    @Override
    protected ISchedulingRule getSchedulingRule(DMRepositoryProvider provider) {
        IResource[] resources = getResources();
        HashSet<IProject> participatingProjects = new HashSet<IProject>();
        participatingProjects.add(provider.getProject());
        try {
            for (int i = 0; i < resources.length; i++) {
                if (resources[i].getProject().equals(provider.getProject())) {
                    IResource moveSource = DMTeamPlugin.getWorkspace().getMovedFrom(resources[i]);
                    if (moveSource != null) {
                        participatingProjects.add(moveSource.getProject());
                    }
                }
            }
            if (participatingProjects.size() == 1) {
                return provider.getProject(); // must be the supplied provider's project
            }
            return new MultiRule(participatingProjects.toArray(new IResource[participatingProjects.size()]));
        } catch (CoreException e) {
            DMTeamUiPlugin.log(e.getStatus());
        }
        return ResourcesPlugin.getWorkspace().getRoot();
    }

    @Override
    protected void execute(OperationData data, IProgressMonitor monitor) throws CoreException, InterruptedException {
        WorkspaceResourceRequest[] requests = data.getRequestsArray();

        if (requests.length == 0) {
            return;
        }
        IMoveRequest[] moveRequests = new IMoveRequest[requests.length];
        System.arraycopy(requests, 0, moveRequests, 0, requests.length);
        data.getProject().move(moveRequests, monitor);
    }

    @Override
    protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
        return new MoveHelper(getResources(), getFilter(), monitor);
    }

    @Override
    protected TeamOperationWizard createWizard(TeamOperationWizardHelper wizardHelper) {
        return new MoveWizard((MoveHelper) wizardHelper);
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind(Messages.MoveOperation_0, provider.getProject().getName());
    }

    @Override
    protected String getTaskName() {
        return Messages.MoveOperation_1;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * This class provides selection of the named and default branches for this workset
 *
 * @author bstephenson
 */
public class NewWorksetGroupContentsPage<T> extends DimensionsWizardPage {
    public static final String GROUP_CONTENTS_PAGE_ID = "group_contents_page_id"; //$NON-NLS-1$

    private T[] contents;
    private Table nbTable;
    private boolean sccProjects;

    private static final int WIDTH_HINT = 350;

    public NewWorksetGroupContentsPage(String pageName) {
        super(pageName);
    }

    public NewWorksetGroupContentsPage(String pageName, String title, String description, ImageDescriptor titleImage, T[] contents,
            boolean sccProjects) {
        super(pageName, title, titleImage);
        setDescription(description);
        this.contents = contents;
        this.sccProjects = sccProjects;
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NULL);
        GridLayout gridLayout = new GridLayout();
        gridLayout.numColumns = 1;
        composite.setLayout(gridLayout);
        GridData gridData = new GridData(GridData.FILL_BOTH);
        composite.setLayoutData(gridData);

        nbTable = new Table(composite, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CHECK);

        nbTable.setHeaderVisible(true);
        nbTable.setLinesVisible(true);
        GridData gridData2 = new GridData(GridData.HORIZONTAL_ALIGN_FILL | GridData.GRAB_HORIZONTAL | GridData.VERTICAL_ALIGN_FILL
                | GridData.GRAB_VERTICAL);

        gridData2.verticalSpan = 4;
        // initial 10 entries
        int listHeight = nbTable.getItemHeight() * 10;
        Rectangle trim = nbTable.computeTrim(0, 0, 0, listHeight);

        gridData2.heightHint = trim.height;
        gridData2.widthHint = (WIDTH_HINT * 2) / 3;
        nbTable.setLayoutData(gridData2);

        TableLayout layout = new TableLayout();
        createColumns(nbTable, layout);
        nbTable.setLayout(layout);

        nbTable.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent event) {
                if (event.detail == SWT.CHECK) {
                    getContainer().updateButtons();
                }
            }

        });

        setControl(composite);
        initializeValues();
    }

    private void createColumns(Table table, TableLayout layout) {
        // 1 column
        TableColumn column = new TableColumn(table, SWT.NONE);
        column.setResizable(true);
        column.setText(Messages.NewGroupWizard_groupcontents_selected);
        layout.addColumnData(new ColumnWeightData(5, true));

        TableColumn column2 = new TableColumn(table, SWT.NONE);
        column2.setResizable(true);
        if (sccProjects) {
            column2.setText(Messages.NewGroupWizard_containercontents_title);
        } else {
            column2.setText(Messages.NewGroupWizard_groupcontents_title);
        }
        layout.addColumnData(new ColumnWeightData(50, true));

    }

    private void initializeValues() {
        if (nbTable == null || contents == null) {
            return;
        }

        if (nbTable.getItemCount() > 0) {
            nbTable.removeAll();
        }

        for (int i = 0; i < contents.length; i++) {
            String name = "";
            APIObjectAdapter adapter = null;
            if (contents[i] instanceof APIObjectAdapter) {
                adapter = (APIObjectAdapter) contents[i];
            } else if (contents[i] instanceof ProjectMapping) {
                ProjectMapping mapping = (ProjectMapping) contents[i];
                adapter = mapping.getRemoteProject();
            }

            if (sccProjects || adapter instanceof SccProject) {
                String fileName = (String) adapter.getAPIObject().getAttribute(SystemAttributes.ITEMFILE_FILENAME);
                name = fileName.substring(0, fileName.lastIndexOf('.'));
                if (!sccProjects) {
                    // as part or a group potentially containing multiple containers
                    name = name
                            + " ["//$NON-NLS-1$
                            + ((SccProject) adapter).getProjectContainer()
                                    .getAPIObject()
                                    .getAttribute(SystemAttributes.OBJECT_SPEC) + "]"; //$NON-NLS-1$
                }
            } else {
                name = (String) adapter.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
            }

            TableItem ti = new TableItem(nbTable, SWT.NONE);
            ti.setText(new String[] { "", name }); //$NON-NLS-1$
            ti.setChecked(true);
        }
    }

    public List<T> getContents() {
        final List<T> children = new ArrayList<T>();
        if (nbTable != null) {
            nbTable.getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    // get selected rows
                    for (int i = 0; i < contents.length; i++) {
                        TableItem ti = nbTable.getItem(i);
                        if (ti.getChecked()) {
                            children.add(contents[i]);
                        }
                    }
                }
            });
        }
        return children;
    }

    @Override
    public boolean isPageComplete() {
        return !getContents().isEmpty();
    }
}

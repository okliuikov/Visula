/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.internal.ui.Utils;
import org.eclipse.team.internal.ui.synchronize.SynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.TeamUIUtils;

@SuppressWarnings("restriction")
public class DMWorkspaceStreamShelveAction extends DMParticipantAction {
    private static final String MYCOMMITTEXT = Messages.DMWorkspaceCommitAction_1;

    // @formatter:off
    private static final FastSyncInfoFilter MY_INCLUSION_FILTER =
            new FastSyncInfoFilter.AndSyncInfoFilter(
                new FastSyncInfoFilter[] {
                        OnlineFilter.INSTANCE,
                        ProjectTypeFilter.BASELINE_FILTER,
                        new SyncInfoDirectionFilter(new int[] {
                                SyncInfo.OUTGOING,
                                SyncInfo.CONFLICTING
                                })
                        });

    private static final FastSyncInfoFilter MY_EXCLUSION_FILTER =
            new FastSyncInfoFilter.AndSyncInfoFilter(
                new FastSyncInfoFilter[] {
                        new SyncInfoDirectionFilter(new int[] {
                                SyncInfo.INCOMING
                                })
                        });
    // @formatter:on

    public DMWorkspaceStreamShelveAction(ISynchronizePageConfiguration configuration) {
        super(MYCOMMITTEXT, configuration);
    }

    public DMWorkspaceStreamShelveAction(ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider) {
        super(MYCOMMITTEXT, configuration, selectionProvider);
    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        return MY_EXCLUSION_FILTER;
    }

    static FastSyncInfoFilter getSyncInfoInclusionFilter() {
        return MY_INCLUSION_FILTER;
    }

    @Override
    protected boolean updateSelection(IStructuredSelection selection) {
        return isEnabledForSelection(selection);
    }

    private boolean isEnabledForSelection(IStructuredSelection selection) {
        return !Utils.hasMatchingDescendant(selection, getSyncInfoFilter()) && !isAnyResourceFromTopic(selection);
    }

    private boolean isAnyResourceFromTopic(IStructuredSelection selection) {
        IDMWorkspace dmWorkspace = DMTeamPlugin.getWorkspace();
        Map<DimensionsArObject, String> cashedTypeNames = new HashMap<DimensionsArObject, String>();
        for (Iterator iter = selection.iterator(); iter.hasNext();) {
            Object selecteditem = iter.next();
            if (selecteditem instanceof SynchronizeModelElement) {
                try {
                    IDMProject idmProject = dmWorkspace.getProject(((SynchronizeModelElement) selecteditem).getResource().getProject());
                    if (idmProject == null) {//when out of context
                        continue; 
                    }
                    DimensionsArObject dmArObject = idmProject.getDimensionsObject();
                    String typeName = TeamUIUtils.getTypeNameFromResourceWithCash(dmArObject, cashedTypeNames); 
                    if (IDMConstants.TOPIC_TYPE_NAME.equals(typeName)) {
                        return true;
                    }
                } catch (DMException dme) {
                    dme.printStackTrace();
                } catch (CoreException ce) {
                    ce.printStackTrace();
                }
            }
        }
        return false;
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        return new DMWorkspaceCommitOperation(false, true, configuration, elements);
    }

}

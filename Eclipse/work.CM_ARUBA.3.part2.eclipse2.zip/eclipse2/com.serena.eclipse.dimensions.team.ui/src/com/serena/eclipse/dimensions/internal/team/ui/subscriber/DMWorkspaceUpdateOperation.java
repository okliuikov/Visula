/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.CustomSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.DMSyncInfo;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.operations.ReplaceWithRemoteOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UpdateFromRemoteCustomOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UpdateFromRemoteOperation;

/**
 * @author V.Grishchenko
 */
public class DMWorkspaceUpdateOperation extends DMSafeUpdateOperation {

    protected DMWorkspaceUpdateOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements,
            boolean promptBeforeUpdate) {
        super(configuration, elements, promptBeforeUpdate);
    }

    @Override
    protected void overwriteUpdate(SyncInfoSet syncSet, IProgressMonitor monitor) throws CoreException {
        ReplaceWithRemoteOperation replaceOp = new ReplaceWithRemoteOperation(getPart(), syncSet.getResources());
        try {
            replaceOp.run(monitor);
        } catch (InvocationTargetException e) {
            setErrorDetails(replaceOp.getErrorDetails());
            Throwable target = e.getTargetException();
            if (target instanceof CoreException) {
                throw (CoreException) target;
            }
            throw new DMException(DMTeamStatus.createErrorStatus(0, Messages.DMWorkspaceUpdateOperation_0, e.getTargetException()));
        } catch (InterruptedException e) {
            Utils.cancelOperation();
        }
    }

    @Override
    protected void runUpdateDeletions(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, nodes.length * 100);
        try {
            for (int i = 0; i < nodes.length; i++) {
                DMTeamPlugin.getWorkspace().unmanage(nodes[i].getLocal(), Utils.subMonitorFor(monitor, 50));
                deleteAndKeepHistory(nodes[i].getLocal(), Utils.subMonitorFor(monitor, 50));
            }
        } finally {
            monitor.done();
        }
    }

    private void deleteAndKeepHistory(IResource resource, IProgressMonitor monitor) throws CoreException {
        if (!resource.exists()) {
            return;
        }
        if (resource.getType() == IResource.FILE) {
            TeamUtils.deleteResource(resource, monitor);
        } else if (resource.getType() == IResource.FOLDER) {
            // if we get foreign deletion of the folder with children we are not going to delete
            // this folder as it contains child metadata
            if (!TeamUtils.isLocalWorksetPointingToForeignStream(resource)
                    || !(((IFolder) resource).members(IContainer.INCLUDE_TEAM_PRIVATE_MEMBERS).length > 0)) {
                TeamUtils.deleteResource(resource, monitor);
            }
        }
    }

    @Override
    protected void runSafeUpdate(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException {
        UpdateFromRemoteOperation updateOp = null;
        if (getSubscriber() instanceof CustomSubscriber) {
            updateOp = new UpdateFromRemoteCustomOperation((CustomSubscriber) getSubscriber(), getPart(), getLocalResources(nodes));
        } else {
            updateOp = new UpdateFromRemoteOperation(getPart(), getLocalResources(nodes)) {
                @Override
                protected boolean refreshBeforeUpdate() {
                    return false; // assume up to date as we are run from the sync view
                }
            };
        }
        updateOp.setWarnAboutFailures(false);
        safeUpdate(updateOp, monitor);
    }

    @Override
    protected void updated(SyncInfo[] resources, IProgressMonitor monitor) throws CoreException {
        for (int i = 0; i < resources.length; i++) {
            SyncInfo resource = resources[i];
            if (resource instanceof DMSyncInfo && ((DMSyncInfo) resource).getSubscriber() instanceof CustomSubscriber) {
                DMTeamPlugin.getWorkspace().updateRemote(resource.getLocal(), resource.getRemote());
            }
        }
    }

}

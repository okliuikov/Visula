/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantReference;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMSynchronizeParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceStreamOutgoingParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.SyncSelectForeignStreamDialog;

public class TeamUIUtils {

    public static void removeParticipantById(String id) throws TeamException {
        ISynchronizeParticipantReference[] synchronizeParticipants = TeamUI.getSynchronizeManager().getSynchronizeParticipants();

        for (int i = 0; i < synchronizeParticipants.length; i++) {
            if (synchronizeParticipants[i].getId().equals(id)) {
                ISynchronizeParticipant[] remove = new ISynchronizeParticipant[] { synchronizeParticipants[i].getParticipant() };
                TeamUI.getSynchronizeManager().removeSynchronizeParticipants(remove);
            }
        }
    }

    public static void filterSyncJobResults(final DMSynchronizeParticipant participant, final Shell shell) {
        // find the refresh job shortTaskName is Job Name
        // then set a done listener on it to process changes
        Job[] jobs = Job.getJobManager().find(null);
        Job syncjob = null;
        for (int i = 0; i < jobs.length; i++) {
            if (Messages.SynchronizeAction_0.equals(jobs[i].getName())) {
                syncjob = jobs[i];
            }
        }
        if (syncjob != null) {
            syncjob.addJobChangeListener(new JobChangeAdapter() {

                @Override
                public void done(IJobChangeEvent event) {
                    if (!event.getResult().isOK()) {
                        return;
                    }

                    // Refreshing is done get the syncinfos
                    final SyncInfoSet allSyncSet = participant.getSyncInfoSet();
                    final SyncInfo[] infos = allSyncSet.getSyncInfos();

                    if (infos == null || infos.length == 0) {
                        return;
                    }

                    // process the syncinfos
                    final Map<IDMProject, Set<String>> foreignStreams = new LinkedHashMap<IDMProject, Set<String>>();
                    final Map<SyncInfo, TeamUtils.ForeignInfo> interestingChanges = new HashMap<SyncInfo, TeamUtils.ForeignInfo>();
                    for (int si = 0; si < infos.length; si++) {
                        SyncInfo sinfo = infos[si];
                        if ((sinfo.getKind() & SyncInfo.DIRECTION_MASK) == SyncInfo.OUTGOING) {
                            // is outgoing
                            if ((sinfo.getKind() & SyncInfo.CHANGE_MASK) == SyncInfo.ADDITION) {
                                // an outgoing addition.
                                IResource local = sinfo.getLocal();

                                TeamUtils.ForeignInfo[] streamHolder = new TeamUtils.ForeignInfo[1];
                                if (TeamUtils.isResourceFromForeignStreamEx(local, streamHolder)) {
                                    if (!foreignStreams.containsKey(streamHolder[0].getProject())) {
                                        foreignStreams.put(streamHolder[0].getProject(), new HashSet<String>());
                                    }
                                    HashSet<String> set = (HashSet<String>) foreignStreams.get(streamHolder[0].getProject());
                                    if (streamHolder[0].getForeignStream() != null) {
                                        set.add(streamHolder[0].getForeignStream());
                                    }
                                    interestingChanges.put(sinfo, streamHolder[0]);
                                }
                            }
                        }
                    }

                    // remove the key, which has empty entry.
                    SyncSelectForeignStreamDialog.removeEmpties(foreignStreams);

                    if (foreignStreams.size() > 0) {
                        // have some foreign streams post job on UI stream to
                        // select/deselect and remove from syncinfo if deselected

                        if (participant instanceof DMWorkspaceStreamOutgoingParticipant) {
                            DMWorkspaceStreamOutgoingParticipant dp = (DMWorkspaceStreamOutgoingParticipant) participant;
                            // removed sync info is needed to create full list of excluded resources during deliver operation
                            SyncInfoSet removedSyncSet = new SyncInfoSet();
                            runAndProcessStreamSelectDialog(foreignStreams, allSyncSet, removedSyncSet, interestingChanges, shell);
                            dp.setInfoExcludedByCaller(removedSyncSet);
                        } else {
                            runAndProcessStreamSelectDialog(foreignStreams, allSyncSet, null, interestingChanges, shell);
                        }
                    }
                }

            });
        }
    }

    public static String getTypeNameFromResourceWithCash(DimensionsArObject DmArObj, Map<DimensionsArObject, String> cash) {
        String typeName = (String) (DmArObj.getAttribute(SystemAttributes.TYPE_NAME));
        if (typeName == null) {
            if (cash.containsKey(DmArObj)) {
                DmArObj.setAttribute(SystemAttributes.TYPE_NAME, cash.get(DmArObj));
            } else {
                DmArObj.queryAttribute(SystemAttributes.TYPE_NAME);
                typeName = (String) (DmArObj.getAttribute(SystemAttributes.TYPE_NAME));
                cash.put(DmArObj, typeName);
            }
        }
        return typeName;
    }

    private static void runAndProcessStreamSelectDialog(final Map<IDMProject, Set<String>> foreignStreams,
            final SyncInfoSet allSyncSet, final SyncInfoSet removedSyncSet,
            final Map<SyncInfo, TeamUtils.ForeignInfo> interestingChanges, final Shell shell) {
        Display.getDefault().syncExec(new Runnable() {
            @Override
            public void run() {
                SyncSelectForeignStreamDialog dialog = new SyncSelectForeignStreamDialog(shell, foreignStreams);
                int selection = dialog.open();
                if (selection == Window.CANCEL) {
                    return;
                }

                Map<IDMProject, Set<String>> excludedStreams = dialog.getExcludedParticipants();
                if (excludedStreams != null && !excludedStreams.isEmpty()) {

                    // process the interesting changes
                    for (Iterator<SyncInfo> interestingIterator = interestingChanges.keySet().iterator(); interestingIterator.hasNext();) {
                        SyncInfo si = interestingIterator.next();
                        IResource localResource = si.getLocal();

                        if (localResource instanceof IFile || localResource instanceof IFolder) {
                            IDMProject dmProj = interestingChanges.get(si).getProject();

                            if (dmProj != null && excludedStreams.containsKey(dmProj)) {
                                String projID = interestingChanges.get(si).getForeignStream();
                                Set<String> foreignStreamSet = excludedStreams.get(dmProj);
                                if (foreignStreamSet.contains(projID)) {
                                    if (removedSyncSet != null) {
                                        // push removed sync info to the removed info set
                                        SyncInfo filtered = allSyncSet.getSyncInfo(localResource);
                                        if (filtered != null) {
                                            removedSyncSet.add(filtered);
                                        }
                                    }
                                    allSyncSet.remove(localResource);
                                }
                            }
                        }
                    }
                }
            }
        });
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspaceSyncInfo;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.IPromptCondition;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.PromptingDialog;
import com.serena.eclipse.dimensions.internal.team.ui.operations.ReplaceWithRemoteOperation;
import com.serena.eclipse.dimensions.internal.ui.actions.ShowDetailsAction;

/**
 * @author V.Grishchenko
 */
public class DMOverrideAndUpdateOperation extends DMSynchronizeModelOperation {

    public DMOverrideAndUpdateOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        super(configuration, elements);
    }

    @Override
    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
        SyncInfoSet set = getSyncInfoSet();
        try {
            set = DMWorkspaceCommitHelper.resolveRepositoryMoves(set);
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
        if (set.isEmpty()) {
            return;
        }
        try {
            handleConflictingDeletions(set);
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        if (set.isEmpty()) {
            return;
        }
        try {
            // Processing following case of repository moves separately.
            // Case : User1 modifies a file locally, but the same file is moved in repository by another user. User1 does a sync.
            // Repository move will be shown as an incoming addition and a conflicting change. If the user selects the conflicting
            // change node only and does an "Override and Update" then we need to make sure that the incoming change node too is
            // included in "Override and Update" operation.
            processRepositoryMoves(set, monitor);

            processLocalMoves(set);

        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }

        if (promptForOverwrite(set)) {
            ReplaceWithRemoteOperation replaceOperation = new ReplaceWithRemoteOperation(getPart(), set.getResources()) {
                @Override
                protected boolean refreshBeforeUpdate() {
                    return false; // assume up to date as we are run from sync view
                }

                @Override
                protected boolean isDeleteUnmanaged() {
                    return true; // override user preference when run from the sync view
                }
            };
            try {
                replaceOperation.run(monitor);
            } catch (InvocationTargetException e) {
                ((ShowDetailsAction) getGotoAction()).setDetails(replaceOperation.getErrorDetails());
                throw e;
            }
        }
    }

    /**
     * If the user selects only one part of the move and does an override and update, then we should
     * override and update the other part of the move too. Else the sync will be in an inconsistent state.
     *
     * @param set
     * @throws TeamException
     * @throws CoreException
     */
    private void processLocalMoves(SyncInfoSet set) throws TeamException, CoreException {
        IResource[] resources = set.getResources();
        IResource movedFrom = null;
        IResource movedTo = null;
        for (int i = 0; i < resources.length; i++) {
            movedFrom = null;
            DMTeamPlugin.getDefault();
            movedFrom = DMTeamPlugin.getWorkspace().getMovedFrom(resources[i]);
            if (movedFrom != null) {
                set.add(DMTeamPlugin.getWorkspace().getSubscriber().getSyncInfo(movedFrom));
            } else {
                movedTo = null;
                DMTeamPlugin.getDefault();
                movedTo = DMTeamPlugin.getWorkspace().getMovedTo(resources[i]);
                if (movedTo != null) {
                    set.add(DMTeamPlugin.getWorkspace().getSubscriber().getSyncInfo(movedTo));
                }
            }
        }
    }

    private void processRepositoryMoves(SyncInfoSet syncSet, IProgressMonitor monitor) throws CoreException {
        SyncInfo[] changed = syncSet.getSyncInfos();
        List<SyncInfo> repositoryMovesList = new ArrayList<SyncInfo>();
        List<SyncInfo> repositoryMoveList = new ArrayList<SyncInfo>();
        for (int i = 0; i < changed.length; i++) {
            SyncInfo changedNode = changed[i];
            IResource resource = changedNode.getLocal();
            int kind = changedNode.getKind();
            if (resource.getType() == IResource.FILE) {
                if ((((kind & SyncInfo.DIRECTION_MASK) == SyncInfo.CONFLICTING) && ((kind & SyncInfo.CHANGE_MASK) == SyncInfo.CHANGE))
                        || (((kind & SyncInfo.DIRECTION_MASK) == SyncInfo.CONFLICTING) && ((kind & SyncInfo.CHANGE_MASK) == SyncInfo.DELETION))
                        || (((kind & SyncInfo.DIRECTION_MASK) == SyncInfo.INCOMING) && ((kind & SyncInfo.CHANGE_MASK) == SyncInfo.ADDITION))) {
                    repositoryMovesList.add(changedNode);
                }
            }
        }
        repositoryMoveList = processRepositoryMoves(repositoryMovesList, monitor);
        for (int i = 0; i < repositoryMoveList.size(); i++) {
            syncSet.remove((repositoryMoveList.get(i)).getLocal());
        }
    }

    /**
     * @param updateShallow
     *            - All updates including conflicting changes part if repository moves
     * @param repositoryMoveList
     *            - Contains all repository move.
     * @param repositoryMoveSyncPair
     *            - Repository move stored as key-value pair
     * @throws CoreException
     */
    private void excludeRepositoryMovesFromUpdate(List<SyncInfo> updateShallow, List<SyncInfo> repositoryMoveList,
            HashMap<IResource, IResource> repositoryMoveSyncPair, List<SyncInfo> movedFromSyncList, List<SyncInfo> movedToSyncList)
            throws CoreException {
        if (updateShallow.size() > 0) {
            IResource resDelete = null;
            IResource resAdd = null;
            String itemSpecIdOfDeletedItem = null;
            String itemSpecIdOfAddedItem = null;
            int kind1 = 0;
            int kind2 = 0;
            IResource movedinRespositoryFrom = null;
            IResource movedinRespositoryTo = null;
            for (int i = 0; i < updateShallow.size(); i++) {
                resDelete = updateShallow.get(i).getLocal();
                if (resDelete.getType() == IResource.FILE) {
                    kind1 = updateShallow.get(i).getKind();
                    if (kind1 == (SyncInfo.CONFLICTING | SyncInfo.CHANGE) || kind1 == (SyncInfo.CONFLICTING | SyncInfo.DELETION)) {
                        movedinRespositoryTo = DMTeamPlugin.getWorkspace().getMovedInRepositoryTo(resDelete);
                        if (movedinRespositoryTo != null) {
                            itemSpecIdOfDeletedItem = ((IDMRemoteFile) updateShallow.get(i).getBase()).getItemSpecId();
                            for (int j = 0; j < updateShallow.size(); j++) {
                                resAdd = ((DMWorkspaceSyncInfo) updateShallow.get(j)).getLocal();
                                if (resAdd.getType() == IResource.FILE) {
                                    kind2 = updateShallow.get(j).getKind();
                                    if (kind2 == (SyncInfo.INCOMING | SyncInfo.ADDITION)) {
                                        movedinRespositoryFrom = DMTeamPlugin.getWorkspace().getMovedInRepositoryFrom(resAdd);
                                        if (movedinRespositoryFrom != null && resDelete.equals(movedinRespositoryFrom)) {
                                            itemSpecIdOfAddedItem = ((IDMRemoteFile) ((DMWorkspaceSyncInfo) updateShallow.get(j)).getRemote()).getItemSpecId();
                                            if (itemSpecIdOfDeletedItem.equals(itemSpecIdOfAddedItem)) {
                                                repositoryMoveList.add(updateShallow.get(i));
                                                repositoryMoveList.add(updateShallow.get(j));
                                                repositoryMoveSyncPair.put(resDelete, resAdd);
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            updateShallow.removeAll(repositoryMoveList);
        }
    }

    private boolean promptForDiscardChanges(final SyncInfoSet syncSet, final HashMap<IResource, IResource> repositoryMoveSyncPair) {

        IPromptCondition condition = new IPromptCondition() {
            @Override
            public boolean needsPrompt(IResource resource) {
                return syncSet.getSyncInfo(resource).getKind() == (SyncInfo.CONFLICTING | SyncInfo.CHANGE)
                        || syncSet.getSyncInfo(resource).getKind() == (SyncInfo.CONFLICTING | SyncInfo.DELETION);
            }

            @Override
            public String promptMessage(IResource resource) {
                return NLS.bind(Messages.DMRepositoryMoveOverrideAndUpdateOperation_confirmDiscardChangesMessage,
                        resource.getFullPath().toString());
            }
        };

        PromptingDialog dialog = new PromptingDialog(getShell(), syncSet.getResources(), condition,
                Messages.DMRepositoryMoveOverrideAndUpdateOperation_confirmDiscardChangesTitle, true, 2);
        try {
            final HashSet<?> deSelectedList = new HashSet<Object>();
            final HashSet<IResource> resourcesToOverwrite = new HashSet<IResource>(
                    Arrays.asList(dialog.promptForMultiple(deSelectedList)));
            FastSyncInfoFilter rejectFilter = new FastSyncInfoFilter() {
                @Override
                public boolean select(SyncInfo info) {
                    return !resourcesToOverwrite.contains(info.getLocal()) || deSelectedList.contains(info.getLocal())
                            || isPartOfDeSelectedPair(repositoryMoveSyncPair, deSelectedList, info.getLocal());
                }
            };
            syncSet.rejectNodes(rejectFilter);
        } catch (InterruptedException e) {
            return false; // cancel
        }
        return !syncSet.isEmpty();
    }

    private boolean isPartOfDeSelectedPair(HashMap<IResource, IResource> repositoryMoveSyncPair, HashSet<?> deSelectedList,
            IResource resource) {
        Iterator<?> deSel = deSelectedList.iterator();
        while (deSel.hasNext()) {
            if (resource.equals(repositoryMoveSyncPair.get(deSel.next()))) {
                return true;
            }
        }
        return false;
    }

    private List<SyncInfo> processRepositoryMoves(List<SyncInfo> updateShallow, IProgressMonitor monitor) throws CoreException {
        // Processing following case of repository moves separately.
        // Case : User1 modifies a file locally, but the same file is moved in repository by another user. User1 does a sync.
        // Repository move will be shown as an incoming addition and a conflicting change. If the user selects the conflicting
        // change node only and does an Update then we need to make sure that the incoming addition node too is included in the
        // "Override and Update" operation.
        ArrayList<SyncInfo> repositoryMoveList = new ArrayList<SyncInfo>();
        // Repository move nodes stored as key - value pair. Key being the conflicting change
        HashMap<IResource, IResource> repositoryMoveSyncPair = new HashMap<IResource, IResource>();
        ArrayList<SyncInfo> movedFromSyncList = new ArrayList<SyncInfo>();
        ArrayList<SyncInfo> movedToSyncList = new ArrayList<SyncInfo>();
        excludeRepositoryMovesFromUpdate(updateShallow, repositoryMoveList, repositoryMoveSyncPair, movedFromSyncList,
                movedToSyncList);
        SyncInfoSet overrideAndUpdateSyncSet = new SyncInfoSet();
        for (int i = 0; i < repositoryMoveList.size(); i++) {
            overrideAndUpdateSyncSet.add((repositoryMoveList.get(i)));
        }
        if (promptForDiscardChanges(overrideAndUpdateSyncSet, repositoryMoveSyncPair)) {
            DMTeamPlugin.getWorkspace().retainMetadataOfTheResourceBeingMoved(movedToSyncList, movedFromSyncList, monitor);
            ReplaceWithRemoteOperation replaceOperation = new ReplaceWithRemoteOperation(getPart(),
                    overrideAndUpdateSyncSet.getResources()) {
                @Override
                protected boolean refreshBeforeUpdate() {
                    return false; // assume up to date as we are run from sync view
                }

                @Override
                protected boolean isDeleteUnmanaged() {
                    return true; // override user preference when run from the sync view
                }
            };
            try {
                replaceOperation.run(monitor);
            } catch (InvocationTargetException e) {
                ((ShowDetailsAction) getGotoAction()).setDetails(replaceOperation.getErrorDetails());
            } catch (InterruptedException ie) {
            }
        }
        return repositoryMoveList;
    }

    @Override
    protected void run(SyncData data, IProgressMonitor monitor) throws CoreException {
    }

}

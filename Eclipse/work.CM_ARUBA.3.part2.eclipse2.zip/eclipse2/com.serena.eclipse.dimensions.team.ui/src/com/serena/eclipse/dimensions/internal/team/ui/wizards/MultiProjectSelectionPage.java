/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.SccProjectList;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectBrowsePanel;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.WorksetSelectionDialog;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Page that allows to select multiple projects using find and browse.
 * @author V.Grishchenko
 */
public class MultiProjectSelectionPage extends DimensionsWizardPage {
    private static final int COL_PROJECT = 0;
    private static final int COL_OFFSET = 1;
    private static final int COL_DESCRIPTION = 2;

    private static final String COL_PROJECT_PROP = "project"; //$NON-NLS-1$
    private static final String COL_DESCRIPTION_PROP = "desc"; //$NON-NLS-1$
    private static final String COL_OFFSET_PROP = "offset"; //$NON-NLS-1$

    private Label label;
    private DimensionsConnectionDetailsEx connection;
    private boolean connectionChanged;
    private TableViewer tableViewer;

    private List selection = new ArrayList();
    private Button findProjectBtn;
    private Button findBaselineBtn;
    private Button browseBtn;
    private Button removeBtn;
    private Button removeAllBtn;
    private ComboBoxCellEditor cellEditor;

    private Map sccProjects = new HashMap();

    private class ContentProvider implements IStructuredContentProvider {

        @Override
        public Object[] getElements(Object inputElement) {
            return selection.toArray();
        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        }
    }

    private class TableLabelProvider extends WorkbenchLabelProvider implements ITableLabelProvider {

        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            if (columnIndex == COL_PROJECT) {
                return super.getImage(element);
            }
            return null;
        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            if (!(element instanceof VersionManagementProject)) {
                return Utils.EMPTY_STRING;
            }
            if (columnIndex == COL_PROJECT) {
                return Utils.getString(((VersionManagementProject) element).getProjectSpec());
            }
            if (columnIndex == COL_OFFSET && element instanceof SccProject) {
                SccProject legacyIDEProject = (SccProject) element;
                return legacyIDEProject.getOffset();
            }
            if (columnIndex == COL_DESCRIPTION && !(element instanceof SccProject)) { // show desc only for real projects and
                                                                                      // baselines
                DimensionsArObject projectObject = ((VersionManagementProject) element).getAPIObject();
                return Utils.getString((String) projectObject.getAttribute(SystemAttributes.DESCRIPTION));
            }
            return Utils.EMPTY_STRING;
        }
    }

    private class CellModifier implements ICellModifier {

        @Override
        public boolean canModify(Object element, String property) {
            if (COL_OFFSET_PROP.equals(property) && element instanceof VersionManagementProject) {
                SccProjectList list = (SccProjectList) sccProjects.get(getContainer(element));
                return list != null && !list.isEmpty();
            }
            return false;
        }

        @Override
        public Object getValue(Object element, String property) {
            int idx = -1;
            if (COL_OFFSET_PROP.equals(property)) {
                if (element instanceof SccProject) {
                    SccProject legacyProject = (SccProject) element;
                    APIObjectAdapter container = legacyProject.getProjectContainer();
                    SccProjectList list = (SccProjectList) sccProjects.get(container);
                    APIObjectAdapter[] otherProjects = list.getObjects();
                    for (int i = 0; i < otherProjects.length; i++) {
                        SccProject otherProject = (SccProject) otherProjects[i];
                        if (legacyProject.getOffset().equals(otherProject.getOffset())) {
                            idx = i + 1; // one extra for "Use container"
                            break;
                        }
                    }
                } else {
                    idx = 0; // "use container"
                }
            }
            return new Integer(idx);
        }

        @Override
        public void modify(Object element, String property, Object value) {
            if (element instanceof Item) {
                element = ((Item) element).getData();
            }
            if (COL_OFFSET_PROP.equals(property) && element instanceof VersionManagementProject) {
                APIObjectAdapter newSelection = null;
                int idx = ((Integer) value).intValue();
                if (idx == 0) { // "use container" was selected
                    if (element instanceof SccProject) {
                        newSelection = ((SccProject) element).getProjectContainer();
                    }
                } else if (idx > 0) {
                    SccProjectList list = (SccProjectList) sccProjects.get(getContainer(element));
                    newSelection = list.getObjects()[idx - 1];
                }

                if (newSelection != null) {
                    int tableSelection = tableViewer.getTable().getSelectionIndex();
                    if (tableSelection != -1) {
                        selection.set(tableSelection, newSelection);
                        tableViewer.refresh();
                    }
                }
                validate();
            }
        }

    }

    public MultiProjectSelectionPage(String pageName, String title, ImageDescriptor titleImage, String description) {
        super(pageName, title, titleImage, description);
        validate();
    }

    /**
     * @return Returns the selection.
     */
    public List getSelection() {
        return selection;
    }

    public void setConnection(DimensionsConnectionDetailsEx connection) {
        if (this.connection == connection || (this.connection != null && this.connection.equals(connection))) {
            return;
        }
        this.connection = connection;
        this.connectionChanged = true;
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        label = UIUtils.createLabel(composite, null);
        UIUtils.setGridData(label, GridData.FILL_HORIZONTAL);
        updateLabel();

        Table table = new Table(composite, SWT.MULTI | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL | SWT.BORDER);
        table.setHeaderVisible(true);
        table.setLinesVisible(true);
        UIUtils.setGridData(table, GridData.FILL_BOTH);
        TableLayout tableLayout = new TableLayout();
        table.setLayout(tableLayout);

        TableColumn col1 = new TableColumn(table, SWT.NONE);
        col1.setText(Messages.ProjectImportWizard_SelectionPage_col1_title);
        tableLayout.addColumnData(new ColumnWeightData(50, true));

        TableColumn col2 = new TableColumn(table, SWT.NONE);
        col2.setText(Messages.ProjectImportWizard_SelectionPage_col2_title);
        tableLayout.addColumnData(new ColumnWeightData(40, true));

        TableColumn col3 = new TableColumn(table, SWT.NONE);
        col3.setText(Messages.ProjectImportWizard_SelectionPage_col3_title);
        tableLayout.addColumnData(new ColumnWeightData(60, true));

        tableViewer = new TableViewer(table);
        tableViewer.setContentProvider(new ContentProvider());
        tableViewer.setLabelProvider(new TableLabelProvider());
        tableViewer.setInput(selection);
        tableViewer.setColumnProperties(new String[] { COL_PROJECT_PROP, COL_OFFSET_PROP, COL_DESCRIPTION_PROP });

        // hook up editing for the offset column
        cellEditor = new ComboBoxCellEditor(table, Utils.ZERO_LENGTH_STRING_ARRAY, SWT.READ_ONLY);
        tableViewer.setCellEditors(new CellEditor[] { null, cellEditor, null });
        tableViewer.setCellModifier(new CellModifier());

        // table selection listener populates combo cell editor with allowed values
        tableViewer.addSelectionChangedListener(new ISelectionChangedListener() {

            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                if (event.getSelection() instanceof IStructuredSelection) {
                    IStructuredSelection ss = (IStructuredSelection) event.getSelection();
                    String[] choices = Utils.ZERO_LENGTH_STRING_ARRAY;
                    int idx = 0; // Default is "use container"
                    if (ss.size() == 1) {
                        VersionManagementProject selPrj = (VersionManagementProject) ss.getFirstElement();
                        SccProjectList list = (SccProjectList) sccProjects.get(getContainer(selPrj));
                        if (!list.isEmpty()) {
                            APIObjectAdapter[] projects = list.getObjects();
                            choices = new String[projects.length + 1];
                            choices[0] = Messages.ProjectImportWizard_SelectionPage_useContainer;
                            for (int i = 0; i < projects.length; i++) {
                                choices[i + 1] = ((SccProject) projects[i]).getOffset();
                                if (selPrj instanceof SccProject && ((SccProject) selPrj).getOffset().equals(choices[i + 1])) {
                                    idx = i + 1;
                                }
                            }
                        }
                    }
                    cellEditor.setItems(choices);
                    // we get notified on cell editor activation, setting items
                    // invalidates the value so have to restore it
                    cellEditor.setValue(new Integer(idx));
                }
            }
        });

        Listener listener = new Listener() {

            @Override
            public void handleEvent(Event event) {
                if (event.type != SWT.Selection) {
                    return;
                }
                if (findProjectBtn == event.widget) {
                    find(IDMConstants.PROJECT);
                } else if (findBaselineBtn == event.widget) {
                    find(IDMConstants.BASELINE);
                } else if (browseBtn == event.widget) {
                    browse();
                } else if (removeBtn == event.widget) {
                    removeSelection();
                } else if (removeAllBtn == event.widget) {
                    removeAll();
                }
            }
        };

        Composite buttonPanel = new Composite(composite, SWT.NONE);
        UIUtils.setGridLayout(buttonPanel, 6);

        findProjectBtn = new Button(buttonPanel, SWT.PUSH);
        findProjectBtn.setText(Messages.ProjectImportWizard_SelectionPage_findProjects);
        findProjectBtn.addListener(SWT.Selection, listener);

        findBaselineBtn = new Button(buttonPanel, SWT.PUSH);
        findBaselineBtn.setText(Messages.ProjectImportWizard_SelectionPage_findBaselines);
        findBaselineBtn.addListener(SWT.Selection, listener);

        browseBtn = new Button(buttonPanel, SWT.PUSH);
        browseBtn.setText(Messages.ProjectImportWizard_SelectionPage_browse);
        browseBtn.addListener(SWT.Selection, listener);

        UIUtils.createLabel(buttonPanel, null); // spacer

        removeBtn = new Button(buttonPanel, SWT.PUSH);
        removeBtn.setText(Messages.ProjectImportWizard_SelectionPage_remove);
        removeBtn.addListener(SWT.Selection, listener);

        removeAllBtn = new Button(buttonPanel, SWT.PUSH);
        removeAllBtn.setText(Messages.ProjectImportWizard_SelectionPage_removeall);
        removeAllBtn.addListener(SWT.Selection, listener);

        setControl(composite);
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible && connectionChanged) {
            updateLabel();
            removeAll();
            // TODO VG on Mar 8, 2006: clear table
            connectionChanged = false;
        }
        super.setVisible(visible);
    }

    private void updateLabel() {
        if (label != null) {
            if (connection != null) {
                label.setText(NLS.bind(Messages.ProjectImportWizard_SelectionPage_selectedfrom, connection.getConnName()));
            } else {
                label.setText(Messages.ProjectImportWizard_SelectionPage_selected);
            }
        }
    }

    private void find(final int type) {
        if (connection == null) {
            return;
        }
        FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), type, connection, null, false, false);
        if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {

            final List<String> selectedIds = dialog.getSelectedNames();

            try {
                getContainer().run(true, false, new IRunnableWithProgress() {

                    @Override
                    public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                        try {
                            Session session = connection.openSession(null);
                            final DimensionsObjectFactory factory = session.getObjectFactory();
                            session.run(new ISessionRunnable() {
                                @Override
                                public void run() throws Exception {
                                    monitor.beginTask(null, selectedIds.size() + 10 + 100);

                                    List list1 = new ArrayList(selectedIds.size());
                                    List list2 = new ArrayList(selectedIds.size());

                                    for (Iterator iter = selectedIds.iterator(); iter.hasNext();) {
                                        String projectId = (String) iter.next();
                                        DimensionsArObject project = null;
                                        if (type == IDMConstants.PROJECT) {
                                            project = factory.getProject(projectId);
                                        } else {
                                            Filter filter = new Filter();
                                            filter.criteria().add(
                                                    new Filter.Criterion(SystemAttributes.OBJECT_SPEC, projectId,
                                                            Filter.Criterion.EQUALS));
                                            List baselines = factory.getBaselines(filter);
                                            if (!baselines.isEmpty()) {
                                                project = (Baseline) baselines.get(0);
                                            }
                                        }
                                        if (project != null && !containsProject(project)) {
                                            list2.add(project);
                                            if (type == IDMConstants.PROJECT) {
                                                list1.add(new WorksetAdapter((Project) project, connection));
                                            } else {
                                                list1.add(new BaselineAdapter((Baseline) project, connection));
                                            }
                                        }
                                        monitor.worked(1);
                                    }
                                    if (type == IDMConstants.BASELINE) {
                                        Utils.queryAttributes(list2, new int[] { SystemAttributes.DESCRIPTION }, factory, true);
                                    } else {
                                        Utils.queryAttributes(list2, new int[] { SystemAttributes.DESCRIPTION,
                                                SystemAttributes.WSET_IS_STREAM }, factory, true);
                                    }
                                    monitor.worked(10);
                                    addToSelection(list1, Utils.subMonitorFor(monitor, 100));
                                };
                            }, monitor);
                        } catch (DMException e) {
                            throw new InvocationTargetException(e);
                        } finally {
                            monitor.done();
                        }
                    }

                });
            } catch (InvocationTargetException e) {
                DMTeamUiPlugin.getDefault().handle(e);
            } catch (InterruptedException ignore) {
            } finally {
                tableViewer.refresh();
                validate();
            }
        }
    }

    private void browse() {
        WorksetSelectionDialog dialog = new WorksetSelectionDialog(getShell(),
                Messages.ProjectImportWizard_SelectionPage_browsedialog_title, connection, ProjectBrowsePanel.SHOW_ALL
                        | ProjectBrowsePanel.STRICT_MODE, true /* multi */, false, false);
        if (dialog.open() == Window.OK) {
            final List selectedObjects = dialog.getSelectedObjects();
            final ArrayList listToQuery = new ArrayList();
            for (Iterator iter = selectedObjects.iterator(); iter.hasNext();) {
                VersionManagementProject project = (VersionManagementProject) iter.next();
                if (!containsProject(project.getAPIObject())) {
                    listToQuery.add(project.getAPIObject());
                } else {
                    iter.remove();
                }
            }

            if (!listToQuery.isEmpty()) {
                try { // ensure description is cached by the newly added objects
                    getContainer().run(true, false, new IRunnableWithProgress() {

                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            monitor.beginTask(null, 100);
                            try {
                                final Session session = connection.openSession(null);
                                session.run(new ISessionRunnable() {
                                    @Override
                                    public void run() throws Exception {
                                        Utils.queryAttributes(listToQuery, new int[] { SystemAttributes.DESCRIPTION },
                                                session.getObjectFactory(), true);
                                    }
                                }, monitor);
                                monitor.worked(50);
                                addToSelection(selectedObjects, Utils.subMonitorFor(monitor, 50));
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            } finally {
                                monitor.done();
                            }
                        }

                    });
                } catch (InvocationTargetException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                } catch (InterruptedException ignore) {
                } finally {
                    tableViewer.refresh();
                    validate();
                }
            }
        }
    }

    private void removeSelection() {
        ISelection currentSelection = tableViewer.getSelection();
        if (!currentSelection.isEmpty() && currentSelection instanceof IStructuredSelection) {
            for (Iterator iterator = ((IStructuredSelection) currentSelection).iterator(); iterator.hasNext();) {
                selection.remove(iterator.next());
            }
            tableViewer.refresh();
        }
        validate();
    }

    private void removeAll() {
        selection.clear();
        tableViewer.refresh();
        validate();
    }

    private void validate() {
        boolean complete = false;
        String error = null;
        if (!selection.isEmpty()) {
            for (Iterator iter = selection.iterator(); iter.hasNext();) {
                APIObjectAdapter project = (APIObjectAdapter) iter.next();
                if (getProjectCount(project.getAPIObject()) > 1) {
                    error = Messages.ProjectImportWizard_SelectionPage_dupsErr;
                }
            }
            complete = error == null;
        }
        setPageComplete(complete);
        setErrorMessage(error);
    }

    private int getProjectCount(DimensionsArObject project) {
        if (selection.isEmpty()) {
            return 0;
        }
        String id = (String) project.getAttribute(SystemAttributes.OBJECT_SPEC);
        if (id == null) {
            return 0;
        }
        int cnt = 0;
        for (Iterator iter = selection.iterator(); iter.hasNext();) {
            VersionManagementProject adapter = (VersionManagementProject) iter.next();
            if (project == adapter.getAPIObject()
                    || (id.equals(adapter.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC)) && checkGender(project,
                            adapter.getAPIObject()))) {
                cnt++;
            }
        }
        return cnt;
    }

    private boolean containsProject(DimensionsArObject project) {
        return getProjectCount(project) > 0;
    }

    private boolean checkGender(DimensionsArObject o1, DimensionsArObject o2) {
        return (o1 instanceof Project && o2 instanceof Project) || (o1 instanceof Baseline && o2 instanceof Baseline)
                || (o1 instanceof ItemRevision && o2 instanceof ItemRevision);
    }

    private void addToSelection(List objects, IProgressMonitor monitor) throws DMException {
        monitor.beginTask(null, objects.size() * 10);
        try {
            for (Iterator iter = objects.iterator(); iter.hasNext();) {
                APIObjectAdapter object = (APIObjectAdapter) iter.next();
                addToSelection(object, Utils.subMonitorFor(monitor, 10));
            }
        } finally {
            monitor.done();
        }
    }

    // caches ide project information if necessary
    private void addToSelection(APIObjectAdapter object, IProgressMonitor monitor) throws DMException {
        APIObjectAdapter container = getContainer(object);
        if (!sccProjects.containsKey(container)) {
            SccProjectList list = new SccProjectList(container);
            list.fetch(monitor);
            sccProjects.put(container, list);
        }
        selection.add(object);
    }

    private APIObjectAdapter getContainer(Object element) {
        if (element instanceof SccProject) {
            return ((SccProject) element).getProjectContainer();
        }
        if (element instanceof SccProjectContainerWorkset || element instanceof SccBaselineContainer) {
            return (APIObjectAdapter) element;
        }
        if (element instanceof WorksetAdapter) {
            return new SccProjectContainerWorkset((WorksetAdapter) element);
        }
        return new SccBaselineContainer((BaselineAdapter) element);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Updates workspace resources.
 * @author V.Grishchenko
 */
public abstract class UpdateWorkspaceOperation extends RepositoryProviderOperation {
    private List skippedFiles = new ArrayList();
    private boolean warnAboutFailures = true;

    public UpdateWorkspaceOperation(IWorkbenchPart part, IResource[] resources) {
        super(part, resources);
    }

    public UpdateWorkspaceOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    /**
     * @return files that were skipped during the update
     */
    public IFile[] getSkippedFiles() {
        return (IFile[]) skippedFiles.toArray(new IFile[skippedFiles.size()]);
    }

    protected void addSkippedFile(IFile file) {
        skippedFiles.add(file);
    }

    @Override
    protected String getTaskName() {
        return Messages.UpdateFromRemoteOperation_0;
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind(Messages.UpdateFromRemoteOperation_1, provider.getProject().getName());
    }

    // skip conflicting changes or additions
    protected boolean isUpdatable(SyncInfo syncInfo) {
        int kind = syncInfo.getKind();
        return !((kind & SyncInfo.DIRECTION_MASK) == SyncInfo.CONFLICTING && ((kind & SyncInfo.CHANGE_MASK) == SyncInfo.CHANGE || (kind & SyncInfo.CHANGE_MASK) == SyncInfo.ADDITION));
    }

    /*
     * clear skipped files just in case we are re-run
     */
    @Override
    protected void startOperation() {
        super.startOperation();
        skippedFiles.clear();
    }

    @Override
    public void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
        super.execute(monitor);
        if (!skippedFiles.isEmpty() && shouldWarnAboutFailures()) {
            warnAboutFailedResources(getSkippedFiles());
        }
    }

    public void setWarnAboutFailures(boolean b) {
        warnAboutFailures = b;
    }

    protected boolean shouldWarnAboutFailures() {
        return warnAboutFailures;
    }

    /**
     * Warn user that some files could not be updated.
     * Note: This method is designed to be overridden by test cases.
     */
    protected void warnAboutFailedResources(IResource[] conflicts) {
        IStatus[] errors = new IStatus[conflicts.length];
        for (int i = 0; i < errors.length; i++) {
            errors[i] = new Status(IStatus.WARNING, DMTeamUiPlugin.ID, 0, conflicts[i].getFullPath().toString(), null);
        }
        final MultiStatus error = new MultiStatus(DMTeamUiPlugin.ID, 0, errors, Messages.DMSafeUpdateOperation_11, null);
        UIUtils.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                ErrorDialog.openError(getShell(), Messages.DMSafeUpdateOperation_0, Messages.DMSafeUpdateOperation_1, error);
            }
        });
    }

}

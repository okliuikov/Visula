/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectBrowsePanel;

/**
 * @author bstephenson
 */
public class SelectProjectForDefaultRequest extends WorksetSelectionDialog {
    private static final int basic_options = ProjectBrowsePanel.SHOW_WORKSETS | ProjectBrowsePanel.SHOW_SINGLE_ECLIPSE_PROJECTS
            | ProjectBrowsePanel.SHOW_SCC_PROJECT_CONTAINERS;

    public SelectProjectForDefaultRequest(Shell parentShell, String title, DimensionsConnectionDetailsEx connection) {
        super(parentShell, title, connection, basic_options | ProjectBrowsePanel.SHOW_IN_WORKSPACE, true, false, false);
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        // create the main dialog area
        Composite composite = (Composite) super.createDialogArea(parent);
        Button b1 = new Button(composite, SWT.CHECK);
        b1.setText(Messages.defaultRequest_setActive_onlyworkspace_title);
        b1.setToolTipText(Messages.defaultRequest_setActive_onlyworkspace_tooltip);
        b1.setSelection(true);
        b1.addSelectionListener(new SelectionAdapter() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                Button b = (Button) e.getSource();
                if (b != null) {
                    if (b.getSelection()) {
                        worksetSelectionPanel.setOptions(basic_options | ProjectBrowsePanel.SHOW_IN_WORKSPACE);
                    } else {
                        worksetSelectionPanel.setOptions(basic_options);
                    }
                }
            }
        });
        return composite;
    }
}

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.revisions.IRevisionRulerColumn;
import org.eclipse.jface.text.revisions.RevisionInformation;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.internal.editors.quickdiff.LastSaveReferenceProvider;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;

public class BlameAnnotateLocalOperation extends BlameAnnotateOperation {

    public BlameAnnotateLocalOperation(IDMRemoteFile resource, IWorkbenchPage page, DimensionsConnectionDetailsEx connection) {
        super(resource, page, connection);
    }

    @Override
    protected IEditorInput createEditorInput() {
        IFile file = getBase().getLocalFile();
        if (file != null) {
            return new FileEditorInput(file);
        }
        return null;
    }

    @Override
    protected void showRevisionInformation(AbstractDecoratedTextEditor editor, RevisionInformation info) throws CoreException {
        editor.showRevisionInformation(info, LastSaveReferenceProvider.class.getName());
        getPage().activate(editor);
        editor.setFocus();

        IFile localFile = getBase().getLocalFile();
        if (localFile != null && localFile.exists()) {
            // Need to remove previous listeners. This cover possible wrong selection if
            // user open blame annotation, update this file with newer revision, reopen blame annotation
            Object curChObj = localFile.getSessionProperty(changeListener);
            Object curMlObj = localFile.getSessionProperty(menuListener);

            IResourceChangeListener chListener = null;
            MenuDetectListener mdListener = null;

            if (curChObj != null && curChObj instanceof IResourceChangeListener) {
                chListener = (IResourceChangeListener) curChObj;

            }

            if (curMlObj != null && curMlObj instanceof MenuDetectListener) {
                mdListener = (MenuDetectListener) curMlObj;
            }

            IRevisionRulerColumn c = (IRevisionRulerColumn) editor.getAdapter(IRevisionRulerColumn.class);

            if (c != null && mdListener != null) {
                Control control = c.getControl();
                control.removeMenuDetectListener(mdListener);
            }

            if (chListener != null) {
                localFile.getWorkspace().removeResourceChangeListener(chListener);
            }

            chListener = addResourceChangeListener(c);
            mdListener = addMenuDetectListener(info, c);

            localFile.setSessionProperty(changeListener, chListener);
            localFile.setSessionProperty(menuListener, mdListener);

        }
    }

}

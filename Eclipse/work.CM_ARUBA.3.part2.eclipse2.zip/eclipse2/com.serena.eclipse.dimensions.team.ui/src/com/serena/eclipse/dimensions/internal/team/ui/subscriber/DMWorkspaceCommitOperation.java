/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import com.serena.dmclient.api.PersonalStreamHelper;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.StreamInitialData;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspaceMultipleCommand1;
import com.serena.eclipse.dimensions.internal.team.core.DeliverMultipleCommand;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.ShelfDetails;
import com.serena.eclipse.dimensions.internal.team.core.ShelveMultipleCommand;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.TransferToStreamMultipleCommandData;
import com.serena.eclipse.dimensions.internal.team.core.TransferToStreamOperationData;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandLocalScope;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.actions.xml.MergeScopeGroup;
import com.serena.eclipse.dimensions.internal.team.ui.operations.DeliverOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UploadOperation;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.ShelveWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.UpdateStreamWizardFactory;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.WizardFactory;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class DMWorkspaceCommitOperation extends DMSynchronizeModelOperation {
    private DMWorkspaceCommitHelper commitHelper;
    private boolean override;

    // currently this field is being used for shelving purposes
    private Map<Project, DimensionsConnectionDetailsEx> syncScope;

    /**
     * Creates a non-overriding commit operation
     */
    public DMWorkspaceCommitOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        this(configuration, elements, false);
    }

    /**
     * Creates a non-overriding stream commit operation
     */
    public DMWorkspaceCommitOperation(boolean streamDeliverOperation, boolean streamShelveOperation,
            ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        super(configuration, elements, streamDeliverOperation, streamShelveOperation);
    }

    /**
     * Creates an operation that can override and commit incoming changes and conflicts.
     */
    public DMWorkspaceCommitOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements, boolean override) {
        super(configuration, elements);
        this.override = override;
    }

    SyncInfoSet getNonOverlapping(SyncInfoSet set) {
        IResource[] noResources = TeamUtils.getNonOverlapping(set.getResources());
        if (noResources.length == set.size()) {
            return set;
        }
        return reduceInfoSet(set, noResources);
    }

    @Override
    public boolean prompt() throws InvocationTargetException, InterruptedException {
        final SyncInfoSet originalSet = getSyncInfoSet();

        try {
            handleConflictingDeletions(originalSet);
            if (!originalSet.isEmpty()) {
                handleConflictingFolderAdditions(originalSet);
            }
        } catch (CoreException e1) {
            throw new InvocationTargetException(e1);
        }

        if (originalSet.isEmpty()) {
            return false;
        }

        if (!isStreamShelveOperation()) {
            if (!promptForConflictHandling(originalSet)) {
                return false;
            }
        }

        IProgressService progressSvc = PlatformUI.getWorkbench().getProgressService();
        progressSvc.busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    // note that commit helper may modify original set if it contains move sources
                    boolean isStreamOperation = isStreamOperation();
                    boolean isShelveOperation = isStreamShelveOperation();
                    commitHelper = new DMWorkspaceCommitHelper(originalSet, isStreamOperation, isShelveOperation, monitor);
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                }
            }
        });
        DMTeamUiPlugin.warnAboutCleanedCheckouts(commitHelper.getCleanedCheckouts(), getShell());

        if (!commitHelper.getStatus().isOK()) {
            ErrorDialog.openError(getShell(), getJobName(), commitHelper.getErrorMessage(), commitHelper.getStatus());
            if (!commitHelper.continueOnError()) {
                return false;
            }
        }

        if (commitHelper.getAllRequests().size() == 0) {
            return false;
        }

        DMWorkspaceCommitWizard wizard = new DMWorkspaceCommitWizard(commitHelper, isStreamDeliverOperation(),
                isStreamShelveOperation());

        if (isStreamShelveOperation()) {
            if (syncScope.size() != 1) {
                // shelving to different projects not supports
                return false;
            }
            initShelfInitials(wizard);
        }

        WizardDialog dialog;
        if (isStreamShelveOperation()) {
            // for shelve use its own dialog class which allows to set correct height and width
            dialog = new ShelveWizardDialog(getShell(), wizard);
        } else {
            dialog = new TeamOperationWizardDialog(getShell(), wizard);
        }

        if (dialog.open() != Window.OK) {
            return false;
        }

        setSyncInfoSet(reduceInfoSet(originalSet, commitHelper.getOperationResources()));
        return true;
    }

    private void initShelfInitials(final DMWorkspaceCommitWizard wizard) throws InvocationTargetException, InterruptedException {
        IProgressService progressSvc = PlatformUI.getWorkbench().getProgressService();
        progressSvc.busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    Entry<Project, DimensionsConnectionDetailsEx> pair = syncScope.entrySet().iterator().next();
                    DimensionsConnectionDetailsEx con = pair.getValue();
                    final Project project = pair.getKey();
                    final Session session = con.openSession(monitor);
                    session.run(new ISessionRunnable() {

                        @Override
                        public void run() throws Exception {
                            PersonalStreamHelper personalStreamHelper = session.getObjectFactory().getPersonalStreamHelper();
                            StreamInitialData shelfInitials = personalStreamHelper.getShelfStreamInitials(project, "", ""); //$NON-NLS-1$//$NON-NLS-2$

                            if (!StringPath.isNullorEmpty(shelfInitials.getStreamId())) {
                                shelfInitials.setDescription(NLS.bind(Messages.DMWorkspaceCommitOperation_2NewShelfDescription,
                                        project.getName()));
                            }

                            wizard.setShelfInitialData(shelfInitials, project);
                        }
                    }, monitor);
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                }
            }
        });
    }

    protected boolean promptForConflictHandling(SyncInfoSet syncSet) {
        if (syncSet.hasConflicts() || syncSet.hasIncomingChanges()) {
            if (override) {
                return promptForConflicts(syncSet);
            }
            // If there is a conflict in the syncSet, remove from sync set.
            syncSet.removeConflictingNodes();
            syncSet.removeIncomingNodes();
        }
        return true;
    }

    protected boolean promptForConflicts(SyncInfoSet syncSet) {
        final Shell shell = getShell();
        final boolean[] resultHolder = new boolean[1];
        shell.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                resultHolder[0] = MessageDialog.openQuestion(getShell(), Messages.confirm_overwrite,
                        Messages.DMWorkspaceCommitOperation_0);
            }
        });
        return resultHolder[0];
    }

    private SyncInfoSet reduceInfoSet(SyncInfoSet set, IResource[] resources) {
        SyncInfoSet reducedSet = new SyncInfoSet();
        for (int i = 0; i < resources.length; i++) {
            SyncInfo syncInfo = set.getSyncInfo(resources[i]);
            assert syncInfo != null;
            reducedSet.add(syncInfo);
        }
        return reducedSet;
    }

    @Override
    protected void run(SyncData data, IProgressMonitor monitor) throws CoreException, InterruptedException {
        DMRepositoryProvider provider = data.getProvider();
        IDMProject project = provider.getIdmProject();

        CommitRequestsProcessor requestProcessor;
        if (!project.getIsStream()) {
            requestProcessor = new UploadRequestsProcessor(commitHelper, override);
        } else {
            requestProcessor = new DeliverRequestsProcessor(commitHelper, override);
        }

        List<WorkspaceResourceRequest> requestsForCommit = requestProcessor.getRequestsForCommit(data);
        int totalWork = 1000 * requestProcessor.getAllRequestsCount();

        monitor.beginTask(null, totalWork);
        try {
            if (!requestsForCommit.isEmpty()) {
                WorkspaceResourceRequest[] requests = requestsForCommit.toArray(new WorkspaceResourceRequest[requestsForCommit.size()]);
                if (!project.getIsStream()) {
                    UploadOperation uploadOperation = new UploadOperation(getPart(), new IResource[0]);

                    OperationData opData = new OperationData(provider, requests);

                    uploadOperation.execute(opData, Utils.subMonitorFor(monitor, totalWork));

                } else {
                    Assert.isLegal(data instanceof DeliverSyncData);
                    DeliverSyncData delSyncData = (DeliverSyncData) data;

                    TransferToStreamOperationData opData = new TransferToStreamOperationData(provider, requests,
                            delSyncData.getExcludedResources(), delSyncData.getDeliverShape());

                    DeliverOperation deliverOperation = new DeliverOperation(getPart(), new IResource[0]);
                    deliverOperation.execute(opData, Utils.subMonitorFor(monitor, totalWork));
                }
            }

            if (commitHelper != null && commitHelper.getPostCommandExecuteProvider() != null) {
                commitHelper.getPostCommandExecuteProvider().postExecute(monitor);
            }

        } finally {
            monitor.done();
        }

    }

    @Override
    protected void run(List<DeliverSyncData> datas, IProgressMonitor monitor) throws CoreException, InterruptedException {
        if (datas.isEmpty()) {
            return;
        }

        int totalWork = 0;
        TransferToStreamMultipleCommandData multiData = new TransferToStreamMultipleCommandData();

        for (DeliverSyncData opData : datas) {
            if (!opData.getSyncInfoSet().isEmpty()) {
                DMRepositoryProvider provider = opData.getProvider();
                DeliverRequestsProcessor requestProcessor = new DeliverRequestsProcessor(commitHelper, override);
                List<WorkspaceResourceRequest> requestsForCommit = requestProcessor.getRequestsForCommit(opData);

                multiData.addData(provider, requestsForCommit, opData.getExcludedResources(), opData.getDeliverShape());
                multiData.setShelving(opData.isShelving());
                totalWork += 1000 * requestProcessor.getAllRequestsCount();
            }
        }

        boolean shelving = multiData.isShelving();

        monitor.beginTask(null, totalWork);
        try {
            DMWorkspaceMultipleCommand1 cmd;

            if (!shelving) {
                cmd = new DeliverMultipleCommand(multiData);
            } else {
                cmd = new ShelveMultipleCommand(multiData);
                ((ShelveMultipleCommand) cmd).setShelfDetails(commitHelper.getShelfDetails());
            }

            cmd.run(Utils.subMonitorFor(monitor, totalWork));

            if (commitHelper != null && commitHelper.getPostCommandExecuteProvider() != null) {
                commitHelper.getPostCommandExecuteProvider().postExecute(monitor);
            }
        } finally {
            monitor.done();
        }

        if (shelving) {
            ShelfDetails shelfDetails = commitHelper.getShelfDetails();
            if (shelfDetails.isReset()) {
                openUpdateResetWizard(multiData);
            }
        }
    }

    private void openUpdateResetWizard(TransferToStreamMultipleCommandData multiData) throws CoreException {
        Map<IDMProject, TransferToStreamOperationData> deliverOpeartions = multiData.getDeliverOpeartions();
        List<IResource> projects = new ArrayList<IResource>();
        for (IDMProject dmProject : deliverOpeartions.keySet()) {
            projects.add(dmProject.getProject());

        }
        // selected scope
        MergeCommandLocalScope mergeScope = MergeCommandLocalScope.createMergeCommandLocalScope(projects.toArray(new IResource[projects.size()]), true);
        if (mergeScope == null) {
            return;
        }

        ThreeWayWizard wizard = null;
        if (projects.size() > 0) {
            // potential scopes from top-level workspace projects
            List<MergeScopeGroup> possibleMergeScopes = MergeScopeGroup.createValidScopeGroups(mergeScope.getConnection());
            WizardFactory factory = new UpdateStreamWizardFactory(mergeScope, possibleMergeScopes, mergeScope.getConnection(), true);
            wizard = new ThreeWayWizard(factory);
        }

        if (wizard == null) {
            return;
        }

        final ThreeWayWizardDialog dialog = new ThreeWayWizardDialog(getShell(), wizard);
        Display.getDefault().syncExec(new Runnable() {

            @Override
            public void run() {
                BusyIndicator.showWhile(Display.getDefault(), new Runnable() {

                    @Override
                    public void run() {
                        if (dialog.open() == Window.CANCEL) {
                            return;
                        }
                    }

                });
            }
        });
    }

    @Override
    protected String getJobName() {
        if (isStreamDeliverOperation()) {
            return Messages.DMWorkspaceDeliverOperation_1;
        } else if (isStreamShelveOperation()) {
            return Messages.DMWorkspaceShelveOperation_1;
        } else {
            return Messages.DMWorkspaceCommitOperation_1;
        }
    }

    void setSynchronizationScope(Map<Project, DimensionsConnectionDetailsEx> syncScope) {
        this.syncScope = syncScope;
    }

}

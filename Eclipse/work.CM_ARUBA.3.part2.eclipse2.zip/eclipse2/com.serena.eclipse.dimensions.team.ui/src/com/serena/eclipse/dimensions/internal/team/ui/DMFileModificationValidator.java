/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResourceStatus;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.team.core.TeamException;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.core.ConnectJob;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMFileModificationValidator;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.ModificationValidationDialog;
import com.serena.eclipse.dimensions.internal.team.ui.operations.CheckoutOperation;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class DMFileModificationValidator implements IDMFileModificationValidator {

    public DMFileModificationValidator() {
    }

    static IPreferenceStore getPreferences() {
        return DMTeamUiPlugin.getDefault().getPreferenceStore();
    }

    static boolean promptCheckedOut() {
        return IDMTeamPreferences.EDIT_CHECKED_OUT_PROMPT.equals(getPreferences().getString(IDMTeamPreferences.EDIT_CHECKED_OUT));
    }

    static boolean promptUnmanaged() {
        return IDMTeamPreferences.EDIT_UNMANAGED_PROMPT.equals(getPreferences().getString(IDMTeamPreferences.EDIT_UNMANAGED));
    }

    static boolean promptManaged() {
        return IDMTeamPreferences.EDIT_MANAGED_PROMPT.equals(getPreferences().getString(IDMTeamPreferences.EDIT_MANAGED));
    }

    static boolean checkoutManaged() {
        return IDMTeamPreferences.EDIT_MANAGED_CHECKOUT.equals(getPreferences().getString(IDMTeamPreferences.EDIT_MANAGED));
    }

    static boolean makeLocalManaged() {
        return IDMTeamPreferences.EDIT_MANAGED_LOCAL.equals(getPreferences().getString(IDMTeamPreferences.EDIT_MANAGED));
    }

    static void storePreference(String name, String value) {
        getPreferences().setValue(name, value);
        DMTeamUiPlugin.getDefault().savePluginPreferences();
    }

    @Override
    public IStatus validateEdit(DMRepositoryProvider provider, IFile[] files, Object context) {
        if (files == null || files.length == 0) {
            return Status.OK_STATUS;
        }

        try {
            ArrayList unmanagedAndReadOnly = new ArrayList();
            ArrayList checkedOutAndReadOnly = new ArrayList();
            ArrayList pessimistic = new ArrayList();
            boolean isBaseline = provider.getIdmProject().isBaseline();

            for (int i = 0; i < files.length; i++) {
                IDMWorkspaceFile dmFile = getDMFile(files[i]);
                if (dmFile.isPessimistic()) {
                    pessimistic.add(files[i]);
                } else if (files[i].isReadOnly() && dmFile.isExtracted()) {
                    checkedOutAndReadOnly.add(files[i]);
                } else if (files[i].isReadOnly() && !dmFile.isManaged()) {
                    unmanagedAndReadOnly.add(files[i]);
                }
            }
            boolean hasBeenHandled = true;

            if (!unmanagedAndReadOnly.isEmpty()) {
                hasBeenHandled = handleUnmanaged(context,
                        (IFile[]) unmanagedAndReadOnly.toArray(new IFile[unmanagedAndReadOnly.size()]));
            }

            if (!checkedOutAndReadOnly.isEmpty()) {
                hasBeenHandled = handleCheckedOut(context,
                        (IFile[]) checkedOutAndReadOnly.toArray(new IFile[checkedOutAndReadOnly.size()]));
            }

            if (!pessimistic.isEmpty()) {
                DimensionsConnectionDetailsEx connection = provider.getIdmProject().getConnection();
                boolean isStream = provider.getIdmProject().getIsStream();
                boolean makeLocal = makeLocalManaged();
                if (!makeLocal) {
                    preconditionConnection(connection);
                }
                // when offline or in make local mode just make files optimistic - no prompt needed
                if (makeLocal || connection.isOffline()) {
                    makeOptimistic((IFile[]) pessimistic.toArray(new IFile[pessimistic.size()]));
                } else if (connection.isSessionOpen()) { // if session is not open login was canceled or failed
                    hasBeenHandled = handlePessimistic(context, (IFile[]) pessimistic.toArray(new IFile[pessimistic.size()]),
                            isStream || isBaseline);
                }
            }
            if (hasBeenHandled) {
                return validateSuccessful(files);
            } else {
                return Status.CANCEL_STATUS;
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);
            return e.getStatus();
        }
    }

    private ModificationValidationDialog prompt(Shell shell, String title, String message, IFile[] files, boolean offerCheckout) {

        final ModificationValidationDialog dialog = new ModificationValidationDialog(shell, title, message, files, offerCheckout);
        final boolean[] canceled = new boolean[1];
        shell.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                canceled[0] = dialog.open() == Window.CANCEL;
            }
        });
        if (canceled[0]) {
            return null;
        }
        return dialog;
    }

    private boolean handlePessimistic(Object context, IFile[] pessimisticArray, boolean isStream) throws CoreException {
        boolean shouldCheckout = false;
        if (context != null) {
            if (promptManaged()) {
                ModificationValidationDialog dialog = prompt(getShell(context), Messages.DMFileModificationValidator_0,
                        Messages.DMFileModificationValidator_1, pessimisticArray, !isStream);
                if (dialog == null) {
                    return false;
                }
                shouldCheckout = dialog.checkoutFiles();

                if (dialog.storePreference()) {
                    storePreference(IDMTeamPreferences.EDIT_MANAGED, shouldCheckout
                            ? IDMTeamPreferences.EDIT_MANAGED_CHECKOUT : IDMTeamPreferences.EDIT_MANAGED_LOCAL);
                }
            } else {
                shouldCheckout = checkoutManaged();
            }
        }

        if (shouldCheckout) {
            checkout(getShell(context), pessimisticArray);
        } else {
            makeOptimistic(pessimisticArray);
        }
        return true;
    }

    private boolean prompt(final CheckoutOperation operation) {
        final boolean[] result = new boolean[1];
        UIUtils.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                try {
                    result[0] = operation.prompt();
                } catch (InvocationTargetException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                } catch (InterruptedException e) {
                }
            }
        });
        return result[0];
    }

    private void checkout(final Shell shell, final IFile[] files) {
        final CheckoutOperation operation = new CheckoutOperation(null, files, null);
        operation.setShell(shell);
        operation.setValidatingEdit(true);
        try {
            if (prompt(operation)) {
                // run on the calling thread to avoid scheduling rule conflicts
                if (Display.getCurrent() != null) {
                    PlatformUI.getWorkbench().getProgressService().run(false, true, new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            operation.run(monitor);
                        }
                    });
                } else {
                    operation.run(null); // run without progress when non-ui
                }
            }
        } catch (InvocationTargetException e) {
            String title = Messages.DMFileModificationValidator_8;
            String msg = Messages.DMFileModificationValidator_9;
            Throwable target = e.getTargetException();
            if (target instanceof TeamException) { // should already have status info
                UIUtils.showError(shell, title, msg, ((TeamException) target).getStatus(), operation.getShowDetailsAction());
            } else {
                DMTeamUiPlugin.getDefault().handle(e, shell, title, msg);
            }
        } catch (InterruptedException e) {
        }
    }

    private boolean handleUnmanaged(Object context, IFile[] unmanagedArray) {
        if (context != null && promptUnmanaged()) {
            ModificationValidationDialog dialog = prompt(getShell(context), Messages.DMFileModificationValidator_2,
                    Messages.DMFileModificationValidator_3, unmanagedArray, false);
            if (dialog == null) {
                return false;
            }
            if (dialog.storePreference()) {
                storePreference(IDMTeamPreferences.EDIT_UNMANAGED, IDMTeamPreferences.EDIT_UNMANAGED_EDIT);
            }
        }
        makeWriteable(unmanagedArray);
        return true;
    }

    private boolean handleCheckedOut(Object context, IFile[] coroArray) {
        if (context != null && promptCheckedOut()) {
            ModificationValidationDialog dialog = prompt(getShell(context), Messages.DMFileModificationValidator_4,
                    Messages.DMFileModificationValidator_5, coroArray, false);
            if (dialog == null) {
                return false;
            }
            if (dialog.storePreference()) {
                storePreference(IDMTeamPreferences.EDIT_CHECKED_OUT, IDMTeamPreferences.EDIT_CHECKED_OUT_EDIT);
            }
        }
        makeWriteable(coroArray);
        return true;
    }

    private void preconditionConnection(DimensionsConnectionDetailsEx connection) {
        if (!connection.isSessionOpen() && !connection.isOffline()) {
            ConnectJob connectJob = new ConnectJob(connection);
            connectJob.schedule();
            try {
                connectJob.join();
            } catch (InterruptedException e1) {
            }
        }
    }

    private Shell getShell(Object context) {
        if (context instanceof Shell) {
            return (Shell) context;
        }
        return UIUtils.findShell();
    }

    private IDMWorkspaceFile getDMFile(IFile file) throws CoreException {
        return (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(file);
    }

    @Override
    public IStatus validateSave(DMRepositoryProvider provider, IFile file) {
        return validateEdit(provider, new IFile[] { file }, null);
    }

    private IStatus validateSuccessful(IFile[] files) {
        IStatus[] statuses = new IStatus[files.length];
        boolean allOk = true;
        for (int i = 0; i < files.length; i++) {
            statuses[i] = getStatus(files[i]);
            if (!statuses[i].isOK()) {
                allOk = false;
            }
        }
        if (allOk) {
            return Status.OK_STATUS;
        }
        MultiStatus multiStatus = new MultiStatus(DMTeamUiPlugin.ID, 0, statuses, Messages.DMFileModificationValidator_6, null);
        return multiStatus;
    }

    private IStatus getStatus(IFile file) {
        if (!file.isReadOnly()) {
            return Status.OK_STATUS;
        }
        return new Status(IStatus.ERROR, DMTeamUiPlugin.ID, IResourceStatus.READ_ONLY_LOCAL, NLS.bind(
                Messages.DMFileModificationValidator_7, file.getFullPath().toString()), null);
    }

    private void makeOptimistic(IFile[] files) throws CoreException {
        DMTeamPlugin.getWorkspace().setMode(files, false, null);
    }

    private void makeWriteable(IFile[] files) {
        for (int i = 0; i < files.length; i++) {
            TeamUtils.setReadOnly(files[i], false);
        }
    }

}

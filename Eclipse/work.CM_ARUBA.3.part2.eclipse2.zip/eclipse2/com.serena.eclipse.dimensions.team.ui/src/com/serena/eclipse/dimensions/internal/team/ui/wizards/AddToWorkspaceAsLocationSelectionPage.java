/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * @author V.Grishchenko
 */

public class AddToWorkspaceAsLocationSelectionPage extends LocationPage {
    public static final String ADD_TO_WORKSPACE_LOCATION_PAGE_ID = "add_to_workspace_location_page_id"; //$NON-NLS-1$
    private static final int SIZING_TEXT_FIELD_WIDTH = 250;

    private Button browseButton;
    private Text locationPathField;
    private Label locationLabel;

    public AddToWorkspaceAsLocationSelectionPage(String pageName, ProjectMapping[] mappings) {
        super(pageName, mappings);
        setTitle(Messages.AddToWorkspaceAsLocationSelectionPage_title);
        setDescription(Messages.AddToWorkspaceAsLocationSelectionPage_description);
        setMappings(mappings);
    }

    public AddToWorkspaceAsLocationSelectionPage(ProjectMapping[] mappings) {
        this(ADD_TO_WORKSPACE_LOCATION_PAGE_ID, mappings);
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            // update if single project name was changed since page was last shown
            if (isSingleProject() && singleProject != null && !singleProject.getName().equals(mappings[0].getLocalProjectName())) {
                singleProject = null;
                setLocationForSelection(false);
            }
        }
        super.setVisible(visible);
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 3);

        setControl(composite);

        // required in order to use setButtonLayoutData
        initializeDialogUnits(composite);

        final Button useDefaultsButton = new Button(composite, SWT.CHECK | SWT.RIGHT);
        useDefaultsButton.setText(Messages.AddToWorkspaceAsLocationSelectionPage_useDefault);
        useDefaultsButton.setSelection(this.useDefaults);
        useDefaultsButton.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 3, 1));

        createUserSpecifiedProjectLocationGroup(composite, !useDefaults);

        SelectionListener listener = new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                useDefaults = useDefaultsButton.getSelection();
                browseButton.setEnabled(!useDefaults);
                locationPathField.setEditable(!useDefaults);
                locationLabel.setEnabled(!useDefaults);
                setLocationForSelection(true);
                MessageHolder msg = useDefaults ? new MessageHolder() : checkValidLocation();
                setErrorMessage(msg.getErrorMsg());
                if (msg.isRemoveInformationMsg()) {
                    setMessage(null);
                }
            }
        };
        useDefaultsButton.addSelectionListener(listener);
        Dialog.applyDialogFont(parent);
    }

    /**
     * Creates the project location specification controls.
     *
     * @return the parent of the widgets created
     * @param projectGroup
     *            the parent composite
     * @param enabled
     *            - sets the initial enabled state of the widgets
     */
    private Composite createUserSpecifiedProjectLocationGroup(Composite projectGroup, boolean enabled) {

        // location label
        locationLabel = new Label(projectGroup, SWT.NONE);
        if (isSingleProject()) {
            locationLabel.setText(Messages.AddToWorkspaceAsLocationSelectionPage_location);
        } else {
            locationLabel.setText(Messages.AddToWorkspaceAsLocationSelectionPage_directory);
        }
        locationLabel.setEnabled(enabled);
        locationLabel.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));

        // project location entry field
        locationPathField = new Text(projectGroup, SWT.BORDER);
        GridData data = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
        data.widthHint = SIZING_TEXT_FIELD_WIDTH;
        locationPathField.setLayoutData(data);
        locationPathField.setEditable(enabled);

        // browse button
        this.browseButton = new Button(projectGroup, SWT.PUSH);
        this.browseButton.setText(Messages.AddToWorkspaceAsLocationSelectionPage_browse);
        this.browseButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent event) {
                handleLocationBrowseButtonPressed();
            }
        });
        this.browseButton.setEnabled(enabled);
        setButtonLayoutData(browseButton);

        locationPathField.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                MessageHolder msg = checkValidLocation();
                setErrorMessage(msg.getErrorMsg());
                setPageComplete(msg.getErrorMsg() == null);
            }
        });

        setLocationForSelection(true);

        return projectGroup;
    }

    @Override
    protected void setPathField(String text) {
        locationPathField.setText(text);
    }
    
    @Override
    protected String getPathField() {
        return locationPathField.getText();
    }

    /**
     * Set the location to the default location if we are set to useDefaults.
     */
    private void setLocationForSelection(boolean changed) {
        if (useDefaults) {
            IPath defaultPath = calcDefaultPath();
            if (defaultPath != null) {
                locationPathField.setText(defaultPath.toOSString());
            }
            targetLocation = null;
            createWorkArea = false;
        } else if (changed) {
            IPath location = null;
            IProject project = getSingleProject();
            if (project != null) {
                try {
                    location = project.getDescription().getLocation();
                } catch (CoreException e) {
                    // ignore the exception
                }
            }
            if (location == null) {
                targetLocation = null;
                locationPathField.setText(Utils.EMPTY_STRING);
            } else {
                if (isSingleProject()) {
                    targetLocation = location.toOSString();
                } else {
                    targetLocation = location.removeLastSegments(1).toOSString();
                }
                locationPathField.setText(targetLocation);
            }
        }
    }

    /**
     * Open an appropriate directory browser
     */
    private void handleLocationBrowseButtonPressed() {
        proceedWithDirectoryDialog();
        targetLocation = getPathField();
    }
}

class MessageHolder {
    private boolean removeInfo = true;
    private String errMsg = null;

    public boolean isRemoveInformationMsg() {
        return removeInfo;
    }

    public void setRemoveInformationMsg(boolean removeInfo) {
        this.removeInfo = removeInfo;
    }

    public String getErrorMsg() {
        return errMsg;
    }

    public void setErrorMsg(String errMsg) {
        this.errMsg = errMsg;
    }
}

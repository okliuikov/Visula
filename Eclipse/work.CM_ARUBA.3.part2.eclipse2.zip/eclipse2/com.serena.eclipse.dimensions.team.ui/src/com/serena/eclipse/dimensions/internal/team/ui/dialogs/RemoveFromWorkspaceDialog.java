package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import java.util.List;

import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;

public class RemoveFromWorkspaceDialog extends ResizableDialog {

	private List<String> projectsToRemove;
	private static final int WIDTH_HINT = 350;
		
	public RemoveFromWorkspaceDialog(Shell parent, List<String> projectsToRemove) {
		super(parent);
		this.projectsToRemove = projectsToRemove;
	}
	
	public List<String> getProjectsToRemove() {
		return projectsToRemove;
	}

    @Override
    protected Control createDialogArea(Composite parent) {

    	getShell().setText(Messages.AddToWorkspaceAsWizard_title);
        Composite composite = (Composite) super.createDialogArea(parent);
        UIUtils.setGridLayout(composite, 1);
        Label label = new Label(composite, SWT.NONE);
        label.setText(NLS.bind(Messages.ProjectsInTargetStreamHaveSameNamesInWorkspace, projectsToRemove.size()));
        label = new Label(composite, SWT.NONE);
        label.setText(Messages.DoYouWantRemoveProjectsFromWorkspace);
        label = new Label(composite, SWT.NONE);
        label.setText(Messages.SelectProjectsToRemoveFromWorkspace);
        
        Table nbTable = new Table(composite, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CHECK);

        nbTable.setHeaderVisible(true);
        nbTable.setLinesVisible(true);
        GridData gridData2 = new GridData(GridData.HORIZONTAL_ALIGN_FILL | GridData.GRAB_HORIZONTAL | GridData.VERTICAL_ALIGN_FILL
                | GridData.GRAB_VERTICAL);

        gridData2.verticalSpan = 4;
        int listHeight = nbTable.getItemHeight() * 10;
        Rectangle trim = nbTable.computeTrim(0, 0, 0, listHeight);

        gridData2.heightHint = trim.height;
        gridData2.widthHint = (WIDTH_HINT * 2) / 3;
        nbTable.setLayoutData(gridData2);

        TableLayout layout = new TableLayout();
        createColumns(nbTable, layout);
        nbTable.setLayout(layout);

        nbTable.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				if (event.detail == SWT.CHECK) {
					TableItem item = (TableItem) event.item;
					if (item.getChecked()) {
						projectsToRemove.add(item.getText());
					} else {
						projectsToRemove.remove(item.getText());
					}
				}
			}
        });
        
        for (String project : projectsToRemove) {
            TableItem ti = new TableItem(nbTable, SWT.NONE);
            ti.setText(new String[] { project });
            ti.setChecked(true);
        }
        return composite;
    }
    
    private void createColumns(Table table, TableLayout layout) {
        // single column
        TableColumn column = new TableColumn(table, SWT.NONE);
        column.setResizable(true);
        column.setText(Messages.ProjectName);
        layout.addColumnData(new ColumnWeightData(5, true));
    }
}

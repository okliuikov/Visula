/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.action.IAction;
import org.eclipse.ui.PartInitException;

import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.views.DimensionsItemHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 *
 * @author ABollmann
 *
 */
public class ItemHistoryAction extends DMWorkspaceAction {
    private static final StatusFilter MY_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED
            | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);

    public ItemHistoryAction() {
    }

    @Override
    protected boolean isEnabledForMultipleResources() {
        return false;
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

    @Override
    protected boolean isEnabledForFolder() {
        return false;
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return MY_FILTER;
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] selectedResources = getSelectedResources();
        if (selectedResources == null || selectedResources.length == 0 || selectedResources[0].getType() != IResource.FILE) {
            return;
        }
        DimensionsItemHistoryView histView = null;
        try {
            histView = (DimensionsItemHistoryView) getActivePart().getSite().getPage().showView(DimensionsItemHistoryView.VIEW_ID);
        } catch (PartInitException pe) {
            DMTeamUiPlugin.getDefault().handle(pe);
        }
        if (histView != null) {
            histView.showHistory((IFile) selectedResources[0]);
        }
    }

}
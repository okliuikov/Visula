/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.util.List;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ActionWizard;

/**
 * @author V.Grishchenko
 */
public class ActionWorksetAction extends DimensionsAction {

    public ActionWorksetAction() {
        super();
    }

    public ActionWorksetAction(boolean usesDeclarativeEnablement) {
        super(usesDeclarativeEnablement);
    }

    @Override
    public void run(IAction action) {
        List selectedWorksets = getSelection().toList();
        WorksetAdapter[] worksets = new WorksetAdapter[selectedWorksets.size()];
        for (int i = 0; i < selectedWorksets.size(); i++) {
            worksets[i] = (WorksetAdapter) selectedWorksets.get(i);
        }
        ActionWizard wizard = new ActionWizard(worksets);
        WizardDialog dialog = new WizardDialog(getShell(), wizard);
        dialog.open();
    }

    @Override
    protected boolean isEnabledForSelection() {
        return isSameConnection();
    }

}

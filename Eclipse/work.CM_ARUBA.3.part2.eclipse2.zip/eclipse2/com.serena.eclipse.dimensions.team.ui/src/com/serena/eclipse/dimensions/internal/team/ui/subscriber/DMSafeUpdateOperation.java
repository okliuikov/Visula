/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.OrSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMSyncInfo;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspaceSyncInfo;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.IPromptCondition;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.PromptingDialog;
import com.serena.eclipse.dimensions.internal.team.ui.operations.ReplaceWithRemoteOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UpdateWorkspaceOperation;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.actions.ShowDetailsAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * This update action will update all non-conflicting resources first and then prompt the
 * user to overwrite any resources that failed the safe update.
 *
 * Subclasses should determine how the update should handle conflicts by implementing
 * the getOverwriteLocalChanges() method.
 */
public abstract class DMSafeUpdateOperation extends DMSynchronizeModelOperation {

    private boolean promptBeforeUpdate = false;

    private SyncInfoSet skipped = new SyncInfoSet();

    protected DMSafeUpdateOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements, boolean promptBeforeUpdate) {
        super(configuration, elements);
        this.promptBeforeUpdate = promptBeforeUpdate;
    }

    @Override
    public boolean shouldRun() {
        return promptIfNeeded();
    }

    protected boolean shouldValidateEdit() {
        return false;
    }

    @Override
    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
        skipped.clear();
        super.run(monitor);
        try {
            handleFailedUpdates(monitor);
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
    }

    @Override
    public void run(SyncData data, IProgressMonitor monitor) throws CoreException {
        data.getProvider();
        SyncInfoSet syncSet = data.getSyncInfoSet();
        try {
            monitor.beginTask(null, 100);

            handleConflictingDeletions(syncSet);
            if (syncSet.isEmpty()) {
                return;
            }

            // Remove the cases that are known to fail (adding them to skipped list)
            removeKnownFailureCases(syncSet);

            // Process validate edit
            if (shouldValidateEdit()) {
                validateEdit(syncSet);
            }

            // Run the update on the remaining nodes in the set
            // The update will fail for conflicts that turn out to be non-automergable
            safeUpdate(syncSet, Utils.subMonitorFor(monitor, 100));

            // Remove all failed conflicts from the original sync set
            syncSet.rejectNodes(new FastSyncInfoFilter() {
                @Override
                public boolean select(SyncInfo info) {
                    return skipped.getSyncInfo(info.getLocal()) != null;
                }
            });

            // Signal for the ones that were updated
            updated(syncSet.getSyncInfos(), null);
        } finally {
            monitor.done();
        }
    }

    private SyncInfoSet removeKnownFailureCases(SyncInfoSet syncSet) {
        // First, remove any known failure cases
        FastSyncInfoFilter failFilter = getKnownFailureCases();
        SyncInfo[] willFail = syncSet.getNodes(failFilter);
        syncSet.rejectNodes(failFilter);
        for (int i = 0; i < willFail.length; i++) {
            SyncInfo info = willFail[i];
            skipped.add(info);
        }
        return syncSet;
    }

    private void handleFailedUpdates(IProgressMonitor monitor) throws CoreException {
        // Handle conflicting files, ask the user what should be done.
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 1000);
        try {
            if (!skipped.isEmpty()) {
                if (getOverwriteLocalChanges()) {
                    // Ask the user if a replace should be performed on the remaining nodes
                    if (promptForOverwrite(skipped) && !skipped.isEmpty()) {
                        try {
                            overwriteUpdate(skipped, Utils.subMonitorFor(monitor, 900));
                        } finally {
                            if (!skipped.isEmpty()) {
                                updated(skipped.getSyncInfos(), Utils.subMonitorFor(monitor, 100));
                            } else {
                                monitor.worked(100);
                            }
                        }
                    }
                } else {
                    // Warn the user that some nodes could not be updated. This can happen if there are
                    // files with conflicts.
                    warnAboutFailedResources(skipped);
                }
            }
        } finally {
            monitor.done();
        }
    }

    protected boolean getOverwriteLocalChanges() {
        return false;
    }

    /**
     * Perform a safe update on the resources in the provided set. Any included resources
     * that cannot be updated safely will be added to the skippedFiles list.
     *
     * @param syncSet
     *            the set containing the resources to be updated
     * @param monitor
     */
    protected void safeUpdate(SyncInfoSet syncSet, IProgressMonitor monitor) throws CoreException {
        syncSet = DMWorkspaceCommitHelper.resolveRepositoryMoves(syncSet);
        SyncInfo[] changed = syncSet.getSyncInfos();
        if (changed.length == 0) {
            return;
        }

        // The list of sync resources to be updated
        List<SyncInfo> updateShallow = new ArrayList<SyncInfo>();
        // A list of sync resource folders which need to be created locally
        // (incoming addition or previously pruned)
        Set<SyncInfo> parentCreationElements = new HashSet<SyncInfo>();
        // A list of sync resources that are incoming deletions.
        // We do these first to avoid case conflicts
        List<SyncInfo> updateDeletions = new ArrayList<SyncInfo>();
        // List updateFolderDeletions = new ArrayList();

        for (int i = 0; i < changed.length; i++) {
            SyncInfo changedNode = changed[i];

            // Make sure that parent folders exist
            SyncInfo parent = getParent(changedNode);
            if (parent != null && isOutOfSync(parent)) {
                // We need to ensure that parents that are either incoming folder additions
                // or previously pruned folders are recreated.
                parentCreationElements.add(parent);
            }

            IResource resource = changedNode.getLocal();
            int kind = changedNode.getKind();
            boolean willBeAttempted = false;
            if (resource.getType() == IResource.FILE) {
                // Not all change types will require an update
                // Some can be deleted locally without performing an update
                switch (kind & SyncInfo.DIRECTION_MASK) {
                case SyncInfo.INCOMING:
                    switch (kind & SyncInfo.CHANGE_MASK) {
                    case SyncInfo.DELETION:
                        // Incoming deletions can just be deleted instead of updated
                        updateDeletions.add(changedNode);
                        willBeAttempted = true;
                        break;
                    default:
                        // add the file to the list of files to be updated
                        updateShallow.add(changedNode);
                        willBeAttempted = true;
                        break;
                    }
                    break;
                case SyncInfo.CONFLICTING:
                    switch (kind & SyncInfo.CHANGE_MASK) {
                    case SyncInfo.CHANGE:
                        // add the file to the list of files to be updated
                        updateShallow.add(changedNode);
                        willBeAttempted = true;
                        break;
                    case SyncInfo.DELETION:
                        break;
                    }
                    break;
                }
                if (!willBeAttempted) {
                    skipped.add(syncSet.getSyncInfo(resource));
                }
            } else {
                if ((kind & SyncInfo.DIRECTION_MASK) == SyncInfo.INCOMING && (kind & SyncInfo.CHANGE_MASK) == SyncInfo.DELETION) {
                    updateDeletions.add(changedNode);
                } else if (isOutOfSync(changedNode)) {
                    parentCreationElements.add(changedNode);
                }
            }
        }
        try {
            monitor.beginTask(null, 100);

            if (parentCreationElements.size() > 0) {
                SyncInfo[] parentSyncInfos = parentCreationElements.toArray(new SyncInfo[parentCreationElements.size()]);
                ensureParentsExist(parentSyncInfos, Utils.subMonitorFor(monitor, 25), true);
                writeMetadataForEmptyFolders(parentCreationElements, updateShallow);
                updated(parentSyncInfos, null);
            }
            if (updateDeletions.size() > 0) {
                runUpdateDeletions(updateDeletions.toArray(new SyncInfo[updateDeletions.size()]), Utils.subMonitorFor(monitor, 25));
            }
            if (updateShallow.size() > 0) {
                processRepositoryMoves(updateShallow, monitor);
                runSafeUpdate(updateShallow.toArray(new SyncInfo[updateShallow.size()]), Utils.subMonitorFor(monitor, 50));
            }
        } finally {
            monitor.done();
        }
        return;
    }

    /**
     * When empty folders are downloaded metadata won't be written by dmnet api.
     * For non empty folders metadata will be written by dmnet api
     */
    private void writeMetadataForEmptyFolders(Set<SyncInfo> parentCreationElements, List<SyncInfo> updateShallow)
            throws CoreException {
        ArrayList<IContainer> folders = new ArrayList<IContainer>();
        IContainer folder = null;
        if (parentCreationElements.size() > 0) {
            Iterator<SyncInfo> iterFolder = parentCreationElements.iterator();
            while (iterFolder.hasNext()) {
                IContainer container = (IContainer) ((DMSyncInfo) iterFolder.next()).getLocal();
                folders.add(container);
            }
        }
        for (int i = 0; i < folders.size(); i++) {
            folder = folders.get(i);
            if (!TeamUtils.hasFolderGotFileInItOrItsSubfolders(folder)) {
                TeamUtils.ensureReacheable(folder, true);
            }
        }
    }

    /**
     * Perform an overwrite (unsafe) update on the resources in the provided set.
     * The passed sync set may contains resources from multiple projects and
     * it cannot be assumed that any scheduling rule is held when this method
     * is invoked.
     *
     * @param syncSet
     *            the set containing the resources to be updated, upon
     *            return of this method it should contain resources which were successfully
     *            overwritten
     * @param monitor
     */
    protected abstract void overwriteUpdate(SyncInfoSet syncSet, IProgressMonitor monitor) throws CoreException;

    /*
     * Return a filter which selects the cases that we know ahead of time
     * will fail on an update
     */
    protected FastSyncInfoFilter getKnownFailureCases() {
        return new OrSyncInfoFilter(new FastSyncInfoFilter[] { new SyncInfoDirectionFilter(SyncInfo.OUTGOING) });
    }

    /**
     * Warn user that some files could not be updated.
     * Note: This method is designed to be overridden by test cases.
     */
    protected void warnAboutFailedResources(final SyncInfoSet syncSet) {
        IResource[] conflicts = syncSet.getResources();
        IStatus[] errors = new IStatus[conflicts.length];
        for (int i = 0; i < errors.length; i++) {
            errors[i] = new Status(IStatus.WARNING, DMTeamUiPlugin.ID, 0, conflicts[i].getFullPath().toString(), null);
        }
        final MultiStatus error = new MultiStatus(DMTeamUiPlugin.ID, 0, errors, Messages.DMSafeUpdateOperation_11, null);
        UIUtils.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                ErrorDialog.openError(getShell(), Messages.DMSafeUpdateOperation_0, Messages.DMSafeUpdateOperation_1, error);
            }
        });
    }

    /**
     * This method is invoked for all resources in the sync set that are incoming deletions.
     * It is done separately to allow deletions to be performed before additions that may
     * be the same name with different letter case.
     *
     * @param nodes
     *            the SyncInfo nodes that are incoming deletions
     * @param monitor
     * @throws TeamException
     */
    protected abstract void runUpdateDeletions(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException;

    /**
     * This method is invoked for all resources in the sync set that are incoming changes
     * (but not deletions: @see runUpdateDeletions) or conflicting changes.
     * This method should only update those conflicting resources that are automergable.
     *
     * @param nodes
     *            the incoming or conflicting SyncInfo nodes
     * @param monitor
     * @throws TeamException
     */
    protected abstract void runSafeUpdate(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException;

    protected void safeUpdate(UpdateWorkspaceOperation updateOperation, IProgressMonitor monitor) throws CoreException {
        try {
            updateOperation.run(monitor);
            addSkippedFiles(updateOperation.getSkippedFiles());
        } catch (InvocationTargetException e) {
            setErrorDetails(updateOperation.getErrorDetails());
            Throwable target = e.getTargetException();
            if (target instanceof CoreException) {
                throw (CoreException) target;
            }
            throw new DMException(Messages.DMSafeUpdateOperation_2, target);
        } catch (InterruptedException e) {
            Utils.cancelOperation();
        }
    }

    /**
     * Notification of all resource that were updated (either safely or otherwise)
     */
    protected abstract void updated(SyncInfo[] resources, IProgressMonitor monitor) throws CoreException;

    private void addSkippedFiles(IFile[] files) {
        SyncInfoSet set = getSyncInfoSet();
        for (int i = 0; i < files.length; i++) {
            IFile file = files[i];
            skipped.add(set.getSyncInfo(file));
        }
    }

    protected String getErrorTitle() {
        return Messages.DMSafeUpdateOperation_3;
    }

    @Override
    protected String getJobName() {
        SyncInfoSet syncSet = getSyncInfoSet();
        return NLS.bind(Messages.DMSafeUpdateOperation_9, String.valueOf(syncSet.size()));
    }

    /**
     * Confirm with the user what we are going to be doing. By default the update action doesn't
     * prompt because the user has usually selected resources first. But in some cases, for example
     * when performing a toolbar action, a confirmation prompt is nice.
     *
     * @param set
     *            the resources to be updated
     * @return <code>true</code> if the update operation can continue, and <code>false</code> if the update has been cancelled by
     *         the user.
     */
    private boolean promptIfNeeded() {
        final SyncInfoSet set = getSyncInfoSet();
        final boolean[] result = new boolean[] { true };
        if (getPromptBeforeUpdate()) {
            UIUtils.getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    String message = NLS.bind(Messages.DMSafeUpdateOperation_10, String.valueOf(set.size()));
                    result[0] = MessageDialog.openQuestion(getShell(), Messages.DMSafeUpdateOperation_8, message);
                }
            });
        }
        return result[0];
    }

    public void setPromptBeforeUpdate(boolean prompt) {
        this.promptBeforeUpdate = prompt;
    }

    public boolean getPromptBeforeUpdate() {
        return promptBeforeUpdate;
    }

    /**
     * @param updateShallow
     *            - All updates including conflicting changes part if repository moves
     * @param repositoryMoveList
     *            - Contains all repository move.
     * @param repositoryMoveSyncPair
     *            - Repository move stored as key-value pair
     * @param movedFromSyncList
     * @param movedToSyncList
     * @throws CoreException
     */
    private void excludeRepositoryMovesFromUpdate(List<SyncInfo> updateShallow, List<SyncInfo> repositoryMoveList,
            HashMap<IResource, IResource> repositoryMoveSyncPair, List<SyncInfo> movedFromSyncList, List<SyncInfo> movedToSyncList)
            throws CoreException {
        if (updateShallow.size() > 0) {
            IResource resDelete = null;
            IResource resAdd = null;
            String itemSpecIdOfDeletedItem = null;
            String itemSpecIdOfAddedItem = null;
            int kind1 = 0;
            int kind2 = 0;
            IResource movedinRespositoryFrom = null;
            IResource movedinRespositoryTo = null;
            for (int i = 0; i < updateShallow.size(); i++) {
                resDelete = updateShallow.get(i).getLocal();
                if (resDelete.getType() == IResource.FILE) {
                    kind1 = updateShallow.get(i).getKind();
                    if (kind1 == (SyncInfo.CONFLICTING | SyncInfo.CHANGE)) {
                        movedinRespositoryTo = DMTeamPlugin.getWorkspace().getMovedInRepositoryTo(resDelete);
                        if (movedinRespositoryTo != null) {
                            itemSpecIdOfDeletedItem = ((IDMRemoteFile) updateShallow.get(i).getBase()).getItemSpecId();
                            for (int j = 0; j < updateShallow.size(); j++) {
                                resAdd = ((DMWorkspaceSyncInfo) updateShallow.get(j)).getLocal();
                                if (resAdd.getType() == IResource.FILE) {
                                    kind2 = updateShallow.get(j).getKind();
                                    if (kind2 == (SyncInfo.INCOMING | SyncInfo.ADDITION)) {
                                        movedinRespositoryFrom = DMTeamPlugin.getWorkspace().getMovedInRepositoryFrom(resAdd);
                                        if (movedinRespositoryFrom != null && resDelete.equals(movedinRespositoryFrom)) {
                                            itemSpecIdOfAddedItem = ((IDMRemoteFile) ((DMWorkspaceSyncInfo) updateShallow.get(j)).getRemote()).getItemSpecId();
                                            if (itemSpecIdOfDeletedItem.equals(itemSpecIdOfAddedItem)) {
                                                repositoryMoveList.add(updateShallow.get(i));
                                                repositoryMoveList.add(updateShallow.get(j));
                                                movedFromSyncList.add(updateShallow.get(i));
                                                movedToSyncList.add(updateShallow.get(j));
                                                repositoryMoveSyncPair.put(resDelete, resAdd);
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            updateShallow.removeAll(repositoryMoveList);
        }
    }

    private boolean promptForDiscardChanges(final SyncInfoSet syncSet, final HashMap<IResource, IResource> repositoryMoveSyncPair) {

        IPromptCondition condition = new IPromptCondition() {
            @Override
            public boolean needsPrompt(IResource resource) {
                return syncSet.getSyncInfo(resource).getKind() == (SyncInfo.CONFLICTING | SyncInfo.CHANGE);
            }

            @Override
            public String promptMessage(IResource resource) {
                return NLS.bind(Messages.DMRepositoryMoveUpdateOperation_confirmDiscardChangesMessage, resource.getFullPath()
                        .toString());
            }
        };

        PromptingDialog dialog = new PromptingDialog(getShell(), syncSet.getResources(), condition,
                Messages.DMRepositoryMoveUpdateOperation_confirmDiscardChangesTitle, true, 2);
        try {
            final HashSet<?> deselected = new HashSet<Object>();
            final HashSet<IResource> resToOverwrite = new HashSet<IResource>(Arrays.asList(dialog.promptForMultiple(deselected)));
            FastSyncInfoFilter rejectFilter = new FastSyncInfoFilter() {
                @Override
                public boolean select(SyncInfo info) {
                    return !resToOverwrite.contains(info.getLocal()) || deselected.contains(info.getLocal())
                            || isPartOfDeSelectedPair(repositoryMoveSyncPair, deselected, info.getLocal());
                }
            };
            syncSet.rejectNodes(rejectFilter);
        } catch (InterruptedException e) {
            return false; // cancel
        }
        return !syncSet.isEmpty();
    }

    private boolean isPartOfDeSelectedPair(HashMap<IResource, IResource> repositoryMoveSyncPair, HashSet<?> deSelectedList,
            IResource resource) {
        Iterator<?> deSel = deSelectedList.iterator();
        while (deSel.hasNext()) {
            if (resource.equals(repositoryMoveSyncPair.get(deSel.next()))) {
                return true;
            }
        }
        return false;
    }

    private void processRepositoryMoves(List<SyncInfo> updateShallow, IProgressMonitor monitor) throws CoreException {
        // Processing following case of repository moves separately.
        // Case : User1 modifies a file locally, but the same file is moved in repository by another user. User1 does a sync.
        // Repository move will be shown as an incoming addition and a conflicting change. If the user selects the incoming addition
        // node only and does an Update then we need to make sure that the conflicting change node too is included and
        // "Override and Update" operation is invoked on it.
        ArrayList<SyncInfo> repositoryMoveList = new ArrayList<SyncInfo>();
        // Repository move nodes stored as key - value pair. Key being the conflicting change
        HashMap<IResource, IResource> repositoryMoveSyncPair = new HashMap<IResource, IResource>();
        ArrayList<SyncInfo> movedFromSyncList = new ArrayList<SyncInfo>();
        ArrayList<SyncInfo> movedToSyncList = new ArrayList<SyncInfo>();
        excludeRepositoryMovesFromUpdate(updateShallow, repositoryMoveList, repositoryMoveSyncPair, movedFromSyncList,
                movedToSyncList);
        SyncInfoSet overrideAndUpdateSet = new SyncInfoSet();
        for (int i = 0; i < repositoryMoveList.size(); i++) {
            overrideAndUpdateSet.add((repositoryMoveList.get(i)));
        }
        if (promptForDiscardChanges(overrideAndUpdateSet, repositoryMoveSyncPair)) {
            DMTeamPlugin.getDefault();
            DMTeamPlugin.getWorkspace().retainMetadataOfTheResourceBeingMoved(movedToSyncList, movedFromSyncList, monitor);

            ReplaceWithRemoteOperation replaceOperation = new ReplaceWithRemoteOperation(getPart(),
                    overrideAndUpdateSet.getResources()) {
                @Override
                protected boolean refreshBeforeUpdate() {
                    return false; // assume up to date as we are run from sync view
                }

                @Override
                protected boolean isDeleteUnmanaged() {
                    return true; // override user preference when run from the sync view
                }
            };
            try {
                replaceOperation.run(monitor);
            } catch (InvocationTargetException e) {
                ((ShowDetailsAction) getGotoAction()).setDetails(replaceOperation.getErrorDetails());
            } catch (InterruptedException ie) {
            }
        }
    }
}

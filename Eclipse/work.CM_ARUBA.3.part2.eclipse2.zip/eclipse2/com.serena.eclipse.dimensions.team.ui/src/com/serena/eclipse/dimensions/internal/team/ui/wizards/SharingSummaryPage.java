/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsNewWizard;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * Displays sharing summary.
 * @author V.Grishchenko
 */
public class SharingSummaryPage extends DimensionsWizardPage {
    // defaults
    private static boolean OPEN_SYNC_VIEW = false;
    private static boolean RUN_ADD = true;

    private String connection;
    private boolean newConnection;
    private String workset;
    private String project;
    private boolean newWorkset;
    private String defaultBranch;
    private List validBranches;
    private boolean useSbm;
    boolean isStream;

    private Text connectionTxt;
    private Text newConnectionTxt;
    private Text worksetTxt;
    private Text projectTxt;
    private Text newWorksetTxt;
    Text defaultBranchTxt;

    Text validBranchesTxt;
    private Button addToControlBtn;
    private Button openSyncBtn;
    private boolean inContainer;
    private String offset;
    private Text offsetTxt;
    private Text inContainerTxt;
    private Text useSbmTxt;

    Label defBranchLbl;
    Label validBranchesLbl;
    Label objectBeingCreatedLbl;
    Label objectNameLbl;
    VersionManagementProject projectSelected;

    /**
     * @param newConnection2
     * @return
     */
    private static String getBooleanText(boolean value) {
        return value ? Messages.SharingSummaryPage_true : Messages.SharingSummaryPage_false;
    }

    private static String getText(String value) {
        if (Utils.isNullEmpty(value)) {
            return Messages.SharingSummaryPage_none;
        }
        return value;
    }

    public SharingSummaryPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(description);

    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            SharingWizard wizard = (SharingWizard) getWizard();
            projectSelected = (((WorksetSelectionPage) wizard.getPage(SharingWizard.WORKSET_PAGE_ID))).getResult();
            if (projectSelected != null) {
                projectSelected.getAPIObject().queryAttribute(SystemAttributes.WSET_IS_STREAM);
                isStream = ((Boolean) projectSelected.getAPIObject().getAttribute(SystemAttributes.WSET_IS_STREAM)).booleanValue();
            } else {
                isStream = wizard.isStream() || wizard.getMode() == NewStreamWizard.Mode.TOPIC_STREAM;
            }
            setDescription(isStream ? Messages.SharingWizard_streamSummaryPageDescr : Messages.SharingWizard_summaryPageDescr);
            objectNameLbl.setText(isStream ? Messages.SharingSummaryPage_streamLabel : Messages.SharingSummaryPage_projectLabel);
            objectBeingCreatedLbl.setText(isStream ? Messages.SharingSummaryPage_createNewStreamlabel : Messages.SharingSummaryPage_createNewProjectlabel);
        }
        super.setVisible(visible);
    }
    
    @Override
    public void createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 2);

        UIUtils.createLabel(composite, Messages.SharingSummaryPage_connectionLabel);
        connectionTxt = UIUtils.createText(composite, SWT.READ_ONLY, connection);
        UIUtils.setGridData(connectionTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.SharingSummaryPage_createNewConnectionLabel);
        newConnectionTxt = UIUtils.createText(composite, SWT.READ_ONLY, getBooleanText(newConnection));
        UIUtils.setGridData(newConnectionTxt, GridData.FILL_HORIZONTAL);

        objectNameLbl = UIUtils.createLabel(composite, (isStream
                ? Messages.SharingSummaryPage_streamLabel : Messages.SharingSummaryPage_projectLabel));
        worksetTxt = UIUtils.createText(composite, SWT.READ_ONLY, workset);
        UIUtils.setGridData(worksetTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.SharingSummaryPage_ideProjectLabel);
        projectTxt = UIUtils.createText(composite, SWT.READ_ONLY, project);
        UIUtils.setGridData(projectTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.SharingSummaryPage_createdInContainerLabel);
        inContainerTxt = UIUtils.createText(composite, SWT.READ_ONLY, getBooleanText(inContainer));
        UIUtils.setGridData(inContainerTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.SharingSummaryPage_containerOffsetLabel);
        offsetTxt = UIUtils.createText(composite, SWT.READ_ONLY, getDefOffsetText(offset));
        UIUtils.setGridData(offsetTxt, GridData.FILL_HORIZONTAL);

        objectBeingCreatedLbl = UIUtils.createLabel(composite, (isStream
                ? Messages.SharingSummaryPage_createNewStreamlabel : Messages.SharingSummaryPage_createNewProjectlabel));
        newWorksetTxt = UIUtils.createText(composite, SWT.READ_ONLY, getBooleanText(newWorkset));
        UIUtils.setGridData(newWorksetTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.SharingSummaryPage_reqMan);
        useSbmTxt = UIUtils.createText(composite, SWT.READ_ONLY, getReqManString());

        defBranchLbl = UIUtils.createLabel(composite, Messages.SharingSummaryPage_defaultBranch);
        defaultBranchTxt = UIUtils.createText(composite, SWT.READ_ONLY, getDefBranchText(defaultBranch));
        UIUtils.setGridData(defaultBranchTxt, GridData.FILL_HORIZONTAL);

        validBranchesLbl = UIUtils.createLabel(composite, Messages.SharingSummaryPage_validBranches);
        validBranchesTxt = UIUtils.createText(composite, SWT.READ_ONLY, getValidBranchesText(validBranches));
        UIUtils.setGridData(validBranchesTxt, GridData.FILL_HORIZONTAL);

        UIUtils.setGridData(UIUtils.createLabel(composite, null), GridData.FILL_HORIZONTAL, 2);

        Group group = new Group(composite, SWT.NONE);
        UIUtils.setGridData(group, GridData.FILL_HORIZONTAL, 2);
        group.setText(Messages.SharingSummaryPage_optionsGroupText);
        UIUtils.setGridLayout(group, 1);

        addToControlBtn = new Button(group, SWT.CHECK);
        addToControlBtn.setText(Messages.SharingSummaryPage_addButtonText);
        UIUtils.setGridData(addToControlBtn, GridData.FILL_HORIZONTAL);
        addToControlBtn.setSelection(RUN_ADD);

        openSyncBtn = new Button(group, SWT.CHECK);
        openSyncBtn.setText(Messages.SharingSummaryPage_openSyncButtonText);
        UIUtils.setGridData(openSyncBtn, GridData.FILL_HORIZONTAL);
        openSyncBtn.setSelection(OPEN_SYNC_VIEW);

        setControl(composite);
    }

    /**
     * @return
     */
    private String getReqManString() {
        boolean isIdm = false;
        if (getWizard() instanceof DimensionsNewWizard) {
            isIdm = ((DimensionsNewWizard) getWizard()).getConnection().isIdmRequestProvider();
        }

        return useSbm || isIdm ? Messages.SharingSummaryPage_reqManSBM : Messages.SharingSummaryPage_reqManDM;
    }

    public void setConnection(String connection) {
        this.connection = connection;
        if (connectionTxt != null) {
            connectionTxt.setText(getText(connection));
        }
    }

    public void setNewConnection(boolean value) {
        this.newConnection = value;
        if (newConnectionTxt != null) {
            newConnectionTxt.setText(getBooleanText(value));
        }
    }

    public void setNewWorkset(boolean value) {
        this.newWorkset = value;
        if (newWorksetTxt != null) {
            newWorksetTxt.setText(getBooleanText(value));
        }
    }

    public void setProject(String project) {
        this.project = project;
        if (projectTxt != null) {
            projectTxt.setText(getText(project));
        }
    }

    public void setWorkset(String workset) {
        this.workset = workset;
        if (worksetTxt != null) {
            worksetTxt.setText(getText(workset));
        }
    }

    public void setInContainer(boolean value) {
        this.inContainer = value;
        if (inContainerTxt != null) {
            inContainerTxt.setText(getBooleanText(value));
        }
    }

    public void setOffset(String offset) {
        this.offset = offset;
        if (offsetTxt != null) {
            offsetTxt.setText(getText(offset));
        }
    }

    public void setDefaultBranch(String defaultBranch) {
        this.defaultBranch = defaultBranch;
        if (defaultBranchTxt != null) {
            defaultBranchTxt.setText(Utils.getString(getDefBranchText(defaultBranch)));
        }
    }

    public void setValidBranches(List validBranches) {
        this.validBranches = validBranches;
        if (validBranchesTxt != null) {
            validBranchesTxt.setText(Utils.getString(getValidBranchesText(validBranches)));
        }
    }

    public void setUseSbm(boolean b) {
        this.useSbm = b;
        if (useSbmTxt != null) {
            useSbmTxt.setText(getReqManString());
        }
    }

    public boolean openSync() {
        if (openSyncBtn == null) {
            return OPEN_SYNC_VIEW;
        }
        return safeGetBoolean(openSyncBtn);
    }

    public boolean addFiles() {
        if (addToControlBtn == null) {
            return RUN_ADD;
        }
        return safeGetBoolean(addToControlBtn);
    }

    private boolean safeGetBoolean(final Button btn) {
        if (btn == null) {
            return false;
        }
        final boolean[] holder = new boolean[1];
        btn.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                holder[0] = btn.getSelection();
            }
        });
        return holder[0];
    }

    private String getDefBranchText(String defaultBranch) {
        String defBranchStr = null;
        if (defaultBranch == null || (defaultBranch != null && defaultBranch.length() == 0)) {
            defBranchStr = Messages.SharingSummaryPage_noDefaultBranch;
        } else {
            defBranchStr = defaultBranch;
        }
        return defBranchStr;
    }

    private String getDefOffsetText(String defaultOffset) {
        String defOffsetStr = null;
        if (defaultOffset == null || (defaultOffset != null && defaultOffset.length() == 0)) {
            defOffsetStr = Messages.SharingSummaryPage_noOffset;
        } else {
            defOffsetStr = defaultOffset;
        }
        return defOffsetStr;
    }

    private String getValidBranchesText(List _validBranches) {
        String valBranchStr = null;
        if (_validBranches == null || _validBranches.isEmpty()) {
            valBranchStr = Messages.SharingSummaryPage_noValidBranches;
        } else {
            valBranchStr = Utils.toCsvString(_validBranches.toArray(new String[_validBranches.size()]), true);
        }
        return valBranchStr;
    }

}

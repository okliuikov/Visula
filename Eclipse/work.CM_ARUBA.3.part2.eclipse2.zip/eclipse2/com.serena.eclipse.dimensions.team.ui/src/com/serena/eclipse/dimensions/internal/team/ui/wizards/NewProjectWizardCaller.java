package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * Simply calls NewStreamWizard with parameters cause we cannot do it from plugin.xml
 * The wizard will be without "new project" branch & welcome page
 *
 * @author A.Solod
 */
public class NewProjectWizardCaller extends NewStreamWizard {
    public NewProjectWizardCaller() {
        super();
        this.isStream = false;
        this.dontShowWelcomePage = true;
    }

    public NewProjectWizardCaller(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn) {
        super(connection, basedOn, false);
        this.dontShowWelcomePage = true;
    }
}

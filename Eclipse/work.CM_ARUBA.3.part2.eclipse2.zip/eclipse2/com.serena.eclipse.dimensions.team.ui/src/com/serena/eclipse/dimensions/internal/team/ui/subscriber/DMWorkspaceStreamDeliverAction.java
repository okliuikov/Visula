/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2009, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.internal.ui.Utils;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;

@SuppressWarnings("restriction")
public class DMWorkspaceStreamDeliverAction extends DMParticipantAction {
    private static final String MYCOMMITTEXT = Messages.DMWorkspaceCommitAction_0;

    // @formatter:off
    private static final FastSyncInfoFilter MY_INCLUSION_FILTER =
            new FastSyncInfoFilter.AndSyncInfoFilter(
                new FastSyncInfoFilter[] {
                        OnlineFilter.INSTANCE,
                        ProjectTypeFilter.BASELINE_FILTER,
                        new SyncInfoDirectionFilter(new int[] {
                                SyncInfo.OUTGOING
                                })
                        });

    private static final FastSyncInfoFilter MY_EXCLUSION_FILTER =
            new FastSyncInfoFilter.AndSyncInfoFilter(
                new FastSyncInfoFilter[] {
                        OnlineFilter.INSTANCE,
                        ProjectTypeFilter.BASELINE_FILTER,
                        new DeliverFilter(new int[] {
                                SyncInfo.CONFLICTING,
                                SyncInfo.INCOMING
                                })
                        });
    // @formatter:on

    public DMWorkspaceStreamDeliverAction(ISynchronizePageConfiguration configuration) {
        super(MYCOMMITTEXT, configuration);
    }

    public DMWorkspaceStreamDeliverAction(ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider) {
        super(MYCOMMITTEXT, configuration, selectionProvider);
    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        return MY_EXCLUSION_FILTER;
    }

    static FastSyncInfoFilter getSyncInfoInclusionFilter() {
        return MY_INCLUSION_FILTER;
    }

    @Override
    protected boolean updateSelection(IStructuredSelection selection) {
        return isEnabledForSelection(selection);
    }

    private boolean isEnabledForSelection(IStructuredSelection selection) {
        return !Utils.hasMatchingDescendant(selection, getSyncInfoFilter());
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        return new DMWorkspaceCommitOperation(true, false, configuration, elements);
    }

}

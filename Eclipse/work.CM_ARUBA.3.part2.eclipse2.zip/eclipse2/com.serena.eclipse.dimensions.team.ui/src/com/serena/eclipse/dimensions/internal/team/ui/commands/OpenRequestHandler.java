package com.serena.eclipse.dimensions.internal.team.ui.commands;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.ui.internal.PartSite;

import com.serena.dmclient.api.DimensionsChangeStep;
import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.api.IDMRequestIdentifier;
import com.serena.dmclient.api.IDMRequestV2;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.internal.team.ui.ChangeSetViewRequestContributionItem;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.editors.ReportBrowserEditorInput;
import com.serena.eclipse.dimensions.internal.ui.model.IdmRequestData;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class OpenRequestHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        IWorkbenchSite site = HandlerUtil.getActiveSite(event);
        ISelectionProvider selectionProvider = site.getSelectionProvider();
        TreeSelection selection = (TreeSelection) selectionProvider.getSelection();
        Object selObject = selection.getFirstElement();

        ChangeSetHistoryView view = (ChangeSetHistoryView) ((PartSite) site).getPart();
        DimensionsChangeStep changeStep = (DimensionsChangeStep) selObject;

        String requestNameParam = event.getParameter(ChangeSetViewRequestContributionItem.REQUEST_NAME_PARAM);
        if (requestNameParam == null) {
            requestNameParam = changeStep.getRequestsIds().get(0);
        }

        openRequest(view.getConnection(), requestNameParam);

        return null;
    }

    private void openRequest(final DimensionsConnectionDetailsEx conn, final String requestName) {
        Job job = new Job(Messages.blameAnnot_open_request_job) {
            @Override
            protected IStatus run(IProgressMonitor monitor) {
                IStatus result = Status.OK_STATUS;
                try {
                    final ChangeDocumentAdapter[] resultHolder = new ChangeDocumentAdapter[1];
                    final IdmRequestData[] idmHolder = new IdmRequestData[1];
                    final Session session = conn.openSession(monitor);
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            
                            if (conn.isIdmRequestProvider()) {
                                RequestProvider provider = session.getObjectFactory().getRequestProvider(null);
                                IDMHelper helper = session.getObjectFactory().getIDMHelper();
                                List<IDMRequestIdentifier> identifiers = new ArrayList<IDMRequestIdentifier>();
                                identifiers.add(new IDMRequestIdentifier(provider.getUID(), requestName));
                                for (IDMRequestV2 request : helper.getIDMRequests(identifiers)) {
                                    idmHolder[0] = new IdmRequestData(request);
                                    break;
                                }

                            } else {
                                Request requestObj = session.getObjectFactory().findRequest(requestName);
                                if (requestObj != null) {
                                    resultHolder[0] = new ChangeDocumentAdapter(requestObj, conn);
                                }
                            }
                        }
                    }, monitor);

                    if (resultHolder[0] != null || idmHolder[0] != null) {
                        Display.getDefault().asyncExec(new Runnable() {

                            @Override
                            public void run() {
                                if (idmHolder[0] != null) {
                                    try {
                                        if (conn.isSbmRequestProvider()) {
                                            DMUIPlugin.showInBrowser(new ReportBrowserEditorInput(idmHolder[0].name,
                                                    idmHolder[0].octaneLink));
                                        } else {
                                            PlatformUI.getWorkbench().getBrowserSupport().getExternalBrowser()
                                                    .openURL(new URL(idmHolder[0].octaneLink));
                                        }
                                    } catch (PartInitException ignored) {
                                    } catch (MalformedURLException ignored) {
                                    }

                                } else {
                                    IDimensionsObjectEditHandler handler = DMUIPlugin.getDefault()
                                            .getEditHandler(resultHolder[0].getTypeScope());
                                    if (handler != null) {
                                        try {
                                            handler.openEditor(resultHolder[0]);
                                        } catch (CoreException e) {
                                            DMTeamUiPlugin.getDefault().handle(e, UIUtils.findShell(),
                                                    Messages.err_error, Messages.err_openObjEditor);
                                        }
                                    }
                                }
                            }
                        });
                    }

                } catch (DMException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
                return result;
            }

        };
        job.schedule();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.model.IWorkbenchAdapter;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.Product;
import com.serena.dmclient.objects.Type;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProject;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.IDEProjectBaselinesList;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.ProjectGroupBaselinesList;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.INewObjectDetailsPage;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Wizard page for entering new baseline information.
 *
 * @author V.Grishchenko
 *         Baseline only now
 *
 *         Modes Description
 *
 *         TIP_BASELINE
 *         TEMPLATE_BASELINE
 *         REVISED_BASELINE
 */

public class NewBaselineGeneralPage extends DimensionsWizardPage implements INewObjectDetailsPage {
    /** show based on label and find button */
    public static final int SHOW_BASED_ON = 1;
    /** if based on label is showing disables the find button */
    public static final int FIND_DISABLED = 2;

    private int mode;
    private int options;

    private Combo productsCmb;
    private Combo typesCmb;
    private Text objectIdTxt;
    private Label scmProjectLabel;
    private Text scmProjectTxt;
    private CLabel basedOnLbl;
    private Button findBtn;

    public Label objIdLabel;

    private boolean initialized;
    private boolean haveProduct;
    private boolean haveType;
    private boolean haveName;
    private boolean haveBased;

    private DimensionsConnectionDetailsEx connection;

    private Map<String, Product> products = new TreeMap<String, Product>(); // name -> Product
    private Map<String, TreeSet<TypeInfo>> types = new HashMap<String, TreeSet<TypeInfo>>(); // productName -> TreeSet of type infos
    private int typeOptionsRequired = 0; // not now used but left for future

    private APIObjectAdapter basedOnObject;
    private String basedOnProduct;

    private Image basedOnImage;

    private String project; // IDE Project name

    // Flag which indicates whether a Project/Baseline was selected before bringing up the pop up menu
    private boolean isBasedOnSelected = false;
    private Label basedOnTitle;

    /**
     * @param pageName
     * @param title
     * @param description
     * @param titleImage
     * @param connection
     * @param basedOnObject workset or baseline this is based on
     * @param mode one of TIP_BASELINE, TEMPLATE_BASELINE, REVISED_BASELINE
     * @param options
     */
    public NewBaselineGeneralPage(String pageName, String title, String description, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOnObject, int mode, int options) {
        super(pageName, title, titleImage);
        setDescription(description);
        this.connection = connection;
        this.basedOnObject = basedOnObject;
        // initial settings - may get changed
        setMode(mode);
        this.options = options;
        setBasedOn(basedOnObject);
        if (basedOnObject != null) {
            isBasedOnSelected = true;
        }
        setPageComplete(false); // not completed
    }

    private boolean fromWorkset(APIObjectAdapter adapt) {
        return adapt instanceof WorksetAdapter;
    }

    private boolean fromBaseline(APIObjectAdapter adapt) {
        return adapt instanceof BaselineAdapter;
    }

    /**
     * @param basedOnObject
     */
    private boolean setBasedOn(APIObjectAdapter basedOnObject) {
        boolean ret = false;
        if (basedOnObject != null) {
            // only set if the right type
            if ((NewBaselineWizard.isRevisedBaseline(mode) && fromBaseline(basedOnObject))
                    || (NewBaselineWizard.isWorksetBased(mode) && fromWorkset(basedOnObject))) {
                this.basedOnObject = basedOnObject;
                String boName = (String) basedOnObject.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
                if (boName != null) {
                    int idx = boName.indexOf(':');
                    if (idx != -1) {
                        basedOnProduct = boName.substring(0, idx);
                        haveProduct = true;
                    }
                }
                ret = true;
                haveBased = true;
            } else {
                basedOnObject = null;
                isBasedOnSelected = false;
            }
        }
        return ret;
    }

    public void setMode(int mode) {
        Assert.isLegal((mode == NewBaselineWizard.TIP_BASELINE || mode == NewBaselineWizard.TEMPLATE_BASELINE || mode == NewBaselineWizard.REVISED_BASELINE)
                && mode != NewBaselineWizard.INVALID_MODE);
        if (this.mode == mode) {
            return;
        }
        this.mode = mode;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }

    }

    @Override
    public String getProductName() {
        return UIUtils.safeGetCombo(productsCmb);
    }

    public Product getProduct(String productName) {
        return products.get(productName);
    }

    @Override
    public String getTypeName() {
        return UIUtils.safeGetCombo(typesCmb);
    }

    @Override
    public Type getType() {
        String selectedType = UIUtils.safeGetCombo(typesCmb);
        if (Utils.isNullEmpty(selectedType)) {
            return null;
        }
        // get the type from the selected value
        // have to play with the tree set
        TreeSet<TypeInfo> typeInfos = types.get(getProductName());
        if (typeInfos != null) {
            for (Iterator<TypeInfo> iterator = typeInfos.iterator(); iterator.hasNext();) {
                TypeInfo typeInfo = iterator.next();
                if (selectedType.equals(typeInfo.typeName)) {
                    return typeInfo.type;
                }
            }
        }
        return null;
    }

    public String getObjectId() {
        return UIUtils.safeGetText(objectIdTxt);
    }

    public APIObjectAdapter getBasedOnObject() {
        return basedOnObject;
    }

    public String getProject() {
        return UIUtils.safeGetText(scmProjectTxt);
    }

    public void setProject(String project) {
        this.project = project;
        if (scmProjectTxt != null && project != null) {
            scmProjectTxt.setText(project);
        }
    }

    /**
     * @param connection The connection to set.
     */
    @Override
    public void setConnection(DimensionsConnectionDetailsEx connection) {
        if (this.connection == connection || (this.connection != null && this.connection.equals(connection))) {
            return;
        }
        this.connection = connection;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible && !initialized) {
            initializeValues();
        }
        super.setVisible(visible);
    }

    @Override
    public void createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 4);

        UIUtils.createLabel(composite, Messages.newBaselinePage_productLabel);
        productsCmb = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
        UIUtils.setGridData(productsCmb, GridData.FILL_HORIZONTAL, 3);

        UIUtils.createLabel(composite, Messages.newBaselinePage_wstTypeLabel);
        typesCmb = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
        UIUtils.setGridData(typesCmb, GridData.FILL_HORIZONTAL, 3);

        objIdLabel = UIUtils.createLabel(composite, getObjectIdLabelText());
        objectIdTxt = new Text(composite, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(objectIdTxt, GridData.FILL_HORIZONTAL, 3);
        // uppercase the id
        objectIdTxt.addVerifyListener(new VerifyListener() {
            @Override
            public void verifyText(VerifyEvent e) {
                e.text = e.text.toUpperCase();
            }

        });
        objectIdTxt.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                String id = ((Text) e.widget).getText();

                if (id.length() > 0 && isValidNameQuery(id)) {
                    if (getErrorMessage() == Messages.newBaselinePage_badId || getErrorMessage() == Messages.newBaselinePage_noId) {
                        setErrorMessage(null);
                    }
                    haveName = true;
                    checkPage();
                } else {
                    if (id.length() == 0) {
                        setErrorMessage(Messages.newBaselinePage_noId);

                    } else {
                        setErrorMessage(Messages.newBaselinePage_badId);
                    }
                    haveName = false;
                    checkPage();
                }

            }

        });

        if ((SHOW_BASED_ON & options) != 0) {
            basedOnTitle = UIUtils.createLabel(composite, getBaseObjectLabel());
            basedOnLbl = new CLabel(composite, SWT.BORDER);
            UIUtils.setGridData(basedOnLbl, GridData.FILL_HORIZONTAL, 2);
            updateBasedOnLabel();
            findBtn = new Button(composite, SWT.PUSH);
            findBtn.setText(Messages.ProjectSelectionPanel_launchFind);
            findBtn.addSelectionListener(new SelectionAdapter() {
                @Override
                public void widgetSelected(SelectionEvent e) {
                    find();
                }
            });
            findBtn.setEnabled((FIND_DISABLED & options) == 0);
        }

        // only show if input is a SEP , SEP baseline , Project Group , Project Group Baseline

        scmProjectLabel = UIUtils.createLabel(composite, getScmProjectLabelText());
        scmProjectTxt = new Text(composite, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(scmProjectTxt, GridData.FILL_HORIZONTAL, 2);
        UIUtils.createLabel(composite, null);
        boolean fromContainer = ((basedOnObject != null && (basedOnObject instanceof SccProjectContainerWorkset || basedOnObject instanceof SccBaselineContainer)));
        if (fromContainer) {
            scmProjectTxt.setEditable(false);
        }
        UIUtils.createLabel(composite, null);

        enableScm();

        setControl(composite);

        productsCmb.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                String product = productsCmb.getText();
                populateTypes(product);
                haveProduct = true;
                if (!product.equals(basedOnProduct)) {
                    // can't have based on in different product
                    basedOnLbl.setText(Utils.EMPTY_STRING);
                    if (basedOnImage != null) {
                        basedOnImage.dispose();
                        basedOnImage = null;
                        basedOnLbl.setImage(basedOnImage);
                    }
                    basedOnProduct = null;
                    basedOnObject = null;
                    haveBased = false;
                }
                populateName();
                checkPage();
            }
        });

        typesCmb.addSelectionListener(new SelectionAdapter() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                setErrorMessage(null);
                haveType = true;
                checkPage();
            }
        });

    }

    @Override
    public void dispose() {
        if (basedOnImage != null) {
            basedOnImage.dispose();
        }
        super.dispose();
    }

    private boolean enableScm() {
        boolean retval = false;
        if (showScm()) {
            scmProjectLabel.setVisible(true);
            scmProjectTxt.setVisible(true);
            retval = true;
        } else {
            scmProjectLabel.setVisible(false);
            scmProjectTxt.setVisible(false);
        }
        return retval;
    }

    private boolean showScm() {
        boolean ret = false;

        if (basedOnObject != null) {
            if (basedOnObject instanceof DimensionsIDEProject) {
                ret = true;
            } else if (basedOnObject instanceof DimensionsIDEProjectGroup) {
                ret = true;
            } else if (basedOnObject instanceof WorksetAdapter) {
                if (basedOnObject.getParentAdapter() != null && basedOnObject.getParentAdapter() instanceof DimensionsIDEProject) {
                    ret = true;
                }
            } else if (basedOnObject instanceof BaselineAdapter) {
                if (basedOnObject.getObjectList() != null) {
                    if (basedOnObject.getObjectList() instanceof IDEProjectBaselinesList) {
                        ret = true;
                    } else if (basedOnObject.getObjectList() instanceof ProjectGroupBaselinesList) {
                        ret = true;
                    }
                }
            }
        }
        return ret;
    }

    private void updateScmProjectField() {
        if (scmProjectTxt != null) {
            scmProjectTxt.setText(Utils.getString(project));
            boolean fromContainer = ((basedOnObject != null && (basedOnObject instanceof SccProjectContainerWorkset || basedOnObject instanceof SccBaselineContainer)));
            if (basedOnObject != null) { // read-only for baselines and always editable for groups
                if (Utils.isNullEmpty(project) && !fromContainer) {
                    scmProjectTxt.setEditable(true);
                } else {
                    scmProjectTxt.setEditable(false);
                }
            }
        }
    }

    // retrieve base object's ide project name property, contacts the server
    private void processBasedOn(IProgressMonitor monitor) throws DMException {
        if (basedOnObject == null || connection == null) {
            return;
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        try {
            final Session session = connection.openSession(Utils.subMonitorFor(monitor, 1));
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    DimensionsArObject arObject = basedOnObject.getAPIObject();
                    int[] attrs = new int[] { SystemAttributes.IDE_PROJECT_NAME };
                    Utils.queryAttributes(Collections.singletonList(arObject), attrs, session.getObjectFactory(), true);
                    project = (String) arObject.getAttribute(SystemAttributes.IDE_PROJECT_NAME);
                }
            }, monitor);
        } finally {
            monitor.done();
        }
    }

    private String getObjectIdLabelText() {
        return Messages.newBaselinePage_blnLabel;
    }

    private String getScmProjectLabelText() {
        return Messages.newBaselinePage_ideProject;
    }

    private boolean isBasedOnStream(APIObjectAdapter adapt) {
        // default to project
        boolean ret = false;

        Boolean isStream = adapt != null ? ((Boolean) adapt.getAPIObject().getAttribute(SystemAttributes.WSET_IS_STREAM)) : null;
        if (isStream != null) {
            ret = isStream.booleanValue();
        }
        return ret;
    }

    protected String getBaseObjectLabel() {
        String createFrom = ""; // NON-NLS-1$
        if (NewBaselineWizard.isRevisedBaseline(mode)) {
            // has to be baseline
            createFrom = Messages.NewStreamWizard_summary_project3_baseline;
        } else {
            createFrom = isBasedOnStream(basedOnObject)
                    ? Messages.NewStreamWizard_summary_stream3_stream : Messages.NewStreamWizard_summary_project3_project;
        }
        return NLS.bind(Messages.newBaselinePage_Base, createFrom);
    }

    private void updateBasedOnLabel() {
        if (basedOnLbl == null) {
            return;
        }
        Image oldImage = basedOnImage;
        String text = null;
        String productName = null;
        if (basedOnObject != null) {
            IWorkbenchAdapter workbenchAdapter = (IWorkbenchAdapter) basedOnObject.getAdapter(IWorkbenchAdapter.class);
            if (workbenchAdapter != null) {
                ImageDescriptor descriptor = workbenchAdapter.getImageDescriptor(basedOnObject);
                if (descriptor != null) {
                    basedOnImage = descriptor.createImage();
                } else {
                    basedOnImage = null;
                }
            }
            text = (String) basedOnObject.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
            productName = (String) basedOnObject.getAPIObject().getAttribute(SystemAttributes.PRODUCT_NAME);
            productsCmb.select(productsCmb.indexOf(productName));
            if (!isBasedOnSelected) {
                populateTypes(productName);
            }
            objectIdTxt.setEnabled(true);
        } else {
            text = null;
            basedOnImage = null;
        }
        basedOnLbl.setImage(basedOnImage);
        basedOnLbl.setText(text);
        if (oldImage != null) {
            oldImage.dispose();
        }
        basedOnTitle.setText(getBaseObjectLabel());
    }

    private void find() {
        if (connection == null) {
            return;
        }

        FindObjectWizardDialog dialog = null;
        if (mode == NewBaselineWizard.REVISED_BASELINE) {
            dialog = new FindObjectWizardDialog(getShell(), IDMConstants.BASELINE, connection, null, true, false,
                    connection.isOnlyStreamsActive(), connection.isOnlyProjectsActive());
        } else {
            dialog = new FindObjectWizardDialog(getShell(), IDMConstants.PROJECT, connection, null, true, false,
                    connection.isOnlyStreamsActive(), connection.isOnlyProjectsActive(), false, false, true);
        }

        if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {

            List<?> objects = dialog.getFindResult().getObjects();

            final Object selectedObject = objects.get(0);
            final Unit<APIObjectAdapter> result = new Unit<APIObjectAdapter>();

            try {
                if (selectedObject instanceof Project || selectedObject instanceof Baseline) {
                    getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                Session session = connection.openSession(monitor);
                                APIObjectAdapter adapter = session.adapt((DimensionsObject) selectedObject);
                                result.setValue(adapter);
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });
                }

                if (result.getValue() != null) {
                	haveBased = true;
                    setBasedOn(result.getValue());
                    updateBasedOnLabel();
                    populateName();

                    getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                processBasedOn(monitor);
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });
                    enableScm();
                    updateScmProjectField();
                }
            } catch (InvocationTargetException e) {
                handle(e);
            } catch (InterruptedException ignore) {
            }
            checkPage();
        }
    }

    private void initializeValues() {
        products.clear();
        types.clear();
        String selectedProduct = "";
        String selectedType = "";
        final String[][] productNameHolder = new String[1][];
        try {
            IRunnableWithProgress runnableWithProgress = new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    monitor = Utils.monitorFor(monitor);
                    try {
                        monitor.beginTask(null, 100);
                        monitor.worked(25);
                        products.putAll(getProducts(monitor));
                        monitor.worked(25);
                        productNameHolder[0] = products.keySet().toArray(new String[products.size()]);
                        if (productNameHolder[0].length == 1) { // preload wst types for single product
                            List<TypeInfo> objectTypes = getObjectTypes(productNameHolder[0][0], monitor);
                            cacheWorksetTypes(productNameHolder[0][0], objectTypes);
                            monitor.worked(25);
                        } else {
                            monitor.worked(50);
                        }
                        processBasedOn(Utils.subMonitorFor(monitor, 25));
                    } catch (Throwable t) {
                        throw new InvocationTargetException(t);
                    } finally {
                        monitor.setTaskName(Utils.EMPTY_STRING);
                        monitor.subTask(Utils.EMPTY_STRING);
                        monitor.done();
                    }
                }
            };

            // here the intention is to use wizard's progress if it is already visible,
            // or busy indicator before the wizard is shown
            if (getWizard().getStartingPage() == this) {
                PlatformUI.getWorkbench().getProgressService().busyCursorWhile(runnableWithProgress);
            } else {
                getWizard().getContainer().run(true, false, runnableWithProgress);
            }

        } catch (InvocationTargetException e) {
            handle(e);
        } catch (InterruptedException ignore) {
        }

        productsCmb.setEnabled(true);
        typesCmb.setEnabled(true);
        objectIdTxt.setEnabled(true);
        selectedProduct = productsCmb.getText(); // Product selected
        productsCmb.setItems(productNameHolder[0]);
        if (productNameHolder[0].length == 1) {
            selectProduct(productNameHolder[0][0]);
        } else if (basedOnProduct != null) {
            selectProduct(basedOnProduct); // see if originating product there
        } else if (selectedProduct != null && !selectedProduct.equals("")) {
            // while moving back and forth between wizard pages , retain the product selected earlier.
            selectProduct(selectedProduct);
        }

        selectedType = typesCmb.getText();
        if (selectedType != null && !selectedType.equals("") && typesCmb.indexOf(selectedType) != -1) {
            typesCmb.select(typesCmb.indexOf(selectedType));
            haveType = true;
        }
        if (enableScm()) {
            updateScmProjectField();
        }
        populateName();
        initialized = true;
    }

    private void selectProduct(String product) {
        if (Utils.isNullEmpty(product) || productsCmb == null) {
            haveProduct = false;
            return;
        }
        String[] items = productsCmb.getItems();
        for (int i = 0; i < items.length; i++) {
            if (product.equals(items[i])) {
                productsCmb.select(i);
                populateTypes(product);
                haveProduct = true;
                break;
            }
        }
        checkPage();
    }

    private void populateName() {

        if (objectIdTxt == null || objectIdTxt.getText().trim().length() > 0) {
            return; // only populate when empty
        }

        // no based on object
        if (basedOnObject == null) {
            return;
        }

        // prepopulate the name based on the name of the deriving object
        // or the IDE project
        String inId = null;
        inId = (String) basedOnObject.getAPIObject().getAttribute(SystemAttributes.OBJECT_ID);
        String new_ID;
        for (int number = 1;; number++) {
            new_ID = inId + Messages.newBaselinePage_blNameSep + Integer.toString(number);
            if (isValidNameQuery(new_ID)) {
                break;
            }
        }
        objectIdTxt.setText(new_ID);
    }

    // find explicitly rather than using list
    // list slow when many baselines
    // name is full spec
    private boolean isValidNameQuery(String name) {
        String spec = getProductName() + ":" + name; //$NON-NLS-1$
        try {
            return unusedBaselineName(spec);
        } catch (DMException e) {
        }
        return true;
    }

    private TreeSet<TypeInfo> cacheWorksetTypes(String productName, List<TypeInfo> worksetTypes) {
        TreeSet<TypeInfo> treeSet = new TreeSet<TypeInfo>(worksetTypes);
        types.put(productName, treeSet);
        return treeSet;
    }

    // populates wst/bln types combo
    private void populateTypes(final String productName) {
        String selectedType = "";
        if (Utils.isNullEmpty(productName)) {
            typesCmb.setItems(Utils.ZERO_LENGTH_STRING_ARRAY);
            return;
        }
        TreeSet<TypeInfo> typeInfos = types.get(productName);
        if (typeInfos == null) {
            final Unit<List<TypeInfo>> holder = new Unit<List<TypeInfo>>();
            try {
                getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                    @Override
                    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                        monitor.beginTask(null, 2);
                        monitor.worked(1); // show "progress"
                        try {
                            holder.setValue(getObjectTypes(productName, monitor));
                        } catch (DMException e) {
                            throw new InvocationTargetException(e);
                        } finally {
                            monitor.done();
                        }
                    }
                });
            } catch (InvocationTargetException e) {
                handle(e);
            } catch (InterruptedException ignore) {
            }
            typeInfos = cacheWorksetTypes(productName, holder.getValue());
        }
        List<String> visibleTypes = new ArrayList<String>();
        for (Iterator<TypeInfo> iterator = typeInfos.iterator(); iterator.hasNext();) {
            TypeInfo typeInfo = iterator.next();
            if (!typeInfo.type.isDisabled()) {
                visibleTypes.add(typeInfo.typeName);

            } else {
                // need to check type
                // now check if we are valid
                int typeOptions = typeInfo.type.getOptions();
                // only add if meets criteria 0 options required will get all
                // otherwise has to meet the criteria
                if ((typeOptions & typeOptionsRequired) == typeOptionsRequired) {
                    // add the type in here as well
                    visibleTypes.add(typeInfo.typeName);
                }
            }
        }
        selectedType = typesCmb.getText();
        typesCmb.setItems(visibleTypes.toArray(new String[visibleTypes.size()]));
        if (visibleTypes.size() == 1) {
            haveType = true;
            typesCmb.select(0);
        }

        if (selectedType != null && !selectedType.equals("") && typesCmb.indexOf(selectedType) != -1) {
            // while moving back and forth between wizard pages, retain the Type selected earlier.
            typesCmb.select(typesCmb.indexOf(selectedType));
            haveType = true;
        } else {
            // if nothing previously selected choose first.
            typesCmb.select(0);
            haveType = true;
        }

        if (typesCmb.getSelectionIndex() == -1) {
            haveType = false;
        }
        checkPage();
    }

    // queries for existence
    private boolean unusedBaselineName(final String name) throws DMException {
        if (connection == null) {
            return true;
        }
        final boolean[] result = new boolean[1];
        final Session session = connection.openSession(null);
        session.run(new ISessionRunnable() {

            @SuppressWarnings("unchecked")
            @Override
            public void run() throws Exception {
                Filter f = new Filter();
                f.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, name, Filter.Criterion.EQUALS));
                List<Baseline> baselines = session.getObjectFactory().getBaselines(f);
                if (baselines.size() == 0) {
                    result[0] = true;
                } else {
                    result[0] = false;
                }
            }

        }, new NullProgressMonitor());

        return result[0];
    }

    private Map<String, Product> getProducts(IProgressMonitor monitor) throws DMException {
        if (connection == null) {
            return Collections.emptyMap();
        }
        final Map<String, Product> result = new HashMap<String, Product>();
        List<Product> allProducts = connection.getProducts(monitor);
        for (Iterator<Product> iterator = allProducts.iterator(); iterator.hasNext();) {
            Product product = iterator.next();
            String productName = product.getName();
            if (IDMConstants.TEMPLATE_PRODUCT.equalsIgnoreCase(productName)) {
                continue;
            }
            if (basedOnProduct != null && !basedOnProduct.equalsIgnoreCase(productName)) {
                continue; // only allow in same product
            }
            result.put(productName, product);
        }
        return result;
    }

    private List<TypeInfo> getObjectTypes(String product, IProgressMonitor pm) throws DMException {
        if (Utils.isNullEmpty(product) || connection == null) {
            return Collections.emptyList();
        }
        DMTypeScope typeScope = DMTypeScope.BASELINE;
        List<Type> productTypes = connection.getTypes(typeScope, product, pm);
        List<TypeInfo> result = new ArrayList<TypeInfo>(productTypes.size());
        for (Iterator<Type> iterator = productTypes.iterator(); iterator.hasNext();) {
            Type type = iterator.next();
            result.add(new TypeInfo(type.getName(), type));
        }
        return result;
    }

    private void handle(Exception e) {
        DMTeamUiPlugin.getDefault().handle(e);
    }

    // stores type properties (currently name only) and provides a safe access to them
    private static class TypeInfo implements Comparable<TypeInfo> {
        String typeName;
        Type type;

        TypeInfo(String typeName, Type type) {
            this.typeName = typeName;
            this.type = type;
        }

        @Override
        public int compareTo(TypeInfo o) {
            if (o == null || !(o instanceof TypeInfo)) {
                throw new ClassCastException();
            }
            if (this == o) {
                return 0;
            }
            return typeName.compareTo(o.typeName);
        }
    }

    private boolean checkProduct() {
        if (!haveProduct) {
            setErrorMessage(Messages.newBaselinePage_productRequired);
            return false;
        }
        return true;
    }

    private boolean checkType() {
        if (!haveType) {
            setErrorMessage(Messages.newBaselinePage_typeRequired);
            return false;
        }
        return true;
    }

    private boolean checkBased() {
        if (!haveBased) {
            setErrorMessage(Messages.newBaselinePage_basedRequired);
            return false;
        }
        return true;
    }

    private boolean checkName() {
        if (!haveName) {
            if (getErrorMessage() == Messages.newBaselinePage_badId) {
                return false;
            } else {
                setErrorMessage(Messages.newBaselinePage_noId);
            }
            return false;
        }
        return true;
    }

    private void checkPage() {
        /*
         * the haves
         * haveProduct;
         * haveType;
         * haveName;
         * haveBased;
         */
        setPageComplete(false);
        if (checkProduct() && checkType() && checkBased() && checkName()) {
            setErrorMessage(null);
            setPageComplete(true);
        }
    }
}

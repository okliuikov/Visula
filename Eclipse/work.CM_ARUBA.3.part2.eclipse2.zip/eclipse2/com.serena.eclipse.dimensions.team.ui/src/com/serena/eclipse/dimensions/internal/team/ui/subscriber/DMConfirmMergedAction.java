/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * @author V.Grishchenko
 */
public class DMConfirmMergedAction extends DMParticipantAction {
    private static final FastSyncInfoFilter MY_FILTER = new FastSyncInfoFilter.AndSyncInfoFilter(new FastSyncInfoFilter[] {
            OnlineFilter.INSTANCE, new SyncInfoDirectionFilter(new int[] { SyncInfo.CONFLICTING }) });

    private static final String MYTEXT = Messages.DMConfirmMergedAction_0;

    public DMConfirmMergedAction(ISynchronizePageConfiguration configuration) {
        super(MYTEXT, configuration);
    }

    public DMConfirmMergedAction(ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider) {
        super(MYTEXT, configuration, selectionProvider);
    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        return MY_FILTER;
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        return new DMConfirmMergedOperation(configuration, elements);
    }

}

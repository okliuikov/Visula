package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.internal.resources.Workspace;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.DirectoryDialog;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.WaRootInfo;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

@SuppressWarnings("restriction")
public abstract class LocationPage extends DimensionsWizardPage {

    protected ProjectMapping[] mappings;
    protected boolean createWorkArea; // if default no work area
    protected IPath workAreaRoot;
    
    protected boolean useDefaults = true;
    protected String targetLocation;
    
    protected IProject singleProject;
    protected boolean allSameContainer;
    
    public LocationPage(String pageName, ProjectMapping[] mappings) {
        super(pageName);
        setMappings(mappings);
    }
    
    public void setProject(IProject project) {
        singleProject = project;
    }
    
    public void setProjectName(String string) {
        if (string == null || string.equals(".")) {
            return;
        }
        if (singleProject != null && singleProject.getName().equals(string)) {
            return;
        }
        setProject(ResourcesPlugin.getWorkspace().getRoot().getProject(string));
    }
    
    public ProjectMapping[] getMappings()
    {
        return mappings;
    }
    
    /**
     * Return the custom location for a single project. In this case, the specified location is used as the location of the project.
     *
     * @param project
     * @return
     */
    public String getTargetLocation() {
        if (isCustomLocationSpecified()) {
            IPath targetPath = new Path(targetLocation);
            String device = targetPath.getDevice();
            if (device != null) {
                targetPath = targetPath.setDevice(device.toUpperCase());
            }
            return targetPath.toOSString();
        }
        return null;
    }

    private boolean isCustomLocationSpecified() {
        return !useDefaults;
    }

    public boolean createUnderCompatibleWorkArea() {
        return createWorkArea;
    }

    public IPath getCompatibleWorkArea() {
        if (createWorkArea) {
            return workAreaRoot;
        }
        return Path.EMPTY;
    }
    
    protected void proceedWithDirectoryDialog() {
        DirectoryDialog dialog = new DirectoryDialog(getShell());
        if (isSingleProject()) {
            dialog.setMessage(
                    NLS.bind(Messages.AddToWorkspaceAsLocationSelectionPage_browseMsgSingle, getSingleProject().getName()));
        } else {
            dialog.setMessage(
                    NLS.bind(Messages.AddToWorkspaceAsLocationSelectionPage_browseMsgMulti, String.valueOf(mappings.length)));
        }
        String dirName = getPathField();
        if (!dirName.equals(Utils.EMPTY_STRING)) {
            File path = new File(dirName);
            if (path.exists()) {
                dialog.setFilterPath(dirName);
            }
        }

        String selectedDirectory = dialog.open();
        if (selectedDirectory != null) {
            Path selectedPath = new Path(selectedDirectory);
            if (isSingleProject()) {
                if (mappings[0].getRemoteProject() instanceof SccProject) {
                    SccProject sccProject = (SccProject) mappings[0].getRemoteProject();
                    setPathField(selectedPath.append(sccProject.getOffset()).removeTrailingSeparator().toOSString());
                } else {
                    setPathField(selectedPath.append(getSingleProject().getName()).toOSString());
                }
            } else {
                setPathField(selectedPath.toOSString());
            }
        }        
    }
    
    protected void setMappings(ProjectMapping[] mappings)
    {
        this.mappings = mappings;

        if (mappings == null)
            return;
        
        if (isUserLocationDetected()) {
            this.useDefaults = false;
        }
        // check for compatibility
        allSameContainer = ProjectMapping.compatibleProjects(mappings);
        createWorkArea = allSameContainer & !useDefaults;
    }
    
    /**
     * Check if the entry in the widget location is valid. If it is valid return null. Otherwise return a string that indicates the
     * problem.
     */
	protected MessageHolder checkValidLocation() {
		MessageHolder result = new MessageHolder();
		if (useDefaults) {
			targetLocation = null;
			return result;
		}
		targetLocation = getPathField();
		if (targetLocation.equals(Utils.EMPTY_STRING)) {
			result.setErrorMsg(Messages.AddToWorkspaceAsLocationSelectionPage_emptyLocation);
			return result;
		}
		if (!Path.EMPTY.isValidPath(targetLocation)) {
			result.setErrorMsg(Messages.AddToWorkspaceAsLocationSelectionPage_invalidLocation);
			return result;
		}
		IPath targetPath = new Path(targetLocation);
		if (isSingleProject()) {
			// if we deal with an scc project check if path ends with remote offset
			if (mappings[0].getRemoteProject() instanceof SccProject) {
				IPath offset = new Path(((SccProject) mappings[0].getRemoteProject()).getOffset());
				if (!isPathEndsWith(targetPath, offset)) {
					result.setErrorMsg(NLS.bind(Messages.AddToWorkspaceAsLocationSelectionPage_sccLocMsg,
							mappings[0].getLocalProjectName(), offset.removeTrailingSeparator().toOSString()));
					return result;
				}
			}
			IStatus locationStatus = validateProjectLocation(mappings[0].getLocalProjectName(), targetPath);
			if (!locationStatus.isOK()) {
				result.setErrorMsg(locationStatus.getMessage());
				return result;
			}
		} else {
			for (int i = 0; i < mappings.length; i++) {
				String projectName = mappings[i].getLocalProjectName();
				String offset = projectName;
				if (mappings[i].getRemoteProject() instanceof SccProject) {
					offset = ((SccProject) mappings[i].getRemoteProject()).getOffset();
				}
				IStatus locationStatus = validateProjectLocation(projectName, targetPath.append(offset));
				if (!locationStatus.isOK()) {
					result.setErrorMsg(locationStatus.getMessage());
					return result;
				}
			}
		}
		// if here we need to validate work area
		// only if compatible so all scc projects
		if (allSameContainer) {
			APIObjectAdapter obj = mappings[0].getRemoteProject().getParentAdapter();
			return validateWorkAreaRoot(obj.getObjectSpec(), obj.getTypeScope());
		}
		return result;
	}

    protected MessageHolder validateWorkAreaRoot(String objSpec, DMTypeScope objScope) {
        IPath targetPath = new Path(targetLocation);
        
        IPath waPath = null;
        IPath offset = null;
        if (isSingleProject()) {
            // target path has remote offset appended
            offset = new Path(((SccProject) mappings[0].getRemoteProject()).getOffset());
            waPath = removeOffset(targetPath, offset);
        } else {
            // targetPath is the root folder
            waPath = targetPath;
        }
        return validateWorkAreaRoot(objSpec, objScope, waPath, offset);
        
    }
    
    protected MessageHolder validateWorkAreaRoot(String objSpec, DMTypeScope objScope, IPath target, IPath offset) {
        MessageHolder result = new MessageHolder();
        setMessage(null);
        List<WaRootInfo> waRoots = new ArrayList<WaRootInfo>();
        String[] holder = new String[1];
        if (TeamUtils.projectPathNotWritable(null, target, holder)) {
            result.setErrorMsg(NLS.bind(Messages.addToWorkspaceAsLocationSelectionPage_rootNotWritable, holder[0]));
            return result;
        }
        IPath compat = TeamUtils.queryCompatibleWorkAreaRoot(target, objSpec,
                objScope == DMTypeScope.BASELINE, waRoots);
        if (compat == null) {
            createWorkArea = false;
            // either multiple wa or compatible
            if (waRoots.size() == 1) {
                // @formatter:off
                result.setErrorMsg(NLS.bind(
                            Messages.addToWorkspaceAsLocationSelectionPage_invalidwa,
                            new Object[] {
                                    waRoots.get(0).path.toOSString(),
                                    waRoots.get(0).project
                                }
                            ));
                // @formatter:on
                return result;
            } else if (waRoots.size() > 1) {
                result.setErrorMsg(NLS.bind(Messages.addToWorkspaceAsLocationSelectionPage_multiplewa, target.toOSString()));
                return result;
            }

        } else if (compat == Path.EMPTY) {
            workAreaRoot = target;
            createWorkArea = true;
        } else {
            if (compat == target) {
                // use it
                createWorkArea = true;
                workAreaRoot = target;
                result.setRemoveInformationMsg(false);
                setMessage(NLS.bind(Messages.addToWorkspaceAsLocationSelectionPage_usingpath, compat.toOSString(),
                        mappings[0].getRemoteProject().getParentAdapter().getObjectSpec()), IMessageProvider.INFORMATION);
            } else {
                createWorkArea = true;
                workAreaRoot = compat;
                // reset
                if (isSingleProject()) {
                    IPath newPath = compat.append(offset);
                    setPathField(newPath.toOSString());
                    result.setRemoveInformationMsg(false);
                    setMessage(NLS.bind(Messages.addToWorkspaceAsLocationSelectionPage_resetpathSingle,
                            mappings[0].getProjectDescription().getName(), newPath.toOSString()), IMessageProvider.INFORMATION);

                } else {
                    setPathField(compat.toOSString());
                    result.setRemoveInformationMsg(false);
                    setMessage(NLS.bind(Messages.addToWorkspaceAsLocationSelectionPage_resetpathMultiple, compat.toOSString()),
                            IMessageProvider.INFORMATION);
                }

            }
        }
        // check if driveRoot has been chosen
        if (TeamUtils.pathIsRoot(target)) {
            setMessage(Messages.NewStreamWizard_stream_offset_err5, IMessageProvider.WARNING);
        }
        return result;
    }
    
    protected abstract void setPathField(String text);
    
    protected abstract String getPathField();
    
    protected boolean isSingleProject() {
        return mappings.length == 1;
    }
    
    protected IProject getSingleProject() {
        if (singleProject == null) {
            setProjectName(mappings[0].getLocalProjectName());
        }
        return singleProject;
    }
    
    protected boolean isUserLocationDetected() {
        IPath location = null;
        IProject project = getSingleProject();
        if (project != null) {
            try {
                location = project.getDescription().getLocation();
                if (location != null) {
                    return true;
                }
            } catch (CoreException e) {
                // ignore the exception
            }
        }

        return false;
    }
    
    protected IPath calcDefaultPath()
    {
        IPath defaultPath = null;
        if (isSingleProject()) {
            defaultPath = Platform.getLocation().append(mappings[0].getLocalProjectName());
        } else {
            defaultPath = Platform.getLocation();
        }
        return defaultPath;
    }
    
    protected IStatus validateProjectLocation(String projectName, IPath location) {
        IWorkspace workspace = ResourcesPlugin.getWorkspace();
        IProject project = workspace.getRoot().getProject(projectName);
        return workspace.validateProjectLocation(project, location);
    }
    
    // tests if the path ends with the supplied relative path
    private boolean isPathEndsWith(IPath path, IPath relativePath) {
        int extraSegments = path.segmentCount() - relativePath.segmentCount();
        if (extraSegments < 0) {
            return false;
        }
        IPath potentialMatch = path.removeFirstSegments(extraSegments);
        return potentialMatch.matchingFirstSegments(relativePath) == potentialMatch.segmentCount();
    }
    
    protected boolean containsSingleFolderAtWorkspaceRoot() {
        if (!isSingleProject()) {
            return false;
        }
        String location = getPathField();
        if (Utils.isNullEmpty(location)) {
            return false;
        }
        try {
            IPath currentTargetPath = new Path(location);
            IPath workspacePath = Platform.getLocation();
            if (!Workspace.caseSensitive) {
                currentTargetPath = new Path(currentTargetPath.toOSString().toLowerCase());
                workspacePath = new Path(workspacePath.toOSString().toLowerCase());
            }
            if (workspacePath.isPrefixOf(currentTargetPath)) {
                if (currentTargetPath.segmentCount() - workspacePath.segmentCount() == 1) {
                    return true;
                }
            }
        } catch (Exception ex) {
        }
        return false;
    }
    
    private IPath removeOffset(IPath targetPath, IPath offset) {
        int offsetLen = offset.segmentCount();
        return targetPath.removeLastSegments(offsetLen);
    }
    
    private String streamOrProject() {
        DimensionsArObject apiObject = mappings[0].getRemoteProject() instanceof SccProject
                ? mappings[0].getRemoteProject().getParentAdapter().getAPIObject()
                : mappings[0].getRemoteProject().getAPIObject();
        Boolean isStream = (Boolean) apiObject.getAttribute(SystemAttributes.WSET_IS_STREAM);
        if (isStream == null) {
            apiObject.queryAttribute(SystemAttributes.WSET_IS_STREAM);
            isStream = (Boolean) apiObject.getAttribute(SystemAttributes.WSET_IS_STREAM);
        }
        return Boolean.TRUE.equals(isStream) ? "stream" : "project"; //$NON-NLS-1$
    }
}

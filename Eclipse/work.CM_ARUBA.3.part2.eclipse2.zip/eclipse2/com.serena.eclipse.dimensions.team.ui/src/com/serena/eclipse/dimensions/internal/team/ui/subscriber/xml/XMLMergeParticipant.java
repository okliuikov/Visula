/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.io.File;
import java.io.IOException;

import org.eclipse.compare.CompareConfiguration;
import org.eclipse.compare.ICompareContainer;
import org.eclipse.compare.ResourceNode;
import org.eclipse.compare.structuremergeviewer.DiffNode;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;
import org.eclipse.team.ui.synchronize.SubscriberParticipant;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.dmfile.BaseMetadata;
import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.ExpandMode;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeTempStorage;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer.MergeType;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Synchronize participant that configure 3-way merge using server resolution
 */
public class XMLMergeParticipant extends SubscriberParticipant {
    public static final String ID = "com.serena.eclipse.dimensions.team.dmthreewaymerge-participant"; //$NON-NLS-1$
    public static final String TOOLBAR_CONTRIBUTION_GROUP = "toolbar_group"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_1 = "ctx_group_1"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_2 = "ctx_group_2"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_3 = "ctx_group_3"; //$NON-NLS-1$
    public static final String PROPAGATE_CONTEXT_ACTION_EVENT = "propagate_context_action_event"; //$NON-NLS-1$
    private int mode = ISynchronizePageConfiguration.INCOMING_MODE;

    public XMLMergeParticipant(XMLMergeSubscriber subscriber, ISynchronizeScope scope, int mode) {
        super(scope);
        setSubscriber(subscriber);
        this.mode = mode;
    }

    @Override
    protected void setSubscriber(Subscriber subscriber) {
        super.setSubscriber(subscriber);
        try {
            setInitializationData(TeamUI.getSynchronizeManager().getParticipantDescriptor(ID));
        } catch (CoreException e) {
            DMTeamUiPlugin.log(e.getStatus());
        }
        if (getSecondaryId() == null) {
            setSecondaryId(Long.toString(System.currentTimeMillis()));
        }
        changeName(getName());
    }

    private void changeName(String baseName) {
        String name = "";
        XMLMergeSubscriber subscriber = (XMLMergeSubscriber) getSubscriber();
        MergeType mergeType = subscriber.getDescriptorsContainer().getMergeType();
        boolean doUpdate = subscriber.getDescriptorsContainer().getMergeOptions().isDoUpdate();
        if (mergeType == MergeType.PROJECT && !doUpdate) {
            name = Messages.DMXMLMergeParticipant_stream_merge_name;
        } else if (mergeType == MergeType.REQUEST && !doUpdate) {
            name = Messages.DMXMLMergeParticipant_request_merge_name;
        } else if (mergeType == MergeType.PROJECT && doUpdate) {
            name = Messages.DMXMLUpdateParticipant_stream_update_name;
        } else if (mergeType == MergeType.REQUEST && doUpdate) {
            name = Messages.DMXMLUpdateParticipant_request_update_name;
        } else if (mergeType == MergeType.BASELINE) {
            name = Messages.DMXMLMergeParticipant_baseline_merge_name;
        }

        if (name.length() > 0) {
            setName(name);
        }
    }

    @Override
    public void run(IWorkbenchPart part) {
        super.run(part);
        // toolbar refresh makes stale all opened editors
        XMLMergeUIUtils.closeMergeCompareEditors();
    }

    /**
     * Invokes refresh in clean mode if was explicitly specified
     */
    public void clean(IWorkbenchPart part) {
        XMLMergeSubscriber subscriber = (XMLMergeSubscriber) getSubscriber();
        subscriber.forceCleanExecution();
        run(part);
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);
        configuration.setSupportedModes(ISynchronizePageConfiguration.INCOMING_MODE
                | ISynchronizePageConfiguration.CONFLICTING_MODE);
        configuration.setMode(mode);

        XMLMergeParticipantLabelDecorator decorator = new XMLMergeParticipantLabelDecorator();
        configuration.addLabelDecorator(decorator);

        configuration.addActionContribution(new XMLUserActionsContribution());
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3);
    }

    @Override
    public void prepareCompareInput(ISynchronizeModelElement element, CompareConfiguration config, IProgressMonitor monitor)
            throws TeamException {
        if (element instanceof IAdaptable) {
            SyncInfo syncInfo = (SyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
            if (syncInfo != null && syncInfo instanceof XMLSyncInfo) {
                XMLSyncInfo xinfo = (XMLSyncInfo) syncInfo;

                IResource local = xinfo.getLocalResource();
                IFileStore store = xinfo.getDescriptor().getTempStore(xinfo);
                if (local != null && xinfo.getResolution().isFileResolution()) {
                    if (xinfo.hasMergeOption() && store == null) {

                        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
                        try {
                            store = TeamUtils.copyResourceToTemp(xinfo);
                        } catch (IOException e) {
                            DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
                        } catch (CoreException e) {
                            DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
                        } finally {
                            monitor.done();
                        }

                        if (store != null) {
                            xinfo.getDescriptor().addTempStore(xinfo, store);
                        }
                    }

                }

                DiffNode ell = (DiffNode) element;
                if ((xinfo.hasMergeOption() || xinfo.getCurrentAction() == XSyncUserAction.SUAL_UNRESOLVED.value())
                        && store != null) {
                    ell.setLeft(new MergeTempStorage(store, local));
                    config.setLeftEditable(true);
                    updateRemoteLabels(xinfo, config, true);
                } else {
                    if (local != null) {
                        ell.setLeft(new ResourceNode(local));
                        config.setLeftEditable(false);
                    }
                    updateRemoteLabels(xinfo, config, false);
                }

                ICompareContainer container = config.getContainer();
                XMLMergeUIUtils.closeMergeCompareEditorsExcept(xinfo, container);
                cacheContents(xinfo, monitor);
            }
        }
    }

    public void updateRemoteLabels(XMLSyncInfo sync, CompareConfiguration config, boolean useTemp) {
        final IResourceVariant remote = sync.getRemote();
        if (remote instanceof IDMRemoteFile) {
            config.setRightLabel(NLS.bind(Messages.SyncInfoCompareInput_remoteLabelExists, ((IDMRemoteFile) remote).getRevision()));
        } else if (remote == null) {
            config.setRightLabel(Messages.SyncInfoCompareInput_remoteLabel);
        }

        final IResourceVariant base = sync.getBase();
        if (base instanceof IDMRemoteFile) {
            config.setAncestorLabel(NLS.bind(Messages.SyncInfoCompareInput_baseLabelExists, ((IDMRemoteFile) base).getRevision()));
        } else if (base == null) {
            config.setAncestorLabel(Messages.SyncInfoCompareInput_baseLabel);
        }

        IResource local = null;
        if (sync instanceof XMLSyncInfo) {
            XMLSyncInfo xinfo = sync;
            local = xinfo.getLocalResource();
        }

        IDMRemoteFile localres = null;
        if (local != null) {
            try {
                localres = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
            } catch (TeamException e) {
                DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
            }
        }

        String lrev = localres != null ? localres.getRevision() : ""; //$NON-NLS-1$
        if (local != null) {
            config.setLeftLabel(NLS.bind(useTemp
                    ? Messages.SyncInfoCompareInput_tempLabelExistsAndPath : Messages.SyncInfoCompareInput_localLabelExistsAndPath,
                    new String[] {
                            lrev,
                            useTemp
                                    ? new File(sync.getDescriptor().getTempStore(sync).toURI()).getAbsolutePath()
                                    : local.getFullPath().toString() }));
        } else {
            config.setLeftLabel(Messages.SyncInfoCompareInput_localLabel);
        }
    }

    private void cacheContents(XMLSyncInfo syncInfo, IProgressMonitor monitor) throws TeamException {
        if (syncInfo.getResolution().isFileResolution()) {
            try {
                IResource resource = syncInfo.getLocalResource();
                boolean isSubst = false;

                if (resource != null) {
                    BaseMetadata metadata = WorkspaceMetadataManager.getInstance().getMetadata(resource);
                    if (metadata instanceof ItemMetadata) {
                        ItemMetadata idata = (ItemMetadata) metadata;
                        isSubst = idata.isHeaderSubst();
                    }
                }

                ExpandMode[] mode = null;
                if (isSubst) {
                    if ((syncInfo.getKind() & SyncInfo.CONFLICTING) == SyncInfo.CONFLICTING) {
                        mode = new ExpandMode[] { ExpandMode.UNEXPANDED };
                    } else {
                        mode = new ExpandMode[] { ExpandMode.EXPANDED };
                    }
                }

                IResourceVariant ancestor = syncInfo.getBase();
                IResourceVariant remote = syncInfo.getRemote();

                int work = Math.max((ancestor == null ? 0 : 50) + (remote == null ? 0 : 50), 10);
                monitor.beginTask(null, work);

                if (ancestor != null) {
                    if (!isSubst) {
                        ancestor.getStorage(Utils.subMonitorFor(monitor, 50));
                    } else {
                        TeamUtils.fetchReplaceContents(ancestor, mode, Utils.subMonitorFor(monitor, 50));
                    }

                }

                if (remote != null) {
                    if (!isSubst) {
                        remote.getStorage(Utils.subMonitorFor(monitor, 50));
                    } else {
                        TeamUtils.fetchReplaceContents(remote, mode, Utils.subMonitorFor(monitor, 50));
                    }
                }

            } catch (CoreException e) {
                DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
            } finally {
                monitor.done();
            }
        }
    }

}

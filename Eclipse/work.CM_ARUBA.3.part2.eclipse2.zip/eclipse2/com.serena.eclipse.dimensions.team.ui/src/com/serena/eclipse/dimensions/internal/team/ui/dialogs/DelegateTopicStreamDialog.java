package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.controls.DelegateStreamControl;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;

public class DelegateTopicStreamDialog extends ResizableDialog {

    private DelegateStreamControl shareControl = new DelegateStreamControl();

    public DelegateTopicStreamDialog(Shell parent, WorksetAdapter stream) {
        super(parent);

        shareControl.setConnection(stream.getConnectionDetails());
        shareControl.setStream(stream);
    }

    @Override
    protected Point getInitialSize() {
        minWidth = 400;
        return super.getInitialSize();
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        getShell().setText(NLS.bind(Messages.DelegateDialog_title, shareControl.getStream().getAPIObject().getName()));
        Composite composite = (Composite) super.createDialogArea(parent);
        shareControl.createControl(composite);
        shareControl.tryInit();
        return composite;
    }

    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        super.createButtonsForButtonBar(parent);
        getButton(IDialogConstants.OK_ID).setText(Messages.DelegateDialog_okText);
    }

    @Override
    protected void okPressed() {
        shareControl.saveAssignedUsers();
        super.okPressed();
    }
}

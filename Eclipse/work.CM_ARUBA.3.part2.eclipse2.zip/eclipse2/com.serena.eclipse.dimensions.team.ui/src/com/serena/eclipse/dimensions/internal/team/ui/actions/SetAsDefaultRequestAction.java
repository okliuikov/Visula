/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.SelectProjectForDefaultRequest;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;

/**
 * @author bstephenson
 *
 */
public class SetAsDefaultRequestAction extends DimensionsAction {

    public SetAsDefaultRequestAction() {
        super();
    }

    @Override
    protected boolean isEnabledForSelection() {
        if (getSelection().size() != 1) {
            return false;
        }
        return true;
    }

    @Override
    public void run(IAction action) {
        final ChangeDocumentAdapter cd = (ChangeDocumentAdapter) getSelection().getFirstElement();
        SelectProjectForDefaultRequest selProjDialog = new SelectProjectForDefaultRequest(getShell(),
                Messages.setAsDefaultRequestFor_title, cd.getConnectionDetails());
        if (selProjDialog.open() == Window.OK) {
            final List selected = selProjDialog.getSelectedObjects();
            if (selected != null && !selected.isEmpty()) {
                String confirmMsg;
                if (selected.size() == 1) {
                    String id = ((APIObjectAdapter) selected.get(0)).getObjectSpec();
                    confirmMsg = NLS.bind(Messages.defaultRequest_setSelected, cd.getObjectSpec(), id);
                } else {
                    confirmMsg = NLS.bind(Messages.setAsDefaultRequestFor_multiquestion, cd.getObjectSpec());
                }
                if (MessageDialog.openQuestion(getShell(), Messages.Dialog_title, confirmMsg)) {
                    try {
                        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                            @Override
                            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                                try {
                                    setDefaultRequest(cd, selected, monitor);
                                } catch (DMException e) {
                                    throw new InvocationTargetException(e);
                                }
                            }
                        });
                    } catch (InvocationTargetException e) {
                        DMUIPlugin.getDefault().handle(e);
                    } catch (InterruptedException ignore) {
                    }
                }
            }
        }
    }

    private void setDefaultRequest(final ChangeDocumentAdapter cd, final List selected, final IProgressMonitor monitor)
            throws DMException {
        try {
            String progressMsg = Messages.setAsDefaultRequestFor_progressTask;
            monitor.beginTask(progressMsg, selected.size() == 1 ? IProgressMonitor.UNKNOWN : selected.size() + 2);
            final Session session = cd.getConnectionDetails().openSession(Utils.subMonitorFor(monitor, 2));
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws DMException {
                    for (Iterator selit = selected.iterator(); selit.hasNext();) {
                        APIObjectAdapter so = (APIObjectAdapter) selit.next();
                        monitor.subTask(so.getObjectSpec());
                        session.getObjectFactory().setCurrentProject(so.getObjectSpec(), false, null, cd.getObjectSpec(), null,
                                false);
                        monitor.worked(1);
                    }
                }
            }, monitor);
        } finally {
            monitor.done();
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.IDimensionsServiceResource;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.sbm.ISBMRequest;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewStreamTopicWorkareaPage;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewStreamWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewTopicStreamWizardCaller;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.WizardHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewStreamTopicWorkareaPage.PostCreationMode;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Launches new Stream wizard.
 * @author Dinesh Babu
 */
public class NewTopicStreamAction extends DimensionsAction {

    public NewTopicStreamAction() {
        super(true);
    }

    @Override
	public void run(IAction action) {
		IStructuredSelection selection = getSelection();
		if (selection.isEmpty()) {
			return;
		}
		IDimensionsServiceResource dmResource = (IDimensionsServiceResource) selection.getFirstElement();

		APIObjectAdapter basedOn = null;
		if (dmResource.getClass() == WorksetAdapter.class || dmResource instanceof BaselineAdapter
				|| dmResource instanceof ChangeDocumentAdapter
				|| dmResource.getClass() == DimensionsIDEProjectGroup.class
				|| dmResource.getClass() == SccProjectContainerWorkset.class) {
			basedOn = (APIObjectAdapter) dmResource;
		}
		final NewTopicStreamWizardCaller wizard = new NewTopicStreamWizardCaller(dmResource.getConnectionDetails(),
				basedOn);

		if (dmResource instanceof ISBMRequest)
			wizard.setBasedOnSbmRequest((ISBMRequest) dmResource);

		WizardDialog dialog = new NewStreamWizardDialog(getShell(), wizard);
		if (dialog.open() == Window.CANCEL) {
            return;
        }
		
		Object page = wizard.getPage(NewStreamWizard.STREAM_TOPIC_WORKAREA_PAGE);
		final NewStreamTopicWorkareaPage topicPage = (NewStreamTopicWorkareaPage) page;
		if (topicPage.getPostCreationMode() == PostCreationMode.ADD_TO_WORKSPACE) {
			try {
				topicPage.addToWorkspace();
			} catch (InvocationTargetException e) {
				DMTeamUiPlugin.getDefault().handle(e, UIUtils.findShell());
				throw new OperationCanceledException();
			} catch (InterruptedException e) {
				return;
			}
		} else if (topicPage.getPostCreationMode() == PostCreationMode.REHOME) {
			WizardHelper.rehomeWorkspaceProjects(topicPage.getProjectsToRehome(), wizard.getCreatedObjectAdapter());
		}
	}
}

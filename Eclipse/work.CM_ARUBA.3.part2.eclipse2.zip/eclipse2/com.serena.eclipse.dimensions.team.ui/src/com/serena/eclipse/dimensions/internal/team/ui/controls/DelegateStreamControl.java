package com.serena.eclipse.dimensions.internal.team.ui.controls;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ComboViewer;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import com.serena.dmclient.api.DimensionsObjectFactory;

import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Group;
import com.serena.dmclient.api.UWPCmdHelper;
import com.serena.dmclient.api.User;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.StringFilter;
import com.serena.eclipse.dimensions.internal.team.ui.UserInfo;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.util.StringUtils;

public class DelegateStreamControl {
    private Button addUserButton;
    private Button removeUserButton;
    private ComboViewer comboViewer;
    private TableViewer tableViewer;
    private boolean initialized = false;
    private List<UserInfo> activeUsers = new ArrayList<UserInfo>();
    private List<String> initiallyAssignedUsers;
    private SortedSet<UserInfo> assignedUsers = new TreeSet<UserInfo>(new Comparator<UserInfo>() {
        @Override
        public int compare(UserInfo user1, UserInfo user2) {
            if (user1.isGroup != user2.isGroup) {
                return (user1.isGroup ? 1 : 0) - (user2.isGroup ? 1 : 0);
            }
            return user1.id.compareTo(user2.id);
        }
    });

    private final StringFilter filter = new StringFilter();
    private Image userImage;
    private Image groupImage;
    private Color comboHintColor = Display.getDefault().getSystemColor(SWT.COLOR_DARK_GRAY);
    private String comboHintMessage = "Start typing a user name"; // $NON-NLS-1$

    private DimensionsConnectionDetailsEx connection;
    private DimensionsWizardPage hostPage;
    private WorksetAdapter stream;

    public DelegateStreamControl() {
    }

    public void setConnection(DimensionsConnectionDetailsEx connection) {
        this.connection = connection;
    }
    
    public void setStream(WorksetAdapter stream) {
        this.stream = stream;
    }
    
    public WorksetAdapter getStream() {
        return stream;
    }

    public void tryInit() {
        if (!initialized) {
            loadUsersAndGroups();
            initialized = true;
        }
    }

    public void setHostPage(DimensionsWizardPage page) {
        hostPage = page;
    }
    
    public Composite createControl(Composite parent) {

        final Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 3);
        GridData gridData = UIUtils.setGridData(composite, GridData.FILL_BOTH);
        gridData.minimumWidth = 300;
        
        comboViewer = new ComboViewer(composite, SWT.DROP_DOWN);
        UIUtils.setGridData(comboViewer.getCombo(), GridData.FILL_HORIZONTAL);

        comboViewer.setContentProvider(ArrayContentProvider.getInstance());
        comboViewer.setLabelProvider(new LabelProvider() {
            @Override
            public String getText(final Object element) {
                if (element instanceof UserInfo) {
                    return ((UserInfo) element).displayText;
                }
                return super.getText(element);
            }
        });

        comboViewer.addFilter(filter);
        final Combo combo = comboViewer.getCombo();

        combo.addSelectionListener(new SelectionListener() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                updateAvailableActions();
                if (combo.getListVisible() == false) {
                    // user selected an item from drop down, clear filter then
                    filter.setSearchText("");
                    comboViewer.refresh();
                }
            }

            @Override
            public void widgetDefaultSelected(SelectionEvent e) {
            }
        });

        combo.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(final KeyEvent e) {
            }

            @Override
            public void keyReleased(final KeyEvent e) {
                if (e.keyCode == SWT.CR) {
                    filter.setSearchText("");
                    comboViewer.refresh();
                    return;
                }

                if (e.keyCode == SWT.ESC) {
                    return;
                }
                if (combo.getListVisible() == true) {
                    if (e.keyCode == SWT.ALT || e.keyCode == SWT.CTRL)
                        return;
                    if (arrowPressed(e.keyCode))
                        return;
                }
                if (combo.getText().equals(filter.getUserInput())) {
                    return;
                }
                filter.setSearchText(combo.getText());
                comboViewer.refresh();

                String filterString = filter.getUserInput();
                // expand drop down first, otherwise first matching item from the drop down could jump into text area
                combo.setListVisible(combo.getItemCount() > 0);
                combo.setText(filterString);

                if (filterString.length() > 0) {
                    // set cursor to the end of the text
                    combo.setSelection(new Point(filterString.length(), filterString.length()));
                }
            }

            private boolean arrowPressed(int keyCode) {
                if (keyCode == SWT.ARROW_UP || keyCode == SWT.ARROW_DOWN || keyCode == SWT.ARROW_LEFT || keyCode == SWT.ARROW_RIGHT)
                    return true;

                return false;
            }
        });

        combo.addListener(SWT.Paint, new Listener() {
            @Override
            public void handleEvent(Event event) {
                if (Utils.isNullEmpty(comboViewer.getCombo().getText()) && Utils.isNullEmpty(filter.getUserInput())) {
                    drawComboHint(event);
                }
            }
        });

        addUserButton = new Button(composite, SWT.NONE);
        addUserButton.setText("Add"); // $NON-NLS-1$
        addUserButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                addUser();
                combo.setText("");
            }
        });

        removeUserButton = new Button(composite, SWT.NONE);
        removeUserButton.setText("Remove"); // $NON-NLS-1$
        removeUserButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                removeUser();
            }
        });

        final Table table = new Table(composite, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.SINGLE);
        gridData = new GridData(GridData.FILL_HORIZONTAL | GridData.FILL_VERTICAL);
        gridData.horizontalSpan = 3;
        table.setLayoutData(gridData);

        tableViewer = new TableViewer(table);
        tableViewer.setContentProvider(ArrayContentProvider.getInstance());
        tableViewer.addSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                updateRemoveUserAction();
            }
        });

        userImage = DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.USER).createImage();
        groupImage = DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.GROUP).createImage();
        TableViewerColumn col = new TableViewerColumn(tableViewer, SWT.NONE);
        col.getColumn().setWidth(100);
        col.setLabelProvider(new ColumnLabelProvider() {
            @Override
            public void update(ViewerCell cell) {
                UserInfo info = (UserInfo) cell.getElement();
                cell.setText(info.displayText);
                if (info.isGroup) {
                    cell.setImage(groupImage);
                } else {
                    cell.setImage(userImage);
                }
            }
        });

        composite.addControlListener(new ControlAdapter() {
            public void controlResized(ControlEvent e) {
                if (table.getColumnCount() == 0)
                    return;

                Rectangle area = composite.getClientArea();
                area.width -= ((GridLayout) composite.getLayout()).marginWidth * 2;
                Point preferredSize = table.computeSize(SWT.DEFAULT, SWT.DEFAULT);
                int width = area.width - 2 * table.getBorderWidth();
                if (preferredSize.y > area.height + table.getHeaderHeight()) {
                    // Subtract the scroll bar width from the total column width
                    // if a vertical scroll bar will be required
                    Point vBarSize = table.getVerticalBar().getSize();
                    width -= vBarSize.x;
                }
                Point oldSize = table.getSize();
                if (oldSize.x > area.width) {
                    // table is getting smaller so make the columns
                    // smaller first and then resize the table to
                    // match the client area width
                    table.getColumn(0).setWidth(width);
                    table.setSize(area.width, area.height);
                } else {
                    // table is getting bigger so make the table
                    // bigger first and then make the columns wider
                    // to match the client area width
                    table.setSize(area.width, area.height);
                    table.getColumn(0).setWidth(width);
                }
            }
        });

        return composite;
    }

    public List<String> getAssignedUsersAndGroups() {
        List<String> list = new ArrayList<String>(assignedUsers.size());
        for (UserInfo info : assignedUsers) {
            list.add(info.id);
        }
        return list;
    }
    
    
    
    public void saveAssignedUsers() {
        final List<String> currentUsersAndGroups = getAssignedUsersAndGroups();
        if (initiallyAssignedUsers.toString().equalsIgnoreCase(currentUsersAndGroups.toString())) {
            return;
        }
        run(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    monitor.beginTask("Saving assigned users...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
                    DimensionsObjectFactory factory = connection.openSession(monitor).getObjectFactory();
                    UWPCmdHelper helper = factory.getUWPCmdHelper();
                    
                    if  (assignedUsers.size() == 0) {
                        helper.removeAssignedUsers(stream.getAPIObject().getName(), initiallyAssignedUsers);    
                    } else {
                        helper.replaceAssignedUsers(stream.getAPIObject().getName(), currentUsersAndGroups);
                    }
                } catch (DMException e) {
                    DMUIPlugin.getDefault().handle(e);
                } finally {
                    monitor.setTaskName(Utils.EMPTY_STRING);
                    monitor.subTask(Utils.EMPTY_STRING);
                    monitor.done();
                }
            }
        });
    }

    private void loadUsersAndGroups() {
        run(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    monitor.beginTask("Getting users...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
                    List<User> dbUsers = connection.getActiveUsers(monitor);
                    List<String> dbAssignedUsers = new ArrayList<String>();
                    List<String> dbAssignedGroups = new ArrayList<String>();

                    DimensionsObjectFactory factory = connection.openSession(monitor).getObjectFactory();

                    if (stream != null) {
                        UWPCmdHelper helper = factory.getUWPCmdHelper();
                        helper.getAssignedUsers(stream.getAPIObject().getName(), dbAssignedUsers, dbAssignedGroups);
                        initiallyAssignedUsers = new ArrayList<String>(dbAssignedUsers);
                        initiallyAssignedUsers.addAll(dbAssignedGroups);
                    } else {
                        // that is better to use user instance with cached full name to avoid query
                        User sessionUser = factory.getCurrentUser();
                        addUser(assignedUsers, sessionUser);
                    }

                    for (User user : dbUsers) {
                        addUser(activeUsers, user);

                        if (dbAssignedUsers.contains(user.getName())) {
                            addUser(assignedUsers, user);
                        }
                    }
                    Filter filter = new Filter();
                    for (Group group : factory.getBaseDatabase().getGroups(filter)) {
                        UserInfo info = createGroup(group.getName());
                        activeUsers.add(info);

                        if (dbAssignedGroups.contains(group.getName())) {
                            assignedUsers.add(info);
                        }
                    }
                } catch (DMException e) {
                    DMUIPlugin.getDefault().handle(e);
                } finally {
                    monitor.setTaskName(Utils.EMPTY_STRING);
                    monitor.subTask(Utils.EMPTY_STRING);
                    monitor.done();
                }
            }
        });
        comboViewer.setInput(activeUsers);
        tableViewer.setInput(assignedUsers);
        updateAvailableActions();
    }

    private UserInfo createGroup(String name) {
        UserInfo info = new UserInfo();
        info.isGroup = true;
        info.id = name;
        info.displayText = NLS.bind("{0} (Group)", StringUtils.toTitleCase(info.id)); //$NON-NLS-1$
        return info;
    }

    private void run(IRunnableWithProgress runnable) {
        try {
            if (hostPage != null) {
                hostPage.run(runnable, false);
            } else {
                new ProgressMonitorDialog(UIUtils.findShell()).run(true, false, runnable);
            }
        } catch (InvocationTargetException e) {
            DMUIPlugin.getDefault().handle(e);
        } catch (InterruptedException e) {
            throw new OperationCanceledException();
        }
    }

    private void drawComboHint(Event event) {
        GC gc = event.gc;
        gc.setForeground(comboHintColor);

        FontData fontData = gc.getFont().getFontData()[0];
        fontData.setStyle(SWT.ITALIC);
        Font font = new Font(Display.getDefault(), fontData);
        gc.setFont(font);

        // don't rely on event.x, when resizing the wizard, it's wrong sometimes
        gc.drawText(comboHintMessage, 4, event.y, SWT.DRAW_TRANSPARENT);
    }

    private void addUser() {
        IStructuredSelection selection = (IStructuredSelection) comboViewer.getSelection();
        if (selection.getFirstElement() != null) {
            UserInfo candidate = (UserInfo) selection.getFirstElement();
            if (findUserInfo(assignedUsers, candidate.id) == null) {
                assignedUsers.add(candidate);
                tableViewer.refresh();
            }
        }
        updateAvailableActions();
    }

    private void addUser(Collection<UserInfo> users, User user) {
        UserInfo info = new UserInfo();
        info.isGroup = false;
        info.id = user.getName();
        info.displayText = user.getFullUserName();
        if (Utils.isNullEmpty(info.displayText)) {
            // in the case when full name is not set, switch to login name
            info.displayText = info.id;
        }
        users.add(info);
    }

    private void removeUser() {
        IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
        UserInfo assignedUser = (UserInfo) selection.getFirstElement();

        if (assignedUser != null) {
            assignedUsers.remove(assignedUser);
            tableViewer.refresh();
        }
        updateAvailableActions();
    }

    private void updateAvailableActions() {
        updateAddUserAction();
        updateRemoveUserAction();
    }

    private void updateAddUserAction() {
        boolean canAdd = false;
        IStructuredSelection selection = (IStructuredSelection) comboViewer.getSelection();
        if (selection.getFirstElement() != null) {
            UserInfo candidate = (UserInfo) selection.getFirstElement();
            if (findUserInfo(assignedUsers, candidate.id) == null) {
                canAdd = true;
            }
        }
        addUserButton.setEnabled(canAdd);
    }

    private void updateRemoveUserAction() {
        boolean canRemove = false;
        IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
        UserInfo assignedUser = (UserInfo) selection.getFirstElement();
        if (assignedUser != null) {
            canRemove = true;
        }
        removeUserButton.setEnabled(canRemove);
    }

    private UserInfo findUserInfo(Collection<UserInfo> source, String candidateId) {
        for (UserInfo user : source) {
            if (user.id.equalsIgnoreCase(candidateId)) {
                return user;
            }
        }
        return null;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * @author V.Grishchenko
 */
public class ProjectBranchWizardGeneralPage extends DimensionsWizardPage {
    /** branching from local workspace, mutually exclusive with REMOTE */
    public static final int LOCAL = 1;
    /** branching from repository state, mutually exclusive with LOCAL */
    public static final int REMOTE = 2;
    /** whether to show the create baseline option */
    public static final int ALLOW_BASELINE = 4;

    private static final int LABEL_WIDTH = 400;

    private String projectName;
    private int options;
    private boolean baseline;
    private boolean start;

    public ProjectBranchWizardGeneralPage(String pageName, String title, ImageDescriptor titleImage, String description, int options) {
        super(pageName, title, titleImage, description);
        this.options = options;
    }

    /**
     * @return <code>true </code>if baseline should be created
     */
    public boolean getCreateBaseline() {
        return baseline;
    }

    /**
     * @return <code>true</code> if local project sharing should be the newly
     *         created workset
     */
    public boolean getNewSharing() {
        return start;
    }

    public void setProjectName(String name) {
        this.projectName = name;
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        String text1 = NLS.bind(Messages.ProjectBranchWizardGeneralPage_0, getInitialBranchStateText());
        Label lbl1 = UIUtils.createLabel(composite, SWT.LEFT | SWT.WRAP, text1);
        setGridData(lbl1);
        UIUtils.createLabel(composite, null); // spacer

        if (isBaselineAllowed()) {
            String text2 = NLS.bind(Messages.ProjectBranchWizardGeneralPage_1, getBaselineSourceDescription(), projectName);
            Label lbl2 = UIUtils.createLabel(composite, SWT.LEFT | SWT.WRAP, text2);
            setGridData(lbl2);

            final Button baselineBtn = new Button(composite, SWT.CHECK);
            baselineBtn.setText(Messages.ProjectBranchWizardGeneralPage_2);
            baselineBtn.setSelection(true);
            baseline = true;
            UIUtils.createLabel(composite, null); // spacer

            baselineBtn.addListener(SWT.Selection, new Listener() {
                @Override
                public void handleEvent(Event event) {
                    if (event.type == SWT.Selection) {
                        baseline = baselineBtn.getSelection();
                    }
                }
            });
        }

        String text3 = NLS.bind(Messages.ProjectBranchWizardGeneralPage_3, projectName);
        Label lbl3 = UIUtils.createLabel(composite, SWT.LEFT | SWT.WRAP, text3);
        setGridData(lbl3);

        final Button startBtn = new Button(composite, SWT.CHECK);
        startBtn.setText(Messages.ProjectBranchWizardGeneralPage_4);
        startBtn.setSelection(true);
        start = true;

        startBtn.addListener(SWT.Selection, new Listener() {
            @Override
            public void handleEvent(Event event) {
                if (event.type == SWT.Selection) {
                    start = startBtn.getSelection();
                }
            }
        });

        setControl(composite);
    }

    private void setGridData(Label label) {
        UIUtils.setGridData(label, GridData.FILL_HORIZONTAL).widthHint = LABEL_WIDTH;
    }

    private boolean isFromWorkspace() {
        return (options & LOCAL) == LOCAL;
    }

    private boolean isBaselineAllowed() {
        return (options & ALLOW_BASELINE) == ALLOW_BASELINE;
    }

    private String getInitialBranchStateText() {
        return (isFromWorkspace() ? Messages.ProjectBranchWizardGeneralPage_5 : Messages.ProjectBranchWizardGeneralPage_6);
    }

    private String getBaselineSourceDescription() {
        return (isFromWorkspace() ? Messages.ProjectBranchWizardGeneralPage_7 : Messages.ProjectBranchWizardGeneralPage_8);
    }

}

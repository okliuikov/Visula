/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.compare;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.compare.CompareConfiguration;
import org.eclipse.compare.CompareEditorInput;
import org.eclipse.compare.ITypedElement;
import org.eclipse.compare.structuremergeviewer.DiffNode;
import org.eclipse.compare.structuremergeviewer.Differencer;
import org.eclipse.compare.structuremergeviewer.IDiffContainer;
import org.eclipse.compare.structuremergeviewer.IStructureComparator;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.team.core.variants.IResourceVariant;

import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFolder;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamPreferences;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Compares remote projects and baselines.
 * @author V.Grishchenko
 */
public class DMCompareEditorInput extends CompareEditorInput {
    private VersionManagementProject left;
    private VersionManagementProject right;
    private VersionManagementProject ancestor;
    private String toolTipText;

    RemoteResourceTypedElement ancestorRoot = null;
    RemoteResourceTypedElement leftRoot = null;
    RemoteResourceTypedElement rightRoot = null;

    public DMCompareEditorInput(VersionManagementProject left, VersionManagementProject right) {
        this(left, right, null);
    }

    public DMCompareEditorInput(VersionManagementProject left, VersionManagementProject right, VersionManagementProject ancestor) {
        super(new CompareConfiguration());
        this.left = left;
        this.right = right;
        this.ancestor = ancestor;
    }

    public DMCompareEditorInput(RemoteResourceTypedElement left, RemoteResourceTypedElement right) {
        super(new CompareConfiguration());
        assert left != null;
        assert right != null;
        leftRoot = left;
        rightRoot = right;
    }

    @Override
    protected Object prepareInput(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
        monitor = Utils.monitorFor(monitor);
        final boolean threeWay = ancestor != null;

        final Differencer d = new Differencer() {
            @Override
            protected boolean contentsEqual(Object input1, Object input2) {
                if (input1 instanceof RemoteResourceTypedElement && input2 instanceof RemoteResourceTypedElement) {
                    IResourceVariant remote1 = ((RemoteResourceTypedElement) input1).getRemote();
                    IResourceVariant remote2 = ((RemoteResourceTypedElement) input2).getRemote();
                    boolean revisionsEqual = remote1.equals(remote2);
                    if (!revisionsEqual && considerContentsIfRevisionsDiffer()) {
                        return super.contentsEqual(input1, input2);
                    }
                    return revisionsEqual;
                }
                return super.contentsEqual(input1, input2);
            }

            @Override
            protected void updateProgress(IProgressMonitor progressMonitor, Object node) {
                if (node instanceof ITypedElement) {
                    ITypedElement element = (ITypedElement) node;
                    progressMonitor.subTask(NLS.bind(Messages.DMCompareEditorInput_fileProgress, new String[] { element.getName() }));
                    progressMonitor.worked(1);
                }
            }

            @Override
            protected Object[] getChildren(Object input) {
                if (input instanceof IStructureComparator) {
                    Object[] children = ((IStructureComparator) input).getChildren();
                    if (children != null) {
                        return children;
                    }
                }
                return null;
            }

            @Override
            protected Object visit(Object data, int result, Object ancestor, Object left, Object right) {
                return new DiffNode((IDiffContainer) data, result, (ITypedElement) ancestor, (ITypedElement) left,
                        (ITypedElement) right);
            }
        };

        try {

            int ancestorRefreshWork = ancestor == null ? 0 : 500;
            int leftRefreshWork = left == null ? 0 : 500;
            int rightRefreshWork = right == null ? 0 : 500;
            int differencerWork = 500;
            int totalWork = ancestorRefreshWork + leftRefreshWork + rightRefreshWork + differencerWork;

            monitor.beginTask(Messages.DMCompareEditorInput_comparing, totalWork);

            // here we use remote trees to fetch remote data, this is a bit
            // pushing it as trees operate in the context of local projects
            // which we don't technically have in this situation, to fool the
            // trees local bogus project handles are created and passed to the
            // refresh method.
            if (ancestor != null) {
                IProject bogusA = ResourcesPlugin.getWorkspace().getRoot().getProject(Messages.DMCompareEditorInput_ancestorP);
                IDMProject projectA = DMRepositoryProvider.createProject(ancestor, bogusA, null);
                projectA.getRemoteTree().refresh(new IResource[] { bogusA }, IResource.DEPTH_INFINITE,
                        Utils.subMonitorFor(monitor, ancestorRefreshWork));
                ancestorRoot = new RemoteResourceTypedElement(projectA.getRemoteTree().getResourceVariant(bogusA));
            }

            if (left != null) {
                IProject bogusL = ResourcesPlugin.getWorkspace().getRoot().getProject(Messages.DMCompareEditorInput_leftP);
                IDMProject projectL = DMRepositoryProvider.createProject(left, bogusL, null);
                projectL.getRemoteTree().refresh(new IResource[] { bogusL }, IResource.DEPTH_INFINITE,
                        Utils.subMonitorFor(monitor, leftRefreshWork));
                leftRoot = new RemoteResourceTypedElement(projectL.getRemoteTree().getResourceVariant(bogusL));
            }

            if (right != null) {
                IProject bogusR = ResourcesPlugin.getWorkspace().getRoot().getProject(Messages.DMCompareEditorInput_rightP);
                IDMProject projectR = DMRepositoryProvider.createProject(right, bogusR, null);
                projectR.getRemoteTree().refresh(new IResource[] { bogusR }, IResource.DEPTH_INFINITE,
                        Utils.subMonitorFor(monitor, rightRefreshWork));
                rightRoot = new RemoteResourceTypedElement(projectR.getRemoteTree().getResourceVariant(bogusR));
            }

            // do the diff
            Object result = null;
            IProgressMonitor sub = Utils.subMonitorFor(monitor, differencerWork);
            sub.beginTask(Messages.DMCompareEditorInput_comparing, 500);
            try {
                result = d.findDifferences(threeWay, sub, null, ancestorRoot, leftRoot, rightRoot);
            } finally {
                sub.done();
            }
            initLabels();
            return result;
        } catch (OperationCanceledException e) {
            throw new InterruptedException(e.getMessage());
        } catch (Exception e) {
            handle(e);
            return null;
        } finally {
            monitor.done();
        }
    }

    @Override
    public Viewer createDiffViewer(Composite parent) {
        Viewer viewer = super.createDiffViewer(parent);
        viewer.addSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                CompareConfiguration cc = getCompareConfiguration();
                setLabels(cc, (IStructuredSelection) event.getSelection());
            }
        });
        return viewer;
    }

    /**
     * Handles a random exception and sanitizes it into a reasonable
     * error message.
     */
    private void handle(Exception e) {
        // create a status
        Throwable t = e;
        // unwrap the invocation target exception
        if (t instanceof InvocationTargetException) {
            t = ((InvocationTargetException) t).getTargetException();
        }
        IStatus error;
        if (t instanceof CoreException) {
            error = ((CoreException) t).getStatus();
        } else {
            error = DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMCompareEditorInput_internalError, t);
        }
        setMessage(error.getMessage());
        DMTeamUiPlugin.log(error);
    }

    /**
     * Sets up the title and pane labels for the comparison view.
     */
    private void initLabels() {
        CompareConfiguration cc = getCompareConfiguration();
        setLabels(cc, new StructuredSelection());

        String title;
        String lSpec = "", rSpec = ""; //$NON-NLS-1$ //$NON-NLS-2$
        String lRevision = "", rRevision = ""; //$NON-NLS-1$ //$NON-NLS-2$
        String lName = "", rName = ""; //$NON-NLS-1$ //$NON-NLS-2$

        if (leftRoot.getRemote() instanceof IDMRemoteFolder) {
            IDMRemoteFolder remoteFolder = (IDMRemoteFolder) leftRoot.getRemote();
            IDMProject lProject = remoteFolder.getProject();
            lSpec = remoteFolder.getName();
            if (lSpec.length() == 0) {
                // this is the empty root folder, therefore display the project id instead
                lSpec = lProject.getId();
            } else if (lProject.isSccStyle() && lProject.getRemoteOffset().equals(remoteFolder.getPath())) {
                lSpec = lProject.getId() + '/' + lProject.getRemoteOffset().toString();
            }
        } else {
            IDMRemoteFile remoteFile = (IDMRemoteFile) leftRoot.getRemote();
            lSpec = NLS.bind(Messages.nameAndRevision, remoteFile.getName(), remoteFile.getRevision());
            lRevision = remoteFile.getRevision();
            lName = remoteFile.getName();
        }

        if (rightRoot.getRemote() instanceof IDMRemoteFolder) {
            IDMRemoteFolder remoteFolder = (IDMRemoteFolder) rightRoot.getRemote();
            IDMProject rProject = remoteFolder.getProject();
            rSpec = remoteFolder.getName();
            if (rSpec.length() == 0) {
                // this is the empty root folder, therefore display the project id instead
                rSpec = rProject.getId();
            } else if (rProject.isSccStyle() && rProject.getRemoteOffset().equals(remoteFolder.getPath())) {
                rSpec = rProject.getId() + '/' + rProject.getRemoteOffset().toString();
            }
        } else {
            IDMRemoteFile remoteFile = (IDMRemoteFile) rightRoot.getRemote();
            rSpec = NLS.bind(Messages.nameAndRevision, remoteFile.getName(), remoteFile.getRevision());
            rRevision = remoteFile.getRevision();
            rName = remoteFile.getName();
        }
        if (ancestorRoot != null) {
            if (lName.length() > 0 && lName.equals(rName)) {
                title = NLS.bind(Messages.DMCompareEditorInput_titleAncestorSameFile, new Object[] { lName, lRevision, rRevision });
            } else {
                IDMProject aProject = ((IDMRemoteResource) ancestorRoot.getRemote()).getProject();
                String aSpec = aProject.getId();
                if (aProject.isSccStyle()) {
                    aSpec = aSpec + '/' + aProject.getRemoteOffset().toString();
                }
                title = NLS.bind(Messages.DMCompareEditorInput_titleAncestor, new Object[] { lSpec, rSpec, aSpec });
            }
        } else {
            if (lName.length() > 0 && lName.equals(rName)) {
                title = NLS.bind(Messages.DMCompareEditorInput_titleNoAncestorSameFile,
                        new Object[] { lName, lRevision, rRevision });
            } else {
                title = NLS.bind(Messages.DMCompareEditorInput_titleNoAncestor, lSpec, rSpec);
            }
        }
        toolTipText = title;
        setTitle(title);
    }

    private void setLabels(CompareConfiguration cc, IStructuredSelection selection) {
        String ancestorLabel = null;
        String leftLabel = null;
        String rightLabel = null;

        Image ancestorImage = null;
        Image leftImage = null;
        Image rightImage = null;

        if (!selection.isEmpty()) {
            DiffNode node = (DiffNode) selection.getFirstElement();
            RemoteResourceTypedElement ae = (RemoteResourceTypedElement) node.getAncestor();
            if (ae != null) {
                ancestorLabel = getLabel((IDMRemoteResource) ae.getRemote());
            }
            RemoteResourceTypedElement le = (RemoteResourceTypedElement) node.getLeft();
            if (le != null) {
                leftLabel = getLabel((IDMRemoteResource) le.getRemote());
            }
            RemoteResourceTypedElement re = (RemoteResourceTypedElement) node.getRight();
            if (re != null) {
                rightLabel = getLabel((IDMRemoteResource) re.getRemote());
            }
        } else {
            if (ancestorRoot != null) {
                ancestorLabel = getLabel((IDMRemoteResource) ancestorRoot.getRemote());
            }
            if (leftRoot != null) {
                leftLabel = getLabel((IDMRemoteResource) leftRoot.getRemote());
            }
            if (rightRoot != null) {
                rightLabel = getLabel((IDMRemoteResource) rightRoot.getRemote());
            }
        }

        cc.setAncestorLabel(ancestorLabel);
        cc.setLeftLabel(leftLabel);
        cc.setRightLabel(rightLabel);

        cc.setAncestorImage(ancestorImage);
        cc.setLeftImage(leftImage);
        cc.setRightImage(rightImage);
    }

    private String getLabel(IDMRemoteResource remoteResource) {
        if (remoteResource.isContainer()) {
            return remoteResource.getPath().toString();
        }
        IDMRemoteFile remoteFile = (IDMRemoteFile) remoteResource;
        return NLS.bind(Messages.nameAndRevision, remoteFile.getName(), remoteFile.getRevision());
    }

    @Override
    public String getToolTipText() {
        if (toolTipText != null) {
            return toolTipText;
        }
        return super.getToolTipText();
    }

    @Override
    public boolean isSaveNeeded() {
        return false;
    }

    private boolean considerContentsIfRevisionsDiffer() {
        return DMTeamUiPlugin.getDefault().getPreferenceStore().getBoolean(IDMTeamPreferences.COMPARE_CONSIDER_CONTENTS);
    }

}

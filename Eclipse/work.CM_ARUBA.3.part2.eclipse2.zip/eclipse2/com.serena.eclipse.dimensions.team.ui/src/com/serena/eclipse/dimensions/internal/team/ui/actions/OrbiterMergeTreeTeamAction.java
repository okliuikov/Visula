package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.io.UnsupportedEncodingException;

import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.actions.OrbiterMergeTreeAction;
import com.serena.eclipse.dimensions.ui.actions.ShowRepoBrowserPulsePageFromTeamMenuAction;

public class OrbiterMergeTreeTeamAction extends ShowRepoBrowserPulsePageFromTeamMenuAction {
    private OrbiterMergeTreeAction orbiterMergeTreeAction = new OrbiterMergeTreeAction();

    @Override
    protected String getRedirectUrl(DimensionsConnectionDetailsEx dmConn, final Project cmProject) throws 
        UnsupportedEncodingException, DMException {
        return orbiterMergeTreeAction.getRedirectUrl(dmConn, cmProject);
    }
    
    @Override
    protected String getPageTitle() {
        return "Changeset Graph";
    }
    
    @Override
    protected String getImageLocation() {
        return IDMImages.TRANSPARENT_ICON;
    }
}
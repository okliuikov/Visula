/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.CmRulesDetails;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.FolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFolder;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.IMoveRequest;
import com.serena.eclipse.dimensions.internal.team.core.MoveFolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.MoveItemRequest;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.Option;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class MoveHelper extends TeamOperationWizardHelper {
    private static final String UNMANAGE = "unmanage"; //$NON-NLS-1$
    private boolean crossProject;
    private List<IResource> crossPrjMoveSources = Collections.emptyList();

    public MoveHelper(IResource[] initialResources, IDMWorkspaceResourceFilter filter, IProgressMonitor monitor)
            throws CoreException {
        super(initialResources, filter, monitor);
        initialize(monitor);
    }

    @Override
    protected void populateMaps(Map<IResource, WorkspaceResourceRequest> requests, Map<IResource, IAttributeModel> attributes,
            IDMWorkspaceResource[] resources, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);

        ArrayList<IDMWorkspaceFile> movedFiles = new ArrayList<IDMWorkspaceFile>();
        ArrayList<ItemRevision> revisions = new ArrayList<ItemRevision>();
        ArrayList<IDMWorkspaceResource> movedFolders = new ArrayList<IDMWorkspaceResource>();

        for (int i = 0; i < resources.length; i++) {
            if (resources[i].isMoved()) {
                if (resources[i].isContainer()) {
                    movedFolders.add(resources[i]);
                } else {
                    IDMWorkspaceFile dmFile = (IDMWorkspaceFile) resources[i];
                    movedFiles.add(dmFile);
                    revisions.add(dmFile.getBaseFile().getItemRevision());
                }
            } else {
                if (resources[i].isContainer()) {
                    // put a dummy so the parent is shown in the wizard tree
                    requests.put(resources[i].getLocalResource(), new FolderRequest((IContainer) resources[i].getLocalResource()));
                } else {
                    assert false; // not moved files should be excluded by expandResources
                }
            }
        }

        try {
            DimensionsConnectionDetailsEx connection = getConnection();
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            primeAttributesForCache(revisions, Utils.subMonitorFor(monitor, 10));

            // hit structure rules
            ArrayList<IDMWorkspaceResource> filesThenFolders = new ArrayList<IDMWorkspaceResource>(movedFiles.size()
                    + movedFolders.size());
            filesThenFolders.addAll(movedFiles);
            filesThenFolders.addAll(movedFolders);
            int[] cmRulesResult = queryCmRules(CmRulesDetails.CMRULES_STRUCTURE, filesThenFolders, null, monitor);

            for (int i = 0; i < movedFiles.size(); i++) {
                IDMWorkspaceFile dmFile = movedFiles.get(i);
                ItemRevision revision = revisions.get(i);
                ItemType itemType = (ItemType) connection.getType(revision, Utils.subMonitorFor(monitor, 10)); // 10
                boolean requestReqd = cmRulesResult[i] > 0;
                WorkspaceResourceRequest request = new MoveItemRequest(dmFile.getLocalFile(), itemType, revision, requestReqd);
                requests.put(dmFile.getLocalFile(), request);
            }

            for (int i = 0; i < movedFolders.size(); i++) {
                IDMWorkspaceFolder dmFold = (IDMWorkspaceFolder) movedFolders.get(i);
                boolean requestReqd = cmRulesResult[movedFiles.size() + i] > 0;
                WorkspaceResourceRequest request = new MoveFolderRequest(dmFold.getLocalFolder(), requestReqd);
                requests.put(dmFold.getLocalResource(), request);
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    public IResource[] getOperationResources() {
        ArrayList<IResource> list = new ArrayList<IResource>();
        IResource[] selResources = getExpandedResources();
        for (int i = 0; i < selResources.length; i++) {
            if (getRequest(selResources[i]) instanceof IMoveRequest) { // exclude dummies
                list.add(selResources[i]);
            }
        }
        return list.toArray(new IResource[list.size()]);
    }

    @Override
    protected Option[] createOptions() {
        IResource[] resources = getInitialResources();
        for (int i = 0; i < resources.length; i++) {
            if (resources[i].getType() == IResource.PROJECT) {
                try {
                    IDMWorkspaceResource wspProject = DMTeamPlugin.getWorkspace().getWorkspaceResource(resources[i]);
                    if (wspProject.isMoved()) { // move by shallow status
                        return new Option[] {}; // if we rename a project we don't want to have an option to make outgoing additions
                    }
                } catch (CoreException e) {
                    DMTeamUiPlugin.log(e.getStatus());
                }
            }
        }
        return new Option[] { new Option(UNMANAGE, Messages.MoveHelper_1, new Option.Value[] { Option.YES, Option.NO }, 1) };
    }

    @Override
    public void commit() throws CoreException {
        super.commit();
        boolean unmanage = getOptions().length > 0 ? getOptions()[0].getSelectedValue() == Option.YES : false;
        IResource[] resources = getOperationResources();
        for (int i = 0; i < resources.length; i++) {
            IMoveRequest moveRequest = (IMoveRequest) getRequest(resources[i]);
            moveRequest.setComment(getComment());
            moveRequest.setUnmanage(unmanage);
        }

        // get rid of x-prj move sources and set their requests onto the destination requests
        if (crossProject) {
            ArrayList<IMoveRequest> sources = new ArrayList<IMoveRequest>();
            crossPrjMoveSources = new ArrayList<IResource>();
            HashMap<IResource, IMoveRequest> destinations = new HashMap<IResource, IMoveRequest>();
            for (int i = 0; i < resources.length; i++) {
                IMoveRequest moveRequest = (IMoveRequest) getRequest(resources[i]);
                moveRequest.setComment(getComment());
                if (moveRequest.isCrossProject()) {
                    if (moveRequest.isSource()) {
                        sources.add(moveRequest);
                    } else {
                        destinations.put(moveRequest.getResource(), moveRequest);
                    }
                }
            }
            for (Iterator<IMoveRequest> iterator = sources.iterator(); iterator.hasNext();) {
                IMoveRequest srcReq = iterator.next();
                crossPrjMoveSources.add(srcReq.getResource());
                IMoveRequest destReq = destinations.get(srcReq.getDestination());
                if (destReq != null) {
                    destReq.setSourceRequests(srcReq.getChangeRequests());
                }
            }
            excludeFiles(crossPrjMoveSources.toArray(new IResource[crossPrjMoveSources.size()]));
        }
    }

    public IResource[] getCrossProjectMoveSources() {
        return crossPrjMoveSources.toArray(new IResource[crossPrjMoveSources.size()]);
    }

    @Override
    protected IDMWorkspaceResource[] expandResources(IResource[] resources) throws CoreException {
        IDMWorkspaceResource[] expResources = super.expandResources(resources);
        ArrayList<IDMWorkspaceResource> xpMoves = new ArrayList<IDMWorkspaceResource>();
        for (int i = 0; i < expResources.length; i++) {
            IDMProject movedFromProject = expResources[i].getMovedFromProject();
            if (movedFromProject != null && movedFromProject.isWorkset()) {
                crossProject = true;
                IResource movedFrom = expResources[i].getMovedFrom();
                if (movedFrom != null) {
                    xpMoves.add(DMTeamPlugin.getWorkspace().getWorkspaceResource(movedFrom));
                }
            }
        }
        if (xpMoves.isEmpty()) {
            return expResources;
        }
        ArrayList<IDMWorkspaceResource> result = new ArrayList<IDMWorkspaceResource>(expResources.length + xpMoves.size());
        result.addAll(Arrays.asList(expResources));
        result.addAll(xpMoves);
        crossPrjMoveSources = new ArrayList<IResource>(xpMoves.size());
        for (int i = 0; i < xpMoves.size(); i++) {
            crossPrjMoveSources.add(xpMoves.get(i).getLocalResource());
        }
        return result.toArray(new IDMWorkspaceResource[result.size()]);
    }

}

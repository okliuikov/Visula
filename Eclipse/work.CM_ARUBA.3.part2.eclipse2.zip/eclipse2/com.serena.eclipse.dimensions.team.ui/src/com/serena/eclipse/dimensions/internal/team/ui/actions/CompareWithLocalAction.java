/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.IMappedObjectDetails;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.SccProjectList;
import com.serena.eclipse.dimensions.core.VersionManagementAdapter;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.RootIdmProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.views.DimensionsIDEProjectHistoryView;
import com.serena.eclipse.dimensions.internal.ui.views.SccProjectContainerHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Compares remote node with local project if local context is available.
 *
 * @author V.Grishchenko
 */
public class CompareWithLocalAction extends DMTeamAction {

    public CompareWithLocalAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        VersionManagementProject remote = (VersionManagementProject) getSelection().getFirstElement();
        if (remote == null) {
            return;
        }

        IProject local = getLocal(remote);
        if (local == null) {
            return;
        }

        IDMProject remoteProject = getRemoteInterface(local, remote);
        if (remoteProject == null) {
            return;
        }

        IProject[] pa = { local };
        IProject[][] paa = { pa };
        compare(pa, paa, new IDMProject[] { remoteProject });
    }

    @Override
    protected void setActionEnablement(IAction action) {
        super.setActionEnablement(action);

        String text = null;

        if (action.isEnabled()) {
            IProject local = getLocal((VersionManagementProject) getSelection().getFirstElement());
            if (local != null) {
                text = NLS.bind(Messages.CompareWithLocalAction_0, local.getName());
            }
        }

        if (text == null) {
            text = Messages.CompareWithLocalAction_2;
        }

        action.setText(text);
    }

    @Override
    protected boolean isEnabledForSelection() {
        IStructuredSelection selection = getSelection();
        if (selection.size() != 1) {
            return false;
        }

        VersionManagementProject remote = (VersionManagementProject) selection.getFirstElement();

        // 1. only enable for "workspace addable" things
        if (remote.getClass() != WorksetAdapter.class && remote.getClass() != BaselineAdapter.class
                && remote.getClass() != SccProject.class && remote.getClass() != SccProjectContainerWorkset.class
                && remote.getClass() != SccBaselineContainer.class) {
            return false;
        }

        // 2. see if can get a local for it
        return getLocal(remote) != null;
    }

    private IProject getLocal(VersionManagementProject remote) {
        if (remote == null) {
            return null;
        }

        // 1. if in history see if there is local context
        if (getActivePart() instanceof DimensionsIDEProjectHistoryView) {
            if (((DimensionsIDEProjectHistoryView) getActivePart()).getLocal() != null) {
                return ((DimensionsIDEProjectHistoryView) getActivePart()).getLocal();
            }
        } else if (getActivePart() instanceof SccProjectContainerHistoryView) {
            if (((SccProjectContainerHistoryView) getActivePart()).getLocal() != null) {
                return ((SccProjectContainerHistoryView) getActivePart()).getLocal();
            }
        }

        // 2. no luck so far, because of ambiguity reject scc project containers
        if (remote.getClass() == SccProjectContainerWorkset.class || remote.getClass() == SccBaselineContainer.class) {
            return null;
        }

        // 2. otherwise use first local mapping, if any
        try {
            List<IMappedObjectDetails> mappings = remote.getMappings();
            if (!mappings.isEmpty()) {
                for (IMappedObjectDetails mapped : mappings) {
                    if (mapped instanceof RootIdmProject) {
                        return mapped.getProject();
                    }
                }
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }

        return null;
    }

    private IDMProject getRemoteInterface(final IProject local, final VersionManagementAdapter remote)
            throws InvocationTargetException, InterruptedException {
        final IDMProject[] result = new IDMProject[1];
        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    monitor.beginTask(Messages.CompareWithLocalAction_3, 200);
                    VersionManagementAdapter remote1 = null;
                    IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(local);
                    if (dmProject.isSccStyle()) {
                        SccProject sccProject = null;
                        if (remote instanceof SccProject) {
                            sccProject = (SccProject) remote;
                            monitor.worked(100);
                        } else if (remote instanceof SccProjectContainerWorkset) {
                            SccProjectList members = ((SccProjectContainerWorkset) remote).getMemberList();
                            members.fetch(Utils.subMonitorFor(monitor, 100));
                            sccProject = members.findProject(dmProject.getRemoteOffset());
                        } else if (remote instanceof SccBaselineContainer) {
                            SccProjectList members = ((SccBaselineContainer) remote).getMemberList();
                            members.fetch(Utils.subMonitorFor(monitor, 100));
                            sccProject = members.findProject(dmProject.getRemoteOffset());
                        }
                        if (sccProject != null) {
                            remote1 = sccProject;
                        }
                    } else {
                        remote1 = remote;
                        monitor.worked(100);
                    }
                    if (remote1 != null) {
                        result[0] = DMRepositoryProvider.createProject(remote1, local, null);
                    }
                    monitor.worked(100);
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                } finally {
                    monitor.done();
                }
            }
        });
        return result[0];
    }

    private void compare(IProject[] projects, IResource[][] roots, IDMProject[] remoteProjects) {
        DMTeamUiPlugin.getDefault().compare(projects, roots, remoteProjects);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.views;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.PropertyPage;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class ProjectPropertyPage extends PropertyPage {

    private IDMProject dmProject;
    private Text connTxt;
    private Text idTxt;
    private Text streamParentSpecTxt;
    private Label streamParentLabel;
    private Label projStreamLabel;
    private Text ideProjTxt;
    private Text offsetTxt;

    public ProjectPropertyPage() {
    }

    @Override
    protected Control createContents(Composite parent) {

        IProject theProject = getProject();
        if (theProject != null) {
            try {
                dmProject = DMTeamPlugin.getWorkspace().getProject(theProject);
            } catch (CoreException e) {
                DMTeamUiPlugin.getDefault().handle(e, getShell());
            }
        }

        noDefaultAndApplyButton();
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 2);

        // ide proj
        UIUtils.createLabel(composite, Messages.ProjectPropertyPage_ideProj);
        ideProjTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(ideProjTxt, GridData.FILL_HORIZONTAL);

        // remote offset
        if (!(dmProject.getRemoteOffset().toOSString() == null || dmProject.getRemoteOffset().toOSString().length() == 0)) {
            UIUtils.createLabel(composite, Messages.ProjectPropertyPage_offset);
            offsetTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
            UIUtils.setGridData(offsetTxt, GridData.FILL_HORIZONTAL);
        }

        // connection
        UIUtils.createLabel(composite, Messages.ProjectPropertyPage_connection);
        connTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(connTxt, GridData.FILL_HORIZONTAL);

        // project id
        projStreamLabel = UIUtils.createLabel(composite, Messages.ProjectPropertyPage_projId);
        idTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(idTxt, GridData.FILL_HORIZONTAL);

        // Stream parent spec
        streamParentLabel = UIUtils.createLabel(composite, Messages.ProjectPropertyPage_streamParent);
        streamParentSpecTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        streamParentLabel.setVisible(false);
        streamParentSpecTxt.setVisible(false);

        UIUtils.createLabel(composite, SWT.NONE, null); // spacer
        UIUtils.createLabel(composite, SWT.NONE, null); // spacer
        UIUtils.createLabel(composite, SWT.NONE, null); // spacer

        setValues();
        return composite;
    }

    private IProject getProject() {
        IAdaptable adaptableElement = getElement();
        if (adaptableElement instanceof IProject) {
            return (IProject) adaptableElement;
        }
        return (IProject) adaptableElement.getAdapter(IProject.class);
    }

    private void setValues() {
        if (dmProject != null) {
            DimensionsConnectionDetailsEx connection = dmProject.getConnection();

            // connection
            connTxt.setText(connection.getConnName());

            // project id
            idTxt.setText(dmProject.getId());

            try {
                if (dmProject.getIsStream()) {
                    streamParentLabel.setVisible(true);
                    streamParentSpecTxt.setVisible(true);
                    projStreamLabel.setText(Messages.ProjectPropertyPage_streamId);
                    dmProject.getDimensionsObject().queryAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
                    String parentSpec = (String) dmProject.getDimensionsObject().getAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
                    parentSpec = parentSpec == null ? "" : parentSpec;
                    streamParentSpecTxt.setText(parentSpec.equals("") ? Messages.common_noneText : parentSpec);
                }
            } catch (DMException dme) {

            }

            // ide proj
            ideProjTxt.setText(UIUtils.getDisplayText(dmProject.getIdeProjectName()));

            // remote offset
            if (!(dmProject.getRemoteOffset().toOSString() == null || dmProject.getRemoteOffset().toOSString().length() == 0)) {
                offsetTxt.setText(UIUtils.getDisplayText(dmProject.getRemoteOffset().toString()));
            }
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;

public class DMWorkspaceStreamCompareParticipant extends DMWorkspaceStreamOutgoingParticipant {
    public static final String ID = "com.serena.eclipse.dimensions.team.dmworkspace-stream-compare-participant"; //$NON-NLS-1$

    public DMWorkspaceStreamCompareParticipant() {
    }

    public DMWorkspaceStreamCompareParticipant(ISynchronizeScope scope) {
        super(scope);
        setSubscriber(DMTeamPlugin.getWorkspace().getSubscriber());
    }

    @Override
    protected ISynchronizeParticipantDescriptor getDescriptor() {
        return TeamUI.getSynchronizeManager().getParticipantDescriptor(ID);
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);

        int mode = ISynchronizePageConfiguration.BOTH_MODE;
        int supported = ISynchronizePageConfiguration.OUTGOING_MODE | ISynchronizePageConfiguration.CONFLICTING_MODE
                | ISynchronizePageConfiguration.INCOMING_MODE | ISynchronizePageConfiguration.BOTH_MODE;

        configuration.setSupportedModes(supported);
        configuration.setMode(mode);
    }

}

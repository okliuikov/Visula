/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.GetRevisionRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * @author V.Grishchenko
 */
public class DMCompareReplaceOperation extends DMSynchronizeModelOperation {

    public DMCompareReplaceOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        super(configuration, elements);
    }

    @Override
    protected void run(SyncData data, IProgressMonitor monitor) throws CoreException {
        SyncInfoSet set = data.getSyncInfoSet();
        if (set.isEmpty() || !promptForOverwrite(set)) {
            return;
        }

        ArrayList<SyncInfo> folderCreations = new ArrayList<SyncInfo>();
        ArrayList<SyncInfo> deletions = new ArrayList<SyncInfo>();
        ArrayList<SyncInfo> updates = new ArrayList<SyncInfo>();

        SyncInfo[] changes = set.getSyncInfos();
        for (int i = 0; i < changes.length; i++) {
            SyncInfo change = changes[i];

            // Make sure that parent folders exist
            SyncInfo parent = getParent(change);
            if (parent != null && isOutOfSync(parent)) {
                // We need to ensure that parents that are either incoming folder additions
                // or previously pruned folders are recreated.
                folderCreations.add(parent);
            }

            int kind = change.getKind();
            if (change.getRemote() == null && (change.getLocal() != null && change.getLocal().exists())) {
                deletions.add(change);
            } else if ((change.getLocal() == null || !change.getLocal().exists()) && change.getRemote() != null) {
                if (change.getLocal().getType() == IResource.FILE) {
                    updates.add(change);
                } else {
                    folderCreations.add(change);
                }
            } else if (change.getLocal().getType() == IResource.FILE && (SyncInfo.CHANGE_MASK & kind) == SyncInfo.CHANGE) {
                updates.add(change);
            }
        }

        try {
            monitor.beginTask(null, 100 * (folderCreations.size() + deletions.size() + updates.size()));

            if (folderCreations.size() > 0) {
                ensureParentsExist(folderCreations.toArray(new SyncInfo[folderCreations.size()]),
                        Utils.subMonitorFor(monitor, 100 * folderCreations.size()), false);
            }
            if (deletions.size() > 0) {
                runUpdateDeletions(deletions.toArray(new SyncInfo[deletions.size()]),
                        Utils.subMonitorFor(monitor, 100 * deletions.size()));
            }
            if (updates.size() > 0) {
                // cannot use the passed in provider as it is for local sharing only
                update(updates.toArray(new SyncInfo[updates.size()]), Utils.subMonitorFor(monitor, 100 * updates.size()));
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    protected String getJobName() {
        return Messages.DMCompareReplaceOperation_jobName;
    }

    protected void runUpdateDeletions(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100 * nodes.length);
        try {
            for (int i = 0; i < nodes.length; i++) {
                IResource resource = nodes[i].getLocal();
                resource.delete(IResource.KEEP_HISTORY, Utils.subMonitorFor(monitor, 100));
            }
        } finally {
            monitor.done();
        }
    }

    protected void update(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException {
        validateEdit(new SyncInfoSet(nodes));
        Map<IDMProject, List<GetRevisionRequest>> requestsByProject = new HashMap<IDMProject, List<GetRevisionRequest>>();
        for (int i = 0; i < nodes.length; i++) {
            IDMRemoteFile remoteFile = (IDMRemoteFile) nodes[i].getRemote();
            GetRevisionRequest request = new GetRevisionRequest((IFile) nodes[i].getLocal(), remoteFile.getItemRevision());
            request.setMetadata(false);
            request.setMakeWriteable(true);
            IDMProject project = remoteFile.getProject();
            List<GetRevisionRequest> requests = requestsByProject.get(project);
            if (requests == null) {
                requests = new ArrayList<GetRevisionRequest>();
                requestsByProject.put(project, requests);
            }
            requests.add(request);
        }

        monitor.beginTask(null, 100 * requestsByProject.size());
        try {
            for (Iterator<Entry<IDMProject, List<GetRevisionRequest>>> iter = requestsByProject.entrySet().iterator(); iter.hasNext();) {
                Entry<IDMProject, List<GetRevisionRequest>> entry = iter.next();
                IDMProject project = entry.getKey();
                List<GetRevisionRequest> requests = entry.getValue();
                project.copyToWorkspace(requests.toArray(new GetRevisionRequest[requests.size()]),
                        Utils.subMonitorFor(monitor, 100));
            }
        } finally {
            monitor.done();
        }
    }

}

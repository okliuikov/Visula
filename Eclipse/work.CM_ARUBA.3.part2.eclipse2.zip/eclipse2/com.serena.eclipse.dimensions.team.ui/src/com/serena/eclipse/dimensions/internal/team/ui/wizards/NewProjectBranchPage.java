/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2009, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.Iterator;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.List;

import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.collections.VersionBranches;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

public class NewProjectBranchPage extends DimensionsWizardPage {
    private List lstBranches;
    private Combo cmbDefaultBranch;

    public NewProjectBranchPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(description);
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        Group grpValidBranches = new Group(composite, SWT.NONE);
        grpValidBranches.setText(Messages.NewStreamWizard_project_branches_lblValidBranches);
        UIUtils.setGridLayout(grpValidBranches, 1);
        UIUtils.setGridData(grpValidBranches, GridData.FILL_BOTH);

        lstBranches = new List(grpValidBranches, SWT.MULTI | SWT.V_SCROLL);
        UIUtils.setGridData(lstBranches, GridData.FILL_BOTH);

        // get project branches & fill list control with them
        try {
            VersionBranches vbs = ((NewStreamWizard) getWizard()).getConnection()
                    .openSession(null)
                    .getObjectFactory()
                    .getBaseDatabaseAdmin()
                    .getBranches();
            for (Iterator it = vbs.iterator(); it.hasNext();) {
                lstBranches.add((String) it.next());
            }
            Filter filter = new Filter();
            filter.criteria().add(new Filter.Criterion(SystemAttributes.WSET_IS_STREAM, "Y", Filter.Criterion.EQUALS));
            java.util.List streamList = ((NewStreamWizard) getWizard()).getConnection()
                    .openSession(null)
                    .getObjectFactory()
                    .getProjects(filter);
            if (null != streamList) {
                for (int i = 0; i < streamList.size(); i++) {
                    java.util.List branchList = ((Project) streamList.get(i)).getBranchNames();
                    if (null != branchList) {
                        for (int j = 0; j < branchList.size(); j++) {
                            for (int z = 0; z < lstBranches.getItemCount(); z++) {
                                if (branchList.get(j).equals(lstBranches.getItem(z))) {
                                    lstBranches.remove(z);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            setErrorMessage(e.getMessage());
        }

        lstBranches.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                String sel = cmbDefaultBranch.getText();
                cmbDefaultBranch.setItems(lstBranches.getSelection());
                for (int i = 0; i < cmbDefaultBranch.getItems().length; i++) {
                    if (cmbDefaultBranch.getItems()[i].equals(sel)) {
                        cmbDefaultBranch.setText(sel);
                        break;
                    }
                    if (cmbDefaultBranch.getItems().length - 1 == i) {
                        cmbDefaultBranch.setText(cmbDefaultBranch.getItems()[0]);
                    }
                }
            }
        });

        UIUtils.createLabel(composite, Messages.NewStreamWizard_project_branches_lblDefaultBranch);
        cmbDefaultBranch = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY);
        UIUtils.setGridData(cmbDefaultBranch, GridData.FILL_HORIZONTAL | GridData.VERTICAL_ALIGN_END);

        setControl(composite);
        setPageComplete(true);
    }

    public String[] getBranches() {
        final int[] count = new int[1];
        lstBranches.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                if (null == lstBranches || null == lstBranches.getSelection()) {
                    count[0] = 0;
                } else {
                    count[0] = lstBranches.getSelection().length;
                }
            }
        });

        if (0 == count[0]) {
            return null;
        }

        final String[] res = new String[count[0]];
        lstBranches.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < lstBranches.getSelection().length; i++) {
                    res[i] = lstBranches.getSelection()[i];
                }
            }
        });
        return res;
    }

    public String getDefaultBranch() {
        if (null == cmbDefaultBranch) {
            return null;
        }

        final String[] res = new String[1];
        cmbDefaultBranch.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                res[0] = cmbDefaultBranch.getText();
            }
        });
        return res[0];
    }
}

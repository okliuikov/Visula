/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.compare.ICompareContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ISynchronizeView;
import org.eclipse.team.ui.synchronize.ResourceScope;
import org.eclipse.team.ui.synchronize.SyncInfoCompareInput;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.TeamUIUtils;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMSynchronizeParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceStreamOutgoingParticipant;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Utils class for three way merge specific UI actions
 */
public class XMLMergeUIUtils {

    /**
     * Close all editors that were obtained from merge results
     */
    public static void closeMergeCompareEditors() {
        Display.getDefault().asyncExec(new Runnable() {

            @Override
            public void run() {
                IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
                if (page != null) {
                    page.closeEditors(findEditors(page, null, null), false);
                }
            }
        });

    }

    /**
     * Close all editors that related to specified sync info
     */
    public static boolean closeMergeCompareEditors(final XMLSyncInfo xinfo) {
        final boolean[] result = new boolean[] { false };
        Display.getDefault().syncExec(new Runnable() {

            @Override
            public void run() {
                IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
                if (page != null) {
                    IEditorReference[] findEditors = findEditors(page, xinfo, null);
                    if (findEditors != null && findEditors.length > 0) {
                        result[0] = page.closeEditors(findEditors(page, xinfo, null), false);
                    }
                }
            }
        });
        return result[0];

    }

    /**
     * Close all editors that related to specified sync info and does not relate to the specified compare container
     */
    public static boolean closeMergeCompareEditorsExcept(final XMLSyncInfo xinfo, final ICompareContainer dontClose) {
        final boolean[] result = new boolean[] { false };
        Display.getDefault().syncExec(new Runnable() {

            @Override
            public void run() {
                IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
                if (page != null) {
                    IEditorReference[] findEditors = findEditors(page, xinfo, dontClose);
                    if (findEditors != null && findEditors.length > 0) {
                        result[0] = page.closeEditors(findEditors(page, xinfo, dontClose), false);
                    }
                }
            }
        });
        return result[0];

    }

    private static IEditorReference[] findEditors(IWorkbenchPage page, XMLSyncInfo xinfo, ICompareContainer dontClose) {
        if (page == null) {
            page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
        }

        List<IEditorReference> relevantEditors = new ArrayList<IEditorReference>();

        if (page != null) {
            IEditorReference[] editorReferences = page.getEditorReferences();
            for (IEditorReference ref : editorReferences) {
                IEditorInput input;
                try {
                    input = ref.getEditorInput();
                    if (input instanceof SyncInfoCompareInput) {
                        SyncInfoCompareInput syncInput = (SyncInfoCompareInput) input;

                        if (syncInput.getSyncInfo() instanceof XMLSyncInfo) {
                            if (xinfo != null && dontClose != null && syncInput.getSyncInfo().equals(xinfo)
                                    && !dontClose.equals(syncInput)) {
                                relevantEditors.add(ref);
                            } else if (xinfo != null && dontClose == null && syncInput.getSyncInfo().equals(xinfo)) {
                                relevantEditors.add(ref);
                            } else if (xinfo == null && dontClose == null) {
                                relevantEditors.add(ref);
                            }
                        }
                    }
                } catch (PartInitException e) {
                    DMTeamUiPlugin.log(e.getStatus());
                }
            }
        }

        return relevantEditors.toArray(new IEditorReference[relevantEditors.size()]);
    }

    /**
     * Perform synchronization with home stream if this option was enabled in plugin preferences
     */
    public static void syncWithHome(MergeDescriptorsContainer container, final IWorkbenchPart part, boolean show) {
        if (!container.hasAppliedChanges()) {
            return;
        }

        if (DMTeamUiPlugin.getDefault().isForceHomeSync()) {
            final List<IResource> scopes = new ArrayList<IResource>();
            for (XMLMergeDescriptor descr : container.getMergeDescriptors()) {
                scopes.add(descr.getTarget().getProject());
            }

            try {
                TeamUIUtils.removeParticipantById(DMWorkspaceStreamOutgoingParticipant.ID);
            } catch (TeamException e) {
                DMTeamUiPlugin.log(e.getStatus());
            }

            final DMSynchronizeParticipant participant = new DMWorkspaceStreamOutgoingParticipant(new ResourceScope(
                    scopes.toArray(new IResource[scopes.size()])));
            TeamUI.getSynchronizeManager().addSynchronizeParticipants(new ISynchronizeParticipant[] { participant });
            participant.run(part);

            TeamUIUtils.filterSyncJobResults(participant, part != null ? part.getSite().getShell() : null);

            if (show) {
                Display.getDefault().asyncExec(new Runnable() {

                    @Override
                    public void run() {
                        ISynchronizeView view = TeamUI.getSynchronizeManager().showSynchronizeViewInActivePage();
                        if (view != null) {
                            view.display(participant);
                        }
                    }
                });
            }
        }
    }

    /**
     * Create a full label for specified action type inside synchronization view
     */
    public static String resolveActionLabel(Integer action, boolean isSubEntry) {
        XSyncUserAction label = XMLSyncInfo.getActionLabel(action);

        if (label == XSyncUserAction.SUAL_ACCEPT) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_accept;
        } else if (label == XSyncUserAction.SUAL_IGNORE) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ignore;
        } else if (label == XSyncUserAction.SUAL_UNRESOLVED) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved;
        }

        if (!isSubEntry) {
            if (label == XSyncUserAction.SUAL_MERGE) {
                return Messages.DMXMLMergeParticipantLabelDecorator_resolution_merge;
            } else if (label == XSyncUserAction.SUAL_USE_LOCAL) {
                return Messages.DMXMLMergeParticipantLabelDecorator_resolution_local;
            } else if (label == XSyncUserAction.SUAL_USE_REPOSITORY) {
                return Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote;
            }
        }

        XSyncUserAction direction = XMLSyncInfo.getActionDirection(action);
        if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_local_path;
        } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_path;
        } else {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved;
        }

    }

    /**
     * Create a full label for specified action type inside synchronization view.
     * This method is applicable only for conflicts such as add/add conflict
     * @param action action from XSyncUserAction enum.
     * @param revisions number of revisions in item
     * @param full whether full or short version of string needs to be returned
     * @return the label for action
     */
    public static String resolveActionLabelForConflictingItems(Integer action, Integer revisions, boolean full) {
        if (XMLSyncInfo.isConflictingItemsAction(action)) {
            if (revisions == null) {
                return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_hiderevisions;
            } else if (revisions > 1) {
                if (full) {
                    return NLS.bind(
                            Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_multi_full,
                            new Object[] { revisions });
                } else {
                    return NLS.bind(
                            Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_multi,
                            new Object[] { revisions });
                }
            } else if (revisions == 1) {
                if (full) {
                    return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem_full;
                } else {
                    return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_ReplaceWithRepositoryItem;
                }
            }
        } else {
            if (revisions == null) {
                return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_hiderevisions;
            } else if (revisions > 1) {
                if (full) {
                    return NLS.bind(
                            Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_multi_full,
                            new Object[] { revisions });
                } else {
                    return NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_multi,
                            new Object[] { revisions });
                }
            } else if (revisions == 1) {
                if (full) {
                    return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem_full;
                } else {
                    return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_KeepLocalItem;
                }
            }
        }
        return Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved;
    }

    /**
     * Create a path relative label for specified sync info inside synchronization view
     */
    public static String resolveActionPath(XMLSyncInfo info) {
        if (info.isStale()) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_stale;
        }

        XSyncUserAction direction = info.getCurrentActionDirection();
        XSyncUserAction label = info.getCurrentActionLabel();
        if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_local_path;
        } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_path;
        } else if (label == XSyncUserAction.SUAL_ACCEPT) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_path;
        } else if (label == XSyncUserAction.SUAL_IGNORE) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ignore;
        } else if (label == XSyncUserAction.SUAL_MERGE) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_path;
        } else {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved;
        }

    }

    /**
     * Create a content relative label for specified sync info inside synchronization view
     */
    public static String resolveActionContent(XMLSyncInfo info) {
        if (info.isStale()) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_stale;
        }

        XSyncUserAction source = info.getCurrentActionContentSource();
        XSyncUserAction label = info.getCurrentActionLabel();
        if (label == XSyncUserAction.SUAL_ACCEPT) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_content;
        } else if (label == XSyncUserAction.SUAL_IGNORE) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ignore;
        } else if (source == XSyncUserAction.SUAO_MERGE_2WAY || source == XSyncUserAction.SUAO_MERGE_3WAY) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_merge_content;
        } else if (source == XSyncUserAction.SUAO_USE_LOCAL_FILE) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_local_content;
        } else if (source == XSyncUserAction.SUAO_USE_REPOSITORY_FILE) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_content;
        } else {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved;
        }
    }

    public static String resolveActionItem(XMLSyncInfo info) {
        if (info.isStale()) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_stale;
        }

        Integer action = info.getCurrentAction();
        Integer localItemRevisionCount = info.getResolution().getTgt().getRevisionCount();
        Integer repositoryItemRevisionCount = info.getResolution().getSrc().getRevisionCount();

        if (XMLSyncInfo.isUnresolved(action)) {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved;
        }
        if (info.hasConflictingItemsActions()) {
            if (XMLSyncInfo.isConflictingItemsAction(action)) {
                return resolveActionLabelForConflictingItems(action, repositoryItemRevisionCount, false);
            } else {
                return resolveActionLabelForConflictingItems(action, localItemRevisionCount, false);
            }
        } else {
            return Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_LocalItem;
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.eclipse.dimensions.internal.team.ui.controls.FolderBrowsePanel;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * @author V.Grishchenko
 */
public class FolderSelectionDialog extends Dialog {
    protected FolderBrowsePanel folderSelectionPanel;
    private RepositoryFolder selection;
    private String title;

    private DimensionsArObject obj;
    private ViewerFilter folderFilter;

    public FolderSelectionDialog(Shell parentShell, String title, DimensionsArObject obj, ViewerFilter folderFilter) {

        super(parentShell);
        setShellStyle(getShellStyle() | SWT.RESIZE);
        this.title = title;
        this.obj = obj;
        this.folderFilter = folderFilter;
    }

    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        if (title != null) {
            newShell.setText(title);
        }
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite) super.createDialogArea(parent);
        composite.setSize(400, 300);
        folderSelectionPanel = new FolderBrowsePanel(composite, obj, folderFilter);
        GridData gd = UIUtils.setGridData(folderSelectionPanel.getPanel(), GridData.FILL_BOTH);
        gd.widthHint = 400;
        gd.heightHint = 300;

        folderSelectionPanel.setSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                copySelection();
                updateButtons();
            }
        });

        folderSelectionPanel.setDoubleClickListener(new IDoubleClickListener() {
            @Override
            public void doubleClick(DoubleClickEvent event) {
                if (!(event.getSelection() == null)) {
                    copySelection();
                    okPressed();
                }
            }
        });

        return composite;
    }

    private void copySelection() {
        selection = null;
        selection = folderSelectionPanel.getSelectedFolder();
    }

    private void updateButtons() {
        Button okButton = getButton(IDialogConstants.OK_ID);
        okButton.setEnabled(!(selection == null));
    }

    @Override
    protected void cancelPressed() {
        super.cancelPressed();
        selection = null;
    }

    /**
     * @return selected objects, never <code>null</code>
     */
    public RepositoryFolder getSelectedFolder() {
        return selection;
    }

}

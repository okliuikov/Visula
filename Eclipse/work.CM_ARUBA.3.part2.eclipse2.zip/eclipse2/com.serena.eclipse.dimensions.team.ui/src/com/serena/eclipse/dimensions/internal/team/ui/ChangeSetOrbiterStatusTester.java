package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.eclipse.dimensions.internal.ui.views.OrbiterUtils;

public class ChangeSetOrbiterStatusTester extends PropertyTester {

    public static final String URL_AVAILABLE = "peerReviewUrlAvailable"; //$NON-NLS-1$

    public ChangeSetOrbiterStatusTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (!(receiver instanceof StructuredSelection)) {
            return false;
        }
        StructuredSelection ss = (StructuredSelection) receiver;
        Object selected = ss.getFirstElement();
        if (!(selected instanceof DimensionsChangeSet)) {
            return false;
        }
        DimensionsChangeSet cs = (DimensionsChangeSet) selected;

        if (property.equals(URL_AVAILABLE) && cs.isOrbiterStatusReady()) {
            boolean statusOk = (cs.getReview() != OrbiterUtils.NONE || cs.getBuild() != OrbiterUtils.NONE)
                    && (cs.getReview() != OrbiterUtils.UNKNOWN || cs.getBuild() != OrbiterUtils.UNKNOWN);
            return cs.getSuffix() != null && !cs.getSuffix().isEmpty() && statusOk;
        } else {
            return false;
        }
    }

}

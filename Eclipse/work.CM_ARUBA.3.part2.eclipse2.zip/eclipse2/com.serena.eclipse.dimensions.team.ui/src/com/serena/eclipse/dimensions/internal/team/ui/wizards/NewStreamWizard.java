/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsDatabaseOptions;
import com.serena.dmclient.objects.Type;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProject;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectDetails;
import com.serena.eclipse.dimensions.core.FavouriteProjectsList;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.IFavouriteObject;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccBaselineContainerList;
import com.serena.eclipse.dimensions.core.SccProjectContainer;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.core.sbm.ISBMRequest;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.RehomeCommand;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.team.ui.actions.AddToWorkspaceAsAction.MappingsDataTransfer;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewStreamTopicWorkareaPage.PostCreationMode;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.atts.AttributeEntry;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.WorksetAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.wizards.AttributesWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewObjectWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Wizard that creates a stream or project.
 * 
 * @author A.Solod
 */
public class NewStreamWizard extends NewObjectWizard {
    
    public enum Mode {
        UNKNOWN,
        COMMON_STREAM,
        TOPIC_STREAM
    }
    
    public static final String SP_WELCOME_PAGE = "sp_welcome_page"; // 1 both

    public static final String STREAM_GENERAL_PAGE = "stream_general_page"; // 2 stream
    public static final String STREAM_DETAILS_PAGE = "stream_details_page"; // 3 stream
    public static final String STREAM_ATTR_PAGE = "stream_attr_page"; // 4 stream
    public static final String STREAM_SUMMARY_PAGE = "stream_summary_page"; // last stream

    public static final String PROJECT_GENERAL_PAGE = "project_general_page"; // 2 project
    public static final String PROJECT_DETAILS_PAGE = "project_details_page"; // 3 project
    public static final String PROJECT_OPTIONS_PAGE = "stream_options_page"; // 4 project

    public static final String PROJECT_BRANCHES_PAGE = "project_branches_page"; // 5 project
    public static final String PROJECT_ATTR_PAGE = "project_attr_page"; // 6 project
    public static final String PROJECT_SUMMARY_PAGE = "project_summary_page"; // last project

    public static final String STREAM_SELECTOR_PAGE = "stream_selector_page"; // stream
    public static final String STREAM_TOPIC_WORKAREA_PAGE = "stream_topic_workarea_page"; 
    public static final String STREAM_TOPIC_USERS_PAGE = "stream_topic_users_page"; 

    private WorksetAdapter createdAdapter;
    protected boolean isStream = true;
    protected boolean dontShowWelcomePage = false;

    // caching DB Options settings
    private DimensionsConnectionDetailsEx connForDBOptions;
    private boolean streamsAllowed = true;
    private boolean projectsAllowed = true;
    private int typeOption = 0;
    protected Mode mode = Mode.UNKNOWN;
    
    private ISBMRequest basedOnSbmRequest;

    protected DimensionsIDEProjectDetails streamDetails; // like-objectDetails in superclass but for streams

    public NewStreamWizard() {
        setNeedsProgressMonitor(true);
        setWizardTitle();
    }

    public NewStreamWizard(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn, boolean isStream) {
        super(connection, basedOn);
        this.isStream = isStream;
        setNeedsProgressMonitor(true);
        setWizardTitle();
    }
    
    public Mode getMode()
    {
        return mode;
    }
    
    public void setMode(Mode value)
    {
        mode = value;
    }

    public WorksetAdapter getCreatedObjectAdapter() {
        return createdAdapter;
    }
    
    public ISBMRequest getBaseOnSbmRequest() {
        return basedOnSbmRequest;
    }

    public void setBasedOnSbmRequest(ISBMRequest basedOn) {
        this.basedOnSbmRequest = basedOn;
    }

    protected void setWizardTitle() {
        if (getMode() == Mode.TOPIC_STREAM) {
            setWindowTitle("Create New Topic Stream");//$NON-NLS-1$
        } else {
            setWindowTitle(isStream ? Messages.NewStreamWizard_title_stream : Messages.NewStreamWizard_title_project);
        }
    }

    @Override
    public void addPages() {
        super.addPages();

        IWizardPage[] pages = null;
        if (getMode() == Mode.TOPIC_STREAM) {
            pages = createTopicStreamOperationPages();
        }
        else {
            pages = createPages();
        }
        for (int i = 0; i < pages.length; i++) {
            addPage(pages[i]);
        }
    }

    protected IWizardPage[] createTopicStreamOperationPages() {
        IWizardPage[] pages = new IWizardPage[2];
        pages[0] = new NewStreamTopicWorkareaPage(STREAM_TOPIC_WORKAREA_PAGE, null);
        pages[1] = new NewStreamTopicUsersPage(STREAM_TOPIC_USERS_PAGE);

        return pages;
    }

    protected IWizardPage[] createPages() {
        List<IWizardPage> pages_vec = new ArrayList<IWizardPage>();

        // @formatter:off
        if (!dontShowWelcomePage) {
            pages_vec.add(new NewStreamWelcomePage(SP_WELCOME_PAGE,
                    Messages.NewStreamWizard_welcome_title,
                    Messages.NewStreamWizard_welcome_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));
        }
        
        if (!dontShowWelcomePage || isStream) {

            pages_vec.add(new NewStreamGeneralPage(STREAM_GENERAL_PAGE,
                    Messages.NewStreamWizard_stream_general_title,
                    Messages.NewStreamWizard_stream_general_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                    true, false));

            pages_vec.add(new NewStreamDetailsPage(STREAM_DETAILS_PAGE,
                    Messages.NewStreamWizard_stream_details_title,
                    Messages.NewStreamWizard_stream_details_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                    true));

            pages_vec.add(new AttributesWizardPage(STREAM_ATTR_PAGE,
                    Messages.NewStreamWizard_stream_attr_title,
                    Messages.NewStreamWizard_stream_attr_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

            pages_vec.add(new NewStreamSummaryPage(STREAM_SUMMARY_PAGE,
                    Messages.NewStreamWizard_summary_title,
                    Messages.NewStreamWizard_summary_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));
            
        }

        if (!dontShowWelcomePage || !isStream) {
            pages_vec.add(new NewStreamGeneralPage(PROJECT_GENERAL_PAGE,
                    Messages.NewStreamWizard_project_general_title,
                    Messages.NewStreamWizard_project_general_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                    false, false));

            pages_vec.add(new NewStreamDetailsPage(PROJECT_DETAILS_PAGE,
                    Messages.NewStreamWizard_project_details_title,
                    Messages.NewStreamWizard_project_details_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                    false));

            pages_vec.add(new NewProjectOptionsPage(PROJECT_OPTIONS_PAGE,
                    Messages.NewStreamWizard_project_options_title,
                    Messages.NewStreamWizard_project_options_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

            pages_vec.add(new NewProjectBranchPage(PROJECT_BRANCHES_PAGE,
                    Messages.NewStreamWizard_project_branches_title,
                    Messages.NewStreamWizard_project_branches_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

            pages_vec.add(new AttributesWizardPage(PROJECT_ATTR_PAGE,
                    Messages.NewStreamWizard_project_attr_title,
                    Messages.NewStreamWizard_project_attr_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));

            pages_vec.add(new NewStreamSummaryPage(PROJECT_SUMMARY_PAGE,
                    Messages.NewStreamWizard_summary_title,
                    Messages.NewStreamWizard_summary_description,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN)));
        }
        // @formatter:on

        IWizardPage[] pages = pages_vec.toArray(new IWizardPage[pages_vec.size()]);
        return pages;
    }

    @Override
    public IWizardPage getStartingPage() {
        NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE);
        if (null != gp) {
            gp.setSuchProjectTypeAllowed(isStream ? areStreamsAllowed() : areProjectsAllowed());
        }
        return super.getStartingPage();
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page) {
        if (null == page) {
            return null;
        }
        // if (page.getName().equals(SP_WELCOME_PAGE) && !isStream) {
        // page = getPage(STREAM_SUMMARY_PAGE);

        if (page.getName().equals(STREAM_SUMMARY_PAGE)) {
            return null;
        }
        return super.getNextPage(page);
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page, boolean aboutToShow) {
        IWizardPage nextPage = super.getNextPage(page, aboutToShow);

        if (aboutToShow) {
            if (null != page) {
                // setting data before showing page
                if (null != nextPage) {
                    if (nextPage.getName().equals(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE)) {
                        ((NewStreamGeneralPage) nextPage).setSuchProjectTypeAllowed(isStream
                                ? areStreamsAllowed() : areProjectsAllowed());
                    } else if (nextPage.getName().equals(STREAM_ATTR_PAGE) || nextPage.getName().equals(PROJECT_ATTR_PAGE)) {
                        IAttributeModel mod = ((AttributesWizardPage) nextPage).getAttributeModel();
                        NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(isStream
                                ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE);
                        DimensionsIDEProjectDetails det = isStream ? streamDetails : (DimensionsIDEProjectDetails) objectDetails;
                        if (null == mod || null == det || !det.getProductName().equals(gp.getProductName())
                                || !det.getTypeName().equals(gp.getTypeName())) {
                            ((AttributesWizardPage) nextPage).setAttributeModel(createAttributeModel(getProductName(),
                                    gp.getTypeName(), gp.getType(), null));
                            try {
                                ((AttributesWizardPage) nextPage).getAttributeModel().load(null);
                            } catch (DMException e) { // don�t handle exception because
                            } // when project type has no attributes exception will be caught here
                        }

                        // exclude attribute page if no attributes defined for the type
                        if (null != ((AttributesWizardPage) nextPage).getAttributeModel()
                                && null != ((AttributesWizardPage) nextPage).getAttributeModel().getAllValues()
                                && 0 == ((AttributesWizardPage) nextPage).getAttributeModel().getAllValues().length) {
                            nextPage = getNextPage(nextPage);
                        }
                    } else if (nextPage.getName().equals(STREAM_TOPIC_USERS_PAGE)) {
                        DimensionsIDEProjectDetails details = createStreamDetails();
                        objectDetails = details;
                        if (aboutToShow) {
                            // we don't own this wizard's parent dialog, so cannot use late validation mechanism based on overriding dialog's methods
                            if (!runLateValidation()) {
                                return null;
                            }
                        }
                    } else if (nextPage.getName().equals(SharingWizard.OFFSET_PAGE)
                            && (getPage(SharingWizard.WORKSET_PAGE_ID) != null)) {
                        boolean inContainer = ((WorksetSelectionPage) (getPage(SharingWizard.WORKSET_PAGE_ID))).getCreateInContainer();
                        VersionManagementProject projResult = ((WorksetSelectionPage) (getPage(SharingWizard.WORKSET_PAGE_ID))).getResult();
                        String projectSpec = projResult != null ? projResult.getProjectSpec() : Utils.EMPTY_STRING;

                        if (!((OffsetPage) nextPage).isInitialized() || inContainer != ((OffsetPage) nextPage).isInContainerInit()
                                || !projectSpec.equals(((OffsetPage) nextPage).getProjectSpecInit())) {
                            ((OffsetPage) nextPage).initializeValues();
                        }
                    }
                }
            }

            if (nextPage instanceof NewStreamDetailsPage && nextPage.getControl() != null) {
                ((NewStreamDetailsPage) nextPage).reInit(true);
            }
        } else if (null != page) {
            if (page.getName().equals(SP_WELCOME_PAGE)) {
                if (null != ((NewStreamWelcomePage) page).isStream()) {
                    isStream = ((NewStreamWelcomePage) page).isStream().booleanValue();
                    nextPage = super.getNextPage(page, aboutToShow);
                }
            }

            // getting setting data while changing pages content
            if (page.getName().equals(STREAM_SUMMARY_PAGE) || page.getName().equals(PROJECT_SUMMARY_PAGE)) {
                refreshStreamDetails();
                NewStreamSummaryPage sp = (NewStreamSummaryPage) page;
                AttributesWizardPage ap = (AttributesWizardPage) getPage(isStream ? STREAM_ATTR_PAGE : PROJECT_ATTR_PAGE);
                AttributeEntry[] attrEntries = null;
                try {
                    if (null != ap.getAttributeModel()) {
                        attrEntries = ap.getAttributeModel().getEntries("$ALL", null);
                    }
                } catch (DMException e) {
                    attrEntries = null;
                }
                sp.initializeControlData((DimensionsIDEProjectDetails) (isStream ? streamDetails : objectDetails), attrEntries);
            }

            if (nextPage instanceof NewStreamDetailsPage && nextPage.getControl() != null) {
                ((NewStreamDetailsPage) nextPage).reInit(false);
            }
        }

        setWizardTitle();
        return nextPage;
    }

    @Override
    public boolean canFinish() {
        NewStreamWelcomePage wp = (NewStreamWelcomePage) getPage(SP_WELCOME_PAGE);
        // get if project type was changed (getNextPage will be called after)
        if (null != wp && null != wp.isStream()) {
            isStream = wp.isStream().booleanValue();
        }

        if (getMode() == Mode.TOPIC_STREAM) {
            NewStreamTopicWorkareaPage topicWorkareaPage = (NewStreamTopicWorkareaPage) getPage(STREAM_TOPIC_WORKAREA_PAGE);
            return topicWorkareaPage.getControl() != null && topicWorkareaPage.isPageComplete();
        }

        if (null != getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE)
                && getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE).isPageComplete()
                && (null != getPage(isStream ? STREAM_DETAILS_PAGE : PROJECT_DETAILS_PAGE) ? getPage(
                        isStream ? STREAM_DETAILS_PAGE : PROJECT_DETAILS_PAGE).isPageComplete() : true)) {
            return true;
        }
        return false;
    }

    @Override
    protected IAttributeModel createAttributeModel(String productName, String typeName, Type type, APIObjectAdapter base) {
        DimensionsIDEProjectDetails details = createStreamDetails();
        if (typeName.equals(IDMConstants.STREAM_TYPE_NAME)) {
            streamDetails = details;
        } else {
            objectDetails = details;
        }
        return new WorksetAttributeModel(details, type, getConnection());
    }

    protected DimensionsIDEProjectDetails createInstance(String product, String name, String description) {
        return new DimensionsIDEProjectDetails(product, name, description);
    }

    protected DimensionsIDEProjectDetails createStreamDetails() {
        NewStreamWelcomePage welcomePage = (NewStreamWelcomePage) getPage(SP_WELCOME_PAGE);
        if (null != welcomePage) {
            Boolean isStream = welcomePage.isStream();
            if (null != isStream) {
                this.isStream = isStream.booleanValue();
            }
        }
        if (getMode() == Mode.TOPIC_STREAM) {
            DimensionsIDEProjectDetails details = createInstance("", "", Messages.TopicStreamEmptyBasedOnDescription);
            updateTopicStreamDetails(details);
            return details;
        }
        NewStreamGeneralPage generalPage = (NewStreamGeneralPage) (isStream 
                ? getPage(STREAM_GENERAL_PAGE) : getPage(PROJECT_GENERAL_PAGE));
        if (null == generalPage) {
            return null;
        }
        DimensionsIDEProjectDetails newObject = createInstance(generalPage.getProductName(), generalPage.getStreamName(),
                generalPage.getStreamDescription());
        if (isStream) {
            streamDetails = newObject;
        } else {
            objectDetails = newObject;
        }
        refreshStreamDetails();

        return newObject;
    }

    private void updateTopicStreamDetails(DimensionsIDEProjectDetails details) {
        NewStreamTopicWorkareaPage topicWorkareaPage = (NewStreamTopicWorkareaPage) getPage(STREAM_TOPIC_WORKAREA_PAGE);
        
        details.setProductName(topicWorkareaPage.getProductName());
        details.setAttribute(SystemAttributes.OBJECT_ID, topicWorkareaPage.getStreamName());
        details.setTypeName(IDMConstants.STREAM_TYPE_NAME);
        details.setIsStream(true);
        details.setDefaultBranch(topicWorkareaPage.getStreamName());
        String basedOnSpec = topicWorkareaPage.getFullBasedOnStreamSpec();
        if (!Utils.isNullEmpty(basedOnSpec)) {
            details.setBasedOnProject(basedOnSpec);
            details.setAttribute(SystemAttributes.DESCRIPTION, NLS.bind(Messages.TopicStreamBasedOnDescription, basedOnSpec));
        }
        details.setTopicRequests(topicWorkareaPage.getRelatedRequests());
        details.setIsTopicStream(true);
        
        NewStreamTopicUsersPage usersPage = (NewStreamTopicUsersPage) getPage(STREAM_TOPIC_USERS_PAGE);
        List<String> assignedUsers = usersPage.getAssignedUsersAndGroups(); 
        if (assignedUsers.size() > 0) {
            details.setUsers(assignedUsers);
        }
    }

    protected void refreshStreamDetails() {
        
        DimensionsIDEProjectDetails details = isStream ? streamDetails : (DimensionsIDEProjectDetails) objectDetails;
        if (null == details) {
            return;
        }

        if (getMode() == Mode.TOPIC_STREAM) {
            updateTopicStreamDetails(details);
            return;
        }
        
        NewStreamGeneralPage generalPage = (NewStreamGeneralPage) (isStream
                ? getPage(STREAM_GENERAL_PAGE) : getPage(PROJECT_GENERAL_PAGE));
        details.setAttribute(SystemAttributes.PRODUCT_NAME, generalPage.getProductName());
        details.setAttribute(SystemAttributes.OBJECT_ID, generalPage.getStreamName());
        details.setAttribute(SystemAttributes.DESCRIPTION, generalPage.getStreamDescription());
        details.setTypeName(generalPage.getTypeName());
        details.setIsStream(isStream);

        details.setProject(generalPage.getProjectGroupName());
        if (isStream) {
            details.setDefaultBranch(generalPage.getStreamUniqueBranchName());
        }

        details.setBasedOnProject(getBasedOnStream());
        if (null == getBasedOnStream()) {
            details.setBasedOnBaseline(getBasedOnBaseLine());
        }

        NewStreamDetailsPage detailsPage = (NewStreamDetailsPage) (isStream
                ? getPage(STREAM_DETAILS_PAGE) : getPage(PROJECT_DETAILS_PAGE));
        if (null != detailsPage) {
            if (isStream) {
                // get stream specific options
                if (detailsPage.isCMRulesEnable()) {
                    details.setCMRulesFlag(ProjectDetails.PROJECT_CM_RULES_ON);
                    details.setRequestRequiredToRefactorFlag(true);
                } else {
                    details.setCMRulesFlag(ProjectDetails.PROJECT_CM_RULES_OFF);
                    details.setRequestRequiredToRefactorFlag(false);
                }
            }
        }

        if (!isStream) {
            // get non-stream specific options
            NewProjectOptionsPage optionsPage = (NewProjectOptionsPage) getPage(PROJECT_OPTIONS_PAGE);
            if (null != optionsPage) {
                if (null != optionsPage.getBranchFlag()) {
                    details.setBranchFlag(optionsPage.getBranchFlag().booleanValue());
                }
                if (null != optionsPage.getNewRevisionForcedFlag()) {
                    details.setNewRevisionForcedFlag(optionsPage.getNewRevisionForcedFlag().booleanValue());
                }
                if (0 != optionsPage.getCMRulesFlag()) {
                    details.setCMRulesFlag(optionsPage.getCMRulesFlag());
                }
                if (null != optionsPage.getRequestRequiredFlag()) {
                    details.setRequestRequiredToRefactorFlag(optionsPage.getRequestRequiredFlag().booleanValue());
                }
            }

            NewProjectBranchPage branchPage = (NewProjectBranchPage) getPage(PROJECT_BRANCHES_PAGE);
            if (null != branchPage && null != branchPage.getDefaultBranch() && null != branchPage.getBranches()) {
                List<String> branches = new ArrayList<String>();
                for (int i = 0; i < branchPage.getBranches().length; i++) {
                    branches.add(branchPage.getBranches()[i]);
                }
                details.setBranchList(branches);
                details.setDefaultBranch(branchPage.getDefaultBranch());
            }
        }
    }

    protected WorksetList getWorksetList(DimensionsIDEProjectDetails worksetDetails) {
        // no ide project - always in all worksets
        // not true now as containers have no project
        // TODO needs cleanup when using an ide project baseline it uses the query code

        APIObjectAdapter baseObject = getBaseOnObject();
        if (baseObject != null && baseObject instanceof SccProjectContainerWorkset) {
            return (WorksetList) baseObject.getObjectList();
        }
        if (baseObject != null && baseObject instanceof SccBaselineContainer) {
            SccBaselineContainerList clist = (SccBaselineContainerList) ((SccBaselineContainer) baseObject).getObjectList();
            if (clist == null) {
                return WorksetList.getOtherProjectsList(getConnection(), false, false);
            }
            SccProjectContainer pc = clist.getParentContainer();
            return pc.getProjectList();
        }
        if (!isFromContainer() && Utils.isNullEmpty(worksetDetails.getProject())) {
            return WorksetList.getOtherProjectsList(getConnection(), getConnection().isOnlyStreamsActive(),
                    getConnection().isOnlyProjectsActive());
        }
        // initial is an ide project node
        if (worksetDetails.isInitial()) {
            return WorksetList.getDimensionsIDEProjectsList(getConnection(), getConnection().isOnlyStreamsActive(),
                    getConnection().isOnlyProjectsActive());
        }
        if (!isFromContainer()) {
            // not initial and have ide project name - creating ide project member,
            DimensionsIDEProject ideProject = null;
            if (baseObject != null) {
                // can potentially be based on ide project itself which is the
                // initial workset at the same time
                if (baseObject instanceof DimensionsIDEProject) {
                    ideProject = (DimensionsIDEProject) getBaseOnObject();
                } else {
                    // based on a member workset, get project as parent
                    APIObjectAdapter parent = baseObject.getParentAdapter();
                    if (parent instanceof DimensionsIDEProject) {
                        ideProject = ((DimensionsIDEProject) parent);
                    } else {
                        // TODO VG on Feb 16, 2006: handle a case when base object
                        // is an ide object but its parent is not DimensionsIDEProject,
                        // this can happen if base object was selected from a group.
                        // As groups not yet working this is untested
                        try {
                            // reconstructing a project from ide info
                            final Session session = getConnection().openSession(null);
                            final DimensionsIDEProject[] holder = new DimensionsIDEProject[1];

                            session.run(new ISessionRunnable() {

                                @SuppressWarnings("unchecked")
                                @Override
                                public void run() throws Exception {
                                    DimensionsArObject arObject = getBaseOnObject().getAPIObject();

                                    // @formatter:off
                                    Utils.queryAttributes(
                                            Collections.singletonList(arObject),
                                            new int[] {SystemAttributes.IDE_DM_UID},
                                            session.getObjectFactory(), true);
                                    // @formatter:on

                                    Long uid = (Long) arObject.getAttribute(SystemAttributes.IDE_DM_UID);
                                    if (uid != null) {
                                        Filter wsf = new Filter();
                                        wsf.criteria().add(
                                                new Filter.Criterion(SystemAttributes.IDE_DM_UID, uid, Filter.Criterion.EQUALS));
                                        wsf.criteria().add(
                                                new Filter.Criterion(SystemAttributes.IDE_INITIAL, "Y", Filter.Criterion.EQUALS)); //$NON-NLS-1$
                                        List<Project> worksets = session.getObjectFactory().getProjects(wsf);
                                        if (!worksets.isEmpty()) {
                                            Project initialWorkset = worksets.get(0);
                                            holder[0] = new DimensionsIDEProject(initialWorkset, getConnection());
                                            holder[0].setIdeUid(uid.toString());
                                        }
                                    }
                                }

                            }, new NullProgressMonitor());

                            ideProject = holder[0];
                        } catch (DMException e) {
                            // show/log error and continue?
                            DMTeamUiPlugin.getDefault().handle(e);
                        }
                    }
                }
            }
            if (ideProject != null) {
                return ideProject.getProjectList();
            }
        } else {
            // the workset adapter is a container
            SccProjectContainer sccContainer = null;
            if (baseObject != null) {
                // can potentially be based on ide project itself which is the
                // initial workset at the same time
                if (baseObject instanceof SccProjectContainer) {
                    sccContainer = (SccProjectContainer) getBaseOnObject();
                } else {
                    // based on a member workset, get project as parent
                    APIObjectAdapter parent = baseObject.getParentAdapter();
                    if (parent instanceof DimensionsIDEProject) {
                        sccContainer = ((SccProjectContainer) parent);
                    } else {
                        // TODO VG on Feb 16, 2006: handle a case when base object
                        // is an ide object but its parent is not DimensionsIDEProject,
                        // this can happen if base object was selected from a group.
                        // As groups not yet working this is untested
                        try {
                            // reconstructing a project from ide info
                            final Session session = getConnection().openSession(null);
                            final SccProjectContainer[] holder = new SccProjectContainer[1];
                            session.run(new ISessionRunnable() {

                                @SuppressWarnings("unchecked")
                                @Override
                                public void run() throws Exception {
                                    DimensionsArObject arObject = getBaseOnObject().getAPIObject();

                                    // @formatter:off
                                    Utils.queryAttributes(
                                            Collections.singletonList(arObject),
                                            new int[] {SystemAttributes.IDE_DM_UID},
                                            session.getObjectFactory(), true);
                                    // @formatter:on

                                    Long uid = (Long) arObject.getAttribute(SystemAttributes.IDE_DM_UID);
                                    if (uid != null) {
                                        Filter wsf = new Filter();
                                        wsf.criteria().add(
                                                new Filter.Criterion(SystemAttributes.IDE_DM_UID, uid, Filter.Criterion.EQUALS));
                                        wsf.criteria().add(
                                                new Filter.Criterion(SystemAttributes.IDE_INITIAL, "Y", Filter.Criterion.EQUALS)); //$NON-NLS-1$
                                        List<Project> worksets = session.getObjectFactory().getProjects(wsf);
                                        if (!worksets.isEmpty()) {
                                            Project initialWorkset = worksets.get(0);
                                            holder[0] = new SccProjectContainer(initialWorkset, getConnection());
                                            holder[0].setIdeUid(uid.toString());
                                        }
                                    }
                                }

                            }, new NullProgressMonitor());
                            sccContainer = holder[0];
                        } catch (DMException e) {
                            // show/log error and continue?
                            DMTeamUiPlugin.getDefault().handle(e);
                        }
                    }
                }
            }
            if (sccContainer != null) {
                return sccContainer.getProjectList();
            }
        }
        // catch all - shouldn't happen, but return all so we don't crash
        return WorksetList.getOtherProjectsList(getConnection(), getConnection().isOnlyStreamsActive(),
                getConnection().isOnlyProjectsActive());
    }

    @Override
    protected APIObjectAdapter performCreate(IProgressMonitor monitor) throws CoreException {
        DimensionsIDEProjectDetails details = isStream ? streamDetails : (DimensionsIDEProjectDetails) objectDetails;
        NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE);
        if (null == details || !details.getProductName().equals(gp.getProductName())
                || !details.getTypeName().equals(gp.getTypeName())) {
            details = createStreamDetails();
        } else {
            refreshStreamDetails();
            // save unsaved attributes from attribute pages
            AttributesWizardPage attrPage = (AttributesWizardPage) getPage(isStream ? STREAM_ATTR_PAGE : PROJECT_ATTR_PAGE);
            if (null != attrPage && null != attrPage.getAttributeModel()) {
                attrPage.getAttributeModel().save(null);
            }
        }

        if (isStream == false) {
            // Set deployment model
            int wsManualPromotion = 0x080;
            int typeOption = getOptionsFromType();
            if ((typeOption & wsManualPromotion) == wsManualPromotion) {
                details.setManualDeploymentFlag(true);
            } else {
                details.setManualDeploymentFlag(false);
            }
        }

        final DimensionsIDEProjectDetails det = details;
        WorksetList prjList = getWorksetList(det);
        if (prjList == null) {
            prjList = WorksetList.getOtherProjectsList(getConnection(), false, false);
        }
        prjList.createObject(det, monitor);
        final String createdSpec = det.getProductName() + ':' + det.getName();
        // not finding newly created object

        APIObjectAdapter[] worksets = prjList.getObjects();
        for (int i = 0; i < worksets.length; i++) {
            WorksetAdapter worksetAdapter = (WorksetAdapter) worksets[i];
            if (worksetAdapter.getObjectSpec().equalsIgnoreCase(createdSpec)) {
                createdAdapter = worksetAdapter;
                break;
            }
        }

        // may not find in all projects list
        // try the ide projects lists - have to try all as don't have the ide project
        if (createdAdapter == null) {
            WorksetList prjList2 = WorksetList.getDimensionsIDEProjectsList(getConnection(), false, false);
            prjList2.fetch(monitor);
            APIObjectAdapter[] ideWorksets = prjList2.getObjects();
            for (int i = 0; i < ideWorksets.length; i++) {
                DimensionsIDEProject projectAdapter = (DimensionsIDEProject) ideWorksets[i];
                WorksetList prjList3 = WorksetList.getDimensionsIDEProjectWorksetList(getConnection(), projectAdapter);
                prjList3.fetch(monitor);
                APIObjectAdapter[] ideMemberWorksets = prjList3.getObjects();
                for (int j = 0; j < ideMemberWorksets.length; j++) {
                    WorksetAdapter worksetAdapter = (WorksetAdapter) ideMemberWorksets[j];
                    if (worksetAdapter.getObjectSpec().equalsIgnoreCase(createdSpec)) {
                        createdAdapter = worksetAdapter;
                        break;
                    }
                }
                if (createdAdapter != null) {
                    break;
                }

            }
        }

        if (createdAdapter == null) {

            final Session session = getConnection().openSession(monitor);
            final Unit<Project> dto = new Unit<Project>();

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    Project project = session.getObjectFactory().getProject(createdSpec);
                    Assert.isLegal(project != null);
                    project.queryAttribute(WorksetList.DEFAULT_ATTRIBUTES);
                    dto.setValue(project);
                }
            }, monitor);
            createdAdapter = new WorksetAdapter(dto.getValue(), getConnection());
        }

        if (isAdd2FavoriteList()) {
            if (createdAdapter instanceof IFavouriteObject) {
                List<IFavouriteObject> adding = Collections.singletonList((IFavouriteObject) createdAdapter);
                DimensionsConnectionDetailsEx conn = adding.get(0).getConnectionDetails();
                FavouriteProjectsList list = WorksetList.getFavouriteProjectsList(conn, conn.isOnlyStreamsActive(),
                        conn.isOnlyProjectsActive());
                list.addFavourites(adding, monitor);
            }
        }

        Object page = getPage(STREAM_TOPIC_WORKAREA_PAGE);
        if (page instanceof NewStreamTopicWorkareaPage) {
            NewStreamTopicWorkareaPage topicPage = (NewStreamTopicWorkareaPage) page;
            if (topicPage.getPostCreationMode() == PostCreationMode.REHOME
            		&& topicPage.getWorkAreaToRehome() != null) {

            	IProgressMonitor rehomeMonitor = Utils.monitorFor(monitor); 
                try {
                    rehomeMonitor.beginTask("Rehoming...", IProgressMonitor.UNKNOWN);//$NON-NLS-1$
                    RehomeCommand command = new RehomeCommand(topicPage.getProjectsToRehome(), createdAdapter);
                    command.run(rehomeMonitor);
                } finally {
                    rehomeMonitor.setTaskName(Utils.EMPTY_STRING);
                    rehomeMonitor.subTask(Utils.EMPTY_STRING);
                    rehomeMonitor.done();
                }
            }
        }
        assert createdAdapter != null;
        return createdAdapter;
    }

    public String getProductName() {
        if (getMode() == Mode.TOPIC_STREAM) {
            NewStreamTopicWorkareaPage page = (NewStreamTopicWorkareaPage) getPage(NewStreamWizard.STREAM_TOPIC_WORKAREA_PAGE);
            return page.getProductName(); 
        }
        if (getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE) instanceof NewStreamGeneralPage) {
            NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE);
            return gp.getProductName();
        }
        return null;
    }

    public String getProjectTypeName() {
        if (getMode() == Mode.TOPIC_STREAM) {
            return IDMConstants.STREAM_TYPE_NAME;
        }
        if (getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE) instanceof NewStreamGeneralPage) {
            NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(isStream ? STREAM_GENERAL_PAGE : PROJECT_GENERAL_PAGE);
            if (gp != null) {
                return gp.getTypeName();
            }
        }
        return null;
    }

    public String getBasedOnStream() {
        if (getMode() == Mode.TOPIC_STREAM) {
            NewStreamTopicWorkareaPage page = (NewStreamTopicWorkareaPage) getPage(NewStreamWizard.STREAM_TOPIC_WORKAREA_PAGE);
            return page.getFullBasedOnStreamSpec(); 
        }
        
        if (getPage(isStream ? STREAM_DETAILS_PAGE : PROJECT_DETAILS_PAGE) instanceof NewStreamDetailsPage) {
            NewStreamDetailsPage dp = (NewStreamDetailsPage) getPage(isStream ? STREAM_DETAILS_PAGE : PROJECT_DETAILS_PAGE);
            if (null != dp.getBasedOnStreamVersion() && null != getProductName()) {
                return dp.getBasedOnStreamVersion();
            }
        }
        if (null != getBaseOnObject() && getBaseOnObject() instanceof WorksetAdapter) {
            return getBaseOnObject().getAPIObject().getName();
        }
        return null;
    }

    public String getBasedOnBaseLine() {
        if (getPage(isStream ? STREAM_DETAILS_PAGE : PROJECT_DETAILS_PAGE) instanceof NewStreamDetailsPage) {
            NewStreamDetailsPage dp = (NewStreamDetailsPage) getPage(isStream ? STREAM_DETAILS_PAGE : PROJECT_DETAILS_PAGE);
            if (null != dp.getBasedOnBaseline() && null != getProductName()) {
                return dp.getBasedOnBaseline();
            }
        }
        if (null != getBaseOnObject() && getBaseOnObject() instanceof BaselineAdapter) {
            return getBaseOnObject().getAPIObject().getName();
        }
        return null;
    }

    private void getDBOptionsFromDM() {
        try {
            int dbOpt = getConnection().openSession(null)
                    .getObjectFactory()
                    .getBaseDatabaseAdmin()
                    .getDatabaseOptions()
                    .getProjectStreamOptions(true);
            streamsAllowed = DimensionsDatabaseOptions.DBOPTIONS_PROJECTSONLY != dbOpt;
            projectsAllowed = DimensionsDatabaseOptions.DBOPTIONS_STREAMSONLY != dbOpt;
            connForDBOptions = getConnection();
        } catch (Exception e) {
            DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
        }
    }

    /*
     * Gets Database Options settings for Streams
     * @return true if Streams are allowed
     */
    protected boolean areStreamsAllowed() {
        if (null == getConnection() || getConnection().equals(connForDBOptions)) {
            return streamsAllowed; // default
        }

        getDBOptionsFromDM();
        return streamsAllowed;
    }

    /*
     * Gets Database Options settings for Projects
     * @return true if Projects are allowed
     */
    protected boolean areProjectsAllowed() {
        if (null == getConnection() || getConnection().equals(connForDBOptions)) {
            return projectsAllowed; // default
        }

        getDBOptionsFromDM();
        return projectsAllowed;
    }

    /*
     * Get options from type of a project/workset
     */
    public int getOptionsFromType() {
        return typeOption;
    }

    /*
     * Set options from type of a project/workset
     */
    public void setOptionsFromType(int options) {
        typeOption = options;

        if (isStream) {
            NewStreamDetailsPage pageDetails = (NewStreamDetailsPage) getPage(STREAM_DETAILS_PAGE);
            if (pageDetails != null) {
                pageDetails.loadDetailsFromType();
            }
        } else {
            NewProjectOptionsPage pageOptions = (NewProjectOptionsPage) getPage(PROJECT_OPTIONS_PAGE);
            if (pageOptions != null) {
                pageOptions.loadOptionsFromType();
            }
        }
    }

    protected boolean isFromContainer() {
        return false;
    }

    public boolean isAdd2FavoriteList() {
        if (isStream) {
            if (getPage(STREAM_GENERAL_PAGE) instanceof NewStreamGeneralPage) {
                NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(STREAM_GENERAL_PAGE);
                return gp.isAdd2FavoriteList();
            }
        } else {
            if (getPage(PROJECT_GENERAL_PAGE) instanceof NewStreamGeneralPage) {
                NewStreamGeneralPage gp = (NewStreamGeneralPage) getPage(PROJECT_GENERAL_PAGE);
                return gp.isAdd2FavoriteList();
            }
        }

        return false;
    }

    public boolean isBasedOnRequest() {
        APIObjectAdapter basedOn = getBaseOnObject();
        if (basedOn instanceof ChangeDocumentAdapter)
            return true;

        return getBaseOnSbmRequest() != null;
    }

    public boolean isBasedOnBaseline() {
    	return this.getBaseOnObject() instanceof BaselineAdapter;
    }

    public ProjectMapping[] getMappings(WorksetAdapter adapter, IProgressMonitor monitor) {

        MappingsDataTransfer data = new MappingsDataTransfer();
        try {
            monitor.beginTask("Preparing mappings...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
            APIObjectAdapter[] remoteObjects = { new SccProjectContainerWorkset(adapter) };
            data.prepare(remoteObjects, null, monitor);
        } catch (InvocationTargetException e) {
            DMUIPlugin.getDefault().handle(e);
        } catch (InterruptedException e) {
            DMUIPlugin.getDefault().handle(e);
        } finally {
            monitor.setTaskName(Utils.EMPTY_STRING);
            monitor.subTask(Utils.EMPTY_STRING);
            monitor.done();
        }
        return data.getMappings();
    }

    public NewStreamTopicWorkareaPage getTopicPage() {
        Object page = getPage(STREAM_TOPIC_WORKAREA_PAGE);
        return (NewStreamTopicWorkareaPage) page;
    }

    public boolean runLateValidation() {
        if (getMode() == Mode.TOPIC_STREAM) {
            NewStreamTopicWorkareaPage page = (NewStreamTopicWorkareaPage) getPage(NewStreamWizard.STREAM_TOPIC_WORKAREA_PAGE);
            if (page.needsAdditionalValidation()) {
                return page.doAdditionalValidation();
            }
        }
        return true;
    }
}

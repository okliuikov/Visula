/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.ITeamStatus;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.objects.ItemType;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.SccProjectList;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DeleteItemRevisionRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.ImportRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Branches project from workspace.
 * @author V.Grishchenko
 */
public class ProjectBranchWizard extends NewStreamWizard {
    private static final String GENERAL_BRANCH_PAGE = "pbr_general_page"; //$NON-NLS-1$

    private IDMProject project;
    private IDMProject newProject;
    private boolean createBaseline;
    private boolean changeSharing;
    private ProjectBranchWizardGeneralPage generalPage;

    public ProjectBranchWizard(IDMProject project, APIObjectAdapter basedOn) {
        super(project.getConnection(), basedOn, true);
        setWindowTitle(Messages.ProjectBranchWizard_0);
        this.project = project;
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page, boolean aboutToShow) {
        if (aboutToShow) {
            if (page == generalPage) {
                createBaseline = generalPage.getCreateBaseline();
                changeSharing = generalPage.getNewSharing();
            }
        }
        return super.getNextPage(page, aboutToShow);
    }

    public boolean getCreateBaseline() {
        return createBaseline;
    }

    @Override
    protected IWizardPage[] createPages() {
        ArrayList<IWizardPage> myPages = new ArrayList<IWizardPage>();
        // always allow baseline as local revisions can be arbitrary even when shared with baseline
        generalPage = new ProjectBranchWizardGeneralPage(GENERAL_BRANCH_PAGE, Messages.ProjectBranchWizard_1,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), Messages.ProjectBranchWizard_2,
                ProjectBranchWizardGeneralPage.ALLOW_BASELINE | ProjectBranchWizardGeneralPage.LOCAL);
        generalPage.setProjectName(project.getId());
        myPages.add(generalPage);
        // check the type of the project we branching from to dismiss welcome page
        try {
            String typeName = project.getDimensionsObject().getType().getName();
            if (null != typeName) {
                dontShowWelcomePage = true;
                isStream = typeName.equals(IDMConstants.STREAM_TYPE_NAME);
            }
        } catch (DMException e) {
        }
        IWizardPage[] superPages = super.createPages();
        myPages.addAll(Arrays.asList(superPages));

        return myPages.toArray(new IWizardPage[myPages.size()]);
    }

    @Override
    public APIObjectAdapter performCreate(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        int changeSharingWork = changeSharing ? 600 : 0;
        monitor.beginTask(Messages.ProjectBranchWizard_3, 1000 + changeSharingWork);
        try {
            // create workset
            final APIObjectAdapter createdObject = super.performCreate(Utils.subMonitorFor(monitor, 250));
            newProject = DMRepositoryProvider.createProject(getCreatedObjectAdapter(), project.getProject(), null);
            // make sure we are on the last page
            final IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
            // TODO VG on Apr 1, 2006: refresh against the actual project
            // created, for now assume it is the same as workspace remote
            final Subscriber subscriber = workspace.getSubscriber(/* newProject */);
            subscriber.refresh(new IResource[] { project.getProject() }, IResource.DEPTH_INFINITE,
                    Utils.subMonitorFor(monitor, 250));

            // if we sync against the newly created project there should be no
            // incoming changes or conflicts, find incoming and conflicting
            // changes and update the created project accordingly
            final ArrayList<IDMWorkspaceFile> toRemove = new ArrayList<IDMWorkspaceFile>();
            final ArrayList<IDMWorkspaceFile> toExport = new ArrayList<IDMWorkspaceFile>();

            // TODO VG on Apr 1, 2006: what do we do with folders?
            project.getProject().accept(new IResourceVisitor() {
                @Override
                public boolean visit(IResource resource) throws CoreException {
                    if (resource.getType() != IResource.FILE) {
                        return true;
                    }
                    IDMWorkspaceFile dmFile = (IDMWorkspaceFile) workspace.getWorkspaceResource(resource);
                    SyncInfo syncInfo = subscriber.getSyncInfo(resource);
                    if (syncInfo != null) {
                        int kind = syncInfo.getKind();
                        switch (kind & SyncInfo.DIRECTION_MASK) {
                        case SyncInfo.CONFLICTING:
                        case SyncInfo.INCOMING:
                            switch (kind & SyncInfo.CHANGE_MASK) {
                            case SyncInfo.ADDITION:
                                toRemove.add(dmFile);
                                break;
                            case SyncInfo.DELETION:
                                toExport.add(dmFile);
                                break;
                            case SyncInfo.CHANGE:
                                toRemove.add(dmFile);
                                toExport.add(dmFile);
                                break;
                            }
                            break;
                        }
                    }
                    return true;
                }
            }, IResource.DEPTH_INFINITE, true);

            ArrayList<ITeamStatus> unavailable = new ArrayList<ITeamStatus>();
            if (!toRemove.isEmpty() || !toExport.isEmpty()) {
                IProgressMonitor updateMon = Utils.subMonitorFor(monitor, 500);
                updateMon.beginTask(null, (toRemove.size() + toExport.size()) * 100);

                if (!toRemove.isEmpty()) {
                    DeleteItemRevisionRequest[] deleteRequests = new DeleteItemRevisionRequest[toRemove.size()];
                    for (int i = 0; i < toRemove.size(); i++) {
                        IDMWorkspaceFile dmFile = toRemove.get(i);
                        ItemRevision rev = dmFile.getRemoteFile().getItemRevision();
                        ItemType itemType = (ItemType) getConnection().getType(rev, null);
                        deleteRequests[i] = new DeleteItemRevisionRequest(dmFile.getLocalFile(), itemType, rev, false);
                        deleteRequests[i].setUnmanage(false);
                    }
                    newProject.delete(deleteRequests, Utils.subMonitorFor(updateMon, toRemove.size() * 100));
                }

                if (!toExport.isEmpty()) {
                    ImportRequest[] importRequests = new ImportRequest[toExport.size()];
                    for (int i = 0; i < toExport.size(); i++) {
                        IDMWorkspaceFile dmFile = toExport.get(i);
                        importRequests[i] = new ImportRequest(dmFile.getLocalFile(), dmFile.getBaseFile().getItemRevision());
                    }
                    IStatus status = newProject.importFiles(importRequests, Utils.subMonitorFor(updateMon, toExport.size() * 100));
                    if (!status.isOK()) {
                        if (status instanceof ITeamStatus) {
                            unavailable.add((ITeamStatus) status);
                        } else {
                            IStatus[] children = status.getChildren();
                            for (int i = 0; i < children.length; i++) {
                                if (children[i] instanceof ITeamStatus) {
                                    unavailable.add((ITeamStatus) children[i]);
                                }
                            }
                        }
                        warnAboutDeletedRevisions(status);
                    }
                }
            }
            if (changeSharing) {
                assert newProject != null;
                IProject localProject = project.getProject();
                APIObjectAdapter remoteObject = getCreatedObjectAdapter();
                if (project.isSccStyle() && remoteObject instanceof SccProjectContainerWorkset) {
                    // resolve marker file
                    SccProjectList projectList = ((SccProjectContainerWorkset) remoteObject).getMemberList();
                    projectList.fetch(Utils.subMonitorFor(monitor, 200));
                    changeSharingWork -= 200;
                    SccProject sccProject = projectList.findProject(project.getRemoteOffset());
                    if (sccProject != null) {
                        remoteObject = sccProject;
                    } else {
                        String msg = NLS.bind(Messages.ProjectBranchWizard_6, project.getRemoteOffset().toString(),
                                remoteObject.getObjectSpec());
                        Status error = new Status(IStatus.ERROR, DMTeamUiPlugin.ID, 0, msg, null);
                        throw new CoreException(error);
                    }
                }

                workspace.manage(localProject.getProject(), null, remoteObject);
                workspace.getSubscriber().refresh(new IResource[] { localProject }, IResource.DEPTH_INFINITE,
                        Utils.subMonitorFor(monitor, changeSharingWork));
                // finally transform any resources deleted in repo into outgoing additions,
                // conflicting deletions with missing revisions in global are lost forever, amen.
                for (Iterator<ITeamStatus> iter = unavailable.iterator(); iter.hasNext();) {
                    ITeamStatus teamStatus = iter.next();
                    workspace.unmanage(teamStatus.getResource(), null);
                }
            }
            return createdObject;
        } finally {
            monitor.done();
        }
    }

    private void warnAboutDeletedRevisions(final IStatus status) {
        getShell().getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                ErrorDialog.openError(getShell(), Messages.ProjectBranchWizard_4, Messages.ProjectBranchWizard_5, status);
            }
        });
    }

    protected int getOptions() {
        return 0;
    }

    @Override
    protected boolean isFromContainer() {
        return project.isSccStyle();
    }
}

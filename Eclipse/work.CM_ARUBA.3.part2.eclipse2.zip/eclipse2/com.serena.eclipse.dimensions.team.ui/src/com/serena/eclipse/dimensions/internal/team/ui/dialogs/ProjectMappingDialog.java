/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectMappingPanel;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectMappingValidator;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.controls.MessageLine;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;

/**
 * @author V.Grishchenko
 */
public class ProjectMappingDialog extends ResizableDialog {
    private ProjectMapping[] mappings;
    private MessageLine messageLine;
    private ProjectMappingPanel panel;
    private ProjectMappingValidator validator;

    public ProjectMappingDialog(Shell parent, ProjectMapping[] mappings) {
        super(parent);
        this.mappings = mappings == null ? new ProjectMapping[0] : mappings;
    }

    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        newShell.setText(Messages.prjMapDialog_title);
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite) super.createDialogArea(parent);
        panel = new ProjectMappingPanel(composite, SWT.NONE, mappings, Messages.prjMapDialog_message);
        UIUtils.setGridData(panel.getPanel(), GridData.FILL_BOTH);
        messageLine = new MessageLine(composite);
        UIUtils.setGridData(messageLine, GridData.FILL_HORIZONTAL);
        return composite;
    }

    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        super.createButtonsForButtonBar(parent);
        validator = new ProjectMappingValidator(mappings, true) {
            @Override
            protected void setErrorMessage(String message) {
                messageLine.setErrorMessage(message);
                setOkEnabled(message == null);
            }
        };
        panel.setListener(validator);
    }

    private void setOkEnabled(boolean enable) {
        getButton(IDialogConstants.OK_ID).setEnabled(enable);
    }

}

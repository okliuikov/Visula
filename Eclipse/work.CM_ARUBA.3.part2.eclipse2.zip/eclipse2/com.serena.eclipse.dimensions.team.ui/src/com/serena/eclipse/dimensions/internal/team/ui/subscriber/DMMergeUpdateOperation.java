/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.core.variants.IResourceVariant;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UpdateWorkspaceOperation;

/**
 * @author V.Grishchenko
 */
public class DMMergeUpdateOperation extends DMSafeUpdateOperation {

    public DMMergeUpdateOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements, boolean promptBeforeUpdate) {
        super(configuration, elements, promptBeforeUpdate);
    }

    @Override
    protected boolean shouldValidateEdit() {
        return true;
    }

    @Override
    protected boolean getOverwriteLocalChanges() {
        return true;
    }

    @Override
    protected void overwriteUpdate(SyncInfoSet syncSet, IProgressMonitor monitor) throws CoreException {
        SyncInfo[] nodes = syncSet.getSyncInfos();
        HashSet<IResource> notUpdated = new HashSet<IResource>(Arrays.asList(syncSet.getResources()));
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, nodes.length * 100);
        try {
            for (int i = 0; i < nodes.length; i++) {
                IResource local = nodes[i].getLocal();
                IResourceVariant remote = nodes[i].getRemote();
                if (remote == null) {
                    if (local.exists()) {
                        local.delete(IResource.KEEP_HISTORY, Utils.subMonitorFor(monitor, 100));
                    }
                } else {
                    if (remote.isContainer()) {
                        TeamUtils.ensureContainerExists((IContainer) nodes[i].getLocal());
                    } else {
                        update(nodes[i], Utils.subMonitorFor(monitor, 100));
                    }
                }
                notUpdated.remove(nodes[i].getLocal());
            }
        } finally {
            // remove files that failed to update
            if (!notUpdated.isEmpty()) {
                syncSet.removeAll(notUpdated.toArray(new IResource[notUpdated.size()]));
            }
            monitor.done();
        }
    }

    @Override
    protected void runUpdateDeletions(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, 100 * nodes.length);
        // When merging, update deletions become outgoing deletions so just delete
        // the files locally without unmanaging (so the metadata is kept to indicate outgoing deletions)
        try {
            for (int i = 0; i < nodes.length; i++) {
                IResource resource = nodes[i].getLocal();
                if (resource.getType() == IResource.FILE) {
                    TeamUtils.deleteResource(resource, Utils.subMonitorFor(monitor, 100));
                }
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    protected void runSafeUpdate(SyncInfo[] nodes, IProgressMonitor monitor) throws CoreException {
        safeUpdate(new MergeWorkspaceUpdateOperation(getPart(), nodes), monitor);
    }

    @Override
    protected void updated(SyncInfo[] resources, IProgressMonitor monitor) throws CoreException {
        if (resources.length == 0) {
            if (monitor != null) {
                monitor.done();
            }
            return;
        }
        ArrayList<IResource> locals = new ArrayList<IResource>();
        ArrayList<IResourceVariant> remotes = new ArrayList<IResourceVariant>();
        for (int i = 0; i < resources.length; i++) {
            locals.add(resources[i].getLocal());
            remotes.add(resources[i].getRemote());
        }
        getSubscriber().merged(locals.toArray(new IResource[locals.size()]),
                remotes.toArray(new IDMRemoteResource[remotes.size()]), monitor);
    }

    @Override
    protected void ensureParentsExist(SyncInfo[] nodes, IProgressMonitor monitor, boolean ensureReacheable)
            throws CoreException {
        super.ensureParentsExist(nodes, monitor, false); // never create metadata during merge update
    }

    private void update(SyncInfo syncInfo, IProgressMonitor parentMonitor) throws CoreException {
        TeamUtils.copy((IDMRemoteFile) syncInfo.getRemote(), (IFile) syncInfo.getLocal(), parentMonitor);
    }

    // contacts file modification validator to validate edit and copies
    // contents to avoid metadata generation in the workspace - can probably
    // invoke item revision getCopy directly when can specify /NOMETADATA
    private class MergeWorkspaceUpdateOperation extends UpdateWorkspaceOperation {
        private SyncInfoSet syncInfoSet;

        public MergeWorkspaceUpdateOperation(IWorkbenchPart part, SyncInfo[] nodes) {
            super(part, getLocalResources(nodes));
            this.syncInfoSet = new SyncInfoSet(nodes);
            setWarnAboutFailures(false); // turn warning off, if any conflicts DMSafeUpdateOperation will confirm if to overwrite
        }

        @Override
        protected void execute(DMRepositoryProvider provider, IResource[] resources, IProgressMonitor monitor)
                throws CoreException, InterruptedException {
            monitor = Utils.monitorFor(monitor);
            try {
                monitor.beginTask(null, 100 * resources.length);
                for (int i = 0; i < resources.length; i++) {
                    boolean updated = false;
                    SyncInfo syncInfo = syncInfoSet.getSyncInfo(resources[i]);
                    if (isUpdatable(syncInfo)) {
                        IDMRemoteResource remote = (IDMRemoteResource) syncInfo.getRemote();
                        if (remote != null) {
                            update(syncInfo, Utils.subMonitorFor(monitor, 100));
                            updated = true;
                        }
                    } else {
                        addSkippedFile((IFile) resources[i]);
                    }

                    if (!updated) {
                        monitor.worked(100);
                    }
                }
            } finally {
                monitor.done();
            }
        }
    }

}

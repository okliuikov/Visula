/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.actions;

import org.eclipse.jface.action.IAction;

import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;

/**
 * @author bstephenson
 *
 */
public class SetAsActiveRequestAction extends DimensionsAction {

    public SetAsActiveRequestAction() {
        super();
    }

    /**
     * @param usesDeclarativeEnablement
     */
    public SetAsActiveRequestAction(boolean usesDeclarativeEnablement) {
        super(usesDeclarativeEnablement);
    }

    @Override
    protected boolean isEnabledForSelection() {
        if (getSelection().size() != 1) {
            return false;
        }
        return true;
    }

    @Override
    public void run(IAction action) {
        ChangeDocumentAdapter cd = (ChangeDocumentAdapter) getSelection().getFirstElement();
        cd.getConnectionDetails().setSessionProperty(IDMConstants.ACTIVE_REQUEST, cd.getObjectSpec());
    }

    @Override
    protected void setActionEnablement(IAction action) {
        super.setActionEnablement(action);
    }
}

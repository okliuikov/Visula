package com.serena.eclipse.dimensions.internal.team.ui.actions;

import com.serena.dmclient.objects.PeerReview;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.ui.actions.OpenPullRequestAction;

public class NewPullRequestAction extends OpenPullRequestAction {

    @Override
    protected PeerReview getPullRequest(DimensionsConnectionDetailsEx connectionDetails, String projectSpec) {
        return null;
    }
}

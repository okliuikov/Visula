/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.views;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.PropertyPage;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class FolderPropertyPage extends PropertyPage {

    public FolderPropertyPage() {
    }

    @Override
    protected Control createContents(Composite parent) {
        noDefaultAndApplyButton();
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 2);

        IFolder theFolder = getFolder();
        if (theFolder == null) {
            return composite;
        }

        try {
            if (DMTeamPlugin.getWorkspace().isIgnored(theFolder)) {
                Label ignoredLbl = UIUtils.createLabel(composite, Messages.FolderPropertyPage_ignored);
                UIUtils.setGridData(ignoredLbl, GridData.FILL_HORIZONTAL, 2);
            }
            if (!DMTeamPlugin.getWorkspace().isManaged(theFolder)) {
                Label unmanagedLbl = UIUtils.createLabel(composite, Messages.FolderPropertyPage_unmanaged);
                UIUtils.setGridData(unmanagedLbl, GridData.FILL_HORIZONTAL, 2);
            } else {

                IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(theFolder);
                if (dmProject != null) {
                    IPath remotePath = dmProject.getRemotePathForLocalResource(theFolder);
                    UIUtils.createLabel(composite, Messages.FolderPropertyPage_repoPath);
                    Text pathTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, remotePath.toString());
                    UIUtils.setGridData(pathTxt, GridData.FILL_HORIZONTAL);
                }
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }

        return composite;
    }

    private IFolder getFolder() {
        IAdaptable adaptableElement = getElement();
        if (adaptableElement instanceof IFolder) {
            return (IFolder) adaptableElement;
        }
        return (IFolder) adaptableElement.getAdapter(IFolder.class);
    }

}

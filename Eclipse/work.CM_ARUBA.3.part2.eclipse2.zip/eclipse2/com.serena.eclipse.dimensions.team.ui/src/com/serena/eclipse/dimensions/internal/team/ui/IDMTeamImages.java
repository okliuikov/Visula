/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

/**
 * Team image id's.
 *
 * @author V.Grishchenko
 */
public interface IDMTeamImages {
    String ICON_PATH = "icons/full/"; //$NON-NLS-1$

    String DIMENSIONS = "obj16/dimensions_node.gif"; //$NON-NLS-1$

    // overlay icons
    /** under control - hase base info */
    String OVR_MANAGED = "ovr/controlled_glyph.gif"; //$NON-NLS-1$
    /** locally checked out */
    String OVR_EXTRACTED = "ovr/ckd_out_glyph.gif"; //$NON-NLS-1$
    // TODO VG on Mar 20, 2006: the file name is messed up from frydesign - keeping as supplied
    /** checked out in repo */
    String OVR_EXTRACTED_OTHER = "ovr/chkd_out_mul_locl_glyph.gif"; //$NON-NLS-1$
    // TODO VG on Mar 20, 2006: the file name is messed up from frydesign - keeping as supplied
    /** multiple checked out, including locally */
    String OVR_EXTRACTED_MULTIPLE = "ovr/ckd_out_other_glyph.gif"; //$NON-NLS-1$
    /** multiple checked out, but not locally */
    String OVR_EXTRACTED_MULTIPLE_OTHER = "ovr/ckd_out_mul_othr_glyph.gif"; //$NON-NLS-1$
    /** locked exclusively */
    String OVR_LOCKED = "ovr/exclusive_overlay_glyph.gif"; //$NON-NLS-1$
    // TODO VG on Mar 20, 2006: is is not "local edit", it is local mode!
    /** not checked out and writeable, i.e. in local mode */
    String OVR_LOCAL = "ovr/local_edit_glyph.gif"; //$NON-NLS-1$
    /** has local and remote changes */
    String OVR_CONFLICT = "ovr/conflict.gif"; //$NON-NLS-1$
    /** has local changes only */
    String OVR_DIRTY = "ovr/modifed_glyph.gif"; //$NON-NLS-1$
    /** has remote changes only */
    String OVR_STALE = "ovr/out_of_date.gif"; //$NON-NLS-1$
    /** has base information but no remote */
    String OVR_DELETED_REMOTE = "ovr/remote_deleted.gif"; //$NON-NLS-1$
    /** has base information but no local */
    String OVR_DELETED_LOCAL = "ovr/local_deleted.gif"; //$NON-NLS-1$
    /** indicates repo project has a .project file */
    String OVR_ECLIPSE_PROJECT = "ovr/eclipse_marker.gif"; //$NON-NLS-1$
    /** locked by current user */
    String OVR_LOCKED_OWN = "ovr/own_locked.gif"; //$NON-NLS-1$
    /** locked by different user, resource is read-only in lfs */
    String OVR_LOCKED_FOREIGN = "ovr/foreign_locked.gif"; //$NON-NLS-1$
    /** container has locked item(s) */
    String OVR_LOCKED_IN_CONTAINER = "ovr/container_locked.gif"; //$NON-NLS-1$

    /** workspace update */
    String CHECKOUT_ACTION = "elcl16/checkout_action.gif"; //$NON-NLS-1$
    /** workspace update dis */
    String CHECKOUT_ACTION_D = "dlcl16/checkout_action.gif"; //$NON-NLS-1$
    /** commit */
    String CHECKIN_ACTION = "elcl16/checkin_action.gif"; //$NON-NLS-1$
    String DELIVER_ACTION = "elcl16/stream-deliver.png"; //$NON-NLS-1$
    String SHELVE_ACTION = "elcl16/stream-shelve.png"; //$NON-NLS-1$
    /** commit dis */
    String CHECKIN_ACTION_D = "dlcl16/checkin_action.gif"; //$NON-NLS-1$

    String MERGESTREAM_SCHEMA = "misc/merge-stream.png"; //$NON-NLS-1$
    String MERGEREQUEST_SCHEMA = "misc/merge-request.png"; //$NON-NLS-1$
    String MERGEBASELINE_SCHEMA = "misc/merge-baseline.png"; //$NON-NLS-1$
    String USER = "misc/user.png"; //$NON-NLS-1$
    String GROUP = "misc/group.png"; //$NON-NLS-1$

    String STREAMUPDATE_ACTION = "elcl16/stream-update.png"; //$NON-NLS-1$

}

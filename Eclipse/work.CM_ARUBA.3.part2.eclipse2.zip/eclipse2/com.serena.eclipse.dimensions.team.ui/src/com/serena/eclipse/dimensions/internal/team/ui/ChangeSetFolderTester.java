package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;

import com.serena.dmclient.api.DimensionsChangeStep;

public class ChangeSetFolderTester extends PropertyTester {

    public ChangeSetFolderTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (!(receiver instanceof StructuredSelection)) {
            return false;
        }
        StructuredSelection ss = (StructuredSelection) receiver;
        Object selected = ss.getFirstElement();
        if (!(selected instanceof DimensionsChangeStep)) {
            return false;
        }
        DimensionsChangeStep changeStep = (DimensionsChangeStep) selected;
        return changeStep.getObjUid() == -1L; // it's not an item
    }

}

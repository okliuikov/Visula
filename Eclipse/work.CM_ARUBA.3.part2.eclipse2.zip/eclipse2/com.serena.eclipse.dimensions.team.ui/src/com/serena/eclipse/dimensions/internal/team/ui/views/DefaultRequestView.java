/*
 * @DefaultRequestView.java, created on 08-Feb-2006
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, 2006 Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.views;

import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.part.ViewPart;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionListener;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author BStephenson
 *
 */
public class DefaultRequestView extends ViewPart implements ISelectionListener, IPartListener, ISessionListener {

    public static final String VIEW_ID = "com.serena.eclipse.dimensions.internal.team.ui.views.DefaultRequest"; //$NON-NLS-1$

    private Text defaultRequest;
    private Text defaultRequestTitle;
    private Text defaultRequestStatus;
    private Combo defaultBranch;
    private IAction setDefaultRequestAction;
    private IAction deleteDefaultRequestAction;
    private IAction setCurrentRequestAction;
    private Project currentWs;
    private DimensionsConnectionDetailsEx currentCon;
    private Shell myShell;
    private String savedRequest;
    private String savedBranch;
    private String savedStatus;
    private String savedTitle;

    private List wsetBranches;

    @Override
    public void createPartControl(Composite parent) {
        myShell = getViewSite().getShell();
        Composite composite = new Composite(parent, SWT.NONE);

        GridLayout gl = new GridLayout();
        gl.numColumns = 4;
        gl.makeColumnsEqualWidth = true;
        composite.setLayout(gl);
        Label lab1 = new Label(composite, SWT.NONE);
        lab1.setText(Messages.defaultBranch_devbranch);
        defaultBranch = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY);
        GridData gd0 = new GridData();
        gd0.horizontalSpan = 1;
        gd0.horizontalAlignment = GridData.FILL;
        gd0.grabExcessHorizontalSpace = false;
        defaultBranch.setLayoutData(gd0);

        defaultBranch.addSelectionListener(new SelectionListener() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                // do nothing if not connected
                if (currentCon == null) {
                    return;
                }
                Combo c = (Combo) e.getSource();
                String val = c.getText();
                if ((savedBranch != null && !savedBranch.equals(val) && !"".equals(val)) //$NON-NLS-1$
                        || (savedBranch == null && !"".equals(val))) { //$NON-NLS-1$
                    setWorkingBranch(val);
                }
                if (savedBranch != null && "".equals(val)) { //$NON-NLS-1$
                    removeWorkingBranch();
                }
            }

            @Override
            public void widgetDefaultSelected(SelectionEvent e) {
            }

        });
        Label lab2 = new Label(composite, SWT.NONE);
        lab2.setText(Messages.defaultRequest_workingOn);
        lab2.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_CENTER));
        defaultRequest = new Text(composite, SWT.READ_ONLY | SWT.BORDER);
        GridData gd1 = new GridData();
        gd1.horizontalSpan = 1;
        gd1.horizontalAlignment = GridData.FILL;
        gd1.grabExcessHorizontalSpace = false;
        defaultRequest.setLayoutData(gd1);

        defaultRequest.addMouseListener(new MouseListener() {

            @Override
            public void mouseDoubleClick(MouseEvent e) {
                // execute the object editor on the document
                IDimensionsObjectEditHandler handler = null;
                if (currentCon == null || currentCon.isOffline() || (!currentCon.isSessionOpen())) {
                    return;
                }
                currentWs.queryAttribute(SystemAttributes.DEFAULT_REQUEST);
                final String defRequest = (String) currentWs.getAttribute(SystemAttributes.DEFAULT_REQUEST);
                if ("".equals(defRequest) || defRequest == null) { //$NON-NLS-1$
                    return;
                }
                // now get the request
                final Request[] res = new Request[1];
                try {
                    final Session s = currentCon.openSession(null);
                    s.run(new ISessionRunnable() {

                        @Override
                        public void run() throws Exception {
                            res[0] = s.getObjectFactory().findRequest(defRequest);
                        }
                    });
                } catch (DMException e1) {
                }
                if (res[0] == null) {
                    return;
                }

                final APIObjectAdapter dmObj = new ChangeDocumentAdapter(res[0], currentCon);
                handler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.REQUEST);

                if (handler != null) {
                    try {
                        handler.openEditor(dmObj);
                    } catch (CoreException e2) {
                        DMTeamUiPlugin.getDefault()
                                .handle(e2, getSite().getShell(), Messages.err_error, Messages.err_openObjEditor);
                    }
                }

            }

            @Override
            public void mouseDown(MouseEvent e) {
            }

            @Override
            public void mouseUp(MouseEvent e) {
            }
        });

        Label lab3 = new Label(composite, SWT.NONE);
        lab3.setText(Messages.defaultRequest_title);
        defaultRequestTitle = new Text(composite, SWT.READ_ONLY | SWT.BORDER);
        GridData gd2 = new GridData();
        gd2.horizontalSpan = 3;
        gd2.horizontalAlignment = GridData.FILL;
        gd2.grabExcessHorizontalSpace = true;
        defaultRequestTitle.setLayoutData(gd2);
        Label lab4 = new Label(composite, SWT.NONE);

        lab4.setText(Messages.defaultRequest_status);
        defaultRequestStatus = new Text(composite, SWT.READ_ONLY | SWT.BORDER);
        GridData gd3 = new GridData();
        gd3.horizontalSpan = 2;
        gd3.horizontalAlignment = GridData.FILL;
        gd3.grabExcessHorizontalSpace = false;
        defaultRequestStatus.setLayoutData(gd3);

        new Label(composite, SWT.NONE);

        setup();

    }

    private void setup() {
        getSite().getPage().addSelectionListener(this);
        getSite().getPage().addPartListener(this);
        DimensionsConnectionDetailsEx.addSessionListener(this);
        createViewActions();
        contributeToActionBars();
        clearInfo(getDefaultTitle());
    }

    @Override
    public void dispose() {
        // remove from where we set them
        getSite().getPage().removeSelectionListener(this);
        getSite().getPage().removePartListener(this);
        DimensionsConnectionDetailsEx.removeSessionListener(this);
        super.dispose();
    }

    private void removeWorkingBranch() {
        if (currentWs == null || currentCon == null) {
            return;
        }
        final boolean[] doit = new boolean[1];
        doit[0] = false;
        if (MessageDialog.openQuestion(myShell, Messages.Dialog_title,
                NLS.bind(Messages.defaultBranch_removeSelected, currentWs.getName()))) {
            doit[0] = true;
        }
        try {
            final Session session = currentCon.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws DMException {
                    if (doit[0]) {
                        session.getObjectFactory().setCurrentProject(currentWs.getName(), false, null, null, ".", false); //$NON-NLS-1$
                    }
                    processDMObject(currentWs, currentCon);
                }
            });
        } catch (DMException e) {
            DMUIPlugin.getDefault().handle(e);
        }
    }

    private void setWorkingBranch(final String branch) {
        if (currentWs == null || currentCon == null) {
            return;
        }
        final boolean[] doit = new boolean[1];
        doit[0] = false;
        if (MessageDialog.openQuestion(myShell, Messages.Dialog_title,
                NLS.bind(Messages.defaultBranch_setSelected, branch, currentWs.getName()))) {
            doit[0] = true;
        }
        try {
            final Session session = currentCon.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws DMException {
                    if (doit[0]) {
                        session.getObjectFactory().setCurrentProject(currentWs.getName(), false, null, null, branch, false);
                    }
                    processDMObject(currentWs, currentCon);
                }
            }, new NullProgressMonitor());
        } catch (DMException e) {
            DMUIPlugin.getDefault().handle(e);
        }

    }

    protected void createViewActions() {
        // Add Default Change Change Document
        setDefaultRequestAction = new Action(Messages.defaultRequest_newDefault_tooltip, IAction.AS_PUSH_BUTTON) {

            @Override
            public void run() {
                if (currentWs == null || currentCon == null) {
                    return;
                }

                APIObjectAdapter inputObj = new WorksetAdapter(currentWs, currentCon);
                inputObj.getAPIObject().queryAttribute(SystemAttributes.PRODUCT_NAME);
                String productId = (String) inputObj.getAPIObject().getAttribute(SystemAttributes.PRODUCT_NAME);

                FindObjectWizardDialog findDialog = new FindObjectWizardDialog(myShell, IDMConstants.CHANGEDOCUMENT,
                        inputObj.getConnectionDetails(), productId, true, true);

                if (findDialog.open() == Window.OK) {

                    if (findDialog.getFindResult().isEmpty()) {
                        MessageDialog.openError(myShell, Messages.Dialog_title, Messages.defaultRequest_noneSelected);
                        return;
                    }

                    List<String> chd = findDialog.getSelectedNames();
                    final String chdoc = chd.get(0); // only one
                    final Project w = (Project) inputObj.getAPIObject();
                    if (MessageDialog.openQuestion(myShell, Messages.Dialog_title,
                            NLS.bind(Messages.defaultRequest_setSelected, chdoc, w.getName()))) {
                        try {
                            final Session session = currentCon.openSession(null);
                            session.run(new ISessionRunnable() {
                                @Override
                                public void run() throws DMException {
                                    session.getObjectFactory().setCurrentProject(w.getName(), false, null, chdoc, null, false);
                                    processDMObject(w, currentCon);
                                }
                            });
                        } catch (DMException e) {
                            DMUIPlugin.getDefault().handle(e);
                        }
                    }
                }
            }
        };
        setDefaultRequestAction.setToolTipText(Messages.defaultRequest_newDefault_tooltip);
        setDefaultRequestAction.setImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.CHANGEDOC));
        // ------------------------------------------------------
        // Remove Default Change Change Document
        deleteDefaultRequestAction = new Action(Messages.defaultRequest_removeDefault_tooltip, IAction.AS_PUSH_BUTTON) {

            @Override
            public void run() {
                if (currentWs == null || currentCon == null) {
                    return;
                }

                if (MessageDialog.openQuestion(myShell, Messages.Dialog_title,
                        NLS.bind(Messages.defaultRequest_removeSelected, currentWs.getName()))) {
                    try {
                        final Session session = currentCon.openSession(null);
                        session.run(new ISessionRunnable() {
                            @Override
                            public void run() throws DMException {
                                session.getObjectFactory().setCurrentProject(currentWs.getName(), false, null, ".", null, false); //$NON-NLS-1$
                                processDMObject(currentWs, currentCon);
                            }
                        }, new NullProgressMonitor());
                    } catch (DMException e) {
                        DMUIPlugin.getDefault().handle(e);
                    }
                }
            }

        };
        deleteDefaultRequestAction.setToolTipText(Messages.defaultRequest_removeDefault_tooltip);
        deleteDefaultRequestAction.setImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.REMOVE));

        setCurrentRequestAction = new Action(Messages.defaultRequest_setActive, IAction.AS_PUSH_BUTTON) {

            @Override
            public void run() {
                if (currentWs == null || currentCon == null) {
                    return;
                }
                final String currentRequest = (String) currentCon.getSessionProperty(IDMConstants.ACTIVE_REQUEST);
                if (currentRequest == null || currentRequest.length() == 0) {
                    return;
                }
                if (MessageDialog.openQuestion(myShell, Messages.Dialog_title,
                        NLS.bind(Messages.defaultRequest_setSelected, currentRequest, currentWs.getName()))) {
                    try {
                        final Session session = currentCon.openSession(null);
                        session.run(new ISessionRunnable() {
                            @Override
                            public void run() throws DMException {
                                session.getObjectFactory().setCurrentProject(currentWs.getName(), false, null, currentRequest,
                                        null, false);
                                processDMObject(currentWs, currentCon);
                            }
                        }, new NullProgressMonitor());
                    } catch (DMException e) {
                        DMUIPlugin.getDefault().handle(e);
                    }
                }
            }

        };
        setCurrentRequestAction.setToolTipText(Messages.defaultRequest_setActive_tooltip);
        setCurrentRequestAction.setImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.MARKED_CHANGEDOC));

    }

    private void contributeToActionBars() {
        IActionBars bars = getViewSite().getActionBars();
        fillLocalToolBar(bars.getToolBarManager());
    }

    protected void fillLocalToolBar(IToolBarManager manager) {
        manager.add(deleteDefaultRequestAction);
        manager.add(setDefaultRequestAction);
        manager.add(setCurrentRequestAction);
        manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
        manager.add(new Separator());

    }

    @Override
    public void setFocus() {
    }

    private void clearInfo(String titleMessage) {
        defaultRequest.setText(""); //$NON-NLS-1$
        defaultRequestStatus.setText(""); //$NON-NLS-1$
        defaultRequestTitle.setText(""); //$NON-NLS-1$
        defaultBranch.setText(""); //$NON-NLS-1$
        setPartName(titleMessage != null ? titleMessage : ""); //$NON-NLS-1$
        enableDelete(false);
        enableSet(false);
        enableSetActive(false);
        currentWs = null;
        currentCon = null;
    }

    @Override
    public void selectionChanged(IWorkbenchPart part, ISelection selection) {
        // Only handle wiew selections here as not called in Manifest editor
        if (part instanceof IViewPart) {
            // in a view
            if (selection instanceof IStructuredSelection) {
                Object obj = ((IStructuredSelection) selection).getFirstElement();
                if ((obj != null) && (obj instanceof IAdaptable)) {
                    IResource res = (IResource) ((IAdaptable) obj).getAdapter(IResource.class);
                    if (res != null) {
                        handlePartSelection(res);
                    }
                }

            }
        }
    }

    @Override
    public void partActivated(IWorkbenchPart part) {
        if (part instanceof IEditorPart) {
            // an Editor
            IEditorInput editIn = ((IEditorPart) part).getEditorInput();
            if (editIn instanceof IFileEditorInput) {
                handlePartSelection(((IFileEditorInput) editIn).getFile());
            }
        }
    }

    /**
     * @param res
     */
    private void handlePartSelection(IResource res) {
        IDMProject dmp = getDMProject(res);
        if (dmp != null) {
            DimensionsConnectionDetailsEx con = dmp.getConnection();
            if (con.isOffline() || !con.isSessionOpen()) {
                clearInfo(getDefaultTitle());
                enableSet(false);
                enableSetActive(false);
                enableDelete(false);
                defaultBranch.setText(""); //$NON-NLS-1$
                defaultBranch.setItems(Utils.ZERO_LENGTH_STRING_ARRAY);
            } else {
                DimensionsLcObject lco = null;
                try {
                    lco = dmp.getDimensionsObject();
                } catch (DMException e1) {
                }
                processDMObject(lco, con);
            }
        } else {
            clearInfo(Messages.defaultRequest_notWorkingOn_title);
            enableSet(false);
            enableSetActive(false);
            enableDelete(false);
        }
    }

    private String getDefaultTitle() {
        return Messages.defaultRequest_noContext_title;
    }

    @Override
    public void partBroughtToTop(IWorkbenchPart part) {
    }

    @Override
    public void partClosed(IWorkbenchPart part) {
    }

    @Override
    public void partDeactivated(IWorkbenchPart part) {
    }

    @Override
    public void partOpened(IWorkbenchPart part) {

    }

    private IDMProject getDMProject(IResource res) {
        DMRepositoryProvider rep = DMRepositoryProvider.getDMProvider(res);
        if (rep != null) {
            IDMProject dmp = null;
            try {
                dmp = rep.getIdmProject();
            } catch (CoreException e) {
            }
            return dmp;

        }
        return null;
    }

    private void processDMObject(DimensionsLcObject lco, DimensionsConnectionDetailsEx con) {
        // if we are here then we are not offline or not unconnected
        if (lco != null) {
            if (lco instanceof Project) {
                if (setInfo((Project) lco, con)) {
                    enableSet(true);
                    currentCon = con; // connection should be set before enableSetActive() is called
                    enableSetActive(true);
                    enableDelete(true);
                    currentWs = (Project) lco;
                } else {
                    // no default doc but we still have current
                    enableSet(true);
                    currentCon = con; // connection should be set before enableSetActive() is called
                    enableSetActive(true);
                    enableDelete(false);
                    currentWs = (Project) lco;

                }

            } else if (lco instanceof Baseline) {
                clearInfo(Messages.defaultRequest_notWorkingOn_title);
                enableSet(false);
                enableSetActive(false);
                enableDelete(false);
            } else {
                clearInfo(Messages.defaultRequest_notWorkingOn_title);
                enableSet(false);
                enableSetActive(false);
                enableDelete(false);
            }
        }
    }

    private boolean setInfo(final Project workset, final DimensionsConnectionDetailsEx con) {
        // get the default change document and branch
        try {
            final Session s = con.openSession(null);
            s.run(new ISessionRunnable() {
                @Override
                public void run() {
                    workset.queryAttribute(new int[] { SystemAttributes.DEFAULT_REQUEST, SystemAttributes.DEFAULT_BRANCH });
                }
            }, new NullProgressMonitor());
        } catch (DMException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        }

        final String defRequest = (String) workset.getAttribute(SystemAttributes.DEFAULT_REQUEST);
        final String defBranch = (String) workset.getAttribute(SystemAttributes.DEFAULT_BRANCH);
        // if same workset don't requery list of branches
        if (wsetBranches == null || workset != currentWs) {
            wsetBranches = workset.getBranchNames();
        }
        String[] wsetBranchNames = new String[wsetBranches.size() + 1];
        // add in an empty one for clearing it
        wsetBranchNames[0] = ""; //$NON-NLS-1$
        for (int branch = 0; branch < wsetBranches.size(); branch++) {
            wsetBranchNames[branch + 1] = (String) wsetBranches.get(branch);
        }
        defaultBranch.setItems(wsetBranchNames);
        boolean haveRequest = true;
        boolean haveBranch = true;
        if ("".equals(defRequest) || defRequest == null) { //$NON-NLS-1$

            currentWs = workset;
            currentCon = con;
            enableSet(true);
            enableSetActive(true);
            enableDelete(false);
            savedRequest = null;
            savedTitle = null;
            savedStatus = null;
            haveRequest = false;
        }

        if ("".equals(defBranch) || defBranch == null) { //$NON-NLS-1$

            currentWs = workset;
            currentCon = con;
            savedBranch = null;
            haveBranch = false;
        }

        if ((!haveRequest) && (!haveBranch)) {
            // dont have any
            clearInfo(Messages.defaultRequest_notWorkingOn_title);

        } else {
            // have either
            String titleBranch = ""; //$NON-NLS-1$
            String titleRequest = ""; //$NON-NLS-1$
            if (haveRequest) {
                // now get the request
                defaultRequest.setText(defRequest);
                requestDetails(con, defRequest);
                titleRequest = defRequest;
            }
            if (haveBranch) {
                defaultBranch.setText(defBranch);
                titleBranch = defBranch;
                savedBranch = defBranch;
            }
            // set based on info
            setPartName(NLS.bind(Messages.defaultRequest_workingOn_title, titleRequest, titleBranch));
            return true;

        }
        return false; // fall through

    }

    /**
     * @param con
     * @param defRequest
     */
    private void requestDetails(final DimensionsConnectionDetailsEx con, final String defRequest) {
        final String[] res = new String[2];

        if (defRequest.equals(savedRequest)) {
            // have same as last time
            res[0] = savedTitle;
            res[1] = savedStatus;

        } else {
            try {
                final Session s = con.openSession(null);
                s.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        Request cd = s.getObjectFactory().findRequest(defRequest);
                        int[] attrs = new int[] { SystemAttributes.TITLE, SystemAttributes.STATUS };
                        cd.queryAttribute(attrs);
                        res[0] = (String) cd.getAttribute(SystemAttributes.TITLE);
                        res[1] = (String) cd.getAttribute(SystemAttributes.STATUS);
                    }

                });
            } catch (DMException e) {
            }
            savedRequest = defRequest;
            savedTitle = res[0];
            savedStatus = res[1];
        }
        defaultRequestTitle.setText(res[0]);
        defaultRequestStatus.setText(res[1]);
    }

    private void enableSet(boolean on) {
        if (setDefaultRequestAction != null) {
            setDefaultRequestAction.setEnabled(on);
        }
    }

    private void enableSetActive(boolean on) {
        if (setCurrentRequestAction != null) {
            if (currentCon != null) {
                String currentRequest = (String) currentCon.getSessionProperty(IDMConstants.ACTIVE_REQUEST);
                if (currentRequest == null || currentRequest.length() == 0) {
                    on = false;// If there is no active request then do not enable the "set active request as default" button
                }
            }
            setCurrentRequestAction.setEnabled(on);
        }
    }

    private void enableDelete(boolean on) {
        if (deleteDefaultRequestAction != null) {
            deleteDefaultRequestAction.setEnabled(on);
        }
    }

    @Override
    public void sessionCreated(DimensionsConnectionDetailsEx loc) {
    }

    @Override
    public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
        if (currentCon != null && currentCon.equals(loc)) {
            clearInfo(getDefaultTitle());
        }
    }

}

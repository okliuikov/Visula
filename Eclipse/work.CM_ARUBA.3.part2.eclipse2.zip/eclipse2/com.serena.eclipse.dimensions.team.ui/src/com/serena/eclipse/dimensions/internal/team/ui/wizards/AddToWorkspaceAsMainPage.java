/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectMappingPanel;
import com.serena.eclipse.dimensions.internal.team.ui.controls.ProjectMappingValidator;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * Allows to select if a single project should be added via the standard "new project wizard" or
 * specify alternative names for projects without .project file.
 *
 * @author V.Grishchenko
 */
public class AddToWorkspaceAsMainPage extends DimensionsWizardPage {
    public static final String ADD_TO_WORKSPACE_MAIN_PAGE_ID = "add_to_workspace_main_page_id"; //$NON-NLS-1$

    private ProjectMapping[] mappings;
    private boolean allowNewProjectWizard;
    private Button newProjectWizardBtn;
    private Button asProjectsBtn;
    private ProjectMappingPanel projectMappingPanel;
    private boolean newProjectWizard;

    /**
     * Creates a new page.
     */
    public AddToWorkspaceAsMainPage(ProjectMapping[] mappings, ImageDescriptor titleImage, boolean allowNewProjectWizard) {
        super(ADD_TO_WORKSPACE_MAIN_PAGE_ID, Messages.AddToWorkspaceAsMainPage_title, titleImage);
        setDescription(Messages.AddToWorkspaceAsMainPage_description);
        this.mappings = mappings;
        this.allowNewProjectWizard = allowNewProjectWizard;
    }

    public AddToWorkspaceAsMainPage(ProjectMapping[] mappings, boolean allowNewProjectWizard) {
        this(mappings, null, allowNewProjectWizard);
    }

    public boolean useNewProjectWizardSelected() {
        return newProjectWizard;
    }

    private boolean isSingleProject() {
        return mappings.length == 1;
    }

    @Override
    public void createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        setControl(composite);
        UIUtils.setGridLayout(composite, 1);

        if (allowNewProjectWizard) {
            newProjectWizardBtn = new Button(composite, SWT.RADIO);
            newProjectWizardBtn.setText(Messages.AddToWorkspaceAsMainPage_configure);

            asProjectsBtn = new Button(composite, SWT.RADIO);
            asProjectsBtn.setText(getMappingPanelName());
            asProjectsBtn.setSelection(true);
            newProjectWizardBtn.addListener(SWT.Selection, new Listener() {
                @Override
                public void handleEvent(Event event) {
                    if (event.type != SWT.Selection) {
                        return;
                    }
                    if (event.widget == newProjectWizardBtn) {
                        newProjectWizard = newProjectWizardBtn.getSelection();
                        projectMappingPanel.setEnabled(!newProjectWizard);
                        getWizard().getContainer().updateButtons();
                    }
                }
            });
            newProjectWizard = false;
        } else {
            String txt = getMappingPanelName();
            Label label = UIUtils.createLabel(composite, txt);
            UIUtils.setGridData(label, GridData.FILL_HORIZONTAL);
        }

        projectMappingPanel = new ProjectMappingPanel(composite, SWT.NONE, mappings, null);
        UIUtils.setGridData(projectMappingPanel.getPanel(), GridData.FILL_BOTH);
        projectMappingPanel.getPanel().setSize(projectMappingPanel.getPanel().computeSize(400, SWT.DEFAULT));

        ProjectMappingValidator validator = new ProjectMappingValidator(mappings, false) {
            @Override
            protected void setErrorMessage(String message) {
                AddToWorkspaceAsMainPage.this.setErrorMessage(message);
                setPageComplete(message == null);
            }
        };
        setPageComplete(validator.isMappingValid());
        projectMappingPanel.setListener(validator);
    }

    private String getMappingPanelName() {
        if (isSingleProject()) {
            return Messages.AddToWorkspaceAsMainPage_asProject;
        }
        return Messages.AddToWorkspaceAsMainPage_asProjects;
    }

}

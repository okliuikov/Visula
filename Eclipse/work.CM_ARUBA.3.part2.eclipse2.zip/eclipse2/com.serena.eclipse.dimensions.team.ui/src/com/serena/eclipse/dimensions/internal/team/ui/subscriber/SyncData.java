/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.team.core.synchronize.SyncInfoSet;

import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;

/**
 * Synchronization data holder which contains workspace project changes
 */
class SyncData {
    private DMRepositoryProvider provider;
    private SyncInfoSet set;

    SyncData(DMRepositoryProvider provider, SyncInfoSet set) {
        Assert.isNotNull(provider);
        Assert.isNotNull(set);
        this.provider = provider;
        this.set = set;
    }

    DMRepositoryProvider getProvider() {
        return provider;
    }

    SyncInfoSet getSyncInfoSet() {
        return set;
    }
}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IScopeContext;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.osgi.service.prefs.BackingStoreException;
import org.osgi.service.prefs.Preferences;

import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author S. Korniychuk
 */
public class DimensionsProjectPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage,
        IDMTeamPreferences {

    public DimensionsProjectPreferencePage() {
        super(GRID);
        setDescription(Messages.projectPrefPage_descr);
        setPreferenceStore(DMTeamUiPlugin.getDefault().getPreferenceStore());
    }

    @Override
    protected void createFieldEditors() {
        addField(new BooleanFieldEditor(PROJECT_ALLOW_UPDATE_AUTO_MEGRE, Messages.projectPrefPage_allowUpdateAutoMerge,
                getFieldEditorParent()));

        addField(new BooleanFieldEditor(UNDO_COUT_CIN_UNMODIFIED, Messages.teamPrefPage_undoCoutCinUmod, getFieldEditorParent()));

    }

    @Override
    public void init(IWorkbench workbench) {
    }

    @Override
    public boolean performOk() {
        boolean ok = super.performOk();
        DMTeamUiPlugin.getDefault().savePluginPreferences();
        return ok;
    }

    public static boolean setAutoMergePreference(boolean value) {
        IScopeContext instanceContext = new InstanceScope();
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.PROJECT_ALLOW_UPDATE_AUTO_MEGRE, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean saveNode(Preferences node) {
        try {
            node.flush();
            return true;
        } catch (BackingStoreException e) {
            return false;
        }
    }

}

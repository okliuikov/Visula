/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Request association settings.
 *
 * @author V.Grishchenko
 */
public class RequestsPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage, IDMTeamPreferences {

    public RequestsPreferencePage() {
        super(GRID);
        setDescription("Item to request association settings");
        setPreferenceStore(DMTeamUiPlugin.getDefault().getPreferenceStore());
    }

    @Override
    protected void createFieldEditors() {
        addField(new BooleanFieldEditor(USE_ACTIVATED_REQUESTS, Messages.teamPrefPage_useActivated, getFieldEditorParent()));

        addField(new BooleanFieldEditor(SHOW_PROJECT_ON_COMMIT, Messages.teamPrefPage_showProjectCommit, getFieldEditorParent()));

        addField(new BooleanFieldEditor(DEACTIVATE_REQUESTS, Messages.teamPrefPage_deactivateRequests, getFieldEditorParent()));

    }

    @Override
    public void init(IWorkbench workbench) {
    }

    @Override
    public boolean performOk() {
        boolean ok = super.performOk();
        DMTeamUiPlugin.getDefault().savePluginPreferences();
        return ok;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.team.core.TeamException;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantReference;

import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.DMBaseCompareSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.ProjectMergeDescriptor;

/**
 * Base class for compare and merge participants.
 * @author V.Grishchenko
 */
public abstract class DMBaseCompareParticipant extends DMSynchronizeParticipant {

    /**
     * @return found participant with matching id and compares or <code>null</code> if none
     */
    public static DMBaseCompareParticipant getMatchingParticipant(String id, ProjectMergeDescriptor[] merges) {
        Assert.isNotNull(id);
        Assert.isNotNull(merges);
        Set mergeSet = new HashSet();
        mergeSet.addAll(Arrays.asList(merges));
        ISynchronizeParticipantReference[] refs = TeamUI.getSynchronizeManager().getSynchronizeParticipants();
        for (int i = 0; i < refs.length; i++) {
            ISynchronizeParticipantReference reference = refs[i];
            if (reference.getId().equals(id)) {
                DMBaseCompareParticipant p;
                try {
                    p = (DMBaseCompareParticipant) reference.getParticipant();
                } catch (TeamException e) {
                    continue;
                }
                ProjectMergeDescriptor[] otherDescriptors = p.getCompareDescriptors();
                if (mergeSet.size() == otherDescriptors.length && mergeSet.containsAll(Arrays.asList(otherDescriptors))) {
                    return p;
                }
            }
        }
        return null;
    }

    /**
     * No-arg constructor to be invoked on registry creation
     */
    public DMBaseCompareParticipant() {
    }

    /**
     * @param scope
     */
    public DMBaseCompareParticipant(DMBaseCompareSubscriber subscriber) {
        setSubscriber(subscriber);
    }

    public DMBaseCompareSubscriber getCompareSubscriber() {
        return (DMBaseCompareSubscriber) getSubscriber();
    }

    /**
     * @return descriptors for which this participant shows a compare
     */
    public ProjectMergeDescriptor[] getCompareDescriptors() {
        return ((DMBaseCompareSubscriber) getSubscriber()).getDescriptors();
    }

    @Override
    public void dispose() {
        super.dispose();
        if (TeamUI.getSynchronizeManager().get(getId(), getSecondaryId()) == null) {
            // If the participant isn't managed by the synchronize manager then we
            // must ensure that the state cached in the subscriber is flushed.
            flushStateCache();
        }
    }

    protected void flushStateCache() {
        getCompareSubscriber().dispose();
    }

    @Override
    protected String getLongTaskName() {
        return getName();
    }

}

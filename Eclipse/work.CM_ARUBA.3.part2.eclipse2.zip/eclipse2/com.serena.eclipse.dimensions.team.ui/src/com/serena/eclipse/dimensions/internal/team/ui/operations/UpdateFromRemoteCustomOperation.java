package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.internal.team.core.CustomSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DownloadRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;

/**
 * @author kberezovchuk
 */
public class UpdateFromRemoteCustomOperation extends UpdateFromRemoteOperation {
    private CustomSubscriber subscriber;

    public UpdateFromRemoteCustomOperation(CustomSubscriber subscriber, IWorkbenchPart part, IResource[] resources) {
        super(part, resources);
        this.subscriber = subscriber;
    }

    public UpdateFromRemoteCustomOperation(CustomSubscriber subscriber, IWorkbenchPart part, IResource[] resources,
            IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
        this.subscriber = subscriber;
    }

    /**
     * Calls special download function getting item revisions from Subscriber mapped resources
     */
    @Override
    protected void update(DMRepositoryProvider provider, IResource[] resources, IProgressMonitor monitor) throws CoreException,
            InterruptedException {
        DownloadRequest[] requests = new DownloadRequest[resources.length];
        for (int i = 0; i < requests.length; i++) {
            requests[i] = new DownloadRequest(resources[i]);
        }
        addSkippedFiles(provider.getIdmProject().download(subscriber, requests, shouldOverwrite(), isDeleteUnmanaged(), monitor));
    }

    @Override
    protected boolean refreshBeforeUpdate() {
        return false; // assume up to date as we are run from the sync view
    }

}

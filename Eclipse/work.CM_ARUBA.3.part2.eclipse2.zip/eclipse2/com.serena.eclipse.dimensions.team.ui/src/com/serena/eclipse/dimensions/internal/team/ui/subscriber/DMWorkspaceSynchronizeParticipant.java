/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.runtime.Platform;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;
import org.eclipse.team.ui.synchronize.SynchronizePageActionGroup;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.PartInitException;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.actions.CleanTimestampsAction;
import com.serena.eclipse.dimensions.internal.team.ui.actions.IgnoreAction;
import com.serena.eclipse.dimensions.internal.team.ui.actions.ItemHistoryAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class DMWorkspaceSynchronizeParticipant extends DMSynchronizeParticipant {
    /** my id */
    public static final String ID = "com.serena.eclipse.dimensions.team.dmworkspace-participant"; //$NON-NLS-1$

    public static final String TOOLBAR_CONTRIBUTION_GROUP = "toolbar_group"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_1 = "ctx_group_1"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_2 = "ctx_group_2"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_3 = "ctx_group_3"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_4 = "ctx_group_4"; //$NON-NLS-1$

    private class WorkspaceActionContribution extends SynchronizePageActionGroup {

        @Override
        public void initialize(ISynchronizePageConfiguration configuration) {
            super.initialize(configuration);
            //
            // toolbar actions
            DMWorkspaceUpdateAction updateToolbarAction = new DMWorkspaceUpdateAction(configuration,
                    getVisibleRootsSelectionProvider());
            updateToolbarAction.setPromptBeforeUpdate(true);
            updateToolbarAction.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.CHECKOUT_ACTION));
            updateToolbarAction.setDisabledImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(
                    IDMTeamImages.CHECKOUT_ACTION_D));
            updateToolbarAction.setToolTipText(Messages.DMWorkspaceSynchronizeParticipant_1);

            DMWorkspaceCommitAction commitToolbarAction = new DMWorkspaceCommitAction(configuration,
                    getVisibleRootsSelectionProvider());
            commitToolbarAction.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.CHECKIN_ACTION));
            commitToolbarAction.setDisabledImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(
                    IDMTeamImages.CHECKIN_ACTION_D));
            commitToolbarAction.setToolTipText(Messages.DMWorkspaceSynchronizeParticipant_0);

            appendToGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP, updateToolbarAction);

            appendToGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP, commitToolbarAction);

            // ctx menu update commit actions
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1,
                    new DMWorkspaceUpdateAction(configuration));
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1,
                    new DMWorkspaceCommitAction(configuration));

            // override and merge actions
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2,
                    new DMOverrideAndUpdateAction(configuration));
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2,
                    new DMOverrideAndCommitAction(configuration));
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2,
                    new DMConfirmMergedAction(configuration));

            if (!configuration.getSite().isModal()) {
                // use action names from plugin.properties to avoid duplication
                String historyLabel = "!history action key changed in plugin.properties!"; //$NON-NLS-1$
                String ignoreLabel = "!ignore action key changed in plugin.properties!"; //$NON-NLS-1$
                String cleanTsLabel = "!clean timestamps action key changed in plugin.properties"; //$NON-NLS-1$
                try {
                    historyLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "ShowHistory.label"); //$NON-NLS-1$
                    ignoreLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString("Ignore.label"); //$NON-NLS-1$
                    cleanTsLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "CleanTimestamps.label"); //$NON-NLS-1$
                } catch (Exception e) {
                }
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(historyLabel, new ItemHistoryAction(), configuration));
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(ignoreLabel, new IgnoreAction(), configuration));
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(cleanTsLabel, new CleanTimestampsAction(), configuration));
            }
        }
    }

    /**
     * No-arg constructor to be invoked on registry creation
     */
    public DMWorkspaceSynchronizeParticipant() {
    }

    public DMWorkspaceSynchronizeParticipant(ISynchronizeScope scope) {
        super(scope);
        setSubscriber(DMTeamPlugin.getWorkspace().getSubscriber());
    }

    @Override
    public void init(String secondaryId, IMemento memento) throws PartInitException {
        super.init(secondaryId, memento);
        setSubscriber(DMTeamPlugin.getWorkspace().getSubscriber());
    }

    @Override
    protected ISynchronizeParticipantDescriptor getDescriptor() {
        return TeamUI.getSynchronizeManager().getParticipantDescriptor(ID);
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP);
        configuration.addActionContribution(new WorkspaceActionContribution());
        configuration.setSupportedModes(ISynchronizePageConfiguration.ALL_MODES);
        configuration.setMode(ISynchronizePageConfiguration.BOTH_MODE);

        // Add context menu groups here to give the client displaying the
        // page a chance to remove the context menu
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_4);
    }

}

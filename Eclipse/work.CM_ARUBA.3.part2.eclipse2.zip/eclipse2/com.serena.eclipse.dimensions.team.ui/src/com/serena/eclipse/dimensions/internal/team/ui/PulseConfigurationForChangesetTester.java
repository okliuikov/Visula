package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;

import com.serena.dmclient.api.DimensionsChangeSet;


public class PulseConfigurationForChangesetTester extends PropertyTester {
    public static final String BASE_PULSE_URL_AVAILABLE = "basePulseUrlAvailable"; //$NON-NLS-1$

    public PulseConfigurationForChangesetTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (!(receiver instanceof StructuredSelection)) {
            return false;
        }
        StructuredSelection ss = (StructuredSelection) receiver;
        Object selected = ss.getFirstElement();
        if (!(selected instanceof DimensionsChangeSet)) {
            return false;
        }
        DimensionsChangeSet cs = (DimensionsChangeSet) selected;
        if (property.equals(BASE_PULSE_URL_AVAILABLE)) {
            boolean statusOk = cs.getBaseUrl()!=null && !cs.getBaseUrl().isEmpty();
            return statusOk;
        } else {
            return false;
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.viewers.ILabelDecorator;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.graphics.Image;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Wraps a main decorator and allows subclasses to override <code>decorateImage</code> and <code>decorateText</code> in order to
 * add or ignore decorations provided by the main decorator.
 *
 * @author V.Grishchenko
 */
public class LabelDecoratorWrapper implements ILabelDecorator {
    private ILabelDecorator decorator;

    public LabelDecoratorWrapper(ILabelDecorator decorator) {
        Assert.isNotNull(decorator);
        this.decorator = decorator;
    }

    @Override
    public Image decorateImage(Image image, Object element) {
        return decorator.decorateImage(image, element);
    }

    @Override
    public String decorateText(String text, Object element) {
        return decorator.decorateText(text, element);
    }

    @Override
    public void addListener(ILabelProviderListener listener) {
        decorator.addListener(listener);
    }

    @Override
    public void dispose() {
        decorator.dispose();
    }

    @Override
    public boolean isLabelProperty(Object element, String property) {
        return true;
    }

    @Override
    public void removeListener(ILabelProviderListener listener) {
        decorator.removeListener(listener);
    }

}

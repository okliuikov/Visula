/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.controls;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.model.AdaptableList;
import org.eclipse.ui.model.BaseWorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.core.IServiceResource;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.BaselineList;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsIDEProject;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.FavouriteRecentProjectList;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainer;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsCategoryElement;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsProjectsCategory;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class ProjectBrowsePanel {
    public static final int SHOW_NONE = 0;
    public static final int SHOW_WORKSETS = 1;
    public static final int SHOW_BASELINES = 2;
    public static final int SHOW_GROUPS = 4;
    public static final int SHOW_SCC_PROJECT_CONTAINERS = 8;
    public static final int SHOW_SINGLE_ECLIPSE_PROJECTS = 16;
    public static final int SHOW_SCC_PROJECTS = 32;
    public static final int SHOW_ALL_EXCEPT_SCC = SHOW_WORKSETS | SHOW_BASELINES | SHOW_GROUPS | SHOW_SCC_PROJECT_CONTAINERS
            | SHOW_SINGLE_ECLIPSE_PROJECTS;
    public static final int SHOW_ALL = SHOW_ALL_EXCEPT_SCC | SHOW_SCC_PROJECTS;

    public static final int SHOW_IN_WORKSPACE = 0x10000;
    public static final int STRICT_MODE = 0x20000;
    public static final int THREE_WAY_MERGE = 0x40000;

    private int options;
    private ViewerFilter myFilter;

    private Composite panel;
    private TreeViewer treeViewer;

    private ISelectionChangedListener selectionChangedListener;
    private IDoubleClickListener doubleClickListener;

    private DimensionsConnectionDetailsEx connection;

    private WorksetAdapter[] selectedWorksets = new WorksetAdapter[0];
    private BaselineAdapter[] selectedBaselines = new BaselineAdapter[0];
    private SccProject[] selectedSccProjects = new SccProject[0];

    private class Filter extends ViewerFilter {

        @Override
        public boolean select(Viewer viewer, Object parentElement, Object element) {
            if (element instanceof DimensionsProjectsCategory) {
                return true;
            }

            if (element instanceof FavouriteRecentProjectList) {
                if ((options & ProjectBrowsePanel.SHOW_WORKSETS) == ProjectBrowsePanel.SHOW_WORKSETS) {
                    return true;
                }
            }

            if (element instanceof DimensionsIDEProject || element instanceof DimensionsIDEProjectGroup
                    || element instanceof SccProjectContainer) {
                if ((options & SHOW_IN_WORKSPACE) != 0) {
                    return isMapped((VersionManagementProject) element);
                }
                return true;
            }

            if (element instanceof WorksetAdapter) {
                WorksetAdapter adapter = (WorksetAdapter) element;
                if ((options & SHOW_WORKSETS) != 0) {
                    if ((options & SHOW_IN_WORKSPACE) != 0) {
                        // check for mapping only
                        return isMapped(adapter);
                    } else {
                        // check for tag if any tag specific option exists
                        return isTagAllowed(adapter);
                    }
                }
                return false;
            }

            if (element instanceof WorksetList) {
                int type = ((WorksetList) element).getType();
                if (type == WorksetList.OTHER_PROJECTS || type == WorksetList.OTHER_STREAMS
                        || type == WorksetList.OTHER_PROJECTS_AND_STREAMS) {
                    return (options & SHOW_WORKSETS) != 0;
                } else if (type == WorksetList.IDE_PROJECTS || type == WorksetList.IDE_STREAMS
                        || type == WorksetList.IDE_PROJECTS_AND_STREAMS) {
                    return ((options & SHOW_SINGLE_ECLIPSE_PROJECTS) != 0);
                } else if (type == WorksetList.IDE_PROJECT_GROUPS || type == WorksetList.IDE_STREAM_GROUPS
                        || type == WorksetList.IDE_PROJECT_AND_STREAM_GROUPS) {
                    return (options & SHOW_GROUPS) != 0;
                } else if (type == WorksetList.SCC_PROJECT_CONTAINERS || type == WorksetList.SCC_STREAM_CONTAINERS
                        || type == WorksetList.SCC_PROJECT_AND_STREAM_CONTAINERS) {
                    return (options & SHOW_SCC_PROJECT_CONTAINERS) != 0;
                }
                return false;
            }

            if (element instanceof BaselineAdapter) {
                return (options & SHOW_BASELINES) != 0;
            }

            if (element instanceof BaselineList) {
                return (options & SHOW_BASELINES) != 0;
            }

            if (element instanceof SccProject) {
                if ((options & SHOW_SCC_PROJECTS) != 0) {
                    if ((options & SHOW_IN_WORKSPACE) != 0) {
                        return isMapped((SccProject) element);
                    }
                    return true;
                }
                return false;
            }

            return false;
        }

        private boolean isTagAllowed(WorksetAdapter adapter) {
            String tag = (String) adapter.getAPIObject().getAttribute(SystemAttributes.IDE_TAG);
            if (tag == null) {
                return true;
            }

            if ((options & SHOW_SINGLE_ECLIPSE_PROJECTS) == 0) {
                // do not show single eclipse projects
                if (tag.indexOf(IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG) != -1) {
                    return false;
                }
            }

            if ((options & SHOW_GROUPS) == 0) {
                // do not show project groups
                if (tag.indexOf(IDMConstants.ECLIPSE_PROJECT_GROUP_TAG) != -1) {
                    return false;
                }
            }

            if ((options & SHOW_SCC_PROJECT_CONTAINERS) == 0) {
                // do not show project containers
                if (tag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1) {
                    return false;
                }
            }

            return true;

        }

        private boolean isMapped(VersionManagementProject element) {
            try {
                return element.isMapped();
            } catch (CoreException e) {
                DMTeamUiPlugin.log(e.getStatus());
                return true; // assume visible
            }
        }
    }

    public ProjectBrowsePanel(Composite parent, int style, int options) {
        this.options = options;
        createControl(parent, style);
    }

    /**
     * @param connection
     *            The connection to set.
     * @param showOnlyStreams
     *            - Show only Streams in the list
     * @param showOnlyProjects
     *            - Show only Projects in the list
     */
    public void setConnection(DimensionsConnectionDetailsEx connection, boolean showOnlyStreams, boolean showOnlyProjects) {
        if (this.connection == connection || (this.connection != null && this.connection.equals(connection))) {
            return;
        }
        this.connection = connection;
        setViewerInput(showOnlyStreams, showOnlyProjects);
    }

    public Composite getPanel() {
        return panel;
    }

    /**
     * @return selected worksets or empty array
     */
    public WorksetAdapter[] getSelectedWorksets() {
        return selectedWorksets;
    }

    /**
     * @return selected baselines or empty array
     */
    public BaselineAdapter[] getSelectedBaselines() {
        return selectedBaselines;
    }

    /**
     * @return selected legacy ide projects or empty array
     */
    public SccProject[] getSelectedSccProjects() {
        return selectedSccProjects;
    }

    /**
     * Selection listener is notified after events have been processed by
     * this class.
     *
     * @param listener
     */
    public void setSelectionChangedListener(ISelectionChangedListener listener) {
        if (selectionChangedListener == null) {
            selectionChangedListener = listener;
        }
    }

    public void setDoubleClickListener(IDoubleClickListener listener) {
        if (doubleClickListener == null) {
            doubleClickListener = listener;
        }
    }

    public void setEnabled(boolean b) {
        treeViewer.getTree().setEnabled(b);
    }

    public void setOptions(int options) {
        this.options = options;
        if (treeViewer != null && !treeViewer.getControl().isDisposed()) {
            if (!treeViewer.isBusy()) {
                treeViewer.refresh();
            }
        }
    }

    protected void createControl(Composite parent, int style) {
        panel = new Composite(parent, style);

        panel.setLayout(new FillLayout());

        Tree tree = new Tree(panel, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | (style & (SWT.SINGLE | SWT.MULTI)));
        treeViewer = new TreeViewer(tree);
        treeViewer.setLabelProvider(new WorkbenchLabelProvider());
        treeViewer.setContentProvider(new BaseWorkbenchContentProvider() {

            @Override
            public boolean hasChildren(Object element) {
                if (element instanceof IServiceResource) {
                    if ((options & THREE_WAY_MERGE) == THREE_WAY_MERGE
                            && (element instanceof SccProjectContainerWorkset || element instanceof SccBaselineContainer)) {
                        return false;
                    } else {
                        return ((IServiceResource) element).isContainer();
                    }
                }
                return false;
            }

        });
        myFilter = new Filter();
        treeViewer.addFilter(myFilter);
        treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {

            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                ISelection selection = event.getSelection();
                List<Object> all = new ArrayList<Object>();
                if (selection == null || selection.isEmpty() || !(selection instanceof StructuredSelection)) {
                    selectedWorksets = new WorksetAdapter[0];
                    selectedBaselines = new BaselineAdapter[0];
                } else {
                    List<Object> wstList = new ArrayList<Object>();
                    List<Object> blList = new ArrayList<Object>();
                    List<Object> lpList = new ArrayList<Object>();
                    IStructuredSelection ss = (IStructuredSelection) selection;
                    boolean strict = (options & STRICT_MODE) != 0;
                    boolean merge = (options & THREE_WAY_MERGE) != 0;
                    for (Iterator<?> iter = ss.iterator(); iter.hasNext();) {
                        Object element = iter.next();
                        if ((strict && element != null && (element.getClass() == WorksetAdapter.class))
                                || (!strict && (element instanceof WorksetAdapter))) { // avoid IDE projects and groups
                            wstList.add(element);
                            all.add(element);
                        } else if ((strict && element != null && (element.getClass() == BaselineAdapter.class))
                                || (!strict && (element instanceof BaselineAdapter))) {
                            blList.add(element);
                            all.add(element);
                        } else if (element instanceof SccProject) {
                            lpList.add(element);
                            all.add(element);
                        }
                    }

                    if (merge) {
                        for (Iterator<?> iterator = wstList.iterator(); iterator.hasNext();) {
                            Object ell = iterator.next();
                            if (ell instanceof DimensionsIDEProject || ell instanceof SccProjectContainer) {
                                iterator.remove();
                                all.remove(ell);
                            }
                        }
                        for (Iterator<?> iterator = blList.iterator(); iterator.hasNext();) {
                            Object ell = iterator.next();
                            if (!(ell instanceof BaselineAdapter)) {
                                iterator.remove();
                                all.remove(ell);
                            }
                        }
                    }

                    selectedWorksets = wstList.toArray(new WorksetAdapter[wstList.size()]);
                    selectedBaselines = blList.toArray(new BaselineAdapter[blList.size()]);
                    selectedSccProjects = lpList.toArray(new SccProject[lpList.size()]);
                }

                if (selectionChangedListener != null) {
                    selectionChangedListener.selectionChanged(new SelectionChangedEvent(event.getSelectionProvider(),
                            new StructuredSelection(all)));
                }
            }
        });
        treeViewer.addDoubleClickListener(new IDoubleClickListener() {

            @Override
            public void doubleClick(DoubleClickEvent event) {
                if (doubleClickListener != null) {
                    doubleClickListener.doubleClick(event);
                }
            }
        });
    }

    public void setViewerInput(boolean showOnlyStreams, boolean showOnlyProjects) {
        AdaptableList input = new AdaptableList();
        if (connection != null) {
            DimensionsProjectsCategory dpc = (DimensionsProjectsCategory) DimensionsCategoryElement.getCategory(this.connection,
                    DimensionsProjectsCategory.class);
            if (showOnlyStreams) {
                dpc.setShowOnlyStreams(true);
                dpc.setShowOnlyProjects(false);
            } else if (showOnlyProjects) {
                dpc.setShowOnlyProjects(true);
                dpc.setShowOnlyStreams(false);
            } else {
                dpc.setShowOnlyProjects(false);
                dpc.setShowOnlyStreams(false);
            }
            input.add(dpc);
        }
        treeViewer.setInput(input);
        treeViewer.expandToLevel(2);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.operations.DisconnectProviderOperation;

/**
 * @author V.Grishchenko
 */
public class DisconnectProviderAction extends DMTeamAction {
    private boolean deleteMeta;

    public DisconnectProviderAction() {
    }

    static class DeleteProjectDialog extends MessageDialog {

        boolean deleteMeta = false;
        Button radio1;
        Button radio2;

        DeleteProjectDialog(Shell parentShell, IProject[] projects) {
            super(parentShell, getTitle(projects), null, // accept the default window icon
                    getMessage(projects), MessageDialog.QUESTION, new String[] { IDialogConstants.YES_LABEL,
                            IDialogConstants.NO_LABEL }, 0); // yes is the default
        }

        static String getTitle(IProject[] projects) {
            if (projects.length == 1) {
                return Messages.unmapProvider_title;
            }
            return Messages.unmapProvider_titleMulti;
        }

        static String getMessage(IProject[] projects) {
            if (projects.length == 1) {
                IProject project = projects[0];
                return NLS.bind(Messages.unmapProvider_message, project.getName());
            }
            return NLS.bind(Messages.unmapProvider_messageMulti, new Integer(projects.length).toString());
        }

        @Override
        protected Control createCustomArea(Composite parent) {
            Composite composite = new Composite(parent, SWT.NONE);
            composite.setLayout(new GridLayout());
            radio1 = new Button(composite, SWT.RADIO);
            radio1.addSelectionListener(selectionListener);

            radio1.setText(Messages.unmapProvider_keepMeta);

            radio2 = new Button(composite, SWT.RADIO);
            radio2.addSelectionListener(selectionListener);

            radio2.setText(Messages.unmapProvider_nokeepMeta);

            // set initial state
            radio1.setSelection(deleteMeta);
            radio2.setSelection(!deleteMeta);

            // WorkbenchHelp.setHelp(composite, ?);

            return composite;
        }

        private SelectionListener selectionListener = new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                Button button = (Button) e.widget;
                if (button.getSelection()) {
                    deleteMeta = (button == radio1);
                }
            }
        };

        public boolean getDeleteMeta() {
            return deleteMeta;
        }
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        if (confirmDisconnectProjects()) {
            new DisconnectProviderOperation(getActivePart(), getSelectedProjects(), deleteMeta).run();
        }
    }

    boolean confirmDisconnectProjects() {
        IProject[] projects = getSelectedProjects();
        final DeleteProjectDialog dialog = new DeleteProjectDialog(getShell(), projects);
        int result = dialog.open();
        deleteMeta = dialog.getDeleteMeta();
        return result == Window.OK;
    }

}

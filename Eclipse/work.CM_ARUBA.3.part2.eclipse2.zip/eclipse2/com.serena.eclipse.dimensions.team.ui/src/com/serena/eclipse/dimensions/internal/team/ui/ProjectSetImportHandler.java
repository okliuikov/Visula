/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.team.core.ProjectSetSerializationContext;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.SccProjectList;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMProjectLoadInfo;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IProjectSetImportHandler;
import com.serena.eclipse.dimensions.internal.team.ui.operations.AddMultipleProjectsToWorkspaceOperation;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.controls.ConnectionDetailsPanel;
import com.serena.eclipse.dimensions.internal.ui.wizards.ConnectionDetailsPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewConnectionWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/*
 * Resolves connections and launches add to workspace.
 *
 * @author V.Grishchenko
 */
public class ProjectSetImportHandler implements IProjectSetImportHandler {

    public ProjectSetImportHandler() {
    }

    private static class DatabaseLocation {
        String server;
        String db;
        String dbConn;

        DatabaseLocation(DimensionsConnectionDetailsEx connection) {
            server = connection.getServer();
            db = connection.getDbName();
            dbConn = connection.getDbConn();
        }

        DatabaseLocation(DMProjectLoadInfo loadInfo) {
            server = loadInfo.getServer();
            db = loadInfo.getDbName();
            dbConn = loadInfo.getDbConnection();
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof DatabaseLocation) {
                DatabaseLocation otherLoc = (DatabaseLocation) obj;
                return server.equalsIgnoreCase(otherLoc.server) && db.equalsIgnoreCase(otherLoc.db)
                        && dbConn.equalsIgnoreCase(otherLoc.dbConn);
            }
            return false;
        }

        @Override
        public int hashCode() {
            return server.toUpperCase().hashCode() ^ db.toUpperCase().hashCode() ^ dbConn.toUpperCase().hashCode();
        }
    }

    private static class NewLoadConnectionPage extends ConnectionDetailsPage {
        public NewLoadConnectionPage(String pageName, String title, String description, ImageDescriptor titleImage,
                DatabaseLocation loc) {
            super(pageName, title, description, titleImage);
            setHostname(loc.server);
            setDatabase(loc.db);
            setDbConnection(loc.dbConn);
        }

        @Override
        protected ConnectionDetailsPanel createPanel(Composite parent) {
            int options = ConnectionDetailsPanel.SHOW_ALL
                    & ~(ConnectionDetailsPanel.SHOW_KNOWN_CONNECTIONS | ConnectionDetailsPanel.SHOW_WORK_OFFLINE | ConnectionDetailsPanel.SHOW_CONNECT);
            ConnectionDetailsPanel panel = new ConnectionDetailsPanel(parent, SWT.NONE, options,
                    ConnectionDetailsPage.LOAD_CONNECTION);
            // setPageComplete(isAllSet());
            panel.setHostnameEnabled(false);
            panel.setDatabaseEnabled(false);
            panel.setDbConnectionEnabled(false);
            return panel;
        }
    }

    @Override
    public IProject[] addToWorkspace(DMProjectLoadInfo[] loadInfos, ProjectSetSerializationContext context, IProgressMonitor monitor)
            throws CoreException {
        HashMap infosByLocation = new HashMap(loadInfos.length); // dbloc -> {DMProjectSetLoadInfo}
        for (int i = 0; i < loadInfos.length; i++) {
            DatabaseLocation dbLoc = new DatabaseLocation(loadInfos[i]);
            List list = (List) infosByLocation.get(dbLoc);
            if (list == null) {
                list = new ArrayList();
                infosByLocation.put(dbLoc, list);
            }
            list.add(loadInfos[i]);
        }

        DimensionsConnectionDetailsEx[] knownConnections = DMPlugin.getDefault().getKnownLocations();
        HashMap connectionByLocation = new HashMap(knownConnections.length); // dbloc -> DimensionsConnectionDetailsEx
        for (int i = 0; i < knownConnections.length; i++) {
            connectionByLocation.put(new DatabaseLocation(knownConnections[i]), knownConnections[i]);
        }

        HashMap infosByConnection = new HashMap(); // DimensionsConnectionDetailsEx -> {DMProjectSetLoadInfo}
        for (Iterator iter = infosByLocation.entrySet().iterator(); iter.hasNext();) {
            Map.Entry entry = (Map.Entry) iter.next();
            DatabaseLocation dbLoc = (DatabaseLocation) entry.getKey();
            DimensionsConnectionDetailsEx connection = (DimensionsConnectionDetailsEx) connectionByLocation.get(dbLoc);
            if (connection != null) {
                // found matching connection - use it for import for this list
                infosByConnection.put(connection, entry.getValue());
                iter.remove();
            }
        }

        if (!createMissingConnections((Shell) context.getShell(), infosByLocation, infosByConnection)) {
            return new IProject[0];
        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, infosByConnection.size() * 1000);
        try {
            for (Iterator iter = infosByConnection.entrySet().iterator(); iter.hasNext();) {
                Map.Entry entry = (Map.Entry) iter.next();
                DimensionsConnectionDetailsEx connection = (DimensionsConnectionDetailsEx) entry.getKey();
                List list = (List) entry.getValue();
                APIObjectAdapter[] remoteProjects = new APIObjectAdapter[list.size()];
                ProjectMapping[] mappings = new ProjectMapping[list.size()];
                IProgressMonitor subMon = Utils.subMonitorFor(monitor, 100);
                subMon.beginTask(null, mappings.length);
                for (int i = 0; i < mappings.length; i++) {
                    DMProjectLoadInfo loadInfo = (DMProjectLoadInfo) list.get(i);
                    subMon.subTask(NLS.bind(Messages.ProjectSetImportHandler_0,
                            getDescriptionMessage(loadInfo.getRemoteProjectType(), loadInfo.getRemoteProjectId())));
                    VersionManagementProject remoteProject = getRemoteProject(loadInfo, connection);
                    if (remoteProject == null) {
                        throw new CoreException(DMTeamStatus.createErrorStatus(
                                DMTeamStatus.UNKNOWN,
                                getMissingProjectMessage(loadInfo.getRemoteProjectType(), loadInfo.getRemoteProjectId(),
                                        loadInfo.getRemotePath())));
                    }
                    mappings[i] = new ProjectMapping(remoteProject, loadInfo.getLocalProject().getName(), null, Path.EMPTY);
                    remoteProjects[i] = remoteProject;
                    Utils.checkCanceled(subMon);
                    subMon.worked(1);
                }
                subMon.done();
                AddMultipleProjectsToWorkspaceOperation addOperation = new AddMultipleProjectsToWorkspaceOperation(null,
                        remoteProjects, mappings, null) {
                    @Override
                    protected boolean needsPromptForOverwrite(ProjectMapping mapping, IProject project) {
                        return false; // safe to overwrite
                    }
                };
                addOperation.setShell((Shell) context.getShell());
                addOperation.run(Utils.subMonitorFor(monitor, 900));
            }
        } catch (InvocationTargetException e) {
            Throwable target = e.getTargetException();
            if (target instanceof CoreException) {
                // errors from here are handled by Eclipse, make sure we have a trace of it...
                DMTeamUiPlugin.log(((CoreException) target).getStatus());
                throw (CoreException) target;
            }
            String details = target.getMessage();
            if (details == null) {
                details = Utils.EMPTY_STRING;
            }
            throw new DMException(DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN,
                    NLS.bind(Messages.ProjectSetImportHandler_1, details), target));
        } catch (InterruptedException e) {
            return new IProject[0];
        } finally {
            monitor.done();
        }

        IProject[] result = new IProject[loadInfos.length];
        for (int i = 0; i < result.length; i++) {
            result[i] = loadInfos[i].getLocalProject();
        }
        return result;
    }

    // return false if canceled
    private boolean createMissingConnections(Shell shell, Map infoByLocation, Map infosByConnection) {
        if (infoByLocation.isEmpty()) {
            return true; // nothing to do
        }
        for (Iterator iter = infoByLocation.entrySet().iterator(); iter.hasNext();) {
            Map.Entry entry = (Map.Entry) iter.next();
            final DatabaseLocation loc = (DatabaseLocation) entry.getKey();
            List loadInfos = (List) entry.getValue();
            NewConnectionWizard wizard = new NewConnectionWizard() {
                @Override
                protected ConnectionDetailsPage createNewConnectionPage(String id, String title, String desc, ImageDescriptor img) {
                    return new NewLoadConnectionPage(id, title, desc, img, loc);
                }
            };
            wizard.setStrict(true);
            final WizardDialog wizardDialog = new WizardDialog(shell, wizard);
            final int[] holder = new int[1];
            UIUtils.getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    holder[0] = wizardDialog.open();
                }
            });
            if (holder[0] != Window.OK) {
                return false; // canceled
            }
            DimensionsConnectionDetailsEx createdConnection = wizard.getCreatedConnection();
            infosByConnection.put(createdConnection, loadInfos);
        }
        return true;
    }

    private static VersionManagementProject getRemoteProject(final DMProjectLoadInfo loadInfo,
            final DimensionsConnectionDetailsEx connection) throws DMException {
        final VersionManagementProject[] result = new VersionManagementProject[1];
        final Session session = connection.openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                DimensionsObjectFactory factory = session.getObjectFactory();
                if (loadInfo.getRemoteProjectType() == IDMProject.WORKSET) {
                    Project project = factory.getProject(loadInfo.getRemoteProjectId());
                    if (project != null) {
                        result[0] = new WorksetAdapter(project, connection);
                    }
                } else {
                    assert loadInfo.getRemoteProjectType() == IDMProject.BASELINE;
                    Filter filter = new Filter();
                    filter.criteria().add(
                            new Filter.Criterion(SystemAttributes.OBJECT_SPEC, loadInfo.getRemoteProjectId(),
                                    Filter.Criterion.EQUALS));
                    List bl = factory.getBaselines(filter);
                    if (!bl.isEmpty()) {
                        Baseline baseline = (Baseline) bl.get(0);
                        result[0] = new BaselineAdapter(baseline, connection);
                    }
                }
            }
        });
        if (result[0] != null && !loadInfo.getRemotePath().isEmpty()) {
            result[0] = findSccProject(result[0], loadInfo.getRemotePath(), null);
        }
        return result[0];
    }

    private static SccProject findSccProject(APIObjectAdapter container, IPath remoteOffset, IProgressMonitor monitor)
            throws DMException {
        APIObjectAdapter sccContainer = container instanceof WorksetAdapter ? (APIObjectAdapter) new SccProjectContainerWorkset(
                (WorksetAdapter) container) : (APIObjectAdapter) new SccBaselineContainer((BaselineAdapter) container);
        SccProjectList sccProjectList = new SccProjectList(sccContainer);
        sccProjectList.fetch(monitor);
        return sccProjectList.findProject(remoteOffset);
    }

    private static String getMissingProjectMessage(int type, String id, IPath offset) {
        if (offset == null || offset.isEmpty()) {
            return NLS.bind(Messages.ProjectSetImportHandler_2, getDescriptionMessage(type, id));
        }
        return NLS.bind(Messages.ProjectSetImportHandler_4, getDescriptionMessage(type, id), offset.toString());
    }

    private static String getDescriptionMessage(int type, String id) {
        String typeName = IDMProject.WORKSET == type ? DMTypeScope.PROJECT.getDisplayText() : DMTypeScope.BASELINE.getDisplayText();
        return NLS.bind(Messages.ProjectSetImportHandler_3, typeName, id);
    }
}

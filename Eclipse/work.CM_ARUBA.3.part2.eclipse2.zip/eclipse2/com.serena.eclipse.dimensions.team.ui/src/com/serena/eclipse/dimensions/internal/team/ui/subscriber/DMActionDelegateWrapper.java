/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IEditorActionDelegate;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPart;

/**
 * An Action that wraps IActionDelegates so they can be used programatically
 * in toolbars, etc.
 */
public class DMActionDelegateWrapper extends Action implements ISelectionChangedListener {

    private IActionDelegate delegate;

    public DMActionDelegateWrapper(String text, IActionDelegate delegate, ISynchronizePageConfiguration configuration) {
        super(text);
        this.delegate = delegate;
        IWorkbenchPart part = configuration.getSite().getPart();
        if (part != null) {
            if (delegate instanceof IObjectActionDelegate) {
                ((IObjectActionDelegate) delegate).setActivePart(this, part);
            }
            if (part instanceof IViewPart && delegate instanceof IViewActionDelegate) {
                ((IViewActionDelegate) delegate).init((IViewPart) part);
            }
            if (part instanceof IEditorPart && delegate instanceof IViewActionDelegate) {
                ((IEditorActionDelegate) delegate).setActiveEditor(this, (IEditorPart) part);
            }
        }
        initialize(configuration);
    }

    /**
     * Method invoked from the constructor when a configuration is provided.
     * The default implementation registers the action as a selection change
     * listener. Subclass may override.
     * @param configuration the synchronize page configuration
     */
    protected void initialize(final ISynchronizePageConfiguration configuration) {
        configuration.getSite().getSelectionProvider().addSelectionChangedListener(this);
        configuration.getPage().getViewer().getControl().addDisposeListener(new DisposeListener() {
            @Override
            public void widgetDisposed(DisposeEvent e) {
                configuration.getSite().getSelectionProvider().removeSelectionChangedListener(DMActionDelegateWrapper.this);
            }
        });
    }

    @Override
    public void selectionChanged(SelectionChangedEvent event) {
        getDelegate().selectionChanged(this, event.getSelection());
    }

    @Override
    public void run() {
        getDelegate().run(this);
    }

    /**
     * Return the delegate associated with this action.
     * @return the delegate associated with this action
     */
    public IActionDelegate getDelegate() {
        return delegate;
    }

}

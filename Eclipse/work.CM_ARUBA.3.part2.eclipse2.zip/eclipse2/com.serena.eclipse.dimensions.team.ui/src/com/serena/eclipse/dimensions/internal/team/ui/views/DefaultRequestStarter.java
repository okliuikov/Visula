/*
 * Created on 28-Jun-2006
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.serena.eclipse.dimensions.internal.team.ui.views;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author BStephenson
 *
 */
public class DefaultRequestStarter implements ISelectionListener, IPartListener {

    private final boolean[] autoStartHolder = new boolean[1];;

    public DefaultRequestStarter() {
        autoStartHolder[0] = DMTeamUiPlugin.getDefault().isAutoStartDimensionsContext();
        // look for changes
        DMTeamUiPlugin.getDefault().getPreferenceStore().addPropertyChangeListener(new IPropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent e) {
                autoStartHolder[0] = DMTeamUiPlugin.getDefault().isAutoStartDimensionsContext();
            }

        });

    }

    @Override
    public void selectionChanged(IWorkbenchPart part, ISelection selection) {
        if (!autoStartHolder[0]) {
            return;
        }
        // Only handle view selections here as not called in Manifest editor
        if (part instanceof IViewPart) {
            // in a view
            if (selection instanceof IStructuredSelection) {
                Object obj = ((IStructuredSelection) selection).getFirstElement();
                if ((obj != null) && (obj instanceof IAdaptable)) {
                    IResource res = (IResource) ((IAdaptable) obj).getAdapter(IResource.class);
                    if (res != null) {
                        handlePartSelection(part, res);
                    }
                }

            }
        }
    }

    @Override
    public void partActivated(IWorkbenchPart part) {
        if (!autoStartHolder[0]) {
            return;
        }
        if (part instanceof IEditorPart) {
            // an Editor
            IEditorInput editIn = ((IEditorPart) part).getEditorInput();
            if (editIn instanceof IFileEditorInput) {
                handlePartSelection(part, ((IFileEditorInput) editIn).getFile());
            }

        }
    }

    @Override
    public void partBroughtToTop(IWorkbenchPart part) {

    }

    @Override
    public void partClosed(IWorkbenchPart part) {

    }

    @Override
    public void partDeactivated(IWorkbenchPart part) {

    }

    @Override
    public void partOpened(IWorkbenchPart part) {

    }

    private void handlePartSelection(final IWorkbenchPart part, IResource res) {
        // is the view already there return
        if (part.getSite().getPage().findView(DefaultRequestView.VIEW_ID) != null) {
            return;
        }
        IDMProject dmp = getDMProject(res);
        if (dmp != null) {

            DimensionsConnectionDetailsEx con = dmp.getConnection();
            if (con.isOffline() || !con.isSessionOpen()) {
                // do nothing if not connected
                return;
            } else {
                Display.getDefault().asyncExec(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            part.getSite().getPage().showView(DefaultRequestView.VIEW_ID);

                        } catch (PartInitException e) {
                            DMTeamUiPlugin.getDefault().handle(e);
                        }
                    }
                });

            }
        }

    }

    private IDMProject getDMProject(IResource res) {
        DMRepositoryProvider rep = DMRepositoryProvider.getDMProvider(res);
        if (rep != null) {
            IDMProject dmp = null;
            try {
                dmp = rep.getIdmProject();
            } catch (CoreException e) {
            }
            return dmp;

        }
        return null;
    }

}

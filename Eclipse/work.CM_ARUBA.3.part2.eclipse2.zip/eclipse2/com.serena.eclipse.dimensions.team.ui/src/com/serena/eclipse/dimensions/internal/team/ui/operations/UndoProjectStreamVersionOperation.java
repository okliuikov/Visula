package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.text.MessageFormat;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.UndoDeliverCommandDetails;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;

public class UndoProjectStreamVersionOperation extends DMOperation {
    private ChangeSetHistoryView changesetView;
    private UndoDeliverCommandDetails commandDetails;

    public UndoProjectStreamVersionOperation(IWorkbenchPart part, UndoDeliverCommandDetails commandDetails) {
        super(part);
        IWorkbenchPage activePage = UIUtils.getActivePage();
        changesetView = (ChangeSetHistoryView) activePage.findView(ChangeSetHistoryView.ID);
        this.commandDetails = commandDetails;
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
        Project changesetViewProject = changesetView.getProject();
        changesetViewProject.undoDeliver(commandDetails);
        changesetView.refresh();
    }

    @Override
    protected String getTaskName() {
        String changesetViewSourceType = changesetView.getChangesetSourceTypeName().toLowerCase();
        String taskName = MessageFormat.format(Messages.UndoStreamProjectVersionTask,
                (Object[]) new String[] { changesetViewSourceType });
        return taskName;
    }
}

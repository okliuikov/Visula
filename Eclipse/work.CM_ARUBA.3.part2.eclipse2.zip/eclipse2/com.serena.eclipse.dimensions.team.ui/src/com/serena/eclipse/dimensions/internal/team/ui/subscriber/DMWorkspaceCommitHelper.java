/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;

import com.serena.dmclient.api.Part;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.Option;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.ICommitSummary;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.MoveHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.RemoveHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.UploadHelper;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * <P>
 * Helper to create appropriate requests for workspace commit operation.
 * 
 * <P>
 * When overriding:
 * <ul>
 * <li>conflicting additions become outgoing changes
 * <li>conflicting deletions - local metadata is silently deleted
 * <li>conflicting changes become outgoing changes
 * <li>incoming changes become outgoing changes
 * <li>incoming additions become outgoing deletions
 * <li>incoming deletions become outgoing additions
 * </ul>
 * 
 * @author V.Grishchenko
 */
class DMWorkspaceCommitHelper extends DMParticipantOperationHelper implements ICommitSummary {

    private boolean committed;

    private RemoveHelper removeHelper;
    private UploadHelper uploadHelper;
    private MoveHelper moveHelper; // moves w/o local changes
    private MoveHelper chgMoveHelper; // moves w local changes
    protected boolean isStreamHelper;
    protected boolean isShelveHelper;

    private static class Filter implements IDMWorkspaceResourceFilter {
        private Collection<IResource> resources;

        Filter(Collection<IResource> resources) {
            this.resources = resources;
        }

        @Override
        public boolean select(IDMWorkspaceResource resource) throws TeamException {
            return resources.contains(resource.getLocalResource());
        }
    }

    // replace any move sources with move destinations as this is what team.core expects
    private static SyncInfoSet resolveMoves(SyncInfoSet syncInfoSet) throws CoreException {
        IResource[] resources = syncInfoSet.getResources();
        for (int i = 0; i < resources.length; i++) {
            IResource movedTo = DMTeamPlugin.getWorkspace().getMovedTo(resources[i]);
            if (movedTo != null && movedTo.exists()) {
                SyncInfo syncInfo = DMTeamPlugin.getWorkspace().getSubscriber().getSyncInfo(movedTo);
                syncInfoSet.remove(resources[i]);
                if (syncInfo != null) {
                    syncInfoSet.add(syncInfo);
                } else {
                    // this should not happen as move destination would be controlled - has metadata, log and continue
                    DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamUiPlugin.ID, 0, NLS.bind(
                            Messages.DMWorkspaceCommitHelper_4, movedTo.getFullPath().toString()), null));
                }
            }
        }
        return resolveRepositoryMoves(syncInfoSet);
    }

    static SyncInfoSet resolveRepositoryMoves(SyncInfoSet syncInfoSet) throws CoreException {
        IResource[] resources = syncInfoSet.getResources();
        List<IResource> listResources = Arrays.asList(resources);
        for (int i = 0; i < resources.length; i++) {
            IResource movedRes = DMTeamPlugin.getWorkspace().getMovedInRepositoryTo(resources[i]);
            if (movedRes == null) {
                movedRes = DMTeamPlugin.getWorkspace().getMovedInRepositoryFrom(resources[i]);
            }
            if (movedRes != null) {
                if (!listResources.contains(movedRes)) { // user didn't select it
                    SyncInfo syncInfo = DMTeamPlugin.getWorkspace().getSubscriber().getSyncInfo(movedRes);
                    if (syncInfo != null) {
                        DMTeamUiPlugin.log(new Status(IStatus.INFO, DMTeamUiPlugin.ID, 0, NLS.bind(
                                Messages.DMWorkspaceCommitHelper_5, movedRes.getFullPath().toString()), null));
                        syncInfoSet.add(syncInfo);
                    } else {
                        DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamUiPlugin.ID, 0, NLS.bind(
                                Messages.DMWorkspaceCommitHelper_4, movedRes.getFullPath().toString()), null));
                    }
                }
            }
        }
        return syncInfoSet;
    }

    // may modify the passed in info set if it contains moved resources!
    public DMWorkspaceCommitHelper(SyncInfoSet syncInfos, IProgressMonitor monitor) throws CoreException {
        super(resolveMoves(syncInfos), monitor);
        initialize(monitor);
    }

    // may modify the passed in info set if it contains moved resources!
    public DMWorkspaceCommitHelper(SyncInfoSet syncInfos, boolean isStreamHelper, boolean isShelveHelper, IProgressMonitor monitor)
            throws CoreException {
        super(resolveMoves(syncInfos), monitor);
        this.isStreamHelper = isStreamHelper;
        this.isShelveHelper = isShelveHelper;
        initialize(monitor);
    }

    public boolean hasDeletions() {
        if (removeHelper != null) {
            return removeHelper.getOperationResources().length != 0;
        }
        return false;
    }

    public boolean hasAdditions() {
        // answer about files only as this is used in the commit wizard to create appropriate ui
        if (uploadHelper != null) {
            return uploadHelper.isCreateNewItems();
        }
        return false;
    }

    public boolean hasCheckins() {
        if (uploadHelper != null) {
            return uploadHelper.hasCheckins();
        }
        return false;
    }

    public boolean hasOptimisticCheckins() {
        if (uploadHelper != null) {
            return uploadHelper.hasOptimisticCheckins();
        }
        return false;
    }

    public boolean isCreateNewRevisions() {
        return hasOptimisticCheckins() || hasAdditions();
    }

    public boolean hasMoves() {
        if (moveHelper != null) {
            return moveHelper.getOperationResources().length != 0 || chgMoveHelper.getOperationResources().length != 0;
        }
        return false;
    }

    @Override
    public WorkspaceResourceRequest getRequest(IResource resource) {
        if (committed && uploadHelper != null) {
            // upload helper only returns upload requests when committed
            WorkspaceResourceRequest request = uploadHelper.getRequest(resource);
            if (request != null) {
                return request;
            }
        }
        return super.getRequest(resource);
    }

    public IDMWorkspaceResource[] getCleanedCheckouts() {
        if (uploadHelper != null) {
            return uploadHelper.getCleanedCheckouts();
        }
        return new IDMWorkspaceResource[0];
    }

    @Override
    protected void populateMaps(Map<IResource, WorkspaceResourceRequest> requests, Map<IResource, IAttributeModel> attributes,
            IDMWorkspaceResource[] resources, IProgressMonitor monitor) throws CoreException {

        // sort outgoing into 4 baskets:
        List<IResource> additions = new ArrayList<IResource>();
        List<IResource> changes = new ArrayList<IResource>();
        List<IResource> deletions = new ArrayList<IResource>();
        List<IResource> moves = new ArrayList<IResource>();
        List<IResource> chgMoves = new ArrayList<IResource>();

        for (int i = 0; i < resources.length; i++) {
            IResource local = resources[i].getLocalResource();
            if (DMTeamPlugin.getWorkspace().isMoved(local)
                    && getSyncInfo(local).getKind() != (SyncInfo.DELETION | SyncInfo.OUTGOING)) {
                if (local.getType() == IResource.FILE) {
                    if (DMTeamPlugin.getWorkspace().isModified(local)) {
                        changes.add(local);
                        chgMoves.add(local);
                    } else {
                        moves.add(local);
                    }
                } else {
                    moves.add(local);
                }
                continue;
            }

            SyncInfo syncInfo = getSyncInfo(local);
            if (syncInfo == null) { // shouldn't happen, log and continue
                DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamUiPlugin.ID, 0, NLS.bind(Messages.DMWorkspaceCommitHelper_4,
                        local.getFullPath().toString()), null));
                continue;
            }
            int kind = syncInfo.getKind();
            int changeType = kind & SyncInfo.CHANGE_MASK;
            int changeDirection = kind & SyncInfo.DIRECTION_MASK;
            switch (changeDirection) {
            case SyncInfo.OUTGOING: // not conflicting outgoing are put into proper baskets
                switch (changeType) {
                case SyncInfo.ADDITION:
                    additions.add(local);
                    break;
                case SyncInfo.DELETION:
                    deletions.add(local);
                    break;
                case SyncInfo.CHANGE:
                    if (local.getType() == IResource.FILE) {
                        changes.add(local);
                    }
                    break;
                }
                break;
            case SyncInfo.INCOMING: // incoming are converted to outgoing
                switch (changeType) {
                case SyncInfo.ADDITION:
                    deletions.add(local);
                    break;
                case SyncInfo.DELETION:
                    additions.add(local);
                    break;
                case SyncInfo.CHANGE:
                    if (local.getType() == IResource.FILE) {
                        changes.add(local);
                    }
                    break;
                }
                break;
            case SyncInfo.CONFLICTING: // conflicts are outgoing
                switch (changeType) {
                case SyncInfo.DELETION:
                    DMTeamPlugin.getWorkspace().unmanage(local, null); // no use for zombie
                    break;
                case SyncInfo.ADDITION: // conflicting addition will be checked in
                    if (local.getType() == IResource.FILE) {
                        changes.add(local);
                    }
                    break;
                case SyncInfo.CHANGE:
                    if (local.getType() == IResource.FILE) {
                        // handle obscure conflicting changes
                        if (syncInfo.getRemote() == null) {
                            additions.add(local); // local change as compared to metadata and no remote is an addition
                        } else if (!local.exists()) {
                            deletions.add(local); // remote change as compared to metadata and no local is a deletion
                        } else {
                            changes.add(local); // got a vanilla conflicting change
                        }
                    }
                    break;
                }
                break;
            }

        }

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, (additions.size() + deletions.size() + changes.size() + chgMoves.size() + moves.size()) * 1000);

        if (!deletions.isEmpty()) {
            removeHelper = new RemoveHelper(toResourceArray(deletions), new Filter(deletions), Utils.subMonitorFor(monitor,
                    deletions.size() * 1000), true);
            copyRequests(removeHelper, requests);
        }

        if (!changes.isEmpty() || !additions.isEmpty()) {
            List<IResource> uploads = new ArrayList<IResource>(changes.size() + additions.size());
            uploads.addAll(additions);
            uploads.addAll(changes);
            uploadHelper = new UploadHelper(toResourceArray(uploads), new Filter(uploads), Utils.subMonitorFor(monitor,
                    (changes.size() + additions.size()) * 1000));
            setCommentRequired(isCommentRequired() || uploadHelper.isCommentRequired());
            copyRequests(uploadHelper, requests);
            if (isShelveHelper) {
                for (WorkspaceResourceRequest request : requests.values()) {
                    request.setRequestMandatory(false);
                }
            }
            copyAttributeModels(uploadHelper, attributes);
            excludeFiles(uploadHelper.getExcudedFiles());
            status = uploadHelper.getStatus();
        }

        if (!chgMoves.isEmpty()) {
            chgMoveHelper = new MoveHelper(toResourceArray(chgMoves), new Filter(chgMoves), Utils.subMonitorFor(monitor,
                    chgMoves.size() * 1000));
            IResource[] crossSrc = chgMoveHelper.getCrossProjectMoveSources();
            if (crossSrc.length > 0) {
                copyRequests(crossSrc, chgMoveHelper, requests);
                combineResources(chgMoveHelper.getOperationResources());
            }
        }

        if (!moves.isEmpty()) {
            moveHelper = new MoveHelper(toResourceArray(moves), new Filter(moves),
                    Utils.subMonitorFor(monitor, moves.size() * 1000));
            copyRequests(moveHelper, requests);
            combineResources(moveHelper.getOperationResources());
        }
    }

    @Override
    public boolean includePhantoms() {
        return true;
    }

    @Override
    public void commit() throws CoreException {
        super.commit();
        if (uploadHelper != null) {
            uploadHelper.setComment(getComment());
            uploadHelper.commit();
        }
        if (chgMoveHelper != null) { // copy requests selected for uploads onto their corresponding moves, if any
            chgMoveHelper.setComment(getComment());
            chgMoveHelper.commit(); // this will set requests for project remove if cross-project
            excludeFiles(chgMoveHelper.getCrossProjectMoveSources());
            if (uploadHelper != null) {
                IResource[] chgMoveResources = chgMoveHelper.getOperationResources();
                for (int i = 0; i < chgMoveResources.length; i++) {
                    WorkspaceResourceRequest uploadRequest = uploadHelper.getRequest(chgMoveResources[i]);
                    WorkspaceResourceRequest moveRequest = chgMoveHelper.getRequest(chgMoveResources[i]);
                    if (uploadRequest != null && moveRequest != null) {
                        moveRequest.setChangeRequests(uploadRequest.getChangeRequests());
                    }
                }
            }
        }
        if (moveHelper != null) {
            moveHelper.setComment(getComment());
            moveHelper.commit(); // this will set requests for project remove if cross-project
            excludeFiles(moveHelper.getCrossProjectMoveSources());
        }
        committed = true;
    }

    /**
     * @return helper containing move information for resources that are also to
     *         be checked in or <code>null</code> if there are no such
     *         resources
     */
    public MoveHelper getChangeMoveHelper() {
        return chgMoveHelper;
    }

    @Override
    protected Option[] createOptions() {
        if (uploadHelper == null) {
            return new Option[0];
        }
        if (isStreamHelper) {
            return new Option[0]; // options not required for streams
        }
        return uploadHelper.getOptions();
    }

    @Override
    public List<Part> getParts() {
        if (uploadHelper != null) {
            return uploadHelper.getParts();
        }
        return super.getParts();
    }

    @Override
    public void setSelectedResources(IResource[] newSelection) throws CoreException {
        // update contained helpers
        List<IResource> uploads = new ArrayList<IResource>();
        List<IResource> deletions = new ArrayList<IResource>();
        List<IResource> moves = new ArrayList<IResource>();
        List<IResource> chgMoves = new ArrayList<IResource>();

        for (int i = 0; i < newSelection.length; i++) {
            if (uploadHelper != null && uploadHelper.getRequest(newSelection[i]) != null) {
                uploads.add(newSelection[i]);
            }
            if (removeHelper != null && removeHelper.getRequest(newSelection[i]) != null) {
                deletions.add(newSelection[i]);
            }
            if (chgMoveHelper != null && chgMoveHelper.getRequest(newSelection[i]) != null) {
                chgMoves.add(newSelection[i]);
            }
            if (moveHelper != null && moveHelper.getRequest(newSelection[i]) != null) {
                moves.add(newSelection[i]);
            }
        }

        if (uploadHelper != null) {
            uploadHelper.setSelectedResources(uploads.toArray(new IResource[uploads.size()]));
        }
        if (removeHelper != null) {
            removeHelper.setSelectedResources(deletions.toArray(new IResource[deletions.size()]));
        }
        if (chgMoveHelper != null) {
            chgMoveHelper.setSelectedResources(chgMoves.toArray(new IResource[chgMoves.size()]));
        }
        if (moveHelper != null) {
            moveHelper.setSelectedResources(moves.toArray(new IResource[moves.size()]));
        }

        super.setSelectedResources(newSelection);
    }

    @Override
    public int getAdditionCount() {
        if (uploadHelper != null) {
            return uploadHelper.getAdditionCount();
        }
        return 0;
    }

    @Override
    public int getCheckinCount() {
        if (uploadHelper != null) {
            return uploadHelper.getCheckinCount();
        }
        return 0;
    }

    @Override
    public int getDeletionCount() {
        if (removeHelper != null) {
            return removeHelper.getOperationResources().length;
        }
        return 0;
    }

    @Override
    public int getMoveCount() {
        // do not count x-project moves twice, if any
        int result = 0;
        if (moveHelper != null) {
            IResource[] ress = moveHelper.getOperationResources();
            for (int i = 0; i < ress.length; i++) {
                if (ress[i].exists()) {
                    result++;
                }
            }
        }
        if (chgMoveHelper != null) {
            IResource[] ress = chgMoveHelper.getOperationResources();
            for (int i = 0; i < ress.length; i++) {
                if (ress[i].exists()) {
                    result++;
                }
            }
        }
        return result;
    }

    @Override
    public int getOptimisticCheckinCount() {
        if (uploadHelper != null) {
            return uploadHelper.getOptimisticCheckinCount();
        }
        return 0;
    }

    @Override
    public String getErrorMessage() {
        if (uploadHelper != null) {
            return uploadHelper.getErrorMessage();
        }
        return super.getErrorMessage();
    }

}

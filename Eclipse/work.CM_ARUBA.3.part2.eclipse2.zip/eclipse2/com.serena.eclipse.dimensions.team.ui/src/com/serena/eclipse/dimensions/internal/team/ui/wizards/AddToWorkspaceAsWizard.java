/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.NewProjectAction;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.team.ui.operations.AddMultipleProjectDirsToWorkspaceOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.AddSingleProjectDirToWorkspaceOperation;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Adds remote project to workspace with options.
 *
 * @author V.Grishchenko
 */
public class AddToWorkspaceAsWizard extends DimensionsWizard {

    public enum SelectionType {
        /**
         * Represents selection that can be narrowed by nested projects
         */
        HASCHILD_SELECTION,
        /**
         * Represents a direct selection of nodes
         */
        DIRECT_SELECTION
    }

    public static final String ADD_TO_WORKSPACE_LOCATION_PAGE_PARENT_ID = "add_to_workspace_location_page_container_id"; //$NON-NLS-1$
    public static final String ADD_TO_WORKSPACE_LOCATION_PAGE_CHILD_ID = "add_to_workspace_location_page_child_id"; //$NON-NLS-1$

    private ProjectMapping[] mappings;
    private ProjectMapping container;

    // initial selection type
    private SelectionType baseSelType = SelectionType.DIRECT_SELECTION;

    private AddToWorkspaceAsMainPage mainPage;
    private AddToWorkspaceAsLocationSelectionPage mappingsLocationPage;
    private AddToWorkspaceAsLocationSelectionPage containerLocationPage;
    private NewWorksetGroupContentsPage<ProjectMapping> groupPage;
    private AddToWorkspaceAsSwitchSelectionTypePage selectionTypePage;
    private IWorkbenchPart part;

    private static class NewProjectListener implements IResourceChangeListener {
        private IProject newProject = null;

        @Override
        public void resourceChanged(IResourceChangeEvent event) {
            IResourceDelta root = event.getDelta();
            IResourceDelta[] projectDeltas = root.getAffectedChildren();
            for (int i = 0; i < projectDeltas.length; i++) {
                IResourceDelta delta = projectDeltas[i];
                IResource resource = delta.getResource();
                if (delta.getKind() == IResourceDelta.ADDED) {
                    newProject = (IProject) resource;
                }
            }
        }

        /**
         * Gets the newProject.
         *
         * @return IProject
         */
        public IProject getNewProject() {
            // make sure it still exists, e.g. Java prj wizard creates prj then deletes it if
            // cancelled!
            if (newProject != null && newProject.exists()) {
                return newProject;
            }
            return null;
        }
    }

    /**
     * Creates a new "add to workspace as" wizard.
     *
     * @param part
     * @param mappings
     */
    public AddToWorkspaceAsWizard(IWorkbenchPart part, ProjectMapping[] mappings) {
        Assert.isLegal(mappings != null && mappings.length > 0);
        this.part = part;
        this.mappings = mappings;
        setWindowTitle(Messages.AddToWorkspaceAsWizard_title);
        setDefaultPageImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN));
    }

    /**
     * Creates a new "add to workspace as" wizard with possibility to fetch mappings or mappings
     * parent container
     *
     * @param part
     * @param containerMapping
     * @param mappings
     */
    public AddToWorkspaceAsWizard(IWorkbenchPart part, ProjectMapping containerMapping, ProjectMapping[] mappings) {
        this(part, mappings);
        Assert.isLegal(containerMapping != null);
        this.container = containerMapping;
        this.baseSelType = SelectionType.HASCHILD_SELECTION;
    }

    @Override
    public void addPages() {
        if (baseSelType == SelectionType.HASCHILD_SELECTION) {
            this.selectionTypePage = new AddToWorkspaceAsSwitchSelectionTypePage();
            addPage(selectionTypePage);

            this.groupPage = new NewWorksetGroupContentsPage<ProjectMapping>(NewWorksetGroupContentsPage.GROUP_CONTENTS_PAGE_ID,
                    Messages.addGroupToWorkspace_title, Messages.addGroupToWorkspace_description, DMUIPlugin.getDefault()
                            .getImageDescriptor(IDMImages.LOGIN_WIZBAN), mappings,
                    !(container.getRemoteProject() instanceof DimensionsIDEProjectGroup));
            addPage(groupPage);

            if (container.getProjectDescription() == null) {
                this.mainPage = new AddToWorkspaceAsMainPage(new ProjectMapping[] { container, }, true);
                addPage(mainPage);
            }

            this.mappingsLocationPage = new AddToWorkspaceAsLocationSelectionPage(ADD_TO_WORKSPACE_LOCATION_PAGE_CHILD_ID, mappings);
            addPage(mappingsLocationPage);

            ProjectMapping[] parent = new ProjectMapping[] { container, };
            this.containerLocationPage = new AddToWorkspaceAsLocationSelectionPage(ADD_TO_WORKSPACE_LOCATION_PAGE_PARENT_ID, parent);
            addPage(containerLocationPage);
        } else if (baseSelType == SelectionType.DIRECT_SELECTION) {
            // show first page only if there are projects without .project markers
            if (isNameChangesAllowed()) {
                // if single project and no remote .project file allow new project wizard
                boolean allowConfiguration = isSingleProject() && getSingleMapping().getProjectDescription() == null;
                this.mainPage = new AddToWorkspaceAsMainPage(mappings, allowConfiguration);
                addPage(mainPage);
            }

            this.mappingsLocationPage = new AddToWorkspaceAsLocationSelectionPage(mappings);
            addPage(mappingsLocationPage);
        }
    }

    private boolean isSingleProject() {
        return mappings.length == 1;
    }

    private ProjectMapping getSingleMapping() {
        return mappings[0];
    }

    private boolean isNameChangesAllowed() {
        for (int i = 0; i < mappings.length; i++) {
            if (mappings[i].getProjectDescription() == null) {
                return true;
            }
        }
        return false;
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page) {
        if (page == mainPage && mainPage.useNewProjectWizardSelected()) {
            return null;
        }

        if (baseSelType == SelectionType.HASCHILD_SELECTION) {
            SelectionType curSelType = selectionTypePage.getSelectionType();
            IWizardPage nextPage = null;
            if (page == selectionTypePage) {
                switch (curSelType) {
                case HASCHILD_SELECTION:
                    nextPage = groupPage;
                    break;
                case DIRECT_SELECTION:
                    if (mainPage != null) {
                        nextPage = mainPage;
                    } else {
                        nextPage = containerLocationPage;
                    }
                    break;
                default:
                    break;
                }

                if (nextPage != null) {
                    return nextPage;
                }
            }

            IWizardPage currentPage = getContainer().getCurrentPage();
            if (currentPage == groupPage) {
                return mappingsLocationPage;
            }

            if (currentPage == mainPage) {
                return containerLocationPage;
            }
        } else if (baseSelType == SelectionType.DIRECT_SELECTION) {
            return super.getNextPage(page);
        }

        return null;
    }

    @Override
    public boolean canFinish() {
        SelectionType curSelType = baseSelType;
        if (selectionTypePage != null) {
            curSelType = selectionTypePage.getSelectionType();
        }

        if (curSelType == SelectionType.HASCHILD_SELECTION) {
            if (!groupPage.isPageComplete() || !mappingsLocationPage.isPageComplete()) {
                return false;
            }
        } else if (curSelType == SelectionType.DIRECT_SELECTION) {
            if (mainPage != null) {
                if (!mainPage.isPageComplete()) {
                    return false;
                }

                if (mainPage.useNewProjectWizardSelected()) {
                    return true;
                }
            }

            if (baseSelType == SelectionType.HASCHILD_SELECTION) {
                if (!containerLocationPage.isPageComplete()) {
                    return false;
                }
            } else if (baseSelType == SelectionType.DIRECT_SELECTION) {
                if (!mappingsLocationPage.isPageComplete()) {
                    return false;
                }
            }
        }

        return true;
    }

    @Override
    public boolean performFinish() {
        try {
            SelectionType curSelType = baseSelType;
            if (selectionTypePage != null) {
                curSelType = selectionTypePage.getSelectionType();
            }

            if (baseSelType == SelectionType.DIRECT_SELECTION) {
                if (mainPage != null && mainPage.useNewProjectWizardSelected()) {
                    return addWithNewWizard(mappings, mappingsLocationPage, part);
                } else if (isSingleProject()) {
                    return addSingleProject(mappings, mappingsLocationPage, part);
                } else {
                    return addMultipleProjects(mappings, mappingsLocationPage, part);
                }
            } else if (baseSelType == SelectionType.HASCHILD_SELECTION) {
                if (curSelType == SelectionType.HASCHILD_SELECTION) {
                    if (isSingleProject()) {
                        return addSingleProject(mappings, mappingsLocationPage, part);
                    } else {
                        List<ProjectMapping> contents = groupPage.getContents();
                        return addMultipleProjects(contents.toArray(new ProjectMapping[contents.size()]), mappingsLocationPage,
                                part);
                    }
                } else if (curSelType == SelectionType.DIRECT_SELECTION) {
                    if (mainPage != null && mainPage.useNewProjectWizardSelected()) {
                        return addWithNewWizard(new ProjectMapping[] { container, }, containerLocationPage, part);
                    } else {
                        return addSingleProject(new ProjectMapping[] { container, }, containerLocationPage, part);
                    }
                }
            }
        } catch (InterruptedException ignore) {
        } catch (InvocationTargetException e) {
            handle(e);
        }
        return false;
    }
    
    private void handle(Throwable e) {
        DMTeamUiPlugin.getDefault().handle(e);
    }

    private static boolean addMultipleProjects(ProjectMapping[] mappings, AddToWorkspaceAsLocationSelectionPage location,
            IWorkbenchPart part) throws InterruptedException, InvocationTargetException {
        APIObjectAdapter[] remoteObjects = new APIObjectAdapter[mappings.length];
        for (int i = 0; i < mappings.length; i++) {
            if (location.createUnderCompatibleWorkArea()) {
                mappings[i].setWorkAreaRoot(location.getCompatibleWorkArea());
            }
            remoteObjects[i] = mappings[i].getRemoteProject();
        }

        AddMultipleProjectDirsToWorkspaceOperation operation = new AddMultipleProjectDirsToWorkspaceOperation(part, remoteObjects,
                mappings, location.getTargetLocation());
        operation.run();
        return true;
    }

    private static boolean addSingleProject(ProjectMapping[] mappings, AddToWorkspaceAsLocationSelectionPage location,
            IWorkbenchPart part) throws InterruptedException, InvocationTargetException {
        if (location.createUnderCompatibleWorkArea()) {
            mappings[0].setWorkAreaRoot(location.getCompatibleWorkArea());
        }
        AddSingleProjectDirToWorkspaceOperation operation = new AddSingleProjectDirToWorkspaceOperation(part, mappings[0],
                location.getTargetLocation());
        operation.run();
        return true;
    }

    private static boolean addWithNewWizard(ProjectMapping[] mappings, AddToWorkspaceAsLocationSelectionPage location,
            IWorkbenchPart part) throws InterruptedException, InvocationTargetException {
        IProject newProject = getNewProject();
        if (newProject == null) {
            return false;
        }
        mappings[0].setLocalProjectName(newProject.getName());
        AddSingleProjectDirToWorkspaceOperation operation = new AddSingleProjectDirToWorkspaceOperation(part, mappings[0],
                location.getTargetLocation());
        operation.setPreconfigured(true);
        operation.setTargetProject(newProject);
        operation.run();
        return true;
    }

    /**
     * Get a new project that is configured by the new project wizard. This is currently the only
     * way to do this.
     */
    private static IProject getNewProject() {
        NewProjectListener listener = new NewProjectListener();
        ResourcesPlugin.getWorkspace().addResourceChangeListener(listener, IResourceChangeEvent.POST_CHANGE);
        (new NewProjectAction(PlatformUI.getWorkbench().getActiveWorkbenchWindow())).run();
        ResourcesPlugin.getWorkspace().removeResourceChangeListener(listener);
        IProject project = listener.getNewProject();
        return project;
    }
}

/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2018 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.sbm.ISBMRequest;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.RemoveFromWorkspaceDialog;
import com.serena.eclipse.dimensions.internal.team.ui.operations.AddMultipleProjectDirsToWorkspaceOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.AddSingleProjectDirToWorkspaceOperation;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.util.SpecUtils;

public class NewStreamTopicWorkareaPage extends LocationPage {

    private class StateHolder {
        private PostCreationOptions options;
        private PostCreationMode mode;

        public StateHolder(PostCreationOptions options, PostCreationMode mode) {
            forceOptions(options);
            if (!trySetMode(mode)) {
                forceMode(PostCreationMode.NONE);
            }
        }

        public PostCreationOptions getOptions() {
            return options;
        }

        public boolean trySetOptions(PostCreationOptions options) {
            if (!canApply(options)) {
                return false;
            }
            forceOptions(options);
            if (!trySetMode(mode)) {
                forceMode(PostCreationMode.NONE);
            }
            return true;
        }

        public PostCreationMode getMode() {
            return mode;
        }

        public boolean trySetMode(PostCreationMode mode) {
            if (!canApply(mode)) {
                return false;
            }
            forceMode(mode);
            return true;
        }

        private boolean canApply(PostCreationOptions options) {
            return this.options != PostCreationOptions.HIDDEN;
        }
        
        private boolean canApply(PostCreationMode mode) {
            switch (options) {
            case ALL:
                return true;

            case DISABLED:
            case HIDDEN:
                return mode == PostCreationMode.NONE;

            case NO_REHOME:
                return mode != PostCreationMode.REHOME;

            default:
                return false;
            }
        }

        private void forceOptions(PostCreationOptions options) {
            this.options = options;
        }

        private void forceMode(PostCreationMode mode) {
            this.mode = mode;
        }
    }

    public enum PostCreationMode {
        NONE, REHOME, ADD_TO_WORKSPACE
    }

    public enum PostCreationOptions {
        ALL,
        // 'rehome' is disabled (and unchecked)
        NO_REHOME,
        // only 'dont add to workspace' is enabled (and checked)
        DISABLED,
        // none of options are visible to user
        HIDDEN
    }

    private boolean stateChanging = false;
    private StateHolder stateHolder;

    private Text txtStreamName;
    private Combo comboProduct;
    private Label lblParenStream;
    private Text txtBasedOnStreamSpec;
    private Text txtRequestIds;
    private Button findWorksetButton;
    private Label lblOptions;
    private Button radioRehomeWorkArea;
    private Label labelProjectToRehome;
    private Combo comboProjectToRehome;
    private Button radioAddToWorkArea;
    private Text txtAddToWorkArea;
    private Button browseLocationButton;
    private Button radioDontAddToWorkArea;
    private Composite optionsComposite;
    private Project baseProject;
    private HashMap<String, IPath> keyToWorkAreas = new HashMap<String, IPath>();
    private HashMap<IPath, List<IDMProject>> waCandidatesToRehome = new HashMap<IPath, List<IDMProject>>();
    private IPath workAreaToRehome;
    private NewStreamWizard wizard;
    private AdvancedWorkAreaSettings advancedSettings = new AdvancedWorkAreaSettings(false);
    private IProject project;
    
    private String lastValidatedRequestIds = "";
    private String lastRequestIdsValidationMessage = "";
    private String lastValidatedProjectSpec = "";
    private String lastProjectSpecValidationMessage = "";
    private final VerifyListener upperCaseMaker = new VerifyListener() {
        @Override
        public void verifyText(VerifyEvent e) {
            e.text = e.text.toUpperCase();
        }
    };
    
    public NewStreamTopicWorkareaPage(String pageName, ProjectMapping[] mappings) {
        super(pageName, mappings);
        setTitle("Topic Stream Details");
        setImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN));
        setDescription(
                "Give your new stream a name and choose the work area. The changes can be auto-merged into the parent stream.");

        stateHolder = new StateHolder(PostCreationOptions.ALL, PostCreationMode.REHOME);
    }
    
    public NewStreamTopicWorkareaPage(String pageName, ProjectMapping[] mappings, boolean showAdvancedSettings, IProject project) {
        this(pageName, mappings);
        this.project = project;
        advancedSettings.setAllowed(showAdvancedSettings);
    }


    public PostCreationMode getPostCreationMode() {
        return stateHolder.getMode();
    }

    @Override
    public void createControl(Composite parent) {
        wizard = (NewStreamWizard) getWizard();

        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);
        
        Composite compositeStreamSpec = new Composite(composite, SWT.NONE);
        
        GridLayout gridLayout = UIUtils.setGridLayout(compositeStreamSpec, 2);
        gridLayout.marginHeight = 0;
        gridLayout.marginWidth = 0;
        
        GridData gridData = new GridData(GridData.FILL_HORIZONTAL | GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_BEGINNING);
        compositeStreamSpec.setLayoutData(gridData);
        
        Label labelProductDescription = new Label(compositeStreamSpec, SWT.NONE);
        labelProductDescription.setText("Product:");

        Label lblStreamName = new Label(compositeStreamSpec, SWT.NONE);
        UIUtils.setGridData(lblStreamName, GridData.FILL_HORIZONTAL);
        lblStreamName.setText("Stream name:");

        comboProduct = new Combo(compositeStreamSpec, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
        try {
            for (String productName : Utils.getProductNames(wizard.getConnection())) {
                comboProduct.add(productName);
            }
            if (comboProduct.getItemCount() > 0) {
                String product = SpecUtils.getProduct(getWizardBasedOnStreamSpec());
                if (!Utils.isNullEmpty(product)) {
                    comboProduct.select(comboProduct.indexOf(product));
                }
            }
            if (Utils.isNullEmpty(comboProduct.getText())) {
                comboProduct.select(0);
            }

        } catch (Exception e) {
            setErrorMessage(e.getMessage());
        }
        
        // set the minimum width so it fits longest allowed product 'WWWWWWWWWW'
        if (comboProduct.computeSize(SWT.DEFAULT, SWT.DEFAULT, false).x < 139) {
            gridData = UIUtils.setGridData(comboProduct, SWT.NONE);
            gridData.widthHint = 113;
        }
        
        comboProduct.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                changePath();
                if (advancedSettings.getAllowed()) {
                    advancedSettings.fillPartCombo();
                }
                checkPage();
            }
        });
        
        txtStreamName = new Text(compositeStreamSpec, SWT.BORDER);
        UIUtils.setGridData(txtStreamName, GridData.FILL_HORIZONTAL);

        String topicName = getBasedOnRequestId();
        String basedOnStreamSpec = getWizardBasedOnStreamSpec();
        setBaseProject();

        if (!Utils.isNullEmpty(basedOnStreamSpec)) {
            topicName = topicName.replaceFirst(SpecUtils.getProduct(basedOnStreamSpec), "");
        } else {
            basedOnStreamSpec = "";
            topicName = topicName.replaceFirst(getProductName(), "");
        }
        
        while (topicName.startsWith("_"))
            topicName = topicName.replaceFirst("_", "");
        txtStreamName.setText(topicName);
        txtStreamName.addVerifyListener(upperCaseMaker);
        txtStreamName.addModifyListener(new ModifyListener() {
            @Override
			public void modifyText(ModifyEvent e) {
				changePath();
				checkPage();
			}
        });

        addBasedOnStreamControls(composite, basedOnStreamSpec);
        
        if (advancedSettings.getAllowed()) {
            advancedSettings.init(this, composite, project);
            advancedSettings.addChangeListener(new ChangeListener() {
                
                @Override
                public void stateChanged(ChangeEvent e) {
                    checkPage();
                }
            });
        }

        optionsComposite = new Composite(composite, SWT.NONE);
        
        lblOptions = new Label(optionsComposite, SWT.NONE);
        UIUtils.setGridData(lblOptions, GridData.FILL_HORIZONTAL);
        lblOptions.setText("When the new stream is created:");
        ((GridData) lblOptions.getLayoutData()).horizontalSpan = 3;

        gridData = new GridData(GridData.FILL_BOTH | GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_BEGINNING);
        optionsComposite.setLayoutData(gridData);

        gridLayout = UIUtils.setGridLayout(optionsComposite, 3);
        gridLayout.marginHeight = 0;
        gridLayout.marginWidth = 0;

        SelectionListener selectionListener = new SelectionAdapter() {
            public void widgetSelected(SelectionEvent event) {
                Button button = ((Button) event.widget);
                if (!button.getSelection())
                    return;

                if (button == radioRehomeWorkArea) {
                    applyState(PostCreationMode.REHOME);
                } else if (button == radioAddToWorkArea) {
                    applyState(PostCreationMode.ADD_TO_WORKSPACE);
                } else {
                    applyState(PostCreationMode.NONE);
                }
            };
        };

        radioRehomeWorkArea = new Button(optionsComposite, SWT.RADIO);
        radioRehomeWorkArea.setText(Messages.RehomeExistingProjectsIn);
        radioRehomeWorkArea.addSelectionListener(selectionListener);

        labelProjectToRehome = new Label(optionsComposite, SWT.NONE);
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        labelProjectToRehome.setLayoutData(gridData);
        
        comboProjectToRehome = new Combo(optionsComposite, SWT.NONE | SWT.READ_ONLY);
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        comboProjectToRehome.setLayoutData(gridData);
        comboProjectToRehome.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
                setProjectToRehome(comboProjectToRehome.getText());
            }
        });
        
        radioAddToWorkArea = new Button(optionsComposite, SWT.RADIO);
        radioAddToWorkArea.setText(Messages.AddToWorkspace);
        radioAddToWorkArea.addSelectionListener(selectionListener);

        txtAddToWorkArea = new Text(optionsComposite, SWT.BORDER);
        UIUtils.setGridData(txtAddToWorkArea, GridData.FILL_HORIZONTAL | GridData.GRAB_HORIZONTAL);
        
        txtAddToWorkArea.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                verifyLocation();
            }
        });
        
        browseLocationButton = new Button(optionsComposite, SWT.NONE);
        browseLocationButton.setText(Messages.SelectWithThreeDots);
        browseLocationButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                proceedWithDirectoryDialog();
            }
        });
        
        radioDontAddToWorkArea = new Button(optionsComposite, SWT.RADIO);
        radioDontAddToWorkArea.setText(Messages.DoNotAddToWorkspace);
        radioDontAddToWorkArea.addSelectionListener(selectionListener);

        txtStreamName.setSelection(txtStreamName.getText().length());
        setControl(composite);
        txtAddToWorkArea.getShell().layout(true, true);
        
        if (wizard instanceof SharingWizard) {
            applyState(PostCreationOptions.HIDDEN);
        }
        verifyRehomeAbility();
    }
    
    private boolean validateRequests() {
        final boolean[] result = new boolean[] { true };
        run(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    monitor.beginTask("Validating requests...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
                    DimensionsObjectFactory factory = wizard.getConnection().openSession(monitor).getObjectFactory();
                    for (String requestId : getRelatedRequests()) {
                        Object request = null;
                        if (wizard.getConnection().isIdmRequestProvider()) {
                            @SuppressWarnings("unchecked")
                            List<Object> list = factory.findIDMRequestsByName(Arrays.asList(requestId));
                            if (!list.isEmpty()) {
                                request = list.get(0);
                            }
                        } else {
                            request = factory.findRequest(requestId);
                        }
                        if (request == null) {
                            result[0] = false;
                            lastRequestIdsValidationMessage = NLS.bind(Messages.RequestDoesNotExist, requestId);
                            return;
                        }
                    }
                } catch (DMException e) {
                    DMUIPlugin.getDefault().handle(e);
                } finally {
                    monitor.setTaskName(Utils.EMPTY_STRING);
                    monitor.subTask(Utils.EMPTY_STRING);
                    monitor.done();
                }
            }

        }, false);
        lastValidatedRequestIds = UIUtils.safeGetText(txtRequestIds);
        if (result[0] == true) {
            lastRequestIdsValidationMessage = "";
        }
        checkPage();
        return result[0];
    }

    private boolean validateBasedOnProject() {

        final String fullSpec = getFullBasedOnStreamSpec();
        lastValidatedProjectSpec = fullSpec;
        lastProjectSpecValidationMessage = "";

        if (Utils.isNullEmpty(fullSpec)) {
            return true;
        }
        if (baseProject != null) {
            if (baseProject.getName().equals(fullSpec)) {
                return true;
            }
        }
        final boolean[] result = { true };
        
        run(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    monitor.beginTask("Validating project...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
                    DimensionsObjectFactory factory = wizard.getConnection().openSession(monitor).getObjectFactory();

                    if (factory.getProject(fullSpec) == null) {
                        lastProjectSpecValidationMessage = NLS.bind(Messages.StreamOrProjectDoesNotExistInProduct,
                            SpecUtils.getProjectName(fullSpec), SpecUtils.getProduct(fullSpec));
                        result[0] = false;
                    }
                } catch (NullPointerException e) {
                } catch (IllegalArgumentException e) {
                } catch (DMException e) {
                    DMUIPlugin.getDefault().handle(e);
                } finally {
                    monitor.setTaskName(Utils.EMPTY_STRING);
                    monitor.subTask(Utils.EMPTY_STRING);
                    monitor.done();
                }
            }
        }, false);

        lastValidatedProjectSpec = fullSpec;
        return result[0];
    }
    
    private void addBasedOnStreamControls(Composite composite, String basedOnStreamSpec) {
        lblParenStream = new Label(composite, SWT.NONE);
        UIUtils.setGridData(lblParenStream, GridData.FILL_HORIZONTAL);
        lblParenStream.setText(Messages.WorkWillBeMergedInto);

        Composite basedOnStreamComposite = new Composite(composite, SWT.NONE);

        GridLayout gridLayout = UIUtils.setGridLayout(basedOnStreamComposite, 2);
        gridLayout.marginHeight = 0;
        gridLayout.marginWidth = 0;

        UIUtils.setGridData(basedOnStreamComposite, GridData.FILL_HORIZONTAL);

        txtBasedOnStreamSpec = new Text(basedOnStreamComposite, SWT.BORDER);
        txtBasedOnStreamSpec.setText(basedOnStreamSpec);
        txtBasedOnStreamSpec.addVerifyListener(upperCaseMaker);
        txtBasedOnStreamSpec.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {

                if (stateHolder.getOptions() == PostCreationOptions.HIDDEN) {
                    // ensure last late validation error is removed
                    checkPage();
                    return;
                }
                if (Utils.isNullEmpty(txtBasedOnStreamSpec.getText())) {
                    applyState(PostCreationOptions.DISABLED);
                    return;
                }
                verifyRehomeAbility();
            }
        });

        UIUtils.setGridData(txtBasedOnStreamSpec, GridData.FILL_HORIZONTAL);

        findWorksetButton = new Button(basedOnStreamComposite, SWT.NONE);
        findWorksetButton.setText(Messages.SelectWithThreeDots);
        findWorksetButton.addSelectionListener(new SelectionAdapter() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                DimensionsConnectionDetailsEx connection = wizard.getConnection();
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), IDMConstants.PROJECT, connection,
                        getProductName(), true, false, connection.isOnlyStreamsActive(), connection.isOnlyProjectsActive());

                if (dialog.open() != Window.OK || dialog.getFindResult().isEmpty())
                    return;

                lastProjectSpecValidationMessage = "";
                List<?> objects = dialog.getFindResult().getObjects();
                Project selectedProject = (Project) objects.get(0);
                txtBasedOnStreamSpec.setText(selectedProject.getName());

                if (selectedProject.equals(baseProject))
                    return;

                baseProject = selectedProject;
                setMappings(null);

                if (stateHolder.getOptions() == PostCreationOptions.HIDDEN) {
                    return;
                }
                verifyLocation();
                verifyRehomeAbility();
            }
        });
        
        Label lblRequest = new Label(composite, SWT.NONE);
        UIUtils.setGridData(lblRequest, GridData.FILL_HORIZONTAL);
        lblRequest.setText(Messages.RequestToMergeChanges);

        Composite requestComposite = new Composite(composite, SWT.NONE);

        gridLayout = UIUtils.setGridLayout(requestComposite, 2);
        gridLayout.marginHeight = 0;
        gridLayout.marginWidth = 0;
        UIUtils.setGridData(requestComposite, GridData.FILL_HORIZONTAL);
        
        txtRequestIds = new Text(requestComposite, SWT.BORDER);
        txtRequestIds.setText(getBasedOnRequestId());

        UIUtils.setGridData(txtRequestIds, GridData.FILL_HORIZONTAL);
        
        txtRequestIds.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                try {
                    checkPage();
                } catch (Exception ex) {
                }
            }
        });

        Button findRequestButton = new Button(requestComposite, SWT.NONE);
        findRequestButton.setText(Messages.SelectWithThreeDots);
        findRequestButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.CHANGEDOCUMENT,
                        wizard.getConnection(), "", false, false);
                        
                if (dialog.open() == Window.OK) {
                    List<String> requests = dialog.getSelectedNames();
                    txtRequestIds.setText(Utils.listToString(requests, false));
                }
            }
        });
    }

    public String getProductName() {
        return UIUtils.safeGetCombo(comboProduct);
    }
    
    public String getOffset() {
        if (advancedSettings.getAllowed()) {
            return advancedSettings.getOffset();
        } else if (project != null) {
            return project.getName();
        }
        return "";
    }

    public String getPart() {
        if (advancedSettings.getAllowed()) {
            return advancedSettings.getPart(); 
        }
        return null;
    }

    public String getWorkArea() {
        if (advancedSettings.getAllowed()) {
            return advancedSettings.getWorkArea(); 
        }
        return "";
    }
    
    @Override
    protected IPath calcDefaultPath()
    {
        IPath defaultPath = null;
        String spec = getStreamSpec();
        if (!Utils.isNullEmpty(spec)) {
            defaultPath = Platform.getLocation().append(spec);
        } else {
            defaultPath = Platform.getLocation();
        }
        return defaultPath;
    }
    
    @Override
    protected void proceedWithDirectoryDialog() {
        DirectoryDialog dialog = new DirectoryDialog(getShell());
        dialog.setMessage("Select the parent directory");
        String dirName = getPathField();
        if (!dirName.equals(Utils.EMPTY_STRING)) {
            File path = new File(dirName);
            if (path.exists()) {
                dialog.setFilterPath(dirName);
            }
        }
        String selectedDirectory = dialog.open();
        setPathField(new Path(selectedDirectory).toOSString());
    }
    
    @Override
    public void setVisible (boolean visible) {
        if (visible && advancedSettings.getAllowed()) {
            advancedSettings.update();
        }
        super.setVisible(visible);
    }
    
    @Override
    protected String getPathField() {
        return txtAddToWorkArea.getText();
    }
    
    @Override
    protected void setPathField(String text) {
        txtAddToWorkArea.setText(text);
    }

    public String getBasedOnStreamText() {
        String spec = UIUtils.safeGetText(txtBasedOnStreamSpec);
        if (Utils.isNullEmpty(spec))
            return null;

        return spec;
    }

    public String getFullBasedOnStreamSpec() {
        String spec = UIUtils.safeGetText(txtBasedOnStreamSpec);
        if (Utils.isNullEmpty(spec))
            return "";
        if (!Utils.isNullEmpty(SpecUtils.getProduct(spec))) {
            return spec;
        }
        return NLS.bind("{0}:{1}", getProductName(), spec);
    }
    
	public List<IDMProject> getProjectsToRehome() {
		if (workAreaToRehome != null) {
			return waCandidatesToRehome.get(workAreaToRehome);
		}
		return null;
	}

    public String getStreamSpec() {
        return String.format("%s:%s", getProductName(), getStreamName());
    }
    
    public String getStreamName() {
        return UIUtils.safeGetText(txtStreamName);
    }
    
	public IPath getWorkAreaToRehome() {
		return workAreaToRehome;
	}
    
    public List<String> getRelatedRequests() {
        return Utils.fromCsvToList(UIUtils.safeGetText(txtRequestIds));
    }
    
	public void addToWorkspace() throws InvocationTargetException, InterruptedException {

		new ProgressMonitorDialog(UIUtils.findShell()).run(true, true, new IRunnableWithProgress() {

			@Override
			public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
				NewStreamWizard wizard = (NewStreamWizard) getWizard();
				ProjectMapping[] mappings = wizard.getMappings(wizard.getCreatedObjectAdapter(), monitor);
				setMappings(mappings);
			}
		});

		final ProjectMapping[] mappings = getMappings();

		if (isSingleProject()) {
			IPath target = new Path(targetLocation);
			if (target.segmentCount() > 1) {
				if (!target.lastSegment().equalsIgnoreCase(mappings[0].getLocalProjectName())) {
					target = target.append(mappings[0].getLocalProjectName());
					targetLocation = target.toOSString();
				}
			}
		}
		final APIObjectAdapter[] remoteObjects = new APIObjectAdapter[mappings.length];

		final Map<String, IDMProject> existingProjects = new HashMap<String, IDMProject>();
		final List<String> projectsToRemove = new ArrayList<String>();
		try {
			for (IDMProject project : DMTeamPlugin.getWorkspace().getProjects()) {
				existingProjects.put(project.getProject().getName(), project);
			}
		} catch (CoreException e) {
			throw new InvocationTargetException(e);
		}
		for (int i = 0; i < mappings.length; i++) {
			if (createUnderCompatibleWorkArea()) {
				mappings[i].setWorkAreaRoot(getCompatibleWorkArea());
			}
			remoteObjects[i] = mappings[i].getRemoteProject();
			String name = mappings[i].getLocalProjectName();
			if (existingProjects.containsKey(name)) {
				projectsToRemove.add(name);
			}
		}

		if (projectsToRemove.size() > 0) {
			final Shell shell = UIUtils.findShell();
			shell.getDisplay().syncExec(new Runnable() {
				@Override
				public void run() {
					RemoveFromWorkspaceDialog confirmRemoveDialog = new RemoveFromWorkspaceDialog(shell,
							projectsToRemove);
					if (confirmRemoveDialog.open() == Window.OK) {
						for (String projectName : confirmRemoveDialog.getProjectsToRemove()) {
							IDMProject project = existingProjects.get(projectName);
							if (project != null) {
								try {
									project.getProject().delete(false, true, new NullProgressMonitor());
								} catch (CoreException e) {
									DMUIPlugin.getDefault().handle(e);
								}
							}
						}
					}
				}
			});
		}

		new ProgressMonitorDialog(UIUtils.findShell()).run(true, true, new IRunnableWithProgress() {
			@Override
			public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
				if (mappings.length > 1) {
					AddMultipleProjectDirsToWorkspaceOperation operation = new AddMultipleProjectDirsToWorkspaceOperation(
							null, remoteObjects, mappings, getTargetLocation());
					operation.run(monitor);
				} else {
					AddSingleProjectDirToWorkspaceOperation operation = new AddSingleProjectDirToWorkspaceOperation(
							null, mappings[0], getTargetLocation());
					operation.run(monitor);
				}
			}
		});
	}
    
    public boolean needsAdditionalValidation() {
        if (!Utils.isNullEmpty(getErrorMessage())) {
            return false;
        }
        if (!lastValidatedProjectSpec.equalsIgnoreCase(getFullBasedOnStreamSpec())) {
            return true;
        }
        String currentRequestIds = UIUtils.safeGetText(txtRequestIds);
        if (Utils.isNullEmpty(currentRequestIds)) {
            return false;
        }
        return !currentRequestIds.equalsIgnoreCase(lastValidatedRequestIds);
    }

    public boolean doAdditionalValidation() {
        try {
            if (!validateBasedOnProject()) {
                return false;
            }
            return validateRequests();
        } finally {
            checkPage();
        }
    }

    private void applyState(PostCreationOptions options) {
        applyState(options, null);
    }

    private void applyState(PostCreationMode mode) {
        applyState(null, mode);
    }

    private void applyState(PostCreationOptions options, PostCreationMode mode) {
        try {
            // not for multithreading, rather to guard from recursive calls
            if (stateChanging) {
                logStateChange("stateChanging", options, mode);
                return;
            }
            stateChanging = true;

            if (options != null) {
                if (!stateHolder.trySetOptions(options)) {
                    if (stateHolder.getOptions() != PostCreationOptions.HIDDEN) {
                        logStateChange("stateHolder.trySetOptions", options, mode);
                    }
                    return;
                }
            }
            if (mode != null) {
                if (!stateHolder.trySetMode(mode)) {
                    logStateChange("stateHolder.trySetMode", options, mode);
                    return;
                }
            }
            switch (stateHolder.getOptions()) {

            case ALL:
                updateRehomeControls(true);
                updateAddToWorkAreaControls(true);
                break;

            case NO_REHOME:
                updateRehomeControls(false);
                updateAddToWorkAreaControls(true);
                break;

            case DISABLED:
                updateRehomeControls(false);
                updateAddToWorkAreaControls(false);
                break;

            case HIDDEN:
                optionsComposite.setVisible(false);
                break;

            default:
                logStateChange("switch options", options, mode);
                break;
            }

            switch (stateHolder.getMode()) {

            case REHOME:
                ensureSingleSelection(radioRehomeWorkArea);
                break;

            case ADD_TO_WORKSPACE:
                ensureSingleSelection(radioAddToWorkArea);

                break;
            case NONE:
                ensureSingleSelection(radioDontAddToWorkArea);
                break;

            default:
                logStateChange("switch mode", options, mode);
                break;
            }
        } finally {
            stateChanging = false;
            checkPage();
        }
    }

    private void logStateChange(String message, PostCreationOptions options, PostCreationMode mode) {
        String finalMessage = NLS.bind("{0}; requested state: {1}, {2}; current state: {3}, {4}", new Object[] { message, options, mode, stateHolder.getOptions(), stateHolder.getMode() });
        DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamUiPlugin.ID, finalMessage));
    }

    private void ensureSingleSelection(Button radio) {
        radioRehomeWorkArea.setSelection(radioRehomeWorkArea == radio);
        radioAddToWorkArea.setSelection(radioAddToWorkArea == radio);
        radioDontAddToWorkArea.setSelection(radioDontAddToWorkArea == radio);
    }

    private void updateRehomeControls(boolean enabled) {
        radioRehomeWorkArea.setEnabled(enabled);

        if (enabled) {
            comboProjectToRehome.select(0);
            if (comboProjectToRehome.getItemCount() > 1) {
                showFirstHideSecond(comboProjectToRehome, labelProjectToRehome);
            } else {
                showFirstHideSecond(labelProjectToRehome, comboProjectToRehome);
                labelProjectToRehome.setText(comboProjectToRehome.getText());
            }
        } else {
            showFirstHideSecond(labelProjectToRehome, comboProjectToRehome);
            labelProjectToRehome.setText("");
        }
    }

    private void updateAddToWorkAreaControls(boolean enabled) {
        radioAddToWorkArea.setEnabled(enabled);

        txtAddToWorkArea.setEnabled(enabled);
        browseLocationButton.setEnabled(enabled);

        if (enabled) {
            if (Utils.isNullEmpty(getPathField())) {
                setPathField(calcDefaultPath().toOSString());
            } else {
                verifyLocation();
            }
        } else {
            setPathField("");
        }
    }

    private void setBaseProject() {
        final String basedOnStreamSpec = getWizardBasedOnStreamSpec();
        if (StringPath.isNullorEmpty(basedOnStreamSpec))
            return;

        run(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    monitor.beginTask("Getting base project...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
                    DimensionsObjectFactory factory = wizard.getConnection().openSession(monitor).getObjectFactory();
                    baseProject = factory.getProject(basedOnStreamSpec);
                } catch (DMException e) {
                    DMUIPlugin.getDefault().handle(e);
                } finally {
                    monitor.setTaskName(Utils.EMPTY_STRING);
                    monitor.subTask(Utils.EMPTY_STRING);
                    monitor.done();
                }
            }
        }, false);
    }
    
    private void checkPage() {
        setMessage(null);
        setErrorMessage(null);
        setPageComplete(true);

        if (Utils.isNullEmpty(txtStreamName.getText())) {
            setPageComplete(false);
            setErrorMessage(NLS.bind(Messages.NewStreamWizard_stream_general_name_is_required, Messages.SharingWizard_stream));
            return;
        }
        
        String product = SpecUtils.getProduct(getFullBasedOnStreamSpec());

        // in the case when user input in the parent stream field is full spec 
        // check its product matches the combo selection
        if (!Utils.isNullEmpty(product)) {
            if (!product.equalsIgnoreCase(getProductName()) ) {
                setPageComplete(false);
                setErrorMessage(NLS.bind(Messages.ProductDoesNotMatch, product, getProductName()));
                return;
            }
        }

        if (!Utils.isNullEmpty(lastRequestIdsValidationMessage)) {
            if (UIUtils.safeGetText(txtRequestIds).equalsIgnoreCase(lastValidatedRequestIds)) {
                setPageComplete(false);
                setErrorMessage(lastRequestIdsValidationMessage); 
                return;
            }
        }
        
        if (!Utils.isNullEmpty(lastProjectSpecValidationMessage)) {
            if (getFullBasedOnStreamSpec().equalsIgnoreCase(lastValidatedProjectSpec)) {
                setPageComplete(false);
                setErrorMessage(lastProjectSpecValidationMessage); 
                return;
            }
        }

        verifyLocation();
        
        // need to check irrespective of showing advanced
        String[] holder = new String[1];
        if (project != null
                && TeamUtils.projectPathNotWritable(project.getLocation(), advancedSettings.getWorkAreaPath(), holder)) {
            setPageComplete(false);
            setErrorMessage(NLS.bind(Messages.NewStreamWizard_stream_offset_err6, holder[0]));
            return;
        }

        if (advancedSettings.getAllowed()) {
            advancedSettings.checkPage();
        }
    }

	private void verifyRehomeAbility() {
		if (stateHolder.getOptions() == PostCreationOptions.HIDDEN) {
			return;
		}
		String parentStreamSpec = getFullBasedOnStreamSpec();
		if (Utils.isNullEmpty(parentStreamSpec)) {
			applyState(PostCreationOptions.DISABLED);
			return;
		}
		IDMProject[] projects = null;

		try {
			projects = DMTeamPlugin.getWorkspace().getProjects();
		} catch (CoreException e) {
			setErrorMessage(e.getMessage());
		}

		comboProjectToRehome.removeAll();
		waCandidatesToRehome.clear();
		keyToWorkAreas.clear();

		for (int i = 0; projects != null && i < projects.length; i++) {
			IDMProject candidate = projects[i];
			if (!candidate.getId().equals(parentStreamSpec) || !candidate.getIsStream()) {
				continue;
			}
			IPath wa = WizardHelper.queryWorkAreaToRehome(candidate, parentStreamSpec);
			if (wa != null) {
				if (!waCandidatesToRehome.containsKey(wa)) {
					waCandidatesToRehome.put(wa, new ArrayList<IDMProject>());
				}
				waCandidatesToRehome.get(wa).add(candidate);
			}
		}
		for (IPath workArea : waCandidatesToRehome.keySet()) {
			String key = getStreamKey(workArea);
			keyToWorkAreas.put(key, workArea);
			comboProjectToRehome.add(key);
		}

		if (comboProjectToRehome.getItemCount() == 0) {
			applyState(PostCreationOptions.NO_REHOME);
		} else {
			applyState(PostCreationOptions.ALL);
		}
		setProjectToRehome(comboProjectToRehome.getText());
	}

	private void setProjectToRehome(String key) {
		if (keyToWorkAreas.containsKey(key)) {
			workAreaToRehome = keyToWorkAreas.get(key);
		} else {
			workAreaToRehome = null;
		}
	}

	private String getStreamKey(IPath wa) {
		List<IDMProject> projects = waCandidatesToRehome.get(wa);
		IPath commonRoot = wa;
		if (projects.size() > 1) {
			String offset = TeamUtils.calculateCommonOffset(projects);
			if (!Utils.isNullEmpty(offset)) {
				commonRoot = commonRoot.append(offset);
			}
		}
		StringBuffer builder = new StringBuffer(commonRoot.toOSString());
		builder.append(" (");
		IDMProject firstProject = projects.get(0);
		// stream specification
		builder.append(firstProject.getId());
		if (projects.size() == 1) {
			String name = firstProject.getIdeProjectName();
			if (Utils.isNullEmpty(name)) {
				IProject p = firstProject.getProject();
				if (p != null)
					name = p.getName();
				else
					name = firstProject.getUserDirectory().toOSString();
			}
			builder.append("/").append(name);
		} else {
			builder.append("/").append(NLS.bind(Messages.ProjectsCount, projects.size()));
		}
		builder.append(")");
		return builder.toString();
	}

    
    private void showFirstHideSecond(Control first, Control second) {
        first.setVisible(true);
        ((GridData) first.getLayoutData()).horizontalSpan = 2;
        ((GridData) first.getLayoutData()).exclude = false;
        second.setVisible(false);
        ((GridData) second.getLayoutData()).exclude = true;
        first.getShell().layout(true, true);
    }

    private String getBasedOnRequestId() {
        APIObjectAdapter request = wizard.getBaseOnObject();

        if (request instanceof ChangeDocumentAdapter)
            return request.getObjectSpec();

        ISBMRequest sbmRequest = wizard.getBaseOnSbmRequest();

        if (sbmRequest != null)
            return sbmRequest.getID();

        return "";
    }

    private String getWizardBasedOnStreamSpec() {
    	if(wizard.isBasedOnBaseline()) {
    		return "";
    	}
    	if (!wizard.isBasedOnRequest()) {
            return WizardHelper.getBasedOnSpec(wizard);
        }
        APIObjectAdapter request = wizard.getBaseOnObject();
        if (request == null)
            return "";

        DimensionsArObject apiRequest = request.getAPIObject();
        Object stream = apiRequest.getAttribute(SystemAttributes.PROJECT);
        if (stream == null) {
            apiRequest.queryAttribute(SystemAttributes.PROJECT);
            stream = apiRequest.getAttribute(SystemAttributes.PROJECT);
        }

        return stream == null ? "" : stream.toString();
    }

	private void verifyLocation() {
		if (stateHolder.getOptions() == PostCreationOptions.HIDDEN) {
			return;
		}
		useDefaults = false;

		if (getPostCreationMode() != PostCreationMode.ADD_TO_WORKSPACE)
			return;
		MessageHolder msg = new MessageHolder();
		targetLocation = getPathField();
		if (targetLocation.equals(Utils.EMPTY_STRING)) {
			msg.setErrorMsg(Messages.AddToWorkspaceAsLocationSelectionPage_emptyLocation);
		} else if (!Path.EMPTY.isValidPath(targetLocation)) {
			msg.setErrorMsg(Messages.AddToWorkspaceAsLocationSelectionPage_invalidLocation);
		} else {
			msg = validateWorkAreaRoot(getStreamSpec(), DMTypeScope.PROJECT, new Path(targetLocation), null);
		}
		setErrorMessage(msg.getErrorMsg());
		setPageComplete(msg.getErrorMsg() == null);
	}
    
    private void changePath() {
        IPath location = new Path(getPathField());
        if (Platform.getLocation().equals(location)) {
        	setPathField(location.append(TeamUtils.toValidResourceName(getStreamSpec(), null)).toOSString());
        } else if (location.segmentCount() > 0) {
            // replace last segment
            setPathField(
                    location.append(".." + Path.SEPARATOR + TeamUtils.toValidResourceName(getStreamSpec(), null)).toOSString());
        }
    }
}

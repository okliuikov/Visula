package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 *
 * @author kberezovchuk
 *
 */
public class LockWizard extends TeamOperationWizard {
    private boolean isLock = false; // true for locking, false otherwise

    public LockWizard(LockHelper helper, boolean isLock) {
        super(helper, true);
        this.isLock = isLock;
        setWindowTitle((this.isLock ? Messages.LockWizard_lock_title : Messages.LockWizard_unlock_title));
    }

    @Override
    protected String getMainPageTitle() {
        return (isLock ? Messages.LockWizard_lock_mainPageTitle : Messages.LockWizard_unlock_mainPageTitle);
    }

    @Override
    protected String getMainPageDescription() {
        return (isLock ? Messages.LockWizard_lock_mainPageDescription : Messages.LockWizard_unlock_mainPageDescription);
    }

    @Override
    protected int getMainPageOptions() {
        return TeamOperationWizardMainPage.SHOW_TREE | TeamOperationWizardMainPage.SHOW_COMPARE;
    }

    @Override
    protected TeamOperationWizardAttributesPage createAttributesPage(String name) {
        return null;
    }

}

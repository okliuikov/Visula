/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ActionWizard;

/**
 * Actions workset or baseline.
 *
 * @author V.Grishchenko
 */
public class ActionProjectAction extends DMTeamAction {

    public ActionProjectAction() {
        super();
    }

    @Override
    public void execute(IAction action) {
        IResource[] resources = getSelectedResources();
        WorksetAdapter[] worksets = new WorksetAdapter[resources.length];
        try {
            for (int i = 0; i < resources.length; i++) {
                IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(resources[0]);
                WorksetAdapter adapter = (WorksetAdapter) dmProject.getDimensionsObjectAdapter();

                worksets[i] = adapter;
            }
        } catch (CoreException e) {
        }
        // Check if all connections could be made. In case they couldn't, this worksets array would contain nulls.
        // In that case we shouldn't open the dialog as it will be throwing a null pointer exception
        for (int i = 0; i < worksets.length; i++) {
            if (worksets[i] == null) {
                return;
            }
        }
        ActionWizard wizard = new ActionWizard(worksets);
        WizardDialog dialog = new WizardDialog(getShell(), wizard);
        dialog.open();
    }

}

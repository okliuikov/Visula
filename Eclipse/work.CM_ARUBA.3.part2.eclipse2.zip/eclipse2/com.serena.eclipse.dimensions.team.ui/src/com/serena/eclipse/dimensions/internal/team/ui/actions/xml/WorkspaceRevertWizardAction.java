package com.serena.eclipse.dimensions.internal.team.ui.actions.xml;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandLocalScope;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.RevertStreamWizardFactory;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.WizardFactory;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;

public class WorkspaceRevertWizardAction extends WorkspaceUpdateWizardAction {
    private DimensionsChangeSet changeset;
    private Project changesetViewSourceStream;
    private IResource changesetScopeResource;

    public WorkspaceRevertWizardAction() {
        super();
    }

    public WorkspaceRevertWizardAction(DimensionsChangeSet changeset, Project changesetViewSourceStream,
            IResource changesetScopeResource) {
        super();
        this.changeset = changeset;
        this.changesetViewSourceStream = changesetViewSourceStream;
        this.showInformationDialog = true;
        this.changesetScopeResource = changesetScopeResource;
    }

    @Override
    protected WizardFactory createWizardFactory(MergeCommandLocalScope mergeScope, List<MergeScopeGroup> possibleScopes,
            DimensionsConnectionDetailsEx connection) {
        return new RevertStreamWizardFactory(mergeScope, possibleScopes, connection, changeset, changesetScopeResource != null);
    }

    @Override
    protected boolean isEnabledForSelection() {
        return true;
    }

    @Override
    protected IResource[] getSelectedResources() {
        try {
            return getResources();
        } catch (CoreException e) {
            return new IResource[0];
        }
    }

    @Override
    protected IResource[] getResources() throws CoreException {
        IWorkspaceRoot workspaceRoot = ResourcesPlugin.getWorkspace().getRoot();
        if (changesetScopeResource == null) {
            IProject[] projects = workspaceRoot.getProjects();
            if (projects != null) {
                List<IResource> resourceList = new ArrayList<IResource>();
                for (IProject currentProject : projects) {
                    try {
                        IDMProject idmProject = DMTeamPlugin.getWorkspace().getProject(currentProject);
                        if (idmProject != null) {
                            VersionManagementProject versionManagementProject = idmProject.getDimensionsObjectAdapter();
                            Project cmProject = (Project) versionManagementProject.getAPIObject();
                            if (changesetViewSourceStream.equals(cmProject)) {
                                resourceList.add(currentProject);
                            }
                        }
                    } catch (CoreException e) {
                        String errorMsg = "Cannot get resources for revert from work area operation";
                        Status status = DMPlugin.getStatusFromExceptionChain(errorMsg, IStatus.ERROR, 0, e);
                        DMUIPlugin.log(status);
                    }
                }
                return resourceList.toArray(new IResource[0]);
            } else {
                return new IResource[0];
            }
        } else {
            return new IResource[] { changesetScopeResource };
        }
    }

    protected String getInformationMessage() {
        String infoMessage = MessageFormat.format(Messages.RevertStreamVersion_nothingToRevert,
                (Object[]) new String[] { changesetViewSourceStream.getName() });
        return infoMessage;
    }

    @Override
    protected Map<IDMProject, List<IResource>> getScopes(IResource[] resources) throws CoreException {
        return MergeCommandLocalScope.getScopes(resources, false);
    }

    @Override
    protected MergeCommandLocalScope createMergeCommandLocalScope(IResource[] resources) throws CoreException {
        return MergeCommandLocalScope.createMergeCommandLocalScope(resources, false);
    }
}

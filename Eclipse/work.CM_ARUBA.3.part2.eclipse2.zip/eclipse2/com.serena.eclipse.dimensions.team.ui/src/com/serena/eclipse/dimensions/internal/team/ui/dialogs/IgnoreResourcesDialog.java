/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 * Contributors:
 * IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.resource.JFaceColors;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.serena.eclipse.dimensions.internal.team.core.FileNameMatcher;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;

import org.eclipse.swt.widgets.Group;

public class IgnoreResourcesDialog extends Dialog {
    // resources that should be ignored
    private IResource[] resources;

    private static final int ADD_NAME_ENTRY = 0;
    private static final int ADD_EXTENSION_ENTRY = 1;
    private static final int ADD_CUSTOM_ENTRY = 2;

    // dialogs settings that are persistent between workbench sessions

    // buttons
    private Group patternsGroup; 
    private Button addNameEntryButton;
    private Button addExtensionEntryButton;
    private Button addCustomEntryButton;
    private Button addRecursivelyCheckBox;

    private Text customEntryText;

    private int selectedAction;
    private boolean isRecursive;
    private String customPattern;

    // layout controls
    private static final int LABEL_WIDTH_HINT = 400;
    private static final int LABEL_INDENT_WIDTH = 32;

    /**
     * Creates a new dialog for ignoring resources.
     * @param shell the parent shell
     * @param resources the array of resources to be ignored
     */
    public IgnoreResourcesDialog(Shell shell, IResource[] resources) {
        super(shell);
        this.resources = resources;
        this.isRecursive = false;
    }

    /**
     * Determines the ignore pattern to use for a resource given the selected action.
     *
     * @param resource the resource
     * @return the ignore pattern for the specified resource
     */
    public String getIgnorePatternFor(IResource resource) {
        switch (selectedAction) {
        case ADD_NAME_ENTRY:
            return resource.getName();
        case ADD_EXTENSION_ENTRY: {
            String extension = resource.getFileExtension();
            return (extension == null) ? resource.getName() : "*." + extension; //$NON-NLS-1$
        }
        case ADD_CUSTOM_ENTRY:
            return customPattern;
        }
        throw new IllegalStateException();
    }

    public boolean isRecursive() {
        return isRecursive;
    }
    

    protected Control createButtonBar(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        // create a layout with spacing and margins appropriate for the font
        // size.
        GridLayout layout = new GridLayout();
        layout.numColumns = 0; // this is incremented by createButton
        
        layout.marginWidth = convertHorizontalDLUsToPixels(IDialogConstants.HORIZONTAL_MARGIN-4);//convertHorizontalDLUsToPixels(IDialogConstants.HORIZONTAL_MARGIN);
        layout.marginHeight = convertHorizontalDLUsToPixels(IDialogConstants.VERTICAL_MARGIN-2); //convertVerticalDLUsToPixels(IDialogConstants.VERTICAL_MARGIN);
        layout.horizontalSpacing = convertHorizontalDLUsToPixels(IDialogConstants.HORIZONTAL_SPACING);
        layout.verticalSpacing = convertVerticalDLUsToPixels(IDialogConstants.VERTICAL_SPACING);
        composite.setLayout(layout);
        
        GridData data = new GridData(GridData.VERTICAL_ALIGN_BEGINNING);

        composite.setLayoutData(data);
        composite.setFont(parent.getFont());
        
        // Add the buttons to the button bar.
        createButtonsForButtonBar(composite);
        return composite;
    }
    
    /*
     * (non-Javadoc)
     * Method declared on Dialog.
     */
    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        
        ((GridLayout) parent.getLayout()).numColumns++;
        addRecursivelyCheckBox = new Button(parent, SWT.CHECK);
        addRecursivelyCheckBox.setText(Messages.IgnoreResourcesDialog_addRecursivelyCheckBox);
        
        GridData gridData = new GridData(SWT.LEFT, SWT.TOP, true, true, 1, 1);
        addRecursivelyCheckBox.setLayoutData(gridData);
        
        ((GridLayout) parent.getLayout()).numColumns++;
        Label lbl = new Label(parent, SWT.TOP);
        GridData gd = new GridData(SWT.LEFT, SWT.TOP, true, true, 1, 1);

        gd.widthHint = convertHorizontalDLUsToPixels(187);
        lbl.setLayoutData(gd);
        lbl.setText("");
        
        createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
        createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
    }

    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        if (resources.length == 1) {
            newShell.setText(NLS.bind(Messages.IgnoreResourcesDialog_titleSingle, resources[0].getName()));
        } else {
            newShell.setText(NLS.bind(Messages.IgnoreResourcesDialog_titleMany, Integer.toString(resources.length)));
        }
    }

    @Override
    protected Control createContents(Composite parent) {
        Control control = super.createContents(parent);
        updateEnablements();
        return control;
    }

    @Override
    protected Control createDialogArea(Composite parent) {

        Composite top = new Composite(parent, SWT.NONE);

        GridLayout layout = new GridLayout();
        
        layout.numColumns = 1;
        
        top.setLayout(layout);
        
        GridData data = new GridData(GridData.FILL_BOTH);
        data.grabExcessHorizontalSpace = true;

        data.widthHint = convertHorizontalDLUsToPixels(395);//593px 
        top.setLayoutData(data);

        Listener selectionListener = new Listener() {
            @Override
            public void handleEvent(Event event) {
                updateEnablements();
            }
        };
        Listener modifyListener = new Listener() {
            @Override
            public void handleEvent(Event event) {
                validate();
            }
        };

        patternsGroup = new Group(top, SWT.SHADOW_IN);
        
        patternsGroup.setText(Messages.IgnoreResourcesDialog_prompt);
        
        GridLayout gridLayout = new GridLayout();
 
        gridLayout.numColumns=1;
        gridLayout.marginWidth = 10;
        gridLayout.marginHeight = 10;
        
        patternsGroup.setLayout(gridLayout);
        GridData data2 = new GridData(SWT.FILL, SWT.FILL, true, true);
        data2.grabExcessHorizontalSpace = true;
        
        patternsGroup.setLayoutData(data2);
        
        addNameEntryButton = createRadioButton(patternsGroup, Messages.IgnoreResourcesDialog_addNameEntryButton);
        addNameEntryButton.addListener(SWT.Selection, selectionListener);
        addNameEntryButton.setSelection(selectedAction == ADD_NAME_ENTRY);
        createIndentedLabel(patternsGroup, Messages.IgnoreResourcesDialog_addNameEntryExample, LABEL_INDENT_WIDTH);

       
        addExtensionEntryButton = createRadioButton(patternsGroup, Messages.IgnoreResourcesDialog_addExtensionEntryButton);
        addExtensionEntryButton.addListener(SWT.Selection, selectionListener);
        addExtensionEntryButton.setSelection(selectedAction == ADD_EXTENSION_ENTRY);
        createIndentedLabel(patternsGroup, Messages.IgnoreResourcesDialog_addExtensionEntryExample, LABEL_INDENT_WIDTH);

        addCustomEntryButton = createRadioButton(patternsGroup, Messages.IgnoreResourcesDialog_addCustomEntryButton);
        addCustomEntryButton.addListener(SWT.Selection, selectionListener);
        addCustomEntryButton.setSelection(selectedAction == ADD_CUSTOM_ENTRY);
        createIndentedLabel(patternsGroup, Messages.IgnoreResourcesDialog_addCustomEntryExample, LABEL_INDENT_WIDTH);

        customEntryText = createIndentedText(patternsGroup, resources[0].getName(), LABEL_INDENT_WIDTH);
        customEntryText.addListener(SWT.Modify, modifyListener);

        Dialog.applyDialogFont(parent);
        
        return top;
    }

    @Override
    protected void okPressed() {
        
        // settings.put(ACTION_KEY, selectedAction);
        isRecursive = addRecursivelyCheckBox.getSelection();
        super.okPressed();
    }

    @Override
    protected void cancelPressed() {
        isRecursive = false;
        setReturnCode(CANCEL);
        close();
    }

    private Label createIndentedLabel(Composite parent, String text, int indent) {
        Label label = new Label(parent, SWT.LEFT);
        label.setText(text);
        GridData data = new GridData(GridData.VERTICAL_ALIGN_FILL | GridData.FILL_HORIZONTAL);
        data.horizontalIndent = indent;
        label.setLayoutData(data);
        return label;
    }

    private Text createIndentedText(Composite parent, String text, int indent) {
        Text textbox = new Text(parent, SWT.BORDER);
        textbox.setText(text);
        GridData data = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
        data.horizontalIndent = indent;
        textbox.setLayoutData(data);
        return textbox;
    }

    private Button createRadioButton(Composite parent, String text) {
        Button button = new Button(parent, SWT.RADIO);
        button.setText(text);
        button.setLayoutData(new GridData(GridData.VERTICAL_ALIGN_FILL | GridData.FILL_HORIZONTAL));
        return button;
    }

    private void updateEnablements() {
        if (addNameEntryButton.getSelection()) {
            selectedAction = ADD_NAME_ENTRY;
        } else if (addExtensionEntryButton.getSelection()) {
            selectedAction = ADD_EXTENSION_ENTRY;
        } else if (addCustomEntryButton.getSelection()) {
            selectedAction = ADD_CUSTOM_ENTRY;
        }
        customEntryText.setEnabled(selectedAction == ADD_CUSTOM_ENTRY);
        validate();
    }

    private void validate() {
        if (selectedAction == ADD_CUSTOM_ENTRY) {
            customPattern = customEntryText.getText();
            if (customPattern.length() == 0) {
            	getButton(IDialogConstants.OK_ID).setEnabled(false);
                return;
            }
        }
        getButton(IDialogConstants.OK_ID).setEnabled(true);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.io.File;
import java.net.URI;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.RepositoryProvider;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public abstract class AddProjectToWorkspaceOperation extends AddToWorkspaceOperation { 
    private String targetLocation;

    public AddProjectToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects, String targetLocation) {
        super(part, remoteObjects);
        this.targetLocation = targetLocation;
    }

    public AddProjectToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects, ProjectMapping[] mappings,
            String targetLocation) {
        super(part, remoteObjects, mappings);
        this.targetLocation = targetLocation;
    }

    protected IStatus addToWorkspace(ProjectMapping mapping, IProject project, IProgressMonitor monitor)
            throws CoreException {
        monitor = Utils.monitorFor(monitor);
        if (project == null) {
            project = resolveProject(mapping);
            if (project == null) {
                return OK; // canceled
            }
        }

        ISchedulingRule schedulingRule = getSchedulingRule(new IProject[] { project });
        try {
            Job.getJobManager().beginRule(schedulingRule, monitor);
            return performAddToWorkspace(mapping, project, monitor, mapping.getRemoteProject());
        } finally {
            Job.getJobManager().endRule(schedulingRule);
            monitor.done();
        }
    }

    protected IStatus performAddToWorkspace(ProjectMapping mapping, IProject project, IProgressMonitor monitor,
            APIObjectAdapter remoteProject) throws CoreException {
        if (performScrubProjects()) {
            if (needsPromptForOverwrite(mapping, project)) {
                if (!promptToOverwrite(mapping, project)) {
                    return OK; // canceled
                } else {
                    // try to remove sync and deliver participants if we override existing project
                    removeSyncParticipants(project, remoteProject);
                }
            }
        }
        String task = NLS.bind(Messages.AddProjectToWorkspaceOperation_0, mapping.getRemoteProjectName(), project.getName());
        monitor.beginTask(task, 100);
        monitor.setTaskName(task);
        createAndOpenProject(mapping, project, Utils.subMonitorFor(monitor, 10));
        scrubProject(project, Utils.subMonitorFor(monitor, 10));
        IDMProject dmProject = DMTeamPlugin.getWorkspace()
                .manage(project, null, remoteProject, null, /* no refresh, it could degrade performance */false)
                .getIdmProject();
        return dmProject.copyDirToWorkspace(Utils.subMonitorFor(monitor, 80));
    }

    protected boolean promptToOverwrite(ProjectMapping mapping, IProject project) {
        // First, if the project exists in the workspace, prompt
        if (project.exists()) {
            return promptToOverwrite(Messages.confirm_overwrite,
                    NLS.bind(Messages.addConfirmOverwrite_prompt, project.getName(), mapping.getRemoteProjectName()));
        }

        // Even if the project exists, check the target location
        IPath path = getTargetLocationFor(mapping, project);
        File localLocation = null;
        if (path == null) {
            // There is no custom location. However, still prompt
            // if the project directory in the workspace directory
            // would be overwritten.
            localLocation = getFileLocation(project);
        } else {
            localLocation = path.toFile();
        }
        if (localLocation != null && localLocation.exists()) {
            return (promptToOverwrite(Messages.confirm_overwrite, NLS.bind(Messages.addConfirmOverwriteExtFolder_prompt,
                    localLocation.getAbsolutePath(), mapping.getRemoteProjectName())));
        }
        return true;
    }

    protected boolean needsPromptForOverwrite(ProjectMapping mapping, IProject project) {
        // First, check the description location
        IProjectDescription desc = getDescriptionFor(mapping, project);
        if (desc != null) {
            URI locationURI = desc.getLocationURI();
            if (locationURI != null) {
                IPath location = new Path(locationURI.getPath());
                File localLocation = location.toFile();
                if (localLocation.exists()) {
                    return true;
                }
            }
        }

        // Next, check if the resource itself exists
        if (project.exists()) {
            return true;
        }

        // Finally, check if the location in the workspace exists;
        File localLocation = getFileLocation(project);
        if (localLocation.exists()) {
            return true;
        }

        // The target doesn't exist
        return false;
    }

    protected File getFileLocation(IProject project) {
        return new File(project.getParent().getLocation().toFile(), project.getName());
    }

    @Override
    protected IProject resolveProject(ProjectMapping mapping) {
        return ResourcesPlugin.getWorkspace().getRoot().getProject(mapping.getLocalProjectName());
    }

    /**
     * Create and open the project, using a custom location if there is one.
     *
     * @param project
     * @param monitor
     * @throws CoreException
     */
    protected void createAndOpenProject(ProjectMapping mapping, IProject project, IProgressMonitor monitor)
            throws CoreException {
        try {
            monitor.beginTask(null, 5);
            IProjectDescription desc = getDescriptionFor(mapping, project);
            if (project.exists()) {
                if (desc != null) {
                    try {
                        project.move(desc, true, Utils.subMonitorFor(monitor, 3));
                    } catch (IllegalArgumentException e) {
                        /* IllegalArgumentException is thrown when whole project directory is absent
                         * ResourceTree.standardMoveProject 1052: 
                         * if (!source.isAccessible())
                         *     throw new IllegalArgumentException();
                         */
                        project.delete(false, Utils.subMonitorFor(monitor, 3));
                        project.create(desc, Utils.subMonitorFor(monitor, 3));
                    }
                }
            } else {
                if (desc == null) {
                    // create in default location
                    project.create(Utils.subMonitorFor(monitor, 3));
                } else {
                    // create in some other location
                    project.create(desc, Utils.subMonitorFor(monitor, 3));
                }
            }
            if (!project.isOpen()) {
                project.open(Utils.subMonitorFor(monitor, 2));
            }
        } finally {
            monitor.done();
        }
    }

    /**
     * Return the target location where the given project should be located or <code>null</code> if the default location should be
     * used.
     *
     * @param project
     */
    protected IPath getTargetLocationFor(ProjectMapping mapping, IProject project) {
        if (targetLocation == null) {
            return null;
        }
        return new Path(targetLocation);
    }

    /**
     * Return true if the target projects should be scrubbed before the add occurs.
     * Default is to scrub the projects. Can be overridden by subclasses.
     */
    protected boolean performScrubProjects() {
        return true;
    }

    protected IProjectDescription getDescriptionFor(ProjectMapping mapping, IProject project) {
        IProjectDescription description = null;
        if (mapping != null) {
            description = mapping.getProjectDescription();
        }
        if (targetLocation == null) {
            return description;
        }
        if (description == null) {
            // no description from remote, create our own
            String projectName = project.getName();
            description = ResourcesPlugin.getWorkspace().newProjectDescription(projectName);
        }
        description.setLocation(getTargetLocationFor(mapping, project));
        return description;
    }

    private ISchedulingRule getSchedulingRule(IProject[] projects) {
        if (projects.length == 1) {
            return ResourcesPlugin.getWorkspace().getRuleFactory().modifyRule(projects[0]);
        }
        Set<ISchedulingRule> rules = new HashSet<ISchedulingRule>();
        for (int i = 0; i < projects.length; i++) {
            ISchedulingRule modifyRule = ResourcesPlugin.getWorkspace().getRuleFactory().modifyRule(projects[i]);
            if (modifyRule instanceof IResource && ((IResource) modifyRule).getType() == IResource.ROOT) {
                // One of the projects is mapped to a provider that locks the workspace.
                // Just return the workspace root rule
                return modifyRule;
            }
            rules.add(modifyRule);
        }
        return new MultiRule(rules.toArray(new ISchedulingRule[rules.size()]));
    }

    protected void scrubProject(IProject project, IProgressMonitor monitor) throws CoreException {
        // unmap the project from any previous repository provider
        RepositoryProvider provider = RepositoryProvider.getProvider(project);
        if (provider != null) {
            // if it is us make sure all internal state is flushed and listeners are notified
            if (provider instanceof DMRepositoryProvider) {
                DMTeamPlugin.getWorkspace().unmanage(project, false, null);
            } else {
                RepositoryProvider.unmap(project);
            }
        }
        // We do not want to delete the project to avoid a project deletion delta
        // We do not want to delete the .project to avoid core exceptions
        IResource[] children = project.members(IContainer.INCLUDE_TEAM_PRIVATE_MEMBERS);
        Utils.checkCanceled(monitor);
        monitor.beginTask(null, 100 + children.length * 100);
        monitor.subTask(NLS.bind(Messages.addScrubProject_msg, project.getName()));
        try {
            for (int j = 0; j < children.length; j++) {
                if (children[j].getName().equals(IProjectDescription.DESCRIPTION_FILE_NAME)) {
                    if (children[j].exists()) {
                        // make writable so that it can be overwritten on get
                        TeamUtils.setReadOnly(children[j], false);
                    }
                } else {
                    try {
                        children[j].delete(true /* force */, Utils.subMonitorFor(monitor, 100));
                    } catch (CoreException e) {
                        // log the exception
                        DMTeamUiPlugin.log(e.getStatus());
                        // try to delete again
                        try {
                            if (children[j].exists()) {
                                children[j].delete(true /* force */, Utils.subMonitorFor(monitor, 100));
                            }
                        } catch (CoreException e1) {
                            DMTeamUiPlugin.log(e1.getStatus());
                            // rethrow
                            throw e1;
                        }
                    }
                }
            }
        } finally {
            monitor.subTask(Utils.EMPTY_STRING);
            monitor.done();
        }
    }

    @Override
    protected String getTaskName() {
        APIObjectAdapter[] remoteObjects = getRemoteObjects();
        if (remoteObjects.length == 1) {
            String spec = (String) remoteObjects[0].getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
            return NLS.bind(Messages.addSingleProjectOperation_taskName, spec);
        }
        return NLS.bind(Messages.addMultipleProjectsOperation_taskName, String.valueOf(remoteObjects.length));
    }

}

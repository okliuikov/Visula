/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.dialogs.MessageDialogWithToggle;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.ISubscriberChangeEvent;
import org.eclipse.team.core.subscribers.ISubscriberChangeListener;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantListener;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamPreferences;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Handles participant removals actions, shows notification if merge data become stale
 */
public class XMLMergeParticipantListener implements ISynchronizeParticipantListener, ISubscriberChangeListener {

    private static boolean debugUpdateMerge = DMTeamPlugin.getDefault().isDebuggingUpdateMerge();

    @Override
    public void participantsRemoved(ISynchronizeParticipant[] participants) {
        for (int i = 0; i < participants.length; i++) {
            if (participants[i].getId().equals(XMLMergeParticipant.ID)) {
                XMLMergeParticipant participant = (XMLMergeParticipant) participants[i];
                XMLMergeSubscriber subscriber = (XMLMergeSubscriber) participant.getSubscriber();

                subscriber.removeListener(this);
                TeamUI.getSynchronizeManager().removeSynchronizeParticipantListener(this);
                ResourcesPlugin.getWorkspace().removeResourceChangeListener(subscriber);

                subscriber.getDescriptorsContainer().clearCachedInfo();

                XMLMergeUIUtils.closeMergeCompareEditors();
            }
        }

    }

    @Override
    public void subscriberResourceChanged(ISubscriberChangeEvent[] deltas) {
        if (debugUpdateMerge) {
            DMPlugin.getDefault().getConsole().printMessage("XMLMergeParticipantListener#subscriberResourceChanged started");
        }
        final IPreferenceStore store = DMTeamUiPlugin.getDefault().getPreferenceStore();
        if (!store.getBoolean(IDMTeamPreferences.MERGE3W_SHOW_STALE_RESULTS_WARNING)) {
            return;
        }

        for (ISubscriberChangeEvent event : deltas) {
            IResource resource = event.getResource();
            Subscriber subscriber = event.getSubscriber();
            if (subscriber instanceof XMLMergeSubscriber) {
                final XMLMergeSubscriber mergeSubscriber = (XMLMergeSubscriber) subscriber;
                try {
                    XMLSyncInfo syncInfo = (XMLSyncInfo) subscriber.getSyncInfo(resource);
                    if (syncInfo != null && syncInfo.isStale() && !syncInfo.getDescriptor().isInSync()
                            && mergeSubscriber.isUpToDate()) {

                        Display.getDefault().asyncExec(new Runnable() {
                            @Override
                            public void run() {
                                boolean doUpdate = mergeSubscriber.getDescriptorsContainer().getMergeOptions().isDoUpdate();
                                String name = doUpdate ? Messages.DMXMLUpdate_name : Messages.DMXMLMerge_name;
                                String msg = doUpdate
                                        ? Messages.DMXMLUpdateParticipant_stale_view_warning
                                        : Messages.DMXMLMergeParticipant_stale_view_warning;

                                //@formatter:off
                                MessageDialogWithToggle.openWarning(
                                        null, name, msg, Messages.DMXMLMergeOperation_dont_show_message,
                                        !store.getBoolean(IDMTeamPreferences.MERGE3W_SHOW_STALE_RESULTS_WARNING),
                                        store, IDMTeamPreferences.MERGE3W_SHOW_STALE_RESULTS_WARNING);
                                //@formatter:on

                            }
                        });
                        return;
                    }
                } catch (TeamException e) {
                    DMTeamUiPlugin.log(e.getStatus());
                }
            }
        }
        if (debugUpdateMerge) {
            DMPlugin.getDefault().getConsole().printMessage("XMLMergeParticipantListener#subscriberResourceChanged finished");
        }
    }

    @Override
    public void participantsAdded(ISynchronizeParticipant[] participants) {
    }

}

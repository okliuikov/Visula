package com.serena.eclipse.dimensions.internal.team.ui.commands;

import java.lang.reflect.InvocationTargetException;
import java.text.MessageFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.team.core.TeamException;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.dmclient.api.DimensionsChangeStep;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.UndoDeliverCommandDetails;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UndoProjectStreamVersionOperation;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.UndoStreamProjectVersionDialog;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class UndoProjectStreamVersionInDCHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent executionEvent) throws ExecutionException {
        Shell shell = UIUtils.findShell();
        IWorkbenchPage activePage = UIUtils.getActivePage();
        final ChangeSetHistoryView changesetView = (ChangeSetHistoryView) activePage.findView(ChangeSetHistoryView.ID);
        String changesetViewSourceType = changesetView.getChangesetSourceTypeName().toLowerCase();
        IWorkbenchSite changesetsSite = changesetView.getSite();
        ISelectionProvider selectionProvider = changesetsSite.getSelectionProvider();
        TreeSelection selection = (TreeSelection) selectionProvider.getSelection();
        Object[] selectedObjects = selection.toArray();
        DimensionsChangeSet changeset = (DimensionsChangeSet) selectedObjects[0];
        boolean allowOperation = false;
        String scopePath = changesetView.getScopePath();
        if (!"".equals(scopePath)) {
            Filter filter = changesetView.getCurrentFilter();
            changeset.queryDimensionsChangeSteps(filter, null);
            List<DimensionsChangeStep> changesWithoutScope = changeset.getDimensionsChangeSteps();
            changeset.queryDimensionsChangeSteps(filter, scopePath);
            List<DimensionsChangeStep> changesWithScope = changeset.getDimensionsChangeSteps();
            Set<DimensionsChangeStep> changesWithoutScopeSet = new HashSet<DimensionsChangeStep>(changesWithoutScope);
            Set<DimensionsChangeStep> changesWithScopeSet = new HashSet<DimensionsChangeStep>(changesWithScope);
            changesWithoutScopeSet.removeAll(changesWithScopeSet);
            if (!changesWithoutScopeSet.isEmpty()) {
                String errorMessage = MessageFormat.format(Messages.UndoFailedDueToChangesOutOfScope,
                        (Object[]) new String[] { changesetViewSourceType });
                UIUtils.showMessageDialog(shell, "Dimensions", errorMessage, true);
            } else {
                allowOperation = true;
            }
        } else {
            allowOperation = true;
        }
        if (allowOperation) {
            final UndoDeliverCommandDetails commandDetails = new UndoDeliverCommandDetails();
            UndoStreamProjectVersionDialog dialog = new UndoStreamProjectVersionDialog(shell, changeset, commandDetails);
            int returnCode = dialog.open();
            if (Window.OK == returnCode) {
                final UndoProjectStreamVersionOperation operation = new UndoProjectStreamVersionOperation(changesetView,
                        commandDetails);
                try {
                    PlatformUI.getWorkbench().getProgressService().run(false, true, new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            operation.run(monitor);
                        }
                    });
                } catch (InvocationTargetException e) {
                    String title = "Dimensions";
                    String msg = MessageFormat.format(Messages.UndoStreamProjectVersionErrorDialogMessage,
                            (Object[]) new String[] { changesetViewSourceType });
                    Throwable target = e.getTargetException();
                    if (target instanceof TeamException) {
                        UIUtils.showError(shell, title, msg, ((TeamException) target).getStatus(),
                                operation.getShowDetailsAction());
                    } else {
                        DMTeamUiPlugin.getDefault().handle(e, shell, title, msg);
                    }
                } catch (InterruptedException e) {
                }
            }
        }
        return null;
    }
}

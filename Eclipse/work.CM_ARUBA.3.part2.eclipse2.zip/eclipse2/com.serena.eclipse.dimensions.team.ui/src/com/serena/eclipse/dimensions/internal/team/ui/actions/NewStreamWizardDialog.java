package com.serena.eclipse.dimensions.internal.team.ui.actions;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewStreamWizard;

public class NewStreamWizardDialog extends WizardDialog {

    private NewStreamWizard wizard;
    
    public NewStreamWizardDialog(Shell parentShell, NewStreamWizard newWizard) {
        super(parentShell, newWizard);
        wizard = newWizard;
    }

    public void setFinishButtonText(String text) {
        Button finishButton = getButton(IDialogConstants.FINISH_ID);
        finishButton.setText(text);
        setButtonLayoutData(finishButton);
    }
    
    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        super.createButtonsForButtonBar(parent);

        setFinishButtonText("Create Stream"); //$NON-NLS-1$
    }
    
    @Override
    protected void nextPressed() {
        if (!wizard.runLateValidation()) {
            return;
        }
        super.nextPressed();
    }
    
    @Override
    protected void finishPressed() {
        if (!wizard.runLateValidation()) {
            return;
        }
        super.finishPressed();
    }
}

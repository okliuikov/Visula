package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.dmclient.api.BaselineDetails;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;

public class NewRevisedBaselineWizard extends NewBaselineWizard {
    public NewRevisedBaselineWizard() {
        super();
    }

    public NewRevisedBaselineWizard(DimensionsConnectionDetailsEx connection, WorksetAdapter basedOn, FormToolkit toolkit) {
        super(connection, basedOn, toolkit);
    }

    public NewRevisedBaselineWizard(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn) {
        super(connection, basedOn);
    }

    public NewRevisedBaselineWizard(DimensionsConnectionDetailsEx connection) {
        super(connection);
    }

    @Override
    protected String[] getTitleDesc() {
        String[] titleDesc = new String[2];
        titleDesc[0] = Messages.NewBaselineWizard_revised_title;
        titleDesc[1] = Messages.NewBaselineWizard_revised_description;
        return titleDesc;
    }

    @Override
    protected int getBaselineCode() {
        return NewBaselineWizard.REVISED_BASELINE;
    }

    @Override
    protected void addInternalPages(int options) {
        addPage(new NewBaselineRevisePage(BASELINE_REVISE_PAGE, Messages.newBaselineRevisePage_title,
                Messages.newBaselineRevisePage_desc, DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                getConnection(), getBaselineCode(), options));
    }

    @Override
    protected BaselineDetails createBaselineDetails(BaselineDetails baselineDetails, NewBaselineGeneralPage generalPage) {
        BaselineDetails det = super.createBaselineDetails(baselineDetails, generalPage);
        // Revised Baseline specific
        NewBaselineRevisePage revpage = (NewBaselineRevisePage) getPage(BASELINE_REVISE_PAGE);
        Boolean trav = revpage.getTraverseRequests();
        Boolean canc = null;
        if (trav != null) {
            canc = trav == Boolean.TRUE ? Boolean.FALSE : Boolean.TRUE;
        }
        det.setCancelTraverse(canc);
        det.setRemoveRequests(revpage.getRemoveRequests());
        det.setUpdateRequests(revpage.getUpdateRequests());
        det.setBasedOnProject(revpage.getScopingObject());
        return det;
    }
}

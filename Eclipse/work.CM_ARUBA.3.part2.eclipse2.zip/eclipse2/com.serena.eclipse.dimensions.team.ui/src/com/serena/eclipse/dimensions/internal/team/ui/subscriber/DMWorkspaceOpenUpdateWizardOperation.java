/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandLocalScope;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.actions.xml.MergeScopeGroup;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.UpdateStreamWizardFactory;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.WizardFactory;
import com.serena.eclipse.dimensions.internal.ui.actions.ShowDetailsAction;

public class DMWorkspaceOpenUpdateWizardOperation extends SynchronizeModelOperation {
    private ShowDetailsAction showDetailsAction;
    private String errorDetails;

    public DMWorkspaceOpenUpdateWizardOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        super(configuration, elements);
        showDetailsAction = new ShowDetailsAction();
        showDetailsAction.setShell(getShell());
    }

    @Override
    public void run(IProgressMonitor monitor) throws InvocationTargetException {
        SyncInfoSet set = getSyncInfoSet();
        if (set.isEmpty()) {
            return;
        }

        IResource[] resources = set.getResources();
        Set<IResource> projects = new HashSet<IResource>();
        for (int i = 0; i < resources.length; i++) {
            projects.add(resources[i].getProject());
        }
        try {
            // selected scope
            MergeCommandLocalScope mergeScope = MergeCommandLocalScope.createMergeCommandLocalScope(projects.toArray(new IResource[projects.size()]), true);
            if (mergeScope == null) {
                return;
            }

            ThreeWayWizard wizard = null;
            if (projects.size() > 0) {
                // potential scopes from top-level workspace projects
                List<MergeScopeGroup> possibleMergeScopes = MergeScopeGroup.createValidScopeGroups(mergeScope.getConnection());
                WizardFactory factory = new UpdateStreamWizardFactory(mergeScope, possibleMergeScopes, mergeScope.getConnection());
                wizard = new ThreeWayWizard(factory);
            }

            if (wizard == null) {
                return;
            }

            final ThreeWayWizardDialog dialog = new ThreeWayWizardDialog(getShell(), wizard);
            Display.getDefault().syncExec(new Runnable() {

                @Override
                public void run() {
                    BusyIndicator.showWhile(Display.getDefault(), new Runnable() {

                        @Override
                        public void run() {
                            if (dialog.open() == Window.CANCEL) {
                                return;
                            }
                        }

                    });
                }
            });
        } catch (CoreException e) {
            showDetailsAction.setDetails(errorDetails);
            throw new InvocationTargetException(e);
        }
    }

    @Override
    protected String getJobName() {
        return Messages.DMWorkspaceStreamUpdateOperation_0;
    }

    @Override
    protected IAction getGotoAction() {
        return showDetailsAction;
    }

}

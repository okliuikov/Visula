/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.ui.IWorkbenchPage;

import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.operations.BlameAnnotateLocalOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.BlameAnnotateOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.BlameAnnotateRemoteOperation;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 *
 * @author kberezovchuk
 *
 */
public class ItemBlameViewAction extends DMWorkspaceAction {
    private static final StatusFilter MANAGED_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED, StatusFilter.AND);

    public ItemBlameViewAction() {
    }

    @Override
    protected boolean isEnabledForMultipleResources() {
        return false;
    }

    @Override
    protected boolean isEnabledForFolder() {
        return false;
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return MANAGED_FILTER;
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] selectedResources = getSelectedResources();
        if (selectedResources == null || selectedResources.length == 0 || selectedResources[0].getType() != IResource.FILE) {
            return;
        }

        IFile file = (IFile) selectedResources[0];
        IWorkbenchPage activePage = UIUtils.getActivePage();
        try {
            boolean needRemoteEditor = TeamUtils.isFileModified(file);
            IDMRemoteResource baseResource = DMTeamPlugin.getWorkspace().getBaseResource(file);
            IDMRemoteResource remoteResource = DMTeamPlugin.getWorkspace().getRemoteResource(file);

            if (baseResource != null && baseResource instanceof IDMRemoteFile) {

                if (remoteResource != null && remoteResource instanceof IDMRemoteFile) {
                    IDMRemoteFile baseFile = (IDMRemoteFile) baseResource;
                    IDMRemoteFile remoteFile = (IDMRemoteFile) remoteResource;
                    String baseRevision = baseFile.getRevision();
                    String remoteRevision = remoteFile.getRevision();

                    if (!StringPath.isNullorEmpty(baseRevision) && !StringPath.isNullorEmpty(remoteRevision)) {
                        if (!baseRevision.equals(remoteRevision)) {
                            baseResource = remoteResource;
                            needRemoteEditor = true;
                        }
                    }
                }

                DimensionsConnectionDetailsEx connection = baseResource.getProject().getConnection();
                BlameAnnotateOperation op = null;
                if (!needRemoteEditor) {
                    op = new BlameAnnotateLocalOperation((IDMRemoteFile) baseResource, activePage, connection);
                } else {
                    op = new BlameAnnotateRemoteOperation((IDMRemoteFile) baseResource, activePage, connection);
                }
                op.execute();
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        }

    }

}
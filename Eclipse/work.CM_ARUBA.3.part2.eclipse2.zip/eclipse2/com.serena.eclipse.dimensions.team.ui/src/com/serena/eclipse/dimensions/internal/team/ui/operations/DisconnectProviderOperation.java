/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.RootIdmProject;
import com.serena.eclipse.dimensions.internal.team.core.VirtualIdmProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Disconnects projects from Dimensions.
 *
 * @author V.Grishchenko
 */
public class DisconnectProviderOperation extends RepositoryProviderOperation {
    private boolean deleteMeta;

    public DisconnectProviderOperation(IWorkbenchPart part, IResource[] resources, boolean deleteMeta) {
        super(part, resources);
        this.deleteMeta = deleteMeta;
    }

    @Override
    protected String getTaskName() {
        return Messages.unmapProviderOp_task;
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind(Messages.unmapProviderOp_providerTask, provider.getProject().getName());
    }

    @Override
    protected void execute(DMRepositoryProvider provider, IResource[] resources, IProgressMonitor monitor) throws DMException,
            InterruptedException {
        IProject project = provider.getProject();
        try {
            DMTeamPlugin.getWorkspace().unmanage(project, deleteMeta, monitor);
        } catch (CoreException e) {
            throw DMTeamUiPlugin.asDMException(e);
        }
    }

    @Override
    protected boolean canRunAsJob() {
        return false; // run in foreground
    }

    @Override
    protected ISchedulingRule getSchedulingRule(DMRepositoryProvider provider) {
        IProject mainProject = provider.getProject();
        List<IProject> rules = new ArrayList<IProject>();
        rules.add(mainProject);

        // find all possible children and add them all to rule
        IDMProject idmProject;
        try {
            idmProject = provider.getIdmProject();
            if (idmProject instanceof RootIdmProject) {
                List<VirtualIdmProject> virtualChildProjects = ((RootIdmProject) idmProject).getVirtualChildProjects();
                for (VirtualIdmProject virtualIdmProject : virtualChildProjects) {
                    IDMProject childIdmProject = virtualIdmProject;
                    rules.add(childIdmProject.getProject());
                }
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.log(e.getStatus());
        }

        MultiRule multiRule = new MultiRule(rules.toArray(new IResource[rules.size()]));
        return multiRule;
    }

}

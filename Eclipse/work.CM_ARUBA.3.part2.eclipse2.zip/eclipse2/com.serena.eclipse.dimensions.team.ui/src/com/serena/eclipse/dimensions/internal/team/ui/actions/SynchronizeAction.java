/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.compare.CompareUI;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.subscribers.Subscriber;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ResourceScope;
import org.eclipse.team.ui.synchronize.SyncInfoCompareInput;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.TeamUIUtils;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMSynchronizeParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceStreamCompareParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceStreamOutgoingParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceSynchronizeParticipant;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class SynchronizeAction extends DMWorkspaceAction {

    public SynchronizeAction() {
    }

    @Override
    protected boolean isEnabledForSelection() {
        if(this.getAction().getId().equals("com.serena.eclipse.dimensions.team.ui.actions.Shelve")) {
            if(isAnyResourceFromTopic()){
                return false;
            }
        }
        if (isSelectedSccProjectsMoved()) {
            return false;
        }
        return super.isEnabledForSelection();
    }

    protected boolean isAnyResourceFromTopic() {
        IResource[] resources = getSelectedResources();
        try {
            IDMWorkspace dmWorkspace = DMTeamPlugin.getWorkspace();
            Map<DimensionsArObject, String> cashedTypeNames = new HashMap<DimensionsArObject, String>();
            List<DimensionsConnectionDetailsEx> unconnected = Arrays.asList(DMPlugin.getDefault().getKnownUnconnectedLocations());
            for (int i = 0; i < resources.length; i++) {
            	IDMProject idmProject = dmWorkspace.getProject(resources[i].getProject());
            	if (unconnected.contains(idmProject.getConnection())) {
            		continue;
            	}
                DimensionsArObject dmArObject = idmProject.getDimensionsObject();
                String typeName = TeamUIUtils.getTypeNameFromResourceWithCash(dmArObject, cashedTypeNames); 
                if (IDMConstants.TOPIC_TYPE_NAME.equals(typeName)) {
                    return true;
                }
            }
        } catch (CoreException ce) {
            DMPlugin.log(ce.getStatus());
        }
        return false;
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources;
        try {
            resources = getResources();
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        if (resources.length == 0) {
            return;
        }

        boolean isAnySelectedResourceFromStream = false;
        // YC: 1. have to find sync infos first, then prompt for foreign stream participants.
        // otherwise sync infos could be empty because it is collected with another thread, and sync
        // view would ignore the participants.
        // 2. always collect/refresh syn infos, and don't use 'if (participant == null) ...',
        // because sync infos are cached if selection is not changed in the workspace
        final DMSynchronizeParticipant[] participantHolder = new DMSynchronizeParticipant[1];
        isAnySelectedResourceFromStream = TeamUtils.isAnyResourceFromStream(getSelectedResources());
        try {
            ResourceScope resourceScope = new ResourceScope(resources);
            if (isAnySelectedResourceFromStream) {
                TeamUIUtils.removeParticipantById(DMWorkspaceSynchronizeParticipant.ID);
                if (this instanceof CompareWithLatestAction) {
                    participantHolder[0] = new DMWorkspaceStreamCompareParticipant(resourceScope);
                } else {
                    participantHolder[0] = new DMWorkspaceStreamOutgoingParticipant(resourceScope);
                }
            } else {
                TeamUIUtils.removeParticipantById(DMWorkspaceStreamOutgoingParticipant.ID);
                TeamUIUtils.removeParticipantById(DMWorkspaceStreamCompareParticipant.ID);
                participantHolder[0] = new DMWorkspaceSynchronizeParticipant(resourceScope);
            }
        } catch (TeamException e) {
            DMTeamUiPlugin.log(e.getStatus());
        }

        TeamUI.getSynchronizeManager().addSynchronizeParticipants(new ISynchronizeParticipant[] { participantHolder[0] });

        participantHolder[0].refresh(resources, Messages.SynchronizeAction_0,
                NLS.bind(Messages.SynchronizeAction_1, participantHolder[0].getName()), getActivePart().getSite());
        TeamUIUtils.filterSyncJobResults(participantHolder[0], getShell());
    }

    /**
     * Refresh the subscriber directly and show the resulting synchronization state in a compare editor. If there
     * is no difference the user is prompted.
     *
     * @param resources
     *            the file to refresh and compare
     */
    public static void showSingleFileComparison(final Shell shell, final Subscriber subscriber, final IResource resource) {
        try {
            PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    try {
                        subscriber.refresh(new IResource[] { resource }, IResource.DEPTH_ZERO, monitor);
                    } catch (TeamException e) {
                        throw new InvocationTargetException(e);
                    }
                }
            });
            final SyncInfo info = subscriber.getSyncInfo(resource);
            if (info == null) {
                return;
            }
            shell.getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    if (info.getKind() == SyncInfo.IN_SYNC) {
                        MessageDialog.openInformation(shell, Messages.SynchronizeAction_2, Messages.SynchronizeAction_3);
                    } else {
                        SyncInfoCompareInput input = new SyncInfoCompareInput(subscriber.getName(), info);
                        CompareUI.openCompareEditor(input);
                    }
                }
            });
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        } catch (InterruptedException e) {
        } catch (TeamException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        }
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

    public static boolean isSingleFile(IResource[] resources) {
        return resources.length == 1 && resources[0].getType() == IResource.FILE;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.BaselineList;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsObjectList;
import com.serena.eclipse.dimensions.internal.ui.AttributeColumnDetails;
import com.serena.eclipse.dimensions.internal.ui.AttributeUtils;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListConfiguration;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class BaselineListConfiguration extends DimensionsObjectListConfiguration {
    public static final QualifiedName GENERIC = new QualifiedName(BaselineListConfiguration.class.getName(), "generic"); //$NON-NLS-1$
    /** all baselines */
    public static final QualifiedName OTHER = new QualifiedName(BaselineListConfiguration.class.getName(), "other_baselines"); //$NON-NLS-1$
    /** ide project baselines */
    public static final QualifiedName IDE_PROJECT = new QualifiedName(BaselineListConfiguration.class.getName(),
            "ide_project_baselines"); //$NON-NLS-1$
    /** ide project group baselines */
    public static final QualifiedName IDE_PROJECT_GROUP = new QualifiedName(BaselineListConfiguration.class.getName(),
            "ide_project_group_baselines"); //$NON-NLS-1$;

    public BaselineListConfiguration(DimensionsConnectionDetailsEx con, QualifiedName qualifier) {
        super(DMTypeScope.BASELINE, con, qualifier);
    }

    @Override
    public boolean isMultiPage() {
        return DMTeamUiPlugin.getDefault().isMultiPageLayoutForProjectList();
    }

    @Override
    protected AttributeColumnDetails[] getDefaultGrouping() {
        AttributeColumnDetails[] defaultGroupOrder = new AttributeColumnDetails[1];
        defaultGroupOrder[0] = createSystem(SystemAttributes.PRODUCT_NAME);
        return defaultGroupOrder;
    }

    @Override
    public AttributeColumnDetails getDefaultSortColumn() {
        return createSystem(SystemAttributes.OBJECT_SPEC);
    }

    @Override
    protected AttributeColumnDetails[] getDefaultColumns() {
        AttributeColumnDetails[] defaults = new AttributeColumnDetails[5];
        defaults[0] = createSystem(SystemAttributes.OBJECT_SPEC);
        defaults[1] = createSystem(SystemAttributes.STATUS);
        defaults[2] = createSystem(SystemAttributes.CREATION_DATE);
        defaults[3] = createSystem(SystemAttributes.CREATION_USER);
        defaults[4] = createSystem(SystemAttributes.DESCRIPTION);
        return defaults;
    }

    @Override
    protected AttributeColumnDetails[] getSystemColumns() {
        int[] sysAttrs = AttributeUtils.getBaselineSystemAttributes();
        AttributeColumnDetails[] columns = new AttributeColumnDetails[sysAttrs.length];
        for (int i = 0; i < sysAttrs.length; i++) {
            columns[i] = createSystem(sysAttrs[i]);
        }
        return columns;
    }

    @Override
    public String getPageTitle(DimensionsObjectList list) {
        if (list instanceof BaselineList) {
            switch (list.getType()) {
            case BaselineList.OTHER_BASELINES:
                return Messages.BaselineListConfiguration_otherBaselines;
            case BaselineList.PROJECT_BASELINES:
            case BaselineList.GROUP_BASELINES:
                return NLS.bind(Messages.BaselineListConfiguration_prjBaselines, list.getQualifier());
            }
        }
        return super.getPageTitle(list);
    }

    @Override
    public ImageDescriptor getImageDescriptor(DimensionsObjectList list) {
        return DMUIPlugin.getDefault().getImageDescriptor(IDMImages.OTHER_BASELINES);
    }

}

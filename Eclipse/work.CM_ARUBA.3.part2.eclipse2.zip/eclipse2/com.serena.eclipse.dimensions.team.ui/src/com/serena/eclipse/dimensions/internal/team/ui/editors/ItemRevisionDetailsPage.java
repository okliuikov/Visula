/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.editors;

import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditor;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorPage;
import com.serena.eclipse.dimensions.internal.ui.forms.ObjectDetailsSection;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;

/**
 * Item Revision details page, displayed first in the document editor.
 *
 * @author A.Bollmann
 */
public class ItemRevisionDetailsPage extends DimensionsObjectEditorPage {
    public static final String ID = "bl_details_page_id"; //$NON-NLS-1$

    public ItemRevisionDetailsPage(DimensionsObjectEditor editor, String title, String formText, IDimensionsArObjectModel model) {
        super(editor, ID, title, formText, model);
    }

    @Override
    protected void fillBody(IManagedForm managedForm, FormToolkit toolkit) {
        Composite body = managedForm.getForm().getBody();
        body.setLayout(new FillLayout());
        ObjectDetailsSection ods = getObjectEditor().createDetailsSection(body, this);
        managedForm.addPart(ods);
    }
}

/*
 * @DMTeamPreferencePage.java, created on May 5, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IScopeContext;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.osgi.service.prefs.BackingStoreException;
import org.osgi.service.prefs.Preferences;

import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Version management preference page.
 *
 * @author V.Grishchenko
 */
public class DMTeamPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage, IDMTeamPreferences {

    /**
     * @param style
     */
    public DMTeamPreferencePage() {
        super(GRID);
        setDescription(Messages.teamPrefPage_descr);
        setPreferenceStore(DMTeamUiPlugin.getDefault().getPreferenceStore());
    }

    @Override
    protected void createFieldEditors() {
        addField(new BooleanFieldEditor(DELETE_UNMANAGED_ON_REPLACE, Messages.teamPrefPage_deleteOnReplace, getFieldEditorParent()));

        addField(new BooleanFieldEditor(COMPARE_CONSIDER_CONTENTS, Messages.teamPrefPage_considerContents, getFieldEditorParent()));

        addField(new BooleanFieldEditor(AUTO_FIND_ANCESTOR, Messages.teamPrefPage_findAncestor, getFieldEditorParent()));

        addField(new BooleanFieldEditor(PRESELECT_DEFAULT_REQUESTS, Messages.teamPrefPage_preselectDefaultRequests,
                getFieldEditorParent()));

        addField(new BooleanFieldEditor(CLEAN_TIMESTAMPS, Messages.teamPrefPage_cleanTimestamps, getFieldEditorParent()));

        addField(new BooleanFieldEditor(EXPAND_SUBSTITUTION, Messages.teamPrefPage_expandVariables, getFieldEditorParent()));

        addField(new BooleanFieldEditor(AUTO_SHARE, Messages.teamPrefPage_autoShare, getFieldEditorParent()));
        
        addField(new BooleanFieldEditor(IGNORE_DERIVED_RESOURCES, Messages.teamPrefPage_ignoreDerivedResources,
                getFieldEditorParent()));

    }

    @Override
    public void init(IWorkbench workbench) {
    }

    @Override
    public boolean performOk() {
        boolean ok = super.performOk();
        DMTeamUiPlugin.getDefault().savePluginPreferences();
        // Need to access this flag from TeamUtils.java which is in com.serena.eclipse.dimensions.team.core plugin and hence setting
        // it at the eclipse instance scope level
        setConsiderCompareContentPreference(DMTeamUiPlugin.getDefault()
                .getPreferenceStore()
                .getBoolean(IDMTeamPreferences.COMPARE_CONSIDER_CONTENTS) ? TeamUtils.YES : TeamUtils.NO);
        setExpandSubstitutionPreference(DMTeamUiPlugin.getDefault()
                .getPreferenceStore()
                .getBoolean(IDMTeamPreferences.EXPAND_SUBSTITUTION));
        setIgnoreDerivedResourcesPreference(
                DMTeamUiPlugin.getDefault().getPreferenceStore().getBoolean(IDMTeamPreferences.IGNORE_DERIVED_RESOURCES));
        return ok;
    }

    public static boolean setConsiderCompareContentPreference(String value) {
        IScopeContext instanceContext = new InstanceScope();
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.put(TeamUtils.COMPARE_CONSIDER_FILE_CONTENTS, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setExpandSubstitutionPreference(boolean value) {
        IScopeContext instanceContext = new InstanceScope();
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(TeamUtils.EXPAND_SUBSTITUTION, value);
        }
        return saveNode(instanceNode);
    }
    
    public static boolean setIgnoreDerivedResourcesPreference(boolean value) {
        IScopeContext instanceContext = new InstanceScope();
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(TeamUtils.IGNORE_DERIVED_RESOURCES, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean saveNode(Preferences node) {
        try {
            node.flush();
            return true;
        } catch (BackingStoreException e) {
            return false;
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import org.eclipse.core.resources.IResource;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import com.serena.dmfile.xml.Resolution;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * Property model for the {@link XMLSyncInfo}
 */
public class XMLSyncInfoPropertySource implements IPropertySource {
    private static final String DETAILS = "DETAILS";//$NON-NLS-1$
    private static final String TARGET_FILE_PATH = "TARGET_FILE_PATH";//$NON-NLS-1$
    private static final String LOCAL_FILE_PATH = "LOCAL_FILE_PATH";//$NON-NLS-1$
    private static final String LOCAL_SPEC = "LOCAL_SPEC";//$NON-NLS-1$
    private static final String REMOTE_FILE_PATH = "REMOTE_FILE_PATH";//$NON-NLS-1$
    private static final String REMOTE_SPEC = "REMOTE_SPEC";//$NON-NLS-1$
    private static final String ANCESTOR_FILE_PATH = "ANCESTOR_FILE_PATH";//$NON-NLS-1$
    private static final String ANCESTOR_SPEC = "ANCESTOR_SPEC";//$NON-NLS-1$
    private static final String USER_ACTION_CONTENT = "USER_ACTION_CONTENT";//$NON-NLS-1$
    private static final String USER_ACTION_PATH = "USER_ACTION_PATH";//$NON-NLS-1$
    private static final String USER_ACTION_ITEM = "USER_ACTION_ITEM";//$NON-NLS-1$

    private static final String DETAILS_CATEGORY = Messages.DMXMLMergeParticipant_prop_infocategory;
    private static final String RESOLUTION_CATEGORY = Messages.DMXMLMergeParticipant_prop_usercategory;
    private static final String PATHS_CATEGORY = Messages.DMXMLMergeParticipant_prop_pathcategory;
    private static final String REVISIONS_CATEGORY = Messages.DMXMLMergeParticipant_prop_speccategory;

    private final XMLSyncInfo info;

    public XMLSyncInfoPropertySource(XMLSyncInfo info) {
        this.info = info;
    }

    @Override
    public Object getEditableValue() {
        return null;
    }

    @Override
    public IPropertyDescriptor[] getPropertyDescriptors() {
        PropertyDescriptor details = new PropertyDescriptor(DETAILS, Messages.DMXMLMergeParticipant_prop_details);
        details.setCategory(DETAILS_CATEGORY);

        PropertyDescriptor localFilePath = new PropertyDescriptor(LOCAL_FILE_PATH, Messages.DMXMLMergeParticipant_prop_local);
        localFilePath.setCategory(PATHS_CATEGORY);

        PropertyDescriptor localFileRevision = new PropertyDescriptor(LOCAL_SPEC, Messages.DMXMLMergeParticipant_prop_local);
        localFileRevision.setCategory(REVISIONS_CATEGORY);

        PropertyDescriptor remoteFilePath = new PropertyDescriptor(REMOTE_FILE_PATH, Messages.DMXMLMergeParticipant_prop_remote);
        remoteFilePath.setCategory(PATHS_CATEGORY);

        PropertyDescriptor remoteFileRev = new PropertyDescriptor(REMOTE_SPEC, Messages.DMXMLMergeParticipant_prop_remote);
        remoteFileRev.setCategory(REVISIONS_CATEGORY);

        PropertyDescriptor ancestorFilePath = new PropertyDescriptor(ANCESTOR_FILE_PATH,
                Messages.DMXMLMergeParticipant_prop_ancestor);
        ancestorFilePath.setCategory(PATHS_CATEGORY);

        PropertyDescriptor ancestorFileRev = new PropertyDescriptor(ANCESTOR_SPEC, Messages.DMXMLMergeParticipant_prop_ancestor);
        ancestorFileRev.setCategory(REVISIONS_CATEGORY);

        PropertyDescriptor content = new PropertyDescriptor(USER_ACTION_CONTENT, Messages.DMXMLMergeParticipant_prop_action_content);
        content.setCategory(RESOLUTION_CATEGORY);

        PropertyDescriptor path = new PropertyDescriptor(USER_ACTION_PATH, Messages.DMXMLMergeParticipant_prop_action_path);
        path.setCategory(RESOLUTION_CATEGORY);

        PropertyDescriptor item = new PropertyDescriptor(USER_ACTION_ITEM, Messages.DMXMLMergeParticipant_prop_action_item);
        item.setCategory(RESOLUTION_CATEGORY);

        return new IPropertyDescriptor[] { details, localFilePath, localFileRevision, remoteFilePath, remoteFileRev,
                ancestorFilePath, ancestorFileRev, content, path, item };
    }

    @Override
    public Object getPropertyValue(Object id) {
        Resolution resolution = info.getResolution();
        if (DETAILS.equals(id)) {
            return resolution.getMessage();
        } else if (TARGET_FILE_PATH.equals(id)) {
            return resolution.getRelPath();
        } else if (LOCAL_FILE_PATH.equals(id)) {
            IResource local = info.getLocalResource();
            if (local != null) {
                String string = local.getFullPath().toString();
                if (string.indexOf('/') == 0 || string.indexOf('\\') == 0) {
                    return string.substring(1, string.length());
                }
                return string;
            }
        } else if (REMOTE_FILE_PATH.equals(id)) {
            if (resolution.getSrc() != null) {
                return resolution.getSrc().getRelPath();
            }
        } else if (ANCESTOR_FILE_PATH.equals(id)) {
            if (resolution.getAnc() != null) {
                return resolution.getAnc().getRelPath();
            }
        } else if (LOCAL_SPEC.equals(id)) {
            if (resolution.getTgt() != null) {
                return resolution.getTgt().getSpec();
            }
        } else if (REMOTE_SPEC.equals(id)) {
            if (resolution.getSrc() != null) {
                return resolution.getSrc().getSpec();
            }
        } else if (ANCESTOR_SPEC.equals(id)) {
            if (resolution.getAnc() != null) {
                return resolution.getAnc().getSpec();
            }
        } else if (USER_ACTION_CONTENT.equals(id)) {
            return XMLMergeUIUtils.resolveActionContent(info);
        } else if (USER_ACTION_PATH.equals(id)) {
            return XMLMergeUIUtils.resolveActionPath(info);
        } else if (USER_ACTION_ITEM.equals(id)) {
            return XMLMergeUIUtils.resolveActionItem(info);
        }
        return "";
    }

    @Override
    public boolean isPropertySet(Object id) {
        return false;
    }

    @Override
    public void resetPropertyValue(Object id) {
    }

    @Override
    public void setPropertyValue(Object id, Object value) {
    }

}
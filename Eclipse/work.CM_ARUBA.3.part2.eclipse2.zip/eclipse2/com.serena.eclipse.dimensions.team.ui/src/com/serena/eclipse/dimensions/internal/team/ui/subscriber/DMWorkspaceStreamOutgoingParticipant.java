/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.compare.CompareConfiguration;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.core.synchronize.SyncInfoTree;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;
import org.eclipse.team.ui.synchronize.SynchronizePageActionGroup;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.PartInitException;

import com.serena.dmfile.dto.Pair;
import com.serena.dmfile.sync.Shape;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.TransferShape;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.actions.CleanTimestampsAction;
import com.serena.eclipse.dimensions.internal.team.ui.actions.IgnoreAction;
import com.serena.eclipse.dimensions.internal.team.ui.actions.ItemHistoryAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class DMWorkspaceStreamOutgoingParticipant extends DMSynchronizeParticipant {
    public static final String ID = "com.serena.eclipse.dimensions.team.dmworkspace-stream-outgoing-participant"; //$NON-NLS-1$
    public static final String TOOLBAR_CONTRIBUTION_GROUP = "toolbar_group"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_1 = "ctx_group_1"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_2 = "ctx_group_2"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_3 = "ctx_group_3"; //$NON-NLS-1$

    @Override
    public void prepareCompareInput(ISynchronizeModelElement element, CompareConfiguration config, IProgressMonitor monitor)
            throws TeamException {
        super.prepareCompareInput(element, config, monitor);

        config.setLeftEditable(false);
        if (element instanceof IAdaptable) {
            SyncInfo syncInfo = (SyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
            if (syncInfo != null) {
                int kind = syncInfo.getKind();
                if ((kind & SyncInfo.DIRECTION_MASK) == SyncInfo.OUTGOING) {
                    config.setLeftEditable(true);
                }
            }
        }
    }

    protected class WorkspaceActionContribution extends SynchronizePageActionGroup {

        @Override
        public void initialize(ISynchronizePageConfiguration configuration) {
            super.initialize(configuration);

            // toolbar actions
            DMWorkspaceStreamDeliverAction deliverToolbarAction = new DMWorkspaceStreamDeliverAction(configuration,
                    getVisibleRootsSelectionProvider());
            deliverToolbarAction.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.DELIVER_ACTION));
            deliverToolbarAction.setToolTipText(Messages.DMWorkspaceSynchronizeParticipant_2);

            DMWorkspaceStreamShelveAction shelveToolbarAction = new DMWorkspaceStreamShelveAction(configuration,
                    getVisibleRootsSelectionProvider());
            shelveToolbarAction.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.SHELVE_ACTION));
            shelveToolbarAction.setToolTipText(Messages.DMWorkspaceSynchronizeParticipant_3);

            appendToGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP, deliverToolbarAction);

            appendToGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP, shelveToolbarAction);

            DMWorkspaceStreamDeliverAction contextDeliver = new DMWorkspaceStreamDeliverAction(configuration);
            contextDeliver.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.DELIVER_ACTION));
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1, contextDeliver);

            DMWorkspaceStreamShelveAction contextShelve = new DMWorkspaceStreamShelveAction(configuration);
            contextShelve.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.SHELVE_ACTION));
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1, contextShelve);

            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1,
                    new DMOverrideAndUpdateAction(configuration, Messages.DMOverrideAndUpdateAction_1));

            if (!configuration.getSite().isModal()) {
                // use action names from plugin.properties to avoid duplication
                String historyLabel = "!history action key changed in plugin.properties!"; //$NON-NLS-1$
                String ignoreLabel = "!ignore action key changed in plugin.properties!"; //$NON-NLS-1$
                String cleanTsLabel = "!clean timestamps action key changed in plugin.properties"; //$NON-NLS-1$
                try {
                    historyLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "ShowHistory.label"); //$NON-NLS-1$
                    ignoreLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString("Ignore.label"); //$NON-NLS-1$
                    cleanTsLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "CleanTimestamps.label"); //$NON-NLS-1$
                } catch (Exception e) {
                }
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(historyLabel, new ItemHistoryAction(), configuration));
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(ignoreLabel, new IgnoreAction(), configuration));
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(cleanTsLabel, new CleanTimestampsAction(), configuration));
            }
        }

        @Override
        public void fillContextMenu(IMenuManager menu) {
            super.fillContextMenu(menu);

            ISelection selection = getConfiguration().getSite().getSelectionProvider().getSelection();
            if (selection instanceof IStructuredSelection) {
                IStructuredSelection sel = (IStructuredSelection) selection;
                // try to find common actions for selected nodes

                boolean rootsSelected = true;
                for (Iterator<?> iterator = sel.iterator(); iterator.hasNext();) {
                    Object element = iterator.next();

                    if (!(element instanceof ISynchronizeModelElement)) {
                        rootsSelected = false;
                        break;
                    }

                    ISynchronizeModelElement selement = (ISynchronizeModelElement) element;
                    IResource resource = selement.getResource();

                    if (!(resource instanceof IProject)) {
                        rootsSelected = false;
                        break;
                    }

                }

                if (rootsSelected) {
                    menu.appendToGroup(CONTEXT_MENU_CONTRIBUTION_GROUP_2, new DMWorkspaceStreamUpdateWizardAction(
                            getConfiguration(), getVisibleRootsSelectionProvider()));
                }
            }
        }
    }

    /**
     * No-arg constructor to be invoked on registry creation
     */
    public DMWorkspaceStreamOutgoingParticipant() {
    }

    /**
     * per project collects information about scope resources and scope (TREE or LIST)
     */
    private Map<IProject, Pair<Shape, List<IResource>>> shapes = new HashMap<IProject, Pair<Shape, List<IResource>>>();

    /**
     * set of changes that were excluded from original set of changes on initialization stage
     */
    private SyncInfoSet infoExcludedByCaller = new SyncInfoSet();

    public DMWorkspaceStreamOutgoingParticipant(ISynchronizeScope scope) {
        super(scope);
        setSubscriber(DMTeamPlugin.getWorkspace().getSubscriber());
        IResource[] roots = scope.getRoots();

        for (int i = 0; i < roots.length; i++) {

            IProject project = roots[i].getProject();

            if (shapes.containsKey(project)) {
                // if exists then scope should be MULTISELECT (user selected more than one child resources in project for deliver)
                Pair<Shape, List<IResource>> projectScope = shapes.get(project);
                projectScope.setFirst(Shape.MULTISELECT);
                projectScope.getSecond().add(roots[i]);
            } else {
                // if new then scope should be TREE unless resource is a file
                Shape shape;
                if (roots[i] instanceof IFile) {
                    shape = Shape.MULTISELECT;
                } else if (!roots[i].getProjectRelativePath().isEmpty()) {
                    shape = Shape.MULTISELECT;
                } else {
                    shape = Shape.TREE;
                }
                Pair<Shape, List<IResource>> projectScope = new Pair<Shape, List<IResource>>(shape, new ArrayList<IResource>());
                projectScope.getSecond().add(roots[i]);
                shapes.put(project, projectScope);
            }
        }
    }

    public SyncInfoSet getAllOutgoingSyncInfoSet() {
        SyncInfoSet result = new SyncInfoSet();
        SyncInfoTree infoSet = getSyncInfoSet();
        if (infoSet != null) {
            result.addAll(infoSet);
            if (infoExcludedByCaller != null) {
                // remove from excluded set all resources that again appeared in original set
                infoExcludedByCaller.removeAll(result.getResources());

                // and add filtered excluded info to result
                result.addAll(infoExcludedByCaller);
            }

            result.removeIncomingNodes();
        }
        return result;
    }

    @Override
    public void init(String secondaryId, IMemento memento) throws PartInitException {
        super.init(secondaryId, memento);
        setSubscriber(DMTeamPlugin.getWorkspace().getSubscriber());
    }

    @Override
    protected ISynchronizeParticipantDescriptor getDescriptor() {
        return TeamUI.getSynchronizeManager().getParticipantDescriptor(ID);
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP);
        configuration.addActionContribution(new WorkspaceActionContribution());

        int mode = ISynchronizePageConfiguration.OUTGOING_MODE;
        int supported = ISynchronizePageConfiguration.OUTGOING_MODE | ISynchronizePageConfiguration.CONFLICTING_MODE;
        configuration.setSupportedModes(supported);
        configuration.setMode(mode);

        // Add context menu groups here to give the client displaying the
        // page a chance to remove the context menu
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3);
    }

    /**
     * @return the shape for project delivery
     */
    public TransferShape getTransferShape(IProject project) {
        Pair<Shape, List<IResource>> shape = shapes.get(project);

        if (shape == null || shape.getSecond() == null || shape.getSecond().size() == 0) {
            // play safe and return tree shape
            return new TransferShape.TreeShape(project);
        }

        if (shape.getFirst() == Shape.TREE) {
            return new TransferShape.TreeShape(shape.getSecond().get(0));
        } else {
            return new TransferShape.MultiselectShape(shape.getSecond());
        }
    }

    public void setInfoExcludedByCaller(SyncInfoSet excludedByCaller) {
        this.infoExcludedByCaller = excludedByCaller;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions.xml;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;

import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.actions.DMWorkspaceAction;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.WizardFactory;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Action that creates wizard from requests that were selected by user
 */
public abstract class RequestWizardAction extends DMWorkspaceAction {

    protected abstract WizardFactory createWizardFactory(VersionManagementProject foreignProject,
            List<ChangeDocumentAdapter> preselected, List<MergeScopeGroup> possibleScopes, DimensionsConnectionDetailsEx connection);

    @Override
    protected boolean isEnabledForSelection() {
        final IStructuredSelection selection = getSelection();
        if (selection.isEmpty()) {
            return false;
        }

        List<MergeScopeGroup> possibleMergeScopes = null;
        try {
            // suppose the whole selection is ChangeDocumentAdapter list from the single connection
            if (selection.getFirstElement() instanceof ChangeDocumentAdapter) {
                DimensionsConnectionDetailsEx conn = ((ChangeDocumentAdapter) selection.getFirstElement()).getConnectionDetails();
                possibleMergeScopes = MergeScopeGroup.createValidScopeGroups(conn);
                for (@SuppressWarnings("rawtypes")
                Iterator chDocs = getSelection().toList().iterator(); chDocs.hasNext();) {
                    Object chDoc = chDocs.next();
                    if (!(chDoc instanceof ChangeDocumentAdapter)
                            || !conn.equals(((ChangeDocumentAdapter) chDoc).getConnectionDetails())
                            || possibleMergeScopes.isEmpty()) {
                        return false;
                    }
                }
                return true;
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
            return false;
        }

        return false;
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IStructuredSelection selection = getSelection();

        ThreeWayWizard wizard = null;
        if (!(selection.getFirstElement() instanceof ChangeDocumentAdapter)) {
            return;
        }

        if (selection.getFirstElement() instanceof ChangeDocumentAdapter) {
            // if the action was invoked from Requests View
            try {
                // implies size > 0
                List<ChangeDocumentAdapter> preselected = getPreselectedRequests();
                DimensionsConnectionDetailsEx connection = preselected.get(0).getConnectionDetails();

                List<Request> reqs = new ArrayList<Request>(preselected.size());
                for (ChangeDocumentAdapter changeDocumentAdapter : preselected) {
                    reqs.add((Request) changeDocumentAdapter.getAPIObject());
                }

                Project project = TeamUtils.getSingleStreamRelatedToRequests(reqs, connection);
                VersionManagementProject foreignProject = null;
                if (project != null) {
                    foreignProject = new WorksetAdapter(project, connection);
                }

                // potential scopes from top-level workspace projects
                List<MergeScopeGroup> possibleScopes = MergeScopeGroup.createValidScopeGroups(connection);
                WizardFactory factory = createWizardFactory(foreignProject, preselected, possibleScopes, connection);
                wizard = new ThreeWayWizard(factory);
            } catch (CoreException e) {
                DMTeamUiPlugin.getDefault().handle(e, getShell());
            }
        }

        if (wizard == null) {
            return;
        }

        final ThreeWayWizardDialog dialog = new ThreeWayWizardDialog(getShell(), wizard);
        BusyIndicator.showWhile(Display.getDefault(), new Runnable() {

            @Override
            public void run() {
                if (dialog.open() == Window.CANCEL) {
                    return;
                }
            }

        });
    }

    /*
     * Should be used if the action was invoked from the Request View only (it implies requests.size() > 0)
     */
    protected List<ChangeDocumentAdapter> getPreselectedRequests() {
        final List<ChangeDocumentAdapter> requests = new ArrayList<ChangeDocumentAdapter>();
        // get preselected requests if the wizard was started from Requests View
        for (@SuppressWarnings("rawtypes")
        Iterator iterator = getSelection().iterator(); iterator.hasNext();) {
            Object elem = iterator.next();
            if (elem instanceof ChangeDocumentAdapter) {
                requests.add((ChangeDocumentAdapter) elem);
            }
        }
        return requests;
    }

}

package com.serena.eclipse.dimensions.internal.team.ui.commands;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.handlers.HandlerUtil;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;
import com.serena.eclipse.dimensions.ui.actions.ShowReviewByButtonClickAction;

public class ChangeSetOpenInDCHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        IWorkbenchSite activeSite = HandlerUtil.getActiveSite(event);
        ChangeSetHistoryView view = (ChangeSetHistoryView) activeSite.getPage().findView(ChangeSetHistoryView.ID);
        IWorkbenchSite site = view.getSite();
        ISelectionProvider selectionProvider = site.getSelectionProvider();
        TreeSelection selection = (TreeSelection) selectionProvider.getSelection();
        Object selObject = selection.getFirstElement();
        DimensionsChangeSet cs = (DimensionsChangeSet) selObject;
        ShowReviewByButtonClickAction action = new ShowReviewByButtonClickAction(view.getConnection(), cs);
        action.run(null);
        return null;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

/**
 * Displays merge summary.
 *
 * @author V.Grishchenko
 */
class MergeSummaryPage extends DimensionsWizardPage {
    private Text connectionTxt;
    private Text sourceTxt;
    private Text sourceTypeTxt;
    private Text ancestorTxt;
    private Text targetTxt;
    private Text targetTypeTxt;
    private Text localTargetTxt;

    public MergeSummaryPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage, description);
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 2);

        UIUtils.createLabel(composite, Messages.MergeSummaryPage_0);
        connectionTxt = UIUtils.createText(composite, SWT.READ_ONLY, null);
        UIUtils.setGridData(connectionTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.MergeSummaryPage_1);
        sourceTxt = UIUtils.createText(composite, SWT.READ_ONLY, null);
        UIUtils.setGridData(sourceTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.MergeSummaryPage_2);
        sourceTypeTxt = UIUtils.createText(composite, SWT.READ_ONLY, null);
        UIUtils.setGridData(sourceTypeTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.MergeSummaryPage_3);
        ancestorTxt = UIUtils.createText(composite, SWT.READ_ONLY, null);
        UIUtils.setGridData(ancestorTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.MergeSummaryPage_4);
        targetTxt = UIUtils.createText(composite, SWT.READ_ONLY, null);
        UIUtils.setGridData(targetTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.MergeSummaryPage_5);
        targetTypeTxt = UIUtils.createText(composite, SWT.READ_ONLY, null);
        UIUtils.setGridData(targetTypeTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, Messages.MergeSummaryPage_6);
        localTargetTxt = UIUtils.createText(composite, SWT.READ_ONLY, null);
        UIUtils.setGridData(localTargetTxt, GridData.FILL_HORIZONTAL);

        setControl(composite);
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            MergeWizard mergeWizard = (MergeWizard) getWizard();
            connectionTxt.setText(mergeWizard.getTarget() != null
                    ? mergeWizard.getTarget().getConnectionDetails().getConnName() : Utils.EMPTY_STRING);
            sourceTxt.setText(mergeWizard.getSource() != null ? getIdString(mergeWizard.getSource()) : Utils.EMPTY_STRING);
            sourceTypeTxt.setText(mergeWizard.getSource() != null ? getTypeString(mergeWizard.getSource()) : Utils.EMPTY_STRING);
            ancestorTxt.setText(mergeWizard.getAncestor() != null ? getIdString(mergeWizard.getAncestor()) : Utils.EMPTY_STRING);
            targetTxt.setText(mergeWizard.getTarget() != null ? getIdString(mergeWizard.getTarget()) : Utils.EMPTY_STRING);
            targetTypeTxt.setText(mergeWizard.getTarget() != null ? getTypeString(mergeWizard.getTarget()) : Utils.EMPTY_STRING);
            localTargetTxt.setText(mergeWizard.getLocalTarget() != null
                    ? mergeWizard.getLocalTarget().getName() : Utils.EMPTY_STRING);
        }
        super.setVisible(visible);
    }

    private String getIdString(VersionManagementProject project) {
        String id = project.getProjectSpec();
        if (project instanceof SccProject) {
            id = NLS.bind(Messages.MergeSummaryPage_7, id, ((SccProject) project).getOffset());
        }
        return id;
    }

    private String getTypeString(VersionManagementProject project) {
        if (project instanceof SccProject) {
            return ((SccProject) project).getProjectContainer().getTypeScope().getDisplayText();
        }
        return project.getTypeScope().getDisplayText();

    }

}

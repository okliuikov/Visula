package com.serena.eclipse.dimensions.internal.team.ui;

import java.util.List;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IEditorPart;

import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotateRevision;

public class BlameRequestPropertyTester extends PropertyTester {

    private final static String ONE_REQUEST = "oneRequest";//$NON-NLS-1$
    private final static String SEVERAL_REQUESTS = "severalRequests";//$NON-NLS-1$
    private final static String VISIBILITY_PROPERTY = "checkRequestVisibility";//$NON-NLS-1$
    private final static String ENABLEMENT_PROPERTY = "checkRequestEnablement";//$NON-NLS-1$

    public BlameRequestPropertyTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (receiver instanceof IEditorPart) {
            IEditorPart part = (IEditorPart) receiver;
            StructuredSelection ssel = UIUtils.getStructuredSelectionFromRuler(part);
            Object selObj = null;
            if (ssel != null && ssel.size() > 0 && ((selObj = ssel.getFirstElement()) instanceof BlameAnnotateRevision)) {
                BlameAnnotateRevision revision = (BlameAnnotateRevision) selObj;
                List<String> requests = revision.getRequests();
                if (property.equals(VISIBILITY_PROPERTY) && (requests == null || requests.size() <= 1)
                        && expectedValue.equals(ONE_REQUEST)) {
                    return true;
                } else if (property.equals(VISIBILITY_PROPERTY) && requests != null && requests.size() > 1
                        && expectedValue.equals(SEVERAL_REQUESTS)) {
                    return true;
                } else if (property.equals(ENABLEMENT_PROPERTY) && requests != null && requests.size() > 0) {
                    return true;
                }
            }
        }

        return false;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.DownloadRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class UpdateFromRemoteOperation extends UpdateWorkspaceOperation {

    public UpdateFromRemoteOperation(IWorkbenchPart part, IResource[] resources) {
        super(part, resources);
    }

    public UpdateFromRemoteOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    protected boolean refreshBeforeUpdate() {
        return true;
    }

    protected void addSkippedFiles(IStatus status) {
        if (status.isOK()) {
            return;
        }
        if (status instanceof DMTeamStatus && ((DMTeamStatus) status).getResource() != null
                && ((DMTeamStatus) status).getResource().getType() == IResource.FILE) {
            addSkippedFile((IFile) ((DMTeamStatus) status).getResource());
            DMTeamUiPlugin.log(status);
            return;
        }
        IStatus[] children = status.getChildren();
        for (int i = 0; i < children.length; i++) {
            addSkippedFiles(children[i]);
        }
    }

    protected void update(DMRepositoryProvider provider, IResource[] resources, IProgressMonitor monitor) throws CoreException,
            InterruptedException {

        DownloadRequest[] requests = new DownloadRequest[resources.length];
        for (int i = 0; i < requests.length; i++) {
            requests[i] = new DownloadRequest(resources[i]);
        }
        addSkippedFiles(provider.getIdmProject().download(requests, shouldOverwrite(), isDeleteUnmanaged(), monitor));
    }

    /**
     * @return <code>true</code> for overwrite during download, returns <code>false</code> otherwise
     */
    protected boolean shouldOverwrite() {
        return false;
    }

    /**
     * Answers if any outgoing additions should be discarded. This
     * implementation returns <code>false</code>.
     *
     * @return <code>true</code> if any new files or folders should be
     *         deleted, returns <code>false</code> otherwise
     */
    protected boolean isDeleteUnmanaged() {
        return false;
    }

    @Override
    protected void execute(DMRepositoryProvider provider, IResource[] resources, IProgressMonitor monitor) throws CoreException,
            InterruptedException {

        if (resources == null || resources.length == 0) {
            return;
        }

        try {
            IProgressMonitor downloadMonitor = monitor;
            if (refreshBeforeUpdate()) {
                monitor.beginTask(null, 1000);
                DMTeamPlugin.getWorkspace()
                        .getSubscriber()
                        .refresh(resources, IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, 500));
                downloadMonitor = Utils.subMonitorFor(monitor, 500);
            }
            update(provider, resources, downloadMonitor);
        } finally {
            monitor.done();
        }

    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantReference;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.ProjectMappingDialog;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceStreamOutgoingParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceSynchronizeParticipant;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Base class for all add to ws operations.
 *
 * @author V.Grishchenko
 */
public abstract class AddToWorkspaceOperation extends RemoteOperation {
    private ProjectMapping[] mappings;

    public AddToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects) {
        this(part, remoteObjects, null);
    }

    public AddToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects, ProjectMapping[] mappings) {
        super(part, remoteObjects);
        this.mappings = mappings;
    }

    protected ProjectMapping[] getMappings() {
        return mappings;
    }

    @Override
    public boolean prompt() throws InvocationTargetException, InterruptedException {
        if (mappings != null) {
            return mappings.length > 0;
        }

        final APIObjectAdapter[] remoteObjects = getRemoteObjects();
        if (remoteObjects == null || remoteObjects.length == 0) {
            return false;
        }

        VersionManagementProject[] projects = new VersionManagementProject[remoteObjects.length];
        System.arraycopy(remoteObjects, 0, projects, 0, remoteObjects.length);

        final CreateProjectMappingsOperation mappingsOperation = new CreateProjectMappingsOperation(getPart(), projects);
        mappingsOperation.run();
        mappings = mappingsOperation.getMappings();
        final boolean[] result = { true };
        if (mappingsOperation.hasInconsistentMappings()) {
            getShell().getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    ProjectMappingDialog dialog = new ProjectMappingDialog(getShell(), mappingsOperation.getInconsistentMappings());
                    result[0] = dialog.open() == Window.OK;
                }
            });
        }
        return result[0];
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
        if (mappings == null || mappings.length == 0) {
            return;
        }
        boolean debug = DMTeamPlugin.getDefault().isDebugging();
        long startMillis = 0l;
        if (debug) {
            startMillis = System.currentTimeMillis();
            System.out.println("+ Executing: " + getClass().getName());//$NON-NLS-1$
        }
        addToWorkspace(mappings, Utils.monitorFor(monitor));
        if (debug) {
            long stopMillis = System.currentTimeMillis();
            System.out.println("- Executing done: " + getClass().getName() + ", took "//$NON-NLS-1$
                    + (stopMillis - startMillis) + "ms");//$NON-NLS-1$
        }
    }

    protected void addToWorkspace(ProjectMapping[] _mappings, IProgressMonitor monitor) throws CoreException {
        monitor.beginTask(null, _mappings.length * 100);
        final String[] warning = new String[] { Messages.AddToWorkspaceOperationCommonWarning };
        boolean isOk = true;
        try {
            for (int i = 0; i < _mappings.length; i++) {
                ProjectMapping aMapping = _mappings[i];
                try {
                    IStatus result = addToWorkspace(aMapping, Utils.subMonitorFor(monitor, 100));
                    collectStatus(result);
                } catch (CoreException e) {
                    final String projectName = aMapping.getIdeProjectName();
                    Display.getDefault().asyncExec(new Runnable() {
                        @Override
                        public void run() {
                            MessageDialog.openWarning(getShell(), projectName + " - " + Messages.movingProjectError, Messages.couldNotMoveProject);
                        }
                    });
                    IStatus status = ((CoreException) e).getStatus();
                    DMTeamUiPlugin.log(status);
                } catch (Exception e) {
                    int index = -1;
                    isOk = false;

                    if (e.getMessage() != null && ((index = e.getMessage().indexOf("java.net.")) > -1)) {//$NON-NLS-1$
                        String className = e.getMessage().substring(index, e.getMessage().indexOf(':'));
                        Object objectInstance = null;
                        try {
                            Class<?> classDefinition = Class.forName(className);
                            objectInstance = classDefinition.newInstance();
                        } catch (ClassNotFoundException e1) {
                            DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamPlugin.ID, "", e1));
                        } catch (InstantiationException e1) {
                            DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamPlugin.ID, "", e1));
                        } catch (IllegalAccessException e1) {
                            DMTeamUiPlugin.log(new Status(IStatus.WARNING, DMTeamPlugin.ID, "", e1));
                        }

                        if (objectInstance instanceof java.net.UnknownHostException
                                || objectInstance instanceof java.net.SocketException) {
                            IStatus status = new Status(IStatus.ERROR, DMTeamUiPlugin.ID, "", e);
                            DMTeamUiPlugin.log(status);

                            DimensionsConnectionDetailsEx con = aMapping.getRemoteProject().getConnectionDetails();
                            con.destroySession(); // clean up the socket

                            StringBuffer conLabel = new StringBuffer(con.getConnName());
                            conLabel.append(' ')
                                    .append('[')
                                    .append(con.getUsername())
                                    .append('@')
                                    .append(con.getServer())
                                    .append(':')
                                    .append(con.getDbName())
                                    .append(':')
                                    .append(con.getDbConn())
                                    .append(']');
                            warning[0] = NLS.bind(Messages.addToWorkspaceOperation_connectionLost, conLabel.toString());

                            deleteProjectResources(aMapping, monitor);
                            return;
                        }
                    }

                    IStatus status = new Status(IStatus.ERROR, DMTeamUiPlugin.ID, "", e);
                    DMTeamUiPlugin.log(status);
                } finally {
                    Utils.checkCanceled(monitor);
                }
            }
        } finally {
            monitor.done();
            if (!isOk) {
                Display.getDefault().asyncExec(new Runnable() {
                    @Override
                    public void run() {
                        MessageDialog.openWarning(getShell(), Messages.AddToWorkspaceOperationCommonWarningTitle, warning[0]);
                    }
                });
            }
        }
    }

    protected IProject resolveProject(ProjectMapping mapping) {
        return ResourcesPlugin.getWorkspace().getRoot().getProject(mapping.getLocalProjectName());
    }

    private void deleteProjectResources(ProjectMapping mapping, IProgressMonitor monitor) throws CoreException {
        final IProject project = resolveProject(mapping);
        IWorkspace workspace = ResourcesPlugin.getWorkspace();
        IWorkspaceRunnable operation = new IWorkspaceRunnable() {
            @Override
            public void run(IProgressMonitor monitor) throws CoreException {
                try {
                    // the side effect of gc invoking hint is locked 'hanging' files release and prevention of 'sharing violation'
                    // problem
                    System.gc();
                    project.delete(true, true, Utils.subMonitorFor(monitor, 10)); // clean up the project
                    project.refreshLocal(IResource.DEPTH_INFINITE, null);
                } catch (Exception ex) {
                    DMTeamPlugin.log(new DMTeamStatus(IStatus.WARNING, DMTeamStatus.UNKNOWN, ex.getMessage(), ex));
                }
            }
        };
        workspace.run(operation, null);
    }

    /**
     * Remove sync participant if we override project by stream or
     * remove deliver participant if we override stream by project
     *
     * @param project
     * @param remoteProject
     * @throws CoreException
     */
    protected void removeSyncParticipants(IProject project, APIObjectAdapter remoteProject) throws CoreException {
        ISynchronizeParticipantReference[] synchronizeParticipants = TeamUI.getSynchronizeManager().getSynchronizeParticipants();

        boolean isProjectLocal = !(TeamUtils.isLocalWorksetAProject(project) == null);
        boolean isStreamLocal = !(TeamUtils.isLocalWorksetAStream(project) == null);

        if (!isProjectLocal && !isStreamLocal) {
            // baseline as same as project there
            isProjectLocal = true;
        }

        boolean isProjectRemote = false;

        DimensionsArObject apiObject = null;
        if (remoteProject.getAPIObject() instanceof Project || remoteProject.getAPIObject() instanceof Baseline) {
            apiObject = remoteProject.getAPIObject();
        } else {
            APIObjectAdapter adapter = remoteProject.getParentAdapter();
            apiObject = adapter.getAPIObject();
        }

        if (apiObject instanceof Baseline) {
            // baseline as same as project there
            isProjectRemote = true;
        } else {
            Object attribute = apiObject.getAttribute(SystemAttributes.WSET_IS_STREAM);
            if (attribute == null) {
                apiObject.queryAttribute(SystemAttributes.WSET_IS_STREAM);
                attribute = apiObject.getAttribute(SystemAttributes.WSET_IS_STREAM);
            }

            if (attribute != null) {
                isProjectRemote = !(Boolean) attribute;
            }
        }

        boolean shouldRemove = isProjectLocal != isProjectRemote;

        if (shouldRemove) {
            String idToRemove = null;
            if (isProjectRemote) {
                idToRemove = DMWorkspaceStreamOutgoingParticipant.ID;
            } else {
                idToRemove = DMWorkspaceSynchronizeParticipant.ID;
            }

            for (int i = 0; i < synchronizeParticipants.length; i++) {
                if (synchronizeParticipants[i].getId().equals(idToRemove)) {
                    ISynchronizeParticipant[] remove = new ISynchronizeParticipant[] { synchronizeParticipants[i].getParticipant() };
                    TeamUI.getSynchronizeManager().removeSynchronizeParticipants(remove);
                }
            }
        }

    }

    protected abstract IStatus addToWorkspace(ProjectMapping mapping, IProgressMonitor monitor) throws CoreException;

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;

/**
 * @author V.Grishchenko
 */
public class AddSingleProjectToWorkspaceOperation extends AddProjectToWorkspaceOperation {

    private IProject targetProject;
    private boolean preconfigured;

    public AddSingleProjectToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter remoteProject, String targetLocation) {
        super(part, new APIObjectAdapter[] { remoteProject }, targetLocation);
    }

    public AddSingleProjectToWorkspaceOperation(IWorkbenchPart part, ProjectMapping mapping, String targetLocation) {
        super(part, new APIObjectAdapter[] { mapping.getRemoteProject() }, new ProjectMapping[] { mapping }, targetLocation);
    }

    public void setTargetProject(IProject project) {
        this.targetProject = project;
    }

    /**
     * @return Returns the preconfigured.
     */
    public boolean isPreconfigured() {
        return preconfigured;
    }

    public void setPreconfigured(boolean b) {
        this.preconfigured = b;
    }

    @Override
    protected boolean needsPromptForOverwrite(ProjectMapping mapping, IProject project) {
        // No need to prompt if the project was preconfigured
        if (isPreconfigured()) {
            return false;
        }
        return super.needsPromptForOverwrite(mapping, project);
    }

    @Override
    protected IStatus addToWorkspace(ProjectMapping mapping, IProgressMonitor monitor) throws CoreException {
        return addToWorkspace(mapping, targetProject, monitor);
    }

}

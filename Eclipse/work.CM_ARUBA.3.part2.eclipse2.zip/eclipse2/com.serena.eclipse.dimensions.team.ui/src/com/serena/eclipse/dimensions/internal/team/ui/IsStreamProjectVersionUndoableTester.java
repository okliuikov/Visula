package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IWorkbenchPage;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;

public class IsStreamProjectVersionUndoableTester extends PropertyTester {
    public static final String IS_STREAM_PROJECT_VERSION_UNDOABLE = "isStreamProjectVersionUndoable"; //$NON-NLS-1$

    public IsStreamProjectVersionUndoableTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (!(receiver instanceof StructuredSelection)) {
            return false;
        }
        StructuredSelection ss = (StructuredSelection) receiver;
        Object selected = ss.getFirstElement();
        if (!(selected instanceof DimensionsChangeSet)) {
            return false;
        }
        DimensionsChangeSet cs = (DimensionsChangeSet) selected;
        if (property.equals(IS_STREAM_PROJECT_VERSION_UNDOABLE)) {
            IWorkbenchPage activePage = UIUtils.getActivePage();
            ChangeSetHistoryView view = (ChangeSetHistoryView) activePage.findView(ChangeSetHistoryView.ID);
            String changesetSourceType = view.getChangesetSourceTypeName();
            if ("Project".equals(changesetSourceType)) {
                return getIsProjectChangesetUndoable(cs.getOperationType());
            } else if ("Stream".equals(changesetSourceType)) {
                return getIsStreamChangesetUndoable(cs.getOperationType());
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean getIsProjectChangesetUndoable(int operationType) {
        switch (operationType) {
        case DimensionsChangeSet.OP_PROMOTION: // Promotion
        case DimensionsChangeSet.OP_DEMOTION: // Demotion
        case DimensionsChangeSet.OP_UPGRADE: // Upgrade
        case DimensionsChangeSet.OP_AGGREGATE: // Aggregate
        case DimensionsChangeSet.OP_BASELINE: // Baseline
        case DimensionsChangeSet.OP_BRANCH: // Branch
        case DimensionsChangeSet.OP_U141_UPCS: // U141_UPCS
        case DimensionsChangeSet.OP_U141_OPEN: // U141_OPEN
        case DimensionsChangeSet.OP_U141_BLN_TREE: // U141_BLN_TREE
        case DimensionsChangeSet.OP_U141_BLN_ARCS: // U141_BLN_ARCS
        case DimensionsChangeSet.OP_HIDDEN_UPGRADE: // U141_UPGRADE
        case DimensionsChangeSet.OP_HISTORY_ONLY: // History
        case DimensionsChangeSet.OP_HIDDEN_MIGRATION: // Migrated
        case DimensionsChangeSet.OP_SHELF: // Shelf
            return false;
        default:
            return true;
        }
    }

    private boolean getIsStreamChangesetUndoable(int operationType) {
        switch (operationType) {
        case DimensionsChangeSet.OP_UNKNOWN: // Oeration type is not known
        case DimensionsChangeSet.OP_DELIVER: // Deliver
        case DimensionsChangeSet.OP_MERGE: // Merge
        case DimensionsChangeSet.OP_PROMOTION: // Promotion
        case DimensionsChangeSet.OP_DEMOTION: // Demotion
        case DimensionsChangeSet.OP_BLD_COLLECTION: // Build output collection
        case DimensionsChangeSet.OP_UNDO: // Undo
            return true;
        default:
            return false;
        }
    }
}

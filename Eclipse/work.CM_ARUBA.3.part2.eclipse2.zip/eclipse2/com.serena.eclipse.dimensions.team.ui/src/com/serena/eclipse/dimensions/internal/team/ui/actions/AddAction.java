/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;

import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UploadOperation;

/**
 * Adds local resources to source control.
 * @author V.Grishchenko
 */
public class AddAction extends DMWorkspaceAction {
    // this filter makes sure the action is enabled on ignored files so that
    // they can be added to source-control - a certification requirement
    private static final IDMWorkspaceResourceFilter FILE_FILTER = new IDMWorkspaceResourceFilter.OrFilter(
            new IDMWorkspaceResourceFilter[] {
                    new StatusFilter(WorkspaceResourceStatus.MANAGED_NO_REMOTE_NOT_MOVED, StatusFilter.AND),
                    new StatusFilter(WorkspaceResourceStatus.UNMANAGED | WorkspaceResourceStatus.REMOTE_MISSING, StatusFilter.AND) });

    public AddAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources;
        try {
            resources = getResources();
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        if (resources.length == 0) {
            return;
        }

        boolean includesFiles = false;
        boolean includesFolders = false;
        for (int i = 0; i < resources.length; i++) {
            boolean aFile = resources[i].getType() == IResource.FILE;
            includesFiles |= aFile;
            includesFolders |= !aFile;
        }
        assert includesFiles || includesFolders;
        IDMWorkspaceResourceFilter filter = null;
        if (includesFiles && includesFolders) {
            filter = new IDMWorkspaceResourceFilter.OrFilter(new IDMWorkspaceResourceFilter[] { FILE_FILTER, getResourceFilter() });
        } else if (includesFiles) {
            filter = FILE_FILTER;
        } else {
            filter = getResourceFilter();
        }
        UploadOperation operation = new UploadOperation(getActivePart(), resources, filter);
        if (!operation.prompt()) {
            throw new InterruptedException();
        }
        operation.run();
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return IDMProject.ADD_FILTER;
    }

    @Override
    protected IDMWorkspaceResourceFilter getFileFilter() {
        return FILE_FILTER;
    }

}

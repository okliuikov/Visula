/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions.xml;

import java.lang.reflect.InvocationTargetException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandLocalScope;
import com.serena.eclipse.dimensions.internal.team.ui.actions.DMWorkspaceAction;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.WizardFactory;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Action that creates wizard from workspace resources that were selected by user
 */
public abstract class WorkspaceWizardAction extends DMWorkspaceAction {
    protected boolean showInformationDialog = false;

    protected abstract WizardFactory createWizardFactory(MergeCommandLocalScope mergeScope, List<MergeScopeGroup> possibleScopes,
            DimensionsConnectionDetailsEx connection);

    @Override
    protected boolean isEnabledForSelection() {
        final IStructuredSelection selection = getSelection();
        if (selection.isEmpty() || isSelectedSccProjectsMoved()) {
            return false;
        }

        try {
            IResource[] resources = getResources();

            Map<IDMProject, List<IResource>> scopes = getScopes(resources);
            if (scopes == null) {
                return false;
            }

            // Use default enablement implementation
            return super.isEnabledForSelection();
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
            return false;
        }

    }

    @Override
    protected IResource[] getResources() throws CoreException {
        IResource[] selected = getSelectedResources();
        if (selected == null || selected.length == 0) {
            return new IResource[0];
        }

        Set<IResource> resourcesSet = new HashSet<IResource>();
        for (int i = 0; i < selected.length; i++) {
            IResource resource = TeamUtils.getResource(selected[i]);
            resourcesSet.add(resource);
        }
        return resourcesSet.toArray(new IResource[resourcesSet.size()]);
    }

    protected String getInformationMessage() {
        return "";
    }

    protected Map<IDMProject, List<IResource>> getScopes(IResource[] resources) throws CoreException {
        return MergeCommandLocalScope.getScopes(resources, true);
    }

    protected MergeCommandLocalScope createMergeCommandLocalScope(IResource[] resources) throws CoreException {
        return MergeCommandLocalScope.createMergeCommandLocalScope(resources, true);
    }
    
    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources; // Eclipse resources
        try {
            resources = getResources();
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }

        try {
            ThreeWayWizard wizard = null;
            if (resources.length > 0) {
                // selected scope
                MergeCommandLocalScope mergeScope = createMergeCommandLocalScope(resources);
                if (mergeScope == null) {
                    return;
                }
                DimensionsConnectionDetailsEx connection = mergeScope.getConnection();

                // potential scopes from top-level workspace projects
                List<MergeScopeGroup> possibleMergeScopes = MergeScopeGroup.createValidScopeGroups(connection);
                WizardFactory factory = createWizardFactory(mergeScope, possibleMergeScopes, connection);
                wizard = new ThreeWayWizard(factory);
            }

            if (wizard == null) {
                if (showInformationDialog) {
                    String infoMessage = getInformationMessage();
                    UIUtils.showMessageDialog(shell, "Dimensions", infoMessage, false);
                }
                return;
            }

            final ThreeWayWizardDialog dialog = new ThreeWayWizardDialog(getShell(), wizard);
            BusyIndicator.showWhile(Display.getDefault(), new Runnable() {

                @Override
                public void run() {
                    if (dialog.open() == Window.CANCEL) {
                        return;
                    }
                }

            });
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }
    }

}

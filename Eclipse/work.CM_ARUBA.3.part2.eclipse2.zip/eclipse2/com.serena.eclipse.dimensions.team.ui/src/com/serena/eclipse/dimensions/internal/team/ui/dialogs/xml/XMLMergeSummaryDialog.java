/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.dialogs.xml;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.serena.dmfile.sync.SyncConstants.ObjectClass;
import com.serena.dmfile.sync.XSyncResolutions;
import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.dmfile.xml.Action;
import com.serena.dmfile.xml.DetectedResolutions;
import com.serena.dmfile.xml.ExecutedResolutions;
import com.serena.dmfile.xml.Resolution;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor.MergeDescriptorsContainer;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * Dialog that shows summary after silent merge execution
 */
public class XMLMergeSummaryDialog extends Dialog {
    private Text text;
    private String name;
    private MergeDescriptorsContainer container;
    private boolean isMerge = true;

    // changes
    private SummaryGroup additions;
    private SummaryGroup deletions;
    private SummaryGroup modify;
    private SummaryGroup move;
    private SummaryGroup movemodify;
    private SummaryGroup ignore;
    private SummaryGroup errors;

    // conflicts (r - remote, l - local, m - merged, c - content, p - path)
    private SummaryGroup mc;
    private SummaryGroup lc;
    private SummaryGroup rc;
    private SummaryGroup lp;
    private SummaryGroup rp;
    private SummaryGroup mcrp;
    private SummaryGroup mclp;
    private SummaryGroup rcrp;
    private SummaryGroup rclp;
    private SummaryGroup lcrp;
    private SummaryGroup lclp;

    // special
    private SummaryGroup upgrades;

    private static class SummaryGroup {
        private Set<String> group = new TreeSet<String>(c);
        private String name;

        public SummaryGroup(String name) {
            this.name = name;
        }

        public void add(String path) {
            group.add(path);
        }

        private static Comparator<String> c = new Comparator<String>() {

            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        };

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            if (group.size() > 0) {
                sb.append(name).append('\n');
                for (Iterator<String> iterator = group.iterator(); iterator.hasNext();) {
                    sb.append('\t').append(iterator.next()).append('\n');
                    if (!iterator.hasNext()) {
                        sb.append('\n');
                    }
                }
            }
            return sb.toString();
        };
    }

    /**
     * Create the dialog.
     *
     * @param parentShell
     */
    public XMLMergeSummaryDialog(Shell parentShell, MergeDescriptorsContainer container, String name, boolean isMerge) {
        super(parentShell);
        this.container = container;
        this.name = name;
        this.isMerge = isMerge;
        fillGroups();
    }

    private void fillGroups() {
        for (XMLMergeDescriptor descr : container.getMergeDescriptors()) {
            ExecutedResolutions executed = descr.getExecutedResolutions();
            if (executed != null) {
                Map<Integer, Action> actionMap = executed.getActionMap();
                for (Entry<Integer, Action> entry : actionMap.entrySet()) {
                    addToGroup(executed.getDetectedResolutions(), entry.getValue());
                }
            }
        }
    }

    private void addToGroup(DetectedResolutions resolutions, Action action) {
        if (!action.getStatus()) {
            if (errors == null) {
                this.errors = new SummaryGroup(Messages.DMXMLMergeSummary_errors);
            }
            errors.add(action.getRelPath());
            return;
        }

        XSyncResolutions type = action.getActionType();
        if (type == XSyncResolutions.SR_ERROR) {
            if (errors == null) {
                this.errors = new SummaryGroup(Messages.DMXMLMergeSummary_errors);
            }
            errors.add(action.getRelPath());
        } else if (type == XSyncResolutions.SR_IGNORE || type == XSyncResolutions.SR_UNKNOWN) {
            if (ignore == null) {
                this.ignore = new SummaryGroup(Messages.DMXMLMergeSummary_ignore);
            }
            ignore.add(action.getRelPath());
        } else if (type == XSyncResolutions.SR_REMOVE) {
            if (deletions == null) {
                this.deletions = new SummaryGroup(Messages.DMXMLMergeSummary_delete);
            }
            deletions.add(action.getRelPath());
        } else if (type == XSyncResolutions.SR_CREATE) {
            if (additions == null) {
                this.additions = new SummaryGroup(Messages.DMXMLMergeSummary_add);
            }
            additions.add(action.getRelPath());
        } else if (type == XSyncResolutions.SR_MODIFY) {
            if (modify == null) {
                this.modify = new SummaryGroup(Messages.DMXMLMergeSummary_modify);
            }
            modify.add(action.getRelPath());
        } else if (type == XSyncResolutions.SR_RENAME || type == XSyncResolutions.SR_MOVE) {
            if (move == null) {
                this.move = new SummaryGroup(Messages.DMXMLMergeSummary_move);
            }
            move.add(action.getRelPath());
        } else if (type == XSyncResolutions.SR_MOVE_MODIFY || type == XSyncResolutions.SR_RENAME_MODIFY) {
            if (movemodify == null) {
                this.movemodify = new SummaryGroup(Messages.DMXMLMergeSummary_movemodify);
            }
            movemodify.add(action.getRelPath());
        } else {
            Resolution res = resolutions.findById(action.getId());
            if (res == null) {
                return;
            }

            if (res.isMetadataUpgradeFlagOn() && action.getStatus()) {
                if (upgrades == null) {
                    this.upgrades = new SummaryGroup(Messages.DMXMLMergeSummary_upgrade);
                }
                upgrades.add(action.getRelPath());
            } else if (res.getDefaultAction() != null) {
                Integer def = res.getDefaultAction();
                XSyncUserAction source = XMLSyncInfo.getActionContentSource(def);
                XSyncUserAction direction = XMLSyncInfo.getActionDirection(def);

                if (action.getMovedFrom() == null) {
                    if (source == XSyncUserAction.SUAO_USE_LOCAL_FILE) {
                        if (lc == null) {
                            this.lc = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_lc);
                        }
                        lc.add(action.getRelPath());
                    } else if (source == XSyncUserAction.SUAO_USE_REPOSITORY_FILE) {
                        if (rc == null) {
                            this.rc = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_rc);
                        }
                        rc.add(action.getRelPath());
                    } else if (source == XSyncUserAction.SUAO_MERGE_2WAY || source == XSyncUserAction.SUAO_MERGE_3WAY) {
                        if (mc == null) {
                            this.mc = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_mc);
                        }
                        mc.add(action.getRelPath());
                    }
                } else {
                    // has move
                    if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH && action.getObjClass() == ObjectClass.PCMS_DIRECTORY) {
                        if (lp == null) {
                            this.lp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_lp);
                        }
                        lp.add(action.getRelPath());
                    } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH
                            && action.getObjClass() == ObjectClass.PCMS_DIRECTORY) {
                        if (rp == null) {
                            this.rp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_rp);
                        }
                        rp.add(action.getRelPath());
                    } else if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
                        if (source == XSyncUserAction.SUAO_USE_LOCAL_FILE) {
                            if (lclp == null) {
                                this.lclp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_lclp);
                            }
                            lclp.add(action.getRelPath());
                        } else if (source == XSyncUserAction.SUAO_USE_REPOSITORY_FILE) {
                            if (rclp == null) {
                                this.rclp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_rclp);
                            }
                            rclp.add(action.getRelPath());
                        } else if (source == XSyncUserAction.SUAO_MERGE_2WAY || source == XSyncUserAction.SUAO_MERGE_3WAY) {
                            if (mclp == null) {
                                this.mclp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_mclp);
                            }
                            mclp.add(action.getRelPath());
                        }
                    } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
                        if (source == XSyncUserAction.SUAO_USE_LOCAL_FILE) {
                            if (lcrp == null) {
                                this.lcrp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_lcrp);
                            }
                            lcrp.add(action.getRelPath());
                        } else if (source == XSyncUserAction.SUAO_USE_REPOSITORY_FILE) {
                            if (rcrp == null) {
                                this.rcrp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_rcrp);
                            }
                            rcrp.add(action.getRelPath());
                        } else if (source == XSyncUserAction.SUAO_MERGE_2WAY || source == XSyncUserAction.SUAO_MERGE_3WAY) {
                            if (mcrp == null) {
                                this.mcrp = new SummaryGroup(Messages.DMXMLMergeSummary_conflict_mcrp);
                            }
                            mcrp.add(action.getRelPath());
                        }
                    }
                }
            }
        }
    }

    /**
     * Create contents of the dialog.
     *
     * @param parent
     */
    @Override
    protected Control createDialogArea(Composite parent) {
        String title = "";
        if (isMerge) {
            title = Messages.DMXMLMergeOperation_summary_dialog;
        } else {
            title = Messages.DMXMLMergeOperation_update_summary_dialog;
        }

        getShell().setText(title);
        Composite container = (Composite) super.createDialogArea(parent);
        FillLayout lay = new FillLayout(SWT.VERTICAL);
        lay.marginWidth = 10;
        lay.marginHeight = 10;
        container.setLayout(lay);

        text = new Text(container, SWT.BORDER | SWT.WRAP | SWT.V_SCROLL | SWT.MULTI);
        Color normalBColor = text.getBackground();
        text.setEditable(false);
        text.setBackground(normalBColor);
        StringBuilder sb = new StringBuilder();
        if (name != null) {
            sb.append(name);
        }
        if (upgrades != null) {
            sb.append(upgrades.toString());
        }
        if (additions != null) {
            sb.append(additions.toString());
        }
        if (deletions != null) {
            sb.append(deletions.toString());
        }
        if (modify != null) {
            sb.append(modify.toString());
        }
        if (move != null) {
            sb.append(move.toString());
        }
        if (movemodify != null) {
            sb.append(movemodify.toString());
        }
        if (mc != null) {
            sb.append(mc.toString());
        }
        if (rc != null) {
            sb.append(rc.toString());
        }
        if (lc != null) {
            sb.append(lc.toString());
        }
        if (rp != null) {
            sb.append(rp.toString());
        }
        if (lp != null) {
            sb.append(lp.toString());
        }
        if (mcrp != null) {
            sb.append(mcrp.toString());
        }
        if (mclp != null) {
            sb.append(mclp.toString());
        }
        if (rcrp != null) {
            sb.append(rcrp.toString());
        }
        if (rclp != null) {
            sb.append(rclp.toString());
        }
        if (lcrp != null) {
            sb.append(lcrp.toString());
        }
        if (lclp != null) {
            sb.append(lclp.toString());
        }
        if (ignore != null) {
            sb.append(ignore.toString());
        }
        if (errors != null) {
            sb.append(errors.toString());
        }

        if (sb.length() - name.length() == 0) {
            sb.append(Messages.DMXMLMergeOperation_nochanges);
        }

        String last = sb.substring(sb.length() - 2, sb.length());
        if (last.equals("\n\n")) { //$NON-NLS-1$
            try {
                sb.delete(sb.length() - 2, sb.length());
            } catch (StringIndexOutOfBoundsException e) {
            }
        }

        sb.append("\n\t");//$NON-NLS-1$
        text.setText(sb.toString());
        return container;
    }

    /**
     * Create contents of the button bar.
     *
     * @param parent
     */
    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
        getButton(IDialogConstants.OK_ID).setFocus();
    }

    /**
     * Return the initial size of the dialog.
     */
    @Override
    protected Point getInitialSize() {
        Point size = super.getInitialSize();
        size.x = 640;
        size.y = 480;
        return size;
    }

    @Override
    protected boolean isResizable() {
        return true;
    }

}

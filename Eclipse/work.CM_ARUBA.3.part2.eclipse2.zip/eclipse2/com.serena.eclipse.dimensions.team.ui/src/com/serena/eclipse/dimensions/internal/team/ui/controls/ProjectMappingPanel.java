/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.controls;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.jface.viewers.IColorProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.model.IWorkbenchAdapter;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.OverlayIcon;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class ProjectMappingPanel {
    private static final int COL_REMOTE = 0; // remote workset or baseline
    private static final int COL_LOCAL = 1; // local name

    private static String[] COLUMN_PROPERTIES = { COL_REMOTE + "", //$NON-NLS-1$
            COL_LOCAL + "" //$NON-NLS-1$
    };

    private Composite panel;
    private ProjectMapping[] mappings;
    private Table table;
    private TableViewer tableViewer;
    private IMappingChangeListener listener;
    private Map images = new HashMap(); // cached images
    private ImageDescriptor imgEclipseProject;

    public static interface IMappingChangeListener {
        void mappingChanged(ProjectMapping mapping);
    }

    private class ContentProvider implements IStructuredContentProvider {
        @Override
        public Object[] getElements(Object inputElement) {
            if (inputElement != mappings) {
                return Utils.ZERO_LENGTH_OBJECT_ARRAY;
            }
            return mappings;
        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        }
    }

    private class MappingLabelProvider extends LabelProvider implements ITableLabelProvider, IColorProvider {

        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            if (element instanceof ProjectMapping) {
                ProjectMapping mapping = (ProjectMapping) element;
                switch (columnIndex) {
                case COL_REMOTE:
                    IWorkbenchAdapter workbenchAdapter = (IWorkbenchAdapter) mapping.getRemoteProject().getAdapter(
                            IWorkbenchAdapter.class);
                    if (workbenchAdapter != null) {
                        return getCachedImage(workbenchAdapter.getImageDescriptor(mapping.getRemoteProject()));
                    }
                    return null;
                case COL_LOCAL:
                    if (mapping.getProjectDescription() != null) {
                        return getCachedImage(getEclipseProjectDescriptor());
                    }
                    return PlatformUI.getWorkbench().getSharedImages().getImage(IDE.SharedImages.IMG_OBJ_PROJECT_CLOSED);
                }
            }
            return null;
        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            if (!(element instanceof ProjectMapping)) {
                return Utils.EMPTY_STRING;
            }
            ProjectMapping mapping = (ProjectMapping) element;
            switch (columnIndex) {
            case COL_REMOTE:
                IWorkbenchAdapter workbenchAdapter = (IWorkbenchAdapter) mapping.getRemoteProject().getAdapter(
                        IWorkbenchAdapter.class);
                if (workbenchAdapter != null) {
                    return workbenchAdapter.getLabel(mapping.getRemoteProject());
                }
                return Utils.EMPTY_STRING;
            case COL_LOCAL:
                String localName = mapping.getLocalProjectName();
                return localName == null ? Utils.EMPTY_STRING : localName;
            }
            return Utils.EMPTY_STRING;
        }

        @Override
        public Color getForeground(Object element) {
            return null;
        }

        @Override
        public Color getBackground(Object element) {
            return null;
        }
    }

    private class CellModifier implements ICellModifier {

        int getColumnNumber(String property) {
            Object[] columnProperties = tableViewer.getColumnProperties();
            for (int i = 0; i < columnProperties.length; i++) {
                if (columnProperties[i].equals(property)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public boolean canModify(Object element, String property) {
            if (!(element instanceof ProjectMapping)) {
                return false;
            }
            ProjectMapping mapping = (ProjectMapping) element;
            int column = getColumnNumber(property);
            switch (column) {
            case COL_LOCAL:
                return mapping.getProjectDescription() == null;
            default:
                return false;
            }
        }

        @Override
        public Object getValue(Object element, String property) {
            if (!(element instanceof ProjectMapping)) {
                return Utils.EMPTY_STRING;
            }
            ProjectMapping mapping = (ProjectMapping) element;
            int column = getColumnNumber(property);
            switch (column) {
            case COL_LOCAL:
                String localName = mapping.getLocalProjectName();
                return localName == null ? Utils.EMPTY_STRING : localName;
            default:
                return Utils.EMPTY_STRING;
            }
        }

        @Override
        public void modify(Object element, String property, Object value) {
            if (element instanceof Item) {
                element = ((Item) element).getData();
            }
            if (!(element instanceof ProjectMapping)) {
                return;
            }
            ProjectMapping mapping = (ProjectMapping) element;
            int column = getColumnNumber(property);
            if (column == -1) {
                return;
            }
            switch (column) {
            case COL_LOCAL:
                mapping.setLocalProjectName((String) value);
                break;
            default:
            }
            mappingChanged(mapping);
        }
    }

    public ProjectMappingPanel(Composite parent, int style, ProjectMapping[] mappings, String message) {
        this.mappings = mappings == null ? new ProjectMapping[0] : mappings;
        createControl(parent, style, message);
    }

    public void setEnabled(boolean value) {
        table.setEnabled(value);
    }

    /**
     * @return Returns the panel.
     */
    public Composite getPanel() {
        return panel;
    }

    public void setListener(IMappingChangeListener listener) {
        this.listener = listener;
    }

    private void disposeImages() {
        for (Iterator imageIter = images.values().iterator(); imageIter.hasNext();) {
            ((Image) imageIter.next()).dispose();
        }
    }

    private ImageDescriptor getEclipseProjectDescriptor() {
        if (imgEclipseProject == null) {
            Image projectImg = PlatformUI.getWorkbench().getSharedImages().getImage(IDE.SharedImages.IMG_OBJ_PROJECT_CLOSED);
            ImageData imageData = projectImg.getImageData();
            ImageDescriptor bottomRight = DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.OVR_ECLIPSE_PROJECT);
            ImageDescriptor[] overlays = new ImageDescriptor[4];
            overlays[OverlayIcon.BOTTOM_RIGHT] = bottomRight;
            imgEclipseProject = new OverlayIcon(projectImg, overlays, new Point(imageData.width, imageData.height));
        }
        return imgEclipseProject;
    }

    private Image getCachedImage(ImageDescriptor descriptor) {
        if (descriptor == null) {
            return null;
        }
        Image image = (Image) images.get(descriptor);
        if (image == null) {
            image = descriptor.createImage();
            images.put(descriptor, image);
        }
        return image;
    }

    private void mappingChanged(ProjectMapping mapping) {
        tableViewer.update(mapping, null);
        if (listener != null) {
            listener.mappingChanged(mapping);
        }
    }

    private void createControl(Composite parent, int style, String message) {
        panel = new Composite(parent, style);
        GridLayout gridLayout = UIUtils.setGridLayout(panel, 1);
        gridLayout.marginHeight = gridLayout.marginWidth = 0;
        if (message != null) {
            Label label = UIUtils.createLabel(panel, SWT.WRAP, message);
            GridData gridData = new GridData(450, SWT.DEFAULT);
            // gridData.horizontalSpan = 2;
            label.setLayoutData(gridData);
        }
        table = new Table(panel, SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI | SWT.FULL_SELECTION | SWT.BORDER);
        UIUtils.setGridData(table, GridData.FILL_BOTH);
        table.addListener(SWT.Dispose, new Listener() {
            @Override
            public void handleEvent(Event event) {
                if (event.type == SWT.Dispose) {
                    disposeImages();
                }
            }
        });

        table.setHeaderVisible(true);
        table.setLinesVisible(true);
        TableLayout layout = new TableLayout();
        createColumns(table, layout);
        table.setLayout(layout);
        tableViewer = createTableViewer(table);
    }

    private TableViewer createTableViewer(Table _table) {
        TableViewer result = new TableViewer(_table);
        result.setColumnProperties(COLUMN_PROPERTIES);
        result.setContentProvider(new ContentProvider());
        result.setLabelProvider(new MappingLabelProvider());
        result.setInput(mappings);

        CellEditor[] editors = new CellEditor[COLUMN_PROPERTIES.length];
        editors[0] = null;
        editors[1] = new TextCellEditor(table);
        result.setCellEditors(editors);
        result.setCellModifier(new CellModifier());
        return result;
    }

    private void createColumns(Table table, TableLayout layout) {
        // remote info
        TableColumn column = new TableColumn(table, SWT.NONE);
        column.setResizable(true);
        column.setText(Messages.ProjectMappingPanel_remoteCol);
        layout.addColumnData(new ColumnWeightData(20, true));

        // local project name
        column = new TableColumn(table, SWT.NONE);
        column.setResizable(true);
        column.setText(Messages.ProjectMappingPanel_localCol);
        layout.addColumnData(new ColumnWeightData(20, true));
    }

}

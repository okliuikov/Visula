package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.serena.eclipse.dimensions.internal.team.core.ContainmentComparator;
import com.serena.eclipse.dimensions.internal.team.core.CreateFolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.FolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.IMoveRequest;
import com.serena.eclipse.dimensions.internal.team.core.MetadataHelper;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;

/**
 * Creates requests for upload operation
 */
class UploadRequestsProcessor extends CommitRequestsProcessor { 

    public UploadRequestsProcessor(DMWorkspaceCommitHelper commitHelper, boolean override) {
        super(commitHelper, override);
    }

    @Override
    protected List<WorkspaceResourceRequest> getRequestsForCommit() throws CoreException {
        List<WorkspaceResourceRequest> resoursesToUpload = new ArrayList<WorkspaceResourceRequest>(); // all here
        // process moves first so that the changes can be checked in

        if (!getMoves().isEmpty()) {

            // If a folder is moved then do not include its contents in the move list
            if (!getFolderMoves().isEmpty()) {
                removeContentsOfParentFromMoveList(getFolderMoves(), getItemMoves(), getMoves());
            }

            // If resource is moved and modified we need to tell about only one. The other will be taken care by the
            // metadata information.
            if (!getChanges().isEmpty()) {
                removeMovedAndModifiedFilesFromChangeList(getChanges(), getMoves());
            }

            // play safe: sort by new name to create parent folders first, otherwise they will be created as result of child
            // rename, actual folder rename will be ignored and old folder remains
            TreeSet<IMoveRequest> sortedMoves = new TreeSet<IMoveRequest>(new ContainmentComparator() {

                @Override
                public int compare(Object o1, Object o2) {
                    return super.compare(((IMoveRequest) o1).getResource(), ((IMoveRequest) o2).getResource());
                }

            });
            sortedMoves.addAll(getMoves());
            for (IMoveRequest moveRequest : sortedMoves) {
                if (moveRequest instanceof WorkspaceResourceRequest) {
                    resoursesToUpload.add((WorkspaceResourceRequest) moveRequest);
                }
            }

        }

        if (!getFolderAdditions().isEmpty()) {
            if (!getMoves().isEmpty()) { // remove any folders were created by move
                for (Iterator<CreateFolderRequest> iter = getFolderAdditions().iterator(); iter.hasNext();) {
                    FolderRequest folderRequest = iter.next();
                    IResource container = folderRequest.getResource();
                    if (DMTeamPlugin.getWorkspace().hasRemote(container)) {
                        iter.remove();
                        if (container instanceof IContainer) {
                            MetadataHelper.writeMetadataForContainer((IContainer) container);
                        }
                    }
                }
            }
        }

        removeDeletedItemsFromDeleteList(getDeletions(), getFolderDeletions());

        resoursesToUpload.addAll(getFolderAdditions());
        resoursesToUpload.addAll(getDeletions());
        resoursesToUpload.addAll(getFolderDeletions());
        resoursesToUpload.addAll(getChanges());

        return resoursesToUpload;
    }
}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ResourceScope;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMSynchronizeParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMWorkspaceSynchronizeParticipant;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.ChangeSharingWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class SwitchProjectAction extends DMWorkspaceAction {

    public SwitchProjectAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IProject[] resources = getSelectedProjects();
        try {
            final IDMProject[] dmProjects = new IDMProject[resources.length];
            // only need to check for all SCC Style
            // other checks done in enablement

            for (int selres = 0; selres < resources.length; selres++) {
                IDMProject dmProj = DMTeamPlugin.getWorkspace().getProject(resources[selres]);
                if (dmProj == null) {
                    return;
                }
                if (!dmProj.isSccStyle() && resources.length > 1) {

                    Display.getDefault().syncExec(new Runnable() {

                        @Override
                        public void run() {
                            MessageDialog.openError(getShell(), Messages.Dialog_title, Messages.SwitchAction_IncompatibleTypes);
                        }
                    });
                    return;
                }
                dmProjects[selres] = dmProj;
                // foreign stream check from 12.1 included in multi-project code
                if (dmProj.getIsStream() && DMTeamUiPlugin.getDefault().isSyncWorkspaceOnSwitchingForeignProject()) {
                    String homeStreamName = TeamUtils.isLocalWorksetAStream(resources[selres]);
                    final IResource[] makeProjectResource = new IResource[1]; // only deal with
                                                                              // single
                    makeProjectResource[0] = resources[selres];
                    if (TeamUtils.isLocalWorksetPointingToForeignStream(dmProj.getProject())) {
                        String foreignStreamName = DMTeamPlugin.getWorkspace()
                                .getRemoteResource(makeProjectResource[0].getProject())
                                .getProject()
                                .getId();
                        MessageDialog.openWarning(getShell(), "Warning",
                                NLS.bind(Messages.SwitchProjectAction_wsPointingToForeignStream, homeStreamName, foreignStreamName));
                    } else {
                        final DMSynchronizeParticipant participant = new DMWorkspaceSynchronizeParticipant(new ResourceScope(
                                makeProjectResource));
                        TeamUI.getSynchronizeManager().addSynchronizeParticipants(new ISynchronizeParticipant[] { participant });
                        try {
                            PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                                @Override
                                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                                    participant.refreshNow(makeProjectResource, Messages.SynchronizeAction_0, monitor);
                                }
                            });
                        } catch (InvocationTargetException e) {
                            DMTeamUiPlugin.getDefault().handle(e);
                        } catch (InterruptedException ignore) {
                        }
                        SyncInfoSet syncSet = participant.getSyncInfoSet();
                        if (!syncSet.isEmpty()) {
                            MessageDialog.openWarning(getShell(), "Warning",
                                    NLS.bind(Messages.SwitchProjectAction_wsNotInSyncWithHome, homeStreamName));
                        }
                    }
                }
            }

            // here if all SCC and all in same Project
            ChangeSharingWizard wizard = new ChangeSharingWizard(dmProjects);
            WizardDialog dialog = new WizardDialog(getShell(), wizard);
            dialog.open();

        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

    @Override
    protected boolean isEnabledForSelection() {
        if (isSelectedSccProjectsMoved()) {
            return false;
        }
        // if anything other than projects selected return false
        IResource[] res = getSelectedResources();
        IProject[] projs = getSelectedProjects(); // can only operate on projects
        if (projs == null || projs.length == 0 || res.length != projs.length) {
            return false;
        }
        // use default enablement
        return super.isEnabledForSelection();
    }

}

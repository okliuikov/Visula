package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.List;
import org.eclipse.swt.widgets.Composite;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.ui.controls.DelegateStreamControl;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewObjectWizard;

public class NewStreamTopicUsersPage extends DimensionsWizardPage {
    private DelegateStreamControl shareControl = new DelegateStreamControl();
    
    public NewStreamTopicUsersPage(String pageName) {
        super(pageName);
        setTitle("Stream Access"); // $NON-NLS-1$
        setDescription(
                "By default only you can access the stream. Give access to other users or groups by adding them to the list below."); // $NON-NLS-1$
    }
    
    @Override
    public void createControl(Composite parent) {
        setControl(shareControl.createControl(parent));
    }
    
    @Override
    public void setVisible(boolean visible) {
        
        if (visible) {
            shareControl.setConnection(getConnection());
            shareControl.setHostPage(this);
            shareControl.tryInit();
        }
        super.setVisible(visible);
    }

    public List<String> getAssignedUsersAndGroups() {
        return shareControl.getAssignedUsersAndGroups();
    }
    
    private DimensionsConnectionDetailsEx getConnection() {
        if (getWizard() instanceof NewStreamWizard) {
            return ((NewObjectWizard) getWizard()).getConnection();
        } else if (getWizard() instanceof TeamOperationWizard) {
            return ((TeamOperationWizard) getWizard()).getConnection();
        }
        return null;
    }

}



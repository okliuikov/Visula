/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.util.List;

import org.eclipse.compare.structuremergeviewer.IDiffContainer;
import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.AndSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.DMParticipantAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Action that invokes merge operation in execute mode
 */
public class ExecuteMergeAction extends DMParticipantAction implements IPropertyChangeListener {
    private boolean updateAll = false;

    public ExecuteMergeAction(ISynchronizePageConfiguration configuration) {
        super(Messages.DMXMLMergeParticipant_menu_apply_selected_action, configuration);
    }

    /**
     * Action that performs merge
     * @param configuration
     * @param selectionProvider
     * @param updateAll true if we need to update all elements
     */
    public ExecuteMergeAction(ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider, boolean updateAll) {
        super(updateAll
                ? Messages.DMXMLMergeParticipant_toolbar_apply_action : Messages.DMXMLMergeParticipant_menu_apply_selected_action,
                configuration, selectionProvider);
        this.updateAll = updateAll;
        if (updateAll) {
            setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.CHECKOUT_ACTION));
            setDisabledImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.CHECKOUT_ACTION_D));
        }
    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        return new AndSyncInfoFilter(new FastSyncInfoFilter[] { XMLUserActionFilters.IgnoreFilter.INSTANCE,
                XMLUserActionFilters.StaleFilter.INSTANCE });
    }

    /**
     * Performs selection update if action was propagated through tree nodes
     */
    @Override
    public void propertyChange(PropertyChangeEvent event) {
        if (event.getProperty().equals(XMLMergeParticipant.PROPAGATE_CONTEXT_ACTION_EVENT)) {
            updateSelection(getStructuredSelection());
        }
    }

    /**
     * Sets a most parent node as a selection if need to update all. Otherwise directly selected
     * elements will be used
     */
    @Override
    public void selectionChanged(ISelection selection) {
        if (!updateAll) {
            super.selectionChanged(selection);
        } else {
            if (selection instanceof IStructuredSelection) {
                IStructuredSelection ssel = (IStructuredSelection) selection;
                List<?> list = ssel.toList();

                // find a most parent container for update all action
                for (Object object : list) {
                    if (object instanceof ISynchronizeModelElement) {
                        ISynchronizeModelElement any = (ISynchronizeModelElement) object;
                        IDiffContainer parent = any.getParent();
                        while (parent.getParent() != null) {
                            parent = parent.getParent();
                        }
                        super.selectionChanged(new StructuredSelection(parent));
                        return;
                    }
                }
            }
        }
    }

    /**
     * If any selected element is an unresolved conflict should return false
     */
    @Override
    protected boolean updateSelection(IStructuredSelection selection) {
        if (!super.updateSelection(selection)) {
            setEnabled(false);
            return false;
        }

        IDiffElement[] elements = getFilteredDiffElements();
        ISynchronizeParticipant participant = getConfiguration().getParticipant();
        if (!(participant instanceof XMLMergeParticipant)) {
            setEnabled(false);
            return false;
        }

        // check if any diff under selection is a unresolved conflict
        for (int i = 0; i < elements.length; i++) {
            if (elements[i] instanceof ISynchronizeModelElement && elements[i] instanceof IAdaptable) {
                SyncInfo syncInfo = (SyncInfo) ((IAdaptable) elements[i]).getAdapter(SyncInfo.class);
                if (!(syncInfo instanceof XMLSyncInfo)) {
                    setEnabled(false);
                    return false;
                }

                XMLSyncInfo xinfo = (XMLSyncInfo) syncInfo;
                if (xinfo.getCurrentActionLabel() == XSyncUserAction.SUAL_UNRESOLVED || !xinfo.hasAction(xinfo.getCurrentAction())) {
                    setEnabled(false);
                    return false;
                }
            }
        }

        setEnabled(true);
        return true;
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        return new ExecuteMergeOperation(configuration, elements, updateAll);
    }

}

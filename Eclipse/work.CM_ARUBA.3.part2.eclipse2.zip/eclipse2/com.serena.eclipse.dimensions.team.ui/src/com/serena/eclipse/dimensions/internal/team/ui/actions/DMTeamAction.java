/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.RootIdmProject;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamPreferences;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.IPromptCondition;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.PromptingDialog;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Provides common team specific helpers.
 *
 * @author V.Grishchenko
 */
public abstract class DMTeamAction extends DimensionsAction {
    private List<IStatus> accumulatedStatus = new ArrayList<IStatus>();

    /**
     * Method getNonOverlapping ensures that a resource is not covered more than once.
     *
     * @param resources
     * @return IResource[]
     */
    public static IResource[] getNonOverlapping(IResource[] resources) {
        return TeamUtils.getNonOverlapping(resources);
    }

    /**
     * Method getNonOverlapping ensures that a resource is not covered more than once.
     *
     * @param resources
     * @return IResource[]
     */
    public static IResource[] getNonOverlapping(SortedSet<IResource> resources) {
        return TeamUtils.getNonOverlapping(resources);
    }

    public DMTeamAction() {
    }

    /**
     * @param usesDeclarativeEnablement
     */
    public DMTeamAction(boolean usesDeclarativeEnablement) {
        super(usesDeclarativeEnablement);
    }

    /**
     * Returns the selected projects.
     *
     * @return the selected projects
     */
    protected IProject[] getSelectedProjects() {
        IResource[] selectedResources = getSelectedResources();
        if (selectedResources.length == 0) {
            return new IProject[0];
        }
        Set<IProject> projects = new HashSet<IProject>();
        for (int i = 0; i < selectedResources.length; i++) {
            IResource resource = selectedResources[i];
            if (resource.getType() == IResource.PROJECT) {
                projects.add((IProject) resource);
            }
        }
        return projects.toArray(new IProject[projects.size()]);
    }

    /**
     * Returns parent projects of the selected resources or the projects selected.
     *
     * @return projects of the selected resources
     */
    protected IProject[] getSelectedResourcesProjects() {
        IResource[] selectedResources = getSelectedResources();
        if (selectedResources.length == 0) {
            return new IProject[0];
        }
        Set<IProject> projects = new HashSet<IProject>();
        for (IResource resource : selectedResources) {
            // Cannot select root, so no null checking
            projects.add(resource.getProject());
        }
        return projects.toArray(new IProject[projects.size()]);
    }

    /**
     * Checks if any scc-style project/parent project in the selection was moved.
     *
     * @return true if any container-shared project in the selection was moved, false otherwise
     */
    protected boolean isSelectedSccProjectsMoved() {
        for (IProject project : getSelectedResourcesProjects()) {
            try {
                IDMWorkspaceResource dmResource = DMTeamPlugin.getWorkspace().getWorkspaceResource(project);
                IDMProject idmProject = dmResource.getProject();
                if (idmProject instanceof RootIdmProject && idmProject.isSccStyle() && dmResource.isMoved()) {
                    return true;
                }
            } catch (CoreException e) {
                // swallow intentionally
            }
        }
        return false;
    }

    /**
     * Returns an array of the given class type c that contains all
     * instances of c that are either contained in the selection or
     * are adapted from objects contained in the selection.
     *
     * @param c
     * @return
     */
    protected Object[] getSelectedResources(Class<?> c) {
        return getSelectedAdaptables(getSelection(), c);
    }

    /**
     * Returns the selected resources.
     *
     * @return the selected resources
     */
    protected IResource[] getSelectedResources() {
        Object[] elements = getSelection().toArray();
        List<IResource> resources = new ArrayList<IResource>();
        for (int i = 0; i < elements.length; i++) {
            Object element = elements[i];
            IResource resource = null;
            if (element instanceof IResource) {
                resource = (IResource) element;
            } else if (element instanceof ISynchronizeModelElement) {
                resource = ((ISynchronizeModelElement) element).getResource();
            } else {
                resource = (IResource) getAdapter(element, IResource.class);
                if (resource != null && resource.getType() == IResource.ROOT) {
                    continue;
                }
            }
            if (resource != null) {
                resources.add(resource);
            }
        }
        return resources.toArray(new IResource[resources.size()]);
    }

    protected APIObjectAdapter[] getSelectedRemoteResources() {
        return (APIObjectAdapter[]) getSelectedAdaptables(getSelection(), APIObjectAdapter.class);
    }

    /**
     * Creates an array of the given class type containing all the
     * objects in the selection that adapt to the given class.
     *
     * @param selection
     * @param c
     * @return
     */
    public static Object[] getSelectedAdaptables(ISelection selection, Class<?> c) {
        ArrayList<Object> result = null;
        if (selection != null && !selection.isEmpty()) {
            result = new ArrayList<Object>();
            Iterator<?> elements = ((IStructuredSelection) selection).iterator();
            while (elements.hasNext()) {
                Object adapter = getAdapter(elements.next(), c);
                if (c.isInstance(adapter)) {
                    result.add(adapter);
                }
            }
        }
        if (result != null && !result.isEmpty()) {
            return result.toArray((Object[]) Array.newInstance(c, result.size()));
        }
        return (Object[]) Array.newInstance(c, 0);
    }

    /**
     * Find the object associated with the given object when it is adapted to
     * the provided class. Null is returned if the given object does not adapt
     * to the given class
     *
     * @param selection
     * @param c
     * @return Object
     */
    public static Object getAdapter(Object adaptable, Class<?> c) {
        if (c.isInstance(adaptable)) {
            return adaptable;
        }
        if (adaptable instanceof IAdaptable) {
            IAdaptable a = (IAdaptable) adaptable;
            Object adapter = a.getAdapter(c);
            if (c.isInstance(adapter)) {
                return adapter;
            }
        }
        return null;
    }

    /**
     * Common run method for all actions.
     */
    @Override
    final public void run(IAction action) {
        try {
            if (!beginExecution(action)) {
                return;
            }
            execute(action);
            endExecution();
        } catch (InvocationTargetException e) {
            unwrapAndHandle(e);
        } catch (InterruptedException e) {
            // Show any problems that have occurred so far
            handle(null);
        } catch (DMException e) {
            handle(e);
        }
    }

    /**
     * Actions must override to do their work.
     */
    abstract protected void execute(IAction action) throws InvocationTargetException, InterruptedException;

    /**
     * This method gets invoked after <code>execute(IAction)</code> if no exception occured. Sunclasses may override but should
     * invoke this
     * inherited method to ensure proper handling oy any accumulated IStatus.
     */
    protected void endExecution() throws DMException {
        if (!accumulatedStatus.isEmpty()) {
            handle(null);
        }
    }

    /**
     * This method gets invoked before the <code>execute(IAction)</code> method. It can preform any prechecking and initialization
     * required before
     * the action is executed. Sunclasses may override but must invoke this
     * inherited method to ensure proper initialization of this superclass is performed.
     * These included preparation to accumulate IStatus and checking for dirty editors.
     */
    protected boolean beginExecution(IAction action) throws DMException {
        accumulatedStatus.clear();
        if (needsToSaveDirtyEditors()) {
            if (!saveAllEditors()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Answers if the action would like dirty editors to saved
     * based on the DM preference before running the action. By
     * default, DMTeamActions do not save dirty editors.
     */
    protected boolean needsToSaveDirtyEditors() {
        return false;
    }

    /**
     * Based on the DM preference for saving dirty editors this method will either
     * ignore dirty editors, save them automatically, or prompt the user to save them.
     *
     * @return <code>true</code> if the command succeeded, and <code>false</code> if at least one editor with unsaved changes was
     *         not saved
     */
    private boolean saveAllEditors() {
        final String option = DMTeamUiPlugin.getDefault().getPreferenceStore().getString(IDMTeamPreferences.SAVE_DIRTY_EDITORS);
        final boolean[] okToContinue = new boolean[] { true };
        if (!IDMTeamPreferences.SAVE_DIRTY_EDITORS_NEVER.equals(option)) {
            Display.getDefault().syncExec(new Runnable() {
                @Override
                public void run() {
                    boolean confirm = IDMTeamPreferences.SAVE_DIRTY_EDITORS_PROMPT.equals(option);
                    IResource[] selectedResources = getSelectedResources();
                    if (selectedResources != null && selectedResources.length > 0) {
                        okToContinue[0] = IDE.saveAllEditors(selectedResources, confirm);
                    }
                }
            });
        }
        return okToContinue[0];
    }

    protected void unwrapAndHandle(InvocationTargetException e) {
        Throwable target = e.getTargetException();
        if (target instanceof Error) {
            throw (Error) target;
        }
        if (target instanceof InvocationTargetException) {
            handle(target);
        }
        handle(target);
    }

    /**
     * Handles exception and/or accumulated statuses
     * @param t exception to handle or <code>null</code>
     */
    protected void handle(Throwable t) {
        if (t == null && accumulatedStatus.isEmpty()) {
            return;
        }

        List<IStatus> problems = new ArrayList<IStatus>();

        if (!accumulatedStatus.isEmpty()) {
            problems.addAll(accumulatedStatus);
        }

        if (t != null) {
            IStatus status;
            if (t instanceof CoreException) {
                status = ((CoreException) t).getStatus();
            } else {
                String message = t.getMessage();
                if (Utils.isNullEmpty(message)) {
                    message = getErrorMessage();
                }
                status = DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, message, t);
            }
            problems.add(status);
        }

        IStatus statusToDisplay = getStatusToDisplay(problems.toArray(new IStatus[problems.size()]));
        if (statusToDisplay.isOK()) {
            return;
        }
        String title;
        if (statusToDisplay.getSeverity() == IStatus.ERROR) {
            title = getErrorTitle();
        } else {
            title = getWarningTitle();
        }
        DMTeamUiPlugin.getDefault().handle(statusToDisplay, getShell(), title, getErrorMessage());
    }

    protected IStatus getStatusToDisplay(IStatus[] problems) {
        if (problems.length == 1) {
            return problems[0];
        }
        MultiStatus combinedStatus = new MultiStatus(DMTeamUiPlugin.ID, 0, getMultiStatusMessage(), null);
        for (int i = 0; i < problems.length; i++) {
            combinedStatus.merge(problems[i]);
        }
        return combinedStatus;
    }

    /**
     * Return the title to be displayed on error dialogs.
     * Sunclasses should override to present a custon message.
     */
    protected String getErrorTitle() {
        return Messages.DMTeamAction_0;
    }

    /**
     * Return the title to be displayed on error dialogs when warnings occur.
     * Sunclasses should override to present a custom message.
     */
    protected String getWarningTitle() {
        return Messages.DMTeamAction_1;
    }

    /**
     * Return the message to be used for the parent MultiStatus when
     * mulitple errors occur during an action.
     * Sunclasses should override to present a custom message.
     */
    protected String getMultiStatusMessage() {
        return Messages.DMTeamAction_2;
    }

    protected String getErrorMessage() {
        return Messages.DMTeamAction_3;
    }

    /**
     * Add a status to the list of accumulated status.
     * These will be provided to method handle(Exception, IStatus[])
     * when the action completes.
     */
    protected void addStatus(IStatus status) {
        accumulatedStatus.add(status);
    }

    protected IResource[] checkOverwriteOfDirtyResources(IResource[] resources) throws InterruptedException {
        List<IResource> dirtyResources = new ArrayList<IResource>();
        try {
            for (int i = 0; i < resources.length; i++) {
                IResource resource = resources[i];
                if (DMTeamPlugin.getWorkspace().isModified(resource)) {
                    dirtyResources.add(resource);
                }
            }
        } catch (CoreException e) {
            handle(e);
        }

        PromptingDialog dialog = new PromptingDialog(getShell(), resources,
                getOverwriteLocalChangesPrompt(dirtyResources.toArray(new IResource[dirtyResources.size()])),
                Messages.confirm_overwrite, false, 0);
        return dialog.promptForMultiple();
    }

    protected VersionManagementProject getRemoteProjectFor(final IResource resource) throws InterruptedException,
            InvocationTargetException {

        final VersionManagementProject[] holder = new VersionManagementProject[1];
        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                monitor = Utils.monitorFor(monitor);
                monitor.beginTask(null, IProgressMonitor.UNKNOWN);
                try {
                    IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(resource);
                    // getting an object may cause remote calls - run
                    // inside a busy cursor to avoid freezing the UI
                    holder[0] = dmProject.getDimensionsObjectAdapter();
                    // hack - when this action is run soon enough after the IDE
                    // is started the internal dmclient AttributeMapper
                    // is unitialized and will run a remote query when
                    // accessed for the 1st time, make sure this happens within
                    // a busy cursor
                    dmProject.getConnection().openSession(null).run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            holder[0].getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
                        }
                    }, monitor);
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                } finally {
                    monitor.done();
                }
            }
        });
        return holder[0];
    }

    /**
     * @return helper prompt condition for overwriting uncommitted local changes
     */
    public static IPromptCondition getOverwriteLocalChangesPrompt(final IResource[] dirtyResources) {
        return DMTeamUiPlugin.getOverwriteLocalChangesPrompt(dirtyResources);
    }

    protected String calculateProjectString() {
        IResource[] resources = getSelectedResources();
        ArrayList<DMRepositoryProvider> dmProjects = new ArrayList<DMRepositoryProvider>();
        for (int i = 0; i < resources.length; i++) {
            DMRepositoryProvider provider = DMRepositoryProvider.getDMProvider(resources[i]);
            if (provider != null && !dmProjects.contains(provider)) {
                dmProjects.add(provider);
            }
        }
        String text = null;
        try {
            if (dmProjects.size() == 1) {
                IDMProject project = dmProjects.get(0).getIdmProject();
                if (project.isWorkset()) {
                    text = NLS.bind(Messages.projectString_project, DMTypeScope.PROJECT.getDisplayText(project.getId()));
                }
                if (project.isBaseline()) {
                    text = NLS.bind(Messages.projectString_baseline, DMTypeScope.BASELINE.getDisplayText(project.getId()));
                }
            }
        } catch (CoreException e) {
            handle(e);
        }
        if (text == null) {
            text = Messages.projectString_multi;
        }
        return text;
    }

}

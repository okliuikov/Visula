package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.dmclient.api.BaselineDetails;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;

public class NewTemplateBaselineWizard extends NewBaselineWizard {

    Boolean cancelTrav = null;
    Boolean includeInfo = null;
    Boolean includeClosed = null;

    public NewTemplateBaselineWizard() {
        super();
    }

    public NewTemplateBaselineWizard(DimensionsConnectionDetailsEx connection, WorksetAdapter basedOn, FormToolkit toolkit) {
        super(connection, basedOn, toolkit);
    }

    public NewTemplateBaselineWizard(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn) {
        super(connection, basedOn);
    }

    public NewTemplateBaselineWizard(DimensionsConnectionDetailsEx connection) {
        super(connection);
    }

    @Override
    protected String[] getTitleDesc() {
        String[] titleDesc = new String[2];
        titleDesc[0] = Messages.NewBaselineWizard_template_title;
        titleDesc[1] = Messages.NewBaselineWizard_template_description;
        return titleDesc;
    }

    @Override
    protected int getBaselineCode() {
        return NewBaselineWizard.TEMPLATE_BASELINE;
    }

    @Override
    protected BaselineDetails createBaselineDetails(BaselineDetails baselineDetails, NewBaselineGeneralPage generalPage) {
        BaselineDetails det = super.createBaselineDetails(baselineDetails, generalPage);
        // Template Baseline specific
        NewBaselineTemplatePage tempPage = (NewBaselineTemplatePage) getPage(BASELINE_TEMPLATE_PAGE);
        det.setTemplateName(tempPage.getTemplate());
        det.setOwningPartSpecification(tempPage.getBaselineTopPart());
        det.setPartLevel(tempPage.getLevels());

        NewBaselineRelatePage relPage = (NewBaselineRelatePage) getPage(BASELINE_REQUEST_PAGE);
        det.setRelatedRequests(relPage.getRelatedRequests());
        // set from saved values in perform finish
        det.setCancelTraverse(cancelTrav);
        det.setIncludeClosed(includeClosed);
        det.setIncludeInfo(includeInfo);

        return det;
    }

    @Override
    protected void addInternalPages(int options) {
        // @formatter:off
         addPage(new NewBaselineTemplatePage(
                BASELINE_TEMPLATE_PAGE,
                Messages.newBaselineTemplatePage_title,
                Messages.newBaselineTemplatePage_desc,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                getConnection(),
                getBaselineCode(),
                options));
         addPage(new NewBaselineRelatePage(
                BASELINE_REQUEST_PAGE,
                Messages.newBaselineRelatePage_title,
                Messages.newBaselineRelatePage_desc,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                getConnection(),
                getBaselineCode()));
         // @formatter:on
    }

    @Override
    public boolean performFinish() {
        // get the values that rely on enablement here not
        NewBaselineRelatePage relPage = (NewBaselineRelatePage) getPage(BASELINE_REQUEST_PAGE);
        Boolean trav = relPage.getTraverseRequests();
        // need to invert
        if (trav != null) {
            cancelTrav = (trav == Boolean.TRUE) ? Boolean.FALSE : Boolean.TRUE;
        }
        includeClosed = relPage.getIncludeClosed();
        includeInfo = relPage.getIncludeInfo();

        return super.performFinish();
    }

}

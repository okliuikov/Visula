/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2009, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.eclipse.dimensions.internal.team.core.DMSyncInfo;

public class DeliverFilter extends SyncInfoDirectionFilter {

    public DeliverFilter(int[] directionFilters) {
        super(directionFilters);
    }

    @Override
    public boolean select(SyncInfo info) {
        DMSyncInfo dmInfo = (DMSyncInfo) info;
        return ((dmInfo.getKind() & SyncInfo.DIRECTION_MASK) == SyncInfo.INCOMING || (dmInfo.getKind() & SyncInfo.DIRECTION_MASK) == SyncInfo.CONFLICTING);
    }

}

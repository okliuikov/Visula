/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.IDMPreferences;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * filter foreign item file from other streams before sync.
 * @author YCai
 */
public class SyncSelectForeignStreamDialog extends Dialog {
    public static final String DISABLED = "#DISABLED#";
    private Map<IDMProject, Set<String>> excludedParticipants;
    private Map<IDMProject, Set<String>> foreignStreams;
    private List<Button> vbuttons = new ArrayList<Button>();
    private Button selectAllBtn;
    private Button deselectAllBtn;

    public SyncSelectForeignStreamDialog(Shell parentShell, Map<IDMProject, Set<String>> foreignStreams) {
        super(parentShell);
        setShellStyle(getShellStyle() | SWT.RESIZE);
        this.foreignStreams = foreignStreams;
    }

    @Override
    protected Control createDialogArea(Composite _parent) {
        getShell().setImage(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.DIMENSIONS).createImage());
        Composite composite = (Composite) super.createDialogArea(_parent);
        composite.setLayout(new GridLayout(1, true));
        GridLayout gridLayout = new GridLayout();
        gridLayout.numColumns = 1;
        composite.setLayout(gridLayout);

        Label label2 = new Label(composite, SWT.NONE);
        label2.setFont(JFaceResources.getFontRegistry().get(IDMPreferences.ATTRIBUTES_FONT));
        UIUtils.setGridData(label2, GridData.BEGINNING);

        Set<IDMProject> keys = foreignStreams.keySet();
        Iterator<IDMProject> itr = keys.iterator();

        HashSet<String> streams;
        IDMProject dmProj;
        String ideProjId;
        String streamId;

        Button button;
        Group group;
        GridData gridData;

        boolean isStreams = false;
        boolean isProjects = false;

        while (itr.hasNext()) {
            dmProj = itr.next();
            if (dmProj.getIsStream()) {
                isStreams = true;
            } else {
                isProjects = true;
            }
            group = new Group(composite, SWT.SHADOW_ETCHED_IN);

            IProject proj = dmProj.getProject();
            ideProjId = dmProj.getId() + " [" + proj.getName() + "]";
            group.setText(ideProjId);

            group.setLayout(new GridLayout(1, true));

            streams = (HashSet<String>) foreignStreams.get(dmProj);
            Iterator<String> itr2 = streams.iterator();
            while (itr2.hasNext()) {
                streamId = itr2.next();
                button = new Button(group, SWT.CHECK);
                button.setData(dmProj);
                boolean isDisabled = streamId.startsWith(DISABLED) ? true : false;
                if (!isDisabled) {
                    button.setSelection(true);
                } else {
                    streamId = streamId.substring(DISABLED.length());
                    button.setSelection(false);
                    button.setEnabled(false);
                }
                button.setText(streamId);
                vbuttons.add(button);
                button.setLayoutData(new GridData(GridData.FILL, GridData.CENTER, true, false, 1, 1));
            }
            gridData = new GridData();
            gridData.horizontalAlignment = GridData.FILL;
            group.setLayoutData(gridData);
        }

        if (isStreams && !isProjects) {
            getShell().setText(Messages.SyncSelectForeignDialogStream_title);
            label2.setText(Messages.SyncSelectForeignDialogStream_description);
        } else if (isProjects && !isStreams) {
            getShell().setText(Messages.SyncSelectForeignDialogProject_title);
            label2.setText(Messages.SyncSelectForeignDialogProject_description);
        } else if (isStreams && isProjects) {
            getShell().setText(Messages.SyncSelectForeignDialogStreamProject_title);
            label2.setText(Messages.SyncSelectForeignDialogStreamProject_description);
        }

        return composite;
    }

    @Override
    protected void okPressed() {
        excludedParticipants = new Hashtable<IDMProject, Set<String>>();
        IDMProject dmProj;
        HashSet<String> set;
        for (int i = 0; i < vbuttons.size(); i++) {
            Button cur = vbuttons.get(i);
            dmProj = (IDMProject) cur.getData();
            if (!excludedParticipants.containsKey(dmProj)) {
                excludedParticipants.put(dmProj, new HashSet<String>());
            }
            set = (HashSet<String>) excludedParticipants.get(dmProj);
            if (!cur.getSelection()) {
                set.add(cur.getText());
            }
        }
        removeEmpties(excludedParticipants);
        super.okPressed();
    }

    public static void removeEmpties(Map<IDMProject, Set<String>> map) {
        if (map != null && !map.isEmpty()) {
            Set<IDMProject> keys = map.keySet();
            Iterator<IDMProject> itr = keys.iterator();
            Object key;
            HashSet<String> values;
            while (itr.hasNext()) {
                key = itr.next();
                values = (HashSet<String>) map.get(key);
                if (values == null || values.isEmpty()) {
                    itr.remove();
                }
            }
        }
    }

    public Map<IDMProject, Set<String>> getExcludedParticipants() {
        return excludedParticipants;
    }

    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        selectAllBtn = createButton(parent, IDialogConstants.SELECT_ALL_ID, Messages.SyncSelectForeignStreamDialog_selectAll, true);
        deselectAllBtn = createButton(parent, IDialogConstants.DESELECT_ALL_ID, Messages.SyncSelectForeignStreamDialog_deselectAll,
                true);
        createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
        SelectionListener btnSelectionListener = new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (e.widget == selectAllBtn) {
                    for (int i = 0; i < vbuttons.size(); i++) {
                        vbuttons.get(i).setSelection(true);
                    }
                }
                if (e.widget == deselectAllBtn) {
                    for (int i = 0; i < vbuttons.size(); i++) {
                        vbuttons.get(i).setSelection(false);
                    }
                }
            }
        };

        selectAllBtn.addSelectionListener(btnSelectionListener);
        deselectAllBtn.addSelectionListener(btnSelectionListener);
    }
}
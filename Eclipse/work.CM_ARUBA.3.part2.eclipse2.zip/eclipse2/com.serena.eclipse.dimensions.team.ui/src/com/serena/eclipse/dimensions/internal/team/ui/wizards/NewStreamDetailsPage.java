/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008-2011, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;
import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.ChangeSetsQuery;
import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.StreamVersionSelectionDialog;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsNewWizard;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

public class NewStreamDetailsPage extends DimensionsWizardPage implements PropertyChangeListener {
    private static final String LATEST_STREAM_VER = Messages.NewStreamDetailsPage_latest_stream_ver;

    private boolean isStream;
    private String productName;

    private Button btnNothing;
    private Button btnBasedOnStream;
    private Button btnBasedOnBaseline;

    private Button btnRequest;

    private String basedOnSpec;
    private boolean basedOnType;

    private DimensionsConnectionDetailsEx connection;
    private Button checkSelectStreamVer;
    private Text txtStreamVer;
    private Button btnSelectStreamVer;

    private List<DimensionsChangeSet> changeSetList;
    private Project projectQueried;
    private long treeVersionSelected = -1; // invalid value by default
    private int CM_RULES_ALWAYS_ENABLED = 0x1000;

    private Button findWorksetButton;
    private Text basedOnStreamText;
    private Button findBaselineButton;
    private Text basedOnBaselineText;

    private Project selectedProject;
    private Baseline selectedBaseline;

    private SelectionAdapter commonSelectionListener = new SelectionAdapter() {
        @Override
        public void widgetSelected(SelectionEvent e) {
            if (((Button) e.getSource()).getSelection() == false) {
                return;
            }
            checkPage();
        }
    };;

    public NewStreamDetailsPage(String pageName, String title, String description, ImageDescriptor titleImage, boolean isStream) {
        super(pageName, title, titleImage);
        setDescription(description);
        this.isStream = isStream;
    }

    @Override
    public void createControl(Composite parent) {
        changeProductName();

        connection = ((DimensionsNewWizard) getWizard()).getConnection();
        NewStreamWizard wiz = (NewStreamWizard) getWizard();
        boolean isBasedOnStream = (null != wiz.getBasedOnStream());

        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        Composite baseOnContainer = composite;
        if (isStream) {
            baseOnContainer = new Group(composite, SWT.NONE);
            ((Group) baseOnContainer).setText(Messages.NewStreamWizard_stream_details_lblBasedOn);
            UIUtils.setGridLayout(baseOnContainer, 1);
            UIUtils.setGridData(baseOnContainer, GridData.FILL_HORIZONTAL);
        }

        btnNothing = new Button(baseOnContainer, SWT.RADIO);
        btnNothing.setText(isStream
                ? Messages.NewStreamWizard_stream_details_btnNothing : Messages.NewStreamWizard_project_details_btnNothing);
        UIUtils.setGridData(btnNothing, GridData.FILL_HORIZONTAL);
        btnNothing.addSelectionListener(commonSelectionListener);
        btnNothing.setSelection(null == wiz.getBasedOnStream() && null == wiz.getBasedOnBaseLine());

        UIUtils.createLabel(baseOnContainer, Utils.EMPTY_STRING);

        btnBasedOnStream = new Button(baseOnContainer, SWT.RADIO);
        btnBasedOnStream.setText(Messages.NewStreamWizard_project_details_lblBasedOnStreamOrProject);
        UIUtils.setGridData(btnBasedOnStream, GridData.FILL_HORIZONTAL);
        btnBasedOnStream.setSelection(isBasedOnStream);

        btnBasedOnStream.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (((Button) e.getSource()).getSelection() == false) {
                    return;
                }
                if (selectedProject != null) {
                    getChangeSetUidsData(selectedProject);
                }
                checkPage();
            }
        });

        Composite streamRowGrid = new Composite(baseOnContainer, SWT.NONE);
        UIUtils.setGridData(streamRowGrid, GridData.FILL_HORIZONTAL);
        UIUtils.setGridLayout(streamRowGrid, 2);

        basedOnStreamText = new Text(streamRowGrid, SWT.READ_ONLY | SWT.BORDER);
        UIUtils.setGridData(basedOnStreamText, GridData.FILL_HORIZONTAL);
        findWorksetButton = new Button(streamRowGrid, SWT.NONE);
        findWorksetButton.setText(Messages.ProjectSelectionPanel_launchFind);

        findWorksetButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {

                if (connection == null) {
                    return;
                }

                FindObjectWizardDialog dialog = null;

                dialog = new FindObjectWizardDialog(getShell(), IDMConstants.PROJECT, connection, productName, true, false,
                        connection.isOnlyStreamsActive(), connection.isOnlyProjectsActive());

                if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {
                    List<?> objects = dialog.getFindResult().getObjects();
                    selectedProject = (Project) objects.get(0);
                    basedOnStreamText.setText(selectedProject.getName());
                    getChangeSetUidsData(selectedProject);
                }

                checkPage();
            }
        });

        Composite streamVersionPanel = new Composite(baseOnContainer, SWT.NONE);
        UIUtils.setGridLayout(streamVersionPanel, 3);

        checkSelectStreamVer = new Button(streamVersionPanel, SWT.CHECK);
        checkSelectStreamVer.setText(isStream
                ? Messages.NewStreamDetailsPage_checkSpecStreamVerTitle : Messages.NewStreamDetailsPage_checkSpecProjectVerTitle);
        UIUtils.setGridData(checkSelectStreamVer, GridData.BEGINNING).widthHint = checkSelectStreamVer.computeSize(SWT.DEFAULT,
                SWT.DEFAULT, false).x + 20;
        checkSelectStreamVer.setSelection(false);
        checkSelectStreamVer.setEnabled(isBasedOnStream);
        checkSelectStreamVer.addSelectionListener(commonSelectionListener);

        txtStreamVer = new Text(streamVersionPanel, SWT.RIGHT | SWT.BORDER);
        txtStreamVer.setForeground(getShell().getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
        txtStreamVer.setText(LATEST_STREAM_VER);
        txtStreamVer.setLayoutData(new GridData(45, SWT.DEFAULT));

        txtStreamVer.addVerifyListener(new VerifyListener() {
            @Override
            public void verifyText(VerifyEvent e) {
                String string = e.text;

                if (txtStreamVer.getText().length() < 1 && string.equals(LATEST_STREAM_VER)) {
                    return;
                }

                char[] chars = new char[string.length()];
                string.getChars(0, chars.length, chars, 0);
                for (char ch : chars) {
                    if (!(ch >= '0' && ch <= '9')) {
                        e.doit = false;
                        return;
                    }
                }

                if (txtStreamVer.getText().equals(LATEST_STREAM_VER)) {
                    txtStreamVer.selectAll();
                }
            }
        });

        txtStreamVer.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                if (txtStreamVer.getText().equals(LATEST_STREAM_VER)) {
                    txtStreamVer.setForeground(getShell().getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
                } else {
                    txtStreamVer.setForeground(null);
                }
                checkPage();
            }
        });

        txtStreamVer.addFocusListener(new FocusListener() {
            @Override
            public void focusLost(FocusEvent e) {
                if (txtStreamVer.getText().length() < 1) {
                    txtStreamVer.setText(LATEST_STREAM_VER);
                }
            }

            @Override
            public void focusGained(FocusEvent e) {
                if (txtStreamVer.getText().equals(LATEST_STREAM_VER)) {
                    txtStreamVer.setText(Utils.EMPTY_STRING);
                }
            }
        });

        btnSelectStreamVer = new Button(streamVersionPanel, SWT.PUSH);
        btnSelectStreamVer.setText(Messages.NewStreamDetailsPage_btnSelectTitle);

        btnSelectStreamVer.addSelectionListener(new SelectionAdapter() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                if (selectedProject != null) {
                    WorksetAdapter wsAdapter = new WorksetAdapter(selectedProject, ((NewStreamWizard) getWizard()).getConnection());

                    StreamVersionSelectionDialog dialog = new StreamVersionSelectionDialog(getShell(), (isStream
                            ? Messages.NewStreamDetailsPage_dialogStreamVerTitle
                            : Messages.NewStreamDetailsPage_dialogProjectVerTitle), wsAdapter);
                    dialog.addPropertyChangeListener(NewStreamDetailsPage.this);

                    if (dialog.open() == Window.OK) {
                        txtStreamVer.setText(String.valueOf(treeVersionSelected));
                    }
                }
            }
        });

        setEnabledVersionPanel(isBasedOnStream);

        btnBasedOnBaseline = new Button(baseOnContainer, SWT.RADIO);
        btnBasedOnBaseline.setText(isStream
                ? Messages.NewStreamWizard_stream_details_btnBasedOnBaseline
                : Messages.NewStreamWizard_project_details_btnBasedOnBaseline);
        UIUtils.setGridData(btnBasedOnBaseline, GridData.FILL_HORIZONTAL);
        btnBasedOnBaseline.addSelectionListener(commonSelectionListener);
        btnBasedOnBaseline.setSelection(null != wiz.getBasedOnBaseLine());

        Composite baselineRowGrid = new Composite(baseOnContainer, SWT.NONE);
        UIUtils.setGridData(baselineRowGrid, GridData.FILL_HORIZONTAL);
        UIUtils.setGridLayout(baselineRowGrid, 2);

        basedOnBaselineText = new Text(baselineRowGrid, SWT.READ_ONLY | SWT.BORDER);
        UIUtils.setGridData(basedOnBaselineText, GridData.FILL_HORIZONTAL);

        findBaselineButton = new Button(baselineRowGrid, SWT.NONE);
        findBaselineButton.setText(Messages.ProjectSelectionPanel_launchFind);

        findBaselineButton.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (connection == null) {
                    return;
                }

                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), IDMConstants.BASELINE, connection,
                        productName, true, false, isStream, !isStream);

                if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {
                    List<?> objects = dialog.getFindResult().getObjects();
                    selectedBaseline = (Baseline) objects.get(0);
                    basedOnBaselineText.setText(selectedBaseline.getName());
                }

                checkPage();
            }
        });

        // KB> code to revisit
        String spec = (wiz.getBasedOnStream() != null) ? wiz.getBasedOnStream() : wiz.getBasedOnBaseLine();

        if (null != spec) {
            int idx = spec.indexOf(":"); //$NON-NLS-1$
            if (-1 != idx) {
                String prod = spec.substring(0, idx);
                spec.substring(idx + 1);

                if (prod.equals(productName) && isBasedOnStream && wiz.getBaseOnObject() != null) {
                    basedOnStreamText.setText(wiz.getBaseOnObject().getAPIObject().getName());
                    selectedProject = (Project) wiz.getBaseOnObject().getAPIObject();
                    getChangeSetUidsData(selectedProject);
                }

                if (prod.equals(productName) && null != wiz.getBasedOnBaseLine()) {
                    basedOnBaselineText.setText(wiz.getBaseOnObject().getAPIObject().getName());
                    selectedBaseline = (Baseline) wiz.getBaseOnObject().getAPIObject();
                }
            }
        }

        if (isStream) {
            Group grpRules = new Group(composite, SWT.NONE);
            grpRules.setText(Messages.NewStreamWizard_stream_details_lblRules);
            UIUtils.setGridLayout(grpRules, 5);
            UIUtils.setGridData(grpRules, GridData.FILL_HORIZONTAL);

            btnRequest = new Button(grpRules, SWT.CHECK);
            btnRequest.setText(Messages.NewStreamWizard_stream_details_chkValidReq);
            UIUtils.setGridData(btnRequest, GridData.FILL_HORIZONTAL, 5);
            GridData gridDataBtnRequest = new GridData(GridData.FILL_HORIZONTAL);
            gridDataBtnRequest.horizontalSpan = 5;
            btnRequest.setLayoutData(gridDataBtnRequest);
            loadDetailsFromType();
        }

        setControl(composite);
        checkPage();
    }

    public String getBasedOnStreamVersion() {
        if (basedOnStreamText == null || btnBasedOnStream == null || txtStreamVer == null) {
            return null;
        }
        final String[] result = new String[1];
        UIUtils.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                result[0] = basedOnStreamText.getText();
                if (!btnBasedOnStream.getSelection() || Utils.EMPTY_STRING.equals(result[0])) {
                    result[0] = null;
                } else if (btnBasedOnStream.getSelection() && checkSelectStreamVer.getSelection()
                        && isValidVersionRange(txtStreamVer.getText()) && !txtStreamVer.getText().equals(LATEST_STREAM_VER)) {
                    result[0] += ";" + txtStreamVer.getText(); //$NON-NLS-1$
                }
            }
        });
        return result[0];
    }

    public String getBasedOnBaseline() {
        if (basedOnBaselineText == null || btnBasedOnBaseline == null) {
            return null;
        }
        final String[] result = new String[1];
        UIUtils.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                result[0] = basedOnBaselineText.getText();
                if (!btnBasedOnBaseline.getSelection() || Utils.EMPTY_STRING.equals(result[0])) {
                    result[0] = null;
                }
            }
        });
        return result[0];
    }

    public Boolean getRequestRequired() {
        if (null == btnRequest) {
            return null;
        }

        final boolean[] res = new boolean[1];
        btnRequest.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                res[0] = btnRequest.getSelection();
            }
        });
        return Boolean.valueOf(res[0]);
    }

    private boolean isValidVersionRange(String value) {
        if (value.equals(LATEST_STREAM_VER)) {
            return true;
        } else if (value.length() > 1 && value.charAt(0) == '0') {
            return false;
        }

        if (changeSetList != null) {
            int maxVersion = changeSetList.size() - 1;
            try {
                int version = Integer.parseInt(value);
                return (version >= 0 && version <= maxVersion);
            } catch (NumberFormatException nfe) {
                return false;
            }
        }
        return false;
    }

    private void setEnabledVersionPanel(boolean enable) {
        checkSelectStreamVer.setEnabled(enable);

        boolean isSelected = checkSelectStreamVer.getSelection();
        if (enable && isSelected) {
            txtStreamVer.setEnabled(true);
            txtStreamVer.setBackground(null);
        } else {
            txtStreamVer.setEnabled(false);
            // Bugfix for the issue with incorrect background of disabled element with
            // custom foreground color (Windows classic interface)
            txtStreamVer.setBackground(checkSelectStreamVer.getBackground());
        }
        btnSelectStreamVer.setEnabled(enable && isSelected);
    }

    private void checkPage() {
        setPageComplete(true);
        setErrorMessage(null);

        boolean isBasedOnStream = btnBasedOnStream.getSelection();
        boolean isBasedOnBaseline = btnBasedOnBaseline.getSelection();
        setBasedOnObject();

        findWorksetButton.setEnabled(isBasedOnStream);
        setEnabledVersionPanel(isBasedOnStream && !basedOnStreamText.getText().equals(Utils.EMPTY_STRING));
        findBaselineButton.setEnabled(isBasedOnBaseline);

        if (isBasedOnStream) {
            if (basedOnStreamText.getText().equals(Utils.EMPTY_STRING)) {
                setErrorMessage(isStream
                        ? Messages.NewStreamWizard_stream_details_err1 : Messages.NewStreamWizard_stream_details_err2);
                setPageComplete(false);
            } else {
                if (!basedOnStreamText.getText().equals(basedOnSpec)) {
                    if (btnRequest != null) {
                        btnRequest.setSelection(getRequestRequiredData(basedOnStreamText.getText()));
                    }
                    basedOnSpec = basedOnStreamText.getText();
                }

                if (checkSelectStreamVer.getSelection() && txtStreamVer.getText().length() < 1) {
                    setErrorMessage(isStream
                            ? Messages.NewStreamDetailsPage_enterStreamVerMessage
                            : Messages.NewStreamDetailsPage_enterProjectVerMessage);
                    setPageComplete(false);
                } else if (checkSelectStreamVer.getSelection() && !isValidVersionRange(txtStreamVer.getText())) {
                    setErrorMessage(isStream
                            ? Messages.NewStreamDetailsPage_incorrectStreamVerMessage
                            : Messages.NewStreamDetailsPage_incorrectProjectVerMessage);
                    setPageComplete(false);
                }
            }

            basedOnType = false;
        } else if (isBasedOnBaseline) {
            if (basedOnBaselineText.getText().equals(Utils.EMPTY_STRING)) {
                setErrorMessage(Messages.NewStreamWizard_stream_details_err3);
                setPageComplete(false);
            } else if (!basedOnBaselineText.getText().equals(basedOnSpec)) {
                loadDetailsFromType();
                basedOnSpec = basedOnBaselineText.getText();
            }

            basedOnType = false;
        } else {
            if (!basedOnType) {
                loadDetailsFromType();
            }

            basedOnSpec = Utils.EMPTY_STRING;
            basedOnType = true;
        }
    }

    public void reInit(boolean fetch) {
        if (isStaleProduct(((NewStreamWizard) getWizard()).getProductName())) {
            for (Control control : btnNothing.getParent().getChildren()) {
                if (control instanceof Button && (((Button) control).getStyle() & SWT.RADIO) != 0) {
                    ((Button) control).setSelection(false);
                }
            }
            btnNothing.setSelection(true);
            setEnabledVersionPanel(false);
            txtStreamVer.setText(LATEST_STREAM_VER);
            if (fetch) {
                changeProductName();
            }
        }

        loadDetailsFromType();
    }

    public boolean isStaleProduct(String newProductName) {
        Assert.isNotNull(newProductName, "product name cannot be null"); //$NON-NLS-1$
        return !newProductName.equals(productName);
    }

    private void changeProductName() {
        final NewStreamWizard wiz = (NewStreamWizard) getWizard();
        this.productName = wiz.getProductName();
    }

    public boolean getRequestRequiredData(String projectSpec) {
        try {
            Project prj = connection.openSession(null).getObjectFactory().getProject(projectSpec);
            if (null != prj) {
                prj.queryAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
                String cmRules = (String) prj.getAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
                if (null != cmRules && cmRules.getBytes()[0] == ProjectDetails.PROJECT_CM_RULES_ON) {
                    return true;
                }
            }
        } catch (DMException e) {
            setErrorMessage(e.getMessage());
        }
        return false;
    }

    private void getChangeSetUidsData(final Project project) {
        if (projectQueried != null && projectQueried.equals(project)) {
            return;
        }

        try {
            PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                @Override
                public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    monitor.beginTask(null, IProgressMonitor.UNKNOWN);
                    try {
                        final Session session = connection.openSession(null);
                        ISessionRunnable work = new ISessionRunnable() {
                            @Override
                            public void run() throws Exception {
                                ChangeSetsQuery query = session.getObjectFactory().getChangeSetsQuery();
                                changeSetList = query.queryChangeSets(project, null, null, false);
                                projectQueried = project;
                            }
                        };
                        session.run(work, monitor);
                    } catch (DMException e) {
                        DMUIPlugin.log(e.getStatus());
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InterruptedException e) {
            DMUIPlugin.log(new Status(IStatus.ERROR, DMUIPlugin.ID, 0, Utils.EMPTY_STRING, e));
        } catch (InvocationTargetException e) {
            DMUIPlugin.getDefault().handle(e, null);
        }
    }

    public void loadDetailsFromType() {
        if (btnRequest == null) {
            return;
        }

        NewStreamWizard wiz = (NewStreamWizard) getWizard();
        int typeCmRulesAlwaysEnabled = CM_RULES_ALWAYS_ENABLED;
        int typeOption = wiz.getOptionsFromType();

        if ((typeOption & typeCmRulesAlwaysEnabled) == typeCmRulesAlwaysEnabled) {
            btnRequest.setSelection(true);
        } else {
            btnRequest.setSelection(false);
        }
    }

    public boolean isCMRulesEnable() {
        if (btnRequest != null) {
            return getRequestRequired();
        }

        NewStreamWizard wiz = (NewStreamWizard) getWizard();
        int typeCmRulesAlwaysEnabled = CM_RULES_ALWAYS_ENABLED;
        int typeOption = wiz.getOptionsFromType();

        if ((typeOption & typeCmRulesAlwaysEnabled) == typeCmRulesAlwaysEnabled) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void propertyChange(PropertyChangeEvent event) {
        if (event.getNewValue() instanceof TreeSelection) {
            TreeSelection value = (TreeSelection) event.getNewValue();
            if (value.getFirstElement() instanceof DimensionsChangeSet) {
                DimensionsChangeSet changeSetSelected = (DimensionsChangeSet) value.getFirstElement();
                treeVersionSelected = changeSetSelected.getRepositoryVersion().getTreeVersion();
            }
        }
    }
    
    private void setBasedOnObject() {
        NewStreamWizard wizard = (NewStreamWizard) getWizard();
        if (btnBasedOnStream.getSelection() == true && selectedProject != null) {
            wizard.setBasedOnObject(new WorksetAdapter(selectedProject, wizard.getConnection()));
        } else if (btnBasedOnBaseline.getSelection() == true && selectedBaseline != null) {
            ((NewStreamWizard) getWizard()).setBasedOnObject(new BaselineAdapter(selectedBaseline, wizard.getConnection()));
        } else {
            wizard.setBasedOnObject(null);
        }
    }
}
package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * Simply calls NewStreamWizard with parameters cause we cannot do it from plugin.xml
 * The wizard will be without "new stream" branch & welcome page
 *
 * @author A.Solod
 */
public class NewStreamWizardCaller extends NewStreamWizard {
    public NewStreamWizardCaller() {
        this.isStream = true;
        this.dontShowWelcomePage = true;
    }

    public NewStreamWizardCaller(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn) {
        super(connection, basedOn, true);
        this.dontShowWelcomePage = true;
    }
}

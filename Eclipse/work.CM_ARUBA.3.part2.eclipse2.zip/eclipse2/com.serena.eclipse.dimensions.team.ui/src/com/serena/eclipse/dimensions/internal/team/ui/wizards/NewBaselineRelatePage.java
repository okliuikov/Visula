/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2012, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.IDimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewObjectWizard;

/**
 * Wizard page for entering new baseline related requests information.
 *
 * @author V.Grishchenko
 *         Baseline only now
 *
 *         Modes Description
 *
 *         TIP_BASELINE
 *         TEMPLATE_BASELINE
 */

public class NewBaselineRelatePage extends DimensionsWizardPage implements IDimensionsWizardPage {
    private int mode;
    private boolean initialized;

    private DimensionsConnectionDetailsEx connection;

    private NewBaselineGeneralPage genPage = null;
    private NewBaselineTemplatePage templatePage = null;

    private Label relatedRequestsLabel;
    private Text relatedRequestsText;
    private Button relatedRequestsBtn;

    private Button traverseRequestBtn;
    private Button includeInfoBtn;
    private Button includeClosedBtn;

    private String lastTemplate;

    /**
     * @param mode one of TIP_BASELINE, TEMPLATE_BASELINE, REVISED_BASELINE
     */
    public NewBaselineRelatePage(String pageName, String title, String description, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx connection, int mode) {

        super(pageName, title, titleImage);
        setDescription(description);
        this.connection = connection;
        // initial settings - may get changed
        setMode(mode);
        if (NewBaselineWizard.isTemplateBaseline(mode)) {
            setPageComplete(false); // non-optional page if request based
        } else {
            // if not template then tip and not required
            setPageComplete(true);
        }
    }

    private NewBaselineGeneralPage getGeneralPage() {
        if (genPage == null) {
            genPage = (NewBaselineGeneralPage) getWizard().getPage(NewObjectWizard.GENERAL_PAGE);
        }
        return genPage;
    }

    private NewBaselineTemplatePage getTemplatePage() {
        if (templatePage == null) {
            templatePage = (NewBaselineTemplatePage) getWizard().getPage(NewBaselineWizard.BASELINE_TEMPLATE_PAGE);
        }
        return templatePage;
    }

    public void setMode(int mode) {
        Assert.isLegal((mode == NewBaselineWizard.TIP_BASELINE || mode == NewBaselineWizard.TEMPLATE_BASELINE)
                && mode != NewBaselineWizard.INVALID_MODE);
        if (this.mode == mode) {
            return;
        }
        this.mode = mode;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }
    }

    /**
     * @param connection The connection to set.
     */
    @Override
    public void setConnection(DimensionsConnectionDetailsEx connection) {
        if (this.connection == connection || (this.connection != null && this.connection.equals(connection))) {
            return;
        }
        this.connection = connection;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }
    }

    @Override
    public void setVisible(boolean visible) {

        if (visible) {
            refreshPage();
            if (!initialized) {
                initializeValues();
            }
        }
        super.setVisible(visible);
    }

    private void initializeValues() {
        initialized = true;
    }

    private void setRequestEnablement(boolean enabled) {
        if (getControl() != null) {
            if (enabled) {
                relatedRequestsText.setEnabled(true);
                relatedRequestsBtn.setEnabled(true);
            } else {
                relatedRequestsText.setText(""); // NON-NLS-1$
                relatedRequestsText.setEnabled(false);
                relatedRequestsBtn.setEnabled(false);
            }
        }
    }

    private void setButtonEnablement(boolean enable) {
        if (getControl() != null) {
            if (enable) {
                traverseRequestBtn.setEnabled(true);
                traverseRequestBtn.setVisible(true);
                traverseRequestBtn.setSelection(true);
                includeInfoBtn.setEnabled(true);
                includeInfoBtn.setVisible(true);
                includeClosedBtn.setEnabled(true);
                includeClosedBtn.setVisible(true);

            } else {
                traverseRequestBtn.setEnabled(false);
                traverseRequestBtn.setVisible(false);
                traverseRequestBtn.setSelection(false);
                includeInfoBtn.setEnabled(false);
                includeInfoBtn.setVisible(false);
                includeClosedBtn.setEnabled(false);
                includeClosedBtn.setVisible(false);
            }
        }
    }

    private void refreshPage() {
        String label = Messages.newBaselineRelatePage_relatedRequestsLabel;
        if (NewBaselineWizard.isTemplateBaseline(mode)) {
            // set based on item / request based template

            String template = getTemplatePage().getTemplate();

            if (lastTemplate == null || (lastTemplate != null && !lastTemplate.equals(template))) {
                if (Utils.isNullEmpty(template)) {
                    setButtonEnablement(false);
                    setRequestEnablement(false);
                } else if (getTemplatePage().isItemTemplate(template)) {
                    label = Messages.newBaselineRelatePage_relatedRequestsLabel;
                    setButtonEnablement(false);
                    setRequestEnablement(true);
                } else {
                    label = Messages.newBaselineRelatePage_relatedRequestsLabel1;
                    setButtonEnablement(true);
                    setRequestEnablement(true);
                }
                setRelatedRequestsLabelText(label);
                lastTemplate = template;
            }
        } else if (NewBaselineWizard.isTipBaseline(mode)) {
            label = Messages.newBaselineRelatePage_relatedRequestsLabel;
            setRelatedRequestsLabelText(label);
        }
        checkPage();
    }

    private void setRelatedRequestsLabelText(String label) {
        if (relatedRequestsLabel != null) {
            relatedRequestsLabel.setText(label);
        }
    }

    @Override
    public void createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 4);
        // add a related requests
        relatedRequestsLabel = UIUtils.createLabel(composite, null);
        setRelatedRequestsLabelText(Messages.newBaselineRelatePage_relatedRequestsLabel);
        relatedRequestsText = new Text(composite, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(relatedRequestsText, GridData.FILL_HORIZONTAL, 2);
        relatedRequestsText.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                checkPage();

            }
        });
        relatedRequestsBtn = new Button(composite, SWT.PUSH);
        relatedRequestsBtn.setText(Messages.newBaselinePage_browse);
        relatedRequestsBtn.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                // open the find Part Wizardxx
                String selectedProduct = getGeneralPage().getProductName();
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.CHANGEDOCUMENT,
                        connection, selectedProduct, false, false);
                if (dialog.open() == Window.OK) {
                    List<String> requests = dialog.getSelectedNames();
                    relatedRequestsText.setText(Utils.listToString(requests, false));
                    checkPage();
                }
            }
        });

        if (NewBaselineWizard.isTemplateBaseline(mode)) {
            Label spacer1 = UIUtils.createLabel(parent, null);
            UIUtils.setGridData(spacer1, GridData.FILL_HORIZONTAL, 4);

            traverseRequestBtn = new Button(composite, SWT.CHECK);
            traverseRequestBtn.setText(Messages.newBaselineRelatePage_traverseLabel);
            GridData data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 2, 1);
            traverseRequestBtn.setLayoutData(data);
            traverseRequestBtn.setSelection(true);
            includeClosedBtn = new Button(composite, SWT.CHECK);
            includeClosedBtn.setText(Messages.newBaselineRelatePage_includeClosedLabel);
            data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 3, 1);
            includeClosedBtn.setLayoutData(data);
            includeInfoBtn = new Button(composite, SWT.CHECK);
            includeInfoBtn.setText(Messages.newBaselineRelatePage_includeInfoLabel);
            data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 3, 1);
            includeInfoBtn.setLayoutData(data);
        }
        setControl(composite);
    }

    @Override
    public void dispose() {
        super.dispose();
    }

    public List getRelatedRequests() {
        return Utils.fromCsvToList(UIUtils.safeGetText(relatedRequestsText));
    }

    public Boolean getTraverseRequests() {
        return UIUtils.safeGetButton(traverseRequestBtn, true);
    }

    public Boolean getIncludeClosed() {
        return UIUtils.safeGetButton(includeClosedBtn, true);
    }

    public Boolean getIncludeInfo() {
        return UIUtils.safeGetButton(includeInfoBtn, true);
    }

    // have to have requests
    private boolean checkHaveRequests() {
        if (NewBaselineWizard.isTemplateBaseline(mode)) {
            String template = getTemplatePage().getTemplate();
            if (getTemplatePage().isRequestTemplate(template) && (getRelatedRequests().size() == 0)) {
                setErrorMessage(Messages.newBaselineRelatePage_norequests);
                return false;
            }
        }
        return true;
    }

    private void checkPage() {
        setPageComplete(false);
        if (checkHaveRequests()) {
            setPageComplete(true);
            setErrorMessage(null);
        }

    }
}

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IEditorPart;

import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotateRevision;

public class BlameRevisionPropertyTester extends PropertyTester {

    private final static String VISIBILITY_PROPERTY = "checkRevisionVisibility";//$NON-NLS-1$
    private final static String ENABLEMENT_PROPERTY = "checkRevisionEnablement";//$NON-NLS-1$

    public BlameRevisionPropertyTester() {
    }

    @Override
    public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
        if (receiver instanceof IEditorPart) {
            IEditorPart part = (IEditorPart) receiver;
            StructuredSelection ssel = UIUtils.getStructuredSelectionFromRuler(part);
            Object selObj = null;
            if (ssel != null && ssel.size() > 0 && ((selObj = ssel.getFirstElement()) instanceof BlameAnnotateRevision)) {
                if (property.equals(VISIBILITY_PROPERTY)) {
                    return true;
                } else if (property.equals(ENABLEMENT_PROPERTY)) {
                    BlameAnnotateRevision revision = (BlameAnnotateRevision) selObj;
                    IDMRemoteFile base = revision.getBase();
                    if (!revision.getId().equals(base.getRevision())) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.DimensionsIDEProject;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccProjectContainer;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.views.DimensionsIDEProjectHistoryView;
import com.serena.eclipse.dimensions.internal.ui.views.DimensionsWorksetHistoryView;
import com.serena.eclipse.dimensions.internal.ui.views.SccProjectContainerHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Shows history for a workspace project shared with Dimensions.
 * Opens:
 * <ul>
 * <li>IDE project history for SEP,
 * <li>Container history for SCC projects
 * <li>CM project history for stand alone projects
 * </ul>
 *
 * @author V.Grishchenko
 */
public class ProjectHistoryAction extends DMWorkspaceAction {

    public ProjectHistoryAction() {
    }

    @Override
    protected boolean isEnabledForMultipleResources() {
        return false;
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        final IProject[] selectedProjects = getSelectedProjects();
        if (selectedProjects.length == 0) {
            return;
        }
        final WorksetAdapter[] projectHolder = new WorksetAdapter[1];
        PlatformUI.getWorkbench().getProgressService().run(true, true, new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    projectHolder[0] = getProjectObject(selectedProjects[0], monitor);
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                }
            }
        });
        if (projectHolder[0] != null) {
            openHistoryView(projectHolder[0], selectedProjects[0]);
        } else {
            MessageDialog.openInformation(getShell(), Messages.Dialog_title, Messages.ProjectHistoryAction_1);
        }
    }

    @SuppressWarnings("unchecked")
    private WorksetAdapter getProjectObject(IProject iproject, IProgressMonitor monitor) throws CoreException {
        // TODO VG on Feb 22, 2007: this can be simplified when dmproject returns proper adapter object
        IDMProject dmPrj = DMTeamPlugin.getWorkspace().getProject(iproject);
        if (dmPrj == null) {
            return null;
        }
        monitor.beginTask(Messages.ProjectHistoryAction_0, IProgressMonitor.UNKNOWN);
        try {
            final DimensionsLcObject project = dmPrj.getDimensionsObject();
            final Session session = dmPrj.getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    int attrs[];
                    if (project instanceof Project) {
                        // @formatter:off
                        attrs = new int[] {
                                SystemAttributes.IDE_DM_UID,
                                SystemAttributes.IDE_INITIAL,
                                SystemAttributes.IDE_PROJECT_NAME,
                                SystemAttributes.IDE_TAG };
                        // @formatter:on
                    } else {
                        // @formatter:off
                        attrs = new int[] {
                                SystemAttributes.IDE_DM_UID,
                                SystemAttributes.IDE_PROJECT_NAME,
                                SystemAttributes.IDE_TAG };
                        // @formatter:on
                    }
                    project.queryAttribute(attrs);
                }
            }, monitor);

            String ideTag = (String) project.getAttribute(SystemAttributes.IDE_TAG);
            String idePname = (String) project.getAttribute(SystemAttributes.IDE_PROJECT_NAME);
            Long ideUid = (Long) project.getAttribute(SystemAttributes.IDE_DM_UID);
            String initial = (String) project.getAttribute(SystemAttributes.IDE_INITIAL);

            final Project[] initialProjectHolder = new Project[1];
            if (ideUid != null && ideUid.longValue() > 0) {
                if (project instanceof Project && "Y".equalsIgnoreCase(initial)) { //$NON-NLS-1$
                    initialProjectHolder[0] = (Project) project;
                } else {
                    final Filter wsf = new Filter();
                    wsf.criteria().add(new Filter.Criterion(SystemAttributes.IDE_DM_UID, ideUid, Filter.Criterion.EQUALS));
                    wsf.criteria().add(new Filter.Criterion(SystemAttributes.IDE_INITIAL, "Y", Filter.Criterion.EQUALS)); //$NON-NLS-1$
                    session.run(new ISessionRunnable() {

                        @Override
                        public void run() throws Exception {
                            List<Project> worksets = session.getObjectFactory().getProjects(wsf);
                            if (!worksets.isEmpty()) {
                                initialProjectHolder[0] = worksets.get(0);
                            }
                        }

                    }, monitor);
                }
            }

            if (ideTag != null && ideTag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1) {
                if (initialProjectHolder[0] != null) {
                    return new SccProjectContainer(initialProjectHolder[0], dmPrj.getConnection(), ideTag, ideUid.toString());
                }
            } else if (IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG.equals(ideTag)) {
                if (initialProjectHolder[0] != null) {
                    return new DimensionsIDEProject(initialProjectHolder[0], dmPrj.getConnection(), ideTag, idePname,
                            String.valueOf(ideUid));
                }
            }

            if (project instanceof Project) {
                return new WorksetAdapter((Project) project, dmPrj.getConnection());
            }
        } finally {
            monitor.done();
        }
        return null;
    }

    private void openHistoryView(WorksetAdapter project, IProject local) {
        if (project == null) {
            return;
        }
        try {
            if (project instanceof SccProjectContainer) {
                SccProjectContainerHistoryView histView = (SccProjectContainerHistoryView) getActivePart().getSite()
                        .getPage()
                        .showView(SccProjectContainerHistoryView.VIEW_ID);
                if (histView != null) {
                    histView.setLocal(local);
                    histView.ShowHistory(project, true);
                }
            } else if (project instanceof DimensionsIDEProject) {
                DimensionsIDEProjectHistoryView histView = (DimensionsIDEProjectHistoryView) getActivePart().getSite()
                        .getPage()
                        .showView(DimensionsIDEProjectHistoryView.VIEW_ID);
                if (histView != null) {
                    histView.setLocal(local);
                    histView.ShowHistory((DimensionsIDEProject) project, true);
                }
            } else {
                DimensionsWorksetHistoryView histView = (DimensionsWorksetHistoryView) getActivePart().getSite()
                        .getPage()
                        .showView(DimensionsWorksetHistoryView.VIEW_ID);
                if (histView != null) {
                    histView.ShowHistory(project, true);
                }
            }
        } catch (PartInitException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }
    }

}

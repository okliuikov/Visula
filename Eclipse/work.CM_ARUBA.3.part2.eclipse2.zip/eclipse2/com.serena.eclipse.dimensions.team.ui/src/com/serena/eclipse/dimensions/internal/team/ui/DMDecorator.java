/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.jface.viewers.IDecoration;
import org.eclipse.jface.viewers.ILightweightLabelDecorator;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.LabelProviderChangedEvent;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFolder;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IResourceStateChangeListener;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class DMDecorator extends LabelProvider
        implements ILightweightLabelDecorator, IResourceStateChangeListener, IPropertyChangeListener, IDMTeamPreferences {

    public static final String ID = "com.serena.eclipse.dimensions.team.ui.decorator"; //$NON-NLS-1$

    private static final String DIRTY_INDICATOR = ">"; //$NON-NLS-1$

    private static ImageDescriptor checkedIn; // managed and not checked out/local
    private static ImageDescriptor extracted; // extracted to workspace
    private static ImageDescriptor extractedOther; // extracted in repo but not locally
    private static ImageDescriptor extractedMultipleOther; // multi extract but not locally
    private static ImageDescriptor extractedMultipleLocal; // multi extract including locally
    private static ImageDescriptor locked; // locked exclusively
    private static ImageDescriptor local;
    private static ImageDescriptor dirty;
    private static ImageDescriptor remoteDeleted;
    private static ImageDescriptor localDeleted;
    private static ImageDescriptor ownLocked;
    private static ImageDescriptor foreignLocked;
    private static ImageDescriptor lockedInContainer;

    // @formatter:off
    private static Collection<String> decoratorPreferences =
                                new ArrayList<String>(Arrays.asList(new String[] {
                                        DECORATE_DEEP_STATUS_FOLDERS,
                                        DECORATE_FORCE_DEEP_STATUS_PROJECT,
                                        DECORATE_REMOTE_INFO_PROJECT,
                                        DECORATE_BASE_REVISION,
                                        DECORATE_REMOTE_REVISION,
                                        DECORATE_LOCALLY_MODIFIED,
                                        DECORATE_LOCALLY_MODIFIED_TEXT,
                                        DECORATE_LOCAL_MODE,
                                        DECORATE_SYNC_STATUS,
                                }));
    // @formatter:on

    static {
        DMTeamUiPlugin teamuiplugin = DMTeamUiPlugin.getDefault();
        checkedIn = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_MANAGED));
        extracted = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_EXTRACTED));
        extractedOther = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_EXTRACTED_OTHER));
        extractedMultipleLocal = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_EXTRACTED_MULTIPLE));
        extractedMultipleOther = new CachedImageDescriptor(
                teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_EXTRACTED_MULTIPLE_OTHER));
        locked = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_LOCKED));
        local = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_LOCAL));
        dirty = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_DIRTY));
        remoteDeleted = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_DELETED_REMOTE));
        localDeleted = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_DELETED_LOCAL));
        ownLocked = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_LOCKED_OWN));
        foreignLocked = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_LOCKED_FOREIGN));
        lockedInContainer = new CachedImageDescriptor(teamuiplugin.getImageDescriptor(IDMTeamImages.OVR_LOCKED_IN_CONTAINER));
    }

    // cache image data once
    static class CachedImageDescriptor extends ImageDescriptor {
        ImageDescriptor descriptor;
        ImageData data;

        public CachedImageDescriptor(ImageDescriptor descriptor) {
            assert descriptor != null;
            this.descriptor = descriptor;
        }

        @Override
        public ImageData getImageData() {
            if (data == null) {
                data = descriptor.getImageData();
            }
            return data;
        }
    }

    static boolean showDeepFolderStatus() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_DEEP_STATUS_FOLDERS);
    }

    static boolean forceDeepProjectStatus() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_FORCE_DEEP_STATUS_PROJECT);
    }

    static boolean showProjectRemoteInfo() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_REMOTE_INFO_PROJECT);
    }

    static boolean showFileBaseRevision() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_BASE_REVISION);
    }

    static boolean showFileRemoteRevision() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_REMOTE_REVISION);
    }

    // icon dirty decoration
    static boolean showLocallyModifiedStatus() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_LOCALLY_MODIFIED);
    }

    // text dirty decoration
    static boolean showLocallyModifiedStatusText() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_LOCALLY_MODIFIED_TEXT);
    }

    static boolean showLocalMode() {
        return DMTeamUiPlugin.getDefault().getPluginPreferences().getBoolean(DECORATE_LOCAL_MODE);
    }

    static boolean isDecoratorPreference(String prop) {
        return decoratorPreferences.contains(prop);

    }

    // all-inclusive update for DM decorations
    public static void refresh() {
        PlatformUI.getWorkbench().getDecoratorManager().update(ID);
    }

    public DMDecorator() {
        hookListeners();
    }

    private void hookListeners() {
        DMTeamUiPlugin.getDefault().getPreferenceStore().addPropertyChangeListener(this);
        DMTeamPlugin.getWorkspace().addResourceStateChangeListener(this);
    }

    private void unhookListeners() {
        DMTeamPlugin.getWorkspace().removeResourceStateChangeListener(this);
        DMTeamUiPlugin.getDefault().getPreferenceStore().removePropertyChangeListener(this);
    }

    @Override
    public void dispose() {
        unhookListeners();
        super.dispose();
    }

    /*
     * Update the decorators for every resource in project
     */
    public void refresh(IProject project) {
        final List<IResource> resources = new ArrayList<IResource>();
        try {
            project.accept(new IResourceVisitor() {
                @Override
                public boolean visit(IResource resource) {
                    resources.add(resource);
                    return true;
                }
            });
            postLabelEvent(new LabelProviderChangedEvent(this, resources.toArray()));
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);// log(e.getStatus());
        }
    }

    /*
     * Post the label event to the UI thread
     */
    private void postLabelEvent(final LabelProviderChangedEvent event) {
        Display.getDefault().asyncExec(new Runnable() {
            @Override
            public void run() {
                fireLabelProviderChanged(event);
            }
        });
    }

    @Override
    public void decorate(Object element, IDecoration decoration) {
        IResource resource = getResource(element);
        if (resource == null || resource.getType() == IResource.ROOT) {
            return;
        }

        IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
        try {
            IDMWorkspaceResource dmResource = workspace.getWorkspaceResource(resource);

            if (dmResource == null || dmResource.isIgnored()) {
                return;
            }
            dmResource.setCacheVariants(true); // reuse variants

            String prefix = getPrefix(resource, dmResource);
            if (prefix != null) {
                decoration.addPrefix(prefix);
            }

            String suffix = getSuffix(resource, dmResource);
            if (suffix != null) {
                decoration.addSuffix(' ' + suffix);
            }

            ImageDescriptor stateOverlay = getStateOverlay(resource, dmResource);
            if (stateOverlay != null) {
                decoration.addOverlay(stateOverlay); // bottom right
            }

            ImageDescriptor syncOverlay = getSyncOverlay(resource, dmResource);
            if (syncOverlay != null) {
                decoration.addOverlay(syncOverlay, IDecoration.TOP_RIGHT);
            }

        } catch (CoreException e) {
            // silently log and continue
            DMTeamUiPlugin.log(e.getStatus());
        }
    }
    
    @Override
    public void workAreaRehomeDetected(List<IDMProject> projectsToRehome, WorksetAdapter targetProject) {
    }

    // calculates resource state overlay icon reflecting resource checkout, local mode state
    private ImageDescriptor getStateOverlay(IResource resource, IDMWorkspaceResource dmResource) throws TeamException {
        if (!resource.exists()) {
            return localDeleted;
        }
        switch (resource.getType()) {
        case IResource.PROJECT:
            return getProjectStateOverlay((IDMWorkspaceFolder) dmResource);
        case IResource.FOLDER:
            return getFolderStateOverlay((IDMWorkspaceFolder) dmResource);
        case IResource.FILE:
            return getFileStateOverlay((IDMWorkspaceFile) dmResource);
        default:
            return null;
        }
    }

    // calculates resource sync state overlay for displaying outgoing, incoming, conflict state
    private ImageDescriptor getSyncOverlay(IResource resource, IDMWorkspaceResource dmResource) throws TeamException {
        switch (resource.getType()) {
        case IResource.PROJECT:
            return getProjectSyncOverlay((IDMWorkspaceFolder) dmResource);
        case IResource.FOLDER:
            return getFolderSyncOverlay((IDMWorkspaceFolder) dmResource);
        case IResource.FILE:
            return getFileSyncOverlay((IDMWorkspaceFile) dmResource);
        default:
            return null;
        }
    }

    private ImageDescriptor getFileSyncOverlay(IDMWorkspaceFile dmFile) throws TeamException {
        if (!dmFile.isManaged()) {
            return null;
        }
        if (dmFile.isModified() && showLocallyModifiedStatus()) {
            return dirty;
        }
        return null;
    }

    private ImageDescriptor getFileStateOverlay(IDMWorkspaceFile dmFile) throws TeamException {
        if (!dmFile.isManaged()) {
            return null;
        }

        if (!dmFile.hasRemote()) {
            return remoteDeleted;
        }

        if (dmFile.isExtracted()) {
            if (dmFile.isMultiExtracted()) {
                return extractedMultipleLocal;
            }
            return extracted;
        }

        if (dmFile.getProject().getIsStream()) {
            if (dmFile.isLockedOther()) {
                return foreignLocked;
            } else if (dmFile.isLocked()) {
                return ownLocked;
            }
        }

        if (dmFile.isOptimistic() && showLocalMode()) {
            return local;
        }

        if (dmFile.isExtractedExclusive()) {
            return locked;
        }

        if (dmFile.isAnyExtracted()) {
            if (dmFile.isMultiExtracted()) {
                return extractedMultipleOther;
            }
            return extractedOther; // treat all remote checkouts as other
        }

        return checkedIn;
    }

    private ImageDescriptor getFolderStateOverlay(IDMWorkspaceFolder dmFolder) throws TeamException {
        return getFolderStateOverlay(dmFolder, showDeepFolderStatus());
    }

    private ImageDescriptor getFolderSyncOverlay(IDMWorkspaceFolder dmFolder) throws TeamException {
        return getFolderSyncOverlay(dmFolder, showDeepFolderStatus());
    }

    private ImageDescriptor getFolderSyncOverlay(IDMWorkspaceFolder dmFolder, boolean deep) throws TeamException {
        if (!dmFolder.containsManaged(deep) && !dmFolder.isManaged()) {
            return null;
        }

        if (showLocallyModifiedStatus() && isFolderModified(dmFolder, deep)) {
            return dirty;
        }

        return null;
    }

    private boolean isFolderModified(IDMWorkspaceFolder dmFolder, boolean deep) throws TeamException {
        if (deep) {
            return dmFolder.isModified();
        }
        return dmFolder.containsModified(false) || dmFolder.hasAddedOrDeletedMembers();
    }

    private ImageDescriptor getFolderStateOverlay(IDMWorkspaceFolder dmFolder, boolean deep) throws TeamException {
        if (!dmFolder.containsManaged(deep) && !dmFolder.isManaged()) {
            return null;
        }

        if (dmFolder.isManaged() && !dmFolder.hasRemote()) {
            return remoteDeleted;
        }

        if (dmFolder.containsExtracted(deep)) {
            return extracted;
        }

        if (dmFolder.getProject().getIsStream()) {
            if (dmFolder.containsLocked(deep)) {
                return lockedInContainer;
            }

            if (dmFolder.containsModified(deep) && showLocalMode()) {
                return local;
            }
        } else {
            if (dmFolder.containsOptimistic(deep) && showLocalMode()) {
                return local;
            }
        }

        return checkedIn;
    }

    private ImageDescriptor getProjectStateOverlay(IDMWorkspaceFolder dmFolder) throws TeamException {
        ImageDescriptor folderOverlay = getFolderStateOverlay(dmFolder, showDeepFolderStatus() || forceDeepProjectStatus());
        if (folderOverlay != null) {
            return folderOverlay;
        }
        return checkedIn;
    }

    private ImageDescriptor getProjectSyncOverlay(IDMWorkspaceFolder dmFolder) throws TeamException {
        return getFolderSyncOverlay(dmFolder, showDeepFolderStatus() || forceDeepProjectStatus());
    }

    private String getPrefix(IResource resource, IDMWorkspaceResource dmResource) throws TeamException {
        switch (resource.getType()) {
        case IResource.PROJECT:
            return getProjectPrefix((IDMWorkspaceFolder) dmResource);
        case IResource.FOLDER:
            return getFolderPrefix((IDMWorkspaceFolder) dmResource);
        case IResource.FILE:
            return getFilePrefix((IDMWorkspaceFile) dmResource);
        default:
            return null;
        }
    }

    private String getProjectPrefix(IDMWorkspaceFolder dmFolder) throws TeamException {
        return getFolderPrefix(dmFolder, showDeepFolderStatus() || forceDeepProjectStatus());
    }

    private String getFolderPrefix(IDMWorkspaceFolder dmFolder) throws TeamException {
        return getFolderPrefix(dmFolder, showDeepFolderStatus());
    }

    private String getFolderPrefix(IDMWorkspaceFolder dmFolder, boolean deep) throws TeamException {
        return showLocallyModifiedStatusText() && isFolderModified(dmFolder, deep) ? DIRTY_INDICATOR : null;
    }

    private String getFilePrefix(IDMWorkspaceFile dmResource) throws TeamException {
        return dmResource.isModified() && showLocallyModifiedStatusText() ? DIRTY_INDICATOR : null;
    }

    private String getSuffix(IResource resource, IDMWorkspaceResource dmResource) throws CoreException {
        String suffix = null;

        IResource virtualResource = dmResource.geVirtualResource();
        if (virtualResource != null && virtualResource.getType() == IResource.PROJECT) {
            return getVirtualSuffix((IDMWorkspaceFolder) dmResource);
        }

        switch (dmResource.getLocalResource().getType()) {
        case IResource.PROJECT:
            suffix = getProjectSuffix((IDMWorkspaceFolder) dmResource);
            break;
        case IResource.FILE:
            suffix = getFileSuffix((IDMWorkspaceFile) dmResource);
            break;
        }
        try {
            String moveSuffix = getMovedSuffix(dmResource);
            String moveInRepositorySuffix = getMovedInRepositorySuffix(dmResource);
            if (moveSuffix != null && moveInRepositorySuffix == null) {
                if (suffix != null) {
                    suffix += moveSuffix;
                } else {
                    suffix = moveSuffix;
                }
            }
        } catch (CoreException e) {
            throw TeamException.asTeamException(e);
        }

        return suffix;
    }

    private String getVirtualSuffix(IDMWorkspaceFolder dmResource) {
        return NLS.bind(Messages.decorator_parent, dmResource.getProject().getProject().getName());
    }

    public static String getMovedSuffix(IDMWorkspaceResource dmResource) throws CoreException {
        IResource movedFrom = dmResource.getMovedFrom();
        if (movedFrom != null) {
            return getMovedSuffix(dmResource.getLocalResource(), movedFrom, true);
        }
        IResource movedTo = dmResource.getMovedTo();
        if (movedTo != null) {
            return getMovedSuffix(dmResource.getLocalResource(), movedTo, false);
        }
        return null;
    }

    public static String getMovedInRepositorySuffix(IDMWorkspaceResource dmResource) throws CoreException {
        IResource movedFrom = dmResource.getMovedInRepositoryFrom();
        if (movedFrom != null) {
            return getMovedInRepositorySuffix(dmResource.getLocalResource(), movedFrom, true);
        }
        IResource movedTo = dmResource.getMovedInRepositoryTo();
        if (movedTo != null) {
            return getMovedInRepositorySuffix(dmResource.getLocalResource(), movedTo, false);
        }
        return null;
    }

    private static String getMovedSuffix(IResource resource, IResource mvResource, boolean from) {
        StringBuffer buf = new StringBuffer(" "); //$NON-NLS-1$
        buf.append(from ? Messages.decorator_movedFrom : Messages.decorator_movedTo).append(' ');
        if (mvResource instanceof IProject) { // project local renaming
            buf.append(NLS.bind(Messages.decorator_movedPath, mvResource.getFullPath().toString()));
        } else if (resource.getProject().equals(mvResource.getProject())) {
            buf.append(NLS.bind(Messages.decorator_movedPath, mvResource.getProjectRelativePath().toString()));
        } else {
            buf.append(NLS.bind(Messages.decorator_movedCrossProjectPath, mvResource.getProject().getName(),
                    mvResource.getProjectRelativePath().toString()));
        }
        return buf.toString();
    }

    private static String getMovedInRepositorySuffix(IResource resource, IResource mvResource, boolean from) {
        StringBuffer buf = new StringBuffer(" "); //$NON-NLS-1$
        buf.append(from ? Messages.decorator_movedInRepositoryFrom : Messages.decorator_movedInRepositoryTo).append(' ');
        buf.append(NLS.bind(Messages.decorator_movedInRepositoryPath, mvResource.getProjectRelativePath().toString()));
        return buf.toString();
    }

    private String getProjectSuffix(IDMWorkspaceFolder folder) {
        if (showProjectRemoteInfo()) {
            String key = folder.getProject().getIsStream()
                    ? Messages.decorator_prjStreamInfo
                    : (folder.getProject().isBaseline() ? Messages.decorator_prjBaselineInfo : Messages.decorator_prjWorksetInfo);
            // is it a SCC style
            IDMProject theProject = folder.getProject();

            StringBuffer prjText = new StringBuffer(folder.getProject().getId());
            if (theProject.isSccStyle()) {
                prjText.append("/").append(theProject.getRemoteOffset().toString()); //$NON-NLS-1$
            }
            String suffix = NLS.bind(key, prjText.toString(), folder.getProject().getConnection().getConnName());

            return suffix;
        }
        return null;
    }

    private String getFileSuffix(IDMWorkspaceFile file) throws TeamException {
        if (!showFileBaseRevision() && !showFileRemoteRevision()) {
            return null;
        }

        IDMRemoteFile base = file.getBaseFile();
        IDMRemoteFile remote = file.getRemoteFile();

        if (base != null && remote != null) {
            String baseRev = base.getRevision();
            String remRev = remote.getRevision();
            if (baseRev.equals(remRev)) {
                if (showFileBaseRevision()) {
                    return NLS.bind(Messages.decorator_fileBase, baseRev);
                }
                return NLS.bind(Messages.decorator_fileRemote, remote.getRevision());
            }
            if (showFileBaseRevision() && showFileRemoteRevision()) {
                return NLS.bind(Messages.decorator_fileBaseRemote, base.getRevision(), remote.getRevision());
            }
            if (showFileBaseRevision()) {
                return NLS.bind(Messages.decorator_fileBase, baseRev);
            }
            return NLS.bind(Messages.decorator_fileRemote, remote.getRevision());
        }

        if (base != null && showFileBaseRevision()) {
            return NLS.bind(Messages.decorator_fileBase, base.getRevision());
        }

        if (remote != null && showFileRemoteRevision()) {
            return NLS.bind(Messages.decorator_fileRemote, remote.getRevision());
        }

        return null;
    }

    @Override
    public void projectConfigured(IProject project) {
        refresh(project);
    }

    @Override
    public void projectDeconfigured(IProject project) {
        refresh(project);
    }

    @Override
    public void resourceStateChanged(IResource[] resources) {
        resourceModified(resources);
    }

    @Override
    public void resourceModified(IResource[] resources) {
        if (resources != null && resources.length > 0) {
            postLabelEvent(new LabelProviderChangedEvent(this, resources));
        }
    }

    private IResource getResource(Object object) {
        if (object instanceof IResource) {
            return (IResource) object;
        }

        if (object instanceof IAdaptable) {
            return (IResource) ((IAdaptable) object).getAdapter(IResource.class);
        }

        return null;
    }

    @Override
    public void propertyChange(PropertyChangeEvent event) {
        String prop = event.getProperty();
        if (prop.equals(TeamUI.GLOBAL_IGNORES_CHANGED)) {
            refresh();
        } else if (isDecoratorPreference(prop)) {
            refresh();
        }
    }

}

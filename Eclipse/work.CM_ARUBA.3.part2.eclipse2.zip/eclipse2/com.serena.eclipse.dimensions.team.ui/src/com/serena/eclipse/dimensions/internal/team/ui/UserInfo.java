package com.serena.eclipse.dimensions.internal.team.ui;

public class UserInfo {
    public boolean isGroup = false;
    public String id;
    public String displayText;
}
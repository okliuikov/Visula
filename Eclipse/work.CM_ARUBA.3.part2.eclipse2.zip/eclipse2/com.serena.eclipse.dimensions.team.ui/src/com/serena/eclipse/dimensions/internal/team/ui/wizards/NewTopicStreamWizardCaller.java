package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * Simply calls NewStreamWizard with parameters cause we cannot do it from plugin.xml
 * The wizard will be without "new stream" branch & welcome page
 *
 * @author A.Solod
 */
public class NewTopicStreamWizardCaller extends NewStreamWizard {
    public NewTopicStreamWizardCaller() {
        this.isStream = true;
        this.dontShowWelcomePage = true;
        this.setMode(NewStreamWizard.Mode.TOPIC_STREAM);
    }

    public NewTopicStreamWizardCaller(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn) {
        super(connection, basedOn, true);
        this.dontShowWelcomePage = true;
        this.setMode(NewStreamWizard.Mode.TOPIC_STREAM);
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.team.core.RepositoryProvider;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;

/**
 * Performs a repository operation on resources from multiple providers.
 *
 * @author V.Grishchenko
 */
public abstract class WorkspaceOperation extends DMOperation {

    private IDMWorkspaceResource[] resources;
    private IDMWorkspaceResourceFilter filter;

    public WorkspaceOperation(IWorkbenchPart part, IDMWorkspaceResource[] resources) {
        this(part, resources, null);
    }

    public WorkspaceOperation(IWorkbenchPart part, IDMWorkspaceResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part);
        this.resources = resources;
        this.filter = filter;
    }

    @Override
    public void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
        Map<RepositoryProvider, List<IDMWorkspaceResource>> table = getProviderMapping(getResources());
        Set<RepositoryProvider> keySet = table.keySet();
        monitor.beginTask(null, keySet.size() * 1000);
        Iterator<RepositoryProvider> iterator = keySet.iterator();
        while (iterator.hasNext()) {
            IProgressMonitor subMonitor = Utils.subMonitorFor(monitor, 1000, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK);
            DMRepositoryProvider provider = (DMRepositoryProvider) iterator.next();
            List<IDMWorkspaceResource> list = table.get(provider);
            IDMWorkspaceResource[] providerResources = (IDMWorkspaceResource[]) list.toArray(new IResource[list.size()]);
            ISchedulingRule rule = getSchedulingRule(provider);
            try {
                Job.getJobManager().beginRule(rule, monitor);
                monitor.setTaskName(getTaskName(provider));
                execute(provider.getIdmProject(), providerResources, subMonitor);
            } finally {
                Job.getJobManager().endRule(rule);
            }
        }
    }

    /**
     * Return the taskname to be shown in the progress monitor while operating
     * on the given provider.
     * @param provider the provider being processed
     * @return the taskname to be shown in the progress monitor
     */
    protected abstract String getTaskName(DMRepositoryProvider provider);

    /**
     * Return the scheduling rule to be obtained before work
     * begins on the given provider. By default, it is the provider's project.
     * This can be changed by subclasses.
     * @param provider
     * @return
     */
    protected ISchedulingRule getSchedulingRule(DMRepositoryProvider provider) {
        return provider.getProject();
    }

    /**
     * Helper method. Return a Map mapping provider to a list of resources
     * shared with that provider.
     */
    private Map<RepositoryProvider, List<IDMWorkspaceResource>> getProviderMapping(IDMWorkspaceResource[] resources) {
        Map<RepositoryProvider, List<IDMWorkspaceResource>> result = new HashMap<RepositoryProvider, List<IDMWorkspaceResource>>();
        for (int i = 0; i < resources.length; i++) {
            RepositoryProvider provider = DMRepositoryProvider.getDMProvider(resources[i].getLocalResource().getProject());
            assert provider != null;
            List<IDMWorkspaceResource> list = result.get(provider);
            if (list == null) {
                list = new ArrayList<IDMWorkspaceResource>();
                result.put(provider, list);
            }
            list.add(resources[i]);
        }
        return result;
    }

    /**
     * Return the resources that the operation is being performed on
     * @return
     */
    protected IDMWorkspaceResource[] getResources() {
        return resources;
    }

    public IDMWorkspaceResourceFilter getFilter() {
        return filter;
    }

    /**
     * Set the resources that the operation is to be performed on
     * @param resources
     */
    protected void setResources(IDMWorkspaceResource[] resources) {
        this.resources = resources;
    }

    /**
     * Execute the operation on the resources for the given provider.
     * @param provider
     * @param providerResources
     * @param monitor
     * @throws DMException
     * @throws InterruptedException
     */
    protected abstract void execute(IDMProject provider, IDMWorkspaceResource[] resources, IProgressMonitor monitor)
            throws CoreException, InterruptedException;

}

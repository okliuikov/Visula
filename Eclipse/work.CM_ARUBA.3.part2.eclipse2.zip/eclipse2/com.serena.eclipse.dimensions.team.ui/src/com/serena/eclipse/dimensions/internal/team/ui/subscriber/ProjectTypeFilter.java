/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Filters resources out that belong to the project of the specified type.
 * @author V.Grishchenko
 */
public class ProjectTypeFilter extends FastSyncInfoFilter {
    /** filters resources shared with projects */
    public static final ProjectTypeFilter PROJECT_FILTER = new ProjectTypeFilter(IDMProject.WORKSET);
    /** filters resources shared with baselines */
    public static final ProjectTypeFilter BASELINE_FILTER = new ProjectTypeFilter(IDMProject.BASELINE);

    private int type;

    private ProjectTypeFilter(int typeToFilter) {
        Assert.isLegal(typeToFilter == IDMProject.WORKSET || typeToFilter == IDMProject.BASELINE);
        this.type = typeToFilter;
    }

    @Override
    public boolean select(SyncInfo info) {
        IDMProject project = null;
        if (info.getRemote() != null) {
            project = ((IDMRemoteResource) info.getRemote()).getProject();
        } else if (info.getBase() != null) {
            project = ((IDMRemoteResource) info.getBase()).getProject();
        } else if (info.getLocal() != null) {
            try {
                project = DMTeamPlugin.getWorkspace().getProject(info.getLocal());
            } catch (CoreException e) {
                DMTeamUiPlugin.log(e.getStatus()); // log and continue
            }
        }
        if (project == null) {
            return true;
        }
        return project.getType() != type;
    }

}

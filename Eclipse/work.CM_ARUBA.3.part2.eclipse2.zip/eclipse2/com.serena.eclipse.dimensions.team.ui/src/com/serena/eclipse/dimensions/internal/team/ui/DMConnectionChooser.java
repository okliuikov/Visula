package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.IDMConnectionProvider;
import com.serena.eclipse.dimensions.internal.ui.controls.ConnectionListPanel;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ConnectionListDialog;

public class DMConnectionChooser implements IDMConnectionProvider {

    public DMConnectionChooser() {

    }

    @Override
    public DimensionsConnectionDetailsEx getConnection(final DimensionsConnectionDetailsEx[] inputs) {
        final Display disp = Display.getDefault();
        final DimensionsConnectionDetailsEx[] cons = new DimensionsConnectionDetailsEx[1];
        disp.syncExec(new Runnable() {
            @Override
            public void run() {
                ConnectionListDialog consel = new ConnectionListDialog(disp.getActiveShell(), Messages.ConnectionSelector_title,
                        Messages.ConnectionSelector_desc, false, ConnectionListPanel.SHOW_ALL);
                consel.setConnections(inputs);
                if (consel.open() == Window.OK) {
                    DimensionsConnectionDetailsEx[] selectedCons = consel.getSelectedConnections();
                    cons[0] = selectedCons[0];
                } else {
                    cons[0] = null;
                }
            }
        });
        return cons[0];
    }

    // force it into starting
    @Override
    public boolean poke() {
        return true;
    }

}

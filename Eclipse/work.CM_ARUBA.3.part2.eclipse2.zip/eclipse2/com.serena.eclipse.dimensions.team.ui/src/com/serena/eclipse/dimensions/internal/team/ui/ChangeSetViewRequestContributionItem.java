package com.serena.eclipse.dimensions.internal.team.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.CompoundContributionItem;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;

import com.serena.dmclient.api.DimensionsChangeStep;

public class ChangeSetViewRequestContributionItem extends CompoundContributionItem {

    public static final String OPEN_REQUEST_COMMAND = "changesets.OpenRequestCommand"; //$NON-NLS-1$
    public static final String REQUEST_NAME_PARAM = "changesets.requestNameParam"; //$NON-NLS-1$

    public ChangeSetViewRequestContributionItem() {
    }

    public ChangeSetViewRequestContributionItem(String id) {
        super(id);
    }

    @Override
    protected IContributionItem[] getContributionItems() {
        IContributionItem[] result = new IContributionItem[0];

        IWorkbench wb = PlatformUI.getWorkbench();
        IWorkbenchWindow win = wb.getActiveWorkbenchWindow();
        IWorkbenchPage page = win.getActivePage();
        IWorkbenchPart active = page.getActivePart();

        if (active == null) {
            return result;
        }
        IWorkbenchSite site = active.getSite();
        ISelectionProvider selectionProvider = site.getSelectionProvider();
        TreeSelection selection = (TreeSelection) selectionProvider.getSelection();
        Object selObject = selection.getFirstElement();

        DimensionsChangeStep changeStep = (DimensionsChangeStep) selObject;

        List<String> requests = changeStep.getRequestsIds();
        Map<String, String> params = null;
        List<CommandContributionItem> contributions = new ArrayList<CommandContributionItem>();
        for (String requestName : requests) {
            params = new HashMap<String, String>();
            params.put(REQUEST_NAME_PARAM, requestName);
            CommandContributionItemParameter param = new CommandContributionItemParameter(PlatformUI.getWorkbench(),
                    REQUEST_NAME_PARAM + requestName, OPEN_REQUEST_COMMAND, CommandContributionItem.STYLE_PUSH);
            param.label = requestName;
            param.parameters = params;
            param.visibleEnabled = true;
            contributions.add(new CommandContributionItem(param));
        }
        result = contributions.toArray(new IContributionItem[requests.size()]);
        return result;
    }
}

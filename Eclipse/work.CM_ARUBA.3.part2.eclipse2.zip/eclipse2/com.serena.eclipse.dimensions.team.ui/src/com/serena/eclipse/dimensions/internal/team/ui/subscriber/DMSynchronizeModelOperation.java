/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.jface.action.IAction;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.SubscriberParticipant;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.dmfile.sync.WorkareaType;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMSyncInfo;
import com.serena.eclipse.dimensions.internal.team.core.DMSyncTreeSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.TransferShape;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.IPromptCondition;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.PromptingDialog;
import com.serena.eclipse.dimensions.internal.ui.actions.ShowDetailsAction;

/**
 * Base class for all sync operations, adds a generic <code>prompt</code> method
 * as normally we prompt the user before the operation is run.
 * @author V.Grishchenko
 */
public abstract class DMSynchronizeModelOperation extends SynchronizeModelOperation {
    private DMSyncTreeSubscriber subscriber;
    private SyncInfoSet syncInfoSet;
    private ShowDetailsAction showDetailsAction;
    private String errorDetails;

    private boolean streamDeliverOperation;
    private boolean streamShelveOperation;
    private boolean streamOperation;
    private ISynchronizePageConfiguration configuration;
    private SyncInfoSet allOutgoingInfos = new SyncInfoSet();

    public DMSynchronizeModelOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        super(configuration, elements);
        this.subscriber = (DMSyncTreeSubscriber) ((SubscriberParticipant) configuration.getParticipant()).getSubscriber();
        this.showDetailsAction = new ShowDetailsAction();
        this.showDetailsAction.setShell(getShell());
    }

    public DMSynchronizeModelOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements,
            boolean streamDeliverOperation, boolean streamShelveOperation) {
        this(configuration, elements);
        this.configuration = configuration;
        this.streamDeliverOperation = streamDeliverOperation;
        this.streamShelveOperation = streamShelveOperation;
        this.streamOperation = streamDeliverOperation || streamShelveOperation;

        if (streamOperation && configuration != null) {
            ISynchronizeParticipant participant = configuration.getParticipant();
            if (participant instanceof DMWorkspaceStreamOutgoingParticipant) {
                DMWorkspaceStreamOutgoingParticipant dp = (DMWorkspaceStreamOutgoingParticipant) participant;
                this.allOutgoingInfos = dp.getAllOutgoingSyncInfoSet();
            }
        }
    }

    @Override
    protected boolean canRunAsJob() {
        return true;
    }

    @Override
    protected SyncInfoSet getSyncInfoSet() {
        if (syncInfoSet == null) {
            return super.getSyncInfoSet();
        }
        return syncInfoSet;
    }

    public void setSyncInfoSet(SyncInfoSet syncInfoSet) {
        this.syncInfoSet = syncInfoSet;
    }

    private SyncInfoSet getAllOutgoingSyncInfo() {
        return allOutgoingInfos;
    }

    /**
     * @return Returns the subscriber.
     */
    public DMSyncTreeSubscriber getSubscriber() {
        return subscriber;
    }

    /**
     * Prompts the user for additional information, if necessary.
     *
     * @return
     *         <code>true</code> if the operation should be executed, returns <code>false</code> otherwise
     * @throws CoreException
     */
    public boolean prompt() throws InvocationTargetException, InterruptedException {
        return true;
    }

    @Override
    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
        DMWorkspaceStreamOutgoingParticipant dp = null;
        if (isStreamOperation() && configuration != null) {
            ISynchronizeParticipant participant = configuration.getParticipant();
            if (participant instanceof DMWorkspaceStreamOutgoingParticipant) {
                dp = (DMWorkspaceStreamOutgoingParticipant) participant;
            }
        }

        SyncInfoSet selSyncSet = getSyncInfoSet();
        SyncInfoSet allSyncInfo = getAllOutgoingSyncInfo();

        // divide the sync info by project

        ProjectsSyncInfoMapping syncInfoMapping;
        if (dp != null && isStreamShelveOperation()) {
            syncInfoMapping = ProjectsSyncInfoMapping.createUnitedStreamSyncMapping(selSyncSet, allSyncInfo);
        } else {
            // divide cross project info and default delivery data
            syncInfoMapping = ProjectsSyncInfoMapping.createSyncMapping(selSyncSet, allSyncInfo, isStreamOperation());
        }

        monitor.beginTask(null, syncInfoMapping.getTotalProjectsLength() * 100);

        try {
            if (dp != null) {
                if (isStreamDeliverOperation()) {
                    runDeliverOperation(syncInfoMapping, dp, monitor);
                } else if (isStreamShelveOperation()) {
                    runShelveOperation(syncInfoMapping, dp, monitor);
                }
            } else {
                runOperation(syncInfoMapping, monitor);
            }
        } catch (CoreException e) {
            showDetailsAction.setDetails(errorDetails);
            throw new InvocationTargetException(e);
        } finally {
            monitor.done();
        }
    }

    private void runOperation(ProjectsSyncInfoMapping syncMapping, IProgressMonitor monitor) throws CoreException,
            InterruptedException {
        SyncData data;
        // upload cross project changes
        Map<IProject, SyncInfoSet> crossInfoSets = syncMapping.getCrossInfoSets();
        for (Iterator<IProject> iter = crossInfoSets.keySet().iterator(); iter.hasNext();) {
            IProject project = iter.next();
            data = new SyncData(DMRepositoryProvider.getDMProvider(project), crossInfoSets.get(project));
            run(data, Utils.subMonitorFor(monitor, 100));
        }

        // upload default changes
        Map<IProject, SyncInfoSet> infoSets = syncMapping.getInfoSets();
        for (Iterator<IProject> iter = infoSets.keySet().iterator(); iter.hasNext();) {
            IProject project = iter.next();
            data = new SyncData(DMRepositoryProvider.getDMProvider(project), infoSets.get(project));
            run(data, Utils.subMonitorFor(monitor, 100));
        }
    }

    private void runDeliverOperation(ProjectsSyncInfoMapping syncMapping, DMWorkspaceStreamOutgoingParticipant participant,
            IProgressMonitor monitor) throws CoreException, InterruptedException {
        // save ordering
        Map<QualifiedName, List<DeliverSyncData>> crossDeliveryDetails = new LinkedHashMap<QualifiedName, List<DeliverSyncData>>();

        // cross project changes
        Map<IProject, SyncInfoSet> crossInfoSets = syncMapping.getCrossInfoSets();
        fillDeliveryDetails(crossDeliveryDetails, syncMapping, participant, crossInfoSets, false);
        for (Map.Entry<QualifiedName, List<DeliverSyncData>> entry : crossDeliveryDetails.entrySet()) {
            List<DeliverSyncData> deliverBucket = entry.getValue();
            run(deliverBucket, Utils.subMonitorFor(monitor, deliverBucket.size() * 100));
        }

        // save ordering
        Map<QualifiedName, List<DeliverSyncData>> deliveryDetails = new LinkedHashMap<QualifiedName, List<DeliverSyncData>>();
        // default changes
        Map<IProject, SyncInfoSet> infoSets = syncMapping.getInfoSets();
        fillDeliveryDetails(deliveryDetails, syncMapping, participant, infoSets, false);
        for (Map.Entry<QualifiedName, List<DeliverSyncData>> entry : deliveryDetails.entrySet()) {
            List<DeliverSyncData> deliverBucket = entry.getValue();
            run(deliverBucket, Utils.subMonitorFor(monitor, deliverBucket.size() * 100));
        }

    }

    private void runShelveOperation(ProjectsSyncInfoMapping syncMapping, DMWorkspaceStreamOutgoingParticipant participant,
            IProgressMonitor monitor) throws CoreException, InterruptedException {
        // save ordering
        Map<QualifiedName, List<DeliverSyncData>> deliveryDetails = new LinkedHashMap<QualifiedName, List<DeliverSyncData>>();
        // default changes
        Map<IProject, SyncInfoSet> infoSets = syncMapping.getInfoSets();
        fillDeliveryDetails(deliveryDetails, syncMapping, participant, infoSets, true);

        for (Map.Entry<QualifiedName, List<DeliverSyncData>> entry : deliveryDetails.entrySet()) {
            List<DeliverSyncData> deliverBucket = entry.getValue();
            run(deliverBucket, Utils.subMonitorFor(monitor, deliverBucket.size() * 100));
        }
    }

    /**
     * Creates buckets for delivery using qualified name
     */
    private static void fillDeliveryDetails(Map<QualifiedName, List<DeliverSyncData>> deliveryDetails,
            ProjectsSyncInfoMapping syncMapping, DMWorkspaceStreamOutgoingParticipant participant,
            Map<IProject, SyncInfoSet> infoSets, boolean isShelving) throws CoreException {
        for (IProject project : infoSets.keySet()) {
            TransferShape shape = participant.getTransferShape(project);
            DMRepositoryProvider provider = DMRepositoryProvider.getDMProvider(project);
            SyncInfoSet infoSet = infoSets.get(project);
            Set<IResource> excludedResources = syncMapping.getExcludedCrossResources(project);

            DeliverSyncData data = new DeliverSyncData(provider, infoSet, excludedResources, shape, isShelving);

            QualifiedName qualifiedName = getQualifiedName(provider.getIdmProject());

            if (!deliveryDetails.containsKey(qualifiedName)) {
                deliveryDetails.put(qualifiedName, new ArrayList<DeliverSyncData>());
            }

            List<DeliverSyncData> datas = deliveryDetails.get(qualifiedName);
            datas.add(data);
        }
    }

    private static final String COMMON = WorkareaType.COMMON.toString();
    private static final String RELATIVE = WorkareaType.RELATIVE.toString();

    /**
     * @param project to get qualified name for
     * @return name of project to create delivery buckets </br> <code>
     * RELATIVE_WORKAREA:STREAMSPEC:CONNECTION or
     * COMMON_WORKAREA:STREAMNAME:CONNECTION:WORKAREAPATH
     * </code>
     */
    private static QualifiedName getQualifiedName(IDMProject project) {
        String spec = project.getId();
        String connName = project.getConnection().getConnName();

        if (project.isContainedEclipseProject() && !project.isFullWorkArea()) {
            return new QualifiedName(RELATIVE, new StringBuilder(spec).append(":").append(connName).toString());
        } else {
            IPath path = project.getUserDirectory();
            return new QualifiedName(COMMON, new StringBuilder(spec).append(":")
                    .append(connName)
                    .append(":")
                    .append(path)
                    .toString());
        }
    }

    protected abstract void run(SyncData data, IProgressMonitor monitor) throws CoreException, InterruptedException;

    protected void run(List<DeliverSyncData> datas, IProgressMonitor monitor) throws CoreException, InterruptedException {
    }

    /*
     * Indicate that the resource is out of sync if the sync state is not IN_SYNC
     * or if the local doesn't exist but the remote does.
     */
    protected boolean isOutOfSync(SyncInfo resource) {
        if (resource == null) {
            return false;
        }
        return (!(resource.getKind() == 0) || (!resource.getLocal().exists() && resource.getRemote() != null));
    }

    protected SyncInfo getParent(SyncInfo info) throws TeamException {
        return ((DMSyncInfo) info).getSubscriber().getSyncInfo(info.getLocal().getParent());
    }

    protected IResource[] getLocalResources(SyncInfo[] changes) {
        IResource[] result = new IResource[changes.length];
        for (int i = 0; i < result.length; i++) {
            result[i] = changes[i].getLocal();
        }
        return result;
    }

    protected boolean promptForOverwrite(final SyncInfoSet syncSet) {
        IPromptCondition condition = new IPromptCondition() {
            @Override
            public boolean needsPrompt(IResource resource) {
                return syncSet.getSyncInfo(resource) != null;
            }

            @Override
            public String promptMessage(IResource resource) {
                return NLS.bind(Messages.DMSynchronizeModelOperation_confirmOverwriteMessage, resource.getFullPath().toString());
            }
        };

        PromptingDialog dialog = new PromptingDialog(getShell(), syncSet.getResources(), condition,
                Messages.DMSynchronizeModelOperation_confirmOverwriteTitle, false, 0);
        try {
            final Set<IResource> resourcesToOverwrite = new HashSet<IResource>(Arrays.asList(dialog.promptForMultiple()));
            FastSyncInfoFilter rejectFilter = new FastSyncInfoFilter() {

                @Override
                public boolean select(SyncInfo info) {
                    return !resourcesToOverwrite.contains(info.getLocal());
                }

            };
            syncSet.rejectNodes(rejectFilter);
        } catch (InterruptedException e) {
            return false; // cancel
        }
        return !syncSet.isEmpty();
    }

    // removes metadata for conflicting deletions and remove them from the supplied set
    protected void handleConflictingDeletions(SyncInfoSet set) throws CoreException {
        FastSyncInfoFilter filter = FastSyncInfoFilter.getDirectionAndChangeFilter(SyncInfo.CONFLICTING, SyncInfo.DELETION);
        SyncInfo[] nodes = set.getNodes(filter);
        if (nodes.length > 0) {
            ArrayList<IResource> localsArray = new ArrayList<IResource>();
            for (int i = 0; i < nodes.length; i++) {
                IResource local = nodes[i].getLocal();
                IDMRemoteResource remote = (IDMRemoteResource) nodes[i].getRemote();
                // When we do merge from foreign stream we could get conflicting deletion instead of conflicting modifications from
                // verifying RPC.
                // If it is the case - ignore it, handle in another place
                if (TeamUtils.isLocalWorksetPointingToForeignStream(local)) {
                    if (!local.exists() && remote == null) { // if it is real conflicting deletion
                        localsArray.add(local);
                    }
                } else {
                    localsArray.add(local);
                }

            }
            IResource[] locals = localsArray.toArray(new IResource[localsArray.size()]);
            IDMRemoteResource[] remotes = new IDMRemoteResource[localsArray.size()];
            getSubscriber().merged(locals, remotes, null);
            set.removeAll(locals);
        }
    }

    // effectively manages the conflicting folders adds by adding metadata to them
    protected void handleConflictingFolderAdditions(SyncInfoSet set) throws CoreException {
        // reduces the set to that of conflicting folder additions
        class FolderFilter extends FastSyncInfoFilter {
            FastSyncInfoFilter filter;

            FolderFilter(FastSyncInfoFilter filter) {
                this.filter = filter;
            }

            @Override
            public boolean select(SyncInfo info) {
                if (info.getLocal().getType() == IResource.FOLDER) {
                    return filter.select(info);
                }
                return false;
            }
        }

        FastSyncInfoFilter filter = new FolderFilter(FastSyncInfoFilter.getDirectionAndChangeFilter(SyncInfo.CONFLICTING,
                SyncInfo.ADDITION));
        SyncInfo[] nodes = set.getNodes(filter);
        if (nodes.length > 0) {
            IResource[] locals = new IResource[nodes.length];
            IDMRemoteResource[] remotes = new IDMRemoteResource[nodes.length];
            for (int i = 0; i < nodes.length; i++) {
                locals[i] = nodes[i].getLocal();
                remotes[i] = (IDMRemoteResource) nodes[i].getRemote();
            }
            getSubscriber().merged(locals, remotes, null);
            set.removeAll(locals);
        }

    }

    protected void ensureParentsExist(SyncInfo[] nodes, IProgressMonitor monitor, boolean ensureReacheable) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, nodes.length);
        for (int i = 0; i < nodes.length; i++) {
            IContainer container = (IContainer) nodes[i].getLocal();
            TeamUtils.ensureContainerExists(container);
            if (ensureReacheable) {
                TeamUtils.ensureReacheable(container, false);
            }
            monitor.worked(1);
        }
        monitor.done();
    }

    protected void validateEdit(SyncInfoSet syncSet) throws CoreException {
        ArrayList<IFile> files = new ArrayList<IFile>();
        IResource[] resources = syncSet.getResources();
        for (int i = 0; i < resources.length; i++) {
            if (resources[i].getType() == IResource.FILE && TeamUtils.isReadOnly(resources[i])) {
                files.add((IFile) resources[i]);
            }
        }
        if (!files.isEmpty()) {
            IFile[] filesToValidate = files.toArray(new IFile[files.size()]);
            IStatus status = ResourcesPlugin.getWorkspace().validateEdit(filesToValidate, getShell());
            if (!status.isOK()) {
                throw new CoreException(status);
            }
        }
    }

    @Override
    protected IAction getGotoAction() {
        return showDetailsAction;
    }

    protected void setErrorDetails(String s) {
        this.errorDetails = s;
    }

    protected String getErrorDetails() {
        return errorDetails;
    }

    public boolean isStreamOperation() {
        return streamOperation;
    }

    public boolean isStreamDeliverOperation() {
        return streamDeliverOperation;
    }

    public boolean isStreamShelveOperation() {
        return streamShelveOperation;
    }

}

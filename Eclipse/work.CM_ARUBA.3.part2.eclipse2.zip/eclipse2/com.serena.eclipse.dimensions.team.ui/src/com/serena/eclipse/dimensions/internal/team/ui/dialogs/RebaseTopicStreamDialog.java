package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolTip;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.ChangeSetsQuery;
import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.WizardHelper;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.server.core.SpecialCharacters;
import merant.adm.dimensions.util.SpecUtils;

public class RebaseTopicStreamDialog extends ResizableDialog {
	private WorksetAdapter sourceTopic;
	
	private Project targetProject;
	private Long maxChangesetVersion;
	private List<String> invalidTargetProjectSpecs = new ArrayList<String>();
	
	private static final String LATEST_STREAM_VER = Messages.NewStreamDetailsPage_latest_stream_ver;
	private ToolTip toolTip;
	
	// UI
	private Label labelTargetProject;
	private Text txtTargetProjectSpec;
	private Button findWorksetButton;
	private Label labelTargetProjectVersion;
	private Text txtTargetProjectVersion;
	private Button btnSelectStreamVersion;

	private Integer targetVersion;
	private Listener focusInlistener;
	
	public RebaseTopicStreamDialog(Shell parent, WorksetAdapter topic) {
		super(parent);
		sourceTopic = topic;
	}

	private String getFullTargetProjectSpec() {
        String spec = UIUtils.safeGetText(txtTargetProjectSpec);
        if (Utils.isNullEmpty(spec))
            return "";
        if (!Utils.isNullEmpty(SpecUtils.getProduct(spec))) {
            return spec;
        }
        return NLS.bind("{0}:{1}", SpecUtils.getProduct(sourceTopic.getAPIObject().getName()), spec);
    }
	
	public Project getTargetProject() {
		return targetProject;
	}
	
	public Integer getTargetProjectVersion() {
		return targetVersion;
	}
	
	@Override
	protected Point getInitialSize() {
		minWidth = 560;
		minHeight = 160;
		return super.getInitialSize();
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		
		getShell().setText(NLS.bind(Messages.RebaseDialog_title, sourceTopic.getAPIObject().getName()));
		Composite composite = (Composite) super.createDialogArea(parent);

		Composite targetProjectComposite = new Composite(composite, SWT.NONE);

		GridLayout gridLayout = UIUtils.setGridLayout(targetProjectComposite, 3);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;

		UIUtils.setGridData(targetProjectComposite, GridData.FILL_HORIZONTAL);

		labelTargetProject = new Label(targetProjectComposite, SWT.NONE);
		labelTargetProject.setText(Messages.TargetProject);

		txtTargetProjectSpec = new Text(targetProjectComposite, SWT.BORDER);
		UIUtils.setGridData(txtTargetProjectSpec, GridData.FILL_HORIZONTAL);

		Object parentId = sourceTopic.getAPIObject().getAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
		if (parentId == null) {
			sourceTopic.getAPIObject().queryAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
			parentId = sourceTopic.getAPIObject().getAttribute(SystemAttributes.WSET_MAINLINE_SPEC);
		}
		if (null != parentId) {
			txtTargetProjectSpec.setText(parentId.toString());
		}
		txtTargetProjectSpec.addVerifyListener(new VerifyListener() {
			@Override
			public void verifyText(VerifyEvent e) {
				e.text = e.text.toUpperCase();
			}
		});
		txtTargetProjectSpec.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				validateTargetProject(false);
			}
		});
		findWorksetButton = new Button(targetProjectComposite, SWT.NONE);
		findWorksetButton.setText(Messages.SelectWithThreeDots);
		findWorksetButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DimensionsConnectionDetailsEx connection = sourceTopic.getConnectionDetails();
				FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), IDMConstants.PROJECT, connection,
						"", true, false, connection.isOnlyStreamsActive(),
						connection.isOnlyProjectsActive());
				if (dialog.open() != Window.OK || dialog.getFindResult().isEmpty()) {
					return;
				}
				List<?> objects = dialog.getFindResult().getObjects();
				targetProject = (Project) objects.get(0);
				queryChangeSets();
				txtTargetProjectSpec.setText(targetProject.getName());
				if (validateTargetProject(false)) {
					validateTargetProjectVersion();
				}
			}
		});
		labelTargetProjectVersion = new Label(targetProjectComposite, SWT.NONE);
		labelTargetProjectVersion.setText(Messages.SelectSpecificVersion);
		txtTargetProjectVersion = new Text(targetProjectComposite, SWT.BORDER);
		txtTargetProjectVersion.setForeground(getShell().getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
		txtTargetProjectVersion.setText(LATEST_STREAM_VER);
		UIUtils.setGridData(txtTargetProjectVersion, GridData.FILL_HORIZONTAL);

		txtTargetProjectVersion.addVerifyListener(new VerifyListener() {
			@Override
			public void verifyText(VerifyEvent e) {
				String string = e.text;

				if (txtTargetProjectVersion.getText().length() < 1 && string.equals(LATEST_STREAM_VER)) {
					return;
				}
				char[] chars = new char[string.length()];
				string.getChars(0, chars.length, chars, 0);
				for (char ch : chars) {
					if (!(ch >= '0' && ch <= '9')) {
						e.doit = false;
						return;
					}
				}
				if (txtTargetProjectVersion.getText().equals(LATEST_STREAM_VER)) {
					txtTargetProjectVersion.selectAll();
				}
			}
		});

		txtTargetProjectVersion.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				String value = txtTargetProjectVersion.getText();
				if (value.equals(LATEST_STREAM_VER)) {
					txtTargetProjectVersion.setForeground(getShell().getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
				} else {
					txtTargetProjectVersion.setForeground(null);
				}
				if (isSpecificVersion(value)) {
					validate();
				}
			}
		});

		txtTargetProjectVersion.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent e) {
				if (txtTargetProjectVersion.getText().length() < 1) {
					txtTargetProjectVersion.setText(LATEST_STREAM_VER);
				}
			}

			@Override
			public void focusGained(FocusEvent e) {
				String value = txtTargetProjectVersion.getText();
				if (value.equals(LATEST_STREAM_VER)) {
					txtTargetProjectVersion.setText(Utils.EMPTY_STRING);
				}
			}
		});

		btnSelectStreamVersion = new Button(targetProjectComposite, SWT.PUSH);
		btnSelectStreamVersion.setText(Messages.NewStreamDetailsPage_btnSelectTitle);
		btnSelectStreamVersion.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (!validateTargetProject()) {
					return;
				}

				WorksetAdapter wsAdapter = new WorksetAdapter(targetProject, sourceTopic.getConnectionDetails());
				final long[] treeVersion = new long[1];
				StreamVersionSelectionDialog dialog = new StreamVersionSelectionDialog(getShell(),
						(targetProject.isStream() ? Messages.NewStreamDetailsPage_dialogStreamVerTitle
								: Messages.NewStreamDetailsPage_dialogProjectVerTitle),
						wsAdapter);
				dialog.addPropertyChangeListener(new PropertyChangeListener() {
					@Override
					public void propertyChange(PropertyChangeEvent event) {
						if (event.getNewValue() instanceof TreeSelection) {
							TreeSelection value = (TreeSelection) event.getNewValue();
							if (value.getFirstElement() instanceof DimensionsChangeSet) {
								DimensionsChangeSet changeSetSelected = (DimensionsChangeSet) value.getFirstElement();
								treeVersion[0] = changeSetSelected.getRepositoryVersion().getTreeVersion();
							}
						}
					}
				});
				if (dialog.open() == Window.OK) {
					txtTargetProjectVersion.setText(String.valueOf(treeVersion[0]));
				}
			}
		});

		toolTip = new ToolTip(UIUtils.findShell(), SWT.BALLOON | SWT.ICON_WARNING);
		toolTip.setAutoHide(false);
		
		focusInlistener = new Listener() {
			@Override
			public void handleEvent(Event event) {
				hideTip();
			}
		};
		getShell().getParent().getDisplay().addFilter(SWT.FocusIn, focusInlistener);

		return composite;
	}
	

	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		super.createButtonsForButtonBar(parent);
		getButton(IDialogConstants.OK_ID).setText(Messages.RebaseDialog_okText);
	}

	@Override
	protected void okPressed() {
		if (!validateTargetProject() || !validateTargetProjectVersion()) {
			return;
		}
		super.okPressed();
	}
	
	@Override
	public boolean close() {
		hideTip();
		getShell().getParent().getDisplay().removeFilter(SWT.FocusIn, focusInlistener);
		String value = txtTargetProjectVersion.getText();
		if (isSpecificVersion(value)) {
			targetVersion = Integer.valueOf(value);
		}
		return super.close();
	}
	
	private boolean isSpecificVersion(String version) {
		return !Utils.isNullEmpty(version) && !version.equals(LATEST_STREAM_VER);
	}
	
	private boolean validateTargetProjectVersion() {
		String value = txtTargetProjectVersion.getText();
		if (!isSpecificVersion(value)) {
			hideTip();
			return true;
		}
		boolean isOk = !(value.length() > 1 && value.charAt(0) == '0');
		if (isOk) {
			if (maxChangesetVersion == null) {
				queryChangeSets();
			}
			try {
				Long version = Long.parseLong(value);
				isOk = version >= 0 && version <= maxChangesetVersion;
			} catch (NumberFormatException nfe) {
				isOk = false;
			}
			
		}
		if (!isOk) {
			String message = targetProject.isStream() ? Messages.NewStreamDetailsPage_incorrectStreamVerMessage
					: Messages.NewStreamDetailsPage_incorrectProjectVerMessage;
			showTip(txtTargetProjectVersion, message);
		} else {
			hideTip();
		}
		return isOk;
	}
	
    private void queryChangeSets() {
        try {
            PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
				@Override
				public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
					monitor.beginTask(null, IProgressMonitor.UNKNOWN);
					try {
						final Session session = sourceTopic.getConnectionDetails().openSession(null);
						ISessionRunnable work = new ISessionRunnable() {
							@Override
							public void run() throws Exception {
								ChangeSetsQuery query = session.getObjectFactory().getChangeSetsQuery();
								List<DimensionsChangeSet> changeSets = query.queryChangeSets(targetProject, null, null,
										false);
								long version = 0;
								maxChangesetVersion = Long.valueOf(version);
								for (DimensionsChangeSet changeSet : changeSets) {
									version = changeSet.getRepositoryVersion().getTreeVersion();
									if (maxChangesetVersion < version) {
										maxChangesetVersion = version;
									}
								}
							}
						};
						session.run(work, monitor);
					} catch (DMException e) {
						DMUIPlugin.log(e.getStatus());
					} finally {
						monitor.done();
					}
				}
            });
        } catch (InterruptedException e) {
            DMUIPlugin.log(new Status(IStatus.ERROR, DMUIPlugin.ID, 0, Utils.EMPTY_STRING, e));
        } catch (InvocationTargetException e) {
            DMUIPlugin.getDefault().handle(e, null);
        }
    }
    
    private void validate() {
		if (validateTargetProject()) {
			validateTargetProjectVersion();
		}
    }
    private boolean validateTargetProject() {
    	return validateTargetProject(/*allowQuery*/ true);
    }
    
    private boolean validateTargetProject(boolean allowQuery) {
		final String fullSpec = getFullTargetProjectSpec();

		if (SpecUtils.hasInvalidCharacterInProjectName(fullSpec)) {
			showTargetProjectValidationTip(NLS.bind(Messages.StreamNameContainsInvalidCharacters, SpecialCharacters.INVALID_OBJ_NAME_CHARS));
			return false;
		}
		if (invalidTargetProjectSpecs.contains(fullSpec)) {
			showTargetProjectValidationTip(getProjectDoesNotExistMessage(fullSpec));
			return false;
		} 
		if (fullSpec.equals(sourceTopic.getAPIObject().getName())) {
			showTargetProjectValidationTip(Messages.SourceAndTargetAreTheSame);
			return false;
		}
		if (Utils.isNullEmpty(fullSpec)) {
			showTargetProjectValidationTip(Messages.TargetProjectIsEmpty);
			return false;
		}
		hideTip();
		if (targetProject != null) {
			if (targetProject.getName().equals(fullSpec)) {
				return true;
			}
		}
		if (allowQuery == false) {
			return true;
		}
		
		final boolean[] result = { true };

		try {
			PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
				@Override
				public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
					try {
						monitor.beginTask("Validating project...", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
						DimensionsObjectFactory factory = sourceTopic.getConnectionDetails().openSession(monitor)
								.getObjectFactory();

						Project project = factory.getProject(fullSpec);
						if (project != null) {
							targetProject = project;
							maxChangesetVersion = null;
							result[0] = true;
						} else {
							result[0] = false;
						}
					} catch (NullPointerException e) {
					} catch (IllegalArgumentException e) {
					} catch (DMException e) {
						DMTeamUiPlugin.getDefault().handle(e, UIUtils.findShell());
					} finally {
						monitor.setTaskName(Utils.EMPTY_STRING);
						monitor.subTask(Utils.EMPTY_STRING);
						monitor.done();
					}
				}
			});
		} catch (InvocationTargetException e) {
		} catch (InterruptedException e) {
			DMTeamUiPlugin.getDefault().handle(e, UIUtils.findShell());
		}
		if (result[0] == false) {
			invalidTargetProjectSpecs.add(fullSpec);
			showTargetProjectValidationTip(getProjectDoesNotExistMessage(fullSpec));
		}
		return result[0];
	}
	
	private String getProjectDoesNotExistMessage(String fullSpec) {
		return NLS.bind(Messages.StreamOrProjectDoesNotExistInProduct,
				SpecUtils.getProjectName(fullSpec), SpecUtils.getProduct(fullSpec));
	}
    
	private void showTip(Control control, String message) {
		setTipDetails(control, message, true);
	}
	
	private void showTargetProjectValidationTip(String message) {
		Control control = txtTargetProjectSpec;
		if (txtTargetProjectVersion.isFocusControl()) {
			control = txtTargetProjectVersion; 
		}
		setTipDetails(control, message, true);
	}

	private void hideTip() {
		toolTip.setVisible(false);
	}

	private void setTipDetails(Control control, String message, boolean visible) {
		WizardHelper.setToolTipDetails(control, toolTip, message, visible);
	}
}

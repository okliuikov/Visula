/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions.xml;

import java.util.List;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandLocalScope;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.CommonWizardFactory;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.WizardFactory;

/**
 * Action that creates merge wizard from workspace resources that were selected by user
 */
public class WorkspaceMergeWizardAction extends WorkspaceWizardAction {

    @Override
    protected WizardFactory createWizardFactory(MergeCommandLocalScope mergeScope, List<MergeScopeGroup> possibleScopes,
            DimensionsConnectionDetailsEx connection) {
        return new CommonWizardFactory(mergeScope, possibleScopes, connection);
    }

}

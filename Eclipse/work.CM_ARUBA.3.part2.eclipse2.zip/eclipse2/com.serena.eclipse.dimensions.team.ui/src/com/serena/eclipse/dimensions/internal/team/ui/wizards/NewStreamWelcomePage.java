/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

public class NewStreamWelcomePage extends DimensionsWizardPage {
    private Button btnStream;
    private Button btnGeneral;

    private boolean setIsStreamOnInit = true;

    public NewStreamWelcomePage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(description);
        setPageComplete(true);
    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        Group grp = new Group(composite, SWT.NONE);
        UIUtils.setGridLayout(grp, 1);
        UIUtils.setGridData(grp, GridData.FILL_HORIZONTAL);

        btnStream = new Button(grp, SWT.RADIO);
        btnStream.setText(Messages.NewStreamWizard_welcome_btnStream);
        UIUtils.setGridData(btnStream, GridData.FILL_HORIZONTAL);
        UIUtils.createLabel(grp, Messages.NewStreamWizard_welcome_lblStream);
        UIUtils.createLabel(grp, Utils.EMPTY_STRING);

        btnGeneral = new Button(grp, SWT.RADIO);
        btnGeneral.setText(Messages.NewStreamWizard_welcome_btnProject);
        UIUtils.setGridData(btnGeneral, GridData.FILL_HORIZONTAL);
        btnGeneral.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                setPageComplete(true);
            }
        });

        btnStream.setSelection(setIsStreamOnInit);
        btnGeneral.setSelection(!setIsStreamOnInit);

        setControl(composite);
    }

    public Boolean isStream() {
        return safeGetSelection(btnStream);
    }

    public void setIsStream(boolean isStream) {
        setIsStreamOnInit = isStream;
        if (null == btnStream || null == btnGeneral) {
            return;
        }

        btnStream.setSelection(isStream);
        btnGeneral.setSelection(!isStream);
    }

    private Boolean safeGetSelection(final Button button) {
        if (null == button) {
            return null;
        }

        final boolean[] res = new boolean[1];
        button.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                res[0] = button.getSelection();
            }
        });
        return Boolean.valueOf(res[0]);
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.internal.resources.Project;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.viewers.ILabelDecorator;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.graphics.Image;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.ui.DMDecorator;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/*
 * Decorator used by sync participants.
 *
 * @author V.Grishchenko
 */
class DMParticipantLabelDecorator extends LabelProvider implements ILabelDecorator {
    public DMParticipantLabelDecorator(ISynchronizePageConfiguration configuration) {
    }

    @Override
    public Image decorateImage(Image image, Object element) {
        return null;
    }

    @Override
    public String decorateText(String text, Object element) {
        if (element instanceof ISynchronizeModelElement) {
            String suffix = getSuffix((ISynchronizeModelElement) element);
            if (suffix != null) {
                return text + suffix;
            }
        }
        return null;
    }

    private String getProjectSuffix(IDMWorkspaceResource project) {
        if (project == null || project.getProject() == null) {
            return "";
        }
        String key = project.getProject().getIsStream() ? Messages.decorator_prjStreamInfo : (project.getProject().isBaseline()
                ? Messages.decorator_prjBaselineInfo : Messages.decorator_prjWorksetInfo);
        // is it a SCC style
        IDMProject theProject = project.getProject();

        StringBuffer prjText = new StringBuffer(project.getProject().getId());
        if (theProject.isSccStyle()) {
            prjText.append("/").append(theProject.getRemoteOffset().toString());
        }
        String suffix = NLS.bind(key, prjText.toString(), project.getProject().getConnection().getConnName());
        return suffix;
    }

    String getSuffix(ISynchronizeModelElement element) {
        StringBuffer suffix = null;
        IResource resource = element.getResource();
        if (resource instanceof Project) {// Decorate Project/Stream
            try {
                return getProjectSuffix(DMTeamPlugin.getWorkspace().getWorkspaceResource(resource));
            } catch (CoreException ce) {
                // log and continue
                DMTeamUiPlugin.log(ce.getStatus());
            }
        }
        if (element instanceof IAdaptable) {
            SyncInfo syncInfo = (SyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
            if (syncInfo != null) {
                IResource local = syncInfo.getLocal();
                if (local != null && local.getType() == IResource.FILE && syncInfo.getRemote() instanceof IDMRemoteFile) {
                    try {
                        IDMRemoteResource base = DMTeamPlugin.getWorkspace().getBaseResource(local);
                        if (base instanceof IDMRemoteFile) {
                            String baseRev = ((IDMRemoteFile) base).getRevision();
                            String remtRev = ((IDMRemoteFile) syncInfo.getRemote()).getRevision();
                            suffix = new StringBuffer(" "); //$NON-NLS-1$
                            suffix.append(NLS.bind(Messages.DMParticipantLabelDecorator_suffix, baseRev, remtRev));
                        }
                    } catch (TeamException e) {
                        DMTeamUiPlugin.log(e.getStatus());
                    }
                }
                if (local != null) {
                    try {
                        IDMWorkspaceResource dmResource = DMTeamPlugin.getWorkspace().getWorkspaceResource(syncInfo.getLocal());
                        String moveSuffix = DMDecorator.getMovedInRepositorySuffix(dmResource);
                        if (moveSuffix != null) { // show only moves in repository
                            if (suffix != null) {
                                suffix.append(moveSuffix);
                            } else {
                                suffix = new StringBuffer(" ").append(moveSuffix); //$NON-NLS-1$
                            }
                        } else {
                            moveSuffix = DMDecorator.getMovedSuffix(dmResource);
                            if (moveSuffix != null) {
                                if (suffix != null) {
                                    suffix.append(moveSuffix);
                                } else {
                                    suffix = new StringBuffer(" ").append(moveSuffix); //$NON-NLS-1$
                                }
                            }
                        }
                    } catch (CoreException e) {
                        DMTeamUiPlugin.log(e.getStatus()); // just log it
                    }
                }
            }
        }
        return suffix == null ? null : suffix.toString();
    }

}

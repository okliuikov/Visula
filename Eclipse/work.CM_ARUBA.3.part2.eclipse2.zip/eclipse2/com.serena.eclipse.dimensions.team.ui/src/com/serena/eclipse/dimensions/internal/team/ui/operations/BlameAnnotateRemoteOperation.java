package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.revisions.IRevisionRulerColumn;
import org.eclipse.jface.text.revisions.RevisionInformation;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.internal.editors.quickdiff.LastSaveReferenceProvider;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.team.ui.editors.BlameRemoteFileEditorInput;

public class BlameAnnotateRemoteOperation extends BlameAnnotateOperation {

    public BlameAnnotateRemoteOperation(IDMRemoteFile resource, IWorkbenchPage page, DimensionsConnectionDetailsEx connection) {
        super(resource, page, connection);
    }

    @Override
    protected IEditorInput createEditorInput() {
        IDMRemoteFile remoteFile = getBase();
        if (remoteFile != null) {
            return new BlameRemoteFileEditorInput(remoteFile);
        }
        return null;
    }

    @Override
    protected void showRevisionInformation(AbstractDecoratedTextEditor editor, RevisionInformation info) throws CoreException {
        // Default quick diff provider because editor opened in read only mode.
        editor.showRevisionInformation(info, LastSaveReferenceProvider.class.getName());
        getPage().activate(editor);
        IRevisionRulerColumn c = (IRevisionRulerColumn) editor.getAdapter(IRevisionRulerColumn.class);
        addMenuDetectListener(info, c);
    }

}

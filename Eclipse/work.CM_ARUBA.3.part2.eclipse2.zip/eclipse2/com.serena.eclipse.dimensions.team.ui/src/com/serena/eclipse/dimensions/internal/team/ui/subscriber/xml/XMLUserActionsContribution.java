/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizePageActionGroup;

import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * Generate user actions menu that based on the server xml result
 */
class XMLUserActionsContribution extends SynchronizePageActionGroup {
    private ExecuteMergeAction updateToolbarAction;

    private static Set<Integer> defaultActions = new HashSet<Integer>(6);
    static {
        defaultActions.add(XSyncUserAction.SUAL_IGNORE.value());
        defaultActions.add(XSyncUserAction.SUAL_ACCEPT.value());
        defaultActions.add(XSyncUserAction.SUAL_USE_LOCAL.value());
        defaultActions.add(XSyncUserAction.SUAL_USE_REPOSITORY.value());
    }

    @Override
    public void initialize(ISynchronizePageConfiguration configuration) {
        super.initialize(configuration);
        this.updateToolbarAction = new ExecuteMergeAction(configuration, getVisibleRootsSelectionProvider(), true);
        updateToolbarAction.setToolTipText(Messages.DMXMLMergeParticipant_toolbar_apply_action);

        appendToGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, XMLMergeParticipant.TOOLBAR_CONTRIBUTION_GROUP,
                updateToolbarAction);

        appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_2,
                new XMLResolutionDetailsAction(Messages.DMXMLMergeParticipant_details_action, configuration));

        appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                new ExecuteMergeAction(configuration));

        appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                new ExecuteMergeAction(configuration, configuration.getSite().getSelectionProvider(), true));

    }

    /**
     * Dynamically creates context menu of possible user actions
     */
    @Override
    public void fillContextMenu(IMenuManager menu) {
        super.fillContextMenu(menu);
        ISelection selection = getConfiguration().getSite().getSelectionProvider().getSelection();
        if (selection instanceof IStructuredSelection) {
            IStructuredSelection sel = (IStructuredSelection) selection;

            boolean autoNode = false;
            Set<Integer> commonActions = null;

            boolean hasConflictingItems = false;
            Integer repositoryItemRevisionCount = null;
            Integer localItemRevisionCount = null;

            // try to find common actions for selected nodes
            for (Iterator<?> iterator = sel.iterator(); iterator.hasNext();) {
                Object element = iterator.next();

                if (!(element instanceof ISynchronizeModelElement) || !(element instanceof IAdaptable)) {
                    autoNode = true;
                    continue;
                }

                SyncInfo syncInfo = (SyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
                if (!(syncInfo instanceof XMLSyncInfo)) {
                    autoNode = true;
                    continue;
                }

                XMLSyncInfo xinfo = (XMLSyncInfo) syncInfo;
                Set<Integer> actions = new HashSet<Integer>(xinfo.getActions());

                hasConflictingItems = xinfo.hasConflictingItemsActions();
                if (hasConflictingItems && sel.size() == 1) {
                    localItemRevisionCount = xinfo.getResolution().getTgt().getRevisionCount();
                    repositoryItemRevisionCount = xinfo.getResolution().getSrc().getRevisionCount();
                }

                if (commonActions == null) {
                    commonActions = actions;
                } else {
                    commonActions.retainAll(actions);
                }

            }

            if (autoNode && commonActions != null) {
                commonActions.retainAll(defaultActions);
            }

            // use default action set if common actions set is empty
            if (commonActions == null) {
                commonActions = new HashSet<Integer>(defaultActions);
            }

            // try to initialize every known action type in the menu using common actions set
            if (XMLSyncInfo.hasAcceptAction(commonActions)) {
                Integer action = XMLSyncInfo.getAcceptAction(commonActions);
                XMLUserAction ua = new XMLUserAction(XMLMergeUIUtils.resolveActionLabel(action, false), action, getConfiguration());
                ua.addPropertyChangeListener(updateToolbarAction);
                menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, ua);
            }

            if (XMLSyncInfo.hasIgnoreAction(commonActions)) {
                Integer action = XMLSyncInfo.getIgnoreAction(commonActions);
                XMLUserAction ua = new XMLUserAction(XMLMergeUIUtils.resolveActionLabel(action, false), action, getConfiguration());
                ua.addPropertyChangeListener(updateToolbarAction);
                menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, ua);
            }

            if (XMLSyncInfo.hasMergeActions(commonActions)) {
                List<Integer> actions = XMLSyncInfo.getMergeActions(commonActions);
                if (actions.size() == 1) {
                    XMLUserAction ua = new XMLUserAction(XMLMergeUIUtils.resolveActionLabel(actions.get(0), false), actions.get(0),
                            getConfiguration());
                    ua.addPropertyChangeListener(updateToolbarAction);
                    menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, ua);
                } else {
                    MenuManager subm = new MenuManager(Messages.DMXMLMergeParticipantLabelDecorator_resolution_merge_content);
                    for (Integer action : actions) {
                        String actionLabel = null;
                        if (hasConflictingItems) {
                            if (XMLSyncInfo.isConflictingItemsAction(action)) {
                                actionLabel = XMLMergeUIUtils.resolveActionLabelForConflictingItems(action,
                                        repositoryItemRevisionCount, true);
                            } else {
                                actionLabel = XMLMergeUIUtils.resolveActionLabelForConflictingItems(action, localItemRevisionCount,
                                        true);
                            }
                        } else {
                            actionLabel = XMLMergeUIUtils.resolveActionLabel(action, true);
                        }
                        XMLUserAction ua = new XMLUserAction(actionLabel, action, getConfiguration());
                        ua.addPropertyChangeListener(updateToolbarAction);
                        ua.selectionChanged(sel);
                        subm.add(ua);
                    }
                    menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, subm);
                }
            }

            if (XMLSyncInfo.hasUseLocalActions(commonActions)) {
                List<Integer> actions = XMLSyncInfo.getUseLocalActions(commonActions);
                if (actions.size() == 1) {
                    XMLUserAction ua = new XMLUserAction(XMLMergeUIUtils.resolveActionLabel(actions.get(0), false), actions.get(0),
                            getConfiguration());
                    ua.addPropertyChangeListener(updateToolbarAction);
                    menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, ua);
                } else {
                    MenuManager subm = new MenuManager(Messages.DMXMLMergeParticipantLabelDecorator_resolution_use_local_content);
                    for (Integer action : actions) {
                        String actionLabel = null;
                        if (hasConflictingItems) {
                            if (XMLSyncInfo.isConflictingItemsAction(action)) {
                                actionLabel = XMLMergeUIUtils.resolveActionLabelForConflictingItems(action,
                                        repositoryItemRevisionCount, true);
                            } else {
                                actionLabel = XMLMergeUIUtils.resolveActionLabelForConflictingItems(action, localItemRevisionCount,
                                        true);
                            }
                        } else {
                            actionLabel = XMLMergeUIUtils.resolveActionLabel(action, true);
                        }
                        XMLUserAction ua = new XMLUserAction(actionLabel, action, getConfiguration());
                        ua.addPropertyChangeListener(updateToolbarAction);
                        ua.selectionChanged(sel);
                        subm.add(ua);
                    }
                    menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, subm);
                }
            }

            if (XMLSyncInfo.hasUseRepositoryActions(commonActions)) {
                List<Integer> actions = XMLSyncInfo.getUseRepositoryActions(commonActions);
                if (actions.size() == 1) {
                    XMLUserAction ua = new XMLUserAction(XMLMergeUIUtils.resolveActionLabel(actions.get(0), false), actions.get(0),
                            getConfiguration());
                    ua.addPropertyChangeListener(updateToolbarAction);
                    menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, ua);
                } else {
                    MenuManager subm = new MenuManager(Messages.DMXMLMergeParticipantLabelDecorator_resolution_use_remote_content);
                    for (Integer action : actions) {
                        String actionLabel = null;
                        if (hasConflictingItems) {
                            if (XMLSyncInfo.isConflictingItemsAction(action)) {
                                actionLabel = XMLMergeUIUtils.resolveActionLabelForConflictingItems(action,
                                        repositoryItemRevisionCount, true);
                            } else {
                                actionLabel = XMLMergeUIUtils.resolveActionLabelForConflictingItems(action, localItemRevisionCount,
                                        true);
                            }
                        } else {
                            actionLabel = XMLMergeUIUtils.resolveActionLabel(action, true);
                        }
                        XMLUserAction ua = new XMLUserAction(actionLabel, action, getConfiguration());
                        ua.addPropertyChangeListener(updateToolbarAction);
                        ua.selectionChanged(sel);
                        subm.add(ua);
                    }
                    menu.appendToGroup(XMLMergeParticipant.CONTEXT_MENU_CONTRIBUTION_GROUP_1, subm);
                }
            }
        }
    }

}
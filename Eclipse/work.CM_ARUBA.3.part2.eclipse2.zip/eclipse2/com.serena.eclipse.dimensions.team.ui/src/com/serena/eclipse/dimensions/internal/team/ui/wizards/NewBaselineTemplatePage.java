/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2012, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.Part;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.collections.BaselineTemplates;
import com.serena.dmclient.objects.Product;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.IDimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewObjectWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Wizard page for entering new baseline template and part information.
 *
 * @author V.Grishchenko
 *         Baselines only now
 *         Modes Description
 *         TEMPLATE_BASELINE
 */

public class NewBaselineTemplatePage extends DimensionsWizardPage implements IDimensionsWizardPage {

    private int mode; // not really needed as is implicit
    private List<String> itemTemplates = new ArrayList<String>();
    private List<String> requestTemplates = new ArrayList<String>();;
    private boolean initialized;
    private Map<String, TreeSet<String>> parts = new HashMap<String, TreeSet<String>>();

    private DimensionsConnectionDetailsEx connection;

    private NewBaselineGeneralPage genPage = null;

    private String[] availableTemplates;

    private Combo templateCombo;
    private Text baselinePartsTxt;
    private Button baselinePartBtn;
    private Group levelsGroup;

    private Product selectedProduct;
    private Product lastProduct;

    private Spinner levelsSpinner;
    private Button allLevelsBtn;
    private Button levelsBtn;

    /**
     * @param mode one of TEMPLATE_BASELINE
     */
    public NewBaselineTemplatePage(String pageName, String title, String description, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx connection, int mode, int options) {

        super(pageName, title, titleImage);
        setDescription(description);
        this.connection = connection;
        setMode(mode);
        setPageComplete(false); // not completed
    }

    public void setMode(int mode) {
        Assert.isLegal((mode == NewBaselineWizard.TEMPLATE_BASELINE) && mode != NewBaselineWizard.INVALID_MODE);
        if (this.mode == mode) {
            return;
        }
        this.mode = mode;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }
    }

    private NewBaselineGeneralPage getGeneralPage() {
        if (genPage == null) {
            genPage = (NewBaselineGeneralPage) getWizard().getPage(NewObjectWizard.GENERAL_PAGE);
        }
        return genPage;
    }

    // pick up values from other pages
    private void refreshPage() {
        // need product from general page
        String productName = getGeneralPage().getProductName();
        selectedProduct = getGeneralPage().getProduct(productName);
        if (lastProduct == null || (lastProduct != null && !lastProduct.equals(selectedProduct))) {
            initialized = false;
            lastProduct = selectedProduct;
        }
    }

    public String getBaselineTopPart() {
        return UIUtils.safeGetText(baselinePartsTxt);
    }

    public String getTemplate() {
        return UIUtils.safeGetCombo(templateCombo);
    }

    public int getLevels() {
        Integer val = UIUtils.safeGetSpinner(levelsSpinner);
        return val == null ? 0 : val.intValue();
    }

    /**
     * @param connection The connection to set.
     */
    @Override
    public void setConnection(DimensionsConnectionDetailsEx connection) {
        if (this.connection == connection || (this.connection != null && this.connection.equals(connection))) {
            return;
        }
        this.connection = connection;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }
    }

    @Override
    public void setVisible(boolean visible) {

        if (visible) {
            refreshPage();
            if (!initialized) {
                initializeValues();
            }
        }
        super.setVisible(visible);
    }

    @Override
    public void createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 4);
        UIUtils.createLabel(composite, Messages.newBaselineTemplatePage_templateLabel);
        templateCombo = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY | SWT.BORDER);
        UIUtils.setGridData(templateCombo, GridData.FILL_HORIZONTAL, 3);
        initTemplateCombo();

        templateCombo.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                String template = templateCombo.getText();
                if (isItemTemplate(template) || Utils.isNullEmpty(template)) {
                    // item template or design bl no need to relate request
                    setPageComplete(true);
                    ((NewBaselineRelatePage) getWizard().getPage(NewBaselineWizard.BASELINE_REQUEST_PAGE)).setPageComplete(true);
                } else if (isRequestTemplate(template)) {
                    ((NewBaselineRelatePage) getWizard().getPage(NewBaselineWizard.BASELINE_REQUEST_PAGE)).setPageComplete(false);
                }
                getContainer().updateButtons();

            }
        });
        UIUtils.createLabel(composite, Messages.newBaselineTemplatePage_topPartLabel);
        baselinePartsTxt = new Text(composite, SWT.BORDER);
        UIUtils.setGridData(baselinePartsTxt, GridData.FILL_HORIZONTAL, 2);
        baselinePartBtn = new Button(composite, SWT.PUSH);
        baselinePartBtn.setText(Messages.newBaselinePage_browse);
        baselinePartBtn.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                // open the find Part Wizardxx
                String selectedProduct = getGeneralPage().getProductName();
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.PART, connection,
                        selectedProduct, true, false);
                if (dialog.open() == Window.OK) {
                    List<String> parts = dialog.getSelectedNames();
                    assert parts.size() == 1; // single selection
                    baselinePartsTxt.setText(parts.get(0));
                }
            }
        });
        baselinePartsTxt.addVerifyListener(new VerifyListener() {
            @Override
            public void verifyText(VerifyEvent e) {
                e.text = e.text.toUpperCase();
            }
        });
        baselinePartsTxt.addModifyListener(new ModifyListener() {
            @Override
            public void modifyText(ModifyEvent e) {
                checkPage();
            }
        });
        // now add a group for levels
        UIUtils.createLabel(composite, null);
        levelsGroup = new Group(composite, SWT.NONE);
        levelsGroup.setText(Messages.newBaselineTemplatePage_levelsTitle);
        UIUtils.setGridLayout(levelsGroup, 3);
        GridData data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 3, 1);
        levelsGroup.setLayoutData(data);
        allLevelsBtn = new Button(levelsGroup, SWT.RADIO);
        allLevelsBtn.setText(Messages.newBaselineTemplatePage_allLevels);
        levelsBtn = new Button(levelsGroup, SWT.RADIO);
        levelsBtn.setText(Messages.newBaselineTemplatePage_Levels);
        levelsSpinner = new Spinner(levelsGroup, SWT.BORDER);
        data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 1, 1);
        allLevelsBtn.setLayoutData(data);
        data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 1, 1);
        levelsBtn.setLayoutData(data);
        data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 1, 1);
        levelsSpinner.setLayoutData(data);
        data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 1, 1);
        levelsSpinner.setLayoutData(data);
        // set up logic
        SelectionListener buttonListener = new SelectionAdapter() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                Button b = (Button) e.widget;
                if (b == allLevelsBtn) {
                    levelsSpinner.setSelection(0);
                    levelsSpinner.setEnabled(false);
                } else if (b == levelsBtn) {
                    levelsSpinner.setEnabled(true);
                }
            }
        };
        allLevelsBtn.setSelection(true);
        levelsSpinner.setSelection(0);
        levelsSpinner.setEnabled(false);
        allLevelsBtn.addSelectionListener(buttonListener);
        levelsBtn.addSelectionListener(buttonListener);
        setControl(composite);
    }

    @Override
    public void dispose() {
        super.dispose();
    }

    private void initializeValues() {
        final Product prod = selectedProduct;
        if (prod == null) {
            return;
        }
        try {
            IRunnableWithProgress runnableWithProgress = new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    monitor = Utils.monitorFor(monitor);
                    try {
                        monitor.beginTask(null, 50);
                        populateParts(prod);
                        monitor.worked(25);
                        populateTemplates(prod);
                    } catch (Throwable t) {
                        throw new InvocationTargetException(t);
                    } finally {
                        monitor.setTaskName(Utils.EMPTY_STRING);
                        monitor.subTask(Utils.EMPTY_STRING);
                        monitor.done();
                    }
                }
            };

            // here the intention is to use wizard's progress if it is already visible,
            // or busy indicator before the wizard is shown
            if (getWizard().getStartingPage() == this) {
                PlatformUI.getWorkbench().getProgressService().busyCursorWhile(runnableWithProgress);
            } else {
                getWizard().getContainer().run(false, false, runnableWithProgress);
            }

        } catch (InvocationTargetException e) {
            handle(e);
        } catch (InterruptedException ignore) {
        }
        initialized = true;
    }

    private TreeSet<String> cachePartNames(String productName, List<Part> partsList) {
        TreeSet<String> partTreeSet = new TreeSet<String>();
        for (Part p : partsList) {
            partTreeSet.add(p.getName());
        }
        parts.put(productName, partTreeSet);
        return partTreeSet;
    }

    private void populateTemplates(final Product prod) {
        final List[] holder = new List[1];
        try {
            getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    monitor.beginTask(null, 2);
                    monitor.worked(1); // show "progress"
                    try {
                        holder[0] = getTemplates(prod);
                    } catch (DMException e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e) {
            handle(e);
        } catch (InterruptedException ignore) {
        }
        String[] temps = new String[holder[0].size() + 1];
        temps[0] = Utils.EMPTY_STRING; // for design baselines
        for (int i = 0; i < holder[0].size(); i++) {
            temps[i + 1] = (String) holder[0].get(i);

        }
        availableTemplates = temps;
        initTemplateCombo();

    }

    private void initTemplateCombo() {
        if (templateCombo != null && availableTemplates != null) {
            templateCombo.setItems(availableTemplates);
            // default to first real template
            if (availableTemplates.length > 1) {
                templateCombo.select(1);
            } else {
                templateCombo.select(0);
            }
        }
    }

    private void populateParts(final Product product) {
        if (baselinePartsTxt == null) {
            return;
        }
        if (product == null) {
            baselinePartsTxt.setText(Utils.EMPTY_STRING);
            return;
        }
        TreeSet<String> productParts = parts.get(product.getName());
        if (productParts == null) {
            final List[] holder = new List[1];
            try {
                getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                    @Override
                    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                        monitor.beginTask(null, 2);
                        monitor.worked(1); // show "progress"
                        try {
                            assert product != null;
                            holder[0] = product.getParts(null);
                        } finally {
                            monitor.done();
                        }
                    }
                });
            } catch (InvocationTargetException e) {
                handle(e);
            } catch (InterruptedException ignore) {
            }
            productParts = cachePartNames(product.getName(), holder[0]);
        }
        // find the top part
        assert product != null;
        Part topPart = product.getRootPart();
        String spec = (String) topPart.getAttribute(SystemAttributes.OBJECT_SPEC);
        baselinePartsTxt.setText(spec);
    }

    private List<String> getTemplates(final Product product) throws DMException {
        // clear lists
        itemTemplates.clear();
        requestTemplates.clear();
        if (product == null || connection == null) {
            return Collections.emptyList();
        }

        BaselineTemplates itmTemps = product.getItemBaselineTemplates();
        BaselineTemplates chdTemps = product.getRequestBaselineTemplates();

        for (Iterator it = itmTemps.iterator(); it.hasNext();) {
            itemTemplates.add((String) it.next());
        }
        for (Iterator it = chdTemps.iterator(); it.hasNext();) {
            requestTemplates.add((String) it.next());
        }
        List<String> result = new ArrayList<String>();
        result.addAll(itemTemplates);
        result.addAll(requestTemplates);
        Collections.sort(result);
        return result;
    }

    private void handle(Exception e) {
        DMTeamUiPlugin.getDefault().handle(e);
    }

    public boolean isRequestTemplate(String name) {
        return requestTemplates.contains(name);
    }

    public boolean isItemTemplate(String name) {
        return itemTemplates.contains(name);
    }

    private boolean checkPart() {
        // check part is in list of all parts
        String topPart = getBaselineTopPart();
        TreeSet<String> partsTree = parts.get(selectedProduct.getName());
        if (partsTree != null && !partsTree.contains(topPart)) {
            setErrorMessage(Messages.newBaselineTemplatePage_validPart);
            return false;
        }
        return true;
    }

    private void checkPage() {
        setPageComplete(false);
        if (checkPart()) {
            setErrorMessage(null);
            setPageComplete(true);
        }
    }
}

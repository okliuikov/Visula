/*
 * @DimensionsItemHistoryView.java, created on 20-Mar-2006
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.views;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.eclipse.compare.CompareEditorInput;
import org.eclipse.compare.CompareUI;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IFontProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.team.core.TeamException;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IWorkbenchSiteProgressService;

import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionHistoryRec;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.ItemMetadata;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionListener;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.GetRevisionRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.IResourceStateChangeListener;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils.ExpandMode;
import com.serena.eclipse.dimensions.internal.team.core.meta.WorkspaceMetadataManager;
import com.serena.eclipse.dimensions.internal.team.ui.ItemRevisionHistory;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.compare.DMCompareRevToLocalEditorInput;
import com.serena.eclipse.dimensions.internal.team.ui.compare.LocalResourceTypedElement;
import com.serena.eclipse.dimensions.internal.team.ui.compare.RemoteResourceTypedElement;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.IPromptCondition;
import com.serena.eclipse.dimensions.internal.team.ui.dialogs.PromptingDialog;
import com.serena.eclipse.dimensions.internal.team.ui.operations.BlameAnnotateRemoteOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.CheckoutOperation;
import com.serena.eclipse.dimensions.internal.team.ui.operations.UndoCheckoutOperation;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.CheckoutHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectCompareHandler;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ActionWizard;
import com.serena.eclipse.dimensions.internal.ui.views.DimensionsCollectionsHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 *
 * @author ABollmann
 *
 */
public class DimensionsItemHistoryView extends DimensionsCollectionsHistoryView {

    public static final String VIEW_ID = "com.serena.eclipse.dimensions.internal.team.ui.views.ItemHistory"; //$NON-NLS-1$

    public static final int COL_NEW_REV = 0;
    public static final int COL_PREV_REV = 1;
    public static final int COL_STATUS = 2;
    public static final int COL_DATETIME = 3;
    public static final int COL_USER = 4;
    public static final int COL_DESC = 5;

    private IAction getContentAction;
    private IAction getRevisionAction;
    private IAction compareAction;
    private IAction compareLocalAction;
    private IAction checkoutAction;
    private IAction openAction;
    private IAction openPropertiesAction;
    private IAction actionAction;
    private IAction refreshAction;
    private IAction mergeAction;
    private IAction undoCheckoutAction;
    private IAction blameAction;

    private DimensionsConnectionDetailsEx conn; // connection for this history
    private String revisionSpec; // spec of the revision to retrieve the history from

    // sharing related
    private IFile local; // local resource if any
    private Project project; // if local is not null this is current mapping (global prj if shared with a baseline)
    private boolean isCurrentProjectBaseline; // if local is not null indicates if sharing is with a baseline
    private String baseRevision;
    private boolean locallyCheckedout; // if we have a local checkout
    private IDMProject dmProject;

    private Project globalProject; // cached global project
    private boolean detailsSet;

    private IResourceStateChangeListener stateListener;
    private String revisionId;

    // forget everything we know
    private void reset() {
        this.conn = null;
        this.revisionSpec = null;
        this.local = null;
        this.project = null;
        this.isCurrentProjectBaseline = false;
        this.baseRevision = null;
        this.locallyCheckedout = false;
        this.dmProject = null;
        this.globalProject = null;
        this.detailsSet = false;
    }

    // forget things that may reference a dead dmclient connection - they will be recreated as needed
    private void disconnected() {
        this.obj = null;
        this.project = null;
        this.isCurrentProjectBaseline = false;
        this.globalProject = null;
    }

    private class ItemHistorySorter extends ViewerSorter {

        @Override
        public int compare(Viewer viewer, Object e1, Object e2) {

            if (e1 instanceof ItemRevisionHistory && e2 instanceof ItemRevisionHistory) {
                // ensure strings are not null
                String dateString1 = Utils.getString(((ItemRevisionHistory) e1).getHistoryDate());
                String dateString2 = Utils.getString(((ItemRevisionHistory) e2).getHistoryDate());
                Date date1 = obj.getConnectionDetails()
                        .getDateTimeHelper()
                        .getDate(dateString1, SystemAttributes.LAST_UPDATED_DATE);
                Date date2 = obj.getConnectionDetails()
                        .getDateTimeHelper()
                        .getDate(dateString2, SystemAttributes.LAST_UPDATED_DATE);
                if (date1 == null || date2 == null) {
                    return dateString1.compareTo(dateString2); // default to string compare when parsing fails
                }
                if (date1.getTime() > date2.getTime()) {
                    return -1;
                } else if (date1.getTime() < date2.getTime()) {
                    return 1;
                } else {
                    return 0;
                }
            }
            return super.compare(viewer, e1, e2);
        }

    }

    public DimensionsItemHistoryView() {
        super();
        stateListener = new ResourceStateListener();
        DMTeamPlugin.getWorkspace().addResourceStateChangeListener(stateListener);
    }

    @Override
    public void createTable(Table table, TableLayout layout) {
        // Columns STATUS, DATE, USER , COMMENT
        layout.addColumnData(new ColumnWeightData(10, 80, true));
        TableColumn tc0 = new TableColumn(table, SWT.NONE);
        tc0.setText(Messages.itemHistory_newRevision);
        tc0.setAlignment(SWT.LEFT);
        tc0.setResizable(true);

        layout.addColumnData(new ColumnWeightData(10, 100, true));
        tc0 = new TableColumn(table, SWT.NONE);
        tc0.setText(Messages.itemHistory_prevRevision);
        tc0.setAlignment(SWT.LEFT);
        tc0.setResizable(true);

        layout.addColumnData(new ColumnWeightData(10, 80, true));
        tc0 = new TableColumn(table, SWT.NONE);
        tc0.setText(Messages.itemHistory_status);
        tc0.setAlignment(SWT.LEFT);
        tc0.setResizable(true);

        layout.addColumnData(new ColumnWeightData(10, 130, true));
        TableColumn tc1 = new TableColumn(table, SWT.NONE);
        tc1.setText(Messages.itemHistory_dateTime);
        tc1.setAlignment(SWT.LEFT);
        tc1.setResizable(true);

        layout.addColumnData(new ColumnWeightData(5, 50, true));
        TableColumn tc2 = new TableColumn(table, SWT.NONE);
        tc2.setText(Messages.itemHistory_user);
        tc2.setAlignment(SWT.LEFT);
        tc2.setResizable(true);

        layout.addColumnData(new ColumnWeightData(30, 150, true));
        TableColumn tc4 = new TableColumn(table, SWT.NONE);
        tc4.setText(Messages.itemHistory_description);
        tc4.setAlignment(SWT.LEFT);
        tc4.setResizable(true);
    }

    @Override
    protected void setupViewer() {
        tableViewer.setContentProvider(new ItemHistoryContentProvider());
        tableViewer.setLabelProvider(new ItemHistoryLabelProvider(tableViewer.getTable()));
        tableViewer.setSorter(new ItemHistorySorter());
        tableViewer.addDoubleClickListener(new ItemHistoryDoubleClickListener());
    }

    @Override
    public void setFocus() {
        tableViewer.getControl().setFocus();
    }

    /**
     * Show history with selection forcing
     * @param local resource
     * @param revisionId for selection
     */
    public void showHistory(IFile local, String revisionId) {
        IDMRemoteFile res = null;
        try {
            res = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
            if (res == null) {
                res = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getRemoteResource(local);
            } else {
                cacheBaseState(res);
            }
        } catch (TeamException e) {
            IStatus error = new Status(IStatus.ERROR, DMTeamUiPlugin.ID, 0, "No remote or base revision information available",
                    null);
            UIUtils.showError(getSite().getShell(), "Error",
                    "Cannot show history for local file " + local.getFullPath().toString(), error);
        }
        showHistory(res, local, revisionId, res.getProject().getConnection());
    }

    public void showHistory(IDMRemoteFile res, IFile local, String revisionId, DimensionsConnectionDetailsEx conn) {
        reset();
        this.revisionId = revisionId;
        if (res != null) {
            try {
                if (local != null) {
                    this.local = local;
                    setDetailsFromLocalFile(local);
                }
                ItemRevisionAdapter item = new ItemRevisionAdapter(res.getItemRevision(), conn);
                this.obj = item;
                this.revisionSpec = item.getObjectSpec();
                this.conn = conn;
                tableViewer.setInput(item);
            } catch (DMException e) {
                DMTeamUiPlugin.getDefault().handle(e);
            }
        } else {
            IStatus error = new Status(IStatus.ERROR, DMTeamUiPlugin.ID, 0, "No remote or base revision information available",
                    null);
            UIUtils.showError(getSite().getShell(), "Error",
                    "Cannot show history for local file " + local.getFullPath().toString(), error);
        }
    }

    public void showHistory(IFile local) {
        showHistory(local, null);
    }

    /**
     * Shows item revision history for the specified item revision.
     *
     * @param item revision to show history for
     * @param local corresponding local resource or <code>null</code> if none
     */
    public void showHistory(ItemRevisionAdapter item) {
        Assert.isNotNull(item);
        reset();
        this.obj = item;
        this.revisionSpec = item.getObjectSpec();
        this.conn = item.getConnectionDetails();
        tableViewer.setInput(item);
    }

    private void setDetails(String contentDescription, String titleTooltip) {
        setContentDescription(contentDescription);
        setTitleToolTip(titleTooltip);
        detailsSet = true;
    }

    private void setDetailsFromLocalFile(IFile local) {
        setDetails(local.getName(), local.getFullPath().toString());
    }

    @Override
    protected void createDynamicContextMenuActions() {
        MenuManager manager = new MenuManager();
        Menu menu = manager.createContextMenu(tableViewer.getControl());
        tableViewer.getControl().setMenu(menu);

        manager.setRemoveAllWhenShown(true);
        manager.addMenuListener(new IMenuListener() {

            @Override
            public void menuAboutToShow(IMenuManager manager) {

                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                if (selection.size() == 1) {
                    ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                    boolean isCheckedOut = itemHistory.getIsExtracted();
                    boolean isInCurrentWorkset = itemHistory.getIsInCurrentProject();
                    itemHistory.getItemRevision().getProject().queryAttribute(SystemAttributes.WSET_IS_STREAM);
                    boolean isStream = ((Boolean) itemHistory.getItemRevision()
                            .getProject()
                            .getAttribute(SystemAttributes.WSET_IS_STREAM)).booleanValue();
                    if (!isStream && /* isInCurrentWorkset */local != null) {
                        manager.add(getContentAction);
                    }
                    if (!isStream && !isCheckedOut && /* isInCurrentWorkset && */!locallyCheckedout && local != null) {
                        manager.add(getRevisionAction);
                    }
                    if (!isStream && !isCurrentProjectBaseline && !isCheckedOut && isInCurrentWorkset && !locallyCheckedout
                            && local != null) {
                        // Check out is only shown if the file belongs to a project, not to a baseline
                        // and the selected item revision is in that selected project and the original revision
                        // is not checked out
                        manager.add(checkoutAction);

                    }
                    if (isCheckedOut) {
                        manager.add(undoCheckoutAction);
                    }
                    if (!isCheckedOut) {
                        manager.add(actionAction);
                    }
                    manager.add(new Separator());
                    manager.add(openAction);
                    manager.add(blameAction);
                    manager.add(openPropertiesAction);
                    manager.add(new Separator());
                    if (local != null) {
                        manager.add(compareLocalAction);
                    }
                }
                if (selection.size() == 2) {
                    manager.add(compareAction);
                }
                if (selection.size() > 1) {
                    ItemRevisionHistory[] selRevs = (ItemRevisionHistory[]) selection.toList().toArray(
                            new ItemRevisionHistory[selection.size()]);
                    boolean allOut = true;
                    for (int i = 0; i < selRevs.length; i++) {
                        if (!selRevs[i].getIsExtracted()) {
                            allOut = false;
                            break;
                        }
                    }
                    if (allOut) {
                        manager.add(undoCheckoutAction);
                    }
                }
                manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
                manager.add(new Separator());
            }
        });
        getSite().registerContextMenu(manager, tableViewer);
    }

    @Override
    protected void createViewActions() {
        createGetContentAction();
        createGetRevisionAction();
        createCheckoutAction();
        createUndoCheckoutAction();
        createOpenAction();
        createBlameAction();
        createOpenPropertiesAction();
        createCompareLocalAction();
        createCompareAction();
        createActionAction();
        createRefreshAction();
        createMergeAction();
    }

    private void cacheObjects(IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        IDMWorkspace ws = DMTeamPlugin.getWorkspace();
        try {
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            final Session session = conn.openSession(Utils.subMonitorFor(monitor, 10));

            if (globalProject == null) {
                session.run(new ISessionRunnable() {
                    @Override
                    public void run() throws Exception {
                        globalProject = session.getObjectFactory().getGlobalProject();
                    }
                }, monitor);
            }
            if (project == null) {
                if (local == null) {
                    project = globalProject;
                } else {
                    dmProject = ws.getProject(local);
                    isCurrentProjectBaseline = dmProject.isBaseline();
                    project = isCurrentProjectBaseline ? globalProject : (Project) dmProject.getDimensionsObject();
                }
            }

            if (getRevision() == null) {
                Filter filter = new Filter();
                filter.criteria().add(new Filter.Criterion(FilterOptions.USAGE_RELATIONSHIP, Boolean.TRUE, 0));
                filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, revisionSpec, Filter.Criterion.EQUALS));
                project.flushRelatedObjects(ItemRevision.class, true);
                List relationships = project.getChildItems(filter);
                project.flushRelatedObjects(ItemRevision.class, true);
                if (!relationships.isEmpty()) {
                    assert relationships.size() == 1;
                    ItemRevision ir = (ItemRevision) ((DimensionsRelatedObject) relationships.get(0)).getObject();
                    setRevision(ir);
                }
            }
        } finally {
            monitor.done();
        }
    }

    private ItemRevision getRevision() {
        return obj != null ? (ItemRevision) obj.getAPIObject() : null;
    }

    private void setRevision(ItemRevision revision) {
        this.obj = new ItemRevisionAdapter(revision, conn);
    }

    public String getRevisionForSelection() {
        return revisionId;
    }

    public void resetRevisionForSelection() {
        this.revisionId = null;
    }

    @Override
    protected void fillLocalToolBar(IToolBarManager manager) {
        manager.add(refreshAction);
        manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
        manager.add(new Separator());
    }

    private void createGetContentAction() {
        getContentAction = new Action() {
            @Override
            public void run() {
                if (!checkOverwrite()) {
                    return;
                }

                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                ItemRevision item = itemHistory.getItemRevision();
                IFile[] filesToValidate = new IFile[1];
                filesToValidate[0] = local;
                IStatus status = ResourcesPlugin.getWorkspace().validateEdit(filesToValidate, tableViewer.getControl().getShell());
                if (!status.isOK()) {
                    return; // abort
                }

                try {
                    GetRevisionRequest revisionRequest = new GetRevisionRequest(local, item);
                    revisionRequest.setMakeWriteable(true);
                    revisionRequest.setMetadata(false);
                    revisionRequest.setExpandSubstitutionVariables(((ItemMetadata) WorkspaceMetadataManager.getInstance()
                            .getMetadata(local)).isHeaderSubst());
                    final GetRevisionRequest requests[] = new GetRevisionRequest[1];
                    requests[0] = revisionRequest;
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                dmProject.copyToWorkspace(requests, monitor);
                            } catch (CoreException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });
                } catch (InterruptedException ignore) {
                } catch (Exception e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
            }
        };
        getContentAction.setEnabled(true);
        getContentAction.setText(Messages.itemHistory_action_getContent_label);
        getContentAction.setToolTipText(Messages.itemHistory_action_getContent_tooltip);
    }

    private void createGetRevisionAction() {
        getRevisionAction = new Action() {
            @Override
            public void run() {
                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                ItemRevision item = itemHistory.getItemRevision();
                boolean overwrite = checkOverwrite();
                if (overwrite) {
                    try {
                        GetRevisionRequest revisionRequest = new GetRevisionRequest(local, item);
                        final GetRevisionRequest requests[] = new GetRevisionRequest[1];
                        requests[0] = revisionRequest;
                        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                            @Override
                            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                                try {
                                    dmProject.copyToWorkspace(requests, monitor);
                                } catch (CoreException e) {
                                    throw new InvocationTargetException(e);
                                }
                            }
                        });
                    } catch (InterruptedException ignore) {
                    } catch (Exception e) {
                        DMTeamUiPlugin.getDefault().handle(e);
                    }
                }
            }
        };
        getRevisionAction.setEnabled(true);
        getRevisionAction.setText(Messages.itemHistory_action_getRevision_label);
        getRevisionAction.setToolTipText(Messages.itemHistory_action_getRevision_tooltip);
    }

    private void createUndoCheckoutAction() {
        undoCheckoutAction = new Action() {
            @Override
            public void run() {
                List list = ((IStructuredSelection) tableViewer.getSelection()).toList();
                ItemRevisionHistory[] selectedHistory = (ItemRevisionHistory[]) list.toArray(new ItemRevisionHistory[list.size()]);
                ArrayList others = new ArrayList();
                boolean undoLocal = false; // if need to undo c/o in the local WSP
                if (local != null && locallyCheckedout) {
                    IDMRemoteResource base = null;
                    try {
                        base = DMTeamPlugin.getWorkspace().getBaseResource(local);
                    } catch (TeamException e) {
                        DMTeamUiPlugin.getDefault().handle(e);
                        return;
                    }
                    if (base instanceof IDMRemoteFile) {
                        IDMRemoteFile baseFile = (IDMRemoteFile) base;
                        assert baseFile.isExtracted();
                        for (int i = 0; i < selectedHistory.length; i++) {
                            ItemRevision revision = selectedHistory[i].getItemRevision();
                            if (baseFile.getItemSpec().equals(revision.getAttribute(SystemAttributes.OBJECT_SPEC))) {
                                undoLocal = true;
                            } else {
                                others.add(selectedHistory[i]);
                            }
                        }
                    }
                } else {
                    others.addAll(Arrays.asList(selectedHistory));
                }

                try {
                    HistoryUndoCheckout operation = new HistoryUndoCheckout(DimensionsItemHistoryView.this, local == null
                            ? new IResource[0] : new IResource[] { local }, null);
                    operation.setUndoLocal(undoLocal);
                    operation.setOtherCheckouts(others);
                    if (operation.prompt()) {
                        operation.run();
                        refresh();
                    }
                } catch (InvocationTargetException e) {
                    DMTeamUiPlugin.getDefault().handle(e, getSite().getShell(), Messages.itemHistory_undoCO_errTitle,
                            Messages.itemHistory_undoCO_errMsg);
                } catch (InterruptedException ignore) {
                }
            }
        };
        undoCheckoutAction.setEnabled(true);
        undoCheckoutAction.setText(Messages.itemHistory_undoCO_text);
        undoCheckoutAction.setToolTipText(Messages.itemHistory_undoCO_tooltip);
    }

    private void createCheckoutAction() {
        final IWorkbenchPart part = this;
        checkoutAction = new Action() {
            @Override
            public void run() {

                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                ItemRevision item = itemHistory.getItemRevision();
                ItemRevision itemToCheckout = project.createItemRevisionFromSpec((String) item.getAttribute(SystemAttributes.OBJECT_SPEC));

                IResource[] resources = new IResource[] { local };
                HistoryCheckoutOperation operation = new HistoryCheckoutOperation(part, resources, itemToCheckout,
                        IDMProject.CHECKOUT_FILTER);
                try {
                    if (!operation.prompt()) {
                        throw new InterruptedException();
                    }
                    operation.run();
                    refresh();
                } catch (InvocationTargetException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                } catch (InterruptedException ignore) {
                }

            }
        };
        checkoutAction.setEnabled(true);
        checkoutAction.setText(Messages.itemHistory_action_checkout_label);
        checkoutAction.setToolTipText(Messages.itemHistory_action_checkout_tooltip);
    }

    private void createOpenAction() {
        openAction = new Action() {
            @Override
            public void run() {
                openFileInEditor();
            }
        };
        openAction.setEnabled(true);
        openAction.setText(Messages.itemHistory_action_open_label);
        openAction.setToolTipText(Messages.itemHistory_action_open_tooltip);
    }

    private void createBlameAction() {
        blameAction = new Action() {
            @Override
            public void run() {
                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                if (!selection.isEmpty()) {
                    ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                    final ItemRevision item = itemHistory.getItemRevision();
                    final IDMRemoteFile[] files = new IDMRemoteFile[1];
                    try {
                        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                            @Override
                            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                                monitor.beginTask(com.serena.eclipse.dimensions.internal.ui.Messages.blameAnnot_prefetch,
                                        IProgressMonitor.UNKNOWN);
                                try {
                                    IDMRemoteFile[] remoteFiles = TeamUtils.getVariants(conn, new ItemRevision[] { item, },
                                            Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
                                    if (remoteFiles != null && remoteFiles.length == 1 && remoteFiles[0] != null) {
                                        files[0] = remoteFiles[0];
                                        files[0].getStorage(Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN));
                                    }
                                } catch (CoreException e) {
                                    DMTeamUiPlugin.getDefault().handle(e);
                                } finally {
                                    monitor.done();
                                }
                            }
                        });

                        if (files[0] != null) {
                            files[0].setProject(dmProject);
                            BlameAnnotateRemoteOperation op = new BlameAnnotateRemoteOperation(files[0], UIUtils.getActivePage(),
                                    conn);
                            op.execute();
                        } else {
                            throw new DMException(new Status(IStatus.ERROR, DMTeamPlugin.ID,
                                    com.serena.eclipse.dimensions.internal.ui.Messages.blameAnnot_error));
                        }
                    } catch (InvocationTargetException e) {
                        DMTeamUiPlugin.getDefault().handle(e);
                    } catch (InterruptedException e) {
                        DMTeamUiPlugin.getDefault().handle(e);
                    } catch (CoreException e) {
                        DMTeamUiPlugin.getDefault().handle(e);
                    }
                }
            }
        };
        blameAction.setEnabled(true);
        blameAction.setText(Messages.itemHistory_action_blame_label);
        blameAction.setToolTipText(Messages.itemHistory_action_blame_tooltip);
    }

    private void createOpenPropertiesAction() {
        openPropertiesAction = new Action() {
            @Override
            public void run() {
                IDimensionsObjectEditHandler handler = null;
                handler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.ITEM);

                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                ItemRevision item = itemHistory.getItemRevision();

                ItemRevisionAdapter adapter = new ItemRevisionAdapter(item, conn);
                if (handler != null) {
                    try {
                        handler.openEditor(adapter);
                    } catch (CoreException e2) {
                        DMTeamUiPlugin.getDefault().handle(e2, tableViewer.getControl().getShell(), Messages.err_error,
                                Messages.err_openObjEditor);
                    }
                }
            }
        };
        openPropertiesAction.setEnabled(true);
        openPropertiesAction.setText(Messages.itemHistory_action_openProperties_label);
        openPropertiesAction.setToolTipText(Messages.itemHistory_action_openProperties_tooltip);
    }

    private void createCompareLocalAction() {
        compareLocalAction = new Action() {
            @Override
            public void run() {
                IDMWorkspace ws = DMTeamPlugin.getWorkspace();

                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                Iterator iterator = selection.iterator();
                ItemRevisionHistory itemHistory = (ItemRevisionHistory) iterator.next();
                ItemRevision remote = itemHistory.getItemRevision();
                try {
                    final IDMRemoteFile remoteFile = ws.getRemoteFile(local, remote);
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() { // comminicate busy
                                                                                                                 // status
                                @Override
                                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                                    try {
                                        cacheContents(remoteFile, null, monitor);
                                    } catch (TeamException e) {
                                        throw new InvocationTargetException(e);
                                    }
                                }
                            });
                    if (remoteFile != null) {
                        RemoteResourceTypedElement left = new RemoteResourceTypedElement(remoteFile);
                        LocalResourceTypedElement right = new LocalResourceTypedElement(local);
                        CompareUI.openCompareEditor(new DMCompareRevToLocalEditorInput(left, right));
                    } else {
                        throw new DMException(new Status(IStatus.WARNING, DMTeamPlugin.ID, NLS.bind(
                                Messages.DMLocalFileNotExist_warning, local.getName())));
                    }
                } catch (InterruptedException ignore) {
                } catch (Exception e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
            }
        };
        compareLocalAction.setEnabled(true);
        compareLocalAction.setText(Messages.itemHistory_action_compareLocal_label);
        compareLocalAction.setToolTipText(Messages.itemHistory_action_compareLocal_tooltip);
    }

    private void createCompareAction() {
        compareAction = new Action() {
            @Override
            public void run() {
                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                Iterator iterator = selection.iterator();
                final ItemRevisionHistory leftItemHistory = (ItemRevisionHistory) iterator.next();
                final ItemRevisionHistory rightItemHistory = (ItemRevisionHistory) iterator.next();
                final CompareEditorInput[] inputHolder = new CompareEditorInput[1];
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() { // Communicate busy
                                // status
                                @Override
                                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                                    try {
                                        IDimensionsObjectCompareHandler compareHandler = DMUIPlugin.getDefault().getCompareHandler(
                                                DMTypeScope.ITEM);
                                        inputHolder[0] = compareHandler.getCompareEditorInput(new ItemRevisionAdapter(
                                                leftItemHistory.getItemRevision(), conn),
                                                new ItemRevisionAdapter(rightItemHistory.getItemRevision(), conn), monitor);
                                    } catch (DMException e) {
                                        throw new InvocationTargetException(e);
                                    }
                                }
                            });
                    if (inputHolder[0] != null) {
                        CompareUI.openCompareEditor(inputHolder[0]);
                    }
                } catch (InterruptedException ignore) {
                } catch (Exception e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
            }
        };
        compareAction.setEnabled(true);
        compareAction.setText(Messages.itemHistory_action_compare_label);
        compareAction.setToolTipText(Messages.itemHistory_action_compare_tooltip);

    }

    // this will cache remote contents locally in the resource variant cache
    private void cacheContents(IDMRemoteFile v1, IDMRemoteFile v2, IProgressMonitor monitor) throws TeamException {
        TeamUtils.cacheContents(v1, v2, monitor);
        boolean expand = TeamUtils.isExpandSubstitution();
        if (v1 != null) {
            if (v1.isFetchedExpanded() == null || (expand && !v1.isFetchedExpanded().booleanValue())
                    || (!expand && v1.isFetchedExpanded().booleanValue())) {
                TeamUtils.fetchReplaceContents(v1, new ExpandMode[] { expand ? ExpandMode.EXPANDED : ExpandMode.UNEXPANDED },
                        Utils.subMonitorFor(monitor, 50));
            }
        }
        if (v2 != null) {
            if (v2.isFetchedExpanded() == null || (expand && !v2.isFetchedExpanded().booleanValue())
                    || (!expand && v2.isFetchedExpanded().booleanValue())) {
                TeamUtils.fetchReplaceContents(v2, new ExpandMode[] { expand ? ExpandMode.EXPANDED : ExpandMode.UNEXPANDED },
                        Utils.subMonitorFor(monitor, 50));
            }
        }
    }

    private void createActionAction() {
        actionAction = new Action() {
            @Override
            public void run() {
                IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
                ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                ItemRevision item = itemHistory.getItemRevision();

                ItemRevisionAdapter itemRevisionAdapters[] = new ItemRevisionAdapter[1];
                itemRevisionAdapters[0] = new ItemRevisionAdapter(item, conn);
                ActionWizard wizard = new ActionWizard(itemRevisionAdapters);
                WizardDialog dialog = new WizardDialog(tableViewer.getControl().getShell(), wizard);
                if (dialog.open() == Window.OK) {
                    refresh();
                }
            }
        };
        actionAction.setEnabled(true);
        actionAction.setText(Messages.itemHistory_action_action_label);
        actionAction.setToolTipText(Messages.itemHistory_action_action_tooltip);

    }

    private void createRefreshAction() {
        refreshAction = new Action() {
            @Override
            public void run() {
                refresh();
            }
        };
        refreshAction.setEnabled(true);
        refreshAction.setText(Messages.itemHistory_action_refresh_label);
        refreshAction.setToolTipText(Messages.itemHistory_action_refresh_tooltip);
        refreshAction.setImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.REFRESH));

    }

    private void createMergeAction() {
        mergeAction = new Action() {
            @Override
            public void run() {

            }
        };
        mergeAction.setEnabled(true);
        mergeAction.setText(Messages.itemHistory_action_merge_label);
        mergeAction.setToolTipText(Messages.itemHistory_action_merge_tooltip);
    }

    private class HistoryCheckoutOperation extends CheckoutOperation {
        private ItemRevision toCheckout;

        public HistoryCheckoutOperation(IWorkbenchPart part, IResource[] resources, ItemRevision toCheckout,
                IDMWorkspaceResourceFilter filter) {
            super(part, resources, filter);
            this.toCheckout = toCheckout;
        }

        @Override
        protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
            return new HistoryCheckoutHelper(getResources(), toCheckout, getFilter(), monitor);
        }

        @Override
        protected boolean canRunAsJob() {
            return false; // run the job synchronously.
        }
    }

    private class HistoryUndoCheckout extends UndoCheckoutOperation {
        private boolean undoLocal;
        private List otherCheckouts = Collections.EMPTY_LIST;
        private boolean doOthers;

        public HistoryUndoCheckout(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
            super(part, resources, filter);
        }

        void setUndoLocal(boolean undoLocal) {
            this.undoLocal = undoLocal;
        }

        void setOtherCheckouts(List otherCheckouts) {
            this.otherCheckouts = otherCheckouts;
        }

        @Override
        public boolean prompt() throws InvocationTargetException, InterruptedException {
            if (!otherCheckouts.isEmpty()) {
                String confirm = undoLocal
                        ? Messages.itemHistory_undoCO_undoOtherConfirm1 : Messages.itemHistory_undoCO_undoOtherConfirm2;
                doOthers = MessageDialog.openQuestion(getSite().getShell(), Messages.itemHistory_undoCO_confirmTitle,
                        NLS.bind(Messages.itemHistory_undoCO_undoOtherMsg, confirm));
            }
            if (undoLocal) {
                return super.prompt();
            }
            return doOthers;
        }

        @Override
        public void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
            if (undoLocal) {
                super.execute(monitor); // local + others
            } else {
                undoOtherCheckouts(monitor); // others only
            }
        }

        @Override
        protected void execute(OperationData data, IProgressMonitor monitor) throws InterruptedException {

            monitor = Utils.monitorFor(monitor);
            monitor.beginTask(Messages.itemHistory_undoCO_task, 10 + getOtherWorkUnits());

            try {
                // undo local
                try {
                    super.execute(data, Utils.subMonitorFor(monitor, 10));
                } catch (CoreException e) {
                    addError(e.getStatus());
                }

                // undo others
                if (!otherCheckouts.isEmpty() && doOthers) {
                    undoOtherCheckouts(Utils.subMonitorFor(monitor, getOtherWorkUnits()));
                }
            } finally {
                monitor.done();
            }
        }

        // cancel c/o for revisions not in the local wsp
        void undoOtherCheckouts(IProgressMonitor monitor) /* throws CoreException */{
            monitor = Utils.monitorFor(monitor);
            try {
                monitor.beginTask(null, getOtherWorkUnits());
                Session session = conn.openSession(Utils.subMonitorFor(monitor, 10));
                for (Iterator iterator = otherCheckouts.iterator(); iterator.hasNext();) {
                    ItemRevisionHistory irh = (ItemRevisionHistory) iterator.next();
                    final ItemRevision revToUCO = irh.getItemRevision();
                    try {
                        session.run(
                                new APIOperation(NLS.bind(Messages.itemHistory_undoCO_consoleMsg,
                                        String.valueOf(revToUCO.getAttribute(SystemAttributes.OBJECT_SPEC)))) {
                                    @Override
                                    protected DimensionsResult doRun() throws Exception {
                                        return revToUCO.undoCheckout(true, null);
                                    }
                                }, monitor);
                    } catch (DMException e) {
                        addError(e.getStatus());
                    }
                    monitor.worked(10);
                    Utils.checkCanceled(monitor);
                }
                if (local != null) {
                    DMTeamPlugin.getWorkspace()
                            .getSubscriber()
                            .refresh(new IResource[] { local }, IResource.DEPTH_INFINITE, Utils.subMonitorFor(monitor, 10));
                }
            } catch (CoreException e) {
                addError(e.getStatus());
            } finally {
                monitor.done();
            }
        }

        private int getOtherWorkUnits() {
            if (doOthers && !otherCheckouts.isEmpty()) {
                return 10 + (10 * otherCheckouts.size()) + 10;
            }
            return 0;
        }

        @Override
        protected boolean canRunAsJob() {
            return false; // block caller
        }

    }

    private class HistoryCheckoutHelper extends CheckoutHelper {
        private ItemRevision itemToCheckout;

        public HistoryCheckoutHelper(IResource[] initialResources, ItemRevision itemToCheckout, IDMWorkspaceResourceFilter filter,
                IProgressMonitor monitor) throws CoreException {
            super(initialResources, filter, monitor);
            this.itemToCheckout = itemToCheckout;
            initialize(monitor);
        }

        @Override
        protected ItemRevision getItemRevision(IDMWorkspaceFile dmFile) throws CoreException {
            return itemToCheckout;
        }

    }

    private boolean checkOverwrite() {
        boolean isModified = false;
        IResource resources[] = new IResource[] { local };
        IResource[] result = null;

        IPromptCondition condition = new IPromptCondition() {
            @Override
            public boolean needsPrompt(IResource resource) {

                return true;
            }

            @Override
            public String promptMessage(IResource resource) {
                return NLS.bind(Messages.locChangeOverwrite_prompt, resource.getFullPath().toString());
            }
        };

        try {
            isModified = DMTeamPlugin.getWorkspace().isModified(local);
            if (isModified) {
                PromptingDialog dialog = new PromptingDialog(tableViewer.getControl().getShell(), resources, condition,
                        Messages.confirm_overwrite, false, 0);
                result = dialog.promptForMultiple();
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);
            return false;
        } catch (InterruptedException e) {
            return false;
        }

        if (result == null || result.length == 1) {
            return true;
        }
        return false;
    }

    private class ItemHistoryDoubleClickListener implements IDoubleClickListener {

        @Override
        public void doubleClick(DoubleClickEvent event) {
            openFileInEditor();
        }

    }

    private void openFileInEditor() {
        IDimensionsObjectEditHandler itemHandler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.ITEM);
        if (itemHandler != null) {
            IStructuredSelection selection = (IStructuredSelection) tableViewer.getSelection();
            if (!selection.isEmpty()) {
                ItemRevisionHistory itemHistory = (ItemRevisionHistory) selection.getFirstElement();
                ItemRevision item = itemHistory.getItemRevision();
                ItemRevisionAdapter adapter = new ItemRevisionAdapter(item, conn);
                try {
                    itemHandler.browse(adapter);
                } catch (CoreException e1) {
                    DMTeamUiPlugin.getDefault().handle(e1, getSite().getShell());
                }
            }
        }
    }

    private void refresh() {
        ItemHistoryContentProvider contentProvider = getItemHistoryContentProvider();
        contentProvider.reset();
        tableViewer.refresh();
    }

    private ItemHistoryContentProvider getItemHistoryContentProvider() {
        if (tableViewer == null) {
            return null;
        }
        return (ItemHistoryContentProvider) tableViewer.getContentProvider();
    }

    private class ResourceStateListener implements IResourceStateChangeListener {

        @Override
        public void projectConfigured(IProject project) {
            // Nothing to do
        }

        @Override
        public void projectDeconfigured(IProject project) {
            // Nothing to do
        }

        @Override
        public void resourceStateChanged(IResource[] resources) {
            if (local == null) {
                return;
            }
            for (int i = 0; i < resources.length; i++) {
                if (resources[i].getType() == IResource.FILE) {
                    if (local.equals(resources[i])) {
                        try {
                            IDMRemoteFile res = (IDMRemoteFile) DMTeamPlugin.getWorkspace().getBaseResource(local);
                            cacheBaseState(res);
                        } catch (TeamException e) {
                            DMTeamUiPlugin.log(e.getStatus()); // just log and continue
                        }

                        Display.getDefault().asyncExec(new Runnable() {
                            @Override
                            public void run() {
                                tableViewer.refresh(true);
                            }
                        });
                    }
                }
            }
        }

        @Override
        public void resourceModified(IResource[] resources) {
            // Nothing to do
        }
        
        @Override
        public void workAreaRehomeDetected(List<IDMProject> projectsToRehome, WorksetAdapter targetProject) {
        }
    }

    @Override
    public void dispose() {
        DMTeamPlugin.getWorkspace().removeResourceStateChangeListener(stateListener);
        super.dispose();
    }

    private void cacheBaseState(IDMRemoteFile res) {
        baseRevision = res != null ? res.getRevision() : null;
        locallyCheckedout = res != null ? res.isExtracted() : false;
    }

    private class ItemHistoryLabelProvider extends LabelProvider implements ITableLabelProvider, IFontProvider {

        private Font italicFont = null;
        private Font defaultFont = null;
        private Table table;

        ItemHistoryLabelProvider(Table table) {
            this.table = table;
        }

        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            // no image
            return null;

        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            ItemRevisionHistory historyRec = (ItemRevisionHistory) element;
            String columnText = Utils.EMPTY_STRING;
            switch (columnIndex) {
            case DimensionsItemHistoryView.COL_NEW_REV:
                String thisRevision = historyRec.getNewRevision();
                if (thisRevision != null && thisRevision.equals(baseRevision)) {
                    columnText = Messages.ItemHistoryLabelProvider_currentRevMarker;
                }
                columnText += thisRevision;
                break;
            case DimensionsItemHistoryView.COL_PREV_REV:
                columnText += historyRec.getPreviousRevision();
                break;
            case DimensionsItemHistoryView.COL_STATUS:
                columnText += historyRec.getStatus();
                break;
            case DimensionsItemHistoryView.COL_DATETIME:
                columnText += historyRec.getHistoryDate();
                break;
            case DimensionsItemHistoryView.COL_USER:
                columnText += historyRec.getAuthor();
                break;
            case DimensionsItemHistoryView.COL_DESC:
                columnText += historyRec.getDescription() == null ? "" : historyRec.getDescription(); //$NON-NLS-1$
                break;
            default:
                break;
            }
            return columnText;
        }

        @Override
        public void dispose() {
            if (italicFont != null) {
                italicFont.dispose();
            }
            super.dispose();
        }

        @Override
        public Font getFont(Object element) {
            if (italicFont == null) {
                defaultFont = table.getFont();
                FontData[] data = defaultFont.getFontData();
                for (int i = 0; i < data.length; i++) {
                    data[i].setStyle(SWT.ITALIC);
                }
                italicFont = new Font(table.getDisplay(), data);
            }
            ItemRevisionHistory historyRec = (ItemRevisionHistory) element;
            if (historyRec.getIsInCurrentProject()) {
                return defaultFont;
            }
            return italicFont;
        }
    }

    private class ItemHistoryContentProvider implements IStructuredContentProvider, ISessionListener/* , ISimpleListener */{
        private boolean disposed = false;
        private FetchItemHistoryJob historyJob;
        private ItemRevisionHistory[] history;

        public ItemHistoryContentProvider() {
            DimensionsConnectionDetailsEx.addSessionListener(this);
        }

        // job to fetch history in the background
        private class FetchItemHistoryJob extends Job {
            public FetchItemHistoryJob() {
                super(Messages.ItemHistoryContentProvider_0);
            }

            @Override
            public IStatus run(final IProgressMonitor monitor) {
                try {
                    monitor.beginTask(Messages.ItemHistoryContentProvider_2, 100);
                    if (!disposed) {
                        final Session s = conn.openSession(null);
                        s.run(new ISessionRunnable() {
                            @Override
                            public void run() throws Exception {
                                history = fetchHistory(s,
                                        Utils.subMonitorFor(monitor, 90, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK));
                            }
                        }, monitor);
                        Shell shell = getShell();
                        if (shell != null) {
                            shell.getDisplay().asyncExec(new Runnable() {
                                @Override
                                public void run() {
                                    if (history != null && tableViewer != null && !tableViewer.getTable().isDisposed()) {
                                        tableViewer.add(history);
                                        String revisionForSelection = getRevisionForSelection();
                                        if (revisionForSelection == null) {
                                            if (getRevision() != null
                                                    && getRevision().getAttribute(SystemAttributes.REVISION) != null) {
                                                revisionForSelection = (String) getRevision().getAttribute(
                                                        SystemAttributes.REVISION); // the revision used to retrieve history
                                            }
                                        }

                                        if (revisionForSelection != null) {
                                            ArrayList<ItemRevisionHistory> selList = new ArrayList<ItemRevisionHistory>();
                                            for (int i = 0; i < history.length; i++) {
                                                if (revisionForSelection.equals(history[i].getNewRevision())) {
                                                    selList.add(history[i]);
                                                }
                                            }
                                            if (!selList.isEmpty()) {
                                                tableViewer.setSelection(new StructuredSelection(selList), true);
                                            }
                                        }
                                        resetRevisionForSelection();
                                    }
                                }
                            });
                        }
                    }
                    return Status.OK_STATUS;
                } catch (DMException e) {
                    return e.getStatus();
                } finally {
                    monitor.done();
                }
            }
        }

        @Override
        public Object[] getElements(Object inputElement) {
            if (history != null) {
                return history;
            }
            if (historyJob == null) {
                historyJob = new FetchItemHistoryJob();
            }
            if (historyJob.getState() != Job.NONE) {
                historyJob.cancel();
                try {
                    historyJob.join();
                } catch (InterruptedException e) {
                    DMTeamUiPlugin.log(DMTeamStatus.createErrorStatus(0, Messages.ItemHistoryContentProvider_1));
                }
            }
            boolean scheduled = false;
            if (getSite() != null) {
                IWorkbenchSiteProgressService siteProgress = (IWorkbenchSiteProgressService) getSite().getAdapter(
                        IWorkbenchSiteProgressService.class);
                if (siteProgress != null) {
                    siteProgress.schedule(historyJob, 0, true /* use half-busy cursor */);
                    scheduled = true;
                }
            }
            if (!scheduled) {
                historyJob.schedule();
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        public void reset() {
            history = null;
        }

        // Receive a disconnect notification - remove all history entries
        public void disconected() {
            history = new ItemRevisionHistory[0];
            contentsChanged();
        }

        @Override
        public void dispose() {
            disposed = true;
            DimensionsConnectionDetailsEx.removeSessionListener(this);
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
            reset();
        }

        // refreshes the viewer
        private void contentsChanged() {
            if (tableViewer != null) {
                getShell().getDisplay().asyncExec(new Runnable() {
                    @Override
                    public void run() {
                        tableViewer.refresh();
                    }
                });
            }
        }

        private ItemRevisionHistory[] fetchHistory(Session s, IProgressMonitor monitor) throws CoreException {
            monitor = Utils.monitorFor(monitor);
            monitor.beginTask(null, 5);
            try {
                cacheObjects(Utils.subMonitorFor(monitor, 1)); // ensure have project and revision objects

                if (getRevision() == null) {
                    return new ItemRevisionHistory[0];
                }

                if (!detailsSet) { // fetch view details if not already set
                    ItemRevision rev = getRevision();
                    int[] attrs = new int[] { SystemAttributes.ITEMFILE_FILENAME, SystemAttributes.FULL_PATH_NAME };
                    Utils.queryAttributes(Collections.singletonList(rev), attrs, s.getObjectFactory(), true);
                    final String itemName = (String) rev.getAttribute(SystemAttributes.ITEMFILE_FILENAME);
                    final String fullItemName = (String) rev.getAttribute(SystemAttributes.FULL_PATH_NAME);
                    getSite().getShell().getDisplay().asyncExec(new Runnable() {
                        @Override
                        public void run() {
                            setDetails(itemName, fullItemName);
                        }
                    });
                }
                monitor.worked(1);

                monitor.subTask(Messages.ItemHistoryContentProvider_3);
                List historyList = getRevision().getRevisionHistory(true);
                monitor.worked(1); // 1 worked
                int attrs[] = new int[14];
                attrs[0] = SystemAttributes.OBJECT_ID;
                attrs[1] = SystemAttributes.VARIANT;
                attrs[2] = SystemAttributes.PRODUCT_NAME;
                attrs[3] = SystemAttributes.ITEMFILE_DIR;
                attrs[4] = SystemAttributes.ITEMFILE_FILENAME;
                attrs[5] = SystemAttributes.TYPE_NAME;
                attrs[6] = SystemAttributes.REVISION;
                attrs[7] = SystemAttributes.UTC_MODIFIED_DATE;
                attrs[8] = SystemAttributes.CREATION_USER;
                attrs[9] = SystemAttributes.STATUS;
                attrs[10] = SystemAttributes.IS_EXTRACTED;
                attrs[11] = SystemAttributes.OBJECT_SPEC;
                attrs[12] = SystemAttributes.FULL_PATH_NAME;
                attrs[13] = SystemAttributes.OBJECT_SPEC_UID;

                List newHistoryList1 = new ArrayList();
                for (int i = 0; i < historyList.size(); i++) {
                    ItemRevision item = ((ItemRevisionHistoryRec) historyList.get(i)).getNewItemRevision();
                    boolean found = false;
                    for (int j = 0; j < newHistoryList1.size(); j++) {
                        ItemRevision oldItem = (ItemRevision) newHistoryList1.get(j);
                        if (oldItem.equals(item)) {
                            found = true;
                        }

                    }
                    if (!found) {
                        newHistoryList1.add(item);
                    }
                }

                if (monitor.isCanceled() || newHistoryList1.size() == 0) {
                    return new ItemRevisionHistory[0];
                }

                monitor.subTask(Messages.ItemHistoryContentProvider_4);
                BulkOperator bulk = s.getObjectFactory().getBulkOperator(newHistoryList1);
                bulk.queryAttribute(attrs);
                monitor.worked(1); // 2 worked

                Filter filter = new Filter();
                Long spec_uid = (Long) ((ItemRevision) newHistoryList1.get(0)).getAttribute(SystemAttributes.OBJECT_SPEC_UID);
                filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC_UID, spec_uid, Filter.Criterion.EQUALS));

                if (monitor.isCanceled()) {
                    return new ItemRevisionHistory[0];
                }

                HashMap revisionsInCurrentProject = new HashMap();
                monitor.subTask(Messages.ItemHistoryContentProvider_5);
                project.flushRelatedObjects(ItemRevision.class, true);
                List currentProjectItems = project.getChildItems(filter);
                project.flushRelatedObjects(ItemRevision.class, true);

                // query for the same attrs - BO can operated on related objects
                bulk = s.getObjectFactory().getBulkOperator(currentProjectItems);

                bulk.queryAttribute(attrs);
                monitor.worked(1); // 3 worked
                for (int i = 0; i < currentProjectItems.size(); i++) {
                    ItemRevision item = (ItemRevision) ((DimensionsRelatedObject) currentProjectItems.get(i)).getObject();
                    revisionsInCurrentProject.put(item.getAttribute(SystemAttributes.REVISION), item);
                }

                List newHistoryList = new ArrayList();
                for (int i = 0; i < historyList.size(); i++) {
                    ItemRevision emptyItem = ((ItemRevisionHistoryRec) historyList.get(i)).getNewItemRevision(); // item attributes
                    ItemRevision filledItem = null; // item with attributes
                    for (int j = 0; j < newHistoryList1.size(); j++) {
                        ItemRevision oldRevision = (ItemRevision) newHistoryList1.get(j);
                        if (oldRevision.equals(emptyItem)) {
                            filledItem = oldRevision;
                        }
                    }
                    String itemRevision = (String) filledItem.getAttribute(SystemAttributes.REVISION);
                    boolean isInCurrentProject = false;
                    if (revisionsInCurrentProject.containsKey(itemRevision)) {
                        isInCurrentProject = true;

                        // this will insure fetch is done within proper project
                        filledItem = (ItemRevision) revisionsInCurrentProject.get(itemRevision);
                    }

                    ItemRevisionHistoryRec record = (ItemRevisionHistoryRec) historyList.get(i);
                    ItemRevisionHistory hist = new ItemRevisionHistory(record, filledItem, isInCurrentProject);
                    newHistoryList.add(hist);
                }
                return (ItemRevisionHistory[]) newHistoryList.toArray(new ItemRevisionHistory[newHistoryList.size()]);
            } finally {
                monitor.done();
            }
        }

        private Shell getShell() {
            if (getSite() != null) {
                return getSite().getShell();
            }
            return null;
        }

        @Override
        public void sessionCreated(DimensionsConnectionDetailsEx loc) {
            // do nothing
        }

        @Override
        public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
            if (!loc.equals(conn)) {
                return; // don't care about other connections
            }
            disconected();
            disconnected();
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;

import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;

public class XMLUserActionFilters {

    /**
     * Filter that excludes all infos that have IGNORE resolution
     */
    public static class IgnoreFilter extends FastSyncInfoFilter {
        public static final IgnoreFilter INSTANCE = new IgnoreFilter();

        private IgnoreFilter() {
        }

        @Override
        public boolean select(SyncInfo info) {
            if (XMLSyncInfoFilter.INSTANCE.select(info)) {
                return ((XMLSyncInfo) info).getCurrentActionLabel() != XSyncUserAction.SUAL_IGNORE;
            }
            return false;
        }

    }

    /**
     * Filter that removes all infos that have STALE status
     */
    public static class StaleFilter extends FastSyncInfoFilter {
        public static final StaleFilter INSTANCE = new StaleFilter();

        private StaleFilter() {
        }

        @Override
        public boolean select(SyncInfo info) {
            if (XMLSyncInfoFilter.INSTANCE.select(info)) {
                return !((XMLSyncInfo) info).isStale();
            }
            return false;
        }

    }

    /**
     * Filter that accepts only DMXMLSyncInfo instances
     */
    public static class XMLSyncInfoFilter extends FastSyncInfoFilter {
        public static final XMLSyncInfoFilter INSTANCE = new XMLSyncInfoFilter();

        private XMLSyncInfoFilter() {
        }

        @Override
        public boolean select(SyncInfo info) {
            return info instanceof XMLSyncInfo;
        }

    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.controls;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.SccProjectList;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.GenericPropertySource;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Allows to find/browse for workset or baseline. Optionally supports
 * null selection.
 *
 * @author V.Grishchenko
 */
public class ProjectSelectionPanel extends GenericPropertySource {
    /** selection property name */
    public static final String SELECTION = "selection"; //$NON-NLS-1$
    /** selection mode property name */
    public static final String SELECTION_MODE = "selection_mode"; //$NON-NLS-1$

    public static final String USE_NONE = "use_none"; //$NON-NLS-1$
    public static final String FIND = "find"; //$NON-NLS-1$
    public static final String BROWSE = "browse"; //$NON-NLS-1$

    public static final int SHOW_NULL_SELECTION = 1;

    public static final int WORKSET = 1;
    public static final int BASELINE = 2;
    public static final int MULTIPLE = 4;
    public static final int THREE_WAY_MERGE_MODE = 8;

    private int mode;
    private VersionManagementProject[] selection;
    private Composite panel;

    private Button nullSelectionBtn;
    private Button findBtn;
    private Button browseBtn;
    private Button launchFindBtn;
    private Combo findModeSelectorCmb;
    private Combo offsetCmb;
    private Text findResultTxt;
    private Label idLbl;
    private Label offsetLbl;

    private ProjectBrowsePanel worksetSelectionPanel;
    private DimensionsConnectionDetailsEx connection;
    private String selectionMode = USE_NONE;
    private IPath[] defaultOffset = new IPath[0];
    private SccProjectList projectList;

    private int options;

    private boolean showOnlyStreams;// Show only Streams in the list
    private boolean showOnlyProjects;// Show only Projects in the list

    private String targetProduct;

    /**
     * Creates a panel with layout options.
     *
     * @param mode <code>WORKSET</code> or <code>BASELINE</code>
     * @param parent
     * @param style
     * @param msg
     * @param options <code>SHOW_NULL_SELECTION</code> or 0
     * @param nullSelectionText
     * @param showOnlyStreams - Show only Streams
     * @param showOnlyProjects - Show only Projects
     */
    public ProjectSelectionPanel(int mode, Composite parent, int style, String msg, int options, String nullSelectionText,
            boolean showOnlyStreams, boolean showOnlyProjects) {
        this.mode = mode;
        this.options = options;
        this.showOnlyProjects = showOnlyProjects;
        this.showOnlyStreams = showOnlyStreams;
        createControl(parent, style, msg, nullSelectionText);
    }

    /**
     * Creates a panel with null selection button.
     *
     * @param mode <code>WORKSET</code> or <code>BASELINE</code>
     * @param parent
     * @param style
     * @param msg
     * @param nullSelectionText
     * @param showOnlyStreams - Show only Streams
     * @param showOnlyProjects - Show only Projects
     */
    public ProjectSelectionPanel(int mode, Composite parent, int style, String msg, String nullSelectionText,
            boolean showOnlyStreams, boolean showOnlyProjects) {
        this(mode, parent, style, msg, SHOW_NULL_SELECTION, nullSelectionText, showOnlyStreams, showOnlyProjects);
    }

    public void setMode(int mode) {
        Assert.isLegal((mode & WORKSET) == WORKSET || (mode & BASELINE) == BASELINE || (mode & MULTIPLE) == MULTIPLE);
        this.mode = mode;
    }

    public VersionManagementProject[] getSelection() {
        return selection;
    }

    /**
     * @return Returns the panel.
     */
    public Composite getPanel() {
        return panel;
    }

    /**
     * @return <code>true</code> if null selection button is selected
     */
    public boolean isNullSelection() {
        return nullSelectionBtn.getSelection();
    }

    public void setConnection(DimensionsConnectionDetailsEx connection) {
        this.connection = connection;
        worksetSelectionPanel.setConnection(connection, showOnlyStreams, showOnlyProjects);
    }

    /**
     * @param defaultOffset The defaultOffset to set.
     */
    public void setDefaultOffset(IPath[] defaultOffset) {
        this.defaultOffset = defaultOffset == null ? new IPath[0] : defaultOffset;
    }

    private void createControl(Composite parent, int style, String msg, String nullSelectionText) {
        panel = new Composite(parent, style);
        UIUtils.setGridLayout(panel, 3);

        if (msg != null) {
            Label msgLabel = UIUtils.createLabel(panel, msg);
            UIUtils.setGridData(msgLabel, GridData.FILL_HORIZONTAL, 3);
            Label spacer = UIUtils.createLabel(panel, null);
            UIUtils.setGridData(spacer, GridData.FILL_HORIZONTAL, 3);
        }

        if ((options & SHOW_NULL_SELECTION) == SHOW_NULL_SELECTION) {
            nullSelectionBtn = new Button(panel, SWT.RADIO);
            nullSelectionBtn.setText(nullSelectionText == null ? Messages.ProjectSelectionPanel_defaultNullText : nullSelectionText);
            UIUtils.createLabel(panel, null);
            UIUtils.createLabel(panel, null);
        }

        if ((mode & THREE_WAY_MERGE_MODE) == THREE_WAY_MERGE_MODE) {
            createSimpleFindControls();
        } else {
            createAdvancedFindControls();
        }

        browseBtn = new Button(panel, SWT.RADIO);
        browseBtn.setText(Messages.ProjectSelectionPanel_browse);
        UIUtils.createLabel(panel, null);
        UIUtils.createLabel(panel, null);

        int browsePanelOptions = 0;
        int sccProjects = 0;
        int strict = 0;
        int merge = 0;

        if ((mode & THREE_WAY_MERGE_MODE) == 0) {
            sccProjects = isMultipleMode() ? 0 : ProjectBrowsePanel.SHOW_SCC_PROJECTS;
            strict = isMultipleMode() ? 0 : ProjectBrowsePanel.STRICT_MODE;
        } else {
            merge = ProjectBrowsePanel.THREE_WAY_MERGE;
        }

        if (isWorksetMode()) {
            browsePanelOptions = ProjectBrowsePanel.SHOW_WORKSETS | ProjectBrowsePanel.SHOW_GROUPS
                    | ProjectBrowsePanel.SHOW_SCC_PROJECT_CONTAINERS | ProjectBrowsePanel.SHOW_SINGLE_ECLIPSE_PROJECTS | strict
                    | sccProjects | merge;
        } else if (isBaselineMode()) {
            browsePanelOptions = ProjectBrowsePanel.SHOW_BASELINES | ProjectBrowsePanel.SHOW_GROUPS
                    | ProjectBrowsePanel.SHOW_SCC_PROJECT_CONTAINERS | ProjectBrowsePanel.SHOW_SINGLE_ECLIPSE_PROJECTS | strict
                    | sccProjects | merge;
        } else if (isBothMode()) {
            browsePanelOptions = ProjectBrowsePanel.SHOW_WORKSETS | ProjectBrowsePanel.SHOW_BASELINES
                    | ProjectBrowsePanel.SHOW_GROUPS | ProjectBrowsePanel.SHOW_SCC_PROJECT_CONTAINERS
                    | ProjectBrowsePanel.SHOW_SINGLE_ECLIPSE_PROJECTS | strict | sccProjects | merge;
        } else {
            browsePanelOptions = ProjectBrowsePanel.SHOW_ALL | ProjectBrowsePanel.STRICT_MODE;
        }

        worksetSelectionPanel = new ProjectBrowsePanel(panel, SWT.SINGLE, browsePanelOptions);
        UIUtils.setGridData(worksetSelectionPanel.getPanel(), GridData.FILL_BOTH, 3);

        worksetSelectionPanel.setSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                VersionManagementProject[] newSelection = null;
                if (!event.getSelection().isEmpty() && event.getSelection() instanceof IStructuredSelection) {
                    Object o = ((IStructuredSelection) event.getSelection()).getFirstElement();
                    if (o instanceof VersionManagementProject) {
                        newSelection = new VersionManagementProject[1];
                        newSelection[0] = (VersionManagementProject) o;
                    }
                }
                if (isMultipleMode() && newSelection != null && newSelection[0] instanceof SccProjectContainerWorkset
                        && (mode & THREE_WAY_MERGE_MODE) == 0) {
                    newSelection = processBrowseResult(newSelection[0]);
                }

                setSelection(newSelection);
            }
        });

        Listener l = new Listener() {
            @Override
            public void handleEvent(Event e) {
                if (e.type != SWT.Selection) {
                    return;
                }
                if (e.widget == nullSelectionBtn && nullSelectionBtn.getSelection()) {
                    setSelectionMode(USE_NONE);
                }
                if (e.widget == findBtn && findBtn.getSelection()) {
                    setSelectionMode(FIND);
                }
                if (e.widget == browseBtn && browseBtn.getSelection()) {
                    setSelectionMode(BROWSE);
                }
                if (e.widget == launchFindBtn) {
                    launchFindWizard();
                }
            }
        };

        // calling setSelection will not fire selection events so must update mode explicitly
        if (nullSelectionBtn != null) {
            nullSelectionBtn.setSelection(true);
            setSelectionMode(USE_NONE);
            nullSelectionBtn.addListener(SWT.Selection, l);
        } else {
            findBtn.setSelection(true);
            setSelectionMode(FIND);
        }
        findBtn.addListener(SWT.Selection, l);
        launchFindBtn.addListener(SWT.Selection, l);
        browseBtn.addListener(SWT.Selection, l);
    }

    private void createAdvancedFindControls() {
        findBtn = new Button(panel, SWT.RADIO);
        findBtn.setText(Messages.ProjectSelectionPanel_find);
        UIUtils.createLabel(panel, null);
        UIUtils.createLabel(panel, null);

        Composite findResultHolder = new Composite(panel, SWT.NONE);
        UIUtils.setGridData(findResultHolder, GridData.FILL_HORIZONTAL, 2);
        GridLayout gridLayout = UIUtils.setGridLayout(findResultHolder, 3);
        gridLayout.marginHeight = 0;
        gridLayout.marginWidth = 20;

        if (isBothMode()) {
            findModeSelectorCmb = new Combo(findResultHolder, SWT.DROP_DOWN | SWT.READ_ONLY);
            findModeSelectorCmb.setItems(new String[] {
                    showOnlyStreams ? Messages.ProjectSelectionPanel_stream : DMTypeScope.PROJECT.getDisplayText(),
                    DMTypeScope.BASELINE.getDisplayText() });
            findModeSelectorCmb.select(0);
        }

        idLbl = UIUtils.createLabel(findResultHolder, Messages.ProjectSelectionPanel_idLabelTxt);
        findResultTxt = new Text(findResultHolder, SWT.BORDER | SWT.READ_ONLY);
        UIUtils.setGridData(findResultTxt, GridData.FILL_HORIZONTAL, isBothMode() ? 1 : 2);

        offsetLbl = UIUtils.createLabel(findResultHolder, Messages.ProjectSelectionPanel_containedProject);
        UIUtils.setGridData(offsetLbl, 0, isBothMode() ? 2 : 1);
        offsetCmb = new Combo(findResultHolder, SWT.DROP_DOWN | SWT.READ_ONLY);
        UIUtils.setGridData(offsetCmb, GridData.FILL_HORIZONTAL, isBothMode() ? 1 : 2);

        offsetCmb.addSelectionListener(new SelectionAdapter() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                offsetSelectionChanged();
            }
        });

        launchFindBtn = new Button(panel, SWT.PUSH);
        launchFindBtn.setText(Messages.ProjectSelectionPanel_launchFind);
        UIUtils.setGridData(launchFindBtn, GridData.VERTICAL_ALIGN_BEGINNING);
    }

    private void createSimpleFindControls() {
        findBtn = new Button(panel, SWT.RADIO);
        findBtn.setText(Messages.ProjectSelectionPanel_find);

        findResultTxt = new Text(panel, SWT.BORDER | SWT.READ_ONLY);
        UIUtils.setGridData(findResultTxt, GridData.FILL_HORIZONTAL);

        launchFindBtn = new Button(panel, SWT.PUSH);
        launchFindBtn.setText("  ...  ");//$NON-NLS-1$
        UIUtils.setGridData(launchFindBtn, GridData.VERTICAL_ALIGN_BEGINNING);
    }

    private void launchFindWizard() {
        int wizardType = (getFindMode() == WORKSET) ? IDMConstants.PROJECT : IDMConstants.BASELINE;
        FindObjectWizardDialog dialog = new FindObjectWizardDialog(panel.getShell(), wizardType, connection, getDefaultProduct(),
                true, false, showOnlyStreams, showOnlyProjects, (mode & THREE_WAY_MERGE_MODE) != 0, false);
        if (dialog.open() == Window.OK) {
            final List<String> list = dialog.getSelectedNames();
            if (!list.isEmpty()) {
                BusyIndicator.showWhile(panel.getDisplay(), new Runnable() {
                    @Override
                    public void run() {
                        processFindResult(list.get(0));
                    }
                });
            }
        }
    }

    private void processFindResult(final String id) {
        try {
            final Session session = connection.openSession(null);
            session.run(new ISessionRunnable() {
                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    VersionManagementProject[] newSelection = null;
                    SccProjectList sccProjectList = null;
                    if (getFindMode() == WORKSET) {
                        Project workset = session.getObjectFactory().getProject(id);
                        newSelection = new VersionManagementProject[1];
                        newSelection[0] = new WorksetAdapter(workset, connection);
                        sccProjectList = new SccProjectList(new SccProjectContainerWorkset(workset, connection));
                    } else {
                        Filter filter = new Filter();
                        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, id, Filter.Criterion.EQUALS));
                        List<Baseline> baselines = session.getObjectFactory().getBaselines(filter);
                        if (!baselines.isEmpty()) {
                            Baseline baseline = baselines.get(0);
                            newSelection = new VersionManagementProject[1];
                            newSelection[0] = new BaselineAdapter(baseline, connection);
                            sccProjectList = new SccProjectList(new SccBaselineContainer(baseline, connection));
                        }
                    }

                    String text = Utils.EMPTY_STRING;
                    if (newSelection != null) {
                        text = id;
                        sccProjectList.fetch(null);
                        if (!sccProjectList.isEmpty()) {
                            ProjectSelectionPanel.this.projectList = sccProjectList;
                            VersionManagementProject[] selections = populateOffsetCombo();
                            if ((mode & THREE_WAY_MERGE_MODE) == 0) {
                                newSelection = selections;
                            }
                        } else if (offsetCmb != null) {
                            offsetCmb.setItems(Utils.ZERO_LENGTH_STRING_ARRAY);
                        }
                    }
                    findResultTxt.setText(text);
                    setSelection(newSelection);
                }
            }, new NullProgressMonitor());
        } catch (DMException e) {
            findResultTxt.setText(Utils.EMPTY_STRING);
            setSelection(null);
            DMTeamUiPlugin.getDefault().handle(e);
        }
    }

    private VersionManagementProject[] populateOffsetCombo() {
        VersionManagementProject[] toRet = null;
        APIObjectAdapter[] sccProjects = projectList.getObjects();
        int dfltIdx = -1;
        List<String> items = new ArrayList<String>();

        if (!isMultipleMode()) {
            items.add(Messages.ProjectSelectionPanel_useContainer);
            for (int i = 1; i <= sccProjects.length; i++) {
                SccProject sccProject = ((SccProject) sccProjects[i - 1]);
                items.add(sccProject.getOffset());
                if (!defaultOffset[0].isEmpty()
                        && defaultOffset[0].matchingFirstSegments(new Path(sccProject.getOffset())) == defaultOffset[0].segmentCount()) {
                    dfltIdx = i;
                }
            }
        } else {
            // multiple mode
            items.add(Messages.ProjectSelectionPanel_useContained);
            List<VersionManagementProject> projs = new ArrayList<VersionManagementProject>();
            for (int i = 0; i < sccProjects.length; i++) {
                SccProject sccProject = ((SccProject) sccProjects[i]);
                for (int dof = 0; dof < defaultOffset.length; dof++) {
                    if (!defaultOffset[dof].isEmpty()
                            && defaultOffset[dof].matchingFirstSegments(new Path(sccProject.getOffset())) == defaultOffset[dof].segmentCount()) {
                        projs.add(sccProject);
                    }
                }

            }
            dfltIdx = 0;
            toRet = projs.toArray(new VersionManagementProject[projs.size()]);

        }

        String[] itemsArr = items.toArray(new String[items.size()]);
        if (offsetCmb != null) {
            offsetCmb.setItems(itemsArr);
        }

        if (dfltIdx == 0) {
            // multiple
            if (offsetCmb != null) {
                offsetCmb.select(dfltIdx);
            }
            return toRet;
        } else if (dfltIdx == -1) {
            if (offsetCmb != null) {
                offsetCmb.deselectAll();
                offsetCmb.clearSelection();
            }
            toRet = new VersionManagementProject[1];
            toRet[0] = (VersionManagementProject) projectList.getContainer();
            return toRet;
        } else {
            if (offsetCmb != null) {
                offsetCmb.select(dfltIdx);
            }
            toRet = new VersionManagementProject[1];
            toRet[0] = (VersionManagementProject) sccProjects[dfltIdx - 1];
            return toRet;
        }
    }

    private void offsetSelectionChanged() {
        int idx = offsetCmb.getSelectionIndex();
        if (idx == -1) {
            return;
        }
        VersionManagementProject[] newSelection = new VersionManagementProject[1];
        if (idx == 0) {
            newSelection[0] = (VersionManagementProject) projectList.getContainer();
            if (offsetCmb != null) {
                offsetCmb.deselectAll();
                offsetCmb.clearSelection();
            }
        } else {
            newSelection[0] = (VersionManagementProject) projectList.getObjects()[idx - 1];
        }
        setSelection(newSelection);
    }

    private VersionManagementProject[] processBrowseResult(final VersionManagementProject selectedContainer) {
        final VersionManagementProject[][] toRetHolder = new VersionManagementProject[1][];
        try {
            final Session session = connection.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    VersionManagementProject[] newSelection = null;
                    SccProjectList sccProjectList = null;
                    if (selectedContainer instanceof SccProjectContainerWorkset) {
                        Project workset = (Project) selectedContainer.getAPIObject();
                        newSelection = new VersionManagementProject[1];
                        newSelection[0] = new WorksetAdapter(workset, connection);
                        toRetHolder[0] = newSelection;
                        sccProjectList = new SccProjectList(new SccProjectContainerWorkset(workset, connection));
                    } else if (selectedContainer instanceof SccBaselineContainer) {

                        Baseline baseline = (Baseline) selectedContainer.getAPIObject();
                        newSelection = new VersionManagementProject[1];
                        newSelection[0] = new BaselineAdapter(baseline, connection);
                        toRetHolder[0] = newSelection;
                        sccProjectList = new SccProjectList(new SccBaselineContainer(baseline, connection));

                    }

                    if (newSelection != null) {
                        sccProjectList.fetch(null);
                        if (!sccProjectList.isEmpty()) {
                            ProjectSelectionPanel.this.projectList = sccProjectList;
                            APIObjectAdapter[] sccProjects = projectList.getObjects();
                            List<VersionManagementProject> projs = new ArrayList<VersionManagementProject>();
                            for (int i = 0; i < sccProjects.length; i++) {
                                SccProject sccProject = ((SccProject) sccProjects[i]);
                                for (int dof = 0; dof < defaultOffset.length; dof++) {
                                    if (!defaultOffset[dof].isEmpty()
                                            && defaultOffset[dof].matchingFirstSegments(new Path(sccProject.getOffset())) == defaultOffset[dof].segmentCount()) {
                                        projs.add(sccProject);
                                    }
                                }
                            }
                            toRetHolder[0] = projs.toArray(new VersionManagementProject[projs.size()]);
                        }
                    }
                }
            }, new NullProgressMonitor());
        } catch (DMException e) {
            findResultTxt.setText(Utils.EMPTY_STRING);
            setSelection(null);
            DMTeamUiPlugin.getDefault().handle(e);
        }
        return toRetHolder[0];
    }

    private void setSelection(VersionManagementProject[] newSelection) {
        VersionManagementProject[] oldSelection = selection;
        this.selection = newSelection;
        firePropertyChange(SELECTION, oldSelection, selection);
    }

    private void setSelectionMode(String newMode) {
        handleNewSelectionMode(newMode);
        String oldMode = selectionMode;
        this.selectionMode = newMode;
        firePropertyChange(SELECTION_MODE, oldMode, newMode);
    }

    private void handleNewSelectionMode(String newMode) {
        VersionManagementProject[] newSelection = new VersionManagementProject[1];
        if (USE_NONE.equals(newMode)) {
            if (findModeSelectorCmb != null) {
                findModeSelectorCmb.setEnabled(false);
            }
            findResultTxt.setText(Utils.EMPTY_STRING);

            if (offsetCmb != null) {
                offsetCmb.deselectAll();
                offsetCmb.clearSelection();
                offsetCmb.setItems(Utils.ZERO_LENGTH_STRING_ARRAY);
                offsetCmb.setEnabled(false);
            }

            if (offsetLbl != null) {
                offsetLbl.setEnabled(false);
            }

            if (idLbl != null) {
                idLbl.setEnabled(false);
            }

            launchFindBtn.setEnabled(false);
            worksetSelectionPanel.setEnabled(false);
        } else if (FIND.equals(newMode)) {
            if (findModeSelectorCmb != null) {
                findModeSelectorCmb.setEnabled(true);
            }

            if (offsetCmb != null) {
                offsetCmb.setEnabled(true);
            }

            if (offsetLbl != null) {
                offsetLbl.setEnabled(true);
            }

            if (idLbl != null) {
                idLbl.setEnabled(true);
            }

            launchFindBtn.setEnabled(true);
            worksetSelectionPanel.setEnabled(false);
        } else if (BROWSE.equals(newMode)) {
            if (findModeSelectorCmb != null) {
                findModeSelectorCmb.setEnabled(false);
            }
            findResultTxt.setText(Utils.EMPTY_STRING);

            if (offsetCmb != null) {
                offsetCmb.deselectAll();
                offsetCmb.clearSelection();
                offsetCmb.setItems(Utils.ZERO_LENGTH_STRING_ARRAY);
                offsetCmb.setEnabled(false);
            }

            if (idLbl != null) {
                idLbl.setEnabled(false);
            }

            if (offsetLbl != null) {
                offsetLbl.setEnabled(false);
            }

            launchFindBtn.setEnabled(false);
            worksetSelectionPanel.setEnabled(true);

            if (worksetSelectionPanel.getSelectedBaselines().length > 0) {
                newSelection[0] = worksetSelectionPanel.getSelectedBaselines()[0];
            } else if (worksetSelectionPanel.getSelectedWorksets().length > 0) {
                newSelection[0] = worksetSelectionPanel.getSelectedWorksets()[0];
            } else if (worksetSelectionPanel.getSelectedSccProjects().length > 0) {
                newSelection[0] = worksetSelectionPanel.getSelectedSccProjects()[0];
            }
        }
        setSelection(newSelection);
    }

    private boolean isWorksetMode() {
        return (mode & WORKSET) == WORKSET && (mode & BASELINE) == 0;
    }

    private boolean isBaselineMode() {
        return (mode & WORKSET) == 0 && (mode & BASELINE) == BASELINE;
    }

    private boolean isBothMode() {
        return (mode & WORKSET) == WORKSET && (mode & BASELINE) == BASELINE;
    }

    // multiple mode - called with array of paths of projects in source
    // gives back array of VersionManagementProjecs for matching projects
    private boolean isMultipleMode() {
        return (mode & MULTIPLE) == MULTIPLE;
    }

    private int getFindMode() {
        if (findModeSelectorCmb == null) {
            return isWorksetMode() ? WORKSET : BASELINE;
        }
        return findModeSelectorCmb.getSelectionIndex() == 0 ? WORKSET : BASELINE;
    }

    public String getDefaultProduct() {
        return targetProduct;
    }

    public void setDefaultProduct(String defaultProduct) {
        this.targetProduct = defaultProduct;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2006, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.controls;

import java.util.List;

import org.eclipse.core.runtime.Path;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author B.Stephenson
 */
public class FolderBrowsePanel {

    private DimensionsArObject obj; // project or repository folder
    private Composite panel;
    private TreeViewer treeViewer;

    private ISelectionChangedListener selectionChangedListener;
    private IDoubleClickListener doubleClickListener;

    private ViewerFilter folderFilter;

    private class FolderContentProvider implements ITreeContentProvider {
        @Override
        public Object[] getChildren(Object parentElement) {
            Object[] ret = Utils.ZERO_LENGTH_OBJECT_ARRAY;
            RepositoryFolder f = (RepositoryFolder) parentElement;
            List flist = f.getImmediateChildFolders();
            if (flist.size() > 0) {
                ret = flist.toArray(new RepositoryFolder[flist.size()]);
            }
            return ret;
        }

        @Override
        public Object getParent(Object element) {
            RepositoryFolder f = (RepositoryFolder) element;
            return f.getParentFolder();
        }

        @Override
        public boolean hasChildren(Object element) {
            RepositoryFolder f = (RepositoryFolder) element;
            List flist = f.getImmediateChildFolders();
            return flist.size() > 0 ? true : false;
        }

        @Override
        public Object[] getElements(Object inputElement) {
            Object[] ret = Utils.ZERO_LENGTH_OBJECT_ARRAY;
            if (inputElement instanceof Project) {
                RepositoryFolder root = ((Project) inputElement).getRootFolder();
                ret = new Object[] { root };
            } else if (inputElement instanceof Baseline) {
                RepositoryFolder root = ((Baseline) inputElement).getRootFolder();
                ret = new Object[] { root };
            } else if (inputElement instanceof RepositoryFolder) {
                List flist = ((RepositoryFolder) inputElement).getImmediateChildFolders();
                if (flist.size() > 0) {
                    ret = flist.toArray(new RepositoryFolder[flist.size()]);
                }
            }
            return ret;

        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        }

    }

    private class FolderLabelProvider implements ILabelProvider {
        @Override
        public Image getImage(Object element) {
            if (element instanceof RepositoryFolder) {
                return PlatformUI.getWorkbench().getSharedImages().getImage(org.eclipse.ui.ISharedImages.IMG_OBJ_FOLDER);
            } else {
                return null;
            }

        }

        @Override
        public String getText(Object element) {
            if (element instanceof RepositoryFolder) {
                String path = new Path(((RepositoryFolder) element).getName()).lastSegment();
                return path == null ? "/" : path; //$NON-NLS-1$
            } else {
                return Utils.EMPTY_STRING;
            }
        }

        @Override
        public void addListener(ILabelProviderListener listener) {
        }

        @Override
        public void dispose() {

        }

        @Override
        public boolean isLabelProperty(Object element, String property) {
            return false;
        }

        @Override
        public void removeListener(ILabelProviderListener listener) {
        }

    }

    /**
     *
     *
     * @param parent composite parent
     * @param obj Repository folder or Project or Baseline
     * @param folderFilter
     */
    public FolderBrowsePanel(Composite parent, DimensionsArObject obj, ViewerFilter folderFilter) {
        assert (obj instanceof RepositoryFolder || obj instanceof Project || obj instanceof Baseline);
        this.obj = obj;
        this.folderFilter = folderFilter;
        createControl(parent);

    }

    public Composite getPanel() {
        return panel;
    }

    /**
     * @return selected folder
     */
    public RepositoryFolder getSelectedFolder() {
        if (treeViewer.getSelection() instanceof IStructuredSelection) {
            return (RepositoryFolder) ((IStructuredSelection) treeViewer.getSelection()).getFirstElement();
        } else {
            return null;
        }
    }

    /**
     * Selection listener is notified after events have been processed by
     * this class.
     * @param listener
     */
    public void setSelectionChangedListener(ISelectionChangedListener listener) {
        if (selectionChangedListener == null) {
            selectionChangedListener = listener;
        }
    }

    /**
     * @param listener
     */
    public void setDoubleClickListener(IDoubleClickListener listener) {
        if (doubleClickListener == null) {
            doubleClickListener = listener;
        }
    }

    /**
     * @param b
     */
    public void setEnabled(boolean b) {
        treeViewer.getTree().setEnabled(b);
    }

    public void setOptions(int options) {
        if (treeViewer != null && !treeViewer.getControl().isDisposed()) {
            treeViewer.refresh();
        }
    }

    protected void createControl(Composite parent) {
        panel = new Composite(parent, SWT.NONE);

        panel.setLayout(new FillLayout());

        Tree tree = new Tree(panel, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.SINGLE);
        treeViewer = new TreeViewer(tree);
        treeViewer.setLabelProvider(new FolderLabelProvider());
        treeViewer.setContentProvider(new FolderContentProvider());
        if (folderFilter != null) {
            treeViewer.addFilter(folderFilter);
        }
        treeViewer.setInput(obj);
        treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {

            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                if (selectionChangedListener != null) {
                    selectionChangedListener.selectionChanged(event);
                }

            }
        });

        treeViewer.addDoubleClickListener(new IDoubleClickListener() {
            @Override
            public void doubleClick(DoubleClickEvent event) {
                if (doubleClickListener != null) {
                    doubleClickListener.doubleClick(event);
                }
            }
        });
    }

}

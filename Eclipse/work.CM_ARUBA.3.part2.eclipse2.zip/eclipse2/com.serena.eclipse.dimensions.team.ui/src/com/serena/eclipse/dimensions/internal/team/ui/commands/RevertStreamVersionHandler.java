package com.serena.eclipse.dimensions.internal.team.ui.commands;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchSite;

import com.serena.dmclient.api.DimensionsChangeSet;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;
import com.serena.eclipse.dimensions.internal.team.ui.actions.xml.WorkspaceRevertWizardAction;

public class RevertStreamVersionHandler extends AbstractHandler {

    public RevertStreamVersionHandler() {
    }

    @Override
    public Object execute(ExecutionEvent arg0) throws ExecutionException {
        IWorkbenchPage activePage = UIUtils.getActivePage();
        final ChangeSetHistoryView changesetView = (ChangeSetHistoryView) activePage.findView(ChangeSetHistoryView.ID);
        IWorkbenchSite changesetsSite = changesetView.getSite();
        ISelectionProvider selectionProvider = changesetsSite.getSelectionProvider();
        TreeSelection selection = (TreeSelection) selectionProvider.getSelection();
        Object[] selectedObjects = selection.toArray();
        DimensionsChangeSet changeset = (DimensionsChangeSet) selectedObjects[0];
        IResource changesetScopeResource = changesetView.getChangesetViewResource();
        WorkspaceRevertWizardAction action = new WorkspaceRevertWizardAction(changeset, changeset.getProject(),
                changesetScopeResource);
        action.run(null);
        return null;
    }
}

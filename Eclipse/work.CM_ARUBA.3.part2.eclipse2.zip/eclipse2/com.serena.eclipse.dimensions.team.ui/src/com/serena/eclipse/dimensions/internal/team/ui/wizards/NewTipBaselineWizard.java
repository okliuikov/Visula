package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.dmclient.api.BaselineDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;

public class NewTipBaselineWizard extends NewBaselineWizard {

    public NewTipBaselineWizard() {
        super();
    }

    public NewTipBaselineWizard(DimensionsConnectionDetailsEx connection, WorksetAdapter basedOn, FormToolkit toolkit) {
        super(connection, basedOn, toolkit);
    }

    public NewTipBaselineWizard(DimensionsConnectionDetailsEx connection, APIObjectAdapter basedOn) {
        super(connection, basedOn);
    }

    public NewTipBaselineWizard(DimensionsConnectionDetailsEx connection) {
        super(connection);

    }

    @Override
    protected String[] getTitleDesc() {
        String[] titleDesc = new String[2];
        titleDesc[0] = Messages.NewBaselineWizard_tip_title;
        titleDesc[1] = Messages.NewBaselineWizard_tip_description;
        return titleDesc;
    }

    @Override
    protected int getBaselineCode() {
        return NewBaselineWizard.TIP_BASELINE;
    }

    @Override
    protected BaselineDetails createBaselineDetails(BaselineDetails baselineDetails, NewBaselineGeneralPage generalPage) {
        BaselineDetails det = super.createBaselineDetails(baselineDetails, generalPage);
        // repeated
        APIObjectAdapter adapter = generalPage.getBasedOnObject();
        assert adapter != null && (adapter instanceof WorksetAdapter || adapter instanceof BaselineAdapter);
        setBasedOnObject(adapter);
        String bow = (String) adapter.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
        det.setBasedOnProject(bow);
        // Tip Baseline specific
        NewBaselineRelatePage relPage = (NewBaselineRelatePage) getPage(BASELINE_REQUEST_PAGE);
        det.setRelatedRequests(relPage.getRelatedRequests());
        return det;
    }

    @Override
    protected void addInternalPages(int options) {
        // @formatter:off
         addPage(new NewBaselineRelatePage(
                BASELINE_REQUEST_PAGE,
                    Messages.newBaselineRelatePage_title,
                    Messages.newBaselineRelatePage_desctip,
                    DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN),
                    getConnection(),
                    getBaselineCode()));
         // @formatter:on
    }
}

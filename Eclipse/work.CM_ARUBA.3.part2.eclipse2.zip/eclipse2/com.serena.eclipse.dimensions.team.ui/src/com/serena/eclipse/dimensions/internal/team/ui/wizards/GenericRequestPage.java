/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2009 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ColumnLayoutData;
import org.eclipse.jface.viewers.ColumnPixelData;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.IFontProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import com.serena.dmclient.api.CmRulesDetails;
import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.api.ItemRevisionDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.ItemType;
import com.serena.dmclient.objects.ItemTypeCMRules;
import com.serena.dmclient.objects.Product;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.TypeReference;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.IdmRequestsPanel;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsNewWizard;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.util.StringUtils;

/**
 * Generic request relate page
 * Designed to be used with SharingWizard
 *
 */
public class GenericRequestPage extends DimensionsWizardPage {
    /* Common stuff */
    private String reqProviderType = null; // current request provider for this control instance
    private DimensionsConnectionDetailsEx connection = null;

    private Composite parent;
    private CheckboxTableViewer docActivatedTableViewer;
    private Button selectAllBtn;
    private Button deselectAllBtn;

    private IDialogSettings settings;
    private List<String> selectedItems;

    private boolean isRequestRequired = false;

    /* IDM stuff */
    private boolean justCreated = true;
    private CTabFolder idmTabFolder;
    private IdmRequestsPanel tablePanel;

    /* DM stuff */
    private boolean useActivated;
    private CheckboxTableViewer docTableViewer;
    private Button showAllBtn;
    private Map documents; // doc id -> RequestInfo
    private Map documentsPending; // doc id -> RequestInfo
    private Map documentsActivated; // doc id -> RequestInfo
    private VersionManagementProject remoteProject;
    // in some cases remoteProject does not exist yet, but we need at least the product name to identify external requests provider
    private String productId;

    public GenericRequestPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage, description);
        setPageComplete(false);
    }

    @Override
    public void createControl(Composite parent) {
        this.parent = parent;
        createInitializeControl();
    }

    /*
     * Should be called on each page displaying to check and create appropriate request page on the fly
     */
    private void createInitializeControl() {
        DimensionsConnectionDetailsEx newConn = getConnection();
        if (!newConn.equals(connection)) {
            documents = null;
        }
        String provider = newConn.getRequestProviderType();
        connection = newConn;
        // dispose all the contents if it's inappropriate
        if (reqProviderType != null && !reqProviderType.equals(provider)) {
            getControl().dispose();
            reqProviderType = null;
        }

        if (connection.isIdmRequestProvider()) {
            boolean recreateUi = tablePanel != null;
            if (reqProviderType == null) {
                IDialogSettings pluginSettings = DMTeamUiPlugin.getDefault().getDialogSettings();
                settings = pluginSettings.getSection(IdmRequestPage.class.getName());
                if (settings == null) {
                    settings = pluginSettings.addNewSection(IdmRequestPage.class.getName());
                }
                setControl(createIDMControl(parent));
                reqProviderType = provider;
            }
            if (recreateUi) {
                getShell().layout(false, true);
            }
        } else {
            if (reqProviderType == null) {
                IDialogSettings pluginSettings = DMTeamUiPlugin.getDefault().getDialogSettings();
                settings = pluginSettings.getSection(DimensionsRequestPage.class.getName());
                if (settings == null) {
                    settings = pluginSettings.addNewSection(DimensionsRequestPage.class.getName());
                }

                setControl(createDMControl(parent));
                reqProviderType = provider;
            }
        }
        checkPage();
    }

    protected Composite createIDMControl(Composite parent) {

        final Composite composite = new Composite(parent, SWT.NONE);
        GridLayout gl = UIUtils.setGridLayout(composite, 1);
        gl.marginHeight = gl.marginWidth = 0;

        idmTabFolder = new CTabFolder(composite, SWT.TOP | SWT.FLAT | SWT.MULTI | SWT.BORDER);
        UIUtils.setGridData(idmTabFolder, GridData.FILL_BOTH);

        Composite panel = createControlForIdmRequests(idmTabFolder);

        CTabItem tabItemInbox = new CTabItem(idmTabFolder, SWT.NONE);
        tabItemInbox.setText(Messages.TeamOperationWizardRequestPage_39);
        tabItemInbox.setControl(panel);

        final CTabItem tabItemFavorites = new CTabItem(idmTabFolder, SWT.NONE);
        tabItemFavorites.setText(Messages.TeamOperationWizardRequestPage_Favorites);
        tabItemFavorites.setControl(panel);

        useActivated = DMTeamUiPlugin.getDefault().isUseActivatedRequests();
        if (useActivated) {
            idmTabFolder.setSelection(tabItemFavorites);
        } else {
            idmTabFolder.setSelection(tabItemInbox);
        }

        idmTabFolder.addSelectionListener(new SelectionListener() {
            @Override
            public void widgetDefaultSelected(SelectionEvent e) {
                showIdmRequests();
            }

            @Override
            public void widgetSelected(SelectionEvent e) {
                showIdmRequests();
            }
        });
        return composite;
    }
    
    private Composite createControlForIdmRequests(Composite parent) {
        Composite panel = new Composite(parent, SWT.NONE);
        GridLayout layout = UIUtils.setGridLayout(panel, 1);
        layout.marginHeight = layout.marginWidth = 0;

        tablePanel = new IdmRequestsPanel(panel, getConnection(), getRequestProvider(),
                true /* allowCheckboxesInTable */);
        tablePanel.getCheckboxTableViewer().addSelectionChangedListener(new ISelectionChangedListener() {

            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                // here we only need to handle 'remove from favorites' operation for the last
                // checked request in the list
                if (tablePanel.getCheckedRequestNames().toArray(new String[0]).length == 0) {
                    updateSelectedIdmRequests();
                }
            }
        });
        
        tablePanel.getCheckboxTableViewer().addCheckStateListener(new ICheckStateListener() {
            @Override
            public void checkStateChanged(CheckStateChangedEvent event) {
                updateSelectedIdmRequests();
            }
        });

        // buttons
        Composite buttons = new Composite(panel, SWT.NONE);
        UIUtils.setGridLayout(buttons, 4);

        selectAllBtn = new Button(buttons, SWT.PUSH);
        selectAllBtn.setText(Messages.SharingRequestPage_selectAllButtonText);

        deselectAllBtn = new Button(buttons, SWT.PUSH);
        deselectAllBtn.setText(Messages.SharingRequestPage_clearAllButtonText);

        SelectionListener buttonListener = new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (e.widget == selectAllBtn || e.widget == deselectAllBtn) {
                    boolean selectAll = e.getSource() == selectAllBtn;
                    tablePanel.getCheckboxTableViewer().setAllChecked(selectAll);
                    updateSelectedIdmRequests();
                }

            }
        };
        selectAllBtn.addSelectionListener(buttonListener);
        deselectAllBtn.addSelectionListener(buttonListener);

        return panel;
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            if (!justCreated) {
                createInitializeControl();
            }
            if (connection.isIdmRequestProvider()) {
                showIdmRequests();
            } else {
                populateDMRequests();
            }
        }
        justCreated = false;
        super.setVisible(visible);
    }
    
    private void showIdmRequests() {
        // we'll try to restore selection (checked requests) when switching between
        // inbox/favorites tab
        List<String> selected = tablePanel.getCheckedRequestNames();

        if (idmTabFolder.getSelection().getText() == Messages.TeamOperationWizardRequestPage_Favorites) {
            tablePanel.showActiveRequests();
        } else {
            tablePanel.showInboxRequests();
        }
        updateIdmCheckboxesAndSelection(selected);
    }

    private void checkPage() {
        List selected = getSelectedItemsList();
        if (isRequestRequired && (selected == null || selected.size() < 1)) {
            setErrorMessage(Messages.NewStreamWizard_generic_request_err1);
            if (isPageComplete()) { // it increases performance
                setPageComplete(false);
            }
        } else {
            setErrorMessage(null);
            if (!isPageComplete()) {
                setPageComplete(true);
            }
        }
    }

    /*
     * Save request selection for checkin/deliver wizards pre-selection
     */
    public void saveSettings() {
        if (settings != null) {
            settings.put(TeamOperationWizardRequestPage.USE_STORED_SELECTION, true);
            settings.put(TeamOperationWizardRequestPage.STORED_SELECTION, getSelectedItems());
        }
    }

    protected void updateSelectedIdmRequests() {
        List<String> checkedRequests = tablePanel.getCheckedRequestNames();
        if (checkedRequests == null || checkedRequests.size() == 0) {
            selectedItems = null;
        } else {
            selectedItems = checkedRequests;
        }
        checkPage();
    }

    /*
     * Gets selected request IDs
     */
    public String[] getSelectedItems() {
        List<String> selected = getSelectedItemsList(); 
        return selected != null ? selected.toArray(new String[selected.size()]) : Utils.ZERO_LENGTH_STRING_ARRAY;
    }

    private List<String> getSelectedItemsList() {
        return selectedItems;
    }

    public boolean checkMarkerCMRules(DimensionsConnectionDetailsEx conn, final String productName) {
        final boolean[] result = { false };
        if (conn == null) {
            return result[0];
        }
        final IProgressMonitor monitor = Utils.monitorFor(null);
        monitor.beginTask(null, 10);
        try {
            final Session session = conn.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    Product product = session.getObjectFactory().getBaseDatabaseAdmin().getProducts().get(productName);
                    if (product != null) {
                        ItemType projType = (ItemType) product.getItemTypes().get(IDMConstants.TYPE_PROJECT);
                        ItemTypeCMRules cm_rules = projType.getCmRules();
                        result[0] = cm_rules.getEnabled();
                    }
                }
            }, monitor);
        } catch (DMException e) {
            setErrorMessage(e.getMessage());
        } finally {
            monitor.done();
        }
        return result[0];
    }

    public boolean checkCMRules(DimensionsConnectionDetailsEx conn, final VersionManagementProject project) {
        final boolean result[] = { false };
        if (conn == null || project == null) {
            return result[0];
        }
        final IProgressMonitor monitor = Utils.monitorFor(null);
        monitor.beginTask(null, 10);
        try {
            final Session session = conn.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    ItemRevisionDetails details = new ItemRevisionDetails();
                    details.setTypeName(IDMConstants.TYPE_PROJECT);
                    String spec = project.getProjectSpec();
                    int idx = spec.indexOf(':');
                    if (idx > 0) {
                        details.setProductName(spec.substring(0, idx));
                    }

                    Project proj = session.getObjectFactory().getProject(project.getProjectSpec());
                    if (proj != null) {
                        proj.queryAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
                        String cm_rules = (String) proj.getAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
                        if (cm_rules != null && cm_rules.getBytes()[0] == ProjectDetails.PROJECT_CM_RULES_ON) {
                            result[0] = true;
                        } else if (cm_rules != null && cm_rules.getBytes()[0] == ProjectDetails.PROJECT_CM_RULES_OFF) {
                            result[0] = false;
                        } else {
                            monitor.subTask(NLS.bind(Messages.UploadHelper_11, proj.getName()));
                            CmRulesDetails.Input[] cmRulesInputs = { new CmRulesDetails.DetailsInput(details,
                                    CmRulesDetails.CMRULES_CREATE) };
                            int singleResult = proj.queryCMRules(cmRulesInputs)[0];
                            result[0] = singleResult > 0;
                        }
                        if (!result[0]) {
                            proj.queryAttribute(SystemAttributes.WSET_PATH_CONTROL);
                            result[0] = ((Boolean) proj.getAttribute(SystemAttributes.WSET_PATH_CONTROL)).booleanValue(); // for the
                                                                                                                          // streams
                                                                                                                          // always
                                                                                                                          // false
                        }
                    }
                }
            }, monitor);
        } catch (DMException e) {
            setErrorMessage(e.getMessage());
        } finally {
            monitor.done();
        }
        return result[0];
    }

    public void setRequestRequired(boolean isRequestRequired) {
        this.isRequestRequired = isRequestRequired;
    }

    public void setProject(VersionManagementProject project) {

        remoteProject = project;
        if (remoteProject != null) {
            setProductId(getStringAttribute(project, SystemAttributes.PRODUCT_NAME));
        }
    }
    
    public void setProductId(String productId) {
        
        boolean stale = !productId.equals(this.productId);
        this.productId = productId;
        
        if (stale && tablePanel != null) {
            // needs refresh
            tablePanel.setRequestProvider(getRequestProvider());
            tablePanel.waitForPendingJobsCompletion();
            tablePanel.forceRefresh();
        }
    }
    
    private String getTargetProductId() {
        if (remoteProject != null) {
            return getStringAttribute(remoteProject, SystemAttributes.PRODUCT_NAME);
        }
        return productId;
    }

    private void populateDMRequests() {
        if (documents == null) {
            // flush selected items on populate
            selectedItems = null;
            createRequestInfos();
            // DEF217861 fix on MacOS. Problem occurs when we fork running IRunnableWithProgress in createRequestInfos.
            // Needs more research to come up with better fix.
            getShell().layout(false, true);
            setDocuments();
        }
    }

    protected Composite createDMControl(Composite parent) {
        final Composite composite = new Composite(parent, SWT.NONE);
        GridLayout gl = UIUtils.setGridLayout(composite, 1);
        gl.marginHeight = gl.marginWidth = 0;

        final CTabFolder tabFolder = new CTabFolder(composite, SWT.TOP | SWT.FLAT | SWT.MULTI | SWT.BORDER);
        UIUtils.setGridData(tabFolder, GridData.FILL_BOTH);

        Table table = createTableForRequests(tabFolder);

        CTabItem tabItem = new CTabItem(tabFolder, SWT.NONE);
        tabItem.setText(Messages.TeamOperationWizardRequestPage_39);
        tabItem.setControl(table);

        final CTabItem tabItemA = new CTabItem(tabFolder, SWT.NONE);
        tabItemA.setText(Messages.TeamOperationWizardRequestPage_Favorites);

        Table tableA = createTableForRequests(tabFolder);
        tabItemA.setControl(tableA);

        useActivated = DMTeamUiPlugin.getDefault().isUseActivatedRequests();
        if (useActivated) {
            tabFolder.setSelection(tabItemA);
        } else {
            tabFolder.setSelection(tabItem);
        }

        tabFolder.addSelectionListener(new SelectionListener() {
            @Override
            public void widgetDefaultSelected(SelectionEvent e) {
                useActivated = (e.item == tabItemA);
                setDocuments();
            }

            @Override
            public void widgetSelected(SelectionEvent e) {
                useActivated = (e.item == tabItemA);
                setDocuments();
            }
        });

        RequestContentProvider rcp = new RequestContentProvider();
        RequestLabelProvider rlp = new RequestLabelProvider();
        RequestSorter rs = new RequestSorter();

        docTableViewer = new CheckboxTableViewer(table);
        docTableViewer.setContentProvider(rcp);
        docTableViewer.setLabelProvider(rlp);
        docTableViewer.setSorter(rs);
        docTableViewer.addFilter(new RequestFilter());

        docActivatedTableViewer = new CheckboxTableViewer(tableA);
        docActivatedTableViewer.setContentProvider(rcp);
        docActivatedTableViewer.setLabelProvider(rlp);
        docActivatedTableViewer.setSorter(rs);
        docActivatedTableViewer.addFilter(new RequestFilter());

        if (documents != null) {
            docTableViewer.setInput(documents);
            docActivatedTableViewer.setInput(documents);
        }

        ICheckStateListener checkStateListener = new ICheckStateListener() {
            @Override
            public void checkStateChanged(CheckStateChangedEvent event) {
                RequestInfo ri = (RequestInfo) event.getElement();
                // undo invalid checks
                if (event.getChecked() && GenericRequestPage.this.getSelectionState(ri) != DimensionsRequestPage.OK) {
                    if (event.getSource() == docActivatedTableViewer) {
                        docActivatedTableViewer.setChecked(ri, false);
                    } else if (event.getSource() == docTableViewer) {
                        docTableViewer.setChecked(ri, false);
                    }
                    return;
                }
                updateSelectedRequests(ri, event.getChecked());
            }
        };
        docTableViewer.addCheckStateListener(checkStateListener);
        docActivatedTableViewer.addCheckStateListener(checkStateListener);

        Composite buttons = new Composite(composite, SWT.NONE);
        UIUtils.setGridLayout(buttons, 6);

        selectAllBtn = new Button(buttons, SWT.PUSH);
        selectAllBtn.setText(Messages.SharingRequestPage_selectAllButtonText);

        deselectAllBtn = new Button(buttons, SWT.PUSH);
        deselectAllBtn.setText(Messages.SharingRequestPage_clearAllButtonText);

        showAllBtn = new Button(buttons, SWT.CHECK);
        showAllBtn.setText(Messages.TeamOperationWizardRequestPage_25);

        SelectionListener btnSelectionListener = new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (e.widget == selectAllBtn) {
                    for (Iterator docIter = documents.values().iterator(); docIter.hasNext();) {
                        RequestInfo ri = (RequestInfo) docIter.next();
                        if (GenericRequestPage.this.getSelectionState(ri) == DimensionsRequestPage.OK) {
                            if (useActivated) {
                                docActivatedTableViewer.setChecked(ri, true);
                            } else {
                                docTableViewer.setChecked(ri, true);
                            }
                            updateSelectedRequests(ri, true);
                        }
                    }
                    return;
                }

                if (e.widget == deselectAllBtn) {
                    for (Iterator docIter = documents.values().iterator(); docIter.hasNext();) {
                        RequestInfo ri = (RequestInfo) docIter.next();
                        if (useActivated) {
                            docActivatedTableViewer.setChecked(ri, false);
                        } else {
                            docTableViewer.setChecked(ri, false);
                        }
                        updateSelectedRequests(ri, false);
                    }
                    return;
                }

                if (e.widget == showAllBtn) {
                    docTableViewer.refresh();
                    docActivatedTableViewer.refresh();
                    updateCheckboxes();
                }
            }
        };
        selectAllBtn.addSelectionListener(btnSelectionListener);
        deselectAllBtn.addSelectionListener(btnSelectionListener);
        showAllBtn.addSelectionListener(btnSelectionListener);

        return composite;
    }

    private Table createTableForRequests(Composite parent) {
        Table table = new Table(parent, SWT.CHECK | SWT.FULL_SELECTION | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL | SWT.BORDER);

        UIUtils.setGridData(table, GridData.FILL_BOTH);
        table.setHeaderVisible(true);
        table.setLinesVisible(true);

        TableLayout tableLayout = new TableLayout();

        TableColumn docIdCol = new TableColumn(table, SWT.NONE);
        docIdCol.setResizable(true);
        docIdCol.setText(Messages.TeamOperationWizardRequestPage_9);
        tableLayout.addColumnData(getColumnLayoutData(DimensionsRequestPage.COL_DOC_ID_WIDTH, 20));
        docIdCol.addControlListener(new TableColumnListener(DimensionsRequestPage.COL_DOC_ID_WIDTH, settings));

        TableColumn statusCol = new TableColumn(table, SWT.NONE);
        statusCol.setResizable(true);
        statusCol.setText(Messages.TeamOperationWizardRequestPage_10);
        tableLayout.addColumnData(getColumnLayoutData(DimensionsRequestPage.COL_DOC_STATUS_WIDTH, 15));
        statusCol.addControlListener(new TableColumnListener(DimensionsRequestPage.COL_DOC_STATUS_WIDTH, settings));

        TableColumn titleCol = new TableColumn(table, SWT.NONE);
        titleCol.setResizable(true);
        titleCol.setText(Messages.TeamOperationWizardRequestPage_11);
        tableLayout.addColumnData(getColumnLayoutData(DimensionsRequestPage.COL_DOC_TITLE_WIDTH, 30));
        titleCol.addControlListener(new TableColumnListener(DimensionsRequestPage.COL_DOC_TITLE_WIDTH, settings));

        TableColumn detailsCol = new TableColumn(table, SWT.NONE);
        detailsCol.setResizable(true);
        detailsCol.setText(Messages.TeamOperationWizardRequestPage_12);
        tableLayout.addColumnData(getColumnLayoutData(DimensionsRequestPage.COL_DOC_DETAILS_WIDTH, 15));
        detailsCol.addControlListener(new TableColumnListener(DimensionsRequestPage.COL_DOC_DETAILS_WIDTH, settings));
        table.setLayout(tableLayout);

        return table;
    }
    
    private void updateIdmCheckboxesAndSelection(List<String> selected) {
        if (selected == null) {
            return;
        }
        tablePanel.setCheckedRequests(selected);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    tablePanel.waitForPendingJobsCompletion();

                    Display.getDefault().asyncExec(new Runnable() {

                        @Override
                        public void run() {
                            if (tablePanel != null && !tablePanel.getTableViewer().getControl().isDisposed()) {
                                updateSelectedIdmRequests();
                            }
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private ColumnLayoutData getColumnLayoutData(String column, int weight) {
        ColumnLayoutData result;
        try {
            result = new ColumnPixelData(settings.getInt(column));
        } catch (NumberFormatException e) {
            result = new ColumnWeightData(weight);
        }
        return result;
    }

    private class RequestContentProvider implements IStructuredContentProvider {

        public RequestContentProvider() {
        }

        @Override
        public Object[] getElements(Object inputElement) {
            if (inputElement == documents) {
                return documents.values().toArray();
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        }

    }

    private class RequestLabelProvider extends LabelProvider implements ITableLabelProvider, IFontProvider {
        private Font italicFont;

        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            return null;
        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            if (!(element instanceof RequestInfo)) {
                return Utils.EMPTY_STRING;
            }
            RequestInfo requestInfo = (RequestInfo) element;
            String text = null;
            switch (columnIndex) {
            case DimensionsRequestPage.COL_DOC_ID:
                text = (String) requestInfo.request.getAPIObject().getAttribute(SystemAttributes.OBJECT_ID);
                break;
            case DimensionsRequestPage.COL_DOC_STATUS:
                text = (String) requestInfo.request.getAPIObject().getAttribute(SystemAttributes.STATUS);
                break;
            case DimensionsRequestPage.COL_DOC_TITLE:
                text = (String) requestInfo.request.getAPIObject().getAttribute(SystemAttributes.TITLE);
                break;
            case DimensionsRequestPage.COL_DOC_DETAILS:
                int selState = getSelectionState(requestInfo);
                if (selState != DimensionsRequestPage.OK) {
                    ArrayList reasons = new ArrayList();
                    if ((selState & DimensionsRequestPage.INVALID_PROJECT) != 0) {
                        String prj = getStringAttribute(requestInfo.request, SystemAttributes.PROJECT);
                        reasons.add(NLS.bind(Messages.TeamOperationWizardRequestPage_2, prj));
                    }
                    text = Utils.toCsvString(reasons.toArray(), true);
                }

                break;
            }
            if (text == null) {
                return Utils.EMPTY_STRING;
            }
            return text;
        }

        @Override
        public Font getFont(Object element) {
            if (element instanceof RequestInfo) {
                RequestInfo request = (RequestInfo) element;
                if (getSelectionState(request) != DimensionsRequestPage.OK) {
                    return getItalicFont();
                }
            }
            return null;
        }

        @Override
        public void dispose() {
            if (italicFont != null) {
                italicFont.dispose();
            }
            super.dispose();
        }

        private Font getItalicFont() {
            if (italicFont == null) {
                Font dfltFont = docTableViewer.getTable().getFont();
                FontData[] data = dfltFont.getFontData();
                for (int i = 0; i < data.length; i++) {
                    data[i].setStyle(SWT.ITALIC);
                }
                italicFont = new Font(docTableViewer.getTable().getDisplay(), data);
            }
            return italicFont;
        }

    }

    private class RequestSorter extends ViewerSorter {
        @Override
        public int compare(Viewer viewer, Object e1, Object e2) {
            if (e1 instanceof RequestInfo && e2 instanceof RequestInfo) {
                return compareChangeRequests((RequestInfo) e1, (RequestInfo) e2);
            }
            return super.compare(viewer, e1, e2);
        }
    }

    // sort order: product, type, number
    private int compareChangeRequests(RequestInfo r1, RequestInfo r2) {
        int result;
        if (r1 != null && r2 != null) {
            // use collator? how to detect server locale?
            String p1 = r1.type.getProduct();
            String p2 = r2.type.getProduct();
            result = p1.compareTo(p2);// collator.compare(p1, p2);
            if (result == 0) {
                String t1 = r1.type.getTypeName();
                String t2 = r2.type.getTypeName();
                result = t1.compareTo(t2);// collator.compare(t1, t2);
                if (result == 0) {
                    int n1 = ((Integer) r1.request.getChangeDocument().getAttribute(SystemAttributes.NUMBER)).intValue();
                    int n2 = ((Integer) r2.request.getChangeDocument().getAttribute(SystemAttributes.NUMBER)).intValue();
                    result = n2 - n1;
                }
            }
        } else {
            result = (r1 != null ? 1 : 0) - (r2 != null ? 1 : 0);
        }
        return result;
    }

    private class RequestFilter extends ViewerFilter {
        @Override
        public boolean select(Viewer viewer, Object parentElement, Object element) {
            if (element instanceof RequestInfo && !showAllBtn.getSelection()) { // exclude invalid
                return getSelectionState((RequestInfo) element) == DimensionsRequestPage.OK;
            }
            return true;
        }
    }

    private void setDocuments() {
        if (useActivated) {
            documents = documentsActivated;
        } else {
            documents = documentsPending;
        }
        docTableViewer.setInput(documents);
        docActivatedTableViewer.setInput(documents);
        updateCheckboxes();
    }

    private void updateSelectedRequests(RequestInfo info, boolean selected) {
        String id = getStringAttribute(info.request, SystemAttributes.OBJECT_ID);
        if (selectedItems == null) {
            selectedItems = new ArrayList();
        }
        if (selected) {
            if (!selectedItems.contains(id)) {
                selectedItems.add(id);
            }
        } else {
            selectedItems.remove(id);
        }
        checkPage();
    }

    private void updateCheckboxes() {
        List elements = null;
        if (selectedItems != null && selectedItems.size() > 0) {
            elements = new ArrayList();
            for (Iterator docIter = documents.values().iterator(); docIter.hasNext();) {
                RequestInfo ri = (RequestInfo) docIter.next();
                String id = getStringAttribute(ri.request, SystemAttributes.OBJECT_ID);
                if (selectedItems.contains(id)) {
                    elements.add(ri);
                }
            }
        }

        Object[] elementsToCheck = (elements == null)
                ? Utils.ZERO_LENGTH_OBJECT_ARRAY : (RequestInfo[]) elements.toArray(new RequestInfo[elements.size()]);
        if (useActivated) {
            docActivatedTableViewer.setCheckedElements(elementsToCheck);
        } else {
            docTableViewer.setCheckedElements(elementsToCheck);
        }

        checkPage();
    }

    /*
     * Gets up-to-date request information from the lists
     */
    protected void createRequestInfos() {
        try {
            getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    String id = GenericRequestPage.class.getName();
                    try {
                        monitor.beginTask(null, 100);
                        documentsPending = readRequestInfo(ChangeDocumentList.getMyPendingList(connection), connection, id, monitor);
                        documentsActivated = readRequestInfo(
                                ChangeDocumentList.getActiveRequestsList(connection, Utils.subMonitorFor(monitor, 10)), connection,
                                id, monitor);
                    } catch (Exception e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.setTaskName(Utils.EMPTY_STRING);
                        monitor.subTask(Utils.EMPTY_STRING);
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e, getContainer().getShell());
        } catch (InterruptedException e) {
        }
    }

    private Map readRequestInfo(ChangeDocumentList myPending, DimensionsConnectionDetailsEx connection, String id,
            IProgressMonitor monitor) throws Exception {
        Map result = null;
        try {
            int[] attrs = new int[] { SystemAttributes.OBJECT_ID, SystemAttributes.STATUS, SystemAttributes.TITLE,
                    SystemAttributes.PRODUCT_NAME, SystemAttributes.TYPE_NAME, SystemAttributes.NUMBER, SystemAttributes.PROJECT,
                    SystemAttributes.CM_PHASE };

            myPending.attributeSubscribe(id, attrs);
            myPending.fetch(Utils.subMonitorFor(monitor, 60));

            IProgressMonitor subMon = Utils.subMonitorFor(monitor, 40, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK);
            APIObjectAdapter[] myDocs = myPending.getObjects();
            result = new HashMap(myDocs.length);
            subMon.beginTask(Messages.TeamOperationWizardRequestPage_4, myDocs.length * 3);
            for (int i = 0; i < myDocs.length; i++) {
                ChangeDocumentAdapter aDoc = (ChangeDocumentAdapter) myDocs[i];
                String docProductName = getStringAttribute(aDoc, SystemAttributes.PRODUCT_NAME);
                String docTypeName = getStringAttribute(aDoc, SystemAttributes.TYPE_NAME);
                String docId = getStringAttribute(aDoc, SystemAttributes.OBJECT_ID);
                RequestInfo requestInfo = new RequestInfo(aDoc, docProductName, docTypeName);
                result.put(docId, requestInfo);
            }
            subMon.done();
        } finally {
            if (myPending != null) {
                myPending.attributeUnsubscribe(id);
            }
            monitor.setTaskName(Utils.EMPTY_STRING);
            monitor.subTask(Utils.EMPTY_STRING);
            monitor.done();
        }
        return result;
    }

    private String getStringAttribute(APIObjectAdapter adapter, int attr) {
        return (String) adapter.getAPIObject().getAttribute(attr);
    }

    /*
     * Information about request
     */
    private class RequestInfo {
        ChangeDocumentAdapter request;
        TypeReference type;

        RequestInfo(ChangeDocumentAdapter request, String product, String type) {
            this.request = request;
            this.type = new TypeReference(connection, product, DMTypeScope.REQUEST, type);
        }
    }

    int getSelectionState(RequestInfo requestInfo) {
        int result = DimensionsRequestPage.OK;
        String relatedProject = getStringAttribute(requestInfo.request, SystemAttributes.PROJECT);
        if (!Utils.isNullEmpty(relatedProject) && !IDMConstants.GLOBAL_WORKSET.equals(relatedProject)) {
            if (remoteProject == null || !relatedProject.equalsIgnoreCase(remoteProject.getObjectSpec())) {
                result |= DimensionsRequestPage.INVALID_PROJECT;
            }
        }
        return result;
    }
    
    private DimensionsConnectionDetailsEx getConnection() {
        return ((DimensionsNewWizard) getWizard()).getConnection();
    }
    
    private RequestProvider getRequestProvider() {

        String productId = getTargetProductId();
        if (StringUtils.isBlank(productId)) {
            return null;
        }
        RequestProvider requestProvider = null;
        try {
            IDMHelper helper = this.connection.openSession(null).getObjectFactory().getIDMHelper();
            requestProvider = helper.getRequestProvider(productId);
        } catch (DMException e) {
            DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, "Error getting request provider", e)); //$NON-NLS-1$
        }
        return requestProvider;
    }

}

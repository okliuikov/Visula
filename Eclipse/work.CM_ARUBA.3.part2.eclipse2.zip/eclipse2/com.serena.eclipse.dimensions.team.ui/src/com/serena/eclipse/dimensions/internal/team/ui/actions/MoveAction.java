/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.team.core.TeamException;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.operations.MoveOperation;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Initiates repository move for locally moved resources.
 *
 * @author V.Grishchenko
 */
public class MoveAction extends DMWorkspaceAction {
    // deep status filter
    private static final IDMWorkspaceResourceFilter MY_FILTER = new StatusFilter(WorkspaceResourceStatus.MOVED,
            StatusFilter.AND);

    private static final IDMWorkspaceResourceFilter MY_FILTER2 = new IDMWorkspaceResourceFilter() {
        @Override
        public boolean select(IDMWorkspaceResource resource) throws TeamException {
            boolean shallowMoved = false;
            try {
                shallowMoved = resource.isMoved();
            } catch (CoreException swallow) {
                // swallow this
            }

            if (!resource.getProject().getIsStream()) { // if Dim project
                if (resource.getProject().isSccStyle()
                        || !(resource.getLocalResource().getType() == IResource.PROJECT && shallowMoved)) {
                    return true;
                } else {
                    return false;
                }
            } else if (resource.getProject().isSccStyle()) { // if Dim stream & in container
                if (resource.getLocalResource().getType() == IResource.PROJECT && shallowMoved) {
                    return true;
                } else {
                    return false;
                }
            }
            return resource.getProject().isSccStyle();
        }
    };

    private static final IDMWorkspaceResourceFilter COMPOUND_FILTER = new IDMWorkspaceResourceFilter.AndFilter(
            new IDMWorkspaceResourceFilter[] { MY_FILTER, MY_FILTER2 });

    public MoveAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources = getSelectedResources();
        if (resources == null || resources.length == 0) {
            return;
        }

        // If the parent project of the resource needs committing move we have to handle it along with this bunch
        try {
            List<IProject> movedProjects = new ArrayList<IProject>();
            for (int i = 0; i < resources.length; i++) {
                IDMWorkspaceResource wspProject = DMTeamPlugin.getWorkspace()
                        .getWorkspaceResource(resources[i].getProject());
                // move by shallow status
                if (wspProject.isMoved() && resources[i].getType() != IResource.PROJECT
                        && !movedProjects.contains(resources[0].getProject())) {
                    movedProjects.add(resources[0].getProject());
                } else if (wspProject.isMoved() && resources[i].getType() == IResource.PROJECT) {
                    movedProjects.remove(resources[i]);
                }
            }
            List<IResource> projectHeadedResources = new ArrayList<IResource>();
            projectHeadedResources.addAll(movedProjects);
            projectHeadedResources.addAll(Arrays.asList(resources));
            resources = projectHeadedResources.toArray(new IResource[projectHeadedResources.size()]);
        } catch (CoreException e) {
            DMTeamUiPlugin.log(e.getStatus());
        }

        MoveOperation moveOperation = new MoveOperation(getActivePart(), getNonOverlapping(resources), MY_FILTER);
        if (!moveOperation.prompt()) {
            throw new InterruptedException();
        }
        moveOperation.run();
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return COMPOUND_FILTER;
    }

}

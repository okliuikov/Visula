/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.ui.GenericPropertySource;

/**
 * Operation option.
 * @author V.Grishchenko
 */
public class Option extends GenericPropertySource {
    /** selection property */
    public static final String SELECTION = "selection"; //$NON-NLS-1$

    public static final Value YES = new Value(Messages.Option_yes);
    public static final Value NO = new Value(Messages.Option_no);
    public static final Value PROMPT = new Value(Messages.Option_prompt);

    public final String option;
    public final String text;

    private Value[] values;
    private int selection;
    private String[] valueText;

    public static class Value {
        public final String text;

        public Value(String text) {
            Assert.isNotNull(text, "null text"); //$NON-NLS-1$
            this.text = text;
        }
    }

    private static void checkValidSelection(int length, int selection) {
        if (selection < 0 || selection > (length - 1)) {
            throw new ArrayIndexOutOfBoundsException(selection);
        }
    }

    /**
     * Creates a new option.
     * @param option options name
     * @param text displayable optin text
     * @param values allowed values
     * @param selection initial selection
     */
    public Option(String option, String text, Value[] values, int selection) {
        Assert.isNotNull(option, "null option"); //$NON-NLS-1$
        Assert.isNotNull(text, "null text"); //$NON-NLS-1$
        Assert.isLegal(values != null && values.length > 0, "no values"); //$NON-NLS-1$
        checkValidSelection(values.length, selection);
        //Assert.isLegal(selection >= 0 && selection < values.length, "invalid selection " + selection); //$NON-NLS-1$
        this.option = option;
        this.text = text;
        this.values = values;
        this.selection = selection;
    }

    /**
     * Sets selected option value.
     * @param selection
     */
    public void setSelection(int selection) {
        checkValidSelection(values.length, selection);
        int oldValue = this.selection;
        this.selection = selection;
        firePropertyChange(SELECTION, new Integer(oldValue), new Integer(selection));
    }

    /**
     * @return Returns the values.
     */
    public Value[] getValues() {
        return values;
    }

    public String[] getValuesAsText() {
        if (valueText == null) {
            valueText = new String[values.length];
            for (int i = 0; i < values.length; i++) {
                valueText[i] = values[i].text;
            }
        }
        return valueText;
    }

    /**
     * @return currently selected option value
     */
    public Value getSelectedValue() {
        return values[selection];
    }

    /**
     * @return option value at the specified position
     */
    public Value getValue(int idx) {
        return values[idx];
    }

    /**
     * @return index of the currently selected value
     */
    public int getSelection() {
        return selection;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.UndoCheckoutRequest;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.UndoCheckoutHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.UndoCheckoutWizard;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * @author V.Grishchenko
 */
public class UndoCheckoutOperation extends WizardOperation {

    public UndoCheckoutOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        return NLS.bind(Messages.UndoCheckoutOperation_0, provider.getProject().getName());
    }

    @Override
    protected String getTaskName() {
        return Messages.UndoCheckoutOperation_1;
    }

    @Override
    protected void execute(OperationData data, IProgressMonitor monitor) throws CoreException, InterruptedException {
        WorkspaceResourceRequest[] requests = data.getRequestsArray();
        UndoCheckoutRequest[] undoCheckoutRequests = new UndoCheckoutRequest[requests.length];
        System.arraycopy(requests, 0, undoCheckoutRequests, 0, requests.length);
        IStatus status = data.getProject().undoCheckout(undoCheckoutRequests, monitor);
        if (!status.isOK()) {
            showInfo(status);
        }
    }

    @Override
    protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
        return new UndoCheckoutHelper(getResources(), getFilter(), monitor);
    }

    @Override
    protected TeamOperationWizard createWizard(TeamOperationWizardHelper helper) {
        return new UndoCheckoutWizard((UndoCheckoutHelper) helper);
    }

    private void showInfo(final IStatus status) {
        UIUtils.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                ErrorDialog.openError(getShell(), Messages.UndoCheckoutOperation_2, Messages.UndoCheckoutOperation_3, status);
            }
        });
    }

}

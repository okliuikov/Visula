/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

/**
 * Preference keys for versioning.
 *
 * @author V.Grishchenko
 */
public interface IDMTeamPreferences {
    String DECORATE_DEEP_STATUS_FOLDERS = "decorate_fld_deep"; //$NON-NLS-1$
    String DECORATE_FORCE_DEEP_STATUS_PROJECT = "decorate_force_prj_deep"; //$NON-NLS-1$
    String DECORATE_REMOTE_INFO_PROJECT = "decorate_prj_remote_info"; //$NON-NLS-1$
    String DECORATE_BASE_REVISION = "decorate_file_base"; //$NON-NLS-1$
    String DECORATE_REMOTE_REVISION = "decorate_file_remote"; //$NON-NLS-1$
    String DECORATE_LOCALLY_MODIFIED = "decorate_loc_modified"; //$NON-NLS-1$
    String DECORATE_LOCALLY_MODIFIED_TEXT = "decorate_loc_modified_txt"; //$NON-NLS-1$
    String DECORATE_LOCAL_MODE = "decorate_loc_mode"; //$NON-NLS-1$
    String DECORATE_SYNC_STATUS = "decorate_sync_status"; //$NON-NLS-1$

    String DELETE_UNMANAGED_ON_REPLACE = "delete_unmanaged_replace"; //$NON-NLS-1$
    String IGNORE_DERIVED_RESOURCES = "ignore_derived_resources"; //$NON-NLS-1$
    String COMPARE_CONSIDER_CONTENTS = "compare_consider_contents"; //$NON-NLS-1$
    String AUTO_FIND_ANCESTOR = "ancestor_find_auto"; //$NON-NLS-1$
    String SYNC_ON_SWITCHING_FOREIGN = "sync_on_switching_to_foreign"; //$NON-NLS-1$
    String SAVE_DIRTY_EDITORS = "save_dirty_editors"; //$NON-NLS-1$
    String SAVE_DIRTY_EDITORS_NEVER = "never"; //$NON-NLS-1$
    String SAVE_DIRTY_EDITORS_PROMPT = "prompt"; //$NON-NLS-1$
    String SAVE_DIRTY_EDITORS_AUTO = "auto"; //$NON-NLS-1$

    String EDIT_MANAGED = "edit_managed"; //$NON-NLS-1$
    String EDIT_MANAGED_CHECKOUT = "checkout"; //$NON-NLS-1$
    String EDIT_MANAGED_LOCAL = "local"; //$NON-NLS-1$
    String EDIT_MANAGED_PROMPT = "prompt"; //$NON-NLS-1$

    String EDIT_CHECKED_OUT = "edit_checked_out"; //$NON-NLS-1$
    String EDIT_CHECKED_OUT_EDIT = "edit"; //$NON-NLS-1$
    String EDIT_CHECKED_OUT_PROMPT = "prompt"; //$NON-NLS-1$

    String EDIT_UNMANAGED = "edit_unmanaged"; //$NON-NLS-1$
    String EDIT_UNMANAGED_EDIT = "edit"; //$NON-NLS-1$
    String EDIT_UNMANAGED_PROMPT = "prompt"; //$NON-NLS-1$

    String EXPAND_SUBSTITUTION = "expand_substitution"; //$NON-NLS-1$

    String AUTO_SHARE = "auto_share"; //$NON-NLS-1$

    /** a string value that controls whether project and baseline lists are shown in view or editor */
    String PROJECT_LIST_DISPLAY = "project_display"; //$NON-NLS-1$
    /** value for showing project and baseline list in a view */
    String PROJECT_LIST_DISPLAY_VIEW_VAL = "v"; //$NON-NLS-1$
    /** value for showing project and baseline list in an editor */
    String PROJECT_LIST_DISPLAY_EDITOR_VAL = "e"; //$NON-NLS-1$
    /** a boolean that controls whether project and baseline lists should be shown in a multi-page view or editor */
    String PROJECT_LIST_DISPLAY_MULTIPAGE = "project_display_multi"; //$NON-NLS-1$
    /** a boolean that controls whether project default view is raised automagically */
    String PROJECT_DEFAULT_AUTO_DISPLAY = "project_default_auto"; //$NON-NLS-1$
    /** a boolean that controls whether to auto-select default requests on checkout */
    String PRESELECT_DEFAULT_REQUESTS = "preselect_default_requests"; //$NON-NLS-1$
    /** a boolean that controls if we clean local file timestamps during refresh status and sync */
    String CLEAN_TIMESTAMPS = "clean_timestamps"; //$NON-NLS-1$
    /** a boolean to undo a checkout if attempt to checkin a file with no local mods */
    String UNDO_COUT_CIN_UNMODIFIED = "undo_cout_cin_umod"; //$NON-NLS-1$
    /** a boolean that controls if plugin will do auto-merge during update operation */
    String PROJECT_ALLOW_UPDATE_AUTO_MEGRE = "project_allow_update_auto_merge"; //$NON-NLS-1$
    String STREAM_ALLOW_UPDATE_AUTO_MEGRE = "stream_allow_update_auto_merge"; //$NON-NLS-1$

    String MAX_COMMENT_HISTORY_ENTRIES = "max_comment_history_entries"; //$NON-NLS-1$

    String SHOW_PROJECT_ON_COMMIT = "show_project_commit"; //$NON-NLS-1$

    /** whether to use activated or pending list during commit/checkout */
    String USE_ACTIVATED_REQUESTS = "use_activate_requests"; //$NON-NLS-1$

    /** whether to deactivated requests after successful commit/checkin */
    String DEACTIVATE_REQUESTS = "deactivate_requests"; //$NON-NLS-1$

    // merge options that should be shown in properties
    String MERGE3W_SHOW_INTERACTIVE_SWITCH_PROMPT = "3wmerge_show_interactive_switch_prompt"; //$NON-NLS-1$
    String MERGE3W_SHOW_STALE_RESULTS_WARNING = "3wmerge_show_stale_results_warning"; //$NON-NLS-1$
    String MERGE3W_REFRESH_HOME_RESULTS = "3wmerge_refresh_home_results"; //$NON-NLS-1$

    // merge options that should be hidden in properties
    String MERGE3W_DO_INTERACTIVE = "3wmerge_do_interactive"; //$NON-NLS-1$
    String MERGE3W_SHOW_ADVANCED_OPTIONS = "3wmerge_show_advanced_options"; //$NON-NLS-1$
    String MERGE3W_SHOW_NONINTERACTIVE_SUMMARY = "3wmerge_show_noninteractive_summary"; //$NON-NLS-1$
    String MERGE3W_APPLY_REPO_DATETIME = "3wmerge_apply_repo_datetime"; //$NON-NLS-1$
    String MERGE3W_ENABLE_LOGGING = "3wmerge_enable_logging"; //$NON-NLS-1$
    String MERGE3W_LOGGING_PATH = "3wmerge_logging_path"; //$NON-NLS-1$

    String MERGE3W_CHERRYPICK_CHANGES = "3wmerge_cherrypick_changes"; //$NON-NLS-1$
    String MERGE3W_REQUEST_INCLUDE_CHILD_REQUEST = "3wmerge_request_include_child_request"; //$NON-NLS-1$
}

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.internal.team.core.FileRequest;
import com.serena.eclipse.dimensions.internal.team.core.FolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Option;
import com.serena.eclipse.dimensions.internal.team.ui.Option.Value;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;

public class LockHelper extends TeamOperationWizardHelper {

    public LockHelper(IResource[] initialResources, IDMWorkspaceResourceFilter filter, IProgressMonitor monitor)
            throws CoreException {
        super(initialResources, filter, monitor);
        if (getClass().equals(LockHelper.class)) {
            initialize(monitor);
        }
    }

    @Override
    protected void populateMaps(Map<IResource, WorkspaceResourceRequest> requests, Map<IResource, IAttributeModel> attributes,
            IDMWorkspaceResource[] resources, IProgressMonitor monitor) throws CoreException {

        for (int i = 0; i < resources.length; i++) {
            if (resources[i].isContainer()) {
                requests.put(resources[i].getLocalResource(), new FolderRequest((IContainer) resources[i].getLocalResource()));
            } else {
                requests.put(resources[i].getLocalResource(), new FileRequest((IFile) resources[i].getLocalResource()) {

                    @Override
                    protected DimensionsResult execute(Session _session, IProgressMonitor monitor) throws Exception {
                        return new DimensionsResult("ok"); //$NON-NLS-1$
                    }

                    @Override
                    public int getKind() {
                        return UNKNOWN;
                    }
                });
            }
        }
    }

    @Override
    public boolean isRequestsSupported() {
        return false;
    }

    @Override
    public IResource[] getOperationResources() {
        return getOperationFiles();
    }

    @Override
    protected Option[] createOptions() {
        // Create placeholder tab
        Option[] result = new Option[1];
        result[0] = new Option("", "", new Value[] { new Value("") }, 0); //$NON-NLS-1$
        return result;
    }
}

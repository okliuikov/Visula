/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2012, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.IDimensionsWizardPage;
import com.serena.eclipse.dimensions.internal.ui.wizards.NewObjectWizard;

/**
 * Wizard page for entering new baseline information.
 *
 * @author V.Grishchenko
 *         Baseline only now
 *
 *         Modes Description
 *
 *         REVISED_BASELINE
 */

public class NewBaselineRevisePage extends DimensionsWizardPage implements IDimensionsWizardPage {
    // creation mode
    private int mode;

    private boolean initialized;

    private DimensionsConnectionDetailsEx connection;

    private Text updateRequestsText;
    private Button updateRequestsBtn;

    private Text removeRequestsText;
    private Button removeRequestsBtn;

    private Button traverseRequestBtn;

    private CLabel scopeLbl;
    private Button scopeFindBtn;
    private NewBaselineGeneralPage genPage;
    private Project scopingObject;

    /**
     * @param mode one of REVISED_BASELINE
     */
    public NewBaselineRevisePage(String pageName, String title, String description, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx connection, int mode, int options) {

        super(pageName, title, titleImage);
        setDescription(description);
        this.connection = connection;
        setMode(mode);
        setPageComplete(false); // not completed
    }

    public void refreshPage() {
        APIObjectAdapter bo = getGeneralPage().getBasedOnObject();
        setBasedOn(bo);
    }

    private NewBaselineGeneralPage getGeneralPage() {
        if (genPage == null) {
            genPage = (NewBaselineGeneralPage) getWizard().getPage(NewObjectWizard.GENERAL_PAGE);
        }
        return genPage;
    }

    /**
     * @param basedOnObject
     */
    private void setBasedOn(APIObjectAdapter basedOnObject) {
        if (basedOnObject != null) {
            // has to be a baseline
            assert basedOnObject instanceof BaselineAdapter;
            List parentWorksetList = basedOnObject.getAPIObject().getParentProjects(null);
            DimensionsRelatedObject dro = (parentWorksetList.size() == 1
                    ? (DimensionsRelatedObject) parentWorksetList.get(0) : null);
            if (dro != null) {
                scopingObject = (Project) dro.getObject();
            }
        } else {
            this.scopingObject = null;
        }
    }

    public void setMode(int mode) {
        Assert.isLegal((NewBaselineWizard.isRevisedBaseline(mode)) && mode != NewBaselineWizard.INVALID_MODE);
        if (this.mode == mode) {
            return;
        }
        this.mode = mode;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }

    }

    public List getUpdateRequests() {
        return Utils.fromCsvToList(UIUtils.safeGetText(updateRequestsText));
    }

    public List getRemoveRequests() {
        return Utils.fromCsvToList(UIUtils.safeGetText(removeRequestsText));
    }

    public Boolean getTraverseRequests() {
        // don't consider enabled
        return UIUtils.safeGetButton(traverseRequestBtn);
    }

    public String getScopingObject() {
        return UIUtils.safeGetClabel(scopeLbl);
    }

    /**
     * @param connection The connection to set.
     */
    @Override
    public void setConnection(DimensionsConnectionDetailsEx connection) {
        if (this.connection == connection || (this.connection != null && this.connection.equals(connection))) {
            return;
        }
        this.connection = connection;
        initialized = false;
        if (getControl() != null && getControl().isVisible()) {
            initializeValues();
        }
    }

    @Override
    public void setVisible(boolean visible) {
        refreshPage();
        updateScopeLabel();
        if (visible && !initialized) {
            initializeValues();
        }
        super.setVisible(visible);
    }

    @Override
    public void createControl(Composite parent) {

        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 4);

        // add a related requests
        UIUtils.createLabel(composite, Messages.newBaselineRevisePage_updateRequestsLabel);
        updateRequestsText = new Text(composite, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(updateRequestsText, GridData.FILL_HORIZONTAL, 2);
        updateRequestsText.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                checkPage();
            }
        });
        updateRequestsBtn = new Button(composite, SWT.PUSH);
        updateRequestsBtn.setText(Messages.ProjectSelectionPanel_launchFind);

        final String selectedProduct = getGeneralPage().getProductName();
        updateRequestsBtn.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                // open the find request wizard
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.CHANGEDOCUMENT,
                        connection, selectedProduct, false, false);
                if (dialog.open() == Window.OK) {
                    List<String> requests = dialog.getSelectedNames();
                    updateRequestsText.setText(Utils.listToString(requests, false));
                    checkPage();
                }
            }
        });

        UIUtils.createLabel(composite, Messages.newBaselineRevisePage_removeRequestsLabel);
        removeRequestsText = new Text(composite, SWT.SINGLE | SWT.BORDER);
        UIUtils.setGridData(removeRequestsText, GridData.FILL_HORIZONTAL, 2);
        removeRequestsText.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                checkPage();
            }
        });
        removeRequestsBtn = new Button(composite, SWT.PUSH);
        removeRequestsBtn.setText(Messages.ProjectSelectionPanel_launchFind);
        removeRequestsBtn.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                // open the find Part Wizardxx
                FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.CHANGEDOCUMENT,
                        connection, selectedProduct, false, false);
                if (dialog.open() == Window.OK) {
                    List<String> requests = dialog.getSelectedNames();
                    removeRequestsText.setText(Utils.listToString(requests, false));
                    checkPage();
                }
            }
        });

        traverseRequestBtn = new Button(composite, SWT.CHECK);
        traverseRequestBtn.setText(Messages.newBaselineRelatePage_traverseLabel);
        GridData data = new GridData(SWT.BEGINNING, SWT.CENTER, true, false, 2, 1);
        data.verticalIndent = 5;
        traverseRequestBtn.setLayoutData(data);
        traverseRequestBtn.setEnabled(true);
        traverseRequestBtn.setSelection(false);
        UIUtils.createLabel(composite, null);
        UIUtils.createLabel(composite, null);

        Label spacer2 = UIUtils.createLabel(composite, null);
        UIUtils.setGridData(spacer2, GridData.FILL_HORIZONTAL, 4);

        UIUtils.createLabel(composite, getScopeObjectLabel());
        scopeLbl = new CLabel(composite, SWT.BORDER | SWT.READ_ONLY);
        UIUtils.setGridData(scopeLbl, GridData.FILL_HORIZONTAL, 2);
        updateScopeLabel();
        scopeFindBtn = new Button(composite, SWT.PUSH);
        scopeFindBtn.setText(Messages.ProjectSelectionPanel_launchFind);
        scopeFindBtn.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                find();
            }
        });
        setControl(composite);
    }

    private String getScopeObjectLabel() {
        return Messages.newBaselineRevisePage_scope;
    }

    private void updateScopeLabel() {
        if (scopingObject != null && scopeLbl != null) {
            scopeLbl.setText(scopingObject.getName());
        }
    }

    @Override
    public void dispose() {
        super.dispose();
    }

    private void find() {
        if (connection == null) {
            return;
        }

        FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), IDMConstants.PROJECT, connection, null, true, false,
                connection.isOnlyStreamsActive(), connection.isOnlyProjectsActive());

        if (Window.OK == dialog.open() && !dialog.getFindResult().isEmpty()) {

            Object object = dialog.getFindResult().getObjects().get(0);
            if (!(object instanceof Project)) {
                return;
            }

            scopingObject = (Project) object;
            updateScopeLabel();
            checkPage();
        }
    }

    private void initializeValues() {
        initialized = true;
    }

    // have to have requests
    private boolean checkHaveRequests() {
        if ((getUpdateRequests().size() == 0) && (getRemoveRequests().size() == 0)) {
            setErrorMessage(Messages.newBaselineRevisePage_norequests);
            return false;
        }
        return true;
    }

    private void checkPage() {
        setPageComplete(false);
        if (checkHaveRequests()) {
            setPageComplete(true);
            setErrorMessage(null);
        }

    }
}

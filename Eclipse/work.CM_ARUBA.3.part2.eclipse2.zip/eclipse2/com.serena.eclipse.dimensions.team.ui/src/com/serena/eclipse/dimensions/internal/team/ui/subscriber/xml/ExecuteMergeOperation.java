/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.MultiRule;
import org.eclipse.jface.action.IAction;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.dmclient.api.MergeCommonCommandDetails;
import com.serena.dmfile.dto.Pair;
import com.serena.dmfile.sync.SyncMode;
import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.dmfile.xml.Resolution;
import com.serena.dmfile.xml.UserResolution;
import com.serena.dmfile.xml.UserResolutionsContainer;
import com.serena.dmfile.xml.utility.NonConsecutiveCherrypickUtility;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLMergeSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLWorkspaceMergeCommand;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.ShowDetailsAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Operation that invokes merge in execute mode. Handles a full update and update of user selection.
 * If resolution is out from selection scope than it treats as ignored resolution.
 */
public class ExecuteMergeOperation extends SynchronizeModelOperation {
    private IWorkbenchPart part;
    private XMLMergeParticipant participant;
    private XMLMergeSubscriber subscriber;
    private ShowDetailsAction showDetailsAction;
    private List<IStatus> errors;
    private List<XMLMergeDescriptor> scope;
    private Set<XMLSyncInfo> subset;

    private final boolean applyAll;
    private final boolean applySelected;

    /**
     * Operation that executes merge from sync view
     * 
     * @param configuration
     * @param elements
     * @param updateAll
     *            true if all nodes ought to be updated
     */
    public ExecuteMergeOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements, boolean updateAll) {
        super(configuration, elements);
        this.part = configuration.getSite().getPart();
        this.participant = (XMLMergeParticipant) configuration.getParticipant();
        this.subscriber = (XMLMergeSubscriber) participant.getSubscriber();
        this.errors = new ArrayList<IStatus>();
        this.showDetailsAction = new ShowDetailsAction();
        this.showDetailsAction.setShell(getShell());

        if (updateAll) {
            this.scope = subscriber.getDescriptorsContainer().getNonEmptyDescriptors();
            applyAll = true;
            applySelected = false;
        } else {
            this.scope = new ArrayList<XMLMergeDescriptor>();
            applyAll = false;
            applySelected = true;
            this.subset = new HashSet<XMLSyncInfo>();
            for (SyncInfo info : getSyncInfoSet().getSyncInfos()) {
                if (info instanceof XMLSyncInfo) {
                    XMLSyncInfo xinfo = (XMLSyncInfo) info;
                    subset.add(xinfo);
                    XMLMergeDescriptor descr = xinfo.getDescriptor();
                    if (!scope.contains(descr)) {
                        scope.add(descr);
                    }
                }
            }
        }
    }

    @Override
    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
        clearErrors();
        ISchedulingRule rule = getSchedulingRule();

        Set<XMLSyncInfo> subsetWithFolders = null;
        if (applySelected) {
            subsetWithFolders = new HashSet<XMLSyncInfo>(subset);
        }
        Set<IProject> projectsToDelete = new HashSet<IProject>();
        
        try {
            Job.getJobManager().beginRule(rule, monitor);
            monitor.beginTask(null, scope.size() * 100);

            subscriber.getDescriptorsContainer().setInUse(true);

            for (XMLMergeDescriptor descr : scope) {
                try {
                    Set<UserResolution> userResolutions = new TreeSet<UserResolution>();
                    Map<Resolution, XMLSyncInfo> resolutionToInfo = descr.getResolutionToInfo();

                    Set<Pair<Resolution, XMLSyncInfo>> selectedPairs = new HashSet<Pair<Resolution, XMLSyncInfo>>();
                    Map<Resolution, XMLSyncInfo> resolutionToFolderInfo = new HashMap<Resolution, XMLSyncInfo>();

                    // for all incoming server resolutions create corresponding user resolution
                    for (Entry<Resolution, XMLSyncInfo> entry : resolutionToInfo.entrySet()) {
                        Resolution resolution = entry.getKey();
                        XMLSyncInfo info = entry.getValue();

                        UserResolution ures = null;
                        if (applyAll || subset.contains(info)) {
                            // apply all or apply selected
                            ures = createUserResolution(info.getCurrentAction(), info, resolution);
                            XMLWorkspaceMergeCommand.addProjectsToDelete(info, projectsToDelete);
                        } else {
                            // ignore unselected otherwise
                            ures = createUserResolution(XSyncUserAction.SUAL_IGNORE.value(), info, resolution);
                        }

                        if (applySelected) {
                            // collect all selected, not ignored resolutions and not local resolutions.
                            // Resolution with local path can be processed without parent directories.
                            if (ures.getUserAction().intValue() != XSyncUserAction.SUAL_IGNORE.value()
                                    && info.getCurrentActionDirection() != XSyncUserAction.SUAO_USE_LOCAL_PATH) {
                                selectedPairs.add(new Pair<Resolution, XMLSyncInfo>(resolution, info));
                            }

                            // collect all folders
                            if (!resolution.isFileResolution()) {
                                resolutionToFolderInfo.put(resolution, info);
                            }
                        }

                        if (resolution.isFileResolution() && ures.getUserAction().intValue() != XSyncUserAction.SUAL_IGNORE.value()) {
                            if (XMLSyncInfo.hasMergeOption(ures.getUserAction())) {
                                // try to install merged file
                                URI mergedFile = null;

                                IFileStore store = info.getDescriptor().getTempStore(info);
                                if (store != null) {
                                    mergedFile = store.toURI();
                                } else {
                                    IResource resource = info.getLocalResource();
                                    if (resource != null) {
                                        mergedFile = resource.getLocationURI();
                                    }
                                }

                                File mergedF = new File(mergedFile);
                                Assert.isLegal(mergedF.exists(), NLS.bind(Messages.DMXMLMergeOperation_assert_access, mergedFile));
                                ures.setMergedFile(mergedF.getAbsolutePath());
                            }
                        }

                        userResolutions.add(ures);
                    }

                    if (applySelected) {
                        // collect all parent resolutions for selected pairs
                        for (Pair<Resolution, XMLSyncInfo> selectedPair : selectedPairs) {
                            IResource selected = selectedPair.getSecond().getLocal();

                            for (Iterator<Entry<Resolution, XMLSyncInfo>> iterator = resolutionToFolderInfo.entrySet().iterator(); iterator.hasNext();) {
                                Entry<Resolution, XMLSyncInfo> entry = iterator.next();
                                Resolution resolution = entry.getKey();
                                XMLSyncInfo info = entry.getValue();
                                IResource parentCandidate = info.getLocal();

                                // check if folder is a parent of selected
                                if (parentCandidate.getFullPath().isPrefixOf(selected.getFullPath())) {
                                    UserResolution ures = createUserResolution(info.getCurrentAction(), info, resolution);
                                    if (!userResolutions.add(ures)) {
                                        userResolutions.remove(ures);
                                        userResolutions.add(ures);
                                        subsetWithFolders.add(info);
                                    }
                                    iterator.remove();
                                }
                            }
                        }
                    }

                    UserResolutionsContainer ucon = new UserResolutionsContainer();
                    ucon.setResolutions(userResolutions);
                    ucon.setVersion("14.1");//$NON-NLS-1$

                    MergeCommonCommandDetails det = descr.getCommandDetails();
                    det.setUserResolutionsContainer(ucon);

                    descr.setCurrentMode(SyncMode.EXECUTE_RESOLUTIONS);

                    descr.getTarget().download(descr, Utils.subMonitorFor(monitor, 100));
                } catch (CoreException e) {
                    errors.add(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
                }

                if (monitor.isCanceled()) {
                    break;
                }
            }

            if (hasErrors()) {
                handleErrors();
            }
        } catch (TeamException e) {
            throw new InvocationTargetException(e);
        } finally {
            if (applySelected) {
                subscriber.setApplySelectedChangesScope(subsetWithFolders);
            }
            for (IProject currentProject : projectsToDelete) {
                try {
                    currentProject.delete(false, true, null);
                } catch (CoreException e) {
                    DMTeamPlugin.log(e.getStatus());
                }
            }
            participant.clean(part);
            monitor.done();
            Job.getJobManager().endRule(rule);

            XMLMergeUIUtils.syncWithHome(subscriber.getDescriptorsContainer(), part, true);
        }
    }

    /**
     * Sets current action from node to the output
     * 
     * @param action
     *            current action
     * @param info
     *            node info
     * @param ures
     *            output
     * @throws CoreException
     */
    private static UserResolution createUserResolution(Integer action, XMLSyncInfo info, Resolution resolution)
            throws CoreException {
        Assert.isNotNull(action);
        Assert.isNotNull(info);
        Assert.isNotNull(resolution);

        UserResolution ures = new UserResolution();
        ures.setId(resolution.getId());

        if (!resolution.isConsecutive() && !resolution.isRoot() && !resolution.isLeaf()) {
            Resolution rootResolution = NonConsecutiveCherrypickUtility.getRootResolution(resolution);
            Resolution mostRecentResolution = NonConsecutiveCherrypickUtility.getMostRecentResolution(rootResolution);
            boolean isAutomerged = NonConsecutiveCherrypickUtility.isResolutionTreeAutomerged(rootResolution);
            
            boolean hasRootMergeFileChanged = true;
            String curMergedFile = resolution.getMergedFile();
            String mostRecentMergedFile = mostRecentResolution.getMergedFile();
            if (mostRecentMergedFile != null && !mostRecentMergedFile.isEmpty() && curMergedFile != null && !curMergedFile.isEmpty()) {
                File mostRecentFile = new File(mostRecentMergedFile);
                File curFile = new File(curMergedFile);
                if (mostRecentFile.exists() && curFile.exists()) {
                    if (Math.abs(mostRecentFile.lastModified() - curFile.lastModified()) < 1000) {
                        hasRootMergeFileChanged = false;
                    }
                }
            }
            
            // If all resolutions were not successfully automerged, all child resolution (except for the latest (leaf)) are ignored.
            if (!isAutomerged || hasRootMergeFileChanged) {
                action = XSyncUserAction.SUAL_IGNORE.value();
            }
        }

        if (!info.hasAction(action)) {
            action = XSyncUserAction.SUAL_IGNORE.value();
        }

        ures.setUserAction(action);

        return ures;
    }

    @Override
    protected ISchedulingRule getSchedulingRule() {
        Set<IResource> rules = new HashSet<IResource>();

        for (XMLMergeDescriptor descr : scope) {
            IProject rootProject = descr.getTarget().getProject();
            Set<IProject> projects = TeamUtils.getAllProjectsForLocation(rootProject);
            rules.addAll(projects);
        }

        return new MultiRule(rules.toArray(new IResource[rules.size()]));
    }

    @Override
    protected final IAction getGotoAction() {
        return showDetailsAction;
    }

    private void clearErrors() {
        showDetailsAction.setDetails(null);
        errors.clear();
    }

    private void handleErrors() throws TeamException {
        if (hasErrors()) {
            IStatus status = null;
            if (errors.size() == 1) {
                status = errors.get(0);
            } else {
                boolean doUpdate = subscriber.getDescriptorsContainer().getMergeOptions().isDoUpdate();
                String msg = doUpdate ? Messages.DMXMLUpdateOperation_errorMsg : Messages.DMXMLMergeOperation_errorMsg;
                status = new MultiStatus(DMTeamUiPlugin.ID, IStatus.ERROR, errors.toArray(new IStatus[errors.size()]), msg, null);
            }

            StringBuilder sb = new StringBuilder();
            for (IStatus error : errors) {
                sb.append(error.getMessage());
            }

            showDetailsAction.setDetails(sb.toString());
            throw new TeamException(status);
        }
    }

    private boolean hasErrors() {
        return errors != null && errors.size() > 0;
    }

}

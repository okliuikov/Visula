/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;

/**
 * @author V.Grishchenko
 */
public class AddMultipleProjectsToWorkspaceOperation extends AddProjectToWorkspaceOperation {

    public AddMultipleProjectsToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects, String targetLocation) {
        super(part, remoteObjects, targetLocation);
        setInvolvesMultipleResources(remoteObjects.length > 1);
    }

    public AddMultipleProjectsToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects,
            ProjectMapping[] mappings, String targetLocation) {
        super(part, remoteObjects, mappings, targetLocation);
        setInvolvesMultipleResources(remoteObjects.length > 1);
    }

    @Override
    protected IStatus addToWorkspace(ProjectMapping mapping, IProgressMonitor monitor) throws CoreException {
        return addToWorkspace(mapping, null, monitor);
    }

    @Override
    protected IPath getTargetLocationFor(ProjectMapping mapping, IProject project) {
        IPath targetLocation = super.getTargetLocationFor(mapping, project);
        if (targetLocation == null) {
            return null;
        }
        if (mapping.getRemoteProject() instanceof SccProject) {
            return targetLocation.append(((SccProject) mapping.getRemoteProject()).getOffset());
        }
        return targetLocation.append(project.getName());
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IScopeContext;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.osgi.service.prefs.BackingStoreException;
import org.osgi.service.prefs.Preferences;

import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class DimensionsStreamPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage,
        IDMTeamPreferences {

    public DimensionsStreamPreferencePage() {
        super(GRID);
        setDescription(Messages.streamPrefPage_descr);
        setPreferenceStore(DMTeamUiPlugin.getDefault().getPreferenceStore());
    }

    @Override
    protected void createFieldEditors() {
        addField(new BooleanFieldEditor(STREAM_ALLOW_UPDATE_AUTO_MEGRE, Messages.streamPrefPage_allowUpdateAutoMerge,
                getFieldEditorParent()));

        addField(new BooleanFieldEditor(MERGE3W_REFRESH_HOME_RESULTS, Messages.streamPrefPage_auto_homesync, getFieldEditorParent()));

        addField(new BooleanFieldEditor(MERGE3W_SHOW_INTERACTIVE_SWITCH_PROMPT, Messages.streamPrefPage_switch_dialog,
                getFieldEditorParent()));

        addField(new BooleanFieldEditor(MERGE3W_SHOW_STALE_RESULTS_WARNING, Messages.streamPrefPage_user_changes_dialog,
                getFieldEditorParent()));
    }

    @Override
    public void init(IWorkbench workbench) {
    }

    @Override
    public boolean performOk() {
        boolean ok = super.performOk();
        IEclipsePreferences preferences = InstanceScope.INSTANCE.getNode(DMTeamUiPlugin.ID);
        try {
            preferences.flush();
        } catch (BackingStoreException e) {
            DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
            return false;
        }
        return ok;
    }

    public static boolean setAutoMergePreference(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.STREAM_ALLOW_UPDATE_AUTO_MEGRE, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setDoInteractivePreference(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.MERGE3W_DO_INTERACTIVE, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setShowAdvancedPreference(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.MERGE3W_SHOW_ADVANCED_OPTIONS, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setShowSummaryPreference(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.MERGE3W_SHOW_NONINTERACTIVE_SUMMARY, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setApplyRepoDateTimePreference(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.MERGE3W_APPLY_REPO_DATETIME, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setEnableLoggingPreference(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.MERGE3W_ENABLE_LOGGING, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setLoggingFolderPreference(String value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.put(IDMTeamPreferences.MERGE3W_LOGGING_PATH, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setCherrypick(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.MERGE3W_CHERRYPICK_CHANGES, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean setIncludeChildRequsts(boolean value) {
        IScopeContext instanceContext = InstanceScope.INSTANCE;
        IEclipsePreferences instanceNode = instanceContext.getNode(TeamUtils.TEAM_UI_PLUGIN_PREFERENCE);
        if (instanceNode != null) {
            instanceNode.putBoolean(IDMTeamPreferences.MERGE3W_REQUEST_INCLUDE_CHILD_REQUEST, value);
        }
        return saveNode(instanceNode);
    }

    public static boolean saveNode(Preferences node) {
        try {
            node.flush();
            return true;
        } catch (BackingStoreException e) {
            return false;
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2007, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;

import org.eclipse.osgi.util.NLS;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * Provides main page description containing commit details.
 * @author V.Grishchenko
 */
public class CommitWizard extends TeamOperationWizard {

    public CommitWizard(TeamOperationWizardHelper helper, boolean needsProgress) {
        super(helper, needsProgress);
    }

    @Override
    protected String getMainPageDescription() {
        if (!(getHelper() instanceof ICommitSummary)) {
            return super.getMainPageDescription();
        }
        ICommitSummary statistics = (ICommitSummary) getHelper();

        ArrayList<String> kinds = new ArrayList<String>();

        int acnt = statistics.getAdditionCount();
        if (acnt > 0) {
            if (acnt == 1) {
                kinds.add(NLS.bind(Messages.CommitWizard_1, String.valueOf(acnt)));
            } else {
                kinds.add(NLS.bind(Messages.CommitWizard_2, String.valueOf(acnt)));
            }
        }

        int ccnt = statistics.getCheckinCount();
        if (ccnt > 0) {
            if (ccnt == 1) {
                kinds.add(NLS.bind(Messages.CommitWizard_3, String.valueOf(ccnt)));
            } else {
                kinds.add(NLS.bind(Messages.CommitWizard_4, String.valueOf(ccnt)));
            }
        }

        int ocnt = statistics.getOptimisticCheckinCount();
        if (ocnt > 0) {
            if (ocnt == 1) {
                kinds.add(NLS.bind(Messages.CommitWizard_5, String.valueOf(ocnt)));
            } else {
                kinds.add(NLS.bind(Messages.CommitWizard_6, String.valueOf(ocnt)));
            }
        }

        int dcnt = statistics.getDeletionCount();
        if (dcnt > 0) {
            if (dcnt == 1) {
                kinds.add(NLS.bind(Messages.CommitWizard_7, String.valueOf(dcnt)));
            } else {
                kinds.add(NLS.bind(Messages.CommitWizard_8, String.valueOf(dcnt)));
            }
        }

        int mcnt = statistics.getMoveCount();
        if (mcnt > 0) {
            if (mcnt == 1) {
                kinds.add(NLS.bind(Messages.CommitWizard_9, String.valueOf(mcnt)));
            } else {
                kinds.add(NLS.bind(Messages.CommitWizard_10, String.valueOf(mcnt)));
            }
        }

        if (!kinds.isEmpty()) {
            return NLS.bind(Messages.CommitWizard_11, Utils.toCsvString(kinds.toArray(new String[kinds.size()]), true));
        }

        return super.getMainPageDescription();
    }

}

/*
 * @FilePropertyPage.java, created on 31-Mar-2006
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.views;

import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.util.Date;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.team.core.TeamException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.PropertyPage;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author bstephenson
 */
public class FilePropertyPage extends PropertyPage {
    private IResource theFile;
    private IDMWorkspaceFile dmFile;

    private Text remtPathTxt;
    private Text baseRevTxt;
    private Text remtRevTxt;
    private Text baseIdTxt;
    private Text remtIdTxt;
    private Text baseTstampTxt;
    private Text modifiedTxt;
    private Text coTxt;
    private Text coMultiTxt;
    private Text coOtherTxt;
    private Text coExclusiveTxt;
    private Text movedFromPathTxt;
    private Text movedFromProjTxt;
    private Text mergedFromTxt;
    private Text isLockedTxt;
    private Text lockUserTxt;
    private Text lockedDateTxt;
    private Button refreshBtn;

    public FilePropertyPage() {
    }

    @Override
    protected Control createContents(Composite parent) {
        noDefaultAndApplyButton();
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 2);

        theFile = getFile();
        if (theFile == null) {
            return composite;
        }

        try {
            dmFile = (IDMWorkspaceFile) DMTeamPlugin.getWorkspace().getWorkspaceResource(theFile);
            if (dmFile == null) {
                return composite; // shouldn't happen as if we are called project has dimenions as a team provider
            }
            if (dmFile.isIgnored()) {
                Label ignoredLbl = UIUtils.createLabel(composite, Messages.FilePropertyPage_ignored);
                UIUtils.setGridData(ignoredLbl, GridData.FILL_HORIZONTAL, 2);
            } else if (!dmFile.isManaged()) {
                Label unmanagedLbl = UIUtils.createLabel(composite, Messages.FilePropertyPage_unmanaged);
                UIUtils.setGridData(unmanagedLbl, GridData.FILL_HORIZONTAL, 2);
            } else {
                createFields(composite);
                fillValues(dmFile.getBaseFile(), dmFile.getRemoteFile());
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);
        }
        return composite;
    }

    private void createFields(Composite composite) {
        // remote path
        UIUtils.createLabel(composite, Messages.FilePropertyPage_repoPath);
        remtPathTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(remtPathTxt, GridData.FILL_HORIZONTAL);

        // base revision
        UIUtils.createLabel(composite, Messages.FilePropertyPage_baseRev);
        baseRevTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(baseRevTxt, GridData.FILL_HORIZONTAL);

        // remote revision
        UIUtils.createLabel(composite, Messages.FilePropertyPage_remtRev);
        remtRevTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(remtRevTxt, GridData.FILL_HORIZONTAL);

        // base id
        UIUtils.createLabel(composite, Messages.FilePropertyPage_baseId);
        baseIdTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(baseIdTxt, GridData.FILL_HORIZONTAL);

        // remote id
        UIUtils.createLabel(composite, Messages.FilePropertyPage_remtId);
        remtIdTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(remtIdTxt, GridData.FILL_HORIZONTAL);

        // base tstamp
        UIUtils.createLabel(composite, Messages.FilePropertyPage_baseTstamp);
        baseTstampTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(baseTstampTxt, GridData.FILL_HORIZONTAL);

        // modified
        UIUtils.createLabel(composite, Messages.FilePropertyPage_modified);
        modifiedTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(modifiedTxt, GridData.FILL_HORIZONTAL);

        // checked out
        UIUtils.createLabel(composite, Messages.FilePropertyPage_co);
        coTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(coTxt, GridData.FILL_HORIZONTAL);

        // checked out multiple
        UIUtils.createLabel(composite, Messages.FilePropertyPage_coMultiple);
        coMultiTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(coMultiTxt, GridData.FILL_HORIZONTAL);

        // checked out other
        UIUtils.createLabel(composite, Messages.FilePropertyPage_coOther);
        coOtherTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(coOtherTxt, GridData.FILL_HORIZONTAL);

        // exclusive co
        UIUtils.createLabel(composite, Messages.FilePropertyPage_coExclusive);
        coExclusiveTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(coExclusiveTxt, GridData.FILL_HORIZONTAL);

        // moved from path
        UIUtils.createLabel(composite, Messages.FilePropertyPage_movedFromPath);
        movedFromPathTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(movedFromPathTxt, GridData.FILL_HORIZONTAL);

        // moved from proj
        UIUtils.createLabel(composite, Messages.FilePropertyPage_movedFromProj);
        movedFromProjTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(movedFromProjTxt, GridData.FILL_HORIZONTAL);

        // merged from
        UIUtils.createLabel(composite, Messages.FilePropertyPage_mergedFrom);
        mergedFromTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(mergedFromTxt, GridData.FILL_HORIZONTAL);

        // is locked
        UIUtils.createLabel(composite, Messages.FilePropertyPage_locked);
        isLockedTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(isLockedTxt, GridData.FILL_HORIZONTAL);

        // locked by
        UIUtils.createLabel(composite, Messages.FilePropertyPage_lockedBy);
        lockUserTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(lockUserTxt, GridData.FILL_HORIZONTAL);

        // locked datetime
        UIUtils.createLabel(composite, Messages.FilePropertyPage_lockedDate);
        lockedDateTxt = UIUtils.createText(composite, SWT.WRAP | SWT.READ_ONLY, null);
        UIUtils.setGridData(lockedDateTxt, GridData.FILL_HORIZONTAL);

        UIUtils.createLabel(composite, null); // spacer
        UIUtils.createLabel(composite, null); // spacer

        // refresh btn
        refreshBtn = new Button(composite, SWT.PUSH);
        refreshBtn.setEnabled(!dmFile.getProject().getConnection().isOffline());
        refreshBtn.setText(Messages.FilePropertyPage_refresh);
        refreshBtn.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                refresh();
            }
        });
        UIUtils.createLabel(composite, null); // spacer
    }

    protected void refresh() {
        try {
            PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    try {
                        DMTeamPlugin.getWorkspace()
                                .getSubscriber()
                                .refresh(new IResource[] { theFile }, IResource.DEPTH_INFINITE, monitor);
                    } catch (TeamException e) {
                        throw new InvocationTargetException(e);
                    }
                }
            });
            fillValues(dmFile.getBaseFile(), dmFile.getRemoteFile());
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        } catch (InterruptedException e) {
        } catch (TeamException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }
    }

    private IFile getFile() {
        IAdaptable adaptableElement = getElement();
        if (adaptableElement instanceof IFile) {
            return (IFile) adaptableElement;
        }
        return (IFile) adaptableElement.getAdapter(IFile.class);
    }

    private String getBooleanText(boolean b) {
        if (b) {
            return Messages.FilePropertyPage_true;
        }
        return Messages.FilePropertyPage_false;
    }

    private void fillValues(IDMRemoteFile base, IDMRemoteFile remote) throws TeamException {
        boolean checkedOut = false;
        remtPathTxt.setText(UIUtils.getDisplayText(dmFile.getProject().getRemotePathForLocalResource(theFile).toString()));
        if (base != null) {
            baseRevTxt.setText(base.getRevision());
            baseIdTxt.setText(base.getItemSpec());
            baseTstampTxt.setText(DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL).format(
                    new Date(base.getModtime())));
            checkedOut = base.isExtracted();
            coTxt.setText(getBooleanText(checkedOut));
            movedFromPathTxt.setText(UIUtils.getDisplayText(base.getMovedFromPath()));
            movedFromProjTxt.setText(UIUtils.getDisplayText(base.getMovedFromProject()));
            mergedFromTxt.setText(UIUtils.getDisplayText(Utils.toCsvString(base.getMergedFromRevisions(), true)));
        }

        if (remote != null) {
            remtRevTxt.setText(remote.getRevision());
            remtIdTxt.setText(remote.getItemSpec());
            coMultiTxt.setText(getBooleanText(remote.isMultiExtracted()));
            coOtherTxt.setText(getBooleanText((!checkedOut && remote.isAnyExtracted()) || remote.isMultiExtracted()));
            coExclusiveTxt.setText(getBooleanText(remote.isExtractedExclusive()));

            isLockedTxt.setText(getBooleanText(remote.isLocked()));
            lockUserTxt.setText(UIUtils.getDisplayText(remote.getLockUser()));
            lockedDateTxt.setText(UIUtils.getDisplayText(remote.getLockDate()));

        }
        modifiedTxt.setText(getBooleanText(dmFile.isModified()));
    }

}

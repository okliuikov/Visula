/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import java.util.Arrays;

import org.eclipse.jface.resource.CompositeImageDescriptor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Point;

/**
 * An DecoratorOverlayIcon consists of a main icon and several adornments.
 */
public class OverlayIcon extends CompositeImageDescriptor {
    // the base image
    private Image base;
    // the overlay images
    private ImageDescriptor[] overlays;
    // the size
    private Point size;

    public static final int TOP_LEFT = 0;
    public static final int TOP_RIGHT = 1;
    public static final int BOTTOM_LEFT = 2;
    public static final int BOTTOM_RIGHT = 3;

    /**
     * OverlayIcon constructor.
     *
     * @param base the base image
     * @param overlays the overlay images
     * @param locations the location of each image
     * @param size the size
     */
    public OverlayIcon(Image baseImage, ImageDescriptor[] overlaysArray, Point sizeValue) {
        this.base = baseImage;
        this.overlays = overlaysArray;
        this.size = sizeValue;
    }

    /**
     * Draw the overlays for the reciever.
     */
    protected void drawOverlays(ImageDescriptor[] overlaysArray) {

        for (int i = 0; i < overlays.length; i++) {
            ImageDescriptor overlay = overlaysArray[i];
            if (overlay == null) {
                continue;
            }
            ImageData overlayData = overlay.getImageData();
            // Use the missing descriptor if it is not there.
            if (overlayData == null) {
                overlayData = ImageDescriptor.getMissingImageDescriptor().getImageData();
            }
            switch (i) {
            case TOP_LEFT:
                drawImage(overlayData, 0, 0);
                break;
            case TOP_RIGHT:
                drawImage(overlayData, size.x - overlayData.width, 0);
                break;
            case BOTTOM_LEFT:
                drawImage(overlayData, 0, size.y - overlayData.height);
                break;
            case BOTTOM_RIGHT:
                drawImage(overlayData, size.x - overlayData.width, size.y - overlayData.height);
                break;
            }
        }
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof OverlayIcon)) {
            return false;
        }
        OverlayIcon other = (OverlayIcon) o;
        return base.equals(other.base) && Arrays.equals(overlays, other.overlays);
    }

    @Override
    public int hashCode() {
        int code = base.hashCode();
        for (int i = 0; i < overlays.length; i++) {
            if (overlays[i] != null) {
                code ^= overlays[i].hashCode();
            }
        }
        return code;
    }

    @Override
    protected void drawCompositeImage(int width, int height) {
        drawImage(base.getImageData(), 0, 0);
        drawOverlays(overlays);
    }

    @Override
    protected Point getSize() {
        return size;
    }

}
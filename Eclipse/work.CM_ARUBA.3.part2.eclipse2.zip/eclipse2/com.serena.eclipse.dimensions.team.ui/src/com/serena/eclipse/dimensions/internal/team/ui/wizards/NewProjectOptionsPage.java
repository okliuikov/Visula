/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizardPage;

public class NewProjectOptionsPage extends DimensionsWizardPage {
    private String basedOnSpec;

    private Button btnBranch;
    private Button btnNotBranch;
    private Button btnOverrideRevNum;

    private Button btnCMRuleDefault;
    private Button btnCMRulesOn;
    private Button btnCMRulesOff;
    private Button btnRequestRequred;

    public NewProjectOptionsPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(description);

    }

    @Override
    public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        UIUtils.setGridLayout(composite, 1);

        Group grpVM = new Group(composite, SWT.NONE);
        grpVM.setText(Messages.NewStreamWizard_project_options_lblVMOptions);
        UIUtils.setGridLayout(grpVM, 1);
        UIUtils.setGridData(grpVM, GridData.FILL_HORIZONTAL);
        UIUtils.createLabel(grpVM, Messages.NewStreamWizard_project_options_lblVMDescr);
        Composite cmpBranch = new Composite(grpVM, SWT.NONE);
        UIUtils.setGridLayout(cmpBranch, 2);
        UIUtils.setGridData(cmpBranch, GridData.FILL_HORIZONTAL);
        btnBranch = new Button(cmpBranch, SWT.RADIO);
        btnBranch.setText(Messages.NewStreamWizard_project_options_btnBranch);
        UIUtils.setGridData(btnBranch, GridData.FILL_HORIZONTAL);
        btnBranch.addPaintListener(new PaintListener() {
            @Override
            public void paintControl(PaintEvent e) {
                checkPage();
            }
        });
        btnNotBranch = new Button(cmpBranch, SWT.RADIO);
        btnNotBranch.setText(Messages.NewStreamWizard_project_options_btnNotBranch);
        btnNotBranch.setSelection(true);
        UIUtils.setGridData(btnNotBranch, GridData.FILL_HORIZONTAL);
        btnOverrideRevNum = new Button(grpVM, SWT.CHECK);
        btnOverrideRevNum.setText(Messages.NewStreamWizard_project_options_btnOverrideRevNum);
        UIUtils.setGridData(btnOverrideRevNum, GridData.FILL_HORIZONTAL);

        Group grpCM = new Group(composite, SWT.NONE);
        grpCM.setText(Messages.NewStreamWizard_project_options_lblCMRules);
        UIUtils.setGridLayout(grpCM, 1);
        UIUtils.setGridData(grpCM, GridData.FILL_HORIZONTAL);
        UIUtils.createLabel(grpCM, Messages.NewStreamWizard_project_options_lblCMDescr);
        Composite cmpItemTypeSet = new Composite(grpCM, SWT.NONE);
        UIUtils.setGridLayout(cmpItemTypeSet, 3);
        UIUtils.setGridData(cmpItemTypeSet, GridData.FILL_HORIZONTAL);
        btnCMRuleDefault = new Button(cmpItemTypeSet, SWT.RADIO);
        btnCMRuleDefault.setText(Messages.NewStreamWizard_project_options_btnUseItem);
        btnCMRuleDefault.setSelection(true);
        UIUtils.setGridData(cmpItemTypeSet, GridData.FILL_HORIZONTAL);
        btnCMRulesOn = new Button(cmpItemTypeSet, SWT.RADIO);
        btnCMRulesOn.setText(Messages.NewStreamWizard_project_options_btnAlwaysEnable);
        UIUtils.setGridData(cmpItemTypeSet, GridData.FILL_HORIZONTAL);
        btnCMRulesOff = new Button(cmpItemTypeSet, SWT.RADIO);
        btnCMRulesOff.setText(Messages.NewStreamWizard_project_options_btnAlwaysDisable);
        UIUtils.setGridData(cmpItemTypeSet, GridData.FILL_HORIZONTAL);
        btnRequestRequred = new Button(grpCM, SWT.CHECK);
        btnRequestRequred.setText(Messages.NewStreamWizard_project_options_chkRequestRequired);
        UIUtils.setGridData(btnRequestRequred, GridData.FILL_HORIZONTAL);

        setControl(composite);
        setPageComplete(true);
        loadOptionsFromType();

        // DEF218236 fix for MacOS
        getShell().layout(false, true);
        UIUtils.getDisplay().readAndDispatch();
    }

    public Boolean getBranchFlag() {
        if (btnBranch != null) {
            return safeGetSelection(btnBranch);
        } else {
            NewStreamWizard wiz = (NewStreamWizard) getWizard();
            if (wiz.isStream == true) {
                return false;
            }
            int typeOption = wiz.getOptionsFromType();

            int typeWsBrunchTrunk = 0x4;
            if ((typeOption & typeWsBrunchTrunk) != typeWsBrunchTrunk) {
                return true;
            }
        }

        return false;
    }

    public Boolean getNewRevisionForcedFlag() {
        if (btnOverrideRevNum != null) {
            return safeGetReverseSelection(btnOverrideRevNum);
        } else {
            NewStreamWizard wiz = (NewStreamWizard) getWizard();
            if (wiz.isStream == true) {
                return false;
            }
            int typeOption = wiz.getOptionsFromType();
            int typeWsAutoRev = 0x8;
            if ((typeOption & typeWsAutoRev) == typeWsAutoRev) {
                return true;
            }
        }
        return false;
    }

    public char getCMRulesFlag() {
        final char[] res = new char[1];
        if (null == btnCMRulesOn || null == btnCMRulesOff) {
            NewStreamWizard wiz = (NewStreamWizard) getWizard();
            if (wiz.isStream == true) {
                return res[0];
            }
            int typeOption = wiz.getOptionsFromType();
            int typeWsRulesAlwaysDisabled = 0x800;
            int typeWsRulesAlwaysEnabled = 0x1000;

            if ((typeOption & typeWsRulesAlwaysDisabled) == typeWsRulesAlwaysDisabled) {
                res[0] = ProjectDetails.PROJECT_CM_RULES_OFF;
            } else if ((typeOption & typeWsRulesAlwaysEnabled) == typeWsRulesAlwaysEnabled) {
                res[0] = ProjectDetails.PROJECT_CM_RULES_ON;
            } else {
                res[0] = ProjectDetails.PROJECT_CM_RULES_DEFAULT;
            }
        } else {
            btnCMRulesOn.getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    res[0] = ProjectDetails.PROJECT_CM_RULES_DEFAULT;
                    if (btnCMRulesOn.getSelection()) {
                        res[0] = ProjectDetails.PROJECT_CM_RULES_ON;
                    }
                    if (btnCMRulesOff.getSelection()) {
                        res[0] = ProjectDetails.PROJECT_CM_RULES_OFF;
                    }
                }
            });
        }
        return res[0];
    }

    public Boolean getRequestRequiredFlag() {
        if (btnRequestRequred != null) {
            return safeGetSelection(btnRequestRequred);
        } else {
            NewStreamWizard wiz = (NewStreamWizard) getWizard();
            if (wiz.isStream == true) {
                return false;
            }
            int typeOption = wiz.getOptionsFromType();
            int typeWsPathControl = 0x2000;
            if ((typeOption & typeWsPathControl) == typeWsPathControl) {
                return true;
            }
        }
        return false;
    }

    public void loadOptionsFromType() {
        if (btnBranch == null) {
            return;
        }

        NewStreamWizard wiz = (NewStreamWizard) getWizard();
        if (wiz.isStream == true) {
            return;
        }

        int typeWsBrunchTrunk = 0x4;
        int typeWsAutoRev = 0x8;
        int typeWsRulesAlwaysDisabled = 0x800;
        int typeWsRulesAlwaysEnabled = 0x1000;
        int typeWsPathControl = 0x2000;

        int typeOption = wiz.getOptionsFromType();

        btnBranch.setSelection(false);
        btnNotBranch.setSelection(false);

        if ((typeOption & typeWsBrunchTrunk) == typeWsBrunchTrunk) {
            btnNotBranch.setSelection(true);
        } else {
            btnBranch.setSelection(true);
        }

        if ((typeOption & typeWsAutoRev) == typeWsAutoRev) {
            btnOverrideRevNum.setSelection(false);
        } else {
            btnOverrideRevNum.setSelection(true);
        }

        if ((typeOption & typeWsPathControl) == typeWsPathControl) {
            btnRequestRequred.setSelection(true);
        } else {
            btnRequestRequred.setSelection(false);
        }

        btnCMRuleDefault.setSelection(false);
        btnCMRulesOn.setSelection(false);
        btnCMRulesOff.setSelection(false);

        if ((typeOption & typeWsRulesAlwaysDisabled) == typeWsRulesAlwaysDisabled) {
            btnCMRulesOff.setSelection(true);
        } else if ((typeOption & typeWsRulesAlwaysEnabled) == typeWsRulesAlwaysEnabled) {
            btnCMRulesOn.setSelection(true);
        } else {
            btnCMRuleDefault.setSelection(true);
        }
    }

    private void checkPage() {
        NewStreamWizard wiz = (NewStreamWizard) getWizard();
        if (null == wiz.getBasedOnStream() || wiz.getBasedOnStream().equals(basedOnSpec)) {
            return;
        }

        try {
            Project prj = wiz.getConnection().openSession(null).getObjectFactory().getProject(wiz.getBasedOnStream());
            if (null != prj) {
                prj.queryAttribute(SystemAttributes.WSET_IS_BRANCH);
                prj.queryAttribute(SystemAttributes.WSET_IS_ENFORCED_REV);
                prj.queryAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
                prj.queryAttribute(SystemAttributes.WSET_PATH_CONTROL);
                Object isBranch = prj.getAttribute(SystemAttributes.WSET_IS_BRANCH);
                Object isRevisionForced = prj.getAttribute(SystemAttributes.WSET_IS_ENFORCED_REV);
                Object cm_rules = prj.getAttribute(SystemAttributes.PROJECT_CM_RULES_USAGE);
                Object isRequestRequred = prj.getAttribute(SystemAttributes.WSET_PATH_CONTROL);
                if (null != isBranch && isBranch instanceof Boolean) {
                    btnBranch.setSelection(((Boolean) isBranch).booleanValue());
                    btnNotBranch.setSelection(!((Boolean) isBranch).booleanValue());
                }
                if (null != isRevisionForced && isRevisionForced instanceof Boolean) {
                    btnOverrideRevNum.setSelection(!((Boolean) isRevisionForced).booleanValue());
                }
                if (null != cm_rules && cm_rules instanceof String && ((String) cm_rules).length() > 0) {
                    String str_cm_rules = (String) cm_rules;
                    btnCMRuleDefault.setSelection(Character.toString(ProjectDetails.PROJECT_CM_RULES_DEFAULT).equals(str_cm_rules));
                    btnCMRulesOn.setSelection(Character.toString(ProjectDetails.PROJECT_CM_RULES_ON).equals(str_cm_rules));
                    btnCMRulesOff.setSelection(Character.toString(ProjectDetails.PROJECT_CM_RULES_OFF).equals(str_cm_rules));
                }
                if (null != isRequestRequred && isRequestRequred instanceof Boolean) {
                    btnRequestRequred.setSelection(((Boolean) isRequestRequred).booleanValue());
                }
                basedOnSpec = wiz.getBasedOnStream();
            }
        } catch (DMException e) {
            setErrorMessage(e.getMessage());
        }
    }

    private Boolean safeGetSelection(final Button button) {
        if (null == button) {
            return null;
        }

        final boolean[] res = new boolean[1];
        button.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                res[0] = button.getSelection();
            }
        });
        return Boolean.valueOf(res[0]);
    }

    private Boolean safeGetReverseSelection(final Button button) {
        Boolean b = safeGetSelection(button);
        if (null == b) {
            return null;
        }

        if (Boolean.TRUE.equals(b)) {
            return Boolean.FALSE;
        }

        return Boolean.TRUE;
    }
}

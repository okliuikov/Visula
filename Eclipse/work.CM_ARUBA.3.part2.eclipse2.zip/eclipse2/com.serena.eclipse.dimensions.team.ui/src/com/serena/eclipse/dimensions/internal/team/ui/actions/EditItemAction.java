/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;

import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class EditItemAction extends DMWorkspaceAction {

    private static final IDMWorkspaceResourceFilter MY_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED
            | WorkspaceResourceStatus.REMOTE_PRESENT, StatusFilter.AND);

    public EditItemAction() {
        super();
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IStructuredSelection selection = getSelection();
        // check for adaptable
        Object selObj = selection.getFirstElement();
        IResource theFile = null;
        if (selObj instanceof IAdaptable) {
            IAdaptable a = (IAdaptable) selObj;
            theFile = (IResource) a.getAdapter(IResource.class);
            if (theFile == null) {
                return;
            }
        } else {
            return;
        }

        IDimensionsObjectEditHandler handler = null;
        handler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.ITEM);
        ItemRevision itemRevision = null;
        DimensionsConnectionDetailsEx conn = null;

        try {
            IDMWorkspaceResource wsres = DMTeamPlugin.getWorkspace().getWorkspaceResource(theFile);
            IDMRemoteFile res = (IDMRemoteFile) wsres.getRemoteResource();
            conn = res.getProject().getConnection();
            itemRevision = res.getItemRevision();

        } catch (CoreException e) {
            e.printStackTrace();
        }

        ItemRevisionAdapter adapter = new ItemRevisionAdapter(itemRevision, conn);
        if (handler != null) {
            try {
                handler.openEditor(adapter);
            } catch (CoreException e2) {
                DMTeamUiPlugin.getDefault().handle(e2, getShell(), Messages.err_error, Messages.err_openObjEditor);
            }
        }
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return MY_FILTER;
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

    @Override
    protected boolean isEnabledForMultipleResources() {
        return false;
    }

    @Override
    protected boolean needsToSaveDirtyEditors() {
        return false; // no need to save before open item properties
    }

}

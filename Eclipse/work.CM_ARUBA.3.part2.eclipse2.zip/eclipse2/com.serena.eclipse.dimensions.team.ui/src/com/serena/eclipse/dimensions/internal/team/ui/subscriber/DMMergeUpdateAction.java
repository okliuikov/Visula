/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.OrSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;

/**
 * @author V.Grishchenko
 */
public class DMMergeUpdateAction extends DMParticipantAction {
    private static final String MY_TEXT = Messages.DMMergeUpdateAction_0;
    private boolean promptBeforeUpdate;

    public DMMergeUpdateAction(ISynchronizePageConfiguration configuration) {
        super(MY_TEXT, configuration);
    }

    public DMMergeUpdateAction(ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider) {
        super(MY_TEXT, configuration, selectionProvider);
    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        // Update works for all incoming and conflicting nodes
        return new OrSyncInfoFilter(new FastSyncInfoFilter[] { new SyncInfoDirectionFilter(SyncInfo.INCOMING),
                new SyncInfoDirectionFilter(SyncInfo.CONFLICTING) });
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        return new DMMergeUpdateOperation(configuration, elements, promptBeforeUpdate);
    }

    public void setPromptBeforeUpdate(boolean promptBeforeUpdate) {
        this.promptBeforeUpdate = promptBeforeUpdate;
    }
}

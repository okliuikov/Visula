/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DimensionsIDEProject;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.IWithAPIMembers;
import com.serena.eclipse.dimensions.core.SccBaselineContainer;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;
import com.serena.eclipse.dimensions.internal.team.ui.operations.CreateProjectMappingsOperation;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.AddToWorkspaceAsWizard;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Initiates a more flexible way to add remote project to workspace where local names and locations can be configured.
 *
 * @author V.Grishchenko
 */
public class AddToWorkspaceAsAction extends DMTeamAction {

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        final MappingsDataTransfer data = new MappingsDataTransfer();
        final APIObjectAdapter[] remoteObjects = getSelectedRemoteResources();
        if (remoteObjects == null || remoteObjects.length == 0) {
            return;
        }
        
        try {
            new ProgressMonitorDialog(UIUtils.findShell()).run(true, true, new IRunnableWithProgress() {

                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    data.prepare(remoteObjects, getActivePart(), monitor);
                }
            });
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e, UIUtils.findShell());
            throw new OperationCanceledException();
        } catch (InterruptedException e) {
            return;
        }

        AddToWorkspaceAsWizard wizard = null;
        if (data.getContainerMapping() != null) {
            wizard = new AddToWorkspaceAsWizard(getActivePart(), data.getContainerMapping(), data.getMappings());
        } else {
            wizard = new AddToWorkspaceAsWizard(getActivePart(), data.getMappings());
        }

        WizardDialog wizardDialog = new WizardDialog(getShell(), wizard);
        wizardDialog.open();
    }

    @Override
    protected boolean isEnabledForSelection() {
        Object[] selObjs = getSelection().toArray();
        int numIdeProjs = 0;
        int numSccProjs = 0;
        int numBaselines = 0;
        int numWorksets = 0;
        int numCont = 0;
        int numGroup = 0;
        for (int i = 0; i < selObjs.length; i++) {
            if (selObjs[i] instanceof SccProject) {
                numSccProjs++;
            } else if (selObjs[i] instanceof SccProjectContainerWorkset) {
                numCont++;
            } else if (selObjs[i] instanceof SccBaselineContainer) {
                numCont++;
            } else if (selObjs[i] instanceof DimensionsIDEProject) {
                numIdeProjs++;
            } else if (selObjs[i] instanceof DimensionsIDEProjectGroup) {
                numGroup++;
            } else if (selObjs[i] instanceof WorksetAdapter) {
                numWorksets++;
            } else if (selObjs[i] instanceof BaselineAdapter) {
                numBaselines++;
            }
        }
        if (numGroup > 1 || numCont > 1) {
            return false;
        }
        if (numGroup == 1) {
            if (numCont > 0 || numIdeProjs > 0 || numBaselines > 0 || numWorksets > 0 || numSccProjs > 0) {
                return false;
            }
        }
        if (numCont == 1) {
            if (numGroup > 0 || numIdeProjs > 0 || numBaselines > 0 || numWorksets > 0 || numSccProjs > 0) {
                return false;
            }
        }
        return true;
    }

    public static class MappingsDataTransfer {
        private ProjectMapping[] mappings;
        private ProjectMapping containerMapping;

        public ProjectMapping[] getMappings() {
            return mappings;
        }

        public void setMappings(ProjectMapping[] mappings) {
            this.mappings = mappings;
        }

        public ProjectMapping getContainerMapping() {
            return containerMapping;
        }

        public void setContainerMapping(ProjectMapping containerMapping) {
            this.containerMapping = containerMapping;
        }

        public void prepare(APIObjectAdapter[] remoteObjects, IWorkbenchPart activePart, 
                IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
            
            IWithAPIMembers container = null;
            APIObjectAdapter[] members = null;
            if (remoteObjects.length == 1 && remoteObjects[0] instanceof IWithAPIMembers) {
                container = (IWithAPIMembers) remoteObjects[0];
                members = container.getMembers(monitor);

                if (members == null || members.length == 0) {
                    container = null;
                }
            }

            VersionManagementProject[] projects = null;
            if (container != null) {
                // add parent container to operation data as an additional element
                projects = new VersionManagementProject[members.length + 1];
                System.arraycopy(members, 0, projects, 0, members.length);
                projects[members.length] = (VersionManagementProject) container;
            } else {
                projects = new VersionManagementProject[remoteObjects.length];
                System.arraycopy(remoteObjects, 0, projects, 0, remoteObjects.length);
            }

            CreateProjectMappingsOperation mappingsOperation = new CreateProjectMappingsOperation(activePart, projects);
            mappingsOperation.run(monitor);

            if (container != null) {
                // extract parent container from operation result as an additional element
                ProjectMapping[] allMappings = mappingsOperation.getMappings();
                setContainerMapping(allMappings[allMappings.length - 1]);
                ProjectMapping[] mappings = new ProjectMapping[allMappings.length - 1];
                System.arraycopy(allMappings, 0, mappings, 0, allMappings.length - 1);
                setMappings(mappings);
            } else {
                setMappings(mappingsOperation.getMappings());
            }
        }

    }
}

package com.serena.eclipse.dimensions.internal.team.ui.actions.xml;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.VirtualIdmProject;

/*
 * Simple DTO for transferring various characteristics of a scope group at one go.
 * MergeScopeGroup is grouped by workset and scope type. There are no notion of child resources like folders and files.
 */
public class MergeScopeGroup {
    /*
     * To be used with MergeScopeGroup
     */
    public enum ScopeGroupType {
        NON_CONTAINED,
        CONTAINED_FWA,
        CONTAINED_NON_FWA
    }

    private final String worksetName;
    private final MergeScopeGroup.ScopeGroupType groupType;
    private final List<IDMProject> projects;

    public MergeScopeGroup(String worksetName, MergeScopeGroup.ScopeGroupType groupType) {
        this.worksetName = worksetName;
        this.groupType = groupType;
        this.projects = new ArrayList<IDMProject>();
    }

    public MergeScopeGroup(String worksetName, MergeScopeGroup.ScopeGroupType groupType, List<IDMProject> projects) {
        this.worksetName = worksetName;
        this.groupType = groupType;
        this.projects = projects;
    }

    /*
     * Has no notion about List<IResource>, simply disregards it
     */
    public MergeScopeGroup(Map<IDMProject, List<IResource>> mergeScopes) {
        Assert.isNotNull(mergeScopes);
        String worksetNameLocal = null;
        MergeScopeGroup.ScopeGroupType groupTypeLocal = null;
        this.projects = new ArrayList<IDMProject>();
        for (Iterator<IDMProject> iter = mergeScopes.keySet().iterator(); iter.hasNext();) {
            IDMProject dmproject = iter.next();

            if (dmproject == null || dmproject.isBaseline() || !dmproject.getIsStream()) { // double-check
                continue;
            }
            if (worksetNameLocal == null) {
                worksetNameLocal = dmproject.getId(); // merge scope is per workset
                if (!dmproject.isSccStyle()) {
                    groupTypeLocal = ScopeGroupType.NON_CONTAINED;
                } else if (dmproject.isFullWorkArea()) { // separate contained FWA group per stream
                    groupTypeLocal = ScopeGroupType.CONTAINED_FWA;
                } else { // separate contained FWA group per stream
                    groupTypeLocal = ScopeGroupType.CONTAINED_NON_FWA;
                }
            }
            this.projects.add(dmproject);
        }
        this.worksetName = worksetNameLocal;
        this.groupType = groupTypeLocal;
    }

    /*
     * There are no notion of child resources like folders and files, so List<IResource> is empty always.
     */
    public Map<IDMProject, List<IResource>> toMergeScopes() {
        Map<IDMProject, List<IResource>> mergeScopes = new HashMap<IDMProject, List<IResource>>();
        for (IDMProject project : projects) {
            mergeScopes.put(project, Collections.<IResource>emptyList());
        }
        return mergeScopes;
    }

    public String getWorksetName() {
        return worksetName;
    }

    public MergeScopeGroup.ScopeGroupType getGroupType() {
        return groupType;
    }

    public List<IDMProject> getGroupProjects() {
        return projects;
    }

    public void addGroupProject(IDMProject project) {
        projects.add(project);
    }

    public void addAllGroupProjects(List<IDMProject> projects) {
        projects.addAll(projects);
    }

    public boolean equalsByNameType(MergeScopeGroup anotherMsGroup) {
        if (anotherMsGroup == null) {
            return false;
        }

        if (this == anotherMsGroup || worksetName.equals(anotherMsGroup.getWorksetName())
                && groupType == anotherMsGroup.getGroupType() && projects.equals(anotherMsGroup.projects)) {
            return true;
        }
        return false;
    }

    /*
     * Returns top-level worksets valid scope groups
     */
    public static List<MergeScopeGroup> createValidScopeGroups(DimensionsConnectionDetailsEx connection) throws CoreException {
        Assert.isNotNull(connection);
        List<MergeScopeGroup> topScopes = new ArrayList<MergeScopeGroup>();

        Map<String, List<IDMProject>> containedFwaScopes = new HashMap<String, List<IDMProject>>();
        Map<String, List<IDMProject>> containedNonFwaScopes = new HashMap<String, List<IDMProject>>();
        IDMProject[] allDmProjects = DMTeamPlugin.getWorkspace().getProjects();
        for (IDMProject dmproject : allDmProjects) {
            if (dmproject == null || dmproject.isBaseline() || !dmproject.getIsStream()
                    || !connection.equals(dmproject.getConnection()) || dmproject instanceof VirtualIdmProject) {
                continue;
            }

            if (!dmproject.isSccStyle()) {
                MergeScopeGroup nonContainedGroup = new MergeScopeGroup(dmproject.getId(), ScopeGroupType.NON_CONTAINED,
                        Collections.singletonList(dmproject));
                topScopes.add(nonContainedGroup); // non-contained group is 1-element list
            } else if (dmproject.isFullWorkArea()) { // separate contained FWA group per stream
                List<IDMProject> containedFwaScope = containedFwaScopes.get(dmproject.getId());
                if (containedFwaScope == null) {
                    containedFwaScope = new ArrayList<IDMProject>();
                    containedFwaScopes.put(dmproject.getId(), containedFwaScope);
                }
                containedFwaScope.add(dmproject);
            } else {
                // separate non-contained FWA group per stream
                List<IDMProject> containedNonFwaScope = containedNonFwaScopes.get(dmproject.getId());
                if (containedNonFwaScope == null) {
                    containedNonFwaScope = new ArrayList<IDMProject>();
                    containedNonFwaScopes.put(dmproject.getId(), containedNonFwaScope);
                }
                containedNonFwaScope.add(dmproject);
            }
        }

        for (String worksetName : containedFwaScopes.keySet()) {
            List<IDMProject> projects = containedFwaScopes.get(worksetName);
            MergeScopeGroup containedFwaGroup = new MergeScopeGroup(worksetName, ScopeGroupType.CONTAINED_FWA, projects);
            topScopes.add(containedFwaGroup);
        }
        for (String worksetName : containedNonFwaScopes.keySet()) {
            List<IDMProject> projects = containedNonFwaScopes.get(worksetName);
            MergeScopeGroup containedFwaGroup = new MergeScopeGroup(worksetName, ScopeGroupType.CONTAINED_NON_FWA, projects);
            topScopes.add(containedFwaGroup);
        }
        return topScopes;
    }
}
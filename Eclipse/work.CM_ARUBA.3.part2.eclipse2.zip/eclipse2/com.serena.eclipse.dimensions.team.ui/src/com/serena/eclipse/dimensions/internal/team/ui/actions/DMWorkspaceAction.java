/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;

/**
 * Action that runs on workspace resources, implements enablement logic.
 *
 * @author V.Grishchenko
 */
public abstract class DMWorkspaceAction extends DMTeamAction {

    public DMWorkspaceAction() {
    }

    @Override
    protected boolean needsToSaveDirtyEditors() {
        return true;
    }

    protected IDMWorkspaceResource[] getWorkspaceResources(IResource[] resources) throws CoreException {
        IDMWorkspaceResource[] result = new IDMWorkspaceResource[resources.length];
        for (int i = 0; i < resources.length; i++) {
            result[i] = DMTeamPlugin.getWorkspace().getWorkspaceResource(resources[i]);
        }
        return result;
    }

    protected IDMWorkspaceResource[] getSelectedWorkspaceResources() throws CoreException {
        return getWorkspaceResources(getSelectedResources());
    }

    @Override
    protected boolean isEnabledForSelection() {
        if (isAlwaysEnabled()) {
            return true;
        }

        try {
            IDMWorkspaceResource[] selectedWspResources = getSelectedWorkspaceResources();
            if (selectedWspResources.length == 0 || (selectedWspResources.length > 1 && !isEnabledForMultipleResources())) {
                return false;
            }
            IDMWorkspaceResourceFilter filter = getResourceFilter();
            IDMWorkspaceResourceFilter fileFilter = getFileFilter();
            DimensionsConnectionDetailsEx connection = null;
            for (int i = 0; i < selectedWspResources.length; i++) {
                IDMWorkspaceResource wspResource = selectedWspResources[i];
                if (connection == null) {
                    if (wspResource == null || wspResource.getProject() == null) {
                        return false;
                    }
                    connection = wspResource.getProject().getConnection();
                } else {
                    if (!isEnabledForMultipleConnections() && !connection.equals(wspResource.getProject().getConnection())) {
                        return false;
                    }
                }
                if (wspResource.getProject().getConnection().isOffline() && !isEnabledOffline()) {
                    return false;
                }
                if (wspResource.getProject().isWorkset() && !isEnabledForWorkset()) {
                    return false;
                }

                if (wspResource.getProject().isBaseline() && !isEnabledForBaseline()) {
                    return false;
                }
                if (wspResource.isContainer() && !isEnabledForFolder()) {
                    return false;
                }
                if (!wspResource.isContainer() && fileFilter != null) {
                    if (!fileFilter.select(wspResource)) {
                        return false;
                    }
                } else if (filter != null && !filter.select(wspResource)) {
                    return false;
                }
                if (TeamUtils.isLinkedResource(wspResource.getLocalResource())) {
                    return false; // always disable for linked
                }
            }
        } catch (CoreException e) {
            handle(e);
        }

        return true;
    }

    /**
     * One of the criteria for action enablement is the wsp resource
     * filter, unless always enabled the action is disabled if any
     * of the directly selected resources is filtered by the filter
     * returned from this method.
     *
     * @return filter or <code>null</code> to skip filter check
     */
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return null;
    }

    /**
     * @return filter to be applied for directly selected files
     */
    protected IDMWorkspaceResourceFilter getFileFilter() {
        return null;
    }

    /**
     * Default: not always enabled
     *
     * @return <code>true</code> to override other enablement criteria
     *         and enable this action unconditionally, returns <code>false</code> if other enablement criteria should be
     *         considered
     *         when enabled state
     *         is calculated
     */
    protected boolean isAlwaysEnabled() {
        return false;
    }

    /**
     * Default: disabled while offline
     *
     * @return <code>true</code> if this action is enabled while offline,
     *         otherwise returns <code>false</code>
     */
    protected boolean isEnabledOffline() {
        return false;
    }

    /**
     * Default: enabled for multiple
     *
     * @return <code>true</code> if this action is enabled for
     *         multi-resource selection, returns <code>false</code> otherwise
     */
    protected boolean isEnabledForMultipleResources() {
        return true;
    }

    /**
     * Default: disabled for baseline
     *
     * @return <code>true</code> if this action is enabled for
     *         resources whose project is shared with a baseline, returns <code>false</code> otherwise
     */
    protected boolean isEnabledForBaseline() {
        return false;
    }

    /**
     * Default: enabled for workset
     *
     * @return <code>true</code> if this action is enabled for
     *         resources whose project is shared with a baseline, returns <code>false</code> otherwise
     */
    protected boolean isEnabledForWorkset() {
        return true;
    }

    /**
     * Default: enabled for folders
     *
     * @return <code>true</code> if this action is enabled for folders in,
     *         addition for files, returns <code>false</code> otherwise.
     */
    protected boolean isEnabledForFolder() {
        return true;
    }

    /**
     * Default: disabled for resources from projects shared on different
     * connections
     *
     * @return <code>true</code> if this action is enabled for
     *         multi-connection selection, returns <code>false</code> otherwise
     */
    protected boolean isEnabledForMultipleConnections() {
        return false;
    }

    protected IResource[] getResources() throws CoreException {
        IResource[] selected = getSelectedResources();
        if (selected == null || selected.length == 0) {
            return new IResource[0];
        }

        Set<IResource> resourcesSet = new HashSet<IResource>();
        for (int i = 0; i < selected.length; i++) {
            IResource resource = TeamUtils.getResource(selected[i]);
            resourcesSet.add(resource);
        }
        return getNonOverlapping(resourcesSet.toArray(new IResource[resourcesSet.size()]));
    }
}

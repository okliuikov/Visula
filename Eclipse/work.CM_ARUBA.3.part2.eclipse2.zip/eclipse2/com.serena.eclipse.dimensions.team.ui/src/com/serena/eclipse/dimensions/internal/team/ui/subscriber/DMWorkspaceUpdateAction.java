/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class DMWorkspaceUpdateAction extends DMParticipantAction {
    private static final String MYTEXT = Messages.DMWorkspaceUpdateAction_0;

    private static final FastSyncInfoFilter MY_FILTER = new FastSyncInfoFilter.AndSyncInfoFilter(new FastSyncInfoFilter[] {
            OnlineFilter.INSTANCE, new SyncInfoDirectionFilter(new int[] { SyncInfo.INCOMING }) });

    private static final FastSyncInfoFilter MY_FILTER_AUTOMERGE_ALLOWED = new FastSyncInfoFilter.AndSyncInfoFilter(
            new FastSyncInfoFilter[] { OnlineFilter.INSTANCE,
                    new SyncInfoDirectionFilter(new int[] { SyncInfo.INCOMING, SyncInfo.CONFLICTING }) });

    private boolean promptBeforeUpdate;

    public DMWorkspaceUpdateAction(ISynchronizePageConfiguration configuration) {
        super(MYTEXT, configuration);
    }

    public DMWorkspaceUpdateAction(ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider) {
        super(MYTEXT, configuration, selectionProvider);
    }

    public void setPromptBeforeUpdate(boolean prompt) {
        promptBeforeUpdate = prompt;
    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        if (DMTeamUiPlugin.getDefault().isAllowProjectUpdateAutoMerge()) {
            return MY_FILTER_AUTOMERGE_ALLOWED;
        } else {
            return MY_FILTER;
        }
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        return new DMWorkspaceUpdateOperation(configuration, elements, promptBeforeUpdate);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;

/**
 * @author V.Grishchenko
 */
public abstract class RemoteOperation extends DMOperation {
    private APIObjectAdapter[] remoteObjects;

    public RemoteOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects) {
        super(part);
        this.remoteObjects = remoteObjects;
    }

    /**
     * @return Returns the remoteObjects.
     */
    public APIObjectAdapter[] getRemoteObjects() {
        return remoteObjects;
    }

    /**
     * @param remoteObjects The remoteObjects to set.
     */
    public void setRemoteObjects(APIObjectAdapter[] remoteObjects) {
        this.remoteObjects = remoteObjects;
    }

}

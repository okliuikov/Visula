/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2008 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.IdmRequestsPanel;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.util.StringUtils;

/**
 * Implements UI for Mashups change request to item association. Assumes all
 * files are from one connection.
 *
 * @author V.Grishchenko
 */
public class IdmRequestPage extends TeamOperationWizardRequestPage implements IPostCommandExecute {

    public enum SelectionRestoreFlags {
        
        NONE(1<<0),
        INBOX(1<<1), 
        FAVORITES(1<<2);
        
        private final long flags;

        SelectionRestoreFlags(long flags) {
            this.flags = flags;
        }
        
        public long getSelectionRestoreFlags(){
            return flags;
        } 
    }
    private IDialogSettings settings;
    private IdmRequestsPanel tablePanel;
    private Button selectAllBtn;
    private Button deselectAllBtn;
    private Button storeSelectionBtn;
    private Button deactivateRequestsBtn;
    
    private boolean useStoredSelection;
    private String[] storedSelection;
    private Set<SelectionRestoreFlags> selectionRestoreFlags = EnumSet.of(SelectionRestoreFlags.NONE);

    private boolean deactivateRequests;
    private CTabFolder tabFolder;

    public IdmRequestPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(description);
        IDialogSettings pluginSettings = DMTeamUiPlugin.getDefault().getDialogSettings();
        this.settings = pluginSettings.getSection(getClass().getName());
        if (this.settings == null) {
            this.settings = pluginSettings.addNewSection(getClass().getName());
        }
        useStoredSelection = settings.getBoolean(USE_STORED_SELECTION);
        storedSelection = settings.getArray(STORED_SELECTION);
    }

    @Override
    public void saveSettings() {
        settings.put(USE_STORED_SELECTION, useStoredSelection);
        if (useStoredSelection) {
            settings.put(STORED_SELECTION, storedSelection);
        } else {
            settings.put(STORED_SELECTION, Utils.ZERO_LENGTH_STRING_ARRAY);
        }
    }

    @Override
    public void setResources(WorkspaceResourceRequest[] resources) {
        this.resources = resources;
        validate(false);
    }

    @Override
    public void createControl(Composite parent) {
        final Composite composite = new Composite(parent, SWT.NONE);
        GridLayout gl = UIUtils.setGridLayout(composite, 1);
        gl.marginHeight = gl.marginWidth = 0;

        tabFolder = new CTabFolder(composite, SWT.TOP | SWT.FLAT | SWT.MULTI | SWT.BORDER);
        UIUtils.setGridData(tabFolder, GridData.FILL_BOTH);

        Composite panel = createRequestsPanel(tabFolder);

        CTabItem tabItemInbox = new CTabItem(tabFolder, SWT.NONE);
        tabItemInbox.setText(Messages.TeamOperationWizardRequestPage_39);
        tabItemInbox.setControl(panel);

        final CTabItem tabItemFavorites = new CTabItem(tabFolder, SWT.NONE);
        tabItemFavorites.setText(Messages.TeamOperationWizardRequestPage_Favorites);
        tabItemFavorites.setControl(panel);

        tabFolder.addSelectionListener(new SelectionListener() {
            
            @Override
            public void widgetDefaultSelected(SelectionEvent e) {
                showRequests();
            }
            
            @Override
            public void widgetSelected(SelectionEvent e) {
                showRequests();
            }
        });
        
        if (DMTeamUiPlugin.getDefault().isUseActivatedRequests()) {
            tabFolder.setSelection(tabItemFavorites);
        } else {
            tabFolder.setSelection(tabItemInbox);
        }
        setControl(composite);
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            showRequests();
        }
        super.setVisible(visible);
    }

    private void updateSelection() {
        updateSelection(tablePanel.getCheckedRequestNames().toArray(new String[0]));
    }
    
    private void updateSelection(String[] checkedRequestNames) {
        storedSelection = checkedRequestNames;
        if (resources == null) {
            return;
        }
        for (int i = 0; i < resources.length; i++) {
            WorkspaceResourceRequest aResource = resources[i];
            if (aResource.isRequestSupported()) {
                aResource.setChangeRequests(Arrays.asList(checkedRequestNames));
            }
        }
        validate();
    }

    private DimensionsConnectionDetailsEx getConnection() {
        return ((TeamOperationWizard) getWizard()).getConnection();
        
    }
    
    private RequestProvider getRequestProvider() { 
        RequestProvider requestProvider = null;
        String productName = ((TeamOperationWizard) getWizard()).getTargetProductName();
        if (!StringUtils.isBlank(productName)) {
            try {
                IDMHelper helper = getConnection().openSession(null).getObjectFactory().getIDMHelper();
                requestProvider = helper.getRequestProvider(productName);
            } catch (DMException e) {
                DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, "Error getting request provider", e)); //$NON-NLS-1$
            }
        }
        return requestProvider;
    }

    
    
    private void updateCheckboxesAndSelection(List<String> selected) {
        if (selected == null) {
            return;
        }
        tablePanel.setCheckedRequests(selected);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    tablePanel.waitForPendingJobsCompletion();

                    Display.getDefault().asyncExec(new Runnable() {

                        @Override
                        public void run() {
                            if (tablePanel != null && !tablePanel.getTableViewer().getControl().isDisposed()) {
                                updateSelection();
                            }
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
    }
    
    private void showRequests() {
        // we'll try to restore selection (checked requests) when switching between inbox/favorites tab
        List<String> selected = tablePanel.getCheckedRequestNames();
        if (tabFolder.getSelection().getText() == Messages.TeamOperationWizardRequestPage_Favorites) {
            tablePanel.showActiveRequests();
            if (!selectionRestoreFlags.contains(SelectionRestoreFlags.FAVORITES)) {
                if (useStoredSelection && storedSelection != null && storedSelection.length > 0) {
                    selected = Arrays.asList(storedSelection);
                }
                selectionRestoreFlags.add(SelectionRestoreFlags.FAVORITES);
                selectionRestoreFlags.remove(SelectionRestoreFlags.NONE);
            }
        } else {
            tablePanel.showInboxRequests();
            if (!selectionRestoreFlags.contains(SelectionRestoreFlags.INBOX)) {
                if (useStoredSelection && storedSelection != null && storedSelection.length > 0) {
                    selected = Arrays.asList(storedSelection);
                }
                selectionRestoreFlags.add(SelectionRestoreFlags.INBOX);
                selectionRestoreFlags.remove(SelectionRestoreFlags.NONE);
            }
        }
        updateCheckboxesAndSelection(selected);
    }

    @Override
    protected WorkspaceResourceRequest[] getFirstCrossProjectMoveWithTheSameRequest() {
        // we do not deploy with Idm requests so this check is irrelevant
        return null;
    }

    @Override
    public void postCommit(TeamOperationWizardHelper helper) throws CoreException {
        if (deactivateRequests && helper != null) {
            helper.setPostCommandExecuteProvider(this);
        }
    }

    @Override
    public void postExecute(IProgressMonitor monitor) throws CoreException {
        if (deactivateRequests) {
            tablePanel.removeFromWorkingList(storedSelection);
        }
    }

    private Composite createRequestsPanel(Composite parent) {

        Composite panel = new Composite(parent, SWT.NONE);
        GridLayout gl = UIUtils.setGridLayout(panel, 1);
        gl.marginHeight = gl.marginWidth = 0;

        tablePanel = new IdmRequestsPanel(panel, getConnection(), getRequestProvider(), true /* allowCheckboxesInTable */);
        tablePanel.getCheckboxTableViewer().addSelectionChangedListener(new ISelectionChangedListener() {

            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                // here we only need to handle 'remove from favorites' operation for the last
                // checked request in the list
                if (tablePanel.getCheckedRequestNames().toArray(new String[0]).length == 0) {
                    updateSelection();
                }
            }
        });

        tablePanel.getCheckboxTableViewer().addCheckStateListener(new ICheckStateListener() {
            @Override
            public void checkStateChanged(CheckStateChangedEvent event) {
                updateSelection();
            }
        });
        deactivateRequests = DMTeamUiPlugin.getDefault().isDeactivateRequestsByDefault();

        // buttons
        Composite buttons = new Composite(panel, SWT.NONE);
        UIUtils.setGridLayout(buttons, 4);

        selectAllBtn = new Button(buttons, SWT.PUSH);
        selectAllBtn.setText(Messages.TeamOperationWizardRequestPage_13);

        deselectAllBtn = new Button(buttons, SWT.PUSH);
        deselectAllBtn.setText(Messages.TeamOperationWizardRequestPage_14);

        storeSelectionBtn = new Button(buttons, SWT.CHECK);
        storeSelectionBtn.setText(Messages.TeamOperationWizardRequestPage_15);
        storeSelectionBtn.setSelection(useStoredSelection);
        storeSelectionBtn.setEnabled(!deactivateRequests);

        deactivateRequestsBtn = new Button(buttons, SWT.CHECK);
        deactivateRequestsBtn.setText(Messages.TeamOperationWizardRequestPage_41);
        deactivateRequestsBtn.setSelection(deactivateRequests);

        SelectionListener buttonListener = new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (e.widget == selectAllBtn || e.widget == deselectAllBtn) {
                    boolean selectAll = e.getSource() == selectAllBtn;
                    tablePanel.getCheckboxTableViewer().setAllChecked(selectAll);
                    updateSelection();
                    return;
                }
                if (e.widget == storeSelectionBtn) {
                    useStoredSelection = storeSelectionBtn.getSelection();
                    return;
                }
                if (e.widget == deactivateRequestsBtn) {
                    deactivateRequests = deactivateRequestsBtn.getSelection();
                    storeSelectionBtn.setEnabled(!deactivateRequests);
                    return;
                }
            }
        };
        selectAllBtn.addSelectionListener(buttonListener);
        deselectAllBtn.addSelectionListener(buttonListener);
        storeSelectionBtn.addSelectionListener(buttonListener);
        deactivateRequestsBtn.addSelectionListener(buttonListener);
        return panel;
    }
}

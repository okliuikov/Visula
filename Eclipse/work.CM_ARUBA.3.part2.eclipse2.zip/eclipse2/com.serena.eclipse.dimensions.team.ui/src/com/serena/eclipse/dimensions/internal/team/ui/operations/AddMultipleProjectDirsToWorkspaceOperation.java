package com.serena.eclipse.dimensions.internal.team.ui.operations;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;

public class AddMultipleProjectDirsToWorkspaceOperation extends AddMultipleProjectsToWorkspaceOperation { 

    public AddMultipleProjectDirsToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects,
            String targetLocation) {
        super(part, remoteObjects, targetLocation);
    }

    public AddMultipleProjectDirsToWorkspaceOperation(IWorkbenchPart part, APIObjectAdapter[] remoteObjects,
            ProjectMapping[] mappings, String targetLocation) {
        super(part, remoteObjects, mappings, targetLocation);
    }

    @Override
    protected IStatus performAddToWorkspace(ProjectMapping mapping, IProject project, IProgressMonitor monitor,
            APIObjectAdapter remoteProject) throws CoreException {
        if (performScrubProjects()) {
            if (needsPromptForOverwrite(mapping, project)) {
                if (!promptToOverwrite(mapping, project)) {
                    return OK; // canceled
                } else {
                    // try to remove sync and deliver participants if we override existing project
                    removeSyncParticipants(project, mapping.getRemoteProject());
                }
            }
        }
        String task = NLS.bind(Messages.AddProjectToWorkspaceOperation_0, mapping.getRemoteProjectName(), project.getName());
        monitor.beginTask(task, 100);
        monitor.setTaskName(task);
        createAndOpenProject(mapping, project, Utils.subMonitorFor(monitor, 10));
        scrubProject(project, Utils.subMonitorFor(monitor, 10));
        IDMProject dmProject = DMTeamPlugin.getWorkspace()
                .manage(project, null, remoteProject, mapping.getWorkAreaRoot(),
                        /* no refresh, it could degrade performance */false)
                .getIdmProject();
        return dmProject.copyDirToWorkspace(Utils.subMonitorFor(monitor, 80));
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import com.serena.eclipse.dimensions.internal.team.core.ItemRequest;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;

/*
 * @author V.Grishchenko
 */
class ItemInfo {
    private ItemRequest request;
    private IAttributeModel attributeModel;

    public ItemInfo(ItemRequest request, IAttributeModel attributeModel) {
        this.request = request;
        this.attributeModel = attributeModel;
    }

    /**
     * @return Returns the attributeModel.
     */
    public IAttributeModel getAttributeModel() {
        return attributeModel;
    }

    /**
     * @return Returns the request.
     */
    public ItemRequest getRequest() {
        return request;
    }
}

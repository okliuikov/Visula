/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DimensionsIDEProjectGroup;
import com.serena.eclipse.dimensions.core.IDimensionsServiceResource;
import com.serena.eclipse.dimensions.core.SccProjectContainerWorkset;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewProjectWizardCaller;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;

/**
 * Launches new workset wizard.
 * @author V.Grishchenko
 */
public class NewProjectAction extends DimensionsAction {

    public NewProjectAction() {
        super(true);
    }

    @Override
    public void run(IAction action) {
        IStructuredSelection selection = getSelection();
        if (selection.isEmpty()) {
            return;
        }
        IDimensionsServiceResource dmResource = (IDimensionsServiceResource) selection.getFirstElement();
        APIObjectAdapter basedOn = null;
        if (dmResource.getClass() == WorksetAdapter.class || dmResource instanceof BaselineAdapter
                || dmResource.getClass() == DimensionsIDEProjectGroup.class
                || dmResource.getClass() == SccProjectContainerWorkset.class) {
            basedOn = (APIObjectAdapter) dmResource;
        }
        NewProjectWizardCaller wizard = new NewProjectWizardCaller(dmResource.getConnectionDetails(), basedOn);
        WizardDialog dialog = new WizardDialog(getShell(), wizard);
        dialog.open();
    }

}

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IPostCommandExecute {

    public void postExecute(IProgressMonitor monitor) throws CoreException;

}

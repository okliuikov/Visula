/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;

import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;

/**
 * @author V.Grishchenko
 */
abstract class DMParticipantOperationHelper extends TeamOperationWizardHelper {

    private SyncInfoSet syncInfos;

    private static class Filter implements IDMWorkspaceResourceFilter {
        SyncInfoSet selected;

        Filter(SyncInfoSet selected) {
            this.selected = selected;
        }

        @Override
        public boolean select(IDMWorkspaceResource resource) throws TeamException {
            return selected.getSyncInfo(resource.getLocalResource()) != null;
        }
    }

    public DMParticipantOperationHelper(SyncInfoSet syncInfos, IProgressMonitor monitor) throws CoreException {
        // resources are already filtered
        super(TeamUtils.getNonOverlapping(syncInfos.getResources()), new Filter(syncInfos), monitor);
        this.syncInfos = syncInfos;
    }

    protected SyncInfo getSyncInfo(IResource resource) {
        return syncInfos.getSyncInfo(resource);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.IDimensionsServiceResource;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewRevisedBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewTemplateBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewTipBaselineWizard;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.internal.ui.Assert;

/**
 * Launches new baseline wizard.
 * @author V.Grishchenko
 */
public class NewBaselineAction extends DimensionsAction {
    private static String idFirst = "com.serena.eclipse.dimensions.team.ui."; // NON-NLS-1$
    private static String idTip = idFirst + "newTipBaselineAction"; // NON-NLS-1$
    private static String idTemplate = idFirst + "newTemplateBaselineAction"; // NON-NLS-1$
    private static String idRevised = idFirst + "newRevisedBaselineAction"; // NON-NLS-1$

    public NewBaselineAction() {
    }

    @Override
    public void run(IAction action) {
        IStructuredSelection selection = getSelection();
        if (selection.isEmpty()) {
            return;
        }
        IDimensionsServiceResource dmResource = (IDimensionsServiceResource) selection.getFirstElement();
        VersionManagementProject basedOn = null;
        NewBaselineWizard wizard = null;
        String id = getAction().getId();
        if (id.equals(idTip)) {
            if (dmResource instanceof WorksetAdapter) {
                basedOn = (WorksetAdapter) dmResource;
            }
            wizard = new NewTipBaselineWizard(dmResource.getConnectionDetails(), basedOn);
        } else if (id.equals(idTemplate)) {
            if (dmResource instanceof WorksetAdapter) {
                basedOn = (WorksetAdapter) dmResource;
            }
            wizard = new NewTemplateBaselineWizard(dmResource.getConnectionDetails(), basedOn);
        } else if (id.equals(idRevised)) {
            if (dmResource instanceof BaselineAdapter) {
                basedOn = (BaselineAdapter) dmResource;
            }
            wizard = new NewRevisedBaselineWizard(dmResource.getConnectionDetails(), basedOn);
        }
        Assert.isNotNull(wizard, "Invalid Baseline mode"); // NON-NLS-$1
        WizardDialog dialog = new WizardDialog(getShell(), wizard);
        dialog.open();
    }

    @Override
    protected boolean isEnabledForSelection() {
        IStructuredSelection selection = getSelection();
        if (selection.isEmpty()) {
            return false;
        }

        String id = getAction().getId();
        IDimensionsServiceResource dmResource = (IDimensionsServiceResource) selection.getFirstElement();
        if (id.equals(idTip) || id.equals(idTemplate)) {
            if (dmResource instanceof WorksetAdapter) {
            	if (((String) ((WorksetAdapter) dmResource).getAPIObject().getAttribute(SystemAttributes.TYPE_NAME)).equals(IDMConstants.TOPIC_TYPE_NAME))
            			return false;
            	return true;
            } else if (dmResource instanceof BaselineAdapter) {
                return false;
            }
        } else if (id.equals(idRevised)) {
            if (dmResource instanceof BaselineAdapter) {
                return true;
            } else if (dmResource instanceof WorksetAdapter) {
                return false;
            }
        }
        return true;
    }

}

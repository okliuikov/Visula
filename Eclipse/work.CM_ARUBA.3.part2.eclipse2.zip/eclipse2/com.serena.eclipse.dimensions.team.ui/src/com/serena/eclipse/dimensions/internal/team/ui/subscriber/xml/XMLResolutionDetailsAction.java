/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.widgets.Display;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelAction;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml.XMLUserActionFilters.XMLSyncInfoFilter;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Action shows property page for selected resolution from sync view in three way merge mode
 */
public class XMLResolutionDetailsAction extends SynchronizeModelAction {

    public XMLResolutionDetailsAction(String text, ISynchronizePageConfiguration configuration) {
        super(text, configuration);
    }

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        return XMLSyncInfoFilter.INSTANCE;
    }

    @Override
    public void setEnabled(boolean enabled) {
        if (enabled) {
            enabled = getStructuredSelection().size() == 1;
        }

        if (enabled) {
            Object ell = getStructuredSelection().getFirstElement();
            if (ell instanceof ISynchronizeModelElement && ell instanceof IAdaptable) {
                SyncInfo syncInfo = (SyncInfo) ((IAdaptable) ell).getAdapter(SyncInfo.class);
                enabled = syncInfo != null && syncInfo instanceof XMLSyncInfo;
            } else {
                enabled = false;
            }
        }

        super.setEnabled(enabled);
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(final ISynchronizePageConfiguration configuration,
            final IDiffElement[] elements) {
        return new SynchronizeModelOperation(configuration, elements) {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                Display.getDefault().asyncExec(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            PlatformUI.getWorkbench()
                                    .getActiveWorkbenchWindow()
                                    .getActivePage()
                                    .showView(IPageLayout.ID_PROP_SHEET);
                        } catch (PartInitException e) {
                            DMTeamUiPlugin.log(e.getStatus());
                        }
                    }
                });
            }
        };
    }

}
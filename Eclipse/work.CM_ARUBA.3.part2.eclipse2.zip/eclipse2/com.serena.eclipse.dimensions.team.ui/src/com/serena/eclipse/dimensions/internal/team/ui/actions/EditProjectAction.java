/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Opens workset or baseline editor
 * @author V.Grishchenko
 */
public class EditProjectAction extends DMWorkspaceAction {

    public EditProjectAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        final IProject[] selectedProjects = getSelectedProjects();
        if (selectedProjects == null || selectedProjects.length == 0) {
            return;
        }
        final ArrayList objects = new ArrayList();
        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                monitor.beginTask(null, selectedProjects.length);
                try {
                    for (int i = 0; i < selectedProjects.length; i++) {
                        IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(selectedProjects[i]);
                        if (dmProject != null) {
                            objects.add(dmProject.getDimensionsObjectAdapter());
                        }
                        monitor.worked(1);
                    }
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                } finally {
                    monitor.done();
                }
            }
        });

        for (Iterator iter = objects.iterator(); iter.hasNext();) {
            APIObjectAdapter object = (APIObjectAdapter) iter.next();
            IDimensionsObjectEditHandler handler = DMUIPlugin.getDefault().getEditHandler(object.getTypeScope());
            if (handler != null) {
                try {
                    handler.openEditor(object);
                } catch (CoreException e) {
                    DMTeamUiPlugin.getDefault().handle(e, getShell());
                }
            }
        }

    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

    @Override
    protected void setActionEnablement(IAction action) {
        IResource[] resources = getSelectedProjects();
        String text = null;
        if (resources != null && resources.length == 1) {
            try {
                IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(resources[0]);
                if (dmProject.isBaseline()) {
                    text = Messages.EditProjectAction_1;
                } else {
                    text = Messages.EditProjectAction_2;
                }
            } catch (CoreException e1) {
                DMTeamUiPlugin.getDefault().handle(e1, getShell());
            }
        }
        action.setText(text == null ? Messages.EditProjectAction_3 : text);
        super.setActionEnablement(action);
    }

    @Override
    protected boolean needsToSaveDirtyEditors() {
        return false; // no need to save before open project properties
    }

}

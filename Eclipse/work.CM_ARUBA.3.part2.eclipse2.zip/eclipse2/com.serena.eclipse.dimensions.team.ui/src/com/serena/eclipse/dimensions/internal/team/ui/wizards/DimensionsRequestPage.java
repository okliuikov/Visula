/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.IFontProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabFolder2Adapter;
import org.eclipse.swt.custom.CTabFolderEvent;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;

import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.SystemRelationship;
import com.serena.dmclient.objects.RequestType;
import com.serena.dmclient.objects.TypeScope;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.MyWorkingChangeDocumentList;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.TypeReference;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.CMRulesSensitiveRequest;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.FolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.ItemRequest;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamPreferences;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Implements UI for Dimensions change request to item association.
 * Assumes all files are from one connection.
 * 
 * @author V.Grishchenko
 */
public class DimensionsRequestPage extends TeamOperationWizardRequestPage implements IPostCommandExecute {

    private static final String COL_TYPE_TREE_TREE_WIDTH = "tree_width"; //$NON-NLS-1$
    private static final String COL_TYPE_TREE_CHKIND_WIDTH = "chkind_width"; //$NON-NLS-1$
    private static final String COL_TYPE_TREE_RULESON_WIDTH = "ruleson_width"; //$NON-NLS-1$
    private static final String COL_TYPE_TREE_DOCS_WIDTH = "docs_width"; //$NON-NLS-1$
    private static final String COL_TYPE_TREE_PROJ_WIDTH = "proj_width"; //$NON-NLS-1$

    public static final String COL_DOC_ID_WIDTH = "id_width"; //$NON-NLS-1$
    public static final String COL_DOC_STATUS_WIDTH = "status_width"; //$NON-NLS-1$
    public static final String COL_DOC_TITLE_WIDTH = "title_width"; //$NON-NLS-1$
    public static final String COL_DOC_DETAILS_WIDTH = "details_width"; //$NON-NLS-1$

    // type tabletree cols
    private static final int COL_TYPE_TREE_TREE = 0;
    private static final int COL_TYPE_TREE_CHKIND = 1;
    private static final int COL_TYPE_TREE_RULESON = 2;
    private static final int COL_TYPE_TREE_DOCS = 3;
    private static final int COL_TYPE_TREE_PROJECT = 4;

    // request table cols
    public static final int COL_DOC_ID = 0;
    public static final int COL_DOC_STATUS = 1;
    public static final int COL_DOC_TITLE = 2;
    public static final int COL_DOC_DETAILS = 3;

    // unable to select request reasons
    public static final int OK = 0;
    public static final int INVALID_RELATIONSHIP = 1;
    public static final int INVALID_PROJECT = 2;
    public static final int RULES_ENABLEMENT_CONFLICT = 4;
    public static final int INVALID_PHASE = 8;

    private AllTypes root;
    private Folders folders;
    // private WorkspaceResourceRequest[] resources;
    private Map documents; // doc id -> RequestInfo
    private Map documentsPending; // doc id -> RequestInfo
    private Map documentsActivated; // doc id -> RequestInfo
    private Map validRelationships; // TypeReference-doc -> {TypeReference-item}
    private boolean useStoredSelection;
    private boolean deactivateRequests;
    private String[] storedSelection;
    private Map defaultRequests; // prjid -> request id

    private TreeViewer typeTreeViewer;
    private CheckboxTableViewer docTableViewer;
    private CheckboxTableViewer docActivatedTableViewer;

    private Button selectAllBtn;
    private Button deselectAllBtn;
    private Button fixRelationshipsBtn;
    private Button storeSelectionBtn;
    private Button showAllBtn;
    private Button deactivateRequestsBtn;

    private IDialogSettings settings;
    private boolean useActivated;

    static String getBooleanText(boolean b) {
        return b ? Messages.TeamOperationWizardRequestPage_0 : Messages.TeamOperationWizardRequestPage_1;
    }

    private String getRequestsAsString(List ids) {
        if (ids == null || ids.isEmpty()) {
            return Utils.EMPTY_STRING;
        }
        StringBuffer buf = new StringBuffer();
        for (Iterator iter = ids.iterator(); iter.hasNext();) {
            String id = (String) iter.next();// getStringAttribute(((RequestInfo)iter.next()).request, SystemAttributes.OBJECT_ID);
            buf.append(id).append(", "); //$NON-NLS-1$
        }
        buf.setLength(buf.length() - 2); // remove trailing ", "
        return buf.toString();
    }

    private class TypeTreeContentProvider implements ITreeContentProvider {
        public TypeTreeContentProvider() {
        }

        @Override
        public Object[] getChildren(Object parentElement) {
            if (parentElement == DimensionsRequestPage.this) {
                return new Object[] { root };
            }
            if (parentElement instanceof RelatedChangeRequestsContainer) {
                List children = ((RelatedChangeRequestsContainer) parentElement).getChildren();
                return children.toArray();
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public Object getParent(Object element) {
            if (element instanceof RelatedChangeRequests) {
                return ((RelatedChangeRequests) element).getParent();
            }
            return null;
        }

        @Override
        public boolean hasChildren(Object element) {
            return element instanceof RelatedChangeRequestsContainer;
        }

        @Override
        public Object[] getElements(Object inputElement) {
            return getChildren(inputElement);
        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        }
    }

    private class TypeTreeLabelProvider extends LabelProvider implements ITableLabelProvider, Comparator {

        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            // there is no support for images in the tabletree tree column...
            return null;
        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            if (columnIndex == COL_TYPE_TREE_TREE && element instanceof RelatedChangeRequests) {
                RelatedChangeRequests rr = (RelatedChangeRequests) element;
                if (rr == root) {
                    return Messages.TeamOperationWizardRequestPage_3;
                }
                if (rr instanceof TypeInfo) {
                    return ((TypeInfo) rr).getTypeString();
                }
                if (rr instanceof Folders) {
                    return Messages.TeamOperationWizardRequestPage_28;
                }
                if (rr instanceof ResourceInfo) {
                    IResource res = ((ResourceInfo) rr).getResource();
                    return res.getFullPath().toOSString();
                }
            }

            if (columnIndex == COL_TYPE_TREE_CHKIND && element instanceof ResourceInfo) {
                return ((ResourceInfo) element).getChangeKind();
            }

            if (columnIndex == COL_TYPE_TREE_RULESON && element instanceof RelatedChangeRequests) {
                RelatedChangeRequests rr = (RelatedChangeRequests) element;
                return getBooleanText(rr.isChangeRequestsMandatory());
            }

            if (columnIndex == COL_TYPE_TREE_DOCS) {
                if (element instanceof RelatedChangeRequests) {
                    RelatedChangeRequests rr = (RelatedChangeRequests) element;
                    ArrayList sorted = new ArrayList(rr.getChangeRequests());
                    Collections.sort(sorted, this);
                    return getRequestsAsString(sorted);
                }
            }

            if (columnIndex == COL_TYPE_TREE_PROJECT) {
                if (element instanceof ResourceInfo) {
                    return ((ResourceInfo) element).getProjectId();
                }
            }

            return Utils.EMPTY_STRING;
        }

        @Override
        public int compare(Object o1, Object o2) {
            if (o1 instanceof String && o2 instanceof String) {
                return compareChangeRequests((RequestInfo) documents.get(o1), (RequestInfo) documents.get(o2));
            }
            return 0;
        }

    }

    private class TypeTreeSorter extends ViewerSorter {
        @Override
        public int compare(Viewer viewer, Object o1, Object o2) {
            int result = 0;
            if (o1 instanceof TypeInfo && o2 instanceof TypeInfo) {
                // sort order: product, type
                TypeInfo info1 = (TypeInfo) o1;
                TypeInfo info2 = (TypeInfo) o2;
                String p1 = info1.type.getProduct();
                String p2 = info2.type.getProduct();
                result = collator.compare(p1, p2);
                if (result == 0) {
                    String t1 = info1.type.getTypeName();
                    String t2 = info2.type.getTypeName();
                    result = collator.compare(t1, t2);
                }
            } else if (o1 instanceof ResourceInfo && o2 instanceof ResourceInfo) {
                // sort by workspace paths
                IPath p1 = ((ResourceInfo) o1).getResource().getFullPath();
                IPath p2 = ((ResourceInfo) o2).getResource().getFullPath();
                result = p1.toFile().compareTo(p2.toFile());
            } else if (o1 instanceof Folders && o2 instanceof TypeInfo) {
                return 1;
            } else if (o1 instanceof TypeInfo && o2 instanceof Folders) {
                return -1;
            } else {
                result = super.compare(viewer, o1, o2);
            }
            return result;
        }
    }

    private class RequestContentProvider implements IStructuredContentProvider {

        public RequestContentProvider() {
        }

        @Override
        public Object[] getElements(Object inputElement) {
            if (inputElement == documents) {
                return documents.values().toArray();
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        }

    }

    private class RequestLabelProvider extends LabelProvider implements ITableLabelProvider, IFontProvider {
        private Font italicFont;

        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            return null;
        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            if (!(element instanceof RequestInfo)) {
                return Utils.EMPTY_STRING;
            }
            RequestInfo requestInfo = (RequestInfo) element;
            String text = null;
            switch (columnIndex) {
            case COL_DOC_ID:
                text = (String) requestInfo.request.getAPIObject().getAttribute(SystemAttributes.OBJECT_ID);
                break;
            case COL_DOC_STATUS:
                text = (String) requestInfo.request.getAPIObject().getAttribute(SystemAttributes.STATUS);
                break;
            case COL_DOC_TITLE:
                text = (String) requestInfo.request.getAPIObject().getAttribute(SystemAttributes.TITLE);
                break;
            case COL_DOC_DETAILS:
            	ISelection selection = typeTreeViewer.getSelection();
                if (!selection.isEmpty() && selection instanceof IStructuredSelection) {
                    RelatedChangeRequests rr = (RelatedChangeRequests) ((IStructuredSelection) selection).getFirstElement();
                    int selState = rr.getSelectionState(requestInfo);
                    if (selState != OK) {
                        ArrayList<String> reasons = new ArrayList<String>();
                        if ((selState & INVALID_PROJECT) != 0) {
                            String prj = getStringAttribute(requestInfo.request, SystemAttributes.PROJECT);
                            reasons.add(NLS.bind(Messages.TeamOperationWizardRequestPage_2, prj));
                        }
                        if ((selState & INVALID_RELATIONSHIP) != 0) {
                            reasons.add(Messages.TeamOperationWizardRequestPage_23);
                        }
                        if ((selState & RULES_ENABLEMENT_CONFLICT) != 0) {
                            reasons.add(NLS.bind(Messages.TeamOperationWizardRequestPage_26, requestInfo.type.getTypeName()));
                        }
                        if ((selState & INVALID_PHASE) != 0) {
                            String phase = getStringAttribute(requestInfo.request, SystemAttributes.CM_PHASE);
                            reasons.add(NLS.bind(Messages.TeamOperationWizardRequestPage_27, phase));
                        }
                        text = Utils.toCsvString(reasons.toArray(), true);
                    }
                }
                break;
            }
            if (text == null) {
                return Utils.EMPTY_STRING;
            }
            return text;
        }

        @Override
        public Font getFont(Object element) {
            if (element instanceof RequestInfo) {
                RequestInfo request = (RequestInfo) element;
                RelatedChangeRequests rcr = getSelectedRelatedRequests();
                if (rcr != null && rcr.getSelectionState(request) != OK) {
                    return getItalicFont();
                }
            }
            return null;
        }

        @Override
        public void dispose() {
            if (italicFont != null) {
                italicFont.dispose();
            }
            super.dispose();
        }

        private Font getItalicFont() {
            if (italicFont == null) {
                Font dfltFont = docTableViewer.getTable().getFont();
                FontData[] data = dfltFont.getFontData();
                for (int i = 0; i < data.length; i++) {
                    data[i].setStyle(SWT.ITALIC);
                }
                italicFont = new Font(docTableViewer.getTable().getDisplay(), data);
            }
            return italicFont;
        }

    }

    private class RequestSorter extends ViewerSorter {
        @Override
        public int compare(Viewer viewer, Object e1, Object e2) {
            if (e1 instanceof RequestInfo && e2 instanceof RequestInfo) {
                return compareChangeRequests((RequestInfo) e1, (RequestInfo) e2);
            }
            return super.compare(viewer, e1, e2);
        }
    }

    private class RequestFilter extends ViewerFilter {
        @Override
        public boolean select(Viewer viewer, Object parentElement, Object element) {
            if (element instanceof RequestInfo && !showAllBtn.getSelection()) { // exclude invalid
                RelatedChangeRequests rr = getSelectedRelatedRequests();
                if (rr != null) {
                    return rr.getSelectionState((RequestInfo) element) == OK;
                }
            }
            return true;
        }
    }

    private abstract class RelatedChangeRequests {
        private RelatedChangeRequestsContainer parent;

        RelatedChangeRequests(RelatedChangeRequestsContainer parent) {
            this.parent = parent;
            if (parent != null) {
                parent.addChild(this);
            }
        }

        public RelatedChangeRequestsContainer getParent() {
            return parent;
        }

        int getDepth() {
            if (parent == null) {
                return 0;
            }
            return parent.getDepth() + 1;
        }

        boolean isReacheableFrom(RelatedChangeRequestsContainer container) {
            if (container == null) {
                return false;
            }
            if (this == container) {
                return true;
            }
            if (parent == null) {
                return false;
            }
            return parent.isReacheableFrom(container);
        }

        RequestInfo[] getRequestInfos() {
            List ids = getChangeRequests();
            List resultList = new ArrayList();
            for (Iterator idIter = ids.iterator(); idIter.hasNext();) {
                String id = (String) idIter.next();
                RequestInfo requestInfo = (RequestInfo) documents.get(id);
                if (requestInfo != null) {
                    resultList.add(requestInfo);
                }
            }
            return (RequestInfo[]) resultList.toArray(new RequestInfo[resultList.size()]);
        }

        void addChangeRequest(String id) {
            addChangeRequest(id, true/* , true */);
        }

        void addChangeRequest(String id, boolean addToParent/* , boolean addToChildren */) {
            doAddChangeRequest(id);
            if (addToParent && parent != null) {
                parent.addChangeRequest(id, addToParent, false);
            }
        }

        void removeChangeRequest(String id) {
            removeChangeRequest(id, true);
        }

        void removeChangeRequest(String id, boolean recomputeParent) {
            doRemoveChangeRequest(id);
            if (parent != null && recomputeParent) {
                parent.recomputeRequests();
            }
        }

        int getSelectionState(RequestInfo requestInfo) {
            int result = OK;
            String relatedProject = getStringAttribute(requestInfo.request, SystemAttributes.PROJECT);
            if (considerProjectRelationship() && !Utils.isNullEmpty(relatedProject)
                    && !IDMConstants.GLOBAL_WORKSET.equals(relatedProject)) {
                Collection projects = getProjects();
                if (projects.size() > 1
                        || (projects.size() == 1 && !relatedProject.equalsIgnoreCase((String) projects.toArray()[0]))) {
                    result |= INVALID_PROJECT;
                }
            }
            if (!isAnyRequest()) { // check if satisfies cm rules requirements
                if (!isValidRelationship(requestInfo)) {
                    result |= INVALID_RELATIONSHIP;
                }
            }
            if (isRulesConflict(requestInfo)) {
                result |= RULES_ENABLEMENT_CONFLICT;
            }
            if (!isCorrectPhase(requestInfo)) {
                result |= INVALID_PHASE;
            }
            return result;
        }

        abstract void doAddChangeRequest(String id); // add to this and all children if container

        abstract void doRemoveChangeRequest(String id); // remove from this and all children if container

        abstract List getChangeRequests();

        abstract boolean isChangeRequestsMandatory();

        abstract Collection getItemTypes(); // returns a collection of TypeReference

        abstract Collection getProjects(); // returns a collection of project ids

        abstract boolean isValidRelationship(RequestInfo requestInfo); // returns if rel between this node and request type is valid

        abstract boolean isRulesConflict(RequestInfo requestInfo); // if item/request rules enablement mismatch

        abstract boolean isCorrectPhase(RequestInfo requestInfo);

        abstract boolean isAnyRequest(); // any request will do - comes from structure change rules

        abstract boolean considerProjectRelationship(); // if should take request to project relationship into account when
                                                        // calculating selection suitability
    }

    private abstract class RelatedChangeRequestsContainer extends RelatedChangeRequests {
        private List requests;
        private List children;

        RelatedChangeRequestsContainer(RelatedChangeRequestsContainer parent) {
            super(parent);
        }

        List getChildren() {
            if (children == null) {
                return Collections.EMPTY_LIST;
            }
            return children;
        }

        public void addChild(RelatedChangeRequests child) {
            if (children == null) {
                children = new ArrayList();
            }
            children.add(child);
        }

        void addChangeRequest(String id, boolean addToParent, boolean addToChildren) {
            internalAddChangeRequest(id, addToChildren);
            if (addToParent && getParent() != null) {
                getParent().addChangeRequest(id, addToParent, false);
            }
        }

        @Override
        void doAddChangeRequest(String id) {
            internalAddChangeRequest(id, true);
        }

        private void internalAddChangeRequest(String id, boolean addToChildren) {
            if (requests == null) {
                requests = new ArrayList();
            }
            if (!requests.contains(id)) {
                requests.add(id);
            }
            if (addToChildren) {
                addChangeRequestToChildren(id);
            }
        }

        private void addChangeRequestToChildren(String id) {
            if (children != null) {
                for (Iterator iter = children.iterator(); iter.hasNext();) {
                    RelatedChangeRequests child = (RelatedChangeRequests) iter.next();
                    child.addChangeRequest(id, child.getParent() != this/* , true */);
                }
            }
        }

        @Override
        void doRemoveChangeRequest(String id) {
            if (requests != null) {
                requests.remove(id);
            }
            removeChangeRequestFromChildren(id);
        }

        private void removeChangeRequestFromChildren(String id) {
            if (children != null) {
                for (Iterator iter = children.iterator(); iter.hasNext();) {
                    RelatedChangeRequests child = (RelatedChangeRequests) iter.next();
                    child.removeChangeRequest(id, child.getParent() != this);
                }
            }
        }

        @Override
        List getChangeRequests() {
            if (requests == null) {
                return Collections.EMPTY_LIST;
            }
            return requests;
        }

        @Override
        boolean isChangeRequestsMandatory() {
            if (children == null) {
                return false;
            }
            for (Iterator childIter = children.iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                if (rr.isChangeRequestsMandatory()) {
                    return true;
                }
            }
            return false;
        }

        @Override
        boolean isRulesConflict(RequestInfo requestInfo) {
            if (children == null) {
                return false;
            }
            for (Iterator childIter = children.iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                if (rr.isRulesConflict(requestInfo)) {
                    return true;
                }
            }
            return false;
        }

        @Override
        boolean isCorrectPhase(RequestInfo requestInfo) {
            if (children == null) {
                return false;
            }
            for (Iterator childIter = children.iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                if (!rr.isCorrectPhase(requestInfo)) {
                    return false;
                }
            }
            return true;
        }

        List getPartialRequests() {
            if (children == null || children.isEmpty() || requests == null || requests.isEmpty()) {
                return Collections.EMPTY_LIST;
            }
            ArrayList result = new ArrayList();
            for (Iterator iter = requests.iterator(); iter.hasNext();) {
                String request = (String) iter.next();
                if (isPartialRequest(request)) {
                    result.add(request);
                }
            }
            return result;
        }

        private boolean isPartialRequest(String request) {
            if (children == null) {
                return false;
            }
            for (Iterator iter = children.iterator(); iter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) iter.next();
                if (!rr.getChangeRequests().contains(request) || (rr instanceof RelatedChangeRequestsContainer)
                        && ((RelatedChangeRequestsContainer) rr).isPartialRequest(request)) {
                    return true;
                }
            }
            return false;
        }

        void recomputeRequests() {
            if (requests != null) {
                requests.clear();
            }
            if (children == null) {
                return;
            }
            HashSet _requests = new HashSet();
            for (Iterator iter = children.iterator(); iter.hasNext();) {
                RelatedChangeRequests child = (RelatedChangeRequests) iter.next();
                _requests.addAll(child.getChangeRequests());
            }
            if (!_requests.isEmpty()) {
                if (requests == null) {
                    requests = new ArrayList(_requests);
                } else {
                    requests.addAll(_requests);
                }
            }
            if (getParent() != null) {
                getParent().recomputeRequests();
            }
        }

        @Override
        Collection getProjects() {
            if (getChildren().isEmpty()) {
                return Collections.EMPTY_SET;
            }
            HashSet result = new HashSet();
            for (Iterator childIter = getChildren().iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                result.addAll(rr.getProjects());
            }
            return result;
        }

        @Override
        boolean isValidRelationship(RequestInfo requestInfo) {
            if (children == null) {
                return false;
            }
            for (Iterator childIter = children.iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                if (!rr.isValidRelationship(requestInfo)) {
                    return false; // invalid if at least one child is invalid
                }
            }
            return true;
        }

        @Override
        boolean isAnyRequest() {
            if (children == null) {
                return false;
            }
            for (Iterator childIter = children.iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                if (!rr.isAnyRequest()) {
                    return false; // any request is not allowed if at least one child says so
                }
            }
            return true;
        }

        @Override
        boolean considerProjectRelationship() {
            if (children == null) {
                return false;
            }
            for (Iterator childIter = children.iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                if (rr.considerProjectRelationship()) {
                    return true; // require valid project if at least one
                }
            }
            return false;
        }
    }

    private class MultiSelectionContainer extends RelatedChangeRequestsContainer {

        MultiSelectionContainer(RelatedChangeRequests[] children) {
            super(null);
            for (int i = 0; i < children.length; i++) {
                addChild(children[i]);
                List cr = children[i].getChangeRequests();
                for (Iterator iterator = cr.iterator(); iterator.hasNext();) {
                    String id = (String) iterator.next();
                    addChangeRequest(id, false, false);
                }
            }
        }

        @Override
        Collection getItemTypes() {
            if (getChildren().isEmpty()) {
                return Collections.EMPTY_SET;
            }
            HashSet result = new HashSet();
            for (Iterator childIter = getChildren().iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                result.addAll(rr.getItemTypes());
            }
            return result;
        }

    }

    private class AllTypes extends RelatedChangeRequestsContainer {
        AllTypes(RelatedChangeRequestsContainer parent) {
            super(parent);
        }

        TypeInfo findType(String product, String type) {
            List children = getChildren();
            for (Iterator iter = children.iterator(); iter.hasNext();) {
                Object next = iter.next();
                if (next instanceof TypeInfo) {
                    TypeInfo typeInfo = (TypeInfo) next;
                    if (typeInfo.type.getProduct().equalsIgnoreCase(product) && typeInfo.type.getTypeName().equalsIgnoreCase(type)) {
                        return typeInfo;
                    }
                }
            }
            return null;
        }

        @Override
        Collection getItemTypes() {
            if (getChildren().isEmpty()) {
                return Collections.EMPTY_SET;
            }
            ArrayList result = new ArrayList();
            for (Iterator childIter = getChildren().iterator(); childIter.hasNext();) {
                RelatedChangeRequests rr = (RelatedChangeRequests) childIter.next();
                if (rr instanceof TypeInfo) {
                    result.add(((TypeInfo) rr).type);
                }
            }
            return result;
        }
    }

    private class TypeInfo extends RelatedChangeRequestsContainer {
        TypeReference type;

        TypeInfo(RelatedChangeRequestsContainer parent, String product, String type/* , boolean rulesOn */) {
            super(parent);
            this.type = new TypeReference(getConnection(), product, DMTypeScope.ITEM, type);
        }

        String getTypeString() {
            return type.getProduct() + ':' + type.getTypeName();
        }

        @Override
        Collection getItemTypes() {
            return Collections.singletonList(type);
        }
    }

    private class Folders extends RelatedChangeRequestsContainer {
        Folders(RelatedChangeRequestsContainer parent) {
            super(parent);
        }

        @Override
        Collection getItemTypes() {
            return Collections.EMPTY_LIST;
        }

    }

    private abstract class ResourceInfo extends RelatedChangeRequests {
        private WorkspaceResourceRequest resRequest;

        ResourceInfo(RelatedChangeRequestsContainer parent, WorkspaceResourceRequest resRequest) {
            super(parent);
            assert resRequest != null;
            this.resRequest = resRequest;
            if (parent != null) {
                List changeRequests = resRequest.getChangeRequests();
                for (Iterator reqIter = changeRequests.iterator(); reqIter.hasNext();) {
                    String request = (String) reqIter.next();
                    parent.addChangeRequest(request, true, false);
                }
            }
        }

        @Override
        void doAddChangeRequest(String id) {
            resRequest.addChangeRequest(id);
        }

        @Override
        void doRemoveChangeRequest(String id) {
            resRequest.removeChangeRequest(id);
        }

        @Override
        List getChangeRequests() {
            return resRequest.getChangeRequests();
        }

        @Override
        boolean isChangeRequestsMandatory() {
            return resRequest.isRequestsMandatory();
        }

        IResource getResource() {
            return resRequest.getResource();
        }

        @Override
        Collection getProjects() {
            IResource res = resRequest.getResource();
            try {
                String pid = DMTeamPlugin.getWorkspace().getProject(res).getId();
                return Collections.singletonList(pid);
            } catch (CoreException e) {
                DMTeamUiPlugin.log(e.getStatus());
            }
            return Collections.EMPTY_LIST;
        }

        @Override
        boolean isAnyRequest() {
            if (resRequest instanceof CMRulesSensitiveRequest) {
                return ((CMRulesSensitiveRequest) resRequest).isAnyRequest();
            }
            return true;
        }

        String getChangeKind() {
            ArrayList kinds = new ArrayList();
            int kind = resRequest.getKind();
            if ((kind & WorkspaceResourceRequest.MOVE) != 0) {
                kinds.add(Messages.TeamOperationWizardRequestPage_29);
            }
            if ((kind & WorkspaceResourceRequest.IMPORT) != 0) {
                kinds.add(Messages.TeamOperationWizardRequestPage_30);
            }
            if ((kind & WorkspaceResourceRequest.CREATE) != 0) {
                kinds.add(Messages.TeamOperationWizardRequestPage_31);
            }
            if ((kind & WorkspaceResourceRequest.DELETE) != 0) {
                kinds.add(Messages.TeamOperationWizardRequestPage_32);
            }
            if ((kind & WorkspaceResourceRequest.MODIFY) != 0) {
                kinds.add(Messages.TeamOperationWizardRequestPage_33);
            }
            return Utils.toCsvString(kinds.toArray(), true);
        }

        String getProjectId() {
            try {
                return DMTeamPlugin.getWorkspace().getProject(resRequest.getResource()).getId();
            } catch (CoreException e) {
                DMTeamUiPlugin.log(e.getStatus());
            }
            return Utils.EMPTY_STRING;
        }
    }

    private class FileInfo extends ResourceInfo {
        private ItemRequest fileRequest;

        FileInfo(RelatedChangeRequestsContainer parent, ItemRequest fileRequest) {
            super(parent, fileRequest);
            assert fileRequest != null;
            this.fileRequest = fileRequest;
        }

        @Override
        boolean isRulesConflict(RequestInfo requestInfo) {
            if (fileRequest instanceof CMRulesSensitiveRequest) {
                return ((CMRulesSensitiveRequest) fileRequest).isRulesEnabled() ^ requestInfo.rulesEnabled;
            }
            return false;
        }

        boolean isRulesEnabled() {
            if (fileRequest instanceof CMRulesSensitiveRequest) {
                return ((CMRulesSensitiveRequest) fileRequest).isRulesEnabled();
            }
            return false;
        }

        @Override
        boolean isCorrectPhase(RequestInfo requestInfo) {
            String phase = getStringAttribute(requestInfo.request, SystemAttributes.CM_PHASE);
            if (Utils.isNullEmpty(phase)) {
                return true; // safer to allow if somehow missing
            }
            if (isRulesEnabled() && !isAnyRequest()) {
                return IDMConstants.WORK_PHASE.equalsIgnoreCase(phase) || IDMConstants.ANWORK_PHASE.equalsIgnoreCase(phase);
            }
            return !(IDMConstants.CLOSED_PHASE.equalsIgnoreCase(phase) || IDMConstants.REJECTED_PHASE.equals(phase));
        }

        @Override
        Collection getItemTypes() {
            return Collections.singletonList(((TypeInfo) getParent()).type);
        }

        @Override
        boolean isValidRelationship(RequestInfo requestInfo) {
            if (!isRulesEnabled()) {
                return true;
            }
            Collection validTypes = (Collection) validRelationships.get(requestInfo.type);
            TypeReference myType = ((TypeInfo) getParent()).type;
            return validTypes != null ? validTypes.contains(myType) : false;
        }

        @Override
        boolean considerProjectRelationship() {
            return fileRequest instanceof CMRulesSensitiveRequest; // only consider project in the context of traditional CM rules
        }
    }

    private class FolderInfo extends ResourceInfo {

        FolderInfo(RelatedChangeRequestsContainer parent, FolderRequest folderRequest) {
            super(parent, folderRequest);
        }

        @Override
        Collection getItemTypes() {
            return Collections.EMPTY_LIST;
        }

        @Override
        boolean isCorrectPhase(RequestInfo requestInfo) {
            return true;
        }

        @Override
        boolean isRulesConflict(RequestInfo requestInfo) {
            return false;
        }

        @Override
        boolean isValidRelationship(RequestInfo requestInfo) {
            return true;
        }

        @Override
        boolean considerProjectRelationship() {
            return false; // can only select folders in the context of a structure change for which there are no restrictions
        }

    }

    private class RequestInfo {
        ChangeDocumentAdapter request;
        TypeReference type;
        boolean rulesEnabled;

        RequestInfo(ChangeDocumentAdapter request, String product, String type) {
            this.request = request;
            this.type = new TypeReference(getConnection(), product, DMTypeScope.REQUEST, type);
        }
    }

    public DimensionsRequestPage(String pageName, String title, String description, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(description);
        settings = DMTeamUiPlugin.getDefault().getDialogSettings().getSection(this.getClass().getName());
        if (settings == null) {
            settings = DMTeamUiPlugin.getDefault().getDialogSettings().addNewSection(this.getClass().getName());
        }
        useStoredSelection = settings.getBoolean(USE_STORED_SELECTION);
        storedSelection = settings.getArray(STORED_SELECTION);
    }

    @Override
    public void saveSettings() {
        if (root != null) {
            settings.put(USE_STORED_SELECTION, useStoredSelection);
            List allSelected = root.getChangeRequests();
            settings.put(STORED_SELECTION, useStoredSelection
                    ? (String[]) allSelected.toArray(new String[allSelected.size()]) : Utils.ZERO_LENGTH_STRING_ARRAY);
        }
    }

    @Override
    public void setResources(WorkspaceResourceRequest[] files) {
        this.resources = files;
        root = null;
        folders = null;
        validate(false);
    }

    @Override
    public void setVisible(boolean visible) {
        if (documents == null) {
            createRequestInfos();
            setDocuments();
        }
        if (visible) {
            if (root == null && resources != null) {
                root = new AllTypes(null);
                buildTree(root);
                typeTreeViewer.setInput(this);
                typeTreeViewer.setSelection(new StructuredSelection(root), true);
            }
            validate(true);
        }
        super.setVisible(visible);
    }

    private void setDocuments() {
        RelatedChangeRequests rcr = getSelectedRelatedRequests();
        if (useActivated) {
            documents = documentsActivated;
        } else {
            documents = documentsPending;
        }
        docTableViewer.setInput(documents);
        docActivatedTableViewer.setInput(documents);
        updateCheckboxes(rcr);
    }

    private boolean preselectDefaultRequests() {
        return DMTeamUiPlugin.getDefault().getPreferenceStore().getBoolean(IDMTeamPreferences.PRESELECT_DEFAULT_REQUESTS);
    }

    protected void buildTree(AllTypes allTypes) {
        for (int i = 0; i < resources.length; i++) {
            if (!resources[i].isRequestSupported()) {
                continue;
            }

            RelatedChangeRequests node = null;

            if (resources[i] instanceof ItemRequest) {
                ItemRequest typedFileRequest = (ItemRequest) resources[i];
                String productName = typedFileRequest.getProductName();
                String typeName = typedFileRequest.getTypeName();
                TypeInfo typeInfo = allTypes.findType(productName, typeName);
                if (typeInfo == null) {
                    typeInfo = new TypeInfo(allTypes, productName, typeName);
                }
                node = new FileInfo(typeInfo, typedFileRequest);
            } else if (resources[i] instanceof FolderRequest) {
                if (folders == null) {
                    folders = new Folders(allTypes);
                }
                node = new FolderInfo(folders, (FolderRequest) resources[i]);
            }

            if (node != null) {
                // configure defaults
                if (useStoredSelection && storedSelection != null && storedSelection.length > 0) {
                    for (int j = 0; j < storedSelection.length; j++) {
                        if (documents.containsKey(storedSelection[j])) {
                            RequestInfo requestInfo = (RequestInfo) documents.get(storedSelection[j]);
                            if (node.getSelectionState(requestInfo) == OK) {
                                node.addChangeRequest(storedSelection[j]);
                            }
                        }
                    }
                } else if (preselectDefaultRequests()) {
                    IResource res = resources[i].getResource();
                    try {
                        IDMProject project = DMTeamPlugin.getWorkspace().getProject(res);
                        if (project.isWorkset()) {
                            String dr = (String) defaultRequests.get(project.getId());
                            // if there is a pending default and it is a valid relationship add to each file
                            Object doc = null;
                            if (!Utils.isNullEmpty(dr)
                                    && ((doc = documentsPending.get(dr)) != null || (doc = documentsActivated.get(dr)) != null)) {
                                if (node.getSelectionState((RequestInfo) doc) == OK) {
                                    node.addChangeRequest(dr);
                                }
                            }
                        }
                    } catch (CoreException e) {
                        DMTeamUiPlugin.log(e.getStatus());
                    }
                }
            }

        }
    }

    private DimensionsConnectionDetailsEx getConnection() {
        return ((TeamOperationWizard) getWizard()).getConnection();
    }

    private Map readRequestInfo(ChangeDocumentList myPending, DimensionsConnectionDetailsEx connection, String id,
            IProgressMonitor monitor) throws Exception {
        Map result = null;
        try {
            int[] attrs = new int[] { SystemAttributes.OBJECT_ID, SystemAttributes.STATUS, SystemAttributes.TITLE,
                    SystemAttributes.PRODUCT_NAME, SystemAttributes.TYPE_NAME, SystemAttributes.NUMBER, SystemAttributes.PROJECT,
                    SystemAttributes.CM_PHASE };

            myPending.attributeSubscribe(id, attrs);
            myPending.fetch(Utils.subMonitorFor(monitor, 60));

            IProgressMonitor subMon = Utils.subMonitorFor(monitor, preselectDefaultRequests() ? 20 : 40,
                    SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK);
            if (validRelationships == null) { // DEF160587 fix
                validRelationships = new HashMap();
            }
            APIObjectAdapter[] myDocs = myPending.getObjects();
            result = new HashMap(myDocs.length);
            subMon.beginTask(Messages.TeamOperationWizardRequestPage_4, myDocs.length * 3);
            for (int i = 0; i < myDocs.length; i++) {
                ChangeDocumentAdapter aDoc = (ChangeDocumentAdapter) myDocs[i];
                String docProductName = getStringAttribute(aDoc, SystemAttributes.PRODUCT_NAME);
                String docTypeName = getStringAttribute(aDoc, SystemAttributes.TYPE_NAME);
                String docId = getStringAttribute(aDoc, SystemAttributes.OBJECT_ID);
                RequestInfo requestInfo = new RequestInfo(aDoc, docProductName, docTypeName);
                requestInfo.rulesEnabled = ((RequestType) requestInfo.type.getType()).getCmRules().getEnabled(); // this will also
                                                                                                                 // cache the type
                result.put(docId, requestInfo);
                subMon.subTask(docProductName + ':' + docTypeName);
                if (!validRelationships.containsKey(requestInfo.type)) {
                    Set relItemTypes = new HashSet();
                    validRelationships.put(requestInfo.type, relItemTypes);
                    final RequestType docType = (RequestType) connection.getType(aDoc.getChangeDocument(),
                            Utils.subMonitorFor(subMon, 1)); // 1
                    final List[] valRels = new List[1];
                    connection.openSession(Utils.subMonitorFor(subMon, 1)).run(new ISessionRunnable() { // 2
                                @Override
                                public void run() throws Exception {
                                    valRels[0] = docType.getValidRelationshipNames(false); // may want to requery each time ???
                                }
                            }, subMon);
                    for (Iterator relIter = valRels[0].iterator(); relIter.hasNext();) {
                        RequestType.ValidRelationshipName rel = (RequestType.ValidRelationshipName) relIter.next();
                        if (TypeScope.ITEM.equals(rel.getTypeScope())) {
                            relItemTypes.add(new TypeReference(getConnection(), rel.getChildProductName(), DMTypeScope.ITEM,
                                    rel.getChildTypeName()));
                        }
                    }
                    subMon.worked(1); // 3
                } else {
                    subMon.worked(3); // 3
                }
            }
            subMon.done();

            if (preselectDefaultRequests()) {
                subMon = Utils.subMonitorFor(monitor, 20, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK);
                subMon.beginTask(Messages.TeamOperationWizardRequestPage_24, resources.length + 1);
                // remember default requests
                defaultRequests = new HashMap(0);
                HashSet addedProjects = new HashSet();
                final ArrayList projects = new ArrayList();
                for (int i = 0; i < resources.length; i++) {
                    IResource resource = resources[i].getResource();
                    IDMProject dmPrj = DMTeamPlugin.getWorkspace().getProject(resource);
                    if (dmPrj.isWorkset() && !addedProjects.contains(dmPrj)) {
                        subMon.subTask(dmPrj.getId());
                        Project prj = (Project) dmPrj.getDimensionsObject();
                        projects.add(prj);
                        addedProjects.add(dmPrj);
                    }
                    subMon.worked(1);
                }
                addedProjects = null; // give it to gc
                if (!projects.isEmpty()) {
                    final Session session = getConnection().openSession(null);
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            Utils.queryAttributes(projects, new int[] { SystemAttributes.DEFAULT_REQUEST },
                                    session.getObjectFactory(), true);
                        }
                    }, subMon);
                    for (Iterator iter = projects.iterator(); iter.hasNext();) {
                        Project prj = (Project) iter.next();
                        String dr = (String) prj.getAttribute(SystemAttributes.DEFAULT_REQUEST);
                        if (!Utils.isNullEmpty(dr)) {
                            defaultRequests.put(prj.getAttribute(SystemAttributes.OBJECT_SPEC), dr);
                        }
                    }
                }
                subMon.worked(1);
                subMon.done();
            }
        } finally {
            if (myPending != null) {
                myPending.attributeUnsubscribe(id);
            }
            monitor.setTaskName(Utils.EMPTY_STRING);
            monitor.subTask(Utils.EMPTY_STRING);
            monitor.done();
        }
        return result;
    }

    protected void createRequestInfos() {
        final DimensionsConnectionDetailsEx connection = getConnection();

        try {
            getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    ChangeDocumentList myPending = null;
                    String id = DimensionsRequestPage.class.getName();
                    try {
                        monitor.beginTask(null, 110);
                        documentsPending = readRequestInfo(ChangeDocumentList.getMyPendingList(connection), connection, id, monitor);
                        documentsActivated = readRequestInfo(
                                ChangeDocumentList.getActiveRequestsList(connection, Utils.subMonitorFor(monitor, 10)), connection,
                                id, monitor);
                    } catch (Exception e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        if (myPending != null) {
                            myPending.attributeUnsubscribe(id);
                        }
                        monitor.setTaskName(Utils.EMPTY_STRING);
                        monitor.subTask(Utils.EMPTY_STRING);
                        monitor.done();
                    }
                }

            });
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e, getContainer().getShell());
        } catch (InterruptedException e) {
        }
    }

    @Override
    public void createControl(Composite parent) {
        SashForm sashForm = new SashForm(parent, SWT.VERTICAL);
        createTypeTreeViewer(sashForm);
        createDocumentTableViewer(sashForm);
        sashForm.setWeights(new int[] { 40, 50 });
        setControl(sashForm);
    }

    public String[] getAllSelectedRequests() {
        List allSelected = root.getChangeRequests();
        return (String[]) allSelected.toArray(new String[allSelected.size()]);
    }

    private void createTypeTreeViewer(Composite composite) {
    	Tree tree = new Tree(composite, SWT.MULTI | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL | SWT.BORDER);
    	tree.setHeaderVisible(true);
    	tree.setLinesVisible(true);

        TreeColumn treeCol = new TreeColumn(tree, SWT.NONE);
        treeCol.setResizable(true);
        treeCol.setText(Messages.TeamOperationWizardRequestPage_5);
        treeCol.setWidth(WizardHelper.getColumnWidth(settings, COL_TYPE_TREE_TREE_WIDTH, 20));
        treeCol.addControlListener(new TableColumnListener(COL_TYPE_TREE_TREE_WIDTH, settings));

        TreeColumn changeKindCol = new TreeColumn(tree, SWT.NONE);
        changeKindCol.setResizable(true);
        changeKindCol.setText(Messages.TeamOperationWizardRequestPage_34);
        changeKindCol.setWidth(WizardHelper.getColumnWidth(settings, COL_TYPE_TREE_CHKIND_WIDTH, 30));
        changeKindCol.addControlListener(new TableColumnListener(COL_TYPE_TREE_CHKIND_WIDTH, settings));

        TreeColumn rulesOnCol = new TreeColumn(tree, SWT.NONE);
        rulesOnCol.setResizable(true);
        rulesOnCol.setText(Messages.TeamOperationWizardRequestPage_6);
        rulesOnCol.setWidth(WizardHelper.getColumnWidth(settings, COL_TYPE_TREE_RULESON_WIDTH, 10));
        rulesOnCol.addControlListener(new TableColumnListener(COL_TYPE_TREE_RULESON_WIDTH, settings));

        TreeColumn docsCol = new TreeColumn(tree, SWT.NONE);
        docsCol.setResizable(true);
        docsCol.setText(Messages.TeamOperationWizardRequestPage_7);
        docsCol.setWidth(WizardHelper.getColumnWidth(settings, COL_TYPE_TREE_DOCS_WIDTH, 20));
        docsCol.addControlListener(new TableColumnListener(COL_TYPE_TREE_DOCS_WIDTH, settings));

        if (DMTeamUiPlugin.getDefault().isShowProjectOnRequestSelectionPage()) {
        	TreeColumn projCol = new TreeColumn(tree, SWT.NONE);
            projCol.setResizable(true);
            projCol.setText(Messages.TeamOperationWizardRequestPage_35);
            projCol.setWidth(WizardHelper.getColumnWidth(settings, COL_TYPE_TREE_PROJ_WIDTH, 30));
            projCol.addControlListener(new TableColumnListener(COL_TYPE_TREE_PROJ_WIDTH, settings));
        }
        tree.setFocus();

        typeTreeViewer = new TreeViewer(tree);
        typeTreeViewer.setContentProvider(new TypeTreeContentProvider());
        typeTreeViewer.setLabelProvider(new TypeTreeLabelProvider());
        typeTreeViewer.setSorter(new TypeTreeSorter());

        if (root != null) {
            typeTreeViewer.setInput(root);
        }

        typeTreeViewer.addSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                ISelection sel = event.getSelection();
                if (useActivated) {
                    docActivatedTableViewer.refresh();
                } else {
                    docTableViewer.refresh(); // refresh viewer before setting checked state
                }
                if (!sel.isEmpty() && sel instanceof IStructuredSelection) {
                    IStructuredSelection ssel = (IStructuredSelection) sel;
                    RelatedChangeRequests rr;
                    if (ssel.size() == 1) {
                        rr = (RelatedChangeRequests) ssel.getFirstElement();
                    } else {
                        RelatedChangeRequests[] selectedNodes = new RelatedChangeRequests[ssel.size()];
                        System.arraycopy(ssel.toArray(), 0, selectedNodes, 0, ssel.size());
                        rr = new MultiSelectionContainer(getNonOverlapping(selectedNodes));
                    }
                    updateCheckboxes(rr);
                }
            }
        });
    }

    private RelatedChangeRequests[] getNonOverlapping(RelatedChangeRequests[] rcrs) {
        List sorted = new ArrayList(Arrays.asList(rcrs));
        Collections.sort(sorted, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                RelatedChangeRequests rcr1 = (RelatedChangeRequests) o1;
                RelatedChangeRequests rcr2 = (RelatedChangeRequests) o2;
                return rcr1.getDepth() - rcr2.getDepth();
            }

            @Override
            public boolean equals(Object obj) {
                return false;
            }
        });

        List coveredNodes = new ArrayList();
        for (Iterator iterator = sorted.iterator(); iterator.hasNext();) {
            RelatedChangeRequests rcr = (RelatedChangeRequests) iterator.next();
            boolean covered = false;
            for (Iterator iterator2 = coveredNodes.iterator(); iterator2.hasNext();) {
                RelatedChangeRequestsContainer node = (RelatedChangeRequestsContainer) iterator2.next();
                if (rcr.isReacheableFrom(node)) {
                    covered = true;
                }
            }
            if (covered) {
                iterator.remove();
            } else {
                if (rcr instanceof RelatedChangeRequestsContainer) {
                    coveredNodes.add(rcr);
                }
            }
        }
        return (RelatedChangeRequests[]) sorted.toArray(new RelatedChangeRequests[sorted.size()]);
    }

    private void setUseActivated(boolean b) {
        useActivated = b;
        deactivateRequestsBtn.setVisible(useActivated);
        storeSelectionBtn.setEnabled(!useActivated || !deactivateRequests);
    }

    private void createDocumentTableViewer(final SashForm parent) {
        final Composite composite = new Composite(parent, SWT.NONE);
        GridLayout gl = UIUtils.setGridLayout(composite, 1);
        gl.marginHeight = gl.marginWidth = 0;
        parent.setMaximizedControl(composite);

        final CTabFolder tabFolder = new CTabFolder(composite, SWT.TOP | SWT.FLAT | SWT.MULTI | SWT.BORDER);
        tabFolder.setMaximizeVisible(true);
        tabFolder.setMaximized(true);
        UIUtils.setGridData(tabFolder, GridData.FILL_BOTH);

        useActivated = DMTeamUiPlugin.getDefault().isUseActivatedRequests();
        deactivateRequests = DMTeamUiPlugin.getDefault().isDeactivateRequestsByDefault();

        Table table = createTableForRequests(tabFolder);

        CTabItem tabItem = new CTabItem(tabFolder, SWT.NONE);
        tabItem.setText(Messages.TeamOperationWizardRequestPage_39);
        tabItem.setControl(table);

        final CTabItem tabItemA = new CTabItem(tabFolder, SWT.NONE);
        tabItemA.setText(Messages.TeamOperationWizardRequestPage_Favorites);

        Table tableA = createTableForRequests(tabFolder);
        tabItemA.setControl(tableA);

        tabFolder.addSelectionListener(new SelectionListener() {
            @Override
            public void widgetDefaultSelected(SelectionEvent e) {
                setUseActivated(e.item == tabItemA);
                setDocuments();
            }

            @Override
            public void widgetSelected(SelectionEvent e) {
                setUseActivated(e.item == tabItemA);
                setDocuments();
            }
        });

        if (useActivated) {
            tabFolder.setSelection(tabItemA);
        }

        RequestContentProvider rcp = new RequestContentProvider();
        RequestLabelProvider rlp = new RequestLabelProvider();
        RequestSorter rs = new RequestSorter();

        docTableViewer = new CheckboxTableViewer(table);
        docTableViewer.setContentProvider(rcp);
        docTableViewer.setLabelProvider(rlp);
        docTableViewer.setSorter(rs);
        docTableViewer.addFilter(new RequestFilter());

        docActivatedTableViewer = new CheckboxTableViewer(tableA);
        docActivatedTableViewer.setContentProvider(rcp);
        docActivatedTableViewer.setLabelProvider(rlp);
        docActivatedTableViewer.setSorter(rs);
        docActivatedTableViewer.addFilter(new RequestFilter());

        if (documents != null) {
            docTableViewer.setInput(documents);
            docActivatedTableViewer.setInput(documents);
        }

        docTableViewer.addCheckStateListener(new ICheckStateListener() {
            @Override
            public void checkStateChanged(CheckStateChangedEvent event) {
                RequestInfo ri = (RequestInfo) event.getElement();
                RelatedChangeRequests rcr = getSelectedRelatedRequests();
                if (event.getChecked() && rcr != null && rcr.getSelectionState(ri) != OK) {
                    docTableViewer.setChecked(ri, false); // undo invalid checks
                    return;
                }
                updateSelectedRequests(ri, event.getChecked(), rcr);
                if (!event.getChecked()) {
                    updatePartialSelection(rcr);
                }
            }
        });

        docActivatedTableViewer.addCheckStateListener(new ICheckStateListener() {
            @Override
            public void checkStateChanged(CheckStateChangedEvent event) {
                RequestInfo ri = (RequestInfo) event.getElement();
                RelatedChangeRequests rcr = getSelectedRelatedRequests();
                if (event.getChecked() && rcr != null && rcr.getSelectionState(ri) != OK) {
                    docActivatedTableViewer.setChecked(ri, false); // undo invalid checks
                    return;
                }
                updateSelectedRequests(ri, event.getChecked(), rcr);
                if (!event.getChecked()) {
                    updatePartialSelection(rcr);
                }
            }
        });

        Composite buttons = new Composite(composite, SWT.NONE);
        UIUtils.setGridLayout(buttons, 6);

        selectAllBtn = new Button(buttons, SWT.PUSH);
        selectAllBtn.setText(Messages.TeamOperationWizardRequestPage_13);

        deselectAllBtn = new Button(buttons, SWT.PUSH);
        deselectAllBtn.setText(Messages.TeamOperationWizardRequestPage_14);

        fixRelationshipsBtn = new Button(buttons, SWT.PUSH);
        fixRelationshipsBtn.setText(Messages.TeamOperationWizardRequestPage_18);
        fixRelationshipsBtn.setToolTipText(Messages.TeamOperationWizardRequestPage_19);

        storeSelectionBtn = new Button(buttons, SWT.CHECK);
        storeSelectionBtn.setText(Messages.TeamOperationWizardRequestPage_15);
        storeSelectionBtn.setSelection(useStoredSelection);

        showAllBtn = new Button(buttons, SWT.CHECK);
        showAllBtn.setText(Messages.TeamOperationWizardRequestPage_25);

        deactivateRequestsBtn = new Button(buttons, SWT.CHECK);
        deactivateRequestsBtn.setText(Messages.TeamOperationWizardRequestPage_41);
        deactivateRequestsBtn.setSelection(deactivateRequests);
        deactivateRequestsBtn.setVisible(useActivated);

        storeSelectionBtn.setEnabled(!useActivated || !deactivateRequests);

        SelectionListener btnSelectionListener = new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                RelatedChangeRequests rcr = getSelectedRelatedRequests();
                if (e.widget == selectAllBtn) {
                    for (Iterator docIter = documents.values().iterator(); docIter.hasNext();) {
                        RequestInfo ri = (RequestInfo) docIter.next();
                        if (rcr != null && rcr.getSelectionState(ri) == OK) {
                            if (useActivated) {
                                docActivatedTableViewer.setChecked(ri, true);
                            } else {
                                docTableViewer.setChecked(ri, true);
                            }
                            updateSelectedRequests(ri, true, rcr);
                        }
                    }
                    updatePartialSelection(rcr);
                    return;
                }

                if (e.widget == deselectAllBtn) {
                    for (Iterator docIter = documents.values().iterator(); docIter.hasNext();) {
                        RequestInfo ri = (RequestInfo) docIter.next();
                        if (useActivated) {
                            docActivatedTableViewer.setChecked(ri, false);
                        } else {
                            docTableViewer.setChecked(ri, false);
                        }
                        updateSelectedRequests(ri, false, rcr);
                    }
                    updatePartialSelection(rcr);
                    return;
                }

                if (e.widget == fixRelationshipsBtn) {
                    ISelection selection = useActivated ? docActivatedTableViewer.getSelection() : docTableViewer.getSelection();
                    if (!selection.isEmpty() && selection instanceof IStructuredSelection) {
                        if (MessageDialog.openQuestion(getShell(), Messages.TeamOperationWizardRequestPage_20,
                                Messages.TeamOperationWizardRequestPage_21)) {
                            fixRelationships(((IStructuredSelection) selection).toList());
                        }
                    }
                }

                if (e.widget == storeSelectionBtn) {
                    useStoredSelection = storeSelectionBtn.getSelection();
                    return;
                }
                if (e.widget == deactivateRequestsBtn) {
                    deactivateRequests = deactivateRequestsBtn.getSelection();
                    storeSelectionBtn.setEnabled(!useActivated || !deactivateRequests);
                    return;
                }

                if (e.widget == showAllBtn) {
                    docTableViewer.refresh();
                    docActivatedTableViewer.refresh();
                    updateCheckboxes(rcr);
                }
            }
        };
        selectAllBtn.addSelectionListener(btnSelectionListener);
        deselectAllBtn.addSelectionListener(btnSelectionListener);
        fixRelationshipsBtn.addSelectionListener(btnSelectionListener);
        storeSelectionBtn.addSelectionListener(btnSelectionListener);
        deactivateRequestsBtn.addSelectionListener(btnSelectionListener);
        showAllBtn.addSelectionListener(btnSelectionListener);

        tabFolder.addCTabFolder2Listener(new CTabFolder2Adapter() {
            @Override
            public void maximize(CTabFolderEvent event) {
                tabFolder.setMaximized(true);
                parent.setMaximizedControl(composite);
            }

            @Override
            public void restore(CTabFolderEvent event) {
                tabFolder.setMaximized(false);
                parent.setMaximizedControl(null);
            }
        });
    }

    private Table createTableForRequests(Composite parent) {
        Table table = new Table(parent, SWT.CHECK | SWT.FULL_SELECTION | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL | SWT.BORDER);

        UIUtils.setGridData(table, GridData.FILL_BOTH);
        table.setHeaderVisible(true);
        table.setLinesVisible(true);

        TableLayout tableLayout = new TableLayout();

        TableColumn docIdCol = new TableColumn(table, SWT.NONE);
        docIdCol.setResizable(true);
        docIdCol.setText(Messages.TeamOperationWizardRequestPage_9);
        tableLayout.addColumnData(WizardHelper.getColumnLayoutData(settings, COL_DOC_ID_WIDTH, 20));
        docIdCol.addControlListener(new TableColumnListener(COL_DOC_ID_WIDTH, settings));

        TableColumn statusCol = new TableColumn(table, SWT.NONE);
        statusCol.setResizable(true);
        statusCol.setText(Messages.TeamOperationWizardRequestPage_10);
        tableLayout.addColumnData(WizardHelper.getColumnLayoutData(settings, COL_DOC_STATUS_WIDTH, 15));
        statusCol.addControlListener(new TableColumnListener(COL_DOC_STATUS_WIDTH, settings));

        TableColumn titleCol = new TableColumn(table, SWT.NONE);
        titleCol.setResizable(true);
        titleCol.setText(Messages.TeamOperationWizardRequestPage_11);
        tableLayout.addColumnData(WizardHelper.getColumnLayoutData(settings, COL_DOC_TITLE_WIDTH, 30));
        titleCol.addControlListener(new TableColumnListener(COL_DOC_TITLE_WIDTH, settings));

        TableColumn detailsCol = new TableColumn(table, SWT.NONE);
        detailsCol.setResizable(true);
        detailsCol.setText(Messages.TeamOperationWizardRequestPage_12);
        tableLayout.addColumnData(WizardHelper.getColumnLayoutData(settings, COL_DOC_DETAILS_WIDTH, 15));
        detailsCol.addControlListener(new TableColumnListener(COL_DOC_DETAILS_WIDTH, settings));
        table.setLayout(tableLayout);

        return table;
    }

    protected void fixRelationships(List requests) {
        final ArrayList toUnrelateFrom = new ArrayList();
        for (Iterator iter = requests.iterator(); iter.hasNext();) {
            RequestInfo requestInfo = (RequestInfo) iter.next();
            String relatedPrj = getStringAttribute(requestInfo.request, SystemAttributes.PROJECT);
            if (!Utils.isNullEmpty(relatedPrj)) {
                toUnrelateFrom.add(requestInfo.request);
            }
        }

        if (toUnrelateFrom.isEmpty()) {
            return;
        }

        try {
            getContainer().run(true, true, new IRunnableWithProgress() {
                @Override
                public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    monitor.beginTask(Messages.TeamOperationWizardRequestPage_22, toUnrelateFrom.size() * 2);
                    try {
                        final Session session = getConnection().openSession(null);
                        session.run(new ISessionRunnable() {
                            @Override
                            public void run() throws Exception {
                                for (Iterator iter = toUnrelateFrom.iterator(); iter.hasNext();) {
                                    ChangeDocumentAdapter request = (ChangeDocumentAdapter) iter.next();
                                    String relatedPrj = getStringAttribute(request, SystemAttributes.PROJECT);
                                    assert relatedPrj != null;
                                    Project project = session.getObjectFactory().getProject(relatedPrj);
                                    monitor.worked(1);
                                    if (project != null) {
                                        request.getChangeDocument().removeParent(SystemRelationship.OWNED, project);
                                        request.getChangeDocument().setAttribute(SystemAttributes.PROJECT, null);
                                        monitor.worked(1);
                                    }
                                }
                            }
                        }, monitor);
                    } catch (DMException e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        } catch (InterruptedException ignore) {
        }
        if (useActivated) {
            docActivatedTableViewer.refresh();
        } else {
            docTableViewer.refresh();
        }
        RelatedChangeRequests rr = getSelectedRelatedRequests();
        if (rr != null) {
            updateCheckboxes(rr);
        }
    }

    private void updateCheckboxes(RelatedChangeRequests rr) {
        Object[] elementsToCheck = (rr == null) ? Utils.ZERO_LENGTH_OBJECT_ARRAY : rr.getRequestInfos();
        if (useActivated) {
            docActivatedTableViewer.setCheckedElements(elementsToCheck);
        } else {
            docTableViewer.setCheckedElements(elementsToCheck);
        }
        updatePartialSelection(rr);
    }

    private void updatePartialSelection(RelatedChangeRequests rr) {
        if (rr == null) {
            if (useActivated) {
                docActivatedTableViewer.setGrayedElements(Utils.ZERO_LENGTH_OBJECT_ARRAY);
            } else {
                docTableViewer.setGrayedElements(Utils.ZERO_LENGTH_OBJECT_ARRAY);
            }
            return;
        }
        List toGray = new ArrayList();
        if (rr instanceof RelatedChangeRequestsContainer) {
            List partialIds = ((RelatedChangeRequestsContainer) rr).getPartialRequests();
            toGray.addAll(getRequestInfos(partialIds));
        }
        if (useActivated) {
            docActivatedTableViewer.setGrayedElements(toGray.toArray());
        } else {
            docTableViewer.setGrayedElements(toGray.toArray());
        }
    }

    private List getRequestInfos(List ids) {
        ArrayList result = new ArrayList();
        for (Iterator idIter = ids.iterator(); idIter.hasNext();) {
            RequestInfo requestInfo = (RequestInfo) documents.get(idIter.next());
            assert requestInfo != null;
            result.add(requestInfo);
        }
        return result;
    }

    private void updateSelectedRequests(RequestInfo info, boolean selected, RelatedChangeRequests rr) {
        if (rr == null) {
            return;
        }
        String id = getStringAttribute(info.request, SystemAttributes.OBJECT_ID);
        if (selected) {
            rr.addChangeRequest(id);
        } else {
            rr.removeChangeRequest(id);
        }
        typeTreeViewer.refresh();
        validate(true);
    }

    private String getStringAttribute(APIObjectAdapter adapter, int attr) {
        return (String) adapter.getAPIObject().getAttribute(attr);
    }

    // sort order: product, type, number
    private int compareChangeRequests(RequestInfo r1, RequestInfo r2) {
        int result;
        if (r1 != null && r2 != null) {
            // use collator? how to detect server locale?
            String p1 = r1.type.getProduct();
            String p2 = r2.type.getProduct();
            result = p1.compareTo(p2);// collator.compare(p1, p2);
            if (result == 0) {
                String t1 = r1.type.getTypeName();
                String t2 = r2.type.getTypeName();
                result = t1.compareTo(t2);// collator.compare(t1, t2);
                if (result == 0) {
                    int n1 = ((Integer) r1.request.getChangeDocument().getAttribute(SystemAttributes.NUMBER)).intValue();
                    int n2 = ((Integer) r2.request.getChangeDocument().getAttribute(SystemAttributes.NUMBER)).intValue();
                    result = n2 - n1;
                }
            }
        } else {
            result = (r1 != null ? 1 : 0) - (r2 != null ? 1 : 0);
        }
        return result;
    }

    private RelatedChangeRequests getSelectedRelatedRequests() {
    	if (typeTreeViewer != null) {
            ISelection selection = typeTreeViewer.getSelection();
            if (!selection.isEmpty() && selection instanceof IStructuredSelection) {
                IStructuredSelection ssel = (IStructuredSelection) selection;
                if (ssel.size() == 1) {
                    return (RelatedChangeRequests) ssel.getFirstElement();
                }
                RelatedChangeRequests[] selectedNodes = new RelatedChangeRequests[ssel.size()];
                System.arraycopy(ssel.toArray(), 0, selectedNodes, 0, ssel.size());
                return new MultiSelectionContainer(getNonOverlapping(selectedNodes));
            }
        }
        return null;
    }

    @Override
    public void postCommit(TeamOperationWizardHelper helper) throws CoreException {
        if (deactivateRequests && helper != null) {
            helper.setPostCommandExecuteProvider(this);
        }
    }

    @Override
    public void postExecute(IProgressMonitor monitor) throws CoreException {
        if (deactivateRequests) {
            if (root != null && documentsActivated != null) {
                List requests = root.getChangeRequests();
                if (requests != null && requests.size() > 0) {
                    List selectedRequests = new ArrayList();
                    for (Iterator iter = requests.iterator(); iter.hasNext();) {
                        String rid = (String) iter.next();
                        Object obj = documentsActivated.get(rid);
                        if (obj instanceof RequestInfo) {
                            RequestInfo rinfo = (RequestInfo) obj;
                            selectedRequests.add(rinfo.request);
                        }
                    }
                    DimensionsConnectionDetailsEx connection = getConnection();
                    MyWorkingChangeDocumentList chdoclist = ChangeDocumentList.getActiveRequestsList(connection, null);
                    chdoclist.removeChangeDocuments(selectedRequests);
                }
            }
        }
    }

}

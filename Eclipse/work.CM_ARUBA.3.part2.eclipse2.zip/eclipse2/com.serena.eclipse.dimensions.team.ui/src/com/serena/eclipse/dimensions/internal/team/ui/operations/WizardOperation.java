/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;

/**
 * An operation that invokes a team operation wizard.
 *
 * @author V.Grishchenko
 */
public abstract class WizardOperation extends RepositoryProviderOperation {
    private TeamOperationWizardHelper helper;
    private boolean canceled = false;

    public WizardOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    /**
     * Brings up a wizard and then updates the resources based on the refined
     * selection and/or operation specifics as provided by the operation helper.
     * @see com.serena.eclipse.dimensions.internal.team.ui.operations.DMOperation#prompt()
     */
    @Override
    public boolean prompt() throws InvocationTargetException, InterruptedException {
        IProgressService progressSvc = PlatformUI.getWorkbench().getProgressService();
        progressSvc.busyCursorWhile(new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    helper = createHelper(monitor);
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                }
            }
        });

        if (!helper.getStatus().isOK()) {
            ErrorDialog.openError(getShell(), getTaskName(), helper.getErrorMessage(), helper.getStatus());
            if (!helper.continueOnError()) {
                return false;
            }
        }

        if (helper.getAllRequests().size() == 0) {
            return false;
        }

        TeamOperationWizard wizard = createWizard(helper);
        WizardDialog dialog = getWizardDialog(getShell(), wizard);
        if (dialog.open() != Window.OK) {
            canceled = true;
            return false;
        }
        setResources(helper.getOperationResources()); // set the resources suitable for this operation
        return true;
    }

    @Override
    protected void execute(DMRepositoryProvider provider, IResource[] resources, IProgressMonitor monitor) throws CoreException,
            InterruptedException {
        if (canceled) {
            throw new InterruptedException();
        }
        WorkspaceResourceRequest[] requests = new WorkspaceResourceRequest[resources.length];
        for (int i = 0; i < requests.length; i++) {
            requests[i] = helper.getRequest(resources[i]);
        }
        execute(new OperationData(provider, requests), monitor);
    }

    /**
     * @return wizard dialog
     */
    protected WizardDialog getWizardDialog(Shell parentShell, TeamOperationWizard wizard) {
        return new TeamOperationWizardDialog(parentShell, wizard);
    }

    /**
     * @return this operation's helper or <code>null</code> if none
     */
    protected TeamOperationWizardHelper getHelper() {
        return helper;
    }

    /**
     * Executes this operation for the specified resource requests.
     * @param executeParam
     */
    protected abstract void execute(OperationData data, IProgressMonitor monitor) throws CoreException, InterruptedException;

    /**
     * @return operation helper
     */
    protected abstract TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException;

    /**
     * @return operation wizard
     */
    protected abstract TeamOperationWizard createWizard(TeamOperationWizardHelper wizardHelper);

}

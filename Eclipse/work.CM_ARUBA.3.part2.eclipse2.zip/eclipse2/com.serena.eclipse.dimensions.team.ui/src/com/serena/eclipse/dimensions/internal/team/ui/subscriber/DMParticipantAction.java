/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.internal.ui.synchronize.SyncInfoModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelAction;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.dto.Pair;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Base class for our participant actions.
 * @author V.Grishchenko
 */
public abstract class DMParticipantAction extends SynchronizeModelAction {

    public DMParticipantAction(String text, ISynchronizePageConfiguration configuration) {
        super(text, configuration);
    }

    public DMParticipantAction(String text, ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider) {
        super(text, configuration, selectionProvider);
    }

    @Override
    public void run() {
        if (needsToSaveDirtyEditors()) {
            if (!saveAllEditors(confirmSaveOfDirtyEditor())) {
                return;
            }
        }
        try {
            SynchronizeModelOperation operation = getSubscriberOperation(getConfiguration(), getFilteredDiffElements());

            if (operation instanceof DMWorkspaceCommitOperation) {
                DMWorkspaceCommitOperation commitOp = (DMWorkspaceCommitOperation) operation;
                if (commitOp.isStreamOperation()) {
                    operation = getStreamSubscriberOperation(commitOp);
                }
            }

            if (operation instanceof DMSynchronizeModelOperation) {
                if (!((DMSynchronizeModelOperation) operation).prompt()) {
                    return;
                }
            }

            operation.run();
        } catch (InvocationTargetException e) {
            handle(e);
        } catch (InterruptedException e) {
            handle(e);
        }
    }

    private SynchronizeModelOperation getStreamSubscriberOperation(DMWorkspaceCommitOperation commitOp) {
        Pair<IDiffElement[], Map<Project, DimensionsConnectionDetailsEx>> result = getFilteredDiffElementsForStreamOperation(commitOp);
        SynchronizeModelOperation operation = getSubscriberOperation(getConfiguration(), result.getFirst());
        ((DMWorkspaceCommitOperation) operation).setSynchronizationScope(result.getSecond());
        return operation;
    }

    @SuppressWarnings("restriction")
    protected final Pair<IDiffElement[], Map<Project, DimensionsConnectionDetailsEx>> getFilteredDiffElementsForStreamOperation(
            DMWorkspaceCommitOperation operation) {
        IDiffElement[] elements = getSelectedDiffElements();
        List<IDiffElement> filtered = new ArrayList<IDiffElement>();

        Set<IProject> projects = new HashSet<IProject>();
        for (int i = 0; i < elements.length; i++) {
            IDiffElement e = elements[i];
            if (e instanceof SyncInfoModelElement) {
                SyncInfo info = ((SyncInfoModelElement) e).getSyncInfo();
                if (info != null) {
                    if (operation.isStreamDeliverOperation()
                            && DMWorkspaceStreamDeliverAction.getSyncInfoInclusionFilter().select(info)) {
                        filtered.add(e);
                    } else if (operation.isStreamShelveOperation()
                            && DMWorkspaceStreamShelveAction.getSyncInfoInclusionFilter().select(info)) {
                        filtered.add(e);
                        IResource local = info.getLocal();
                        projects.add(local.getProject());

                    }
                }
            }
        }

        /*
         * Dimensions projects that are scope for synchronization
         */
        Map<Project, DimensionsConnectionDetailsEx> dmProjects = new HashMap<Project, DimensionsConnectionDetailsEx>();

        IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
        for (IProject project : projects) {
            try {
                IDMProject dmProject = workspace.getProject(project);
                DimensionsLcObject object = dmProject.getDimensionsObject();
                if (object instanceof Project) {
                    dmProjects.put((Project) object, dmProject.getConnection());
                }
            } catch (CoreException e) {
                DMTeamUiPlugin.log(e.getStatus());
            }
        }

        return new Pair<IDiffElement[], Map<Project, DimensionsConnectionDetailsEx>>(
                filtered.toArray(new IDiffElement[filtered.size()]), dmProjects);
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(final ISynchronizePageConfiguration configuration,
            IDiffElement[] elements) {
        return new SynchronizeModelOperation(configuration, elements) {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                UIUtils.showUnderConstruction(configuration.getSite().getShell());
            }
        };
    }

    @Override
    protected void handle(Exception e) {
        DMTeamUiPlugin.getDefault().handle(e, getConfiguration().getSite().getShell());
    }

}

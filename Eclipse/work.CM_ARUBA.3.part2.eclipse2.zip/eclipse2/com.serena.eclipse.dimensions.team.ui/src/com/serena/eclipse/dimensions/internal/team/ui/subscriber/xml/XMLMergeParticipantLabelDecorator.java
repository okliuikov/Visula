/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.viewers.ILabelDecorator;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.graphics.Image;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;

import com.serena.dmfile.StringPath;
import com.serena.dmfile.sync.XSyncUserAction;
import com.serena.dmfile.xml.ObjectAttributes;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLConflictTypeResolver;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Decorator for three way merge results that were obtained by xml mode
 */
class XMLMergeParticipantLabelDecorator extends LabelProvider implements ILabelDecorator {

    @Override
    public Image decorateImage(Image image, Object element) {
        return null;
    }

    @Override
    public String decorateText(String text, Object element) {
        if (element instanceof ISynchronizeModelElement) {
            String suffix = getSuffix((ISynchronizeModelElement) element);
            if (suffix != null) {
                return text + suffix;
            }
        }
        return null;
    }

    private String getSuffix(ISynchronizeModelElement element) {
        StringBuffer suffix = new StringBuffer(" "); //$NON-NLS-1$
        IResource resource = element.getResource();
        if (resource instanceof IProject) {
            try {
                return getProjectSuffix(element, resource);
            } catch (CoreException ce) {
                DMTeamUiPlugin.log(ce.getStatus());
            }
        }

        if (element instanceof IAdaptable) {
            XMLSyncInfo syncInfo = (XMLSyncInfo) ((IAdaptable) element).getAdapter(SyncInfo.class);
            if (syncInfo != null) {
                String resolution = getResolutionSuffix(syncInfo);
                String revision = getRevisionSuffix(syncInfo);
                String move = null;
                if (syncInfo.hasMoveInResolution()) {
                    move = getMoveSuffix(syncInfo);
                }

                suffix.append(resolution);
                if (revision != null) {
                    suffix.append(" ").append(revision); //$NON-NLS-1$
                }
                if (move != null) {
                    suffix.append(" ").append(move); //$NON-NLS-1$
                }
            }
        }

        return suffix == null ? null : suffix.toString();
    }

    private String getProjectSuffix(ISynchronizeModelElement element, IResource resource) throws CoreException {
        IDMWorkspaceResource project = DMTeamPlugin.getWorkspace().getWorkspaceResource(resource);
        if (project == null || project.getProject() == null) {
            return "";
        }
        String key = project.getProject().getIsStream() ? Messages.decorator_prjStreamInfo : (project.getProject().isBaseline()
                ? Messages.decorator_prjBaselineInfo : Messages.decorator_prjWorksetInfo);

        IDMProject theProject = project.getProject();

        StringBuffer prjText = new StringBuffer(project.getProject().getId());
        if (theProject.isSccStyle()) {
            prjText.append("/").append(theProject.getRemoteOffset().toString());//$NON-NLS-1$
        }
        String suffix = NLS.bind(key, prjText.toString(), project.getProject().getConnection().getConnName());
        return suffix;
    }

    private String getResolutionSuffix(XMLSyncInfo info) {
        StringBuffer suffix = new StringBuffer();

        XSyncUserAction label = info.getCurrentActionLabel();

        // Main label resolving
        if (info.isStale()) {
            suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_resolution_stale_pattern, new String[] {
                    Messages.DMXMLMergeParticipantLabelDecorator_resolution_stale,
                    Messages.DMXMLMergeParticipantLabelDecorator_resolution_ignore }));
        } else if (label == XSyncUserAction.SUAL_ACCEPT) {
            suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_resolution_short,
                    Messages.DMXMLMergeParticipantLabelDecorator_resolution_accept));
        } else if (label == XSyncUserAction.SUAL_IGNORE) {
            suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_resolution_short,
                    Messages.DMXMLMergeParticipantLabelDecorator_resolution_ignore));
        } else if (label == XSyncUserAction.SUAL_UNRESOLVED) {
            suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_resolution_short,
                    Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved));
        } else {
            List<String> options = new ArrayList<String>();

            if (label == XSyncUserAction.SUAL_MERGE) {
                options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_merge);
            } else if (label == XSyncUserAction.SUAL_USE_LOCAL) {
                options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_local);
            } else if (label == XSyncUserAction.SUAL_USE_REPOSITORY) {
                options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote);
            } else {
                options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved);
            }

            if (info.getResolution().isFileResolution()) {
                XSyncUserAction source = info.getCurrentActionContentSource();
                if (source == XSyncUserAction.SUAO_USE_LOCAL_FILE) {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_local_content);
                } else if (source == XSyncUserAction.SUAO_USE_REPOSITORY_FILE) {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_content);
                } else if (source == XSyncUserAction.SUAO_MERGE_2WAY || source == XSyncUserAction.SUAO_MERGE_3WAY) {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_merge_content);
                }
            }

            if (info.hasMoveInResolution()) {
                XSyncUserAction direction = info.getCurrentActionDirection();
                if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_local_path);
                } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_remote_path);
                } else {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_unresolved_path);
                }
            }

            if (info.hasConflictingItemsActions()) {
                if (XMLSyncInfo.isConflictingItemsAction(info.getCurrentAction())) {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_RepositoryItem);
                } else {
                    options.add(Messages.DMXMLMergeParticipantLabelDecorator_resolution_ConflictingItems_LocalItem);
                }
            }

            String pattern = null;
            if (options.size() == 3) {
                pattern = Messages.DMXMLMergeParticipantLabelDecorator_resolution_long_3options;
            } else if (options.size() == 2) {
                pattern = Messages.DMXMLMergeParticipantLabelDecorator_resolution_long_2options;
            } else {
                pattern = Messages.DMXMLMergeParticipantLabelDecorator_resolution_long_1option;
            }

            suffix.append(NLS.bind(pattern, options.toArray()));
        }

        return suffix.toString();
    }

    private String getRevisionSuffix(XMLSyncInfo info) {
        StringBuffer suffix = new StringBuffer();

        IResource local = info.getLocal();
        if (local != null && local.getType() == IResource.FILE) {
            String tgtRev = null;
            String srcRev = null;

            ObjectAttributes src = info.getResolution().getSrc();
            ObjectAttributes tgt = info.getResolution().getTgt();

            if (src != null && src.getSpec() != null) {
                srcRev = src.getSpec().substring(src.getSpec().indexOf(';') + 1, src.getSpec().length());
            }

            if (tgt != null && tgt.getSpec() != null) {
                tgtRev = tgt.getSpec().substring(tgt.getSpec().indexOf(';') + 1, tgt.getSpec().length());
            }

            // Revision label resolving
            if (srcRev != null && tgtRev != null) {
                XSyncUserAction source = info.getCurrentActionContentSource();
                if (source == XSyncUserAction.SUAO_USE_REPOSITORY_FILE) {
                    suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_suffix_single, srcRev));
                } else if (source == XSyncUserAction.SUAO_USE_LOCAL_FILE) {
                    suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_suffix_single, tgtRev));
                } else {
                    suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_suffix, tgtRev, srcRev));
                }
            } else if (tgtRev != null && srcRev == null) {
                suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_suffix_single, tgtRev));
            } else if (srcRev != null && tgtRev == null) {
                suffix.append(NLS.bind(Messages.DMXMLMergeParticipantLabelDecorator_suffix_single, srcRev));
            }
        }

        return suffix.toString();
    }

    private String getMoveSuffix(XMLSyncInfo info) {
        StringBuffer suffix = new StringBuffer();

        String arrow = Messages.DMXMLMergeParticipantLabelDecorator_move_unresoved; // <- default

        if (!info.isStale()) {
            if ((info.getKind() & SyncInfo.CONFLICTING) != SyncInfo.CONFLICTING
                    && info.getCurrentActionLabel() != XSyncUserAction.SUAL_IGNORE) {
                arrow = Messages.DMXMLMergeParticipantLabelDecorator_move_accept_left; // <<
            } else {
                XSyncUserAction direction = info.getCurrentActionDirection();
                int baseType = XMLConflictTypeResolver.resolveConflictType(info.getResolution());

                if (baseType == (SyncInfo.CONFLICTING | SyncInfo.ADDITION)
                        || baseType == (SyncInfo.CONFLICTING | SyncInfo.DELETION)) {
                    if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
                        arrow = Messages.DMXMLMergeParticipantLabelDecorator_move_accept_right; // >>
                    } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
                        arrow = Messages.DMXMLMergeParticipantLabelDecorator_move_accept_left; // <<
                    }
                } else if (baseType == (SyncInfo.CONFLICTING | SyncInfo.CHANGE)) {
                    if (direction == XSyncUserAction.SUAO_USE_LOCAL_PATH) {
                        arrow = Messages.DMXMLMergeParticipantLabelDecorator_move_accept_left; // <<
                    } else if (direction == XSyncUserAction.SUAO_USE_REPOSITORY_PATH) {
                        arrow = Messages.DMXMLMergeParticipantLabelDecorator_move_accept_right; // >>
                    }
                }

            }
        }

        String movedFrom = info.getResolution().getMovedFrom();
        ObjectAttributes tgt = info.getResolution().getTgt();
        if (tgt != null && !StringPath.isNullorEmpty(tgt.getInitRelPath())) {
            movedFrom = tgt.getInitRelPath();
        }

        suffix.append(arrow).append(" ") //$NON-NLS-1$
                .append(NLS.bind(
                        Messages.DMXMLMergeParticipantLabelDecorator_movedPath,
                        TeamUtils.constructRelativeResource(movedFrom, info.getResolution().isFileResolution(),
                                info.getDescriptor().getTarget())
                                .getFullPath()
                                .toString()));

        return suffix.toString();
    }

}

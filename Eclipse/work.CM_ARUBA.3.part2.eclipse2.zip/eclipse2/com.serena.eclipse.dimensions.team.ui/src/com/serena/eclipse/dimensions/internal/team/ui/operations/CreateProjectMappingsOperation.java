/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.ProjectMapping;

/**
 * @author V.Grishchenko
 */
public class CreateProjectMappingsOperation extends RemoteOperation {
    private ProjectMapping[] mappings;
    private List<ProjectMapping> inconsistentMappings;

    public CreateProjectMappingsOperation(IWorkbenchPart part, VersionManagementProject[] remoteObjects) {
        super(part, remoteObjects);
    }

    /**
     * @return Returns the mappings.
     */
    public ProjectMapping[] getMappings() {
        return mappings;
    }

    /**
     * @return mappings that have local names automatically generated
     *         or somehow adjusted from the original values metadata
     */
    public ProjectMapping[] getInconsistentMappings() {
        if (inconsistentMappings == null || inconsistentMappings.isEmpty()) {
            return new ProjectMapping[0];
        }
        return inconsistentMappings.toArray(new ProjectMapping[inconsistentMappings.size()]);
    }

    /**
     * @return Returns the mappingsOk.
     */
    public boolean hasInconsistentMappings() {
        return inconsistentMappings != null && !inconsistentMappings.isEmpty();
    }

    @Override
    protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
        final APIObjectAdapter[] remoteObjects = getRemoteObjects();
        if (remoteObjects == null || remoteObjects.length == 0) {
            return;
        }
        mappings = new ProjectMapping[remoteObjects.length];
        inconsistentMappings = new ArrayList<ProjectMapping>(2);

        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.markersSearch_msg, 10 * mappings.length);
        try {
            for (int i = 0; i < mappings.length; i++) {
                monitor.subTask((String) remoteObjects[i].getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC));
                mappings[i] = ProjectMapping.createProjectMapping((VersionManagementProject) remoteObjects[i],
                        Utils.subMonitorFor(monitor, 10, SubProgressMonitor.SUPPRESS_SUBTASK_LABEL));
                // mapping is ok if we have the IDE project name or the .project file,
                // no changes were made to the project name taken from them, and
                // the resulting name is valid
                boolean mappingOk = (mappings[i].getIdeProjectName() != null || mappings[i].getProjectDescription() != null)
                        && !mappings[i].isLocalNameAdjusted() && mappings[i].isLocalProjectNameValid();
                if (!mappingOk) {
                    inconsistentMappings.add(mappings[i]);
                }
            }
        } finally {
            monitor.done();
        }

    }

    @Override
    protected String getTaskName() {
        return Messages.markersSearch_msg;
    }
    
    @Override
    protected boolean canRunAsJob() {
        return false;
    }
}

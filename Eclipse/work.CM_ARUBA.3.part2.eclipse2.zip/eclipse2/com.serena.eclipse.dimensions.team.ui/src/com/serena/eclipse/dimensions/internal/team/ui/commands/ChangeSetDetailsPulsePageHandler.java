package com.serena.eclipse.dimensions.internal.team.ui.commands;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.handlers.HandlerUtil;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;
import com.serena.eclipse.dimensions.ui.actions.ShowChangesetPulsePageFromChangesetViewAction;

public class ChangeSetDetailsPulsePageHandler extends AbstractHandler {
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		IWorkbenchSite site = HandlerUtil.getActiveSite(event);
		ChangeSetHistoryView view = (ChangeSetHistoryView) site.getPage().findView(ChangeSetHistoryView.ID);
		DimensionsConnectionDetailsEx connection = view.getConnection();
		ShowChangesetPulsePageFromChangesetViewAction action = new ShowChangesetPulsePageFromChangesetViewAction(event,
				connection);
		action.run(null);
		return null;
	}
}

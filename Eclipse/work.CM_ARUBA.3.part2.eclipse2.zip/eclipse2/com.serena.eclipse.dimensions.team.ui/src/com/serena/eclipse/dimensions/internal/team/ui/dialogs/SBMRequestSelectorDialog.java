/*
 * Created on July 25, 2018
 */
package com.serena.eclipse.dimensions.internal.team.ui.dialogs;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import com.serena.eclipse.dimensions.core.sbm.ISBMRequest;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.SBMCheckedTablePanel;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author okliuikov
 *
 */
public class SBMRequestSelectorDialog extends Dialog {

    private SBMCheckedTablePanel tablePanel;
    private CheckboxTableViewer tableViewer;
    private ISBMRequest[] requests;
    private List checkedRequests;

    public SBMRequestSelectorDialog(Shell parentShell, ISBMRequest[] requests) {
        super(parentShell);
        this.requests = requests;
    }
    
    public List<String> getSelectedRequestIds() {
        List<String> selectedIds = new ArrayList<String>();
        
        if (checkedRequests != null && checkedRequests.size() > 0) {
            for (Object element: checkedRequests) {
                if (element instanceof ISBMRequest) {
                    selectedIds.add(((ISBMRequest) element).getID());
                }
            }
        }
        return selectedIds;
    }
    
    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite) super.createDialogArea(parent);
        
        GridLayout gl = UIUtils.setGridLayout(composite, 1);
        gl.marginHeight = gl.marginWidth = 0;

        // table
        tablePanel = new SBMCheckedTablePanel(composite);
        tableViewer = tablePanel.getCheckboxTableViewer();
        tableViewer.addCheckStateListener(new ICheckStateListener() {
            @Override
            public void checkStateChanged(CheckStateChangedEvent event) {
                checkedRequests  = Arrays.asList(tableViewer.getCheckedElements());
            }
        });
        UIUtils.setGridData(tablePanel.getPanel(), GridData.FILL_BOTH);

        tablePanel.setDataModel(requests, DMTeamUiPlugin.getDefault().getDialogSettings());
        return composite;
    }
    
    @Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        newShell.setText("Select Requests"); //$NON-NLS-1$
    }
    
    @Override
    protected boolean isResizable() {
        return true;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.jface.action.IAction;

import com.serena.eclipse.dimensions.internal.team.ui.operations.DMOperation;

/**
 * @author V.Grishchenko
 */
public abstract class OperationAction extends DMTeamAction {

    public OperationAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        final DMOperation operation = getOperation();
        if (operation == null) {
            return;
        }
        if (!operation.prompt()) {
            throw new InterruptedException();
        }
        operation.run();
    }

    /**
     * @return operation to run or <code>null</code> if action shouldn't
     *         execute
     */
    protected abstract DMOperation getOperation();

}

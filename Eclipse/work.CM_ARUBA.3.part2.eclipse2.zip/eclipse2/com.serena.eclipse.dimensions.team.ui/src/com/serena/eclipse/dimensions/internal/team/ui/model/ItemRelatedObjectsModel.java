/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2008 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.api.IDMRequest;
import com.serena.dmclient.api.IDMRequestIdentifier;
import com.serena.dmclient.api.IDMRequestV2;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemRelationship;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.dmclient.objects.RequestRelationshipType;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.model.IRelatedObjectsModel;
import com.serena.eclipse.dimensions.internal.ui.model.IdmWorkingListHolder;
import com.serena.eclipse.dimensions.internal.ui.model.RelatedObjectsModel;

/**
 * @author V.Grishchenko
 */
public class ItemRelatedObjectsModel extends RelatedObjectsModel implements IRelatedObjectsModel {

    public ItemRelatedObjectsModel(ItemRevisionAdapter object) {
        super(object);
    }

    @Override
    protected void loadChildChdocs(Session session, DimensionsArObject object, IProgressMonitor monitor) throws DMException {
        if (session.getConnectionDetails().getSBMConnection() == null) {
            super.loadChildChdocs(session, object, monitor);
        } else {
            childChdocs = new ArrayList();
            monitor.done();
        }
    }

    @Override
    protected void loadParentChdocs(Session session, DimensionsArObject object, IProgressMonitor monitor) throws DMException {
        if (!session.getConnectionDetails().isIdmRequestProvider()) {
            super.loadParentChdocs(session, object, monitor);
        } else {
            if (!(object instanceof ItemRevision)) {
                super.loadChildChdocs(session, object, monitor);
            }
            ItemRevision item_rev = (ItemRevision) object;
            monitor = Utils.monitorFor(monitor);
            monitor.beginTask(null, IProgressMonitor.UNKNOWN);
            try {
                parentChdocs = new ArrayList();
                Map<String, String> titles = new HashMap<String, String>();
                List<IDMRequest> chdocs = new ArrayList<IDMRequest>();
                List relatedObjects = item_rev.getParentIDMRequests();
                List<IDMRequestIdentifier> identifiers = new ArrayList<IDMRequestIdentifier>();
                IDMHelper helper = session.getObjectFactory().getIDMHelper();
                RequestProvider provider = session.getObjectFactory().getRequestProvider(null);
                for (int i = 0; i < relatedObjects.size(); i++) {
                    DimensionsRelatedObject relObject = (DimensionsRelatedObject) relatedObjects.get(i);
                    IDMRequest childChdoc = (IDMRequest) relObject.getObject();
                    chdocs.add(childChdoc);
                    identifiers.add(new IDMRequestIdentifier(provider.getUID(), childChdoc.getID()));
                }

                for (IDMRequestV2 request : helper.getIDMRequests(identifiers)) {
                    titles.put(request.getName(), request.getTitle());
                }
                
                for (int i = 0; i < relatedObjects.size(); i++) {
                    DimensionsRelatedObject relObject = (DimensionsRelatedObject) relatedObjects.get(i);
                    IDMRequest parentChdoc = (IDMRequest) chdocs.get(i);
                    DimensionsObject relation = relObject.getRelationship();
                    String relName = getRelName(relation);
                    String item[] = new String[7];
                    item[0] = parentChdoc.getName();
                    String title = titles.get(parentChdoc.getName()); 
                    item[1] = title != null ? title : "";
                    item[2] = relName;
                    item[3] = UNCHANGED;
                    item[4] = relName;
                    item[5] = Messages.relateView_parent;
                    item[6] = Utils.EMPTY_STRING;
                    parentChdocs.add(item);
                    if (allRelatedChangeDocuments.get(parentChdoc.getName()) == null) {
                        allRelatedChangeDocuments.put(parentChdoc.getName(), parentChdoc);
                    }
                }
            } 
            catch (Exception ex) {
                String msg = ex.getMessage();
                throw new DMException(msg, ex);
            } finally {
                monitor.done();
            }
        }
    }

    @Override
    protected void saveChildChdocs(Session session, DimensionsLcObject object) throws DMException {
        if (session.getConnectionDetails().getSBMConnection() == null) {
            super.saveChildChdocs(session, object);
        }
    }

    @Override
    protected void saveParentChdocs(Session session, DimensionsLcObject object) throws DMException {
        if (!session.getConnectionDetails().isIdmRequestProvider()) { 
            super.saveParentChdocs(session, object);
        } else {
            int indicesToRemove[] = new int[parentChdocs.size()];
            int remove = 0;
            IdmWorkingListHolder workingListHolder = null;
            for (int i = 0; i < parentChdocs.size(); i++) {
                String[] info = (String[]) parentChdocs.get(i);
                if (info[3] == UNCHANGED) {
                    continue;
                }
                IDMRequest parentChdoc = null;
                Object obj = allRelatedChangeDocuments.get(info[0]);
                if (obj instanceof IDMRequest) {
                    parentChdoc = (IDMRequest) obj;
                }
                if (parentChdoc == null) {
                    if (workingListHolder == null) {
                        workingListHolder = new IdmWorkingListHolder(session.getConnectionDetails());
                    }
                    parentChdoc = workingListHolder.findRequest(info[0]);
                    if (parentChdoc == null) {
                        List<IDMRequest> requests = session.getObjectFactory().findIDMRequestsByName(Arrays.asList(info[0].trim().toUpperCase()));
                        if (requests != null && requests.size() > 0) {
                            parentChdoc = requests.get(0);
                            allRelatedChangeDocuments.put(parentChdoc.getName(), parentChdoc);
                        }
                    }
                }
                if (objectType == IDMConstants.CHANGEDOCUMENT) {
                    RequestRelationshipType relType = null;
                    if (info[2].equals(Messages.relateView_dependent)) {
                        relType = SystemRelationship.REQUEST_DEPENDENT;
                    } else if (info[2].equals(Messages.relateView_info)) {
                        relType = SystemRelationship.REQUEST_INFO;
                    } else {
                        relType = infoTypes.get(info[2]);
                        if (relType == null) {
                            relType = depTypes.get(info[2]);
                        }
                    }

                    if (info[3] == ADDED) {
                        object.addParent(relType, parentChdoc);
                        if (info[1] == null) {
                            if (parentChdoc != null && parentChdoc.getTitle() != null) {
                                info[1] = parentChdoc.getTitle();
                            }
                            else {
                                info[1] = "";
                            }
                        }
                        info[3] = UNCHANGED;
                    }
                    if (info[3] == REMOVED) {
                        object.removeParent(relType, parentChdoc);
                        indicesToRemove[remove] = i;
                        remove++;
                    }
                    if (info[3] == CHANGED) {
                        RequestRelationshipType oldRelType = null;
                        if (info[4].equals(Messages.relateView_dependent)) {
                            oldRelType = SystemRelationship.REQUEST_DEPENDENT;
                        } else if (info[4].equals(Messages.relateView_info)) {
                            oldRelType = SystemRelationship.REQUEST_INFO;
                        } else {
                            oldRelType = infoTypes.get(info[4]);
                            if (oldRelType == null) {
                                oldRelType = depTypes.get(info[4]);
                            }
                        }
                        if (info[5].equals(Messages.relateView_child)) {
                            // the chdoc was a child beforehand, so use changeChildRelationship and
                            // reverse the direction
                            object.changeChildRelationship(oldRelType, relType, parentChdoc, true);
                        } else {
                            // the direction hasn't changed, so only change the relationship itself
                            object.changeParentRelationship(oldRelType, relType, parentChdoc, false);
                        }
                        info[4] = info[2];
                        info[3] = UNCHANGED;
                    }
                } else {
                    SystemRelationship relType = getRelationshipObject(info[2]);
                    if (info[3] == ADDED) {
                        object.addParent(relType, parentChdoc);
                        
                        if (info[1] == null) {
                            if (parentChdoc != null && parentChdoc.getTitle() != null) {
                                info[1] = parentChdoc.getTitle();
                            } else {
                                info[1] = "";
                            }
                        }
                        info[3] = UNCHANGED;
                        info[4] = info[2];
                    }
                    if (info[3] == REMOVED) {
                        if (info[4] != "") {
                            relType = getRelationshipObject(info[4]);
                        }
                        object.removeParent(relType, parentChdoc);
                        indicesToRemove[remove] = i;
                        remove++;
                    }
                    if (info[3] == CHANGED) {
                        SystemRelationship oldRelType;
                        if (Messages.relateView_inResponse.equals(info[4])) {
                            oldRelType = SystemRelationship.IN_RESPONSE;
                        } else {
                            oldRelType = getRelationshipObject(info[4]);
                        }
                        object.removeParent(oldRelType, parentChdoc);
                        object.addParent(relType, parentChdoc);
                        info[4] = info[2];
                        info[3] = UNCHANGED;
                    }
                }
            }
            for (int i = remove - 1; i >= 0; i--) {
                parentChdocs.remove(indicesToRemove[i]);
            }
        }
    }

    @Override
    protected String getChangeDocDescription(String id) {
        if (!getConnection().isIdmRequestProvider()) {
            return super.getChangeDocDescription(id);
        } else {
            try {
                String title = null;
                final Session session = getConnection().openSession(null);
                IDMHelper helper = session.getObjectFactory().getIDMHelper();
                RequestProvider provider = session.getObjectFactory().getRequestProvider(null);

                List<IDMRequestIdentifier> identifiers = new ArrayList<IDMRequestIdentifier>();
                identifiers.add(new IDMRequestIdentifier(provider.getUID(), id));
                List<IDMRequestV2> requests = helper.getIDMRequests(identifiers);
                if (requests != null && requests.size() > 0) {
                    title = requests.get(0).getTitle();
                }
                return title != null ? title : "";
            } catch (Exception ex) {
                return "";
            }
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.core.synchronize.SyncInfoSet;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.DMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;

/**
 * Filters that are used by synchronize model operations
 */
class DMSyncModelFilters {

    static class CrossProjectFilterResult {
        private SyncInfoSet crossProjectInfos = new SyncInfoSet();

        public SyncInfoSet getCrossProjectInfos() {
            return crossProjectInfos;
        }

        public void addCrossProjectInfos(CrossProjectFilterResult toAdd) {
            if (toAdd != null && toAdd.getCrossProjectInfos() != null) {
                crossProjectInfos.addAll(toAdd.getCrossProjectInfos());
            }
        }
    }

    /**
     * Collect all cross project moves
     */
    static class CrossProjectFilter extends FastSyncInfoFilter {
        private CrossProjectFilterResult filterResult = new CrossProjectFilterResult();
        private Set<IResource> crossProjectUpdateFiles = new HashSet<IResource>();

        CrossProjectFilterResult getFilterResult() {
            return filterResult;
        }

        @Override
        public boolean select(SyncInfo info) {
            boolean result = false;
            int kind = info.getKind();

            DMWorkspace workspace = (DMWorkspace) DMTeamPlugin.getWorkspace();
            IResource local = info.getLocal();
            IResource moveSrc = null;
            IResource moveDst = null;
            IDMProject srcPrj = null;
            IDMProject dstPrj = null;

            try {
                if (kind == (SyncInfo.OUTGOING | SyncInfo.ADDITION)) {
                    if ((moveSrc = workspace.getMovedFrom(local)) != null) {
                        moveDst = workspace.getMovedTo(moveSrc);
                        srcPrj = workspace.getProject(moveSrc);
                        dstPrj = workspace.getProject(moveDst);
                        if (!srcPrj.remoteEquals(dstPrj, true)) {
                            getFilterResult().getCrossProjectInfos().add(info);
                            return true;
                        }
                    }
                } else if (kind == (SyncInfo.INCOMING | SyncInfo.ADDITION)) {
                    if ((moveSrc = workspace.getMovedInRepositoryFrom(local)) != null) {
                        moveDst = workspace.getMovedInRepositoryTo(moveSrc);
                        srcPrj = workspace.getProject(moveSrc);
                        dstPrj = workspace.getProject(moveDst);
                        if (!srcPrj.remoteEquals(dstPrj, true)) {
                            // always true because this is move and we interesting only in one side, no matter which
                            if (!crossProjectUpdateFiles.contains(moveSrc)) {
                                crossProjectUpdateFiles.add(moveSrc);
                                getFilterResult().getCrossProjectInfos().add(info);
                            }
                            return true;
                        }
                    }
                } else if (kind == (SyncInfo.INCOMING | SyncInfo.DELETION)) {
                    if ((moveDst = workspace.getMovedInRepositoryTo(local)) != null) {
                        moveSrc = workspace.getMovedInRepositoryFrom(moveDst);
                        srcPrj = workspace.getProject(moveSrc);
                        dstPrj = workspace.getProject(moveDst);
                        if (!srcPrj.remoteEquals(dstPrj, true)) {
                            // always true because this is move and we interesting only in one side, no matter which
                            if (!crossProjectUpdateFiles.contains(moveSrc)) {
                                crossProjectUpdateFiles.add(moveSrc);
                                getFilterResult().getCrossProjectInfos().add(info);
                            }
                            return true;
                        }
                    }
                }
            } catch (CoreException e) {
                DMTeamPlugin.log(e.getStatus());
            }
            return result;
        }

        boolean isEmpty() {
            return filterResult.getCrossProjectInfos().isEmpty();
        }

    }

    /**
     * Collect new folders that overlaps cross project moves
     */
    static class OverlappingCrossProjectFilter extends FastSyncInfoFilter {
        private CrossProjectFilterResult crossFilterResultIn;
        private CrossProjectFilterResult crossFilterResultOut;

        OverlappingCrossProjectFilter(CrossProjectFilter crossFilter) {
            this.crossFilterResultIn = crossFilter.getFilterResult();
            this.crossFilterResultOut = new CrossProjectFilterResult();
        }

        CrossProjectFilterResult getFilterResult() {
            crossFilterResultOut.addCrossProjectInfos(crossFilterResultIn);
            return crossFilterResultOut;
        }

        @Override
        public boolean select(SyncInfo info) {
            int filter = SyncInfo.OUTGOING | SyncInfo.ADDITION;
            if (info.getKind() != filter) {
                return false;
            }

            IResource local = info.getLocal();
            if (local instanceof IContainer) {
                IPath localPath = local.getFullPath();
                SyncInfoSet crossProjectInfoSet = crossFilterResultIn.getCrossProjectInfos();
                SyncInfo[] crossInfos = crossProjectInfoSet.getSyncInfos();

                for (int i = 0; i < crossInfos.length; i++) {
                    SyncInfo crossInfo = crossInfos[i];
                    IResource crossMoved = crossInfo.getLocal();
                    IPath crossMovedPath = crossMoved.getFullPath();
                    if (localPath.isPrefixOf(crossMovedPath)) {
                        crossFilterResultOut.getCrossProjectInfos().add(info);
                        return true;
                    }
                }
            }
            return false;
        }
    }

}

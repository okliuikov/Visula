/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2019 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.FileRequest;
import com.serena.eclipse.dimensions.internal.team.core.ItemRequest;
import com.serena.eclipse.dimensions.internal.team.core.ShelfDetails;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.Option;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.forms.FormWizard;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

import merant.adm.dimensions.util.StringUtils;

/**
 * <p>
 * Wizard that shows resource selection and comment page, change doc association page and attribute page.
 * <p>
 * Note that all attribute values will be committed to attribute models but the models themselves will not be saved by this wizard.
 * 
 * @author V.Grishchenko
 */
public abstract class TeamOperationWizard extends FormWizard implements IPropertyChangeListener {

    private static final String MAIN_PAGE = "main_page"; //$NON-NLS-1$
    private static final String REQUEST_PAGE = "request_page"; //$NON-NLS-1$
    private static final String ATTRIBUTE_PAGE = "attr_page"; //$NON-NLS-1$
    protected static final String NEW_STREAM_PAGE = "new_stream_page"; //$NON-NLS-1$

    private TeamOperationWizardHelper helper;

    private TeamOperationWizardMainPage mainPage;
    private TeamOperationWizardRequestPage requestPage;
    private TeamOperationWizardAttributesPage attributesPage;

    private NewStreamGeneralPage newStreamPage;

    public TeamOperationWizard(TeamOperationWizardHelper helper, boolean needsProgress) {
        this.helper = helper;
        this.helper.addPropertyChangeListener(this);
        setNeedsProgressMonitor(needsProgress);
    }

    /**
     * @return Returns the helper.
     */
    public TeamOperationWizardHelper getHelper() {
        return helper;
    }

    /**
     * @return Returns the connection.
     */
    public DimensionsConnectionDetailsEx getConnection() {
        return helper.getConnection();
    }

    @Override
    public void addPages() {
        newStreamPage = createNewStreamPage(NEW_STREAM_PAGE);
        if (newStreamPage != null) {
            addPage(newStreamPage);
        }

        mainPage = createMainPage(MAIN_PAGE);
        if (mainPage != null) {
            addPage(mainPage);
        }
        requestPage = createRequestPage(REQUEST_PAGE);
        if (requestPage != null) {
            updateRequestsPage();
            addPage(requestPage);
        }
        attributesPage = createAttributesPage(ATTRIBUTE_PAGE);
        if (attributesPage != null) {
            updateAttributesPage();
            addPage(attributesPage);
        }
    }

    @Override
    public boolean performFinish() {
        super.performFinish(); // commit all form wizard pages
        try {
            if (newStreamPage != null) {
                String productName = newStreamPage.getProductName();
                String streamName = newStreamPage.getStreamName();
                String description = newStreamPage.getStreamDescription();
                ShelfDetails details = new ShelfDetails(productName, streamName, description, IDMConstants.PERSONAL_TYPE_NAME, true);
                details.setDefaultBranch(newStreamPage.getStreamUniqueBranchName());
                details.setFavourite(newStreamPage.isAdd2FavoriteList());
                details.setReset(newStreamPage.isResetAfterShelve());
                helper.setShelfDetails(details);
            }
            if (mainPage != null) {
                helper.setComment(mainPage.getComment());
                mainPage.saveSettings();
            }
            if (requestPage != null) {
                requestPage.saveSettings();
            }
            helper.commit(); // notify helper
            if (requestPage != null) {
                requestPage.postCommit(helper);
            }
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e);
            return false;
        }
        return true;
    }
    
    public String getTargetProductName() {

        if (newStreamPage != null) {
            return newStreamPage.getProductName();
        }
        String productName = "";
        for (WorkspaceResourceRequest request : helper.getAllRequests()) {
            try {
                productName = DMTeamPlugin.getWorkspace().getProject(request.getResource()).getProduct();
                if (!StringUtils.isBlank(productName)) {
                    break;
                }
            } catch (CoreException e) {
                DMUIPlugin.log(new Status(IStatus.ERROR, DMUIPlugin.ID, 0,
                        "Problem getting product id from workspace resource request", e)); //$NON-NLS-1$
            }
        }
        return productName;
    }

    /**
     * @return <code>true</code> if this wizard must show the requests page
     *         if available
     */
    protected boolean requiresRequests() {
        return false;
    }

    /**
     * @return <code>true</code> if this wizard must show the attributes page
     *         if available
     */
    protected boolean requiresAttributes() {
        return false;
    }

    @Override
    public void dispose() {
        super.dispose();
        helper.removePropertyChangeListener(this);
    }

    @Override
    public void propertyChange(PropertyChangeEvent event) {
        if (TeamOperationWizardHelper.SELECTED_RESOURCES.equals(event.getProperty())) {
            updateMainPage();
            updateRequestsPage();
            updateAttributesPage();
            getContainer().updateButtons();
        } else if (TeamOperationWizardHelper.OPTIONS.equals(event.getProperty())) {
            if (requestPage != null) {
                requestPage.validate();
                getContainer().updateButtons();
            }
        }
    }

    protected void updateMainPage() {
        if (mainPage != null) {
            mainPage.setDescription(getMainPageDescription());
        }
    }

    protected void updateRequestsPage() {
        if (requestPage != null) {
            IResource[] selectedResources = helper.getOperationResources();
            WorkspaceResourceRequest[] requests = new WorkspaceResourceRequest[selectedResources.length];
            for (int i = 0; i < requests.length; i++) {
                requests[i] = helper.getRequest(selectedResources[i]);
            }
            requestPage.setResources(requests);
        }
    }

    protected void updateAttributesPage() {
        if (attributesPage != null) {
            IFile[] selectedFiles = helper.getOperationFiles();
            ArrayList<ItemInfo> itemInfos = new ArrayList<ItemInfo>();
            for (int i = 0; i < selectedFiles.length; i++) {
                FileRequest fileRequest = helper.getFileRequest(selectedFiles[i]);
                if (fileRequest instanceof ItemRequest) {
                    IAttributeModel attributeModel = helper.getAttributeModel(selectedFiles[i]);
                    if (attributeModel != null) {
                        itemInfos.add(new ItemInfo((ItemRequest) fileRequest, attributeModel));
                    }
                }
            }
            attributesPage.setFiles(itemInfos.toArray(new ItemInfo[itemInfos.size()]));
        }
    }

    protected TeamOperationWizardMainPage createMainPage(String name) {
        TeamOperationWizardMainPage page = new TeamOperationWizardMainPage(name, getMainPageTitle(), getMainPageDescription(),
                getMainPageImage(), getMainPageOptions());
        page.setHelper(helper);
        page.setOperationOptions(getOperationOptions());
        return page;
    }

    protected NewStreamGeneralPage createNewStreamPage(String newStreamPageId) {
        return null;
    }

    protected String getMainPageTitle() {
        return Messages.TeamOperationWizard_1;
    }

    protected String getMainPageDescription() {
        return Messages.TeamOperationWizard_2;
    }

    protected ImageDescriptor getMainPageImage() {
        return DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN);
    }

    protected int getMainPageOptions() {
        return TeamOperationWizardMainPage.SHOW_ALL;
    }

    protected Option[] getOperationOptions() {
        return helper.getOptions();
    }

    protected TeamOperationWizardRequestPage createRequestPage(String name) {
        if (needRequestPage()) {
            if (helper.getConnection().isIdmRequestProvider()) {
                return new IdmRequestPage(name, getRequestPageTitle(), getRequestPageDescription(),
                        getRequestPageImage());
            }
            return new DimensionsRequestPage(name, getRequestPageTitle(), getRequestPageDescription(),
                    getRequestPageImage());
        }
        return null;
    }

    protected boolean needRequestPage() {
        return helper.isRequestsSupported();
    }

    protected String getRequestPageTitle() {
        return Messages.TeamOperationWizard_3;
    }

    protected String getRequestPageDescription() {
        return Messages.TeamOperationWizard_4;
    }

    protected ImageDescriptor getRequestPageImage() {
        return DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN);
    }

    protected TeamOperationWizardAttributesPage createAttributesPage(String name) {
        TeamOperationWizardAttributesPage page = new TeamOperationWizardAttributesPage(name, getAttributePageTitle(),
                getAttributePageDescription(), getAttributePageImage());
        return page;
    }

    protected String getAttributePageTitle() {
        return Messages.TeamOperationWizard_5;
    }

    protected String getAttributePageDescription() {
        return Messages.TeamOperationWizard_6;
    }

    protected ImageDescriptor getAttributePageImage() {
        return DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN);
    }

}

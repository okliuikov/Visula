/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.action.IAction;

import com.serena.eclipse.dimensions.internal.team.ui.operations.RefreshStatusOperation;

/**
 * Refreshes version control status for selected resources.
 *
 * @author V.Grishchenko
 */
public class RefreshStatusAction extends DMWorkspaceAction {

    public RefreshStatusAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources = getSelectedResources();
        if (resources == null || resources.length == 0) {
            return;
        }
        RefreshStatusOperation operation = new RefreshStatusOperation(getActivePart(), getNonOverlapping(resources));
        operation.run();
    }

    @Override
    protected boolean isAlwaysEnabled() {
        return true;
    }

}

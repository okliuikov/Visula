/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.compare.structuremergeviewer.IDiffElement;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter.SyncInfoDirectionFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.SynchronizeModelOperation;

import com.serena.eclipse.dimensions.internal.team.core.xml.MergeCommandLocalScope;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class DMWorkspaceStreamUpdateWizardAction extends DMParticipantAction {

    private static final String MYCOMMITTEXT = Messages.DMWorkspaceStreamUpdateAction_0;

    public DMWorkspaceStreamUpdateWizardAction(ISynchronizePageConfiguration configuration, ISelectionProvider selectionProvider) {
        super(MYCOMMITTEXT, configuration, selectionProvider);
    }

    @Override
    public ImageDescriptor getImageDescriptor() {
        return DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.STREAMUPDATE_ACTION);
    }

    // @formatter:off
    private static final FastSyncInfoFilter INCLUSION_FILTER = new FastSyncInfoFilter.AndSyncInfoFilter(
            new FastSyncInfoFilter[] {
                    OnlineFilter.INSTANCE,
                    ProjectTypeFilter.BASELINE_FILTER,
                    new SyncInfoDirectionFilter(new int[] {
                            SyncInfo.INCOMING,
                            SyncInfo.CONFLICTING
                            })
                    });// @formatter:on

    @Override
    protected FastSyncInfoFilter getSyncInfoFilter() {
        return INCLUSION_FILTER;
    }

    @Override
    protected boolean updateSelection(IStructuredSelection selection) {
        boolean updated = super.updateSelection(selection);
        if (updated) {
            IDiffElement[] resources = getSelectedDiffElements();
            Set<IResource> projects = new HashSet<IResource>();

            for (int i = 0; i < resources.length; i++) {
                if (resources[i] instanceof ISynchronizeModelElement) {
                    ISynchronizeModelElement ell = (ISynchronizeModelElement) resources[i];
                    if (ell.getResource() != null) {
                        projects.add(ell.getResource().getProject());
                    }
                }
            }

            try {
                return MergeCommandLocalScope.getScopes(projects.toArray(new IResource[projects.size()]), true) != null;
            } catch (CoreException e) {
                return false;
            }
        }
        return false;
    }

    @Override
    protected SynchronizeModelOperation getSubscriberOperation(ISynchronizePageConfiguration configuration, IDiffElement[] elements) {
        return new DMWorkspaceOpenUpdateWizardOperation(configuration, elements);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.MergeWizard;

/**
 * Launches merge wizard.
 *
 * @author V.Grishchenko
 */
public class MergeAction extends DMWorkspaceAction {

    public MergeAction() {
    }

    @Override
    protected boolean isEnabledForSelection() {
        if (isSelectedSccProjectsMoved()) {
            return false;
        } else {
            return super.isEnabledForSelection();
        }
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources;
        try {
            resources = getResources();
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        if (resources.length == 0) {
            return;
        }

        HashMap<IProject, ArrayList<IResource>> resourcesByProject = new HashMap<IProject, ArrayList<IResource>>();
        for (int i = 0; i < resources.length; i++) {
            IProject project = resources[i].getProject();
            ArrayList<IResource> projectResources = resourcesByProject.get(project);
            if (projectResources == null) {
                projectResources = new ArrayList<IResource>();
                resourcesByProject.put(project, projectResources);
            }
            projectResources.add(resources[i]);
        }

        try {
            for (Iterator<Entry<IProject, ArrayList<IResource>>> iter = resourcesByProject.entrySet().iterator(); iter
                    .hasNext();) {
                Entry<IProject, ArrayList<IResource>> entry = iter.next();
                IProject project = entry.getKey();
                ArrayList<IResource> resourceList = entry.getValue();
                IResource[] prjResArray = resourceList.toArray(new IResource[resourceList.size()]);
                IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(project);
                assert dmProject != null;
                VersionManagementProject currentSharing = dmProject.getDimensionsObjectAdapter();
                MergeWizard wizard = new MergeWizard(currentSharing, project, prjResArray, resourcesByProject.size() > 1);
                wizard.setDefaultOffset(dmProject.getRemoteOffset());
                WizardDialog dialog = new WizardDialog(getShell(), wizard);
                if (dialog.open() == Window.CANCEL) {
                    return; // abort all
                }
            }
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return false;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.dialogs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;

/**
 * A confirmation dialog helper that will either show a 'yes/no/yes to all/cancel'
 * dialog to confirm an action performed on several resources or if only one
 * resource is specified 'yes/no' will be shown.
 */
public class PromptingDialog {
    private IResource[] resources;
    private Shell shell;
    private String[] buttons;
    private boolean confirmOverwrite = true;
    private IPromptCondition condition;
    private String title;
    private boolean hasMultipleResources;
    private boolean allOrNothing;

    /**
     * Prompt for the given resources using the specific condition. The prompt dialog will
     * have the title specified.
     * @param overrideDefaultMultipleResourcesCondition - Treat as having only one resource even though there are more than one.
     * @param minimumResourceCountForMultiplicity - Count of resources upto which it is treated as having only one resource.
     *            ( The parameters
     *            " @param overrideDefaultMultipleResourcesCondition and @param minimumResourceCountForMultiplicity" are introduced
     *            for the following case : User1 modifies a file locally, but the same file is moved in repository by another user.
     *            User1 does a sync. Repository move will be shown as an incoming addition and a conflicting change. If the user
     *            selects the conflicting change
     *            node only and does an "Override and Update" then we need to make sure that the incoming addition node too is
     *            included in the "Override and Update"
     *            operation. So, though the user has selected only one node , there are two nodes being processed and we need to
     *            tell the PromptingDialog.java
     *            to treat this scenario as having only one node when displaying the dialog though there are two nodes )
     */
    public PromptingDialog(Shell shell, IResource[] resources, IPromptCondition condition, String title,
            boolean overrideDefaultMultipleResourcesCondition, int minimumResourceCountForMultiplicity) {
        this(shell, resources, condition, title, false /* all or nothing */, overrideDefaultMultipleResourcesCondition,
                minimumResourceCountForMultiplicity);
    }

    public PromptingDialog(Shell shell, IResource[] resources, IPromptCondition condition, String title, boolean allOrNothing,
            boolean overrideDefaultMultipleResourcesCondition, int minimumResourceCountForMultiplicity) {
        this.condition = condition;
        this.resources = resources;
        this.title = title;
        this.shell = shell;
        if (overrideDefaultMultipleResourcesCondition) {
            this.hasMultipleResources = resources.length > minimumResourceCountForMultiplicity;
        } else {
            this.hasMultipleResources = resources.length > 1;
        }

        this.allOrNothing = allOrNothing;
        if (hasMultipleResources) {
            if (allOrNothing) {
                buttons = new String[] { IDialogConstants.YES_LABEL, IDialogConstants.YES_TO_ALL_LABEL,
                        IDialogConstants.CANCEL_LABEL };
            } else {
                buttons = new String[] { IDialogConstants.YES_LABEL, IDialogConstants.YES_TO_ALL_LABEL, IDialogConstants.NO_LABEL,
                        IDialogConstants.CANCEL_LABEL };
            }
        } else {
            buttons = new String[] { IDialogConstants.YES_LABEL, IDialogConstants.NO_LABEL };
        }
    }

    /**
     * Call to calculate and show prompt. If no resources satisfy the prompt condition
     * a dialog won't be shown. The resources for which the user confirmed the action
     * are returned.
     */
    public IResource[] promptForMultiple() throws InterruptedException {
        List targetResources = new ArrayList();
        for (int i = 0; i < resources.length; i++) {
            IResource resource = resources[i];
            if (condition.needsPrompt(resource) && confirmOverwrite) {
                if (prompt(condition.promptMessage(resource))) {
                    targetResources.add(resource);
                    try {
                        DMTeamPlugin.getDefault();
                        if (DMTeamPlugin.getWorkspace().getMovedFrom(resource) != null) {
                            targetResources.add(DMTeamPlugin.getDefault().getWorkspace().getMovedFrom(resource));
                        }
                        DMTeamPlugin.getDefault();
                        if (DMTeamPlugin.getWorkspace().getMovedTo(resource) != null) {
                            targetResources.add(DMTeamPlugin.getDefault().getWorkspace().getMovedTo(resource));
                        }
                    } catch (CoreException e) {
                    }
                }
            } else {
                targetResources.add(resource);
            }
        }
        return (IResource[]) targetResources.toArray(new IResource[targetResources.size()]);
    }

    /**
     *
     * @param deSelectedList
     * @return
     * @throws InterruptedException
     */
    public IResource[] promptForMultiple(HashSet deSelectedList) throws InterruptedException {
        List targetResources = new ArrayList();
        for (int i = 0; i < resources.length; i++) {
            IResource resource = resources[i];
            if (condition.needsPrompt(resource) && confirmOverwrite) {
                if (prompt(condition.promptMessage(resource))) {
                    targetResources.add(resource);
                } else {
                    deSelectedList.add(resource);
                }
            } else {
                targetResources.add(resource);
            }
        }
        return (IResource[]) targetResources.toArray(new IResource[targetResources.size()]);
    }

    /**
     * Opens the confirmation dialog based on the prompt condition settings.
     */
    private boolean prompt(String msg) throws InterruptedException {
        if (!confirmOverwrite) {
            return true;
        }
        final MessageDialog dialog = new MessageDialog(shell, title, null, msg, MessageDialog.QUESTION, buttons, 0);

        // run in syncExec because callback is from an operation,
        // which is probably not running in the UI thread.
        shell.getDisplay().syncExec(new Runnable() {
            @Override
            public void run() {
                dialog.open();
            }
        });
        if (hasMultipleResources) {
            switch (dialog.getReturnCode()) {
            case 0:// Yes
                return true;
            case 1:// Yes to all
                confirmOverwrite = false;
                return true;
            case 2:// No (or CANCEL for all-or-nothing)
                if (allOrNothing) {
                    throw new InterruptedException();
                }
                return false;
            case 3:// Cancel
            default:
                throw new InterruptedException();
            }
        }

        return dialog.getReturnCode() == 0;
    }
}

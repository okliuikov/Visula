package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.StatusFilter;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceStatus;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class ChangeSetHistoryAction extends DMWorkspaceAction {
    private static final StatusFilter MANAGED_FILTER = new StatusFilter(WorkspaceResourceStatus.MANAGED, StatusFilter.AND);

    @Override
    protected boolean isEnabledForMultipleResources() {
        return false;
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return false;
    }

    @Override
    protected IDMWorkspaceResourceFilter getResourceFilter() {
        return MANAGED_FILTER;
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] selectedResources = getSelectedResources();
        if (selectedResources.length != 1) {
            return;
        }

        IResource resource;
        try {
            resource = TeamUtils.getResource(selectedResources[0]);
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
        final IProject proj = resource.getProject();
        IFolder fold = null;
        if (resource.getType() == IResource.FOLDER) {
            fold = (IFolder) resource;
        }

        final WorksetAdapter[] projectHolder = new WorksetAdapter[1];
        PlatformUI.getWorkbench().getProgressService().run(true, true, new IRunnableWithProgress() {
            @Override
            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                try {
                    projectHolder[0] = getProjectObject(proj, monitor);
                } catch (CoreException e) {
                    throw new InvocationTargetException(e);
                }
            }
        });

        IPath folderPath = null;
        try {
            fold = TeamUtils.getFolder(fold);
            folderPath = getFolderPath(proj, fold);
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }

        if (projectHolder[0] != null) {
            openHistoryView(projectHolder[0], folderPath, fold);
        } else {
            MessageDialog.openInformation(getShell(), Messages.Dialog_title, Messages.ChangeSetAction_0);
        }
    }

    // getting folder path if changeset view was called for folder
    private IPath getFolderPath(IProject proj, IFolder fold) throws CoreException {
        IPath folderPath = null;
        if (fold != null) {
            IDMProject dmProj = DMTeamPlugin.getWorkspace().getProject(proj);
            fold = TeamUtils.getFolder(fold);
            IPath offset = dmProj.getRemoteOffset();
            IPath path = fold.getFullPath().removeFirstSegments(1);
            folderPath = offset.append(path);
        }
        return folderPath;
    }

    private WorksetAdapter getProjectObject(IProject iproject, IProgressMonitor monitor) throws CoreException {
        IDMProject dmPrj = DMTeamPlugin.getWorkspace().getProject(iproject);
        if (dmPrj == null) {
            return null;
        }
        final DimensionsLcObject dmProject = dmPrj.getDimensionsObject();
        if (dmProject instanceof Project) {
            return new WorksetAdapter((Project) dmProject, dmPrj.getConnection());
        }
        return null;
    }
    
    private void openHistoryView(final WorksetAdapter project, final IPath folderPath, final IFolder folder) {
        if (project == null) {
            return;
        }
        try {
            final ChangeSetHistoryView changeSetView = (ChangeSetHistoryView) getActivePart().getSite()
                    .getPage()
                    .showView(ChangeSetHistoryView.ID);

            PlatformUI.getWorkbench().getProgressService().run(true, true, new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    UIUtils.getDisplay().asyncExec(new Runnable() {

                        @Override
                        public void run() {
                            if (changeSetView != null) {
                                changeSetView.showMe(project, folderPath, folder);
                            }
                        }

                    });

                }
            });
        } catch (PartInitException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        } catch (InterruptedException e) {
        } catch (InvocationTargetException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }
    }
}

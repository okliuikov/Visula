/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.ui.operations.ReplaceWithRemoteOperation;

/**
 * @author V.Grishchenko
 */
public class ReplaceWithRemoteAction extends DMTeamAction {

    public ReplaceWithRemoteAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resourcesToReplace = checkOverwriteOfDirtyResources(getSelectedResources());
        if (resourcesToReplace == null || resourcesToReplace.length == 0) {
            return;
        }
        new ReplaceWithRemoteOperation(getActivePart(), resourcesToReplace).run();
    }

    @Override
    protected void setActionEnablement(IAction action) {
        IResource[] resources = getSelectedResources();
        List<DMRepositoryProvider> dmProjects = new ArrayList<DMRepositoryProvider>();
        boolean allManaged = true;
        boolean anyOffline = false;
        for (int i = 0; i < resources.length; i++) {
            DMRepositoryProvider provider = DMRepositoryProvider.getDMProvider(resources[i]);
            if (provider != null && !dmProjects.contains(provider)) {
                dmProjects.add(provider);
            }
            try {
                allManaged &= DMTeamPlugin.getWorkspace().isManaged(resources[i])
                        || DMTeamPlugin.getWorkspace().hasRemote(resources[i]);
                DimensionsConnectionDetailsEx connection = provider.getIdmProject().getConnection();
                anyOffline |= connection.isOffline();
            } catch (CoreException e1) {
                handle(e1);
            }
        }
        action.setText(calculateProjectString());
        action.setEnabled(!dmProjects.isEmpty() && allManaged && !anyOffline && !isSelectedSccProjectsMoved());
    }

    @Override
    protected boolean needsToSaveDirtyEditors() {
        return true;
    }

}

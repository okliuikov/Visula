/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions.xml;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.internal.team.ui.actions.DMWorkspaceAction;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.MergeBaselineWizardFactory;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.MergeStreamWizardFactory;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.ThreeWayWizardDialog;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.xml.WizardFactory;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Action that creates merge wizard from workspace projects that were selected by user
 */
public class RepositoryExplorerMergeWizardAction extends DMWorkspaceAction {

    @Override
    protected boolean isEnabledForSelection() {
        final IStructuredSelection selection = getSelection();
        if (selection.isEmpty() || isSelectedSccProjectsMoved()) {
            return false;
        }

        try {
            List<MergeScopeGroup> possibleMergeScopes = null;
            if (selection.getFirstElement() instanceof WorksetAdapter) {
                WorksetAdapter ws = (WorksetAdapter) selection.getFirstElement();
                possibleMergeScopes = MergeScopeGroup.createValidScopeGroups(ws.getConnectionDetails());
                // selection of a stream in Serena Explorer view
                boolean isStream = (Boolean) ((WorksetAdapter) selection.getFirstElement()).getAPIObject().getAttribute(
                        SystemAttributes.WSET_IS_STREAM);
                if (selection.size() != 1 || !isStream || possibleMergeScopes.isEmpty()) {
                    return false;
                }
                return true;
            } else if (selection.getFirstElement() instanceof BaselineAdapter) {
                BaselineAdapter bl = (BaselineAdapter) selection.getFirstElement();
                possibleMergeScopes = MergeScopeGroup.createValidScopeGroups(bl.getConnectionDetails());
                // selection of a baseline in Serena Explorer view
                if (selection.size() != 1 || possibleMergeScopes.isEmpty()) {
                    return false;
                }
                return true;
            }

            return false;
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
            return false;
        }
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IStructuredSelection selection = getSelection();

        try {
            ThreeWayWizard wizard = null;
            DimensionsConnectionDetailsEx connection = null;
            if (selection.getFirstElement() instanceof VersionManagementProject) {
                // action is invoked from Serena Explorer for workset/baseline
                VersionManagementProject sourceProject = (VersionManagementProject) selection.getFirstElement();
                connection = sourceProject.getConnectionDetails();

                // potential scopes from top-level workspace projects
                List<MergeScopeGroup> possibleMergeScopes = MergeScopeGroup.createValidScopeGroups(connection);
                WizardFactory factory = createWizardFactory(sourceProject, possibleMergeScopes, connection);
                wizard = new ThreeWayWizard(factory);
            }

            if (wizard == null) {
                return;
            }

            final ThreeWayWizardDialog dialog = new ThreeWayWizardDialog(getShell(), wizard);
            BusyIndicator.showWhile(Display.getDefault(), new Runnable() {

                @Override
                public void run() {
                    if (dialog.open() == Window.CANCEL) {
                        return;
                    }
                }

            });
        } catch (CoreException e) {
            DMTeamUiPlugin.getDefault().handle(e, getShell());
        }
    }

    private WizardFactory createWizardFactory(VersionManagementProject sourceProject, List<MergeScopeGroup> possibleMergeScopes,
            DimensionsConnectionDetailsEx connection) {
        WizardFactory factory = null;
        if (sourceProject.getAPIObject() instanceof Project) {
            factory = new MergeStreamWizardFactory(sourceProject, possibleMergeScopes, connection);
        } else if (sourceProject.getAPIObject() instanceof Baseline) {
            factory = new MergeBaselineWizardFactory(sourceProject, possibleMergeScopes, connection);
        }
        return factory;
    }

}

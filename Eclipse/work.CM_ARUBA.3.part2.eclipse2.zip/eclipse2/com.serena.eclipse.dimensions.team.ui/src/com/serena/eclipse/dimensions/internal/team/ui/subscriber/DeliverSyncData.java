package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.Set;

import org.eclipse.core.resources.IResource;
import org.eclipse.team.core.synchronize.SyncInfoSet;

import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.TransferShape;

/**
 * Deliver synchronization data holder which contains workspace project changes with information about deliver shapes, excluded
 * resources, etc.
 */
class DeliverSyncData extends SyncData {
    private Set<IResource> excludedResources;
    private TransferShape deliverShape;
    private boolean isShelving;

    DeliverSyncData(DMRepositoryProvider provider, SyncInfoSet set, Set<IResource> excludedResources, TransferShape shape) {
        this(provider, set, excludedResources, shape, false);
    }

    DeliverSyncData(DMRepositoryProvider provider, SyncInfoSet set, Set<IResource> excludedResources, TransferShape shape,
            boolean isShelving) {
        super(provider, set);
        Assert.isNotNull(excludedResources);
        Assert.isNotNull(shape);
        this.excludedResources = excludedResources;
        this.deliverShape = shape;
        this.isShelving = isShelving;
    }

    /**
     * @return the isShelving
     */
    public boolean isShelving() {
        return isShelving;
    }

    /**
     * @param isShelving the isShelving to set
     */
    public void setShelving(boolean isShelving) {
        this.isShelving = isShelving;
    }

    /**
     * @return the excludedResources
     */
    public Set<IResource> getExcludedResources() {
        return excludedResources;
    }

    /**
     * @return the deliverShape
     */
    public TransferShape getDeliverShape() {
        return deliverShape;
    }

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.compare;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.compare.CompareConfiguration;
import org.eclipse.compare.CompareEditorInput;
import org.eclipse.compare.ITypedElement;
import org.eclipse.compare.structuremergeviewer.DiffNode;
import org.eclipse.compare.structuremergeviewer.Differencer;
import org.eclipse.compare.structuremergeviewer.IDiffContainer;
import org.eclipse.compare.structuremergeviewer.IStructureComparator;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.team.core.variants.IResourceVariant;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamStatus;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteResource;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamPreferences;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Compares remote projects and baselines.
 * @author V.Grishchenko
 */
public class DMCompareRevToLocalEditorInput extends CompareEditorInput {

    private String toolTipText;

    RemoteResourceTypedElement ancestor = null;
    RemoteResourceTypedElement remote = null;
    LocalResourceTypedElement local = null;

    public DMCompareRevToLocalEditorInput(RemoteResourceTypedElement remote, LocalResourceTypedElement local) {
        super(new CompareConfiguration());
        assert remote != null;
        assert local != null;
        this.remote = remote;
        this.local = local;
    }

    @Override
    protected Object prepareInput(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
        monitor = Utils.monitorFor(monitor);
        final boolean threeWay = ancestor != null;

        final Differencer d = new Differencer() {
            @Override
            protected boolean contentsEqual(Object input1, Object input2) {
                if (input1 instanceof RemoteResourceTypedElement && input2 instanceof RemoteResourceTypedElement) {
                    IResourceVariant remote1 = ((RemoteResourceTypedElement) input1).getRemote();
                    IResourceVariant remote2 = ((RemoteResourceTypedElement) input2).getRemote();
                    boolean revisionsEqual = remote1.equals(remote2);
                    if (!revisionsEqual && considerContentsIfRevisionsDiffer()) {
                        return super.contentsEqual(input1, input2);
                    }
                    return revisionsEqual;
                }
                return super.contentsEqual(input1, input2);
            }

            @Override
            protected void updateProgress(IProgressMonitor progressMonitor, Object node) {
                if (node instanceof ITypedElement) {
                    ITypedElement element = (ITypedElement) node;
                    progressMonitor.subTask(NLS.bind(Messages.DMCompareEditorInput_fileProgress, new String[] { element.getName() }));
                    progressMonitor.worked(1);
                }
            }

            @Override
            protected Object[] getChildren(Object input) {
                if (input instanceof IStructureComparator) {
                    Object[] children = ((IStructureComparator) input).getChildren();
                    if (children != null) {
                        return children;
                    }
                }
                return null;
            }

            @Override
            protected Object visit(Object data, int result, Object ancestor, Object left, Object right) {
                return new DiffNode((IDiffContainer) data, result, (ITypedElement) ancestor, (ITypedElement) left,
                        (ITypedElement) right);
            }
        };

        try {

            int ancestorRefreshWork = ancestor == null ? 0 : 500;
            int leftRefreshWork = remote == null ? 0 : 500;
            int rightRefreshWork = local == null ? 0 : 500;
            int differencerWork = 500;
            int totalWork = ancestorRefreshWork + leftRefreshWork + rightRefreshWork + differencerWork;

            monitor.beginTask(Messages.DMCompareEditorInput_comparing, totalWork);

            // here we use remote trees to fetch remote data, this is a bit
            // pushing it as trees operate in the context of local projects
            // which we don't technically have in this situation, to fool the
            // trees local bogus project handles are created and passed to the
            // refresh method.

            // do the diff
            Object result = null;
            IProgressMonitor sub = Utils.subMonitorFor(monitor, differencerWork);
            sub.beginTask(Messages.DMCompareEditorInput_comparing, 500);
            try {
                result = d.findDifferences(threeWay, sub, null, ancestor, local, remote);
            } finally {
                sub.done();
            }
            initLabels();
            return result;
        } catch (OperationCanceledException e) {
            throw new InterruptedException(e.getMessage());
        } catch (Exception e) {
            handle(e);
            return null;
        } finally {
            monitor.done();
        }
    }

    @Override
    public Viewer createDiffViewer(Composite parent) {
        Viewer viewer = super.createDiffViewer(parent);
        viewer.addSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                CompareConfiguration cc = getCompareConfiguration();
                setLabels(cc, (IStructuredSelection) event.getSelection());
            }
        });
        return viewer;
    }

    /**
     * Handles a random exception and sanitizes it into a reasonable
     * error message.
     */
    private void handle(Exception e) {
        // create a status
        Throwable t = e;
        // unwrap the invocation target exception
        if (t instanceof InvocationTargetException) {
            t = ((InvocationTargetException) t).getTargetException();
        }
        IStatus error;
        if (t instanceof CoreException) {
            error = ((CoreException) t).getStatus();
        } else {
            error = DMTeamStatus.createErrorStatus(DMTeamStatus.UNKNOWN, Messages.DMCompareRevToLocalEditorInput_internalError, t);
        }
        setMessage(error.getMessage());
        DMTeamUiPlugin.log(error);
    }

    /**
     * Sets up the title and pane labels for the comparison view.
     */
    private void initLabels() {
        CompareConfiguration cc = getCompareConfiguration();
        setLabels(cc, new StructuredSelection());

        String title;
        String lRevision = ""; //$NON-NLS-1$
        String lName = ""; //$NON-NLS-1$

        IDMRemoteFile remoteFile = (IDMRemoteFile) remote.getRemote();
        NLS.bind(Messages.nameAndRevision, remoteFile.getName(), remoteFile.getRevision());
        lRevision = remoteFile.getRevision();
        lName = remoteFile.getName();

        if (ancestor != null) {
            String aSpec = ""; //$NON-NLS-1$
            title = NLS.bind(Messages.DMCompareRevAndLocalEditorInput_titleAncestor, new Object[] { lName, lRevision, aSpec });

        } else {
            title = NLS.bind(Messages.DMCompareRevAndLocalEditorInput_titleNoAncestor, lName, lRevision);
        }
        toolTipText = title;
        setTitle(title);
    }

    private void setLabels(CompareConfiguration cc, IStructuredSelection selection) {
        String ancestorLabel = null;
        String leftLabel = null;
        String rightLabel = null;

        Image ancestorImage = null;
        Image leftImage = null;
        Image rightImage = null;

        if (!selection.isEmpty()) {
            DiffNode node = (DiffNode) selection.getFirstElement();
            RemoteResourceTypedElement ae = (RemoteResourceTypedElement) node.getAncestor();
            if (ae != null) {
                ancestorLabel = getLabel((IDMRemoteResource) ae.getRemote());
            }
            RemoteResourceTypedElement le = (RemoteResourceTypedElement) node.getLeft();
            if (le != null) {
                leftLabel = getLabel((IDMRemoteResource) le.getRemote());
            }
            RemoteResourceTypedElement re = (RemoteResourceTypedElement) node.getRight();
            if (re != null) {
                rightLabel = getLabel((IDMRemoteResource) re.getRemote());
            }
        } else {
            if (ancestor != null) {
                ancestorLabel = getLabel((IDMRemoteResource) ancestor.getRemote());
            }
            if (remote != null) {
                leftLabel = local.getName();
            }
            if (local != null) {
                rightLabel = getLabel((IDMRemoteResource) remote.getRemote());
            }
        }

        cc.setAncestorLabel(ancestorLabel);
        cc.setLeftLabel(leftLabel);
        cc.setRightLabel(rightLabel);

        cc.setAncestorImage(ancestorImage);
        cc.setLeftImage(leftImage);
        cc.setRightImage(rightImage);
    }

    private String getLabel(IDMRemoteResource remoteResource) {
        if (remoteResource.isContainer()) {
            return remoteResource.getPath().toString();
        }
        IDMRemoteFile remoteFile = (IDMRemoteFile) remoteResource;
        return NLS.bind(Messages.nameAndRevision, remoteFile.getName(), remoteFile.getRevision());
    }

    @Override
    public String getToolTipText() {
        if (toolTipText != null) {
            return toolTipText;
        }
        return super.getToolTipText();
    }

    @Override
    public Object getAdapter(Class adapter) {
        if (IFile.class.equals(adapter)) {
            // DEF177767 fix: should not return IFile adapter from this class
            return null;
        } else {
            return super.getAdapter(adapter);
        }
    }

    private boolean considerContentsIfRevisionsDiffer() {
        return DMTeamUiPlugin.getDefault().getPreferenceStore().getBoolean(IDMTeamPreferences.COMPARE_CONSIDER_CONTENTS);
    }

}

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.revisions.IRevisionRulerColumn;
import org.eclipse.jface.text.revisions.IRevisionRulerColumnExtension;
import org.eclipse.jface.text.revisions.Revision;
import org.eclipse.jface.text.revisions.RevisionInformation;
import org.eclipse.jface.text.revisions.RevisionRange;
import org.eclipse.jface.text.source.LineNumberChangeRulerColumn;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.events.MenuDetectEvent;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.editors.text.EditorsUI;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditorPreferenceConstants;

import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.ItemRevision;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotateRevision;
import com.serena.eclipse.dimensions.internal.ui.model.BlameAnnotationModel;
import com.serena.eclipse.dimensions.internal.ui.model.IBlameAnnotationElement;
import com.serena.eclipse.dimensions.internal.ui.model.IBlameAnnotationInfo;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 *
 * @author kberezovchuk
 *
 */
public abstract class BlameAnnotateOperation {

    protected static final String DEFAULT_EDITOR_ID = "org.eclipse.ui.DefaultTextEditor"; //$NON-NLS-1$
    protected static final QualifiedName changeListener = new QualifiedName(
            "com.serena.dimensions.eclipse.blameruler", "chlistener");//$NON-NLS-1$ //$NON-NLS-2$
    protected static final QualifiedName menuListener = new QualifiedName(
            "com.serena.dimensions.eclipse.blameruler", "menulistener");//$NON-NLS-1$ //$NON-NLS-2$
    protected static final String BINTYPE = "BINARY"; //$NON-NLS-1$

    private IWorkbenchPage page;
    private IDMRemoteFile base;
    private DimensionsConnectionDetailsEx connection;

    public BlameAnnotateOperation(IDMRemoteFile base, IWorkbenchPage page, DimensionsConnectionDetailsEx connection) {
        this.page = page;
        this.base = base;
        this.connection = connection;
    }

    protected abstract IEditorInput createEditorInput();

    protected abstract void showRevisionInformation(AbstractDecoratedTextEditor editor, RevisionInformation info)
            throws CoreException;

    protected IWorkbenchPage getPage() {
        return page;
    }

    protected IDMRemoteFile getBase() {
        return base;
    }

    protected DimensionsConnectionDetailsEx getConnection() {
        return connection;
    }

    public void execute() throws CoreException {
        IEditorInput input = createEditorInput();
        IEditorDescriptor descriptor = PlatformUI.getWorkbench().getEditorRegistry().getDefaultEditor(getBase().getName());
        if (descriptor == null) {
            descriptor = PlatformUI.getWorkbench().getEditorRegistry().findEditor(DEFAULT_EDITOR_ID);
        }

        AbstractDecoratedTextEditor editor = findEditor(input, descriptor);
        if (editor != null) {
            IRevisionRulerColumn c = (IRevisionRulerColumn) editor.getAdapter(IRevisionRulerColumn.class);
            if (c != null && c instanceof LineNumberChangeRulerColumn) {
                LineNumberChangeRulerColumn col = (LineNumberChangeRulerColumn) c;
                if (col.isShowingRevisionInformation()) {
                    getPage().activate(editor);
                    return;
                }
            }
        }

        open(input, descriptor);

    }

    private void open(final IEditorInput input, final IEditorDescriptor descriptor) throws CoreException {
        final ItemRevision itemRevision = getBase().getItemRevision();

        Job job = new Job(Messages.blameAnnot_load_description_job) {

            @Override
            protected IStatus run(IProgressMonitor monitor) {
                IStatus result = Status.OK_STATUS;
                try {
                    BlameAnnotationModel model = loadModel(itemRevision, monitor);
                    final RevisionInformation revisionInfo = prepareAnnotatations(model, monitor);
                    if (revisionInfo != null) {
                        Display.getDefault().asyncExec(new Runnable() {

                            @Override
                            public void run() {
                                try {
                                    IPreferenceStore pStore = EditorsUI.getPreferenceStore();
                                    pStore.setValue(AbstractDecoratedTextEditorPreferenceConstants.REVISION_RULER_SHOW_AUTHOR, true);
                                    pStore.setValue(AbstractDecoratedTextEditorPreferenceConstants.REVISION_RULER_SHOW_REVISION,
                                            true);
                                    pStore.setValue(AbstractDecoratedTextEditorPreferenceConstants.REVISION_RULER_RENDERING_MODE,
                                            IRevisionRulerColumnExtension.AUTHOR_SHADED_BY_AGE.name());
                                    IEditorPart editor = getPage().openEditor(input, descriptor.getId(), true);
                                    if (editor != null && editor instanceof AbstractDecoratedTextEditor) {
                                        showRevisionInformation((AbstractDecoratedTextEditor) editor, revisionInfo);
                                    }
                                } catch (PartInitException e) {
                                    DMTeamUiPlugin.getDefault().handle(e);
                                } catch (CoreException e) {
                                    DMTeamUiPlugin.getDefault().handle(e);
                                }
                            }
                        });
                    } else {
                        throw new DMException(new Status(IStatus.ERROR, DMTeamPlugin.ID, Messages.blameAnnot_error));
                    }

                } catch (DMException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
                return result;
            }

        };
        job.schedule();
    }

    private BlameAnnotationModel loadModel(final ItemRevision itemRevision, IProgressMonitor monitor) throws DMException {
        final BlameAnnotationModel model = new BlameAnnotationModel(itemRevision);
        final IProgressMonitor submonitor = Utils.subMonitorFor(monitor, IProgressMonitor.UNKNOWN);
        Session session = getConnection().openSession(monitor);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                boolean isText = connection.isItemRevisionInTextFormat(itemRevision, submonitor);
                if (!isText) {
                    throw new DMException(new Status(IStatus.INFO, DMTeamPlugin.ID, Messages.blameAnnot_fileformat_warning));
                }

                model.load(submonitor);
            }
        }, monitor);
        return model;
    }

    private AbstractDecoratedTextEditor findEditor(IEditorInput input, IEditorDescriptor descriptor) {
        AbstractDecoratedTextEditor result = null;
        String editorId = DEFAULT_EDITOR_ID;
        if (descriptor != null) {
            editorId = descriptor.getId();
        }

        IEditorReference[] findEditors = getPage().findEditors(input, editorId,
                IWorkbenchPage.MATCH_ID | IWorkbenchPage.MATCH_INPUT);
        if (findEditors.length > 0) {
            IEditorPart editor = findEditors[0].getEditor(true);
            if (editor instanceof AbstractDecoratedTextEditor) {
                result = (AbstractDecoratedTextEditor) editor;
            }
        }

        return result;
    }

    private RevisionInformation prepareAnnotatations(BlameAnnotationModel model, IProgressMonitor monitor) throws DMException {
        if (model.isLoaded() && model.getAnnotatedLines() != null) {
            final IDMProject[] project = new IDMProject[1];
            final IDMRemoteFile base = getBase();
            IFile local = null;
            if (getBase().getProject() == null) {
                // Try to resolve workspace project for remote temp file
                final Session session = getConnection().openSession(monitor);
                session.run(new ISessionRunnable() {
                    @Override
                    public void run() throws Exception {
                        DimensionsLcObject relatedObj = base.getItemRevision().getProject();

                        IDMProject[] projects = DMTeamPlugin.getWorkspace().getProjects();
                        for (int i = 0; i < projects.length; i++) {
                            try {
                                DimensionsLcObject currentWorkspaceObject = projects[i].getDimensionsObject();
                                if (currentWorkspaceObject.equals(relatedObj)) {
                                    IPath remoteOffset = projects[i].getRemoteOffset();
                                    if (remoteOffset == null || remoteOffset.isEmpty() || remoteOffset.isPrefixOf(base.getPath())) {
                                        project[0] = projects[i];
                                        break;
                                    }
                                }
                            } catch (DMException e) {
                                // swallow intentionally: expected cause of failure - workset not found. Warning: not safe!
                            }
                        }
                    }
                }, monitor);

                if (project[0] != null) {
                    base.setProject(project[0]);
                }
            }

            if (base.getProject() != null) {
                local = base.getLocalFile();
            }

            final RevisionInformation info = new RevisionInformation();
            Map<String, BlameAnnotateRevision> revisions = new HashMap<String, BlameAnnotateRevision>();
            IBlameAnnotationElement[] annotatedLines = model.getAnnotatedLines();
            int i = 0;
            // Accumulate the lines belonging to the particular revision
            for (IBlameAnnotationElement baElement : annotatedLines) {
                String revisionId = baElement.getRevision();
                BlameAnnotateRevision revision = revisions.get(revisionId);
                if (revision == null) {
                    revisions.put(revisionId, revision = new BlameAnnotateRevision(revisionId, baElement.getAuthor()));
                    info.addRevision(revision);
                }
                revision.addLine(++i);
            }
            DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");//$NON-NLS-1$
            for (BlameAnnotateRevision revision : revisions.values()) {
                revision.addLine(BlameAnnotateRevision.END_LINE);
                IBlameAnnotationInfo annotInfo = model.getAnnotatedLineInfo(revision.getId());
                revision.setComment(annotInfo.getComment());
                revision.setRequests(annotInfo.getRequests());
                revision.setBase(base);
                revision.setLocal(local);
                revision.setConnection(getConnection());
                try {
                    revision.setDate(formatter.parse(annotInfo.getDate()));
                } catch (ParseException e) {
                    DMTeamUiPlugin.getDefault().handle(e);
                }
            }
            return info;
        }
        return null;
    }

    protected MenuDetectListener addMenuDetectListener(RevisionInformation info, IRevisionRulerColumn c) {
        if (c != null && info != null) {
            LineNumberChangeRulerColumn col = (LineNumberChangeRulerColumn) c;
            Control control = c.getControl();
            MenuDetectListener mListener = new ForceSelectionMenuListener(info, col);
            control.addMenuDetectListener(mListener);
            return mListener;
        }
        return null;

    }

    protected IResourceChangeListener addResourceChangeListener(IRevisionRulerColumn c) {
        if (c != null) {
            final LineNumberChangeRulerColumn col = (LineNumberChangeRulerColumn) c;
            final IFile localFile = getBase().getLocalFile();
            if (localFile != null && localFile.exists()) {
                final IWorkspace workspace = localFile.getWorkspace();
                IResourceChangeListener chListener = new IResourceChangeListener() {

                    @Override
                    public void resourceChanged(IResourceChangeEvent event) {
                        IResourceDelta delta = event.getDelta();
                        final IResource[] resuorce = new IResource[1];
                        if (col != null && localFile != null && delta != null && IResourceDelta.CHANGED == delta.getKind()) {
                            try {
                                delta.accept(new IResourceDeltaVisitor() {

                                    @Override
                                    public boolean visit(IResourceDelta delta) throws CoreException {
                                        IResource resource = delta.getResource();
                                        if (resource != null && resource.equals(localFile)
                                                && IResourceDelta.CHANGED == delta.getKind()
                                                && (IResourceDelta.CONTENT & delta.getFlags()) != 0) {
                                            resuorce[0] = resource;
                                            return false;
                                        }
                                        return true;
                                    }
                                });
                            } catch (CoreException e) {
                                DMTeamUiPlugin.getDefault().handle(e);
                            }

                            if (col.isShowingRevisionInformation() && resuorce[0] != null) {
                                Display.getDefault().asyncExec(new Runnable() {

                                    @Override
                                    public void run() {
                                        col.setRevisionInformation(null);
                                    }
                                });
                            } else if (!col.isShowingRevisionInformation()) {
                                workspace.removeResourceChangeListener(this);
                            }
                        }
                    }
                };
                workspace.addResourceChangeListener(chListener);
                return chListener;
            }
        }
        return null;
    }

    private static class ForceSelectionMenuListener implements MenuDetectListener {

        private RevisionInformation info;
        private IRevisionRulerColumn c;

        public ForceSelectionMenuListener(RevisionInformation info, IRevisionRulerColumn c) {
            this.info = info;
            this.c = c;
        }

        @Override
        public void menuDetected(MenuDetectEvent e) {
            if (c != null & info != null) {
                IRevisionRulerColumnExtension ext = (IRevisionRulerColumnExtension) c;
                LineNumberChangeRulerColumn col = (LineNumberChangeRulerColumn) c;
                if (col.isShowingRevisionInformation()) {
                    ISelectionProvider selectionProvider = ext.getRevisionSelectionProvider();
                    int line = c.getLineOfLastMouseButtonActivity();

                    List<RevisionRange> ranges = info.getRanges();

                    Revision revision = null;
                    for (Iterator<RevisionRange> iterator = ranges.iterator(); iterator.hasNext();) {
                        RevisionRange range = iterator.next();
                        int startLine = range.getStartLine();
                        int numberOfLines = range.getNumberOfLines();
                        if (line >= startLine && line < startLine + numberOfLines) {
                            revision = range.getRevision();
                            break;
                        }
                    }

                    if (revision != null) {
                        selectionProvider.setSelection(new StructuredSelection(revision));
                    } else {
                        selectionProvider.setSelection(new StructuredSelection());
                    }
                } else {
                    Control control = col.getControl();
                    if (control != null) {
                        control.removeMenuDetectListener(ForceSelectionMenuListener.this);
                    }
                }
            }
        }

    }

}

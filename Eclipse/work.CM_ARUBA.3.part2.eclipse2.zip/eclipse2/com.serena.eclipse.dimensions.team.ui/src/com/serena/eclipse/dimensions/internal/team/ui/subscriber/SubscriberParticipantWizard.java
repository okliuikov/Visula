/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 * Contributors:
 * IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipant;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;
import org.eclipse.team.ui.synchronize.SubscriberParticipant;

import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * This is the class registered with the org.eclipse.team.ui.synchronizeWizard
 */
public abstract class SubscriberParticipantWizard extends Wizard {

    private GlobalRefreshResourceSelectionPage selectionPage;
    private IWizard importWizard;

    public SubscriberParticipantWizard() {
        setDefaultPageImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN));
        setNeedsProgressMonitor(false);
    }

    @Override
    public String getWindowTitle() {
        return Messages.SubscriberParticipantWizard_title;
    }

    @Override
    public void addPages() {
        if (getRootResources().length == 0) {
            importWizard = getImportWizard();
            importWizard.setContainer(getContainer());
            importWizard.addPages();
            IWizardPage startingPage = importWizard.getStartingPage();
            if (startingPage != null) {
                startingPage.setTitle(NLS.bind(Messages.SubscriberParticipantWizard_noResources, getName()));
                startingPage.setDescription(NLS.bind(Messages.SubscriberParticipantWizard_noResourcesDesc,
                        importWizard.getWindowTitle()));
            }
        } else {
            selectionPage = new GlobalRefreshResourceSelectionPage(getRootResources());
            selectionPage.setTitle(NLS.bind(Messages.SubscriberParticipantWizard_selPageTitle, getName()));
            selectionPage.setMessage(Messages.SubscriberParticipantWizard_selPageMessage);
            addPage(selectionPage);
        }
    }

    @Override
    public boolean performFinish() {
        if (importWizard != null) {
            return importWizard.performFinish();
        }
        IResource[] resources = selectionPage.getRootResources();
        if (resources != null && resources.length > 0) {
            try {

                SubscriberParticipant participant = createParticipant(selectionPage.getSynchronizeScope());
                TeamUI.getSynchronizeManager().addSynchronizeParticipants(new ISynchronizeParticipant[] { participant });
                // We don't know in which site to show progress because a participant could actually
                // be shown in multiple sites.
                participant.run(null /* no site */);
            } catch (TeamException e) {
                DMTeamUiPlugin.log(e.getStatus());
                return false;
            }
        }
        return true;
    }

    @Override
    public IWizardPage getNextPage(IWizardPage page) {
        if (importWizard != null) {
            return importWizard.getNextPage(page);
        }
        return super.getNextPage(page);
    }

    @Override
    public boolean performCancel() {
        if (importWizard != null) {
            return importWizard.performCancel();
        }
        return super.performCancel();
    }

    @Override
    public boolean canFinish() {
        if (importWizard != null) {
            return importWizard.canFinish();
        }
        return super.canFinish();
    }

    @Override
    public IWizardPage getStartingPage() {
        if (importWizard != null) {
            return importWizard.getStartingPage();
        }
        return super.getStartingPage();
    }

    protected abstract IResource[] getRootResources();

    protected abstract SubscriberParticipant createParticipant(ISynchronizeScope scope) throws TeamException;

    protected abstract String getName();

    protected abstract IWizard getImportWizard();
}
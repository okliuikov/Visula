/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.core.IService;
import com.serena.eclipse.core.ServiceRegistry;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.SccProjectContainer;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.WorksetList;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.NewTipBaselineWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.ProjectBranchWizard;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMPreferences;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsCategoryElement;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsProjectsCategory;
import com.serena.eclipse.internal.ui.ServicesView;

/**
 * Branches from the workspace.
 * @author V.Grishchenko
 */
public class BranchAction extends DMWorkspaceAction {

    public BranchAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        IResource[] resources = getSelectedResources();
        if (resources == null || resources.length == 0 || resources[0].getType() != IResource.PROJECT) {
            return;
        }
        IProject project = (IProject) resources[0];
        try {
            final IDMProject dmProject = DMTeamPlugin.getWorkspace().getProject(project);
            final VersionManagementProject remoteProject = getRemoteProjectFor(project); // this will connect if necessary
            if (dmProject.isSccStyle()) {
                MessageDialog dialog = new MessageDialog(getShell(), Messages.BranchAction_0, null, Messages.BranchAction_1,
                        MessageDialog.INFORMATION, new String[] { IDialogConstants.YES_LABEL, IDialogConstants.NO_LABEL }, 0);
                if (dialog.open() == 0) {
                    final ServicesView sv = (ServicesView) getActivePart().getSite().getPage().showView(ServicesView.ID);
                    boolean show_n21 = DMUIPlugin.getDefault()
                            .getPluginPreferences()
                            .getBoolean(IDMPreferences.SHOW_N2ONE_PROJECTS_IN_EXPLORER);
                    if (show_n21) {
                        PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                            @Override
                            public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                                try {
                                    revealProjectContainer(dmProject, remoteProject, new SafeViewerAccess(sv.getServiceTree()),
                                            monitor);
                                } catch (DMException e) {
                                    throw new InvocationTargetException(e);
                                }
                            }
                        });
                    }
                }
                return;
            }

            if (remoteProject != null) {
                ProjectBranchWizard branchWizard = new ProjectBranchWizard(dmProject, remoteProject);
                WizardDialog dialog = new WizardDialog(getShell(), branchWizard);
                if (dialog.open() != Window.CANCEL && branchWizard.getCreateBaseline()) {
                    NewBaselineWizard baselineWizard = new NewTipBaselineWizard(dmProject.getConnection(),
                            branchWizard.getCreatedObjectAdapter());
                    WizardDialog dialog2 = new WizardDialog(getShell(), baselineWizard);
                    dialog2.open();
                }
            }
        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }
    }

    private static class SafeViewerAccess {
        private TreeViewer treeViewer;

        SafeViewerAccess(TreeViewer treeViewer) {
            this.treeViewer = treeViewer;
        }

        void expandToLevel(final Object element, final int level) {
            treeViewer.getTree().getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    treeViewer.expandToLevel(element, level);
                }
            });
        }

        void setSelection(final ISelection sel, final boolean reveal) {
            treeViewer.getTree().getDisplay().syncExec(new Runnable() {
                @Override
                public void run() {
                    treeViewer.setSelection(sel, reveal);
                }
            });
        }
    }

    private void revealProjectContainer(IDMProject dmProject, final VersionManagementProject remoteProject,
            SafeViewerAccess treeViewer, IProgressMonitor monitor) throws DMException {
        monitor.beginTask(Messages.BranchAction_2, IProgressMonitor.UNKNOWN);
        try {
            IService dmSvc = ServiceRegistry.getInstance().getService(DMPlugin.SERVICE_ID);
            if (dmSvc == null) {
                return;
            }

            Session session = dmProject.getConnection().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    remoteProject.getAPIObject().queryAttribute(SystemAttributes.IDE_DM_UID);
                }
            }, monitor);
            Long uid = (Long) remoteProject.getAPIObject().getAttribute(SystemAttributes.IDE_DM_UID);
            if (uid != null && uid.longValue() > 0) {
                treeViewer.expandToLevel(dmSvc, 2);
                treeViewer.expandToLevel(
                        DimensionsCategoryElement.getCategory(dmProject.getConnection(), DimensionsProjectsCategory.class), 1);
                WorksetList containerList = WorksetList.getSccProjectContainerList(dmProject.getConnection(), false, false);
                treeViewer.expandToLevel(containerList, 1);
                APIObjectAdapter[] containers = containerList.getObjects();
                SccProjectContainer theContainer = null;
                for (int i = 0; i < containers.length; i++) {
                    SccProjectContainer aContainer = (SccProjectContainer) containers[i];
                    if (aContainer.getIdeUid().equals(uid.toString())) {
                        theContainer = aContainer;
                        break;
                    }
                }
                if (theContainer != null) {
                    treeViewer.expandToLevel(theContainer, 1);
                    APIObjectAdapter theMember = null;
                    if (remoteProject instanceof WorksetAdapter) {
                        WorksetList memberList = theContainer.getProjectList();
                        APIObjectAdapter[] members = memberList.getObjects();
                        for (int i = 0; i < members.length; i++) {
                            if (dmProject.getId().equals(members[i].getObjectSpec())) {
                                theMember = members[i];
                                break;
                            }
                        }
                    } else {
                        BaselineList containerBaselines = theContainer.getBaselineList();
                        treeViewer.expandToLevel(containerBaselines, 1);
                        APIObjectAdapter[] baselines = containerBaselines.getObjects();
                        for (int i = 0; i < baselines.length; i++) {
                            if (dmProject.getId().equals(baselines[i].getObjectSpec())) {
                                theMember = baselines[i];
                                break;
                            }
                        }
                    }

                    if (theMember != null) {
                        StructuredSelection ss = new StructuredSelection(theMember);
                        treeViewer.setSelection(ss, true);
                    }
                }
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    protected boolean isEnabledForMultipleResources() {
        return false;
    }

    @Override
    protected boolean isEnabledForBaseline() {
        return true;
    }

}

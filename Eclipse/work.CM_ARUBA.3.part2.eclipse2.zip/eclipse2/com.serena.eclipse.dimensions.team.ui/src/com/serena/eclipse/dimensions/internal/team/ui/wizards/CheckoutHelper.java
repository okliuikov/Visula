/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.viewers.ILabelDecorator;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.CmRulesDetails;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.ItemType;
import com.serena.dmclient.objects.TypeOptions;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.TypeReference;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.CheckoutRequest;
import com.serena.eclipse.dimensions.internal.team.core.FolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMRemoteFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceFile;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResource;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.Option;
import com.serena.eclipse.dimensions.internal.team.ui.Option.Value;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel.BulkLoadSupport;
import com.serena.eclipse.dimensions.internal.ui.model.ItemRevisionAttributeModel;

/**
 * @author V.Grishchenko
 */
public class CheckoutHelper extends TeamOperationWizardHelper {
    public static final String CONCURRENT_CHECKOUT = "conc_cout"; //$NON-NLS-1$
    public static final String OVERWRITE = "overwrite"; //$NON-NLS-1$
    public static final String EXPAND_SUBST_VARS = "expand_subst_vars"; //$NON-NLS-1$

    private boolean checkoutBase; // flag to checkout base revision instead of remote

    public CheckoutHelper(IResource[] initialResources, IDMWorkspaceResourceFilter filter, IProgressMonitor monitor)
            throws CoreException {
        this(initialResources, filter, false, monitor);
    }

    public CheckoutHelper(IResource[] initialResources, IDMWorkspaceResourceFilter filter, boolean checkoutBase,
            IProgressMonitor monitor) throws CoreException {
        super(initialResources, filter, monitor);
        this.checkoutBase = checkoutBase;
        if (getClass().equals(CheckoutHelper.class)) {
            initialize(monitor);
        }
    }

    @Override
    public boolean includePhantoms() {
        return true;
    }

    @Override
    public void commit() throws CoreException {
        super.commit();
        IFile[] files = getOperationFiles();
        for (int i = 0; i < files.length; i++) {
            IAttributeModel attributeModel = getAttributeModel(files[i]);
            if (attributeModel != null && attributeModel.isDirty()) {
                attributeModel.save(null);
            }
        }
    }

    @Override
    protected void populateMaps(Map<IResource, WorkspaceResourceRequest> requests, Map<IResource, IAttributeModel> attributes,
            IDMWorkspaceResource[] resources, IProgressMonitor monitor) throws CoreException {
        monitor = Utils.monitorFor(monitor);
        try {
            List<IDMWorkspaceFile> files = new ArrayList<IDMWorkspaceFile>();
            boolean isBaseline = false;
            final List<ItemRevision> revisions = new ArrayList<ItemRevision>();
            for (int i = 0; i < resources.length; i++) {
                if (resources[i].isContainer()) {
                    requests.put(resources[i].getLocalResource(), new FolderRequest((IContainer) resources[i].getLocalResource()));
                } else {
                    IDMWorkspaceFile dmFile = (IDMWorkspaceFile) resources[i];
                    files.add(dmFile);
                    revisions.add(getItemRevision(dmFile));
                }
            }
            DimensionsConnectionDetailsEx connection = getConnection();
            // pre-cache product, type, and current state
            monitor.beginTask(null, 10 + 20 + (30 * files.size()));
            monitor.subTask(Messages.CheckoutHelper_0);
            primeAttributesForCache(revisions, Utils.subMonitorFor(monitor, 10)); // 10

            // consult cm-rules to find out if a request is a must
            int[] cmRulesResult = new int[files.size()];
            if (resources.length != 0) {
                isBaseline = resources[0].getProject().isBaseline();
            }
            if (!isBaseline) {
                cmRulesResult = queryCmRules(CmRulesDetails.CMRULES_EXTRACT, new ArrayList<IDMWorkspaceResource>(files), revisions,
                        Utils.subMonitorFor(monitor, 20)); // 20
            }

            HashMap<TypeReference, BulkLoadSupport> typeGroups = new HashMap<TypeReference, BulkLoadSupport>();

            for (int i = 0; i < files.size(); i++) {
                IDMWorkspaceFile dmFile = files.get(i);
                ItemRevision revision = revisions.get(i);
                ItemType itemType = (ItemType) connection.getType(revision, Utils.subMonitorFor(monitor, 10)); // 10
                revision.getAttribute(SystemAttributes.STATUS);

                CheckoutRequest checkoutRequest = new CheckoutRequest(dmFile.getLocalFile(), itemType, revision,
                        cmRulesResult[i] > 0, cmRulesResult[i] == CmRulesDetails.ANY_REQUEST);

                // checkout helper is used to construct upload requests for
                // optimistically modified files. Note that during vanilla checkout
                // the wizard will ignore comment requirement as comment field
                // is not shown, but during upload this will make sure the wizard will
                // enforce a comment for optimistic checkins
                int options = checkoutRequest.getItemTypeOptions();
                if ((options & TypeOptions.ITEM_REQUIRE_USER_COMMENT) != 0) {
                    setCommentRequired(true);
                }

                requests.put(dmFile.getLocalFile(), checkoutRequest);

                String product = (String) revision.getAttribute(SystemAttributes.PRODUCT_NAME);
                String type = (String) revision.getAttribute(SystemAttributes.TYPE_NAME);
                TypeReference typeReference = new TypeReference(getConnection(), product, DMTypeScope.ITEM, type);
                IAttributeModel.BulkLoadSupport bls = typeGroups.get(typeReference);
                if (bls == null) {
                    bls = new IAttributeModel.BulkLoadSupport();
                    typeGroups.put(typeReference, bls);
                }
                bls.add(revision);

                ItemRevisionAttributeModel model = new ItemRevisionAttributeModel(checkoutRequest.getNewRevisionDetails(),
                        revision, itemType, getConnection());
                model.setBulkLoadSupport(bls);
                attributes.put(dmFile.getLocalFile(), model);

                monitor.worked(10); // 20
            }
            monitor.subTask(Messages.CheckoutHelper_1);
            for (Iterator<IAttributeModel> modelIter = attributes.values().iterator(); modelIter.hasNext();) {
                ItemRevisionAttributeModel model = (ItemRevisionAttributeModel) modelIter.next();
                model.load(Utils.subMonitorFor(monitor, 10)); // 30
            }
        } finally {
            monitor.done();
        }
    }

    @Override
    protected Option[] createOptions() {
        Option[] result = new Option[3];
        result[0] = new Option(OVERWRITE, Messages.CheckoutHelper_2, new Value[] { Option.YES, Option.NO, Option.PROMPT }, 2);
        result[1] = new Option(CONCURRENT_CHECKOUT, Messages.CheckoutHelper_3,
                new Value[] { Option.YES, Option.NO, Option.PROMPT }, 2);
        result[2] = new Option(EXPAND_SUBST_VARS, Messages.CheckoutHelper_5, new Value[] { Option.YES, Option.NO }, 1);
        return result;
    }

    /*
     * Returns a revision to checkout for the supplied workspace file. This
     * implementation returns remote (latest as cached by workspace) if it is
     * not checked out, or workspace base revision if remote is checked out.
     */
    protected ItemRevision getItemRevision(IDMWorkspaceFile dmFile) throws CoreException {
        IDMRemoteFile remoteFile = dmFile.getRemoteFile();
        if (!checkoutBase && remoteFile != null && !remoteFile.isExtracted()) {
            return remoteFile.getItemRevision();
        }
        return dmFile.getBaseFile().getItemRevision();
    }

    @Override
    public ILabelDecorator getLabelDecorator() {
        return new LabelDecoratorWrapper(super.getLabelDecorator()) {
            @Override
            public String decorateText(String text, Object element) {
                String newText = super.decorateText(text, element);
                if (element instanceof IResource) {
                    IResource resource = (IResource) element;
                    if (resource.getType() == IResource.FILE) {
                        CheckoutRequest request = (CheckoutRequest) getFileRequest((IFile) resource);
                        String revision = (String) request.getBasedOnRevision().getAttribute(SystemAttributes.REVISION);
                        newText += NLS.bind(Messages.CheckoutHelper_4, revision);
                    }
                }
                return newText;
            }
        };
    }

    @Override
    public IResource[] getOperationResources() {
        return getOperationFiles();
    }

}

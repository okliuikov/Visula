/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import org.eclipse.core.runtime.Platform;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.SynchronizePageActionGroup;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMBaseCompareSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.DMCompareSubscriber;
import com.serena.eclipse.dimensions.internal.team.core.ProjectMergeDescriptor;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.actions.ItemHistoryAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Compare participant for 2-way compare with remote project or baseline.
 *
 * @author V.Grishchenko
 */
public class DMCompareParticipant extends DMBaseCompareParticipant {
    /** my id */
    public static final String ID = "com.serena.eclipse.dimensions.team.dmcompare-participant"; //$NON-NLS-1$

    private static final String CONTEXT_MENU_CONTRIBUTION_GROUP = "context_group_1"; //$NON-NLS-1$
    private static final String NON_MODAL_CONTEXT_MENU_CONTRIBUTION_GROUP = "context_group_2"; //$NON-NLS-1$

    private String myName;

    private class CompareParticipantActionContribution extends SynchronizePageActionGroup {
        @Override
        public void initialize(ISynchronizePageConfiguration configuration) {
            super.initialize(configuration);

            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP,
                    new DMCompareReplaceAction(configuration));

            if (!configuration.getSite().isModal()) {
                String historyLabel = "!history action key changed in plugin.properties!"; //$NON-NLS-1$
                try {
                    historyLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "ShowHistory.label"); //$NON-NLS-1$
                } catch (Exception e) {
                }
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, NON_MODAL_CONTEXT_MENU_CONTRIBUTION_GROUP,
                        new DMActionDelegateWrapper(historyLabel, new ItemHistoryAction(), configuration));
            }
        }
    }

    public DMCompareParticipant(DMCompareSubscriber compareSubscriber) {
        super(compareSubscriber);
    }

    @Override
    public String getName() {
        if (myName == null) {
            DMBaseCompareSubscriber subscriber = getCompareSubscriber();
            ProjectMergeDescriptor[] descriptors = subscriber.getDescriptors();
            String[] remotes = new String[descriptors.length];
            for (int i = 0; i < remotes.length; i++) {
                remotes[i] = descriptors[i].getRemote().getId();
            }
            myName = NLS.bind(Messages.DMCompareParticipant_namePattern,
                    new String[] { configElement != null ? configElement.getAttribute("name") : super.getName(), //$NON-NLS-1$
                            Utils.toCsvString(remotes, true), TeamUtils.convertSelection(subscriber.roots()) });

        }
        return myName;
    }

    @Override
    protected String getShortTaskName() {
        return Messages.DMCompareParticipant_shortTask;
    }

    @Override
    protected ISynchronizeParticipantDescriptor getDescriptor() {
        return TeamUI.getSynchronizeManager().getParticipantDescriptor(ID);
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, NON_MODAL_CONTEXT_MENU_CONTRIBUTION_GROUP);
        configuration.addActionContribution(new CompareParticipantActionContribution());
    }

}

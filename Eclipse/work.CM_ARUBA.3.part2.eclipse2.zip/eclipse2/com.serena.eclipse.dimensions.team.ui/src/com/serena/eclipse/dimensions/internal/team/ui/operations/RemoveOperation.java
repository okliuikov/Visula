/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.operations;

import java.util.ArrayList;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IWorkbenchPart;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.team.core.DMRepositoryProvider;
import com.serena.eclipse.dimensions.internal.team.core.DeleteFolderRequest;
import com.serena.eclipse.dimensions.internal.team.core.DeleteItemRevisionRequest;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspaceResourceFilter;
import com.serena.eclipse.dimensions.internal.team.core.OperationData;
import com.serena.eclipse.dimensions.internal.team.core.WorkspaceResourceRequest;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.RemoveHelper;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.RemoveWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizard;
import com.serena.eclipse.dimensions.internal.team.ui.wizards.TeamOperationWizardHelper;

/**
 * @author V.Grishchenko
 */
public class RemoveOperation extends WizardOperation {

    public RemoveOperation(IWorkbenchPart part, IResource[] resources, IDMWorkspaceResourceFilter filter) {
        super(part, resources, filter);
    }

    @Override
    protected void execute(OperationData data, IProgressMonitor monitor) throws CoreException, InterruptedException {
        WorkspaceResourceRequest[] requests = data.getRequestsArray();

        if (requests == null || requests.length == 0) {
            if (monitor != null) {
                monitor.done();
            }
            return;
        }

        ArrayList<WorkspaceResourceRequest> folders = new ArrayList<WorkspaceResourceRequest>();
        ArrayList<WorkspaceResourceRequest> items = new ArrayList<WorkspaceResourceRequest>();
        for (int i = 0; i < requests.length; i++) {
            if (requests[i] instanceof DeleteItemRevisionRequest) {
                items.add(requests[i]);
            }
            if (requests[i] instanceof DeleteFolderRequest && requests[i].getResource().getType() != IResource.PROJECT) {
                folders.add(requests[i]);
            }
        }

        int totalWork = 1000 * (items.size() + folders.size());
        monitor.beginTask(null, totalWork);

        if (!items.isEmpty()) {
            DeleteItemRevisionRequest[] deleteRequests = items.toArray(new DeleteItemRevisionRequest[items.size()]);
            data.getProject().delete(deleteRequests, Utils.subMonitorFor(monitor, 1000 * items.size()));
        }

        if (!folders.isEmpty()) {
            DeleteFolderRequest[] folderRequests = folders.toArray(new DeleteFolderRequest[folders.size()]);
            data.getProject().deleteDirectories(folderRequests, ((RemoveHelper) getHelper()).isDeleteLocal(),
                    Utils.subMonitorFor(monitor, 1000 * folders.size()));
        }

    }

    @Override
    protected TeamOperationWizardHelper createHelper(IProgressMonitor monitor) throws CoreException {
        return new RemoveHelper(getResources(), getFilter(), monitor);
    }

    @Override
    protected TeamOperationWizard createWizard(TeamOperationWizardHelper helper) {
        return new RemoveWizard(helper);
    }

    @Override
    protected String getTaskName(DMRepositoryProvider provider) {
        try {
            return NLS.bind(Messages.RemoveOperation_0, provider.getIdmProject().getId());
        } catch (CoreException e) {
            return NLS.bind(Messages.RemoveOperation_0, provider.getProject().getName());
        }
    }

    @Override
    protected String getTaskName() {
        return Messages.RemoveOperation_1;
    }

}

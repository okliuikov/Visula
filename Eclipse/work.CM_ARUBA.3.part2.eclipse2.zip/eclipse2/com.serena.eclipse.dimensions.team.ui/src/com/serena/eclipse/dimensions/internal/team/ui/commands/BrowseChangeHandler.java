/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.commands;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.HandlerUtil;

import com.serena.dmclient.api.DimensionsChangeStep;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.ItemRevisionAdapter;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.views.ChangeSetHistoryView;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

public class BrowseChangeHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        IWorkbenchSite site = HandlerUtil.getActiveSite(event);
        ISelectionProvider selectionProvider = site.getSelectionProvider();
        TreeSelection selection = (TreeSelection) selectionProvider.getSelection();
        Object selObject = selection.getFirstElement();

        if (!(site instanceof IWorkbenchPartSite)) {
            return null;
        }

        ChangeSetHistoryView view = (ChangeSetHistoryView) ((IWorkbenchPartSite) site).getPart();
        DimensionsChangeStep changeStep = (DimensionsChangeStep) selObject;

        try {
            openRevision(view.getConnection(), changeStep);
        } catch (CoreException e1) {
            DMTeamUiPlugin.getDefault().handle(e1, site.getShell());
        }

        return null;
    }

    private void openRevision(final DimensionsConnectionDetailsEx conn, final DimensionsChangeStep changeStep) throws CoreException {
        final long uid = changeStep.getObjUid();
        final String revision = changeStep.getRevision();

        if (uid == -1 || StringPath.isNullorEmpty(revision)) {
            return;
        }

        final ItemRevisionAdapter[] adapter = new ItemRevisionAdapter[1];
        try {
            PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() { // Communicate busy status
                        @Override
                        public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                final Session session = conn.openSession(monitor);
                                session.run(new ISessionRunnable() {

                                    @Override
                                    @SuppressWarnings("unchecked")
                                    public void run() throws Exception {
                                        Project project = changeStep.getChangeSet().getProject();

                                        Filter filter = new Filter();
                                        filter.criteria().add(
                                                new Filter.Criterion(SystemAttributes.OBJECT_UID, uid, Filter.Criterion.EQUALS));
                                        filter.criteria().add(
                                                new Filter.Criterion(SystemAttributes.REVISION, revision, Filter.Criterion.EQUALS));

                                        ItemRevision itemRevision = null;
                                        List<DimensionsRelatedObject> items = project.getChildItems(filter, project);
                                        if (items == null || items.size() != 1) {
                                            project = session.getObjectFactory().getGlobalProject();
                                            itemRevision = project.createItemRevisionFromUid(uid);
                                        } else {
                                            itemRevision = (ItemRevision) items.get(0).getObject();
                                        }

                                        adapter[0] = new ItemRevisionAdapter(itemRevision, conn);
                                    }
                                }, monitor);

                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });

            IDimensionsObjectEditHandler itemHandler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.ITEM);
            itemHandler.browse(adapter[0]);
        } catch (InterruptedException ignore) {
        } catch (Exception e) {
            DMUIPlugin.getDefault().handle(e);
        }

    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IAdapterFactory;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.synchronize.ISynchronizeModelElement;
import org.eclipse.ui.views.properties.IPropertySource;

import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;

/**
 * Adapt {@link XMLSyncInfo} to the property source
 */
public class XMLSyncInfoAdapterFactory implements IAdapterFactory {

    @Override
    @SuppressWarnings("rawtypes")
    public Object getAdapter(Object adaptableObject, Class adapterType) {
        if (adapterType == IPropertySource.class && adaptableObject instanceof ISynchronizeModelElement) {
            SyncInfo syncInfo = (SyncInfo) ((IAdaptable) adaptableObject).getAdapter(SyncInfo.class);
            if (syncInfo instanceof XMLSyncInfo) {
                return new XMLSyncInfoPropertySource((XMLSyncInfo) syncInfo);
            }
        }
        return null;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public Class[] getAdapterList() {
        return new Class[] { IPropertySource.class };
    }

}

package com.serena.eclipse.dimensions.internal.team.ui.subscriber;

import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Platform;
import org.eclipse.osgi.util.NLS;
import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.internal.ui.TeamUIMessages;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizePageConfiguration;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantDescriptor;
import org.eclipse.team.ui.synchronize.ISynchronizeScope;
import org.eclipse.team.ui.synchronize.SynchronizePageActionGroup;

import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.internal.team.core.CustomSubscriber;
import com.serena.eclipse.dimensions.internal.team.ui.IDMTeamImages;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.team.ui.actions.CleanTimestampsAction;
import com.serena.eclipse.dimensions.internal.team.ui.actions.IgnoreAction;
import com.serena.eclipse.dimensions.internal.team.ui.actions.ItemHistoryAction;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author kberezovchuk
 *
 *         Synchronizes workspace resources with their custom-set remote counterparts
 *
 */
public class DMWorkspaceCustomSynchParticipant extends DMSynchronizeParticipant {

    public static final String ID = "com.serena.eclipse.dimensions.team.dmworkspace-customparticipant"; //$NON-NLS-1$

    private static final String TOOLBAR_CONTRIBUTION_GROUP = "toolbar_group"; //$NON-NLS-1$
    private static final String CONTEXT_MENU_CONTRIBUTION_GROUP_1 = "ctx_group_1"; //$NON-NLS-1$
    private static final String CONTEXT_MENU_CONTRIBUTION_GROUP_2 = "ctx_group_2"; //$NON-NLS-1$
    public static final String CONTEXT_MENU_CONTRIBUTION_GROUP_3 = "ctx_group_3"; //$NON-NLS-1$

    private String nameInfo; // additional participant name information

    private static FastSyncInfoFilter MY_FILTER = new FastSyncInfoFilter() {
        @Override
        public boolean select(SyncInfo info) {
            IResource resource = info.getLocal();
            IProject project = resource.getProject();
            IContainer parent = resource.getParent();
            if (project.equals(parent) && resource.getName().equals(project.getName() + "." + IDMConstants.SCC_ECLIPSE_PROJECT_MARKER)) {
                return false;
            }
            return true;
        }
    };

    private class WorkspaceActionContribution extends SynchronizePageActionGroup {

        @Override
        public void initialize(ISynchronizePageConfiguration configuration) {
            super.initialize(configuration);

            DMWorkspaceUpdateAction updateToolbarAction = new DMWorkspaceUpdateAction(
                    configuration, getVisibleRootsSelectionProvider());
            updateToolbarAction.setPromptBeforeUpdate(true);
            updateToolbarAction.setImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(IDMTeamImages.CHECKOUT_ACTION));
            updateToolbarAction.setDisabledImageDescriptor(DMTeamUiPlugin.getDefault().getImageDescriptor(
                    IDMTeamImages.CHECKOUT_ACTION_D));
            updateToolbarAction.setToolTipText(Messages.DMWorkspaceSynchronizeParticipant_1);

            appendToGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP, updateToolbarAction);

            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1,
                    new DMWorkspaceUpdateAction(configuration));
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1,
                    new DMWorkspaceCommitAction(configuration));

            // override and merge actions
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2,
                    new DMOverrideAndUpdateAction(configuration));
            appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2,
                    new DMConfirmMergedAction(configuration));

            if (!configuration.getSite().isModal()) {
                // use action names from plugin.properties to avoid duplication
                String historyLabel = "!history action key changed in plugin.properties!"; //$NON-NLS-1$
                String ignoreLabel = "!ignore action key changed in plugin.properties!"; //$NON-NLS-1$
                String cleanTsLabel = "!clean timestamps action key changed in plugin.properties"; //$NON-NLS-1$
                try {
                    historyLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "ShowHistory.label"); //$NON-NLS-1$
                    ignoreLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString("Ignore.label"); //$NON-NLS-1$
                    cleanTsLabel = Platform.getResourceBundle(DMTeamUiPlugin.getDefault().getBundle()).getString(
                            "CleanTimestamps.label"); //$NON-NLS-1$
                } catch (Exception e) {
                }
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(historyLabel, new ItemHistoryAction(), configuration));
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(ignoreLabel, new IgnoreAction(), configuration));
                appendToGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3,
                        new DMActionDelegateWrapper(cleanTsLabel, new CleanTimestampsAction(), configuration));
            }
        }
    }

    /**
     * No-arg constructor to be invoked on registry creation
     */
    public DMWorkspaceCustomSynchParticipant() {
    }

    public DMWorkspaceCustomSynchParticipant(ISynchronizeScope scope, Map remoteResourcesMap) {
        super(scope);
        setSubscriber(new CustomSubscriber(scope.getRoots(), remoteResourcesMap));
        setSyncInfoFilter(MY_FILTER);
    }

    @Override
    protected void initializeConfiguration(ISynchronizePageConfiguration configuration) {
        super.initializeConfiguration(configuration);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_TOOLBAR_MENU, TOOLBAR_CONTRIBUTION_GROUP);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_1);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_2);
        configuration.addMenuGroup(ISynchronizePageConfiguration.P_CONTEXT_MENU, CONTEXT_MENU_CONTRIBUTION_GROUP_3);

        configuration.addActionContribution(new WorkspaceActionContribution());
        configuration.setSupportedModes(ISynchronizePageConfiguration.ALL_MODES);
        configuration.setMode(ISynchronizePageConfiguration.BOTH_MODE);
    }

    @Override
    protected ISynchronizeParticipantDescriptor getDescriptor() {
        return TeamUI.getSynchronizeManager().getParticipantDescriptor(ID);
    }

    @Override
    public String getName() {
        String name = super.getShortName();
        return NLS.bind(TeamUIMessages.SubscriberParticipant_namePattern, new String[] { name, nameInfo != null ? nameInfo : "" });
    }

    public void setNameInfo(String nameInfo) {
        this.nameInfo = nameInfo;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.team.ui.subscriber.xml;

import java.io.IOException;

import org.eclipse.compare.CompareUI;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.team.core.TeamException;
import org.eclipse.team.core.synchronize.SyncInfo;
import org.eclipse.team.ui.TeamUI;
import org.eclipse.team.ui.synchronize.ISynchronizeParticipantReference;
import org.eclipse.team.ui.synchronize.SyncInfoCompareInput;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.handlers.HandlerUtil;

import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.core.xml.XMLSyncInfo;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Action revert all modifications from temporary file that were used by content merging
 */
public class DiscardTargetFileAction implements IHandler {

    @Override
    public void addHandlerListener(IHandlerListener handlerListener) {
    }

    @Override
    public void dispose() {
    }

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        IEditorPart activeEditor = HandlerUtil.getActiveEditor(event);
        IEditorInput editorInput = activeEditor.getEditorInput();

        if (editorInput instanceof SyncInfoCompareInput) {
            SyncInfoCompareInput sinput = (SyncInfoCompareInput) editorInput;
            SyncInfo syncInfo = sinput.getSyncInfo();
            if (syncInfo instanceof XMLSyncInfo) {
                XMLSyncInfo xinfo = (XMLSyncInfo) syncInfo;
                boolean result = false;
                if (xinfo.getTempStore() != null) {
                    try {
                        result = TeamUtils.copyResourceToTarget(xinfo.getTempStore(), xinfo.getLocalResource());
                    } catch (IOException e) {
                        DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
                    } catch (CoreException e) {
                        DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
                    }
                }

                if (result) {
                    if (XMLMergeUIUtils.closeMergeCompareEditors(xinfo)) {
                        ISynchronizeParticipantReference[] p = TeamUI.getSynchronizeManager().getSynchronizeParticipants();
                        for (int i = 0; i < p.length; i++) {
                            if (p[i].getId().equals(XMLMergeParticipant.ID)) {
                                try {
                                    CompareUI.openCompareEditor(new SyncInfoCompareInput(p[i].getParticipant(), xinfo), true);
                                } catch (TeamException e) {
                                    DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, e.getMessage()));
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }

        return null;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean isHandled() {
        return true;
    }

    @Override
    public void removeHandlerListener(IHandlerListener handlerListener) {
    }

}

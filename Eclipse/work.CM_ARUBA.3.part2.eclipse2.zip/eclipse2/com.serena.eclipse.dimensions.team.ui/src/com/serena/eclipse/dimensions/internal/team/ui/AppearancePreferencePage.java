/*
 * Copyright SERENA Software,Inc. 1998-2011. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.IntegerFieldEditor;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Appearance preference page.
 *
 */
public class AppearancePreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage, IDMTeamPreferences {

    public AppearancePreferencePage() {
        super(GRID);
        setDescription(Messages.appearancePrefPage_descr);
        setPreferenceStore(DMTeamUiPlugin.getDefault().getPreferenceStore());
    }

    @Override
    protected void createFieldEditors() {

        String[][] saveDirtyEditorsOptions = new String[][] {
                { Messages.appearancePrefPage_saveDirtyNever, SAVE_DIRTY_EDITORS_NEVER },
                { Messages.appearancePrefPage_saveDirtyPrompt, SAVE_DIRTY_EDITORS_PROMPT },
                { Messages.appearancePrefPage_saveDirtyAuto, SAVE_DIRTY_EDITORS_AUTO } };

        addField(new RadioGroupFieldEditor(SAVE_DIRTY_EDITORS, Messages.appearancePrefPage_saveDirtyGroup, 1,
                saveDirtyEditorsOptions, getFieldEditorParent(), true));

        String[][] listDisplayOptions = new String[][] {
                { Messages.appearancePrefPage_projShowInEditor, IDMTeamPreferences.PROJECT_LIST_DISPLAY_EDITOR_VAL },
                { Messages.appearancePrefPage_projShowInView, IDMTeamPreferences.PROJECT_LIST_DISPLAY_VIEW_VAL } };

        addField(new RadioGroupFieldEditor(PROJECT_LIST_DISPLAY, Messages.appearancePrefPage_projShowIn, 1, listDisplayOptions,
                getFieldEditorParent(), true));

        addField(new BooleanFieldEditor(PROJECT_LIST_DISPLAY_MULTIPAGE, Messages.appearancePrefPage_projUseMultipage,
                getFieldEditorParent()));

        addField(new BooleanFieldEditor(PROJECT_DEFAULT_AUTO_DISPLAY, Messages.appearancePrefPage_projAutoDefault,
                getFieldEditorParent()));

        IntegerFieldEditor maxCommentHistoryEditor = new IntegerFieldEditor(MAX_COMMENT_HISTORY_ENTRIES,
                Messages.appearancePrefPage_maxCommentHistory, getFieldEditorParent(), 9);
        addField(maxCommentHistoryEditor);
        maxCommentHistoryEditor.setValidRange(1, Integer.MAX_VALUE);
        maxCommentHistoryEditor.setErrorMessage(Messages.appearancePrefPage_maxCommentErrMsg);

    }

    @Override
    public void init(IWorkbench workbench) {
    }

    @Override
    public boolean performOk() {
        boolean ok = super.performOk();
        DMTeamUiPlugin.getDefault().savePluginPreferences();
        return ok;
    }

}

package com.serena.eclipse.dimensions.internal.team.ui.actions;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.action.IAction;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.browser.IWebBrowser;

import com.serena.dmclient.api.DimensionsConnectionException;
import com.serena.dmclient.api.DimensionsUtils;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 *
 * @author kberezovchuk
 *
 *         FYI: This action is still a prototype
 *
 */
public class DeployPrototypeAction extends DMWorkspaceAction {

    public DeployPrototypeAction() {
    }

    @Override
    protected void execute(IAction action) throws InvocationTargetException, InterruptedException {
        try {
            Object[] elements = getSelection().toArray();
            if (elements.length < 1) {
                return;
            }
            final DimensionsConnectionDetailsEx con = (DimensionsConnectionDetailsEx) elements[0];

            final Session session = con.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    final File redirectHTMLFile = getRedirectToDeployFile(con); // Get 'delete on exit' temp file;
                    try {
                        IWebBrowser extBrowser = PlatformUI.getWorkbench().getBrowserSupport().getExternalBrowser();
                        URL url = redirectHTMLFile.toURI().toURL();
                        extBrowser.openURL(url);
                    } catch (IOException e) {
                        DMTeamUiPlugin.log(new Status(IStatus.ERROR, DMTeamUiPlugin.ID, 0, "Error creating browser input file", e)); //$NON-NLS-1$
                    } finally {
                        Utils.deleteFileWithDelay(redirectHTMLFile);
                    }
                }
            }, null);

        } catch (CoreException e) {
            throw new InvocationTargetException(e);
        }

    }

    @Override
    protected boolean isEnabledForSelection() {
        if (getSelection().size() > 1) {
            return false;
        }
        return true;
    }

    /**
     * Creates redirect HTML file in temporary location
     * @return File to open in browser
     */
    public File getRedirectToDeployFile(DimensionsConnectionDetailsEx con) {
        File redirectHTMLFile = null;

        try {
            redirectHTMLFile = File.createTempFile("depl", ".html"); //$NON-NLS-1$ //$NON-NLS-2$
            redirectHTMLFile.deleteOnExit();

            boolean ret = DimensionsUtils.saveDeploymentEntryPageContents(con.openSession(null).getUnderlyingConnection(),
                    Utils.EMPTY_STRING, Utils.EMPTY_STRING, Utils.EMPTY_STRING, Utils.EMPTY_STRING, Utils.EMPTY_STRING,
                    Utils.EMPTY_STRING, Utils.EMPTY_STRING, Utils.EMPTY_STRING, redirectHTMLFile.getCanonicalPath());
            if (!ret) {
                throw new DimensionsConnectionException("Failed get redirect file");
            }
        } catch (IOException e) {
            DMUIPlugin.getDefault().handle(e, getShell(), "Error", "Temporary file could not be created"); //$NON-NLS-1$ //$NON-NLS-2$
        } catch (DMException e) {
            DMUIPlugin.getDefault().handle(e, getShell(), "Error", "Session is invalid"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        return redirectHTMLFile;
    }

}

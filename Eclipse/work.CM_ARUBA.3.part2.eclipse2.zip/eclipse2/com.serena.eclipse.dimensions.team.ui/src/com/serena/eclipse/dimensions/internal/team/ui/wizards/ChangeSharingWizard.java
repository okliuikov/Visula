/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.operation.IRunnableWithProgress;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.BaselineAdapter;
import com.serena.eclipse.dimensions.core.SccProject;
import com.serena.eclipse.dimensions.core.VersionManagementProject;
import com.serena.eclipse.dimensions.core.WorksetAdapter;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.team.core.DMTeamPlugin;
import com.serena.eclipse.dimensions.internal.team.core.IDMProject;
import com.serena.eclipse.dimensions.internal.team.core.IDMWorkspace;
import com.serena.eclipse.dimensions.internal.team.core.TeamUtils;
import com.serena.eclipse.dimensions.internal.team.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.dialogs.UpdateOnSwitchMessageDialog;
import com.serena.eclipse.dimensions.internal.ui.wizards.DimensionsWizard;
import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * Allows to select a new project, baseline, or scc project and set it
 * as new sharing for a local project.
 * @author V.Grishchenko
 */
public class ChangeSharingWizard extends DimensionsWizard {
    private static final String SELECT_PAGE = "select_page"; //$NON-NLS-1$
    private IDMProject[] currentSharings;
    private IDMProject[] newSharings;
    private ProjectSelectionPage page;

    public ChangeSharingWizard(IDMProject[] currentSharings) {
        Assert.isNotNull(currentSharings);
        Assert.isLegal(currentSharings.length > 0);
        this.currentSharings = currentSharings;
        newSharings = new IDMProject[currentSharings.length];
        setWindowTitle((currentSharings[0].getIsStream() ? Messages.ChangeSharingWizard_00 : Messages.ChangeSharingWizard_0));
        setNeedsProgressMonitor(true);

    }

    /**
     * @return new sharing if wizard finished successfully, returns <code>null</code> otherwise
     */
    public IDMProject getNewSharing() {
        return newSharings[0];
    }

    @Override
    public void addPages() {
        boolean isEclipseProjectAStream = false;
        try {
            isEclipseProjectAStream = TeamUtils.isLocalWorksetAStream(currentSharings[0].getProject()) != null;
        } catch (CoreException e) {
        }
        page = new ProjectSelectionPage(SELECT_PAGE, (isEclipseProjectAStream
                ? Messages.ChangeSharingWizard_10 : Messages.ChangeSharingWizard_1), currentSharings.length > 1
                ? (isEclipseProjectAStream ? Messages.ChangeSharingWizard_20m : Messages.ChangeSharingWizard_2m)
                : (isEclipseProjectAStream ? Messages.ChangeSharingWizard_20 : Messages.ChangeSharingWizard_2), null,
                isEclipseProjectAStream ? true : false, isEclipseProjectAStream ? false : true);
        // need to set default offset/offsets
        if (currentSharings.length == 1) {
            page.setDefaultOffset(currentSharings[0].getRemoteOffset());
        } else if (currentSharings.length > 1) {
            // multiple sharings
            IPath[] offsets = new IPath[currentSharings.length];
            for (int offs = 0; offs < currentSharings.length; offs++) {
                offsets[offs] = currentSharings[offs].getRemoteOffset();
            }
            page.setDefaultOffsets(offsets);
        }

        // all must be from same connection
        page.setConnection(currentSharings[0].getConnection());
        addPage(page);
    }

    @Override
    public boolean performFinish() {
        VersionManagementProject[] selectedSharings = page.getSelection();
        // if nothing selected in wizard either scc or sep get first element null
        if (selectedSharings.length == 0 || selectedSharings[0] == null) {
            return false;
        }
        // if selected is scc - all will be scc if first is
        // then build map of current sharings else for SEP currentMap = null
        Map<IPath, IDMProject> tmpCurrentMap = null;
        if (currentSharings.length > 1) {
            if (selectedSharings[0] instanceof SccProject && currentSharings[0].isSccStyle()) {
                tmpCurrentMap = new HashMap<IPath, IDMProject>();
                for (int mapped = 0; mapped < currentSharings.length; mapped++) {
                    IPath mappedCurrentRemote = currentSharings[mapped].getRemoteOffset();
                    tmpCurrentMap.put(mappedCurrentRemote, currentSharings[mapped]);
                }
            }
        }
        final Map<IPath, IDMProject> currentMap = tmpCurrentMap;

        for (int selShares = 0; selectedSharings != null && selShares < selectedSharings.length; selShares++) {

            final int shareIndex = selShares;
            final VersionManagementProject selectedSharing = selectedSharings[shareIndex];
            final IDMProject[] matchedSharingHolder = new IDMProject[1];
            if (currentMap != null) {
                SccProject sccp = (SccProject) selectedSharing;
                IPath toGet = new Path(sccp.getOffset());
                matchedSharingHolder[0] = currentMap.get(toGet);
            } else {
                matchedSharingHolder[0] = currentSharings[0]; // SEP case
            }
            if (!sharingEquals(matchedSharingHolder[0], selectedSharing)) {
                try {
                    getContainer().run(true, true, new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            IDMWorkspace workspace = DMTeamPlugin.getWorkspace();
                            IProject project = matchedSharingHolder[0].getProject();
                            IPath workAreaPath = matchedSharingHolder[0].getWorkAreaPath();
                            try {
                                newSharings[shareIndex] = workspace.manage(project, null, selectedSharing, workAreaPath)
                                        .getIdmProject();
                                workspace.getSubscriber().refresh(new IResource[] { project }, IResource.DEPTH_INFINITE, monitor);
                            } catch (CoreException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });
                } catch (InvocationTargetException e) {
                    DMTeamUiPlugin.getDefault().handle(e, getShell(), Messages.err_error, Messages.ChangeSharingWizard_3);
                    return false;
                } catch (InterruptedException ignore) {
                    return false;
                }
            } else {
                newSharings[0] = currentSharings[0];
            }
        }
        UpdateOnSwitchMessageDialog messageDialog = new UpdateOnSwitchMessageDialog(getShell());
        messageDialog.open();
        return true;
    }

    private boolean sharingEquals(IDMProject currentSharing, VersionManagementProject newSharing) {
        APIObjectAdapter mainProjectObject;
        if (newSharing instanceof SccProject) {
            SccProject sccProject = (SccProject) newSharing;
            if (currentSharing == null) {
                return false;
            }
            IPath sccpo = new Path(sccProject.getOffset());
            IPath cro = currentSharing.getRemoteOffset();
            if (!currentSharing.isSccStyle() || !sccpo.equals(cro)) {
                return false;
            }
            mainProjectObject = sccProject.getProjectContainer();
        } else {
            mainProjectObject = newSharing;
        }
        return currentSharing.getId().equals(mainProjectObject.getObjectSpec())
                && ((currentSharing.isWorkset() && mainProjectObject instanceof WorksetAdapter) || (currentSharing.isBaseline() && mainProjectObject instanceof BaselineAdapter));
    }

}

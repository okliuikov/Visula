/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.team.ui;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.core.runtime.preferences.DefaultScope;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;

import com.serena.eclipse.dimensions.team.ui.DMTeamUiPlugin;

/**
 * @author V.Grishchenko
 */
public class TeamPreferenceInitializer extends AbstractPreferenceInitializer implements IDMTeamPreferences {

    public TeamPreferenceInitializer() {
    }

    @Override
    public void initializeDefaultPreferences() {
        IEclipsePreferences preferences = DefaultScope.INSTANCE.getNode(DMTeamUiPlugin.ID);

        // general team defaults
        preferences.putBoolean(DELETE_UNMANAGED_ON_REPLACE, true);
        preferences.putBoolean(IGNORE_DERIVED_RESOURCES, true);
        preferences.putBoolean(COMPARE_CONSIDER_CONTENTS, false);
        preferences.putBoolean(AUTO_FIND_ANCESTOR, true);
        preferences.putBoolean(PROJECT_DEFAULT_AUTO_DISPLAY, false);
        preferences.putBoolean(PRESELECT_DEFAULT_REQUESTS, true);
        preferences.put(SAVE_DIRTY_EDITORS, SAVE_DIRTY_EDITORS_PROMPT);

        // decorator defaults
        preferences.putBoolean(DECORATE_DEEP_STATUS_FOLDERS, false);
        preferences.putBoolean(DECORATE_FORCE_DEEP_STATUS_PROJECT, true);
        preferences.putBoolean(DECORATE_REMOTE_INFO_PROJECT, true);
        preferences.putBoolean(DECORATE_BASE_REVISION, true);
        preferences.putBoolean(DECORATE_REMOTE_REVISION, true);
        preferences.putBoolean(DECORATE_LOCALLY_MODIFIED, true);
        preferences.putBoolean(DECORATE_LOCALLY_MODIFIED_TEXT, true);
        preferences.putBoolean(DECORATE_LOCAL_MODE, true);

        // modification settings
        preferences.put(EDIT_MANAGED, EDIT_MANAGED_PROMPT);
        preferences.put(EDIT_CHECKED_OUT, EDIT_CHECKED_OUT_PROMPT);
        preferences.put(EDIT_UNMANAGED, EDIT_MANAGED_PROMPT);

        // project list display
        preferences.put(PROJECT_LIST_DISPLAY, PROJECT_LIST_DISPLAY_EDITOR_VAL);
        preferences.putBoolean(PROJECT_LIST_DISPLAY_MULTIPAGE, false);

        // clean timestamps
        preferences.putBoolean(CLEAN_TIMESTAMPS, false);

        // store 10 comments by default
        preferences.putInt(MAX_COMMENT_HISTORY_ENTRIES, 10);

        // don't show project id on request selection page in commit wizard
        preferences.putBoolean(SHOW_PROJECT_ON_COMMIT, false);

        // use activated requests by default
        preferences.putBoolean(USE_ACTIVATED_REQUESTS, true);

        // don't expand substitution variables by default
        preferences.putBoolean(EXPAND_SUBSTITUTION, false);

        // default to autoShare
        preferences.putBoolean(AUTO_SHARE, true);

        // allow project auto-merge during update
        preferences.putBoolean(PROJECT_ALLOW_UPDATE_AUTO_MEGRE, true);
        preferences.putBoolean(SYNC_ON_SWITCHING_FOREIGN, false);
        // undo checkout on checkin
        preferences.putBoolean(UNDO_COUT_CIN_UNMODIFIED, false);

        // defaults for stream merge dialog
        preferences.putBoolean(STREAM_ALLOW_UPDATE_AUTO_MEGRE, true);
        preferences.putBoolean(MERGE3W_SHOW_INTERACTIVE_SWITCH_PROMPT, true);
        preferences.putBoolean(MERGE3W_SHOW_STALE_RESULTS_WARNING, true);
        preferences.putBoolean(MERGE3W_REFRESH_HOME_RESULTS, false);
        preferences.putBoolean(MERGE3W_DO_INTERACTIVE, true);
        preferences.putBoolean(MERGE3W_SHOW_ADVANCED_OPTIONS, false);
        preferences.putBoolean(MERGE3W_SHOW_NONINTERACTIVE_SUMMARY, true);
        preferences.putBoolean(MERGE3W_APPLY_REPO_DATETIME, false);
        preferences.putBoolean(MERGE3W_ENABLE_LOGGING, false);
        preferences.putBoolean(MERGE3W_CHERRYPICK_CHANGES, true);
        preferences.putBoolean(MERGE3W_REQUEST_INCLUDE_CHILD_REQUEST, true);
        preferences.put(MERGE3W_LOGGING_PATH, "");

    }

}

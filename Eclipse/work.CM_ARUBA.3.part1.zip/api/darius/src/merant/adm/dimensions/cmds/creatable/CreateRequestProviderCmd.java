/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2009 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.PrivilegesCommandConstants;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.withattrs.UpdateAttrsRequestProviderCmd;
import merant.adm.dimensions.cmds.helper.IDMUtilsHelper;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Request Provider Instance.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new Request Provider Instance</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author S.Korniychuk
 * @since 10
 */
public class CreateRequestProviderCmd extends UpdateAttrsRequestProviderCmd {

    public CreateRequestProviderCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_CLASS, true, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        String name = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ID), AdmDmLengths.DM_L_IDM_TOOL_NAME, false);
        String specId = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.CLASS_SPEC), AdmDmLengths.DM_L_IDM_TOOL_SPEC_ID);

        if (!IDMUtilsHelper.validateSpecId(specId)) {
            throw new DimInvalidAttributeException("The tool ID must consist only of alphanumeric characters or underscores.");
        }

        Boolean idmWithCm = (Boolean) getAttrValue(AdmAttrNames.IDM_WITH_CM);
        String parent = (String) getAttrValue(AdmAttrNames.PARENT_CLASS);
        AdmBaseId parent_base = AdmBaseId.fromCloneString(parent);
        long parent_id = 0;
        if (parent_base instanceof AdmUid) {
            parent_id = ((AdmUid) parent_base).getUid();
        }
        if (parent_id <= 0) {
            throw new DimInvalidAttributeException("Error: wrong parent key : " + parent_id);
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege(PrivilegesCommandConstants.ADMIN_IDMTOOLMAN)) {
            throw new DimNoPrivilegeException(PrivilegesCommandConstants.ADMIN_IDMTOOLMAN);
        }

        if (IDMUtilsHelper.INVALID_PROVIDER_TOOL_UID != IDMUtilsHelper.getToolUidBySpecId(specId)) {
            throw new DimInvalidAttributeException("Error: The specified ID (" + specId + ") is already used by another request provider.");
        }

        int nid = 0;
        DBIO query = new DBIO("select pcms_seq.nextval from dual");
        query.readStart(DBIO.DB_DONT_CLOSE);
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            nid = query.getInt(1);
        }
        query.close();

        if (nid > 0) {
            query.resetMessage(wcm_sql.INSERT_EXT_TOOL);
            query.bindInput(nid);
            query.bindInput(parent_id);
            query.bindInput(name);
            query.bindInput("Y");
            query.bindInput(specId);
            query.bindInput((idmWithCm != null && idmWithCm == Boolean.TRUE) ? "Y" : "N");
            query.write();
            query.commit();

            saveAttributes(nid);
            saveCredentials(specId);
        }

        return new AdmResult("Operation completed");
    }
}

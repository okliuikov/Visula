/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015 Serena. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.assignable;

import java.util.List;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class DlgsCmd extends RPCExecCmd {
    public DlgsCmd() throws AttrException {
        super();
        setAlias(Assignable.DLGS);

        // user
        setAttrDef(new CmdArgDef(CmdArguments.USER, true, String.class));
        // workset_list
        setAttrDef(new CmdArgDef(AdmAttrNames.WORKSET_LIST, true, List.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // DLGS /WORKSET_LIST=("PROD:STREAM1", "PROD:STREAM2") /USER=user
        String user = (String)getAttrValue(CmdArguments.USER);

        @SuppressWarnings("unchecked")
        List<String> worksets = (List<String>)getAttrValue(AdmAttrNames.WORKSET_LIST);

        StringBuffer workset_list = new StringBuffer();
        if (worksets != null && worksets.size() > 0) {
            for (int i = 0; i < worksets.size(); i++) {
                String stream = (String)worksets.get(i);
                workset_list.append(Encoding.escapeSpec(stream));
                
                if (i != worksets.size() - 1)
                    workset_list.append(",");
            }
        }

        _cmdStr = String.format("DLGS /WORKSET_LIST=(%s) /USER=%s", workset_list.toString(), Encoding.escapeSpec(user));
        return executeRpc();
    }
}

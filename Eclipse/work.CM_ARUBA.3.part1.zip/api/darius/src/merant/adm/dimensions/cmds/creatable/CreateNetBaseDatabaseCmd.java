/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a NetBaseDatabase System object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new NetBaseDatabase</dd>
 *  <dt>CAP_REPLICATE {Boolean}</dt><dd>Workset replication</dd>
 *  <dt>NETBASEDB_CONTACT {String}</dt><dd>Contact name - ID of NetContact object</dd>
 *  <dt>NETINSTANCE {String}</dt><dd>NetBaseDatabase instance name - ID of NetInstance object</dd>
 *  <dt>NETINSTANCE_NODE {String}</dt><dd>NetInstance node name  - NETINSTANCE_NODE of NetInstance object</dd>
 *  <dt>VERSION {String}</dt><dd>Dimensions version</dd>
 *  <dt>NETBASEDB_ROOT_DIR {String}</dt><dd>Dimensions root directory</dd>
 *  <dt>DESCRIPTION {String}</dt><dd>Describes the NetBaseDatabase</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateNetBaseDatabaseCmd extends RPCExecCmd {
    public CreateNetBaseDatabaseCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.NETINSTANCE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETINSTANCE_NODE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CAP_REPLICATE, true, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETBASEDB_CONTACT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VERSION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETBASEDB_ROOT_DIR, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETBASEDB_SITE_NO, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        String id = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ID), AdmDmLengths.DM_L_DBDATABASE);
        String netInstanceId = StringUtils.adjustValue((String) getAttrValue(CmdArguments.NETINSTANCE), 256);
        String netNodeId = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.NETINSTANCE_NODE), 256);

        boolean capReplicate = ((Boolean) getAttrValue(AdmAttrNames.CAP_REPLICATE)).booleanValue();
        String netContactId = (String) getAttrValue(AdmAttrNames.NETBASEDB_CONTACT);
        String version = (String) getAttrValue(AdmAttrNames.VERSION);
        String rootDir = (String) getAttrValue(AdmAttrNames.NETBASEDB_ROOT_DIR);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String siteNo = (String) getAttrValue(AdmAttrNames.NETBASEDB_SITE_NO);
        String senderId = netNodeId + ":" + id + "@" + netInstanceId;
        setAttrValue(CmdArguments.INT_SPEC, senderId);

        _cmdStr = "CBDB ";
        _cmdStr += " /BDB_NAME=" + Encoding.escapeSpec(id);
        _cmdStr += " /DB_SERVICE=\"" + netInstanceId + "\"";
        _cmdStr += " /NN_NAME=\"" + netNodeId + "\"";
        if (netContactId != null) {
            _cmdStr += " /CO_NAME=\"" + netContactId + "\"";
        }
        _cmdStr += " /PCMS_VER=\"" + version + "\"";
        _cmdStr += " /CAP_REPLICATE=\"";
        if (capReplicate) {
            _cmdStr += "Y\"";
        } else {
            _cmdStr += "N\"";
        }

        if (rootDir != null) {
            _cmdStr += " /PCMS_ROOT_DIR=\"" + rootDir + "\"";
        }

        if (desc != null) {
            _cmdStr += " /DESCRIPTION=\"" + desc + "\"";
        }

        if (siteNo != null) {
            _cmdStr += " /SITE_NO=\"" + siteNo + "\"";
        }

        // See TDR_13866
        // if (senderId != null)
        // _cmdStr += " /SENDERID=\""+senderId+"\"";

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, NetBaseDatabase.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2004 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.UserList;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions User List object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class DeleteUserListCmd extends DBIOCmd {
    public DeleteUserListCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UserList)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        List attrs = AdmHelperCmd.getAttributeValues(admObj,
                Arrays.asList(new Object[] { AdmAttrNames.USER_NAME, AdmAttrNames.ID }));

        final String userName = (String) attrs.get(0);
        final String id = (String) attrs.get(1);

        AdmObject curUserObj = AdmCmd.getCurRootObj(User.class);
        String curUserId = curUserObj.getAdmSpec().getSpec();
        if (!curUserId.equals(userName)) {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_CHANGEMAN")) {
                throw new DimNoPrivilegeException("ADMIN_CHANGEMAN");
            }
        }

        if (!DoesExistHelper.userListExists(userName, id)) {
            throw new AdmException("Error: request list \"" + userName + ":" + id + "\" does not exist.");
        }

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {
                // remove relationships to change document
                dbCtx.resetMessage(wcm_sql.DELETE_USER_LIST_1_WEB);
                dbCtx.bindInput(id);
                dbCtx.bindInput(userName);
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

                // remove user list
                dbCtx.resetMessage(wcm_sql.DELETE_USER_LIST_2_WEB);
                dbCtx.bindInput(id);
                dbCtx.bindInput(userName);
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);
            }
        });

        return "Operation completed";
    }
}
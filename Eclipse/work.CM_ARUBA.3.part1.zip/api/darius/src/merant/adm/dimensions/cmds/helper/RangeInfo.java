package merant.adm.dimensions.cmds.helper;

public class RangeInfo {

    // request portion
    long rowStart;
    long rowCount;

    // response portion
    long totalCount;
    int resultCode;

    public RangeInfo(long rowStart, long rowCount) {
        this.rowStart = rowStart;
        this.rowCount = rowCount;
    }

    public long getRowStart() {
        return rowStart;
    }

    public void setRowStart(long rowStart) {
        this.rowStart = rowStart;
    }

    public long getRowCount() {
        return rowCount;
    }

    public void setRowCount(long rowCount) {
        this.rowCount = rowCount;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

}

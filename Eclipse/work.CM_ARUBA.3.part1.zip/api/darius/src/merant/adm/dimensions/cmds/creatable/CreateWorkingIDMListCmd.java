/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkingIDMList;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create an IDM Activated Request list.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>USER_NAME {String}</dt><dd>Product name used exclusively for role checking</dd>
 *  <dt>ID {String}</dt><dd>Name identifier </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class CreateWorkingIDMListCmd extends DBIOCmd {
    public CreateWorkingIDMListCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        String userName = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.USER_NAME), AdmDmLengths.DM_L_USER);
        String id = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ID), AdmDmLengths.DM_L_USER_LIST_ID, false);

        AdmObject curUserObj = AdmCmd.getCurRootObj(User.class);
        String curUserId = curUserObj.getAdmSpec().getSpec();
        if (!curUserId.equals(userName)) {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_CHANGEMAN")) {
                throw new DimNoPrivilegeException("ADMIN_CHANGEMAN");
            }
        }

        // check whether baseline template already exists
        if (DoesExistHelper.doesIDMActivatedListExist(userName, id)) {
            throw new DimAlreadyExistsException("Error: request list " + userName + ":" + id + " has already been defined.");
        }

        DBIO query = new DBIO(wcm_sql.CREATE_WORKING_IDM_LIST);
        query.bindInput(id); // obj_id
        query.bindInput(userName); // product_id
        query.bindInput(curUserId); // originator
        query.write();
        query.commit();

        setAttrValue(CmdArguments.INT_SPEC, userName + ":" + id);
        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, WorkingIDMList.class);
        return retResult;
    }
}

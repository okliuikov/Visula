/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will set the project filename of a Dimensions object.
 * NOTE: As of 10.1.3 this cmd is only used by dmclient ItemRevisionImpl.setRepositoryPath()
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ID {String}<dt><dd>New wrokset filename for the object.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Project that this item is set in</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of requests to be related</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class SetWorksetFilenameCmd extends RPCExecCmd {
    public SetWorksetFilenameCmd() throws AttrException {
        super();
        setAlias(Creatable.SET_WORKSET_FILENAME);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ItemFile)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        WorkSet project = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);

        _cmdStr = "SWF " + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()) + " /WS_FILENAME=" + Encoding.escapeDMCLI(id);
        if (project != null) {
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec());
        }
        if ((chdocs != null) && (chdocs.length() > 0)) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
        }
        return executeRpc();
    }
}

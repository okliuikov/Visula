/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions user.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Login id of the new Dimensions user</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>EMAIL {String}</dt><dd>E-mail address associated with the user</dd>
 *  <dt>USER_DEF_WSET {WorkSet}</dt><dd>User initial default project</dd>
 *  <dt>USER_SITE {String}</dt><dd>Location or site of new Dimensions user</dd>
 *  <dt>USER_GROUP_ID {String}</dt><dd>Group id of new Dimensions user</dd>
 *  <dt>USER_DEPT {String}</dt><dd>Department of new Dimensions user</dd>
 *  <dt>USER_FULL_NAME {String}</dt><dd>Full user name of new Dimensions user</dd>
 *  <dt>USER_PHONE {String}</dt><dd>Phone number of new Dimensions user</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code> <br>
 * 
 * @author Stephen Sitton, Vadym Krevs, Floz
 */
public class CreateUserCmd extends RPCExecCmd {
    public CreateUserCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EMAIL, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_DEF_WSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_SITE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_GROUP_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_DEPT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_FULL_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_PHONE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_PASSWORD_SAVE, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    /**
     * Public execute function for this class.
     * @return AdmResult encapsulating the result.
     */
    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        int attrSet = 0;

        String userId = (String) getAttrValue(AdmAttrNames.ID);
        String email = (String) getAttrValue(AdmAttrNames.EMAIL);
        WorkSet userProject = (WorkSet) getAttrValue(AdmAttrNames.USER_DEF_WSET);
        String userSite = (String) getAttrValue(AdmAttrNames.USER_SITE);
        String userGroupId = (String) getAttrValue(AdmAttrNames.USER_GROUP_ID);
        String userDept = (String) getAttrValue(AdmAttrNames.USER_DEPT);
        String userFullName = (String) getAttrValue(AdmAttrNames.USER_FULL_NAME);
        String userPhone = (String) getAttrValue(AdmAttrNames.USER_PHONE);
        boolean bPasswordSave = ((Boolean) getAttrValue(AdmAttrNames.USER_PASSWORD_SAVE)).booleanValue();

        setAttrValue(CmdArguments.INT_SPEC, userId);

        _cmdStr = "UREG " + Encoding.escapeDMCLI(userId);

        if (userProject != null) {
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(userProject.getAdmSpec().getSpec());
        }

        if (bPasswordSave) {
            _cmdStr += " /PASSWORD_SAVE ";
        }

        // get the list of user attributes in the following format
        // /ATTRIBUTES=(ATTR1="VALUE1",..,ATTRN="VALUEN")
        boolean hasUserAttrs = false;
        String userAttrs = AttributeDefinition.getAttrsCmdStringFromCmd(this);
        if (userAttrs != null && userAttrs.length() > 0) {
            hasUserAttrs = true;
            _cmdStr += userAttrs;
        }

        if ((email != null && email.length() > 0) || (userSite != null && userSite.length() > 0)
                || (userGroupId != null && userGroupId.length() > 0) || (userDept != null && userDept.length() > 0)
                || (userFullName != null && userFullName.length() > 0) || (userPhone != null && userPhone.length() > 0)) {
            if (hasUserAttrs) {
                // strip away the trailing ")" and append a ','
                _cmdStr = _cmdStr.substring(0, _cmdStr.length() - 1);
                _cmdStr += ",";
            } else {
                _cmdStr += " /ATTRIBUTES=(";
            }

            if (email != null && email.length() > 0) {
                _cmdStr += "EMAIL_ADDR=";
                _cmdStr += Encoding.escapeDMCLI(email);
                attrSet = 1;
            }
            if (userSite != null && userSite.length() > 0) {
                if (attrSet != 0 && !_cmdStr.endsWith(",")) {
                    _cmdStr += ",";
                }
                _cmdStr += "SITE=";
                _cmdStr += Encoding.escapeDMCLI(userSite);
                attrSet = 1;
            }
            if (userGroupId != null && userGroupId.length() > 0) {
                if (attrSet != 0 && !_cmdStr.endsWith(",")) {
                    _cmdStr += ",";
                }
                _cmdStr += "GROUP_ID=";
                _cmdStr += Encoding.escapeDMCLI(userGroupId);
                attrSet = 1;
            }
            if (userDept != null && userDept.length() > 0) {
                if (attrSet != 0 && !_cmdStr.endsWith(",")) {
                    _cmdStr += ",";
                }
                _cmdStr += "DEPT=";
                _cmdStr += Encoding.escapeDMCLI(userDept);
                attrSet = 1;
            }
            if (userFullName != null && userFullName.length() > 0) {
                if (attrSet != 0 && !_cmdStr.endsWith(",")) {
                    _cmdStr += ",";
                }
                _cmdStr += "FULL_NAME=";
                _cmdStr += Encoding.escapeDMCLI(userFullName);
                attrSet = 1;
            }
            if (userPhone != null && userPhone.length() > 0) {
                if (attrSet != 0 && !_cmdStr.endsWith(",")) {
                    _cmdStr += ",";
                }
                _cmdStr += "PHONE=";
                _cmdStr += Encoding.escapeDMCLI(userPhone);
                attrSet = 1;
            }
            _cmdStr += ")";
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, User.class);
        return retResult;
    }
}

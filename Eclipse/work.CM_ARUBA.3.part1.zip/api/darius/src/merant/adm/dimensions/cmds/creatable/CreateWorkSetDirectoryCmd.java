/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import com.serena.dmfile.FilePath;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions work set directory.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PARENT_DIR_NAME {String}<dt><dd>Parent directory name for the new directory</dd>
 *  <dt>ID {String}<dt><dd>dentifier of the new directory</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PROJECT {String}<dt><dd>Project specification in which you want to create the directory</dd>
 *  <dt>USE_SUPER_QUERY {Boolean}<dt><dd>Force the use of SuperQuery</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of requests to be related</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateWorkSetDirectoryCmd extends RPCExecCmd {
    public CreateWorkSetDirectoryCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);

        // XXX TODO FIXME_DVDC: this should eventually be an ADM_OBJECT:
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_DIR_NAME, true, String.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARENT_RELATIVE, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String parentDirName = (String) getAttrValue(AdmAttrNames.PARENT_DIR_NAME);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        boolean isRelative = ((Boolean) getAttrValue(CmdArguments.PARENT_RELATIVE)).booleanValue();
        String project = (String) getAttrValue(AdmAttrNames.PROJECT);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);

        String param;
        if (isRelative) {
            char chSep = FilePath.getDirSep(DimSystem.getSystem().getSessionBean().getServerOs());

            // attempt to check new filename for validity:
            if (id == null || id.length() == 0) {
                throw new DimBaseCmdException("New name not specified");
            }
            if (id.indexOf(Constants.DIRPATH_SEP) != -1 || id.indexOf(chSep) != -1) {
                throw new DimBaseCmdException("New name contains directory separator");
            }

            if (parentDirName == null) {
                parentDirName = "";
            }

            // combine the parent directory name with the rename ID:
            if (parentDirName.length() > 0) {
                while (parentDirName.length() > 0
                        && (parentDirName.charAt(0) == Constants.DIRPATH_SEP || parentDirName.charAt(0) == chSep)) {
                    parentDirName = parentDirName.substring(1, parentDirName.length());
                }
                while (parentDirName.length() > 0
                        && (parentDirName.charAt(parentDirName.length() - 1) == Constants.DIRPATH_SEP || parentDirName.charAt(parentDirName.length() - 1) == chSep)) {
                    parentDirName = parentDirName.substring(0, parentDirName.length() - 1);
                }
            }
            if (parentDirName.length() > 0) {
                param = parentDirName + Constants.DIRPATH_SEP + id;
            } else {
                param = id;
            }
        } else {
            // See also RenameCmd - PARENT_RELATIVE isn't strictly necessary
            if (id != null && id.length() > 0) {
                param = id;
            } else {
                param = "";
            }
        }

        setAttrValue(CmdArguments.INT_SPEC, param); // used to retrieve new object

        param = CmdUtils.relPathForCmd(param);
        _cmdStr = "CWSD " + Encoding.escapeSpec(param);

        if (project != null && project.length() > 0) {
            _cmdStr += " /WORKSET=" + Encoding.escapeSpec(project);
        }

        if ((chdocs != null) && (chdocs.length() > 0)) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, DimDirectory.class);
        return retResult;
    }
}

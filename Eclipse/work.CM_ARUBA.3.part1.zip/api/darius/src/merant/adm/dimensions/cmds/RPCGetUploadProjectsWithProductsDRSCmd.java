/*
 * Copyright (C), 2012, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import com.serena.dmnet.drs.DRSClientUploadProjectQueries;
import com.serena.dmnet.drs.DRSClientUploadProjectQueries.UploadProjectQueryContext;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class RPCGetUploadProjectsWithProductsDRSCmd extends RPCCmd {

    /**
     * Constructor defines the command definition and arguments.
     * 
     * @throws AttrException
     */
    public RPCGetUploadProjectsWithProductsDRSCmd() throws AttrException {
        super();
        setAlias("GetUploadProjectsWithProductsDRS");
        AddArgument("cmd", "GetUploadProjectsWithProductsDRS");
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.EXTENSION, true, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.PRODUCT)) {
            String product = (String) attrValue;
            if (product == null) {
                throw new AttrException("Error: Product name is null", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.EXTENSION)) {
            String extension = (String) attrValue;
            if (extension == null) {
                throw new AttrException("Error: Extension is null", attrDef, attrValue);
            }
            if (!extension.startsWith("$$")) {
                throw new AttrException("Error: Extension is invalid", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException {
        validateAllAttrs();
        String product = (String) getAttrValue(CmdArguments.PRODUCT);
        String extension = (String) getAttrValue(CmdArguments.EXTENSION);
        DRSClientUploadProjectQueries drs = new DRSClientUploadProjectQueries(DRSUtils.getLCNetClntObject(),
                UploadProjectQueryContext.QueryUploadProjectSpecWithProduct);
        drs.setProductName(product);
        drs.setExtension(extension);
        DRSOutputDataExtractor output = new DRSQuery(drs).execute();
        String[] result = new String[0];
        if (!output.isResultEmpty()) {
            result = output.getStringValues(DRSParams.UPLOAD_PROJ_SPEC);
        }
        return result;
    }

}

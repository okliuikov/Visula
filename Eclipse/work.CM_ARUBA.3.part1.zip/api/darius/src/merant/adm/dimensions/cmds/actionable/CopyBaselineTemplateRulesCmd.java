/*
 * Copyright (C) 2001, 2006 Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.actionable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Template;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will copy baseline template rules of an existing Dimensions
 * baseline template to the list of rules currently defined for another existing
 * Dimensions baseline template.
 * <p>
 * Any existing rule definitions will not be overwritten. <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name used exclusively for role checking</dd>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Dimensions baseline template the rules are to be copied from</dd>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions baseline template the rules are to be copied to</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * 
 * @author Vadym Krevs
 */
public class CopyBaselineTemplateRulesCmd extends DBIOCmd {

    public CopyBaselineTemplateRulesCmd() throws AttrException {
        super();
        setAlias(Actionable.COPY_BASELINE_TEMPLATE_RULES);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));

        // this is an internal argument for transcational execution of the
        // command
        // and MUST NOT be used by darius callees
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, false, DBIO.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Template))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if ((!(attrValue instanceof Template))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        // verify "to" template
        AdmObject toTemplateObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String toTemplateId = (String) AdmHelperCmd.getAttributeValue(toTemplateObj, AdmAttrNames.ID);

        if (DoesExistHelper.baselineTemplateIsInUse(toTemplateId)) {
            throw new DimInUseException("Error: Baseline Template " + toTemplateId
                    + " has been used to create baselines - it cannot be modified.");
        }

        if (!DoesExistHelper.baselineTemplateExists(toTemplateId)) {
            throw new DimNotExistsException("Error: Baseline Template " + toTemplateId + " has not been defined.");
        }

        Class toScopeClass = (Class) AdmHelperCmd.getAttributeValue(toTemplateObj, AdmAttrNames.PARENT_CLASS);

        // verify "from" template
        AdmObject fromTemplateObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        String fromTemplateId = (String) AdmHelperCmd.getAttributeValue(fromTemplateObj, AdmAttrNames.ID);

        if (!DoesExistHelper.baselineTemplateExists(fromTemplateId)) {
            throw new DimNotExistsException("Error: Baseline Template " + fromTemplateId + " has not been defined.");
        }

        if (fromTemplateId.equalsIgnoreCase(toTemplateId)) {
            throw new DimBaseCmdException("Error: cannot copy rules from baseline template " + fromTemplateId + " to itself");
        }

        Class fromScopeClass = (Class) AdmHelperCmd.getAttributeValue(fromTemplateObj, AdmAttrNames.PARENT_CLASS);

        if (!toScopeClass.equals(fromScopeClass)) {
            throw new DimInvalidAttributeException("Error: cannot copy rules from item baseline template "
                    + "into a request baseline template and vice versa.");
        }

        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        if (query != null) {
            doCopyTemplateRules(query, fromTemplateId, toTemplateId, toScopeClass);
        } else {
            boolean doCommit = true;
            try {
                query = new DBIO(false);
                doCopyTemplateRules(query, fromTemplateId, toTemplateId, toScopeClass);
            }
            // let's be a bit paranoid
            catch (Exception e) {
                if (query != null) {
                    try {
                        query.rollback();
                    } catch (Exception ex) {
                        Debug.error(ex);
                    }
                    doCommit = false;
                }
                Debug.error(e);
                throw new AdmException(e);
            } finally {
                if (query != null && doCommit) {
                    try {
                        query.commit();
                    } catch (Exception ex) {
                        Debug.error(ex);
                        throw new DimBaseCmdException(ex.toString());
                    }
                }
            }
        }

        return new AdmResult("Operation completed");
    }

    private void doCopyTemplateRules(DBIO query, String fromTemplateId, String toTemplateId, Class scopeClass)
            throws DBIOException, DimBaseException, AdmObjectException {
        if (Item.class.equals(scopeClass)) {
            query.resetMessage(wcm_sql.COPY_ITEM_BASELINE_TEMPLATE_RULES);
            query.bindInput(toTemplateId);
            query.bindInput(fromTemplateId);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        } else {
            query.resetMessage(wcm_sql.COPY_CHDOC_BASELINE_TEMPLATE_RULES);
            query.bindInput(toTemplateId);
            query.bindInput(fromTemplateId);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        }

    }

}
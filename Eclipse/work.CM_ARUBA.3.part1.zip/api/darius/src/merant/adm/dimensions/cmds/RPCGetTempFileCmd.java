/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.File;

import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;

/**
 * Obtains a temporary file location using the Dimensions message server.
 * 
 * @author Peter Raymond
 */
public class RPCGetTempFileCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCGetTempFileCmd() throws AdmObjectException {
        super();
        setAlias("GetTempFile");
    }

    @Override
    public Object execute() throws AdmException {

        try {
            File file = File.createTempFile("dmn", "tmp");
            String fname = file.getPath();
            return Constants.SERVER_OK + fname;

        } catch (Exception e) {
            return Constants.SERVER_FAIL;
        }
    }
}

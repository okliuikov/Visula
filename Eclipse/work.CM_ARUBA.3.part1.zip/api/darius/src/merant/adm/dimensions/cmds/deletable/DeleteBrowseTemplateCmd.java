/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.BrowseTemplate;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Browse Template object.
 * <p>
 * This commans will fail if the template revision to be deleted is assigned to at least one type unless REMOVE is set to true.
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt><dd>If true, automatically deassign the deleted template revision from the associated types.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteBrowseTemplateCmd extends RPCExecCmd {
    public DeleteBrowseTemplateCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof BrowseTemplate)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean force = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        long templateUid = ((AdmUidObject) admObj).getAdmUid().getUid();

        List attrs = AdmHelperCmd.getAttributeValues(
                admObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.REVISION,
                        AdmAttrNames.PARENT_CLASS }));

        String productName = (String) attrs.get(0);
        String templateName = (String) attrs.get(1);
        String revision = (String) attrs.get(2);
        Class typeClass = (Class) attrs.get(3);
        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJTMPL /DELETE ");

        if (templateName == null || templateName.length() == 0) {
            throw new DimInvalidAttributeException("Error: template name is not specified.");
        } else {
            templateName = templateName.trim().toUpperCase();
            cmdBuf.append(Encoding.escapeDMCLI(templateName));
        }

        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));

        if (Item.class.equals(typeClass)) {
            cmdBuf.append(" /OBJ_CLASS=ITEM");
        } else if (ChangeDocument.class.equals(typeClass)){
            cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else {
            throw new DimInvalidAttributeException("Error: unsupported object class");
        }

        if (revision == null || revision.length() == 0) {
            throw new DimInvalidAttributeException("Error: template revision number is not specified.");
        } else {
            revision = revision.trim().toUpperCase();
            cmdBuf.append(" /REVISION=").append(Encoding.escapeDMCLI(revision));
    }

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }
}

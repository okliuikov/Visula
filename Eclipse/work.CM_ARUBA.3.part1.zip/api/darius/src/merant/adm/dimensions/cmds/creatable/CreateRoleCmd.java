/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions role definition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new role</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ROLEDEF_DESC {String}<dt><dd>Description for the new role</dd>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Product name of the new role (pre 8.0 only)</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateRoleCmd extends RPCExecCmd {
    public CreateRoleCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ROLEDEF_DESC, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String desc = (String) getAttrValue(AdmAttrNames.ROLEDEF_DESC);

        if (DoesExistHelper.roleExists(id)) {
            throw new DimBaseCmdException("Role " + id + " already exists!");
        }

        setAttrValue(CmdArguments.INT_SPEC, id);
        _cmdStr = "DUR /ROLE=" + Encoding.escapeSpec(id);

        if ((desc != null) && (desc.length() > 0)) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(desc);
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, RoleDefinition.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ReplOutwardTransfer;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Replication Outward Transfer object and its log details
 * (child ReplOutwardTransferLog objects).
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 * <dt>REMOVE {Boolean}<dt>
 * <dd> Whether to purge ALL transfer records and their logs for the replication configuration that
 * is associated with this Replication Outward Transfer object with the exception of the latest record.
 * Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 * <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteReplOutwardTransferCmd extends DBIOCmd {

    public DeleteReplOutwardTransferCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, ReplOutwardTransfer.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReplOutwardTransfer)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final boolean force = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();
        final long relUid = ((AdmUidObject) admObj).getUid();
        final long logUid = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.REPL_LOG_UID)).longValue();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {

                if (!force) {
                    // delete just this one transfer
                    deleteOneTransferRecord(dbCtx, logUid, relUid);
                } else {
                    // purge all transfers but the last
                    purgeAllButLatestTransferRecords(dbCtx, logUid);
                }
            }
        });

        return "Operation Completed";
    }

    private long getObjSpecUid(DBIO dbCtx, String objectType, long logUid) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_QUERY_OBJ_SPEC_UID);
        dbCtx.bindInput(logUid);
        dbCtx.bindInput(objectType, DBIO.DB_ARG_STRING_LITERAL);
        dbCtx.readStart();
        long objSpecUid = dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getLong(1) : Constants.INVALID_UID;
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return objSpecUid;
    }

    private long getMaxObjUid(DBIO dbCtx, String objectType, long objSpecUid) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_QUERY_MAX_OBJ_UID);
        dbCtx.bindInput(objSpecUid);
        dbCtx.bindInput(objectType, DBIO.DB_ARG_STRING_LITERAL);
        dbCtx.readStart();
        long maxUid = dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getLong(1) : Constants.INVALID_UID;
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return maxUid;
    }

    private void purgeAllButLatestTransferRecords(DBIO dbCtx, long logUid) throws Exception {

        long objSpecUid = getObjSpecUid(dbCtx, "TX", logUid);
        if (objSpecUid == Constants.INVALID_UID) {
            throw new DBIOException("Error: database error encountered.");
        }
        long maxUid = getMaxObjUid(dbCtx, "TX", objSpecUid);
        if (maxUid == Constants.INVALID_UID) {
            throw new DBIOException("Error: database error encountered.");
        }

        dbCtx.resetMessage(wcm_sql.REPL_PURGE_OUTWARD_TRANSFER_1);
        dbCtx.bindInput(objSpecUid);
        dbCtx.bindInput(maxUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_PURGE_OUTWARD_TRANSFER_2);
        dbCtx.bindInput(objSpecUid);
        dbCtx.bindInput(maxUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_PURGE_OUTWARD_TRANSFER_3);
        dbCtx.bindInput(objSpecUid);
        dbCtx.bindInput(maxUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private void deleteOneTransferRecord(DBIO dbCtx, long logUid, long relUid) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_OUTWARD_TRANSFER_1);
        dbCtx.bindInput(relUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_OUTWARD_TRANSFER_2);
        dbCtx.bindInput(relUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_OUTWARD_TRANSFER_3);
        dbCtx.bindInput(relUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_OUTWARD_TRANSFER_4);
        dbCtx.bindInput(logUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }
}

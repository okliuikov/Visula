/*
 * Copyright (C) 2010, Serena Software Europe, Ltd.
 * All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.MultiView;
import merant.adm.dimensions.objects.PersistentReport;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class CreateMultiViewCmd extends DBIOCmd {
    public CreateMultiViewCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DATA, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.IS_PUBLIC, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String isPublic = (((Boolean) getAttrValue(AdmAttrNames.IS_PUBLIC)).booleanValue()) ? "Y" : "N";
        long userUid = ((AdmUidObject) AdmCmd.getCurRootObj(User.class)).getAdmUid().getUid();
        String data = (String) getAttrValue(AdmAttrNames.DATA);

        // validate duplicates (globally if isPublic)
        SuperQuery sq = new SuperQuery();
        sq.setObjectType(MultiView.class);
        sq.addSelect(AdmAttrNames.ADM_UID);
        if (((Boolean) getAttrValue(AdmAttrNames.IS_PUBLIC)).booleanValue()) {
            // Ensure that we have the privilege to create public queries
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_PUBLICQUERIES")) {
                throw new DimNoPrivilegeException("ADMIN_PUBLICQUERIES");
            }
            sq.addWhere(AdmAttrNames.IS_PUBLIC, "Y");
        } else {
            sq.addWhere(AdmAttrNames.IS_PUBLIC, "N");
            sq.addWhere(AdmAttrNames.USER_NAME, AdmCmd.getCurRootObj(User.class).getAdmSpec().toString());
        }

        sq.addWhere(AdmAttrNames.ID, id);
        sq.readStart();
        if (sq.read()) {
            sq.close();
            String message = "Multi view \"" + id + "\" already exists";
            throw new DimBaseCmdException(message);
        }

        sq.close();

        // Write a new row into the table
        DBIO query = new DBIO(wcm_sql.MVIEW_CREATE);
        query.bindInput(id);
        query.bindInput(isPublic);
        query.bindInput(userUid);
        query.bindInput(data);
        query.write();
        query.commit();
        query.close();

        // Query that row for the new uid
        long uid = Constants.INVALID_UID;
        query = new DBIO(wcm_sql.MVIEW_QUERY);
        query.bindInput(id);
        query.bindInput(isPublic);
        query.bindInput(userUid);
        query.readStart();
        if (query.read()) {
            uid = query.getLong(1);
        }

        query.close();
        String message = null;
        if (uid == Constants.INVALID_UID) {
            message = "Failed to create multi view \"" + id + "\"";
            throw new DimBaseCmdException(message);
        }

        // Now define the MultiView to PersistentReport relationships,
        // in the database so that we can efficiently query for them
        // specifically to warn users when attempting to delete those
        // persistent reports participating in a multi-view.
        //
        // Note that this relationship is deliberately not specified
        // within AdmSchema.xml since most references to this relationship
        // should be via AdmAttrNames.MULTIVIEW_VIEWS that in turn is
        // read from the MVML data.
        //
        AdmBaseId mvBaseId = AdmHelperCmd.newAdmBaseId(uid, MultiView.class);
        AdmObject admObj = AdmHelperCmd.getObject(mvBaseId);
        admObj.setAttrValue(AdmAttrNames.DATA, data);
        AdmCmd.getCmd("_internal_mvml", admObj).execute();
        List<AdmObject> views = (List<AdmObject>) admObj.getAttrValue(AdmAttrNames.MULTIVIEW_VIEWS);
        if (views != null) {
            long reportUid = 0;
            for (int i = 0; i < views.size(); i++) {
                admObj = views.get(i);
                if (admObj instanceof PersistentReport) {
                    reportUid = ((PersistentReport) admObj).getUid();
                    String userId = ((AdmUidObject) AdmCmd.getCurRootObj(User.class)).getId();
                    query = SqlUtils.sysobjRelsAdd(uid, reportUid, Constants.RELCLASS_MVIEW_TO_PREPORT, userId);
                    query.write();
                    query.commit();
                    query.close();
                }
            }
        }

        message = "Created multi view \"" + id + "\" successfully";
        return new AdmResult(message, mvBaseId);
    }
}

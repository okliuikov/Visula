/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2004 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.WorkingIDMList;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all External Requests related to the IDM Activated List object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class QCWorkingIDMListToExternalRequestCmd extends QueryRelsCmd {
    public QCWorkingIDMListToExternalRequestCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof WorkingIDMList)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(ExternalRequest.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        StringBuffer orderBy = new StringBuffer();
        orderBy.setLength(0);
        if (filter != null) {
            processOrder(filter, orderBy);
        }
        // unless explicitly sorted by change document id, ensure
        // that the query always orders by change document id descending
        if (orderBy.length() == 0) {
            orderBy.append("ecmc.obj_id DESC");
        }

        String id = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
        String userName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.USER_NAME);

        DBIO query = null;
        List ret = new ArrayList();

        query = new DBIO(wcm_sql.QUERY_WORKING_IDM_LIST);
        query.bindInput(id);
        query.bindInput(userName);
        query.bindInput(orderBy.toString(), DBIO.DB_ARG_STRING_LITERAL); // sort order string

        query.readStart();
        while (query.read()) {
            long chdocUid = query.getLong(1);
            AdmBaseId uidBaseId = AdmHelperCmd.newAdmBaseId(chdocUid, ExternalRequest.class, null, null);
            AdmObject rel = addRelation(ret, relationships, admObj.getAdmBaseId(), uidBaseId);
            if (rel != null) {
                String title = query.getString(4);
                String report_uuid = query.getString(5);
                String item_url = query.getString(6);
                rel.setAttrValue(AdmAttrNames.DESCRIPTION, title);
                rel.setAttrValue(AdmAttrNames.REPORT_UID, report_uuid);
                rel.setAttrValue(AdmAttrNames.ITEM_LOC, item_url);
            }
        }

        return ret;
    }

    private void processOrder(FilterImpl f, StringBuffer orderBy) {
        if (f == null) {
            return;
        }
        Collection orders = f.orders();
        if (orders != null && !orders.isEmpty()) {
            boolean comma = false;
            for (Iterator it = orders.iterator(); it.hasNext();) {
                FilterOrder order = (FilterOrder) it.next();
                if (order == null) {
                    continue;
                }
                String attrName = order.getAttrName();

                if (AdmAttrNames.ID.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("ecmc.obj_id");
                    if ((order.getFlags() & FilterOrder.DESCENDING) != 0) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }

                // order by title
                if (AdmAttrNames.DESCRIPTION.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("LOWER(sra.attr_1)");
                    if ((order.getFlags() & FilterOrder.DESCENDING) != 0) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }

            }
        }
    }
}

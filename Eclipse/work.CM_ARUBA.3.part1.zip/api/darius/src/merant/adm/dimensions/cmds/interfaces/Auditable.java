/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for auditable commands.
 * <p>
 * This applies to any dimensions object that can be created into the system.
 * @author Floz
 */
public interface Auditable {
    public static final String DOES_EXIST = "Auditable.DoesExist";
    public static final String GET_NEW_UID = "Auditable.GetNewUid";
    public static final String GET_NEW_ATTRNO = "Auditable.GetNewAttributeNumber";
    public static final String GET_HISTORY = "Auditable.GetHistory";
    public static final String HAS_ANY_ROLE = "Auditable.HasAnyRole";
    public static final String HAS_ROLE = "Auditable.HasRole";
    public static final String HAS_PROFILE = "Auditable.HasProfile";
    public static final String IS_PENDING = "Auditable.IsPending";
    public static final String IS_TOOL_MANAGER = "Auditable.IsToolManager";
    public static final String QUERY_NEW_REV = "Auditable.QueryNewRev";
    public static final String USER_REPORT = "Auditable.UserReport";
    public static final String GET_LASTATTR_UPDATE = "Auditable.GetLastAttrUpdate";
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;



import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.Format;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions data format.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new data format</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}<dt><dd>Description for the new data format</dd>
 *  <dt>FORMAT_TYPE {String}<dt><dd>Data format file type. Valid values: ASCII, BINARY, VMS, MAC, WINDOWS</dd>
 *  <dt>MIME_TYPE {String}<dt><dd>Multipurpose Internet Mail Extension type</dd>
 *  <dt>UPDATE {Boolean}<dt><dd>Whether the data format is being altered</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateFormatCmd extends RPCExecCmd {
    public CreateFormatCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.FORMAT_TYPE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.FORMAT_COMPRESSION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.FORMAT_COMPRESSION_DELTA, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.MIME_TYPE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        String id = ValidationHelper.validateFormatId((String) getAttrValue(AdmAttrNames.ID));
        String desc = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));

        String formatType = (String) getAttrValue(AdmAttrNames.FORMAT_TYPE);
        String compressionLevel = ((String) getAttrValue(AdmAttrNames.FORMAT_COMPRESSION));
        String deltaCompressionStatus = ((String) getAttrValue(AdmAttrNames.FORMAT_COMPRESSION_DELTA));
        String mimeType = (String) getAttrValue(AdmAttrNames.MIME_TYPE);
        boolean update = ((Boolean) getAttrValue(CmdArguments.UPDATE)).booleanValue();

        setAttrValue(CmdArguments.INT_SPEC, id);

        // convert zero-length arguments to nulls
        if (desc != null && desc.length() == 0) {
            desc = null;
        }
        if (formatType != null && formatType.length() == 0) {
            formatType = null;
        }
        if (mimeType != null && mimeType.length() == 0) {
            mimeType = null;
        }

        if (compressionLevel != null) {
            if (compressionLevel.length() != 1 || "0123456789".indexOf(compressionLevel) == -1) {
                compressionLevel = null;
            }
        }

        if (deltaCompressionStatus != null) {
            if (deltaCompressionStatus.length() != 1 || "01".indexOf(deltaCompressionStatus) == -1) {
                deltaCompressionStatus = null;
            }
        }

        // make sure that at least some format attributes are specified;
        // otherwise DDF might just list all registered data formats
        if ((desc == null) && (formatType == null) && (mimeType == null)) {
            throw new DimInvalidAttributeException("Error: missing format attributes");
        }

        // map format type into data format class number
        if (formatType != null) {
            formatType = StringUtils.mapDataFormatName2Class(formatType);
            if (formatType == null) {
                throw new DimInvalidAttributeException("Error: invalid format type");
            }
        }

        // form data format definition command
        if (update) {
            _cmdStr = "SDF ";
        } else {
            _cmdStr = "DDF ";
        }
        _cmdStr += Encoding.escapeSpec(id);
        if (desc != null) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(desc);
        }
        if (mimeType != null) {
            _cmdStr += " /MIME=" + Encoding.escapeSpec(mimeType);
        }
        if (formatType != null) {
            _cmdStr += " /CLASS=" + Encoding.escapeSpec(formatType);
        }

        if (compressionLevel != null) {
            _cmdStr += " /COMPRESSION_LEVEL=" + compressionLevel;
        }

        if (deltaCompressionStatus != null) {
            int status = Integer.valueOf(deltaCompressionStatus).intValue();
            if (status == 0) {
                _cmdStr += " /NOUSE_DELTA_COMPRESSION";
            }
            if (status == 1) {
                _cmdStr += " /USE_DELTA_COMPRESSION";
            }
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Format.class);
        return retResult;
    }

}

/*
 * Copyright (C), 2011, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command gets HTML page for opening RM Project/Requirement/...
 */

public class RPCGetRtmViewEntryPageCmd extends RPCCmd {
    public RPCGetRtmViewEntryPageCmd() throws AttrException {
        super();
        setAlias("GetRtmViewEntryPage");
        setAttrDef(new CmdArgDef("objuid", true, Integer.class));
        setAttrDef(new CmdArgDef("flg", true, Integer.class));
        setAttrDef(new CmdArgDef("fname", true, String.class));
    }

    @Override
    public Object execute() throws AdmException {
        try {
            int objuid = (Integer) getAttrValue("objuid");
            int flg = (Integer) getAttrValue("flg");
            String fname = (String) getAttrValue("fname");
            return getSession().getConnection().rpcGetRTMViewEntryPage(objuid, flg, fname);
        } catch (IOException e) {
            throw new AdmException(e);
        }
    }
}

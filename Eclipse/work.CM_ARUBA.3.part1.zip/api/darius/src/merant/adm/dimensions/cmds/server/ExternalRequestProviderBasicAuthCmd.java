/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  (Micro Focus) are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will authorize user to access to external request provider,
 * with basic authorization, by providers's tool id.
 * <p>
 * <b>Mandatory Arguments:</b>
 * <code><dl>
 * <dt>USER_NAME {String}<dt><dd>The user name for external request provider</dd>
 * <dt>USER_PASSWORD {String}<dt><dd>The user password for external request provider</dd>
 * <dt>ADM_BASE_ID {String}<dt><dd>The external request provider tool id</dd>
 * </dl></code>
 * <br>
 * <b>Returns:</b>
 * <code><dl>
 * <dt>{String}<dt><dd>Dimensions operation completion statement as string</dd>
 * </dl></code>
 */
public class ExternalRequestProviderBasicAuthCmd extends RPCExecCmd {

    public ExternalRequestProviderBasicAuthCmd() throws AttrException {
        super();
        setAlias(Server.EXTERNAL_REQUEST_PROVIDER_BASIC_AUTH);
        setAttrDef(new CmdArgDef(CmdArguments.USER_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_PASSWORD, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_BASE_ID, true, String.class));
    }

    @Override
    public Object execute() throws AdmException {
        validateAllAttrs();
        String user = (String) getAttrValue(CmdArguments.USER_NAME);
        String password = (String) getAttrValue(CmdArguments.USER_PASSWORD);
        String idmToolId = (String) getAttrValue(CmdArguments.ADM_BASE_ID);
        _cmdStr = "AUTH /user=";
        _cmdStr += Encoding.escapeSpec(user);
        _cmdStr += " /password=";
        _cmdStr += Encoding.escapeSpec(password);
        _cmdStr += " /idm_tool=";
        _cmdStr += Encoding.escapeSpec(idmToolId);
        return executeRpc();
    }
}

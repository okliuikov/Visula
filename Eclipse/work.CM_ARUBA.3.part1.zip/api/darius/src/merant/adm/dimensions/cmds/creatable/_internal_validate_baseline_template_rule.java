/*
 * Copyright (C) 2002, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimInvalidLcStateException;
import merant.adm.dimensions.exception.DimInvalidRuleException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to validate a baseline template rule.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>TEMPLATE_ID {String}</dt><dd>Baseline Template name of the parent for the new rule</dd>
 *  <dt>ID {String}</dt><dd>Item or request type name identifier</dd>
 *  <dt>BLINETR_MINSTATUS {String}</dt><dd>Minimum status of the new baseline template</dd>
 * </dl></code><br>
 * <b>Optional Arguments: </b> <code><dl>
 *  <dt>PARENT_CLASS {Class}</dt><dd>Inidicates whether the rule is for an item or request template</dd>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name used for type scoping</dd>
 *  <dt>BLINETR_BLINE_CODE_OBJ {AdmObject}</dt><dd>Baseline code object(Additional rule state selector)</dd>
 *  <dt>UPDATE {Boolean}</dt><dd>Whether to validate for creation or update</dd>
 * </dl></code><br>
 * <br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * 
 * @author Vadym Krevs
 */

public class _internal_validate_baseline_template_rule extends DBIOCmd {

    public _internal_validate_baseline_template_rule() throws AttrException {
        super();
        setAlias("_internal_validate_baseline_template_rule");
        setAttrDef(new CmdArgDef(AdmAttrNames.TEMPLATE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BLINETR_MINSTATUS, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BLINETR_BLINE_CODE_OBJ, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_CLASS, false, Item.class, Class.class));
    }

    public static final String TYPE_STATUS = "typestatus";

    public static final String TYPE_STAGE = "typestage";

    public static final String TYPE_EMPTY = "typeempty";

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        String productId = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String templateId = (String) getAttrValue(AdmAttrNames.TEMPLATE_ID);
        String itemTypeId = (String) getAttrValue(AdmAttrNames.ID);
        String minStatus = (String) getAttrValue(AdmAttrNames.BLINETR_MINSTATUS);
        AdmObject ruleStateSelector = (AdmObject) getAttrValue(AdmAttrNames.BLINETR_BLINE_CODE_OBJ);
        Class scopeClass = (Class) getAttrValue(AdmAttrNames.PARENT_CLASS);

        if (DoesExistHelper.baselineTemplateIsInUse(templateId)) {
            throw new DimInUseException("Error: Baseline Template " + templateId
                    + " has been used to create baselines - it cannot be modified.");
        }

        if (!DoesExistHelper.baselineTemplateExists(templateId)) {
            throw new DimNotExistsException("Error: Baseline Template " + templateId + " has not been defined.");
        }

        boolean flag = validateRule(productId, templateId, itemTypeId, minStatus, ruleStateSelector, scopeClass);

        return (flag ? Boolean.TRUE : Boolean.FALSE);
    }

    private boolean validateRule(String productId, String templateId, String typeName, String minStatus,
            AdmObject ruleStateSelector, Class scopeClass) throws AdmException {
        boolean updatingRule = ((Boolean) getAttrValue(CmdArguments.UPDATE)).booleanValue();

        String ruleType;
        // validate item type
        if (!updatingRule && productId == null) {
            throw new DimInvalidAttributeException("Error: you must specify a product when creating a baseline template rule.");
        }

        if (!updatingRule && !isValidType(productId, typeName, scopeClass)) {
            throw new DimNotExistsException("Error: A valid " + TypeUtils.getClassName(scopeClass) + " type must be specified.");
        }

        // Find out if the rule already exists
        boolean ruleExists = templateRuleExists(templateId, typeName, scopeClass);

        if (ruleExists && !updatingRule) {
            throw new DimAlreadyExistsException("Error: Baseline Template Rule " + templateId + ":" + typeName
                    + " has already been defined.");
        }

        if (!ruleExists && updatingRule) {
            throw new DimNotExistsException("Error: Baseline Template Rule " + templateId + ":" + typeName
                    + " has not been defined.");
        }

        // Find out if the ruleStateSelector is for states or stages
        ruleType = getRuleType(ruleStateSelector);

        if (ruleType == TYPE_STATUS) {
            // validate lifecycle status - it must either be a normal state (if
            // the item tupe has a lifecycle)
            // or one of Constants.BLINETR_MINSTATUS* constants ('*ALL',
            // '*BUILT', '*HIGHEST', '*FINAL', '*MADE_OF', '*LATEST')
            boolean isValidNormalStatus = isValidLifecycleStatus(minStatus, typeName, TypeUtils.getTypeFlag(scopeClass), true);

            if (!isValidNormalStatus) {
                throw new DimInvalidLcStateException(
                        "Error: If a status selector related to status is selected, a valid lifecycle status must be specified.");
            }

            // /* Check translation */
            if (Item.class.equals(scopeClass)) {
                if (!isValidNormalStatus && !isValidStatusRule(minStatus)) {
                    throw new DimInvalidRuleException("Error: " + minStatus + " is an invalid status definition.");
                }
            }
            return isValidNormalStatus;
        } else if (ruleType == TYPE_EMPTY) {
            if (!isValidStatusRule(minStatus)) {
                throw new DimInvalidRuleException(
                        "Error: If no status selector is selected, a status beginning with * must be specified.");
            }
            return true;
        } else {
            if (ChangeDocument.class.equals(scopeClass)) {
                throw new DimInvalidRuleException(
                        "Error: only EQS and SUP status selectors can be used with request baseline template rules.");
            }
            // check if the minStatus is a valid Stage.
            if (!isValidStage(minStatus)) {
                throw new DimInvalidRuleException(
                        "Error: If a status selector related to stages is selected, a valid stage must be specified.");
            }
            return true;
        }
    }

    private boolean templateRuleExists(String templateId, String id, Class scopeClass) throws AdmException {
        DBIO query = new DBIO(wcm_sql.BLINETR_EXISTS);
        query.bindInput(templateId);
        query.bindInput(id);
        query.bindInput(TypeUtils.getTypeFlag(scopeClass));
        query.readStart();

        boolean ruleExists = query.read();

        query.close();

        return ruleExists;

    }

    public boolean isValidType(String productId, String typeName, Class scopeClass) throws AdmException {
        if (productId == null || typeName == null) {
            return false;
        }

        DBIO query = new DBIO(wcm_sql.BLINETR_VALIDATE_IT_WITHSTAR);
        query.bindInput(productId);
        query.bindInput(typeName);
        query.bindInput(TypeUtils.getTypeFlag(scopeClass));
        query.readStart();
        boolean isValidType = query.read();
        query.close();

        return isValidType;
    }

    public boolean isValidStatusRule(String status) {
        return (Constants.BLINETR_MINSTATUS_ALL.equals(status) || Constants.BLINETR_MINSTATUS_BUILT.equals(status)
                || Constants.BLINETR_MINSTATUS_FINAL.equals(status) || Constants.BLINETR_MINSTATUS_HIGHEST.equals(status)
                || Constants.BLINETR_MINSTATUS_LATEST.equals(status) || Constants.BLINETR_MINSTATUS_MADE_OF.equals(status));
    }

    public boolean isValidStatus(String itemTypeId, String status) throws AdmException {
        if (itemTypeId == null || status == null) {
            return false;
        }

        return isValidStatusRule(status) || isValidLifecycleStatus(status, itemTypeId, "I", true);
    }

    public boolean isValidLifecycleStatus(String status, String itemTypeId, String typeFlag, boolean normal) throws AdmException {
        if (status == null || itemTypeId == null || typeFlag == null) {
            return false;
        }

        int message = 0;
        if (normal) {
            message = wcm_sql.BLINETR_VALIDATE_NORMAL_LC;
        } else {
            message = wcm_sql.BLINETR_VALIDATE_LC;
        }

        DBIO query = new DBIO(message);
        query.bindInput(itemTypeId);
        query.bindInput(typeFlag);
        query.bindInput(status);
        query.readStart();
        boolean isValidStatus = query.read();
        query.close();
        return isValidStatus;
    }

    public boolean isValidStatusSelector(AdmObject ruleStateSelector) throws AdmException {
        if (ruleStateSelector == null) {
            return false;
        }
        String code = ruleStateSelector.getId();
        DBIO query = new DBIO(wcm_sql.BLINETR_VALIDATE_BC);
        query.bindInput(code);
        query.readStart();
        boolean isValidBlnCode = query.read();
        query.close();

        return isValidBlnCode;
    }

    public boolean isValidStage(String stageName) throws AdmException {
        if (stageName == "") {
            return false;
        }
        DBIO query = new DBIO(wcm_sql.STAGE_EXISTS);
        query.bindInput(stageName);
        query.readStart();
        boolean bIsValidStage = query.read();
        query.close();

        return bIsValidStage;
    }

    public String getRuleType(AdmObject ruleStateSelector) throws AdmException {
        if (ruleStateSelector == null || ruleStateSelector.getId().equals("")) {
            return TYPE_EMPTY;
        } else if (ruleStateSelector.getId().equals("EQB") || ruleStateSelector.getId().equals("BUP")) {
            return TYPE_STAGE;
        } else {
            return TYPE_STATUS;
        }
    }
}
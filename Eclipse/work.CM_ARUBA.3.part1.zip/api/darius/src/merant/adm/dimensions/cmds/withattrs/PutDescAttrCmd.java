/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.withattrs;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will update an objects description attribute.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.DESCRIPTION {String}<dt><dd>Description of object to update</dd>
 *  <dt>CmdArguments.DESCRIPTION {String}<dt><dd>Description variable</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class PutDescAttrCmd extends RPCExecCmd {
    public PutDescAttrCmd() throws AttrException {
        super();
        setAlias("PutDescAttrCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DESCRIPTION, true, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String descVar = (String) getAttrValue(CmdArguments.DESCRIPTION);

        if (admObj instanceof ChangeDocument) {
            _cmdStr = "UC ";
        }

        _cmdStr += Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());
        _cmdStr += " /ATTRIBUTES=(" + Encoding.escapeDMCLI(descVar) + "=" + Encoding.escapeDMCLI(desc) + ")";
        return executeRpc();
    }
}

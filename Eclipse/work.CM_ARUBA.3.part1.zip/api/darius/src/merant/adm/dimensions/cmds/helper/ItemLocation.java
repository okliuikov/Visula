/*
 * Copyright (C), 2007, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds.helper;

import merant.adm.dimensions.objects.Item;

// a class to encapsulate the contents of the /user_itemlist parameter
// to the download command
public class ItemLocation {
    private Item rev;
    private String loc;

    public ItemLocation() {
    }

    public ItemLocation(Item rev, String loc) {
        this.rev = rev;
        this.loc = loc;
    }

    public Item getItem() {
        return rev;
    }

    public void setItem(Item rev) {
        this.rev = rev;
    }

    public String getLocation() {
        return loc;
    }

    public void setLocation(String loc) {
        this.loc = loc;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.lang.reflect.Method;
import java.util.List;

import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.FrameworkBaseException;

/**
 * Provides debug for every AdmCmd executed.
 * <p>
 * Activate by specifying log.cmds=true in Dimensions.properties. Use log.cmds.inc=&lt;, sep list of Cmd aliases&gt; to inclusively
 * select Cmd's to wrap. Use log.cmds.exc=&lt;, sep list of Cmd aliases&gt; to exclusively select Cmd's not to wrap. Works by
 * wrapping the requested Cmd (obtained via AdmCmd.getCmd(...)). IMPORTANT NOTE: Any implementation of a Cmd which uses 'instanceof'
 * for self discovery - must take AdmDebugCmd into account. E.g. if ((cmd instanceof QueryChildrenCmd) || ((cmd instanceof
 * AdmDebugCmd) && (((AdmDebugCmd)cmd).getNestedCmd() instanceof QueryChildrenCmd)))
 * 
 * @author Floz
 */
public class AdmDebugCmd extends AdmCmd {
    // As I cannot resolve the circular dependency here,
    // Am going to get the class at runtime and as this
    // is slow - hold it as a static member variable.
    private static Class _admUidObjectImplClass = null;

    private static Class getAdmUidObjectImplClass() {
        if (_admUidObjectImplClass != null) {
            return _admUidObjectImplClass;
        }

        try {
            _admUidObjectImplClass = Class.forName("merant.adm.dimensions.objects.AdmUidObjectImpl");
        } catch (Exception e) {
            Debug.error(e);
        }

        return _admUidObjectImplClass;
    }

    public AdmDebugCmd(Cmd cmd) throws AdmObjectException, AttrException {
        setAlias(cmd.getAlias());
        if (cmd != null) {
            setNestedCmd(cmd);
            List<AttrDef> attrDefs = cmd.getAllAttrDefs();
            if (attrDefs != null) {
                AttrDef attrDef = null;
                for (int i = 0; i < attrDefs.size(); i++) {
                    attrDef = attrDefs.get(i);
                    if (attrDef != null) {
                        setAttrDef(attrDef);
                    }
                }
            }
        }
    }

    @Override
    public Object execute() throws FrameworkBaseException, AdmException {
        Object ret = null;
        if (getNestedCmd() == null) {
            Debug.println("Floz: AdmDebugCmd.execute() - getNestedCmd() == null!");
            throw new DimBaseCmdException("Error: Unspecified nested command!");
        }

        // Print out callstack - if there's another way
        // of doing this without throwing an exception,
        // please update this to use it. Ta!
        try {
            if (1 == 1) {
                throw new Exception("AdmDebugCmd: Call Stack (please ignore this exception)");
            }
        } catch (Exception e) {
            Debug.error(e);
        }

        Debug.println("AdmDebugCmd: execute [" + getNestedCmd().getClass().getName() + "]");

        List attrDefs = getNestedCmd().getAllAttrDefs();
        if (attrDefs != null) {
            AttrDef attrDef = null;
            Object attrValue = null;
            for (int i = 0; i < attrDefs.size(); i++) {
                attrDef = (AttrDef) attrDefs.get(i);
                if (attrDef != null) {
                    attrValue = getAttrValue(attrDef.getName());
                    getNestedCmd().setAttrValue(attrDef.getName(), attrValue);
                    if (attrValue == null) {
                        Debug.println("            argument [" + attrDef.getName() + "=null]");
                    } else {
                        // To stop recursion we output the
                        // uid if this is all we have got
                        if (!getAdmUidObjectImplClass().isInstance(attrValue)) {
                            Debug.println("            argument [" + attrDef.getName() + "=" + attrValue + "]{"
                                    + attrValue.getClass().getName() + "}");
                        } else {
                            try {
                                Method rawMethod = getAdmUidObjectImplClass().getMethod("getAdmSpecRaw", (Class[]) null);
                                Object admSpec = rawMethod.invoke(attrValue, (Object[]) null);
                                if (admSpec != null) {
                                    Debug.println("            argument [" + attrDef.getName() + "=" + attrValue + "]{"
                                            + attrValue.getClass().getName() + "}");
                                } else {
                                    rawMethod = getAdmUidObjectImplClass().getMethod("getAdmUidRaw", (Class[]) null);
                                    Debug.println("            argument [" + attrDef.getName() + "="
                                            + rawMethod.invoke(attrValue, (Object[]) null) + "]{" + attrValue.getClass().getName()
                                            + "}");
                                }
                            } catch (Exception e) {
                                Debug.error(e);
                                throw new AdmException(e);
                            }
                        }
                    }
                }
            }
        }

        ret = getNestedCmd().execute();

        if (ret == null) {
            Debug.println("              result [null]");
        } else {
            Debug.println("              result [" + ret + "]{" + ret.getClass().getName() + "}");
        }

        return ret;
    }

    private Cmd _nestedCmd = null;

    protected void setNestedCmd(Cmd nestedCmd) {
        _nestedCmd = nestedCmd;
    }

    public Cmd getNestedCmd() {
        return _nestedCmd;
    }
}

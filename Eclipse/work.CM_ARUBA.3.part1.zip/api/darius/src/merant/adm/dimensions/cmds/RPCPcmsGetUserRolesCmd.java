/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.List;

import com.serena.dmnet.PcmsUserRoleInfo;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Returns either candidate users against a role
 * or users that hold a role.
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>assigntype {String}</dt>
 *      <dd>
 *          filter - '*' for all(no filter), otherwise...<br>
 *              'N' for 'Delegated'<br>
 *              'O' for 'Assigned'<br>
 *              'P' for 'Propagated'<br>
 *              'Y' for 'From Tree'
 *      </dd>
 *  <dt>candidate {String}</dt>
 *      <dd>
 *          'Y' to return candidate users against the specified role
 *          otherwise 'N' ro return users holding the specified role
 *      </dd>
 *  <dt>capability {String}</dt>
 *      <dd>
 *          filter - '*' for all(no filter),
 *          otherwise 'S', 'L' or 'P'
 *      </dd>
 *  <dt>objclass {String}</dt><dd>eg 'I' for item, 'P' for part etc</dd>
 *  <dt>objuid {String}</dt><dd>object uid</dd>
 *  <dt>role {String}</dt><dd>role definition name</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>[user name][/007][assigntype][/007][capability][/007]...</dd>
 * </dl></code>
 * @author Floz
 */
public class RPCPcmsGetUserRolesCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCPcmsGetUserRolesCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("PcmsGetUserRoles");
        AddArgument("cmd", "PcmsGetUserRoles");
        setAttrDef(new CmdArgDef("assigntype", true, "", "", ""));
        setAttrDef(new CmdArgDef("capability", true, "", "", ""));
        setAttrDef(new CmdArgDef("candidate", true, "", "", ""));
        setAttrDef(new CmdArgDef("nowset", false, "", "", ""));
        setAttrDef(new CmdArgDef("objclass", true, "", "", ""));
        setAttrDef(new CmdArgDef("objuid", true, "0", "", ""));
        setAttrDef(new CmdArgDef("partuid", false, "0", "", ""));
        setAttrDef(new CmdArgDef("role", true, "", "", ""));
        setAttrDef(new CmdArgDef("user", false, "", "", ""));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            String assignTypeFilter = (String) getAttrValue("assigntype");
            String capabilityFilter = (String) getAttrValue("capability");
            String candidateStr = (String) getAttrValue("candidate");
            String noWsetStr = (String) getAttrValue("nowset");
            String objTypeStr = (String) getAttrValue("objclass");
            String roleStr = (String) getAttrValue("role");
            String userStr = (String) getAttrValue("user");

            int options = 0;
            if ("Y".equals(candidateStr)) {
                options |= Constants.PCMS_OPT_DLG_CANDIDATES;
            }
            if ("Y".equals(noWsetStr)) {
                options |= Constants.PCMS_OPT_NOWSET;
            }

            int objType = Constants.PART_CLASS;
            if ("B".equals(objTypeStr)) {
                objType = Constants.BASELINE_CLASS;
            } else if ("C".equals(objTypeStr)) {
                objType = Constants.CHDOC_CLASS;
            } else if ("I".equals(objTypeStr)) {
                objType = Constants.ITEM_CLASS;
            } else if ("P".equals(objTypeStr)) {
                objType = Constants.PART_CLASS;
            } else if ("W".equals(objTypeStr)) {
                objType = Constants.WORKSET_CLASS;
            }

            long objUid = Long.parseLong((String) getAttrValue("objuid"));
            long partUid = Long.parseLong((String) getAttrValue("partuid"));

            String[] roles = new String[] { roleStr };

            List<PcmsUserRoleInfo> uris = getSession().getConnection().rpcPcmsGetUserRolesEx(options, objType, objUid, partUid,
                    roles, userStr, assignTypeFilter, capabilityFilter);

            return uris;

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }

}
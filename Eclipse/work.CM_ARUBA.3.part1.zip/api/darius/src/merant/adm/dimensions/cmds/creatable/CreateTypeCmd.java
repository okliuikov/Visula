/*
 * %HEADER%
 * Copyright (C) 2004, Merant. All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.ObjectTypeOptions;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions type.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT_CLASS {Class}<dt><dd>Type class for the new type</dd>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Product name of the new type</dd>
 *  <dt>ID {String}<dt><dd>Identifier of the new type</dd>
 *  <dt>DESCRIPTION {String}<dt><dd>Description for the new type</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>CHDOC_SUPER_TYPE {Integer}<dt><dd>Super Type used for Change Document types only</dd>
 *  <dt>LIFECYCLE_ID{String}<dt><dd>Dimensions lifecycle used by the type</dd>
 *  <dt>TYPE_OPTIONS {Integer}<dt><dd>Bit mask for type options.</dd>
 *  <dt>TYPE_IS_BUILDABLE {Boolean}<dt><dd>Whether item of this item type are buildable. Default - Boolean.FALSE</dd>
 *  <dt>TYPE_DISABLED {Boolean}<dt><dd>Whether this type is disabled
 *      (i.e. can new requests of this type can be created). Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Stephen Sitton, Vadym Krevs
 */
public class CreateTypeCmd extends RPCExecCmd {

    public CreateTypeCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CHDOC_SUPER_TYPE, false, new Integer(-1), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIFECYCLE_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_OPTIONS, false, new Integer(-1), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_IS_BUILDABLE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_DISABLED, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT_CLASS)) {
            if ((!attrValue.equals(Item.class)) && (!attrValue.equals(ChangeDocument.class)) && (!attrValue.equals(Baseline.class))
                    && (!attrValue.equals(Part.class)) && (!attrValue.equals(WorkSet.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        validateAllAttrs();

        final Class typeObjectClass = (Class) getAttrValue(CmdArguments.ADM_OBJECT_CLASS);
        final String productName = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.PRODUCT_NAME));
        String tempTypeName = (String) getAttrValue(AdmAttrNames.ID);
        final String typeName = (Item.class.equals(typeObjectClass)
                ? ValidationHelper.validateItemTypeId(tempTypeName) : ValidationHelper.validateTypeId(tempTypeName));

        final String desc = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION), false);
        String tempLifecycleId = ValidationHelper.validateLifecycleId((String) getAttrValue(AdmAttrNames.LIFECYCLE_ID), true);
        int tempSuperType = ((Integer) getAttrValue(AdmAttrNames.CHDOC_SUPER_TYPE)).intValue();
        int tempOptions = ((Integer) getAttrValue(AdmAttrNames.TYPE_OPTIONS)).intValue();
        final boolean isTypeBuildable = ((Boolean) getAttrValue(AdmAttrNames.TYPE_IS_BUILDABLE)).booleanValue();
        final boolean isTypeDisabled = ((Boolean) getAttrValue(AdmAttrNames.TYPE_DISABLED)).booleanValue();

        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /ADD ");
        cmdBuf.append(Encoding.escapeDMCLI(typeName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));
        if (tempLifecycleId != null)
                cmdBuf.append(" /LIFECYCLE=").append(Encoding.escapeDMCLI(tempLifecycleId));
        if (desc != null)
                cmdBuf.append(" /DESCRIPTION=").append(Encoding.escapeDMCLI(desc));        

        if (typeObjectClass.equals(Item.class)) {
            cmdBuf.append(" /OBJ_CLASS=ITEM");

            if ((tempOptions & ObjectTypeOptions.ITEM_STD_END_PRODUCT) == ObjectTypeOptions.ITEM_STD_END_PRODUCT)
                cmdBuf.append(" /SUPER_TYPE=EXECUTABLE");
            else if ((tempOptions & ObjectTypeOptions.ITEM_STD_DOCUMENT) == ObjectTypeOptions.ITEM_STD_DOCUMENT)
                cmdBuf.append(" /SUPER_TYPE=DOCUMENT");
            else if ((tempOptions & ObjectTypeOptions.ITEM_STD_OTHER) == ObjectTypeOptions.ITEM_STD_OTHER) // same as ObjectTypeOptions.ITEM_STD_DOCUMENT
                cmdBuf.append(" /SUPER_TYPE=OTHER"); // Same as DOCUMENT
            else if ((tempOptions & ObjectTypeOptions.ITEM_STD_SOURCE_FILE) == ObjectTypeOptions.ITEM_STD_SOURCE_FILE)
                cmdBuf.append(" /SUPER_TYPE=SOURCE");
            else if ((tempOptions & ObjectTypeOptions.ITEM_STD_DERIVED_FILE) == ObjectTypeOptions.ITEM_STD_DERIVED_FILE)
                cmdBuf.append(" /SUPER_TYPE=DERIVED"); 

            // 0 means each Option is disabled. This is different from all the default values (-1) for the "Item" object type definitions,
            // when the "ORIGINATOR_ONLY" Option is enabled.
            if (tempOptions >= 0) {
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_ALLOW_PARALLEL_CHECKOUT, "PARALLEL_EXTRACT", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_REQUIRE_USER_COMMENT, "REQUIRE_COMMENT", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_ENABLE_AUTO_GENERATED_IDS, "AUTO_GENERATE_ID", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_ENABLE_ITEM_HEADER_SUBSTITUTION, "HEADER_SUBSTITUTION", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_ALLOW_ITEM_UPDATE_AT_INITIAL_STATE, "UPDATE_AT_INITIAL_STATE", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_DONT_RESTRICT_UPDATE_AT_INITIAL_STATE, "ORIGINATOR_ONLY", true, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_COMPRESS_LIBRARY_FILES, "COMPRESS", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_MAINTAIN_AND_VERIFY_FILE_CHECKSUM, "ONLY_CHANGED", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_ENFORCE_PRIMARY_ROLE, "ENFORCE_PRIMARY", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_ENFORCE_LEADER_ROLE, "ENFORCE_LEADER", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_USE_VM_STYLE_BRANCH_REVISION, "STANDARD_REVISIONING", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.ITEM_AUTOBUILD_ON_ACTION, "AUTOBUILD_ON_ACTION", false, false));
            }

            cmdBuf.append(getCmdOption("DISABLE", isTypeDisabled));

        } else if (typeObjectClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /OBJ_CLASS=REQUEST");

            switch (tempSuperType) {
            case ObjectTypeOptions.CHDOC_SUPER_TYPE_CHANGE_REQUEST:
                cmdBuf.append(" /SUPER_TYPE=CHANGE_REQUEST");
                break;
            case ObjectTypeOptions.CHDOC_SUPER_TYPE_BUG_REPORT:
                cmdBuf.append(" /SUPER_TYPE=BUG_REPORT");
                break;
            case ObjectTypeOptions.CHDOC_SUPER_TYPE_WORK_PACKAGE:
                cmdBuf.append(" /SUPER_TYPE=WORK_PACKAGE");
                break;
            case ObjectTypeOptions.CHDOC_SUPER_TYPE_OTHER:
                cmdBuf.append(" /SUPER_TYPE=OTHER");
                break;
            }

            // 0 means each Option is disabled. This is the same as all the default values (-1) for the "Request" object type definitions,
            // when the "HISTORY" Option is enabled.
            if (tempOptions > 0) {
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.CHDOC_ONLY_USERS_CAN_CREATE, "REQUIRES_ROLE", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.CHDOC_DONT_SAVE_HISTORY_INTO_DATABASE, "HISTORY", true, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.CHDOC_NOTIFY_ORIGINATOR, "CLOSE_NOTIFY", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.CHDOC_ENFORCE_PRIMARY_ROLE, "ENFORCE_PRIMARY", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.CHDOC_ENFORCE_LEADER_ROLE, "ENFORCE_LEADER", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.CHDOC_UNION_USER_ROLES, "PART_ROLES", false, false));
            }

            cmdBuf.append(getCmdOption("DISABLE", isTypeDisabled));

        } else if (typeObjectClass.equals(Baseline.class)) {
            cmdBuf.append(" /OBJ_CLASS=BASELINE");
            cmdBuf.append(getCmdOption("DISABLE", isTypeDisabled));
        } else if (typeObjectClass.equals(Part.class)) {
            cmdBuf.append(" /OBJ_CLASS=PART");
        } else if (typeObjectClass.equals(WorkSet.class)) {
            cmdBuf.append(" /OBJ_CLASS=PROJECT");

            // 0 means each Option is disabled:
            // /BRANCH /NOAUTO_REV /NOPARALLEL_EXTRACT /NOUSE_LOCAL_STAGES /NOPATH_CONTROL
            // This is different from all the default values (-1) for the "Project" object type definitions,
            // when the "USE_LOCAL_STAGES" Option is enabled.
            if (tempOptions >= 0) {
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_IS_TRUNK, "TRUNK", false, true));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_IS_TRUNK, "BRANCH", true, true));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_AUTO_REV, "AUTO_REV", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_PARALLEL_EXTRACT, "PARALLEL_EXTRACT", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_MANUAL_DEPLOYMENT, "USE_LOCAL_STAGES", false, false));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_ALWAYS_DISABLE_CM_RULES, "DEFAULT_CM_RULES", false, true));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_ALWAYS_ENABLE_CM_RULES, "CM_RULES", false, true));
                cmdBuf.append(getCmdOption(tempOptions, ObjectTypeOptions.WORKSET_PATH_CONTROL, "PATH_CONTROL", false, false));
            }
        }

        _cmdStr = cmdBuf.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Type.class);
        return retResult;
    }

    private String getCmdOption(int options, int option, String qual, boolean reverseOption, boolean nonnegatable)  {
        return (((options & option) == option) ^ reverseOption) ?
                " /" + qual : 
                nonnegatable ? "" : " /NO" + qual;
    }

    private String getCmdOption(String qual, boolean value)  {
        return value ? " /" + qual : " /NO" + qual;
    }
}

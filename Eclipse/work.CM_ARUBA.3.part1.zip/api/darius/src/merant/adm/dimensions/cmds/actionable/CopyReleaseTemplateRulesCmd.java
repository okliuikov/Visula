/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ReleaseTemplate;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will copy release template rules of an existing Dimensions release template to
 * the list of rules currently defined for another existing Dimensions release template.
 * <p>
 * Any existing rule definitions will not be overwritten. <b>Mandatory Arguments:</b> <code><dl>
 * <dt>PRODUCT_NAME {String}</dt><dd>Product name used exclusively for role checking</dd>
 * <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Dimensions release template the rules are to be copied from</dd>
 * <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions release template the rules are to be copied to</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 * <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CopyReleaseTemplateRulesCmd extends DBIOCmd {
    public CopyReleaseTemplateRulesCmd() throws AttrException {
        super();
        setAlias(Actionable.COPY_RELEASE_TEMPLATE_RULES);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));

        // this is an internal argument for transcational execution of the command
        // and MUST NOT be used by darius callees
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, false, DBIO.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof ReleaseTemplate))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if ((!(attrValue instanceof ReleaseTemplate))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        // verify "to" template
        AdmObject toTemplateObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String toTemplateId = (String) AdmHelperCmd.getAttributeValue(toTemplateObj, AdmAttrNames.ID);

        if (DoesExistHelper.releaseTemplateIsInUse(toTemplateId)) {
            throw new DimInUseException("Error: Release Template " + toTemplateId
                    + " has been used to create releases - it cannot be modified.");
        }

        if (!DoesExistHelper.releaseTemplateExists(toTemplateId)) {
            throw new DimNotExistsException("Error: Release Template " + toTemplateId + " has not been defined.");
        }

        // verify "from" template
        AdmObject fromTemplateObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        String fromTemplateId = (String) AdmHelperCmd.getAttributeValue(fromTemplateObj, AdmAttrNames.ID);

        if (!DoesExistHelper.releaseTemplateExists(fromTemplateId)) {
            throw new DimNotExistsException("Error: Release Template " + fromTemplateId + " has not been defined.");
        }

        if (fromTemplateId.equalsIgnoreCase(toTemplateId)) {
            throw new DimBaseCmdException("Error: cannot copy rules from release template " + fromTemplateId + " to itself");
        }

        String userId = AdmCmd.getCurRootObj(User.class).getId();

        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        if (query != null) {
            doCopyTemplateRules(query, fromTemplateId, toTemplateId, userId);
        } else {
            boolean doCommit = true;
            try {
                query = new DBIO(false);
                doCopyTemplateRules(query, fromTemplateId, toTemplateId, userId);
            }
            // let's be a bit paranoid
            catch (Throwable e) {
                if (query != null) {
                    try {
                        query.rollback();
                    } catch (Exception ex) {
                        Debug.error(ex);
                    }
                    doCommit = false;
                }
                Debug.error(e);
                throw new AdmException(e);
            } finally {
                if (query != null && doCommit) {
                    try {
                        query.commit();
                    } catch (Exception ex) {
                        Debug.error(ex);
                        throw new DimBaseCmdException(ex.toString());
                    }
                }
            }
        }

        return new AdmResult("Operation completed");
    }

    private void doCopyTemplateRules(DBIO query, String fromTemplateId, String toTemplateId, String userId) throws DBIOException,
            DimBaseException, AdmObjectException {
        query.resetMessage(wcm_sql.COPY_RELEASE_TEMPLATE_RULES);
        query.bindInput(toTemplateId);
        query.bindInput(fromTemplateId);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.releaseTemplateUpdateHistory(query, userId, toTemplateId);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);
    }
}

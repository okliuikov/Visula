/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * PVCS:GETITEMFILEFROMFILENAMECM.A-SRC;impulse#1
 * Description:
 * Item GETITEMFILEFROMFILENAMECM.A
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.legacy;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Legacy command to obtain an ItemFile given it's filename.
 * <p>
 * This command requires integration into the main framework. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>FILENAME {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ATTRIBUTE_NAMES {String/List}<dt><dd>Attribute name or List of attribute names to query</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions work set container for objects</dd>
 *  <dt>REVISION {String}<dt><dd>Revision of the new item</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmObject}<dt><dd>Populated ItemFile object represented by the specified filename</dd>
 * </dl></code>
 * @author Llew
 */
public class IsAreaInUse extends DBIOCmd {
    public IsAreaInUse() throws AttrException {
        super();
        setAlias("IsAreaInUse");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, Object.class));

    }

    /*
     * public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException
     * {
     * super.validateAttr(name, attrDef, attrValue);
     * }
     */

    private boolean IsAreaUsedBySCBCCfg(long areaUid) throws AdmException {

        String queryStr = "SELECT  'x' " + "FROM    DUAL " + "WHERE   EXISTS (SELECT 'x' " + "FROM BLD_BUILD_ENV bbe "
                + "WHERE bbe.BUILD_AREA_ID = :I1)";
        DBIO query = new DBIO(queryStr);

        query.bindInput(areaUid);
        query.readStart();
        boolean isValid = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);
        return isValid;
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        long areaUid = ((AdmUidObject) getAttrValue(CmdArguments.ADM_OBJECT)).getAdmUid().getUid();
        FileArea fa = null;

        if (IsAreaUsedBySCBCCfg(areaUid)) {
            fa = new FileArea(new AdmUid(areaUid, FileArea.class));
        }

        return fa;
    }
}

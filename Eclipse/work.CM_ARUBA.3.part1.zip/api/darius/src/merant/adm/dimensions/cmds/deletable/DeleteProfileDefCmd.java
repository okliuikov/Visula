/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.PrivilegesCommandConstants;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ProfileDefinition;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Profile Definition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Sarah Timmons
 */
public class DeleteProfileDefCmd extends RPCExecCmd {
    public DeleteProfileDefCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ProfileDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege(PrivilegesCommandConstants.ADMIN_UI_PROFILES)) {
            throw new DimNoPrivilegeException(PrivilegesCommandConstants.ADMIN_UI_PROFILES);
        }

        final AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Object obj = null;

        if (admObj instanceof ProfileDefinition) {
            doDeleteProfile(admObj);
        } else {
            throw new IllegalArgumentException("Error: unsupported object type");
        }

        if (obj == null) {
            obj = "Operation Completed";
        }
        return obj;
    }

    private void doDeleteProfile(final AdmObject admObj) throws AdmException {

        if (!DoesExistHelper.profileExists(admObj.getId())) {
            throw new DimNotExistsException("Error: profile " + admObj.getId() + " does not exist.");
        }

        final long profileUid = ((AdmUidObject) admObj).getUid();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws AdmException {

                SqlUtils.profileViewsRelsDelete(dbCtx, profileUid);
                dbCtx.write(DBIO.DB_DONT_COMMIT);

                SqlUtils.profileOperationsRelsDelete(dbCtx, profileUid);
                dbCtx.write(DBIO.DB_DONT_COMMIT);

                dbCtx.resetMessage(wcm_sql.PROFILE_DELETE);
                dbCtx.bindInput(profileUid);
                int affected = dbCtx.write(DBIO.DB_DONT_COMMIT);

                if (affected == 0) {
                    throw new DimInUseException("Error: failed to delete profile " + admObj.getId()
                            + " as it is used by other objects.");
                }
            }
        });
    }

}

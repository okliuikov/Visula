/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.auditable;

import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Checks if a certain row exists in a database given a query.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>SQL_INPUTS {List}<dt><dd>Inputs to query to check object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>SQL_QUERY_NO {Integer}<dt><dd>Query to check object specified as message number</dd>
 *  <dt>SQL_QUERY_STR{String}<dt><dd>Query to check object specified as SQL source</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Boolean}<dt><dd>Is true if the specified query returns any rows</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class DoesExistCmd extends DBIOCmd {

    public DoesExistCmd() throws AttrException {

        super();
        setAlias(Auditable.DOES_EXIST);
        setAttrDef(new CmdArgDef(CmdArguments.SQL_INPUTS, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.SQL_QUERY_NO, false, new Integer(0), Integer.class));
        setAttrDef(new CmdArgDef(CmdArguments.SQL_QUERY_STR, false, null, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        validateAllAttrs();
        int msgNum = ((Integer) getAttrValue(CmdArguments.SQL_QUERY_NO)).intValue();
        String queryStr = (String) getAttrValue(CmdArguments.SQL_QUERY_STR);
        List inputs = (List) getAttrValue(CmdArguments.SQL_INPUTS);

        if (msgNum == 0 && (queryStr == null || queryStr.length() == 0)) {
            throw new AttrException("Error: query source not specified");
        }

        DBIO query = null;
        if (msgNum > 0) {
            query = new DBIO(msgNum);
        } else {
            query = new DBIO(queryStr);
        }

        Iterator iter = inputs.iterator();
        while (iter.hasNext()) {
            query.bindInput(iter.next());
        }

        query.readStart();
        Boolean loc = Boolean.valueOf(query.read());
        query.close();
        return loc;
    }
}

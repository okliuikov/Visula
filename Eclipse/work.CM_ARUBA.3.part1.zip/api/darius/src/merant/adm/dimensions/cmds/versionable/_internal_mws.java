/*
 * %HEADER%
 * Copyright (C) 2004, Merant. All rights reserved.
 */
package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to merge worksets (or obtain the report).
 * <p>
 * This command requires integration into the new proposed merge suite framework. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>base {String}</dt><dd>Dimensions Ancestor Workset specification</dd>
 *  <dt>branch {String}</dt><dd>Dimensions Derivative Workset specification</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>locked {Boolean}</dt><dd>Specify true if merge should occur in a locked state</dd>
 *  <dt>report {Boolean}</dt><dd>Specify true if only a report is to be generated</dd>
 *  <dt>target {String}</dt><dd>Dimensions Target Workset specification</dd>
 *  <dt>type {String}</dt><dd>Workset type of the target workset</dd>
 *  <dt>description {String}</dt><dd>Description of the target workset</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @todo Add support for the return of the report. Will require core changes.
 * @author Floz
 */
public class _internal_mws extends RPCExecCmd {
    public _internal_mws() throws AttrException {
        super();
        setAlias("_internal_mws");
        setAttrDef(new CmdArgDef("base", true, String.class));
        setAttrDef(new CmdArgDef("branch", true, String.class));
        setAttrDef(new CmdArgDef("locked", false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef("report", false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef("target", false, String.class));
        setAttrDef(new CmdArgDef("type", false, String.class));
        setAttrDef(new CmdArgDef("description", false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        String base = (String) getAttrValue("base");
        String branch = (String) getAttrValue("branch");
        boolean locked = ((Boolean) getAttrValue("locked")).booleanValue();
        boolean report = ((Boolean) getAttrValue("report")).booleanValue();
        String target = (String) getAttrValue("target");
        String type = (String) getAttrValue("type");
        String desc = (String) getAttrValue("description");
        String requests = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);

        _cmdStr = "MWS " + Encoding.escapeSpec(base) + " " + Encoding.escapeSpec(branch);

        if (locked) {
            _cmdStr += " /STATUS=\"LOCKED\"";
        } else {
            _cmdStr += " /STATUS=\"UNLOCKED\"";
        }

        if (report) {
            _cmdStr += " /REPORT";
        }

        if (desc != null && desc.length() > 0) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(desc) + "";
        }

        if (requests != null && requests.length() > 0) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + requests + ")";
        }

        if (target != null && target.length() > 0) {
            _cmdStr += " /WORKSET=" + Encoding.escapeSpec(target) + "";

            if (type == null || type.length() == 0) {
                type = "WORKSET";
            }
            _cmdStr += " /TYPE=\"" + type + "\"";

            // More parameters may need to be added for the new workset.
        }

        return executeRpc();
    }
}

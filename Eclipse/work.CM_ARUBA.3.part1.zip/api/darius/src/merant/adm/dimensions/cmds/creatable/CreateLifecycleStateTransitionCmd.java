/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.GlobalStageLifecycleHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidLcStateException;
import merant.adm.dimensions.exception.DimLcInconsistentLifecycleException;
import merant.adm.dimensions.exception.DimLcStTransSplitException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.LifeCycleStateTransition;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions lifecycle state transition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>LIFECYCLE_ID {String}<dt><dd>Identifier of the lifecycle</dd>
 *  <dt>LCSTATETRANS_FROM_STATE {String}<dt><dd>From state</dd>
 *  <dt>LCSTATETRANS_TO_STATE {String}<dt><dd>To state</dd>
 *  <dt>LCSTATETRANS_AUTH_ROLES {List}<dt>
 *  <dd>
 *    List of RoleDefinition objects representing user roles authorized
 *    to perform the transition. Each RoleDefinition object can have optionally
 *    have LCSTATETRANS_IS_OPTIONAL and LCSTATETRANS_IS_PENDING attributes set.
 *    By default, LCSTATETRANS_IS_OPTIONAL is assumed to be FALSE, and
 *    LCSTATETRANS_IS_PENDING is assumed to be TRUE.
 *  </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>LCSTATETRANS_IS_NORM {String}<dt><dd>Whether the transition is normal. Default - TRUE</dd>
 *  <dt>AUTO_SPLIT_TRANSITIONS {Boolean}<dt>
 *  <dd>
 *      Whether to automatically insert new TO_STATE into an existing normal path transition.
 *      If AUTO_SPLIT_TRANSITION is FALSE and there already exists a normal path transition
 *      originating at FROM_STATE, then a @see merant.adm.dimensions.exception.DimLcStateTransSplitException
 *      exception shall be thrown to indicate this condition. Otherwise, the existing normal path transition
 *      shall be automatically split. Default - FALSE.
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateLifecycleStateTransitionCmd extends DBIOCmd {
    public CreateLifecycleStateTransitionCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.LIFECYCLE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_FROM_STATE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_TO_STATE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_AUTH_ROLES, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_IS_NORM, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.AUTO_SPLIT_TRANSITIONS, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.INT_SCOPE, false, AdmBaseId.class));

    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(AdmAttrNames.LCSTATETRANS_AUTH_ROLES)) {
            if (!(attrValue instanceof List)) {
                throw new AttrException("Error: AUTH_ROLES is not a list.");
            }
            List roles = (List) attrValue;
            if (roles.size() == 0) {
                throw new AttrException("Error: AUTH_ROLES is empty.");
            }

            for (int i = 0; i < roles.size(); i++) {
                Object o = roles.get(i);
                if (!(o instanceof RoleDefinition)) {
                    throw new AttrException("Error: AUTH_ROLES must contain only RoleDefinition objects.");
                }
                AdmObject admObj = (AdmObject) o;
                try {
                    if (admObj.getAdmSpec() == null) {
                        throw new AttrException("Error: RoleDefinition object in AUTH_ROLES has no AdmSpec.");
                    }
                } catch (AdmObjectException e) {
                    Debug.error(e);
                    throw new AttrException(e.toString());
                }
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_LIFECYCLEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_LIFECYCLEMAN");
        }

        validateAllAttrs();

        final String lifecycleId = ValidationHelper.validateLifecycleId((String) getAttrValue(AdmAttrNames.LIFECYCLE_ID));
        final String fromState = ValidationHelper.validateLifecycleStatus((String) getAttrValue(AdmAttrNames.LCSTATETRANS_FROM_STATE));
        final String toState = ValidationHelper.validateLifecycleStatus((String) getAttrValue(AdmAttrNames.LCSTATETRANS_TO_STATE));
        final boolean isNormal = ((Boolean) getAttrValue(AdmAttrNames.LCSTATETRANS_IS_NORM)).booleanValue();
        final boolean autoSplitTransitions = ((Boolean) getAttrValue(CmdArguments.AUTO_SPLIT_TRANSITIONS)).booleanValue();

        final List authRoles = (List) getAttrValue(AdmAttrNames.LCSTATETRANS_AUTH_ROLES);

        if (!DoesExistHelper.lifecycleExists(lifecycleId)) {
            throw new DimAlreadyExistsException("Error: Lifecycle " + lifecycleId + " does not exist.");
        }

        setAttrValue(CmdArguments.INT_SPEC, fromState + ':' + toState);
        setAttrValue(CmdArguments.INT_SCOPE, AdmHelperCmd.newAdmBaseId(lifecycleId, LifeCycle.class));

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {
                boolean isGSL = GlobalStageLifecycleHelper.isLifecycleGSL(lifecycleId);
                AdmObject circularGSLTransitionToDelete = null;

                if (isGSL) {
                    int count = GlobalStageLifecycleHelper.getGSLStageCount(dbCtx);
                    if (fromState.equalsIgnoreCase(toState) && count > 1) {
                        throw new DimAlreadyExistsException("Error: Cannot create stage with duplicate name (" + fromState
                                + ") or create transition to itself in Global Stage Lifecycle.");
                    } else if (count == 1) {
                        String stage = GlobalStageLifecycleHelper.getInitialGSLStageId(dbCtx);
                        int normLcCount = GlobalStageLifecycleHelper.getNormLifecycleCount(dbCtx, lifecycleId);
                        if (normLcCount == 1) {
                            // If stage_catalogue & norm_lifecycle counts are both one then
                            // try to delete a circular transition (see further below).
                            // Need to delete it after the new transition has been added though,
                            // to avoid further complications.
                            circularGSLTransitionToDelete = AdmCmd.getObject(AdmCmd.newAdmBaseId(stage + ":" + stage,
                                    LifeCycleStateTransition.class, AdmCmd.newAdmBaseId(lifecycleId, LifeCycle.class)));

                        }
                    }
                }

                // perform create/rename operation
                doAddTransition(dbCtx, lifecycleId, fromState, toState, isNormal, autoSplitTransitions, isGSL);

                // actually insert new records into life_cycles!!!! with all the roles
                doAddRoles(dbCtx, lifecycleId, fromState, toState, isNormal, authRoles);

                // make sure we have at least one transition
                validateTransitionRoles(dbCtx, lifecycleId, fromState, toState);

                // remove circular transition from GSL if it exists (see above)
                if (isGSL && circularGSLTransitionToDelete != null) {
                    try {
                        Cmd cmd = AdmCmd.getCmd(Deletable.DELETE, LifeCycleStateTransition.class);
                        cmd.setAttrValue(CmdArguments.ADM_OBJECT, circularGSLTransitionToDelete);
                        cmd.execute();
                    } catch (AdmException e) {
                        // should we fail the whole operation if the circular transition isn't removed?
                        Debug.error(e);
                    }
                }
            }
        });

        // do create the transition
        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, LifeCycleStateTransition.class);
        return retResult;
    }

    private void doAddRoles(DBIO query, String lifecycleId, String fromState, String toState, boolean isNormal, List authRoles)
            throws Exception {
        Cmd cmd = AdmCmd.getCmd("_internal_assign_transition_roles");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, query);
        cmd.setAttrValue(AdmAttrNames.LIFECYCLE_ID, lifecycleId);
        cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_FROM_STATE, fromState);
        cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_TO_STATE, toState);
        cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_IS_NORM, Boolean.valueOf(isNormal));
        cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_AUTH_ROLES, authRoles);
        cmd.execute();
    }

    /**
     * Adds a state transition to the lifecycle performing myriads of consistency checks
     * All updates and reads from updated tables are performed within the context of one transaction
     */
    private void doAddTransition(DBIO query, String lifecycleId, String newBeginState, String newEndState, boolean isNormal,
            boolean autoSplitTransitions, boolean isGSL) throws Exception {
        char normal_lc = (isNormal ? 'Y' : 'N');
        String newFromState = newBeginState == null ? "" : newBeginState;
        String newToState = newEndState == null ? "" : newEndState;
        String next_status;
        String begin_status;

        //
        // validate input data
        //
        if (newFromState.length() == 0) {
            throw new DimInvalidLcStateException("Error: The Begin State of the transition must be specified.");
        }

        if (newToState.length() == 0) {
            throw new DimInvalidLcStateException("Error: The End State of the transition must be specified.");
        }

        if ("SUSPENDED".equals(newFromState) || "SUSPENDED".equals(newToState)) {
            throw new DimInvalidLcStateException("Error: State SUSPENDED is a reserved state. Please use a different name.");
        }

        //
        // check if transition already exists
        //
        if (transitionExists(query, lifecycleId, newFromState, newToState)) {
            throw new DimAlreadyExistsException("Error: The new transition " + newFromState + "->" + newToState
                    + " already exists.");
        }

        if (normal_lc == 'Y') {
            // Allow insertion of a normal transition into a single-state lifecycle
            if (isSingleStateLifecycle(query, lifecycleId, newFromState, newToState)) {
                // Make the single-state transition off-normal so that the new transition can be inserted successfully
                query.resetMessage(wcm_sql.PM_LC_MAKE_SS_TRANS_OFFNORMAL);
                query.bindInput(lifecycleId);
                query.bindInput(newFromState);
                query.bindInput(newToState);
                query.write(DBIO.DB_DONT_COMMIT);
            } // if (isSingleStateLifecycle(lc_id, newFromState, newToState))

            //
            // check if there already exists a normal path transition from newFromState to some other state
            //
            next_status = getNextStatus(query, lifecycleId, newFromState);
            if (next_status != null) {
                // there already exists a normal path transition from NEW_FROM_STATE to NEXT_STATUS
                // can we automatically split it?
                if (!autoSplitTransitions) {
                    throw new DimLcStTransSplitException(newFromState, next_status);
                }

                // DUPLICATE_CODE: see below/below - these three sections
                // should be re-factored out into a common method later.

                // temporary insert new transition so that we can check a normal path can be generated
                insertTempTransition(query, lifecycleId, newFromState, newToState, normal_lc);
                // insert splitting transition
                insertSplittingTransition(query, lifecycleId, next_status, newToState, true);

                // check if we can generate normal lifecycle path. If not, an exception shall be raised,
                // and the above temporary transition will be deleted as part of the rollback
                generateNormalLifecycle(query, lifecycleId, true);

                // normal lifecycle path was generated successfully - delete temp transition
                deleteTempTransition(query, lifecycleId, newFromState, newToState);

                // insert a stage into stage_catalogue
                if (isGSL && normal_lc == 'Y') {
                    GlobalStageLifecycleHelper.insertGSLStage(query, newFromState, newToState);
                }

                return;
            } // if (next_status != null)

            //
            // check if there already exists a normal path transition from some state to NEW_TO_STATE
            //
            begin_status = getBeginStatus(query, lifecycleId, newToState);
            if (begin_status != null) {
                // there already exists a normal path transition from BEGIN_STATUS to NEW_TO_STATE
                // can we automatically split it?
                if (!autoSplitTransitions) {
                    throw new DimLcStTransSplitException(begin_status, newToState);
                }

                // DUPLICATE_CODE: see above/below - these three sections
                // should be re-factored out into a common method later.

                // temporary insert new transition so that we can check a normal path can be generated
                insertTempTransition(query, lifecycleId, newFromState, newToState, normal_lc);
                // insert splitting transition
                insertSplittingTransition(query, lifecycleId, begin_status, newFromState, false);

                // check if we can generate normal lifecycle path. If not, an exception shall be raised,
                // and the above temporary transition will be deleted as part of the rollback
                generateNormalLifecycle(query, lifecycleId, true);

                // normal lifecycle path was generated successfully - delete temp transition
                deleteTempTransition(query, lifecycleId, newFromState, newToState);

                // insert a stage into stage_catalogue
                if (isGSL && normal_lc == 'Y') {
                    GlobalStageLifecycleHelper.insertGSLStage(query, newFromState, newToState);
                }

                return;
            } // if (begin_status != null)
        } // if (normal_lc == 'Y')
        else if (isGSL) { // && normal_lc='N'
            // can only create off-normal transitions for normal states with the GSL
            // therefore for an off-normal transition both states must already exist
            if (!GlobalStageLifecycleHelper.GSLStageExists(query, newFromState)
                    || !GlobalStageLifecycleHelper.GSLStageExists(query, newToState)) {
                throw new DimInvalidLcStateException("It is not possible to" + " add an off-normal transition to the global stage"
                        + " lifecycle unless that transition connects two" + " stages that already exist.");
            }
        }

        // DUPLICATE_CODE: see above/above - these three sections
        // should be re-factored out into a common method later.

        // Temporary insert new transition so that we can check a normal path can be generated
        insertTempTransition(query, lifecycleId, newFromState, newToState, normal_lc);

        // check if we can generate normal lifecycle path. If not, an exception shall be raised,
        // and the above temporary transition will be deleted as part of the rollback
        generateNormalLifecycle(query, lifecycleId, true);

        // normal lifecycle path was generated successfully - delete temp transition
        deleteTempTransition(query, lifecycleId, newFromState, newToState);

        // insert a stage into stage_catalogue
        if (isGSL && normal_lc == 'Y') {
            GlobalStageLifecycleHelper.insertGSLStage(query, newFromState, newToState);
        }

        return;
    }

    /**
     * Regenerates and validates normal lifecycle path after an alteration of the lifecycle
     */
    private void generateNormalLifecycle(DBIO query, String lifecycleId, boolean addingTransition) throws DBIOException,
            DimBaseException, Exception {
        Cmd cmd = AdmCmd.getCmd("_internal_generate_normal_lifecycle");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, query);
        cmd.setAttrValue(AdmAttrNames.LIFECYCLE_ID, lifecycleId);
        cmd.setAttrValue(CmdArguments.ADDING_TRANSITION, Boolean.valueOf(addingTransition));
        cmd.execute();
    }

    /**
     * Checks if the specified lifecycle is a single state lifecycle
     */
    private boolean isSingleStateLifecycle(DBIO query, String lifecycleId, String fromState, String toState) throws DBIOException,
            DimBaseException, Exception {
        query.resetSQL("SELECT next_doc_status FROM life_cycles " + "WHERE lifecycle_id = :I1 AND "
                + "(doc_status = :I2 OR doc_status = :I3) AND " + "doc_status = next_doc_status AND "
                + "norm_lc = 'Y' AND ROWNUM = 1");

        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);

        query.readStart();
        boolean isSingleState = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        return isSingleState;
    }

    /**
     * Returns next normal state given a lifecycle and a start state
     */
    private String getNextStatus(DBIO query, String lifecycleId, String fromState) throws DBIOException, DimBaseException,
            Exception {
        String nextStatus = null;

        query.resetSQL("SELECT next_doc_status FROM life_cycles " + "WHERE lifecycle_id = :I1 AND "
                + "doc_status = :I2 AND norm_lc = 'Y' AND ROWNUM = 1");
        query.bindInput(lifecycleId);
        query.bindInput(fromState);

        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            nextStatus = query.getString(1);
        }
        return nextStatus;
    }

    /**
     * Returns previous state given a lifecycle and an end state
     */
    private String getBeginStatus(DBIO query, String lifecycleId, String toState) throws DBIOException, DimBaseException, Exception {
        String beginStatus = null;

        query.resetSQL("SELECT doc_status FROM life_cycles " + "WHERE lifecycle_id = :I1 AND "
                + "next_doc_status = :I2 AND norm_lc = 'Y' AND rownum = 1");
        query.bindInput(lifecycleId);
        query.bindInput(toState);

        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            beginStatus = query.getString(1);
        }
        return beginStatus;
    }

    /**
     * Inserts a temporary transition to enable normal path generation
     */
    private void insertTempTransition(DBIO query, String lifecycleId, String fromState, String toState, char normal_lc)
            throws DBIOException, DimBaseException, Exception {
        query.resetMessage(wcm_sql.CREATE_LIFE_CYCLE);
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.bindInput(normal_lc == 'Y' ? "Y" : "N");
        query.write(DBIO.DB_DONT_COMMIT);
    }

    /**
     * Deletes the temporary transition used to enable normal path generation
     */
    private void deleteTempTransition(DBIO query, String lifecycleId, String fromState, String toState) throws DBIOException,
            DimBaseException, Exception {
        query.resetMessage(wcm_sql.DELETE_LIFE_CYCLE);
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.write(DBIO.DB_DONT_COMMIT);
    }

    /**
     * Inserts splitting transition used to enable normal path generation
     */
    private void insertSplittingTransition(DBIO query, String lifecycleId, String existingState, String newState,
            boolean toExistingState) throws DBIOException, DimBaseException, Exception {
        if (toExistingState) {
            // insert splitting transition from NEW_TO_STATE to an existing state
            query.resetMessage(wcm_sql.UPDATE_LIFE_CYCLE_DOC_STATUS);
            query.bindInput(lifecycleId);
            query.bindInput(newState); // FROM new state
            query.bindInput(existingState); // TO existing state
        } else {
            // insert splitting transition from an existing state to NEW_FROM_TRANSITION
            query.resetMessage(wcm_sql.UPDATE_LIFE_CYCLE_NEXT_DOC_STATUS);
            query.bindInput(lifecycleId);
            query.bindInput(existingState); // FROM existing state
            query.bindInput(newState); // TO new state
        }
        query.write(DBIO.DB_DONT_COMMIT);
    }

    /**
     * Check if there is at least one role associated with the transition
     */
    private void validateTransitionRoles(DBIO query, String lifecycleId, String fromState, String toState) throws DBIOException,
            DimBaseException, Exception {
        query.resetSQL("SELECT COUNT(*) FROM life_cycles " + "WHERE lifecycle_id = UPPER(:I1) AND "
                + "doc_status = UPPER(:I2) AND " + "next_doc_status = UPPER(:I3)");
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);

        query.readStart();

        long count = 0;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            count = query.getLong(1);
        }

        if (count == 0) {
            throw new DimLcInconsistentLifecycleException("Error: At least one role must be associated with the transition.");
        }
    }

    /**
     * Checks if a lifecycle state transition already exists in the specified lifecycle
     * @param lifecycleId
     *            the name of the lifecycle to check
     * @param fromState
     *            the FROM state
     * @param toState
     *            the TO state
     */
    private boolean transitionExists(DBIO query, String lifecycleId, String fromState, String toState) throws DBIOException,
            DimBaseException, Exception {
        query.resetSQL("SELECT lifecycle_id FROM life_cycles "
                + "WHERE lifecycle_id = :I1 AND doc_status = :I2 AND next_doc_status = :I3");

        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);

        query.readStart();
        boolean exists = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        return exists;
    }

}

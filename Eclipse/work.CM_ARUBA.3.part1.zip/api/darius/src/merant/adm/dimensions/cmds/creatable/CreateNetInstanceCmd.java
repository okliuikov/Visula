/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetInstance;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Network Instance object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Network service name identifier of the new instance</dd>
 *  <dt>NETINSTANCE_NODE {String}</dt><dd>NetNode identifier of the new instance</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ACTIVE {Boolean}</dt><dd>Indicates if the new instance is to be active</dd>
 *  <dt>NETBASEDB {String}</dt><dd>Specification of a NetBaseDatabase to be related to the new instance</dd>
 *  <dt>NETCONTACT {String}</dt><dd>Specification of a NetContact to be related to the new instance</dd>
 *  <dt>NETINSTANCE_HOME_DIR {String}</dt><dd>Home directory of the new instance</dd>
 *  <dt>NETINSTANCE_TRANSPORT {String}</dt><dd>Transport of the new instance</dd>
 *  <dt>NETINSTANCE_TWO_TASK {String}</dt><dd>Two Task of the new instance</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateNetInstanceCmd extends RPCExecCmd {
    public CreateNetInstanceCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETINSTANCE_NODE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ACTIVE, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.NETBASEDB, false, "X", String.class)); // Default to X as command line is mandatory
                                                                                     // but not validated
        setAttrDef(new CmdArgDef(CmdArguments.NETCONTACT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETINSTANCE_HOME_DIR, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETINSTANCE_TRANSPORT, false, "ODBC", String.class)); // Default to ODBC as command
                                                                                                    // line is mandatory
        setAttrDef(new CmdArgDef(AdmAttrNames.NETINSTANCE_TWO_TASK, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String netNode = (String) getAttrValue(AdmAttrNames.NETINSTANCE_NODE);
        Boolean active = (Boolean) getAttrValue(AdmAttrNames.ACTIVE);
        String netBaseDb = (String) getAttrValue(CmdArguments.NETBASEDB);
        String netContact = (String) getAttrValue(CmdArguments.NETCONTACT);
        String homeDir = (String) getAttrValue(AdmAttrNames.NETINSTANCE_HOME_DIR);
        String transport = (String) getAttrValue(AdmAttrNames.NETINSTANCE_TRANSPORT);
        String twoTask = (String) getAttrValue(AdmAttrNames.NETINSTANCE_TWO_TASK);

        setAttrValue(CmdArguments.INT_SPEC, netNode + ":" + id);

        _cmdStr = "CINS ";
        _cmdStr += " /DB_SERVICE=" + Encoding.escapeSpec(id);
        _cmdStr += " /NN_NAME=\"" + netNode + "\"";

        if (active != null) {
            if (active.booleanValue()) {
                _cmdStr += " /DB_ACTIVE=\"Y\"";
            } else {
                _cmdStr += " /DB_ACTIVE=\"N\"";
            }
        }

        _cmdStr += " /DB_NAME=\"" + netBaseDb + "\"";

        if (netContact != null) {
            _cmdStr += " /CO_NAME=\"" + netContact + "\"";
        }

        if (homeDir != null) {
            _cmdStr += " /DB_HOME_DIR=\"" + homeDir + "\"";
        }

        _cmdStr += " /DB_TRANSPORT=\"" + transport + "\"";

        if (twoTask != null) {
            _cmdStr += " /DB_TWO_TASK=\"" + twoTask + "\"";
        } else {
            _cmdStr += " /DB_TWO_TASK=\"" + id + "\"";
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, NetInstance.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * PVCS:TEMPFILEINPUTSTREAM JAVA.A-SRC;webapp#1
 * Description:
 * Item TEMPFILEINPUTSTREAM JAVA.A
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;

import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdFactory;

/**
 * Uses a temporary file as an OutputStream, the first overridden OutputStream
 * public method call actually opens the file and it is deleted when the stream
 * is closed.
 * The intended use of this class is as follows:
 * Some legacy code exists that copies data to a temporary file, it then needs
 * to return the temporary file's filename back to its caller and the caller
 * must be sure to delete the temporary file.
 * Using this class, the legacy code can be wrapped. Instead of using
 * java.io.File.createTempFile() to create a temporary file, instantiate an
 * object of this class and use getAbsolutePath() to find its filename. When
 * the legacy code has finished writing data into this file, the wrapper can
 * just return this object which acts just like a FileOutputStream, but will
 * delete the temporary file when the stream is closed or finalized.
 * 
 * @author David Conneely
 * @author Neil Dudman
 * 
 */
public class TempFileOutputStream extends OutputStream {
    /**
     * The only constructor creates the temporary file,
     * but doesn't open it yet.
     */
    public TempFileOutputStream() throws AdmObjectException, AdmException, AttrException, DimBaseCmdException, IOException {
        String fname = TempFileOutputStream.getTempFileName();

        file = new File(fname);
        file.createNewFile();
    }

    /**
     * Generates a unique temporary filename.
     */
    public static String getTempFileName() throws AdmObjectException, AdmException, AttrException, DimBaseCmdException, IOException {
        String ret = null;

        CmdFactory factory = DimSystem.getSystem().getAdmCmdFactory();
        RPCCmd cmd = (RPCCmd) factory.getCmd("GetTempFile");
        String result = (String) cmd.execute();

        ret = result.substring(Constants.SERVER_OK.length());
        ret = ret.trim();

        return ret;
    }

    /**
     * Find out where the temporary file being used by this stream is.
     * @return The absolute path of the File object that will be used to write from.
     */
    public String getAbsolutePath() {
        return file.getAbsolutePath();
    }

    public String getCanonicalPath() throws IOException {
        return file.getCanonicalPath();
    }

    public String getName() {
        return file.getName();
    }

    public String getParent() {
        return file.getParent();
    }

    public String getPath() {
        return file.getPath();
    }

    public boolean setLastModified(long time) {
        return file.setLastModified(time);
    }

    public boolean setReadOnly() {
        return file.setReadOnly();
    }

    @Override
    public String toString() {
        return file.toString();
    }

    public URL toURL() throws MalformedURLException {
        return file.toURL();
    }

    /**
     * Create the contained FileOutputStream if it hasn't been opened
     * yet and delegate the write to it.
     * @param The
     *            byte write from the stream, or -1 if eof.
     */
    @Override
    public void write(int b) throws IOException {
        initStream();
        out.write(b);
    }

    @Override
    public void write(byte[] b) throws IOException {
        initStream();
        out.write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        initStream();
        out.write(b, off, len);
    }

    /**
     * Closes the contained stream and deletes the temporary file
     * when the containing stream is closed.
     */
    @Override
    public void close() throws IOException {
        killStream();
    }

    /**
     * Writes a string into the file using the right character encoding.
     */
    public void writeString(String s) throws IOException {
        initStream();
        Writer writer = null;
        try {
            writer = new BufferedWriter(StringUtils.createEncodingWriter(out));
            writer.write(s);
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    /**
     * Closes the contained stream and deletes the temporary file
     * when the last reference is released on this object.
     */
    @Override
    public void finalize() throws IOException {
        close();
    }

    /**
     * Helper method to create contained stream.
     */
    private void initStream() throws IOException {
        if (out == null) {
            out = new FileOutputStream(file);
        }
    }

    /**
     * Helper method to destroy contained stream.
     */
    private void killStream() throws IOException {
        if (out != null) {
            out.close();
            out = null;
        }
        file.delete();
        file = null;
    }

    private File file = null;

    private FileOutputStream out = null;
}

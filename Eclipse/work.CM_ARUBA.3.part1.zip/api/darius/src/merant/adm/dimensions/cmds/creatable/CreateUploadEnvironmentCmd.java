/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.UploadEnvironment;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Upload Environment object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new upload environment</dd>
 *  <dt>EXTENSION {String}</dt><dd>Extension for the new upload environment</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>UPLENV_ALLOW_OTHER {Boolean}</dt><dd>If true, allow's access to other environments</dd>
 * </dl></code> <br>
 * <b>Required privilege:</b> <code><dl>
 *  <dt>ADMIN_UPLOADMAN</dt><dd></dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateUploadEnvironmentCmd extends RPCExecCmd {
    public CreateUploadEnvironmentCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EXTENSION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.UPLENV_ALLOW_OTHER, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UPLOADMAN")) {
            throw new DimNoPrivilegeException("ADMIN_UPLOADMAN");
        }

        String id = (String) getAttrValue(AdmAttrNames.ID);
        String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);
        boolean allowOther = ((Boolean) getAttrValue(AdmAttrNames.UPLENV_ALLOW_OTHER)).booleanValue();

        setAttrValue(CmdArguments.INT_SPEC, id + ";" + extension);

        DBIO query = null;
        if (allowOther) {
            query = new DBIO(wcm_sql.CREATE_UPLENV_ALLOW_OTHERS);
        } else {
            query = new DBIO(wcm_sql.CREATE_UPLENV);
        }

        query.bindInput(id);
        query.bindInput(extension);
        query.write();

        AdmResult retResult = new AdmResult("Created upload environment \"" + id + "\" successfully");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, UploadEnvironment.class);
        return retResult;
    }
}

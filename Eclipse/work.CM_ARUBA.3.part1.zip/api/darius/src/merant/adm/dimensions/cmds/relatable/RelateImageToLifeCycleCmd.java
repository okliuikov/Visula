/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.LifeCycleImage;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate a LifeCycleImage to a LifeCycle.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {LifeCycle}<dt><dd>Dimensions LifeCycleImage object</dd>
 *  <dt>ADM_PARENT_OBJECT {Type}<dt><dd>Parent Dimensions LifeCycle object </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class RelateImageToLifeCycleCmd extends RPCExecCmd {
    public RelateImageToLifeCycleCmd() throws AttrException {
        super();
        setAlias("RelateImageToLifeCycleCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, LifeCycleImage.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, LifeCycle.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LifeCycleImage)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof LifeCycle)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_LIFECYCLEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_LIFECYCLEMAN");
        }

        validateAllAttrs();

        // Dimensions lifecycle image
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        // Dimensions lifecycle
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        String lifecycleId = admParentObj.getId();
        String revision = admObj.getId();

        String imageLifecycleId = ((AdmSpec) admObj.getAdmBaseId().getScope()).getSpec();

        lifecycleId = StringUtils.adjustValue(lifecycleId, AdmDmLengths.DM_L_LIFECYCLE);
        if (lifecycleId == null || lifecycleId.length() == 0) {
            throw new DimInvalidAttributeException("Error: lifecycle name is not specified.");
        }

        if (!DoesExistHelper.lifecycleExists(lifecycleId)) {
            throw new DimNotExistsException("Error: lifecycle " + lifecycleId + " does not exist.");
        }

        imageLifecycleId = StringUtils.adjustValue(imageLifecycleId, AdmDmLengths.DM_L_LIFECYCLE_IMAGE_ID);
        if (imageLifecycleId == null || imageLifecycleId.length() == 0) {
            throw new DimInvalidAttributeException("Error: lifecycle name is not specified.");
        }

        if (!lifecycleId.equals(imageLifecycleId)) {
            throw new DimBaseCmdException("Error: image revision " + admObj.getId() + " is not in image gallery for lifecycle "
                    + lifecycleId + ".");
        }

        StringBuffer cmdBuf = new StringBuffer("LIFECYCLE /UPDATE ");
        cmdBuf.append(Encoding.escapeDMCLI(lifecycleId));
        if (bDeassign)
            cmdBuf.append(" /REVISION=\"\"");
        else
            cmdBuf.append(" /REVISION=").append(Encoding.escapeDMCLI(revision));

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }
}

/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.drs.DRSClientSysObjAttrUtils;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimLockedException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplItemMasterConfig;
import merant.adm.dimensions.objects.ReplItemSubordinateConfig;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions subordinate item replication configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.REPL_CONFIG_OBJ {ReplItemMasterConfig}<dt>
 *      <dd>The master item replication configuration object.</dd>
 *  <dt>AdmAttrNames.REPL_WORKSET_ID {String}<dt>
 *      <dd>The project from which item branches are to be replicated from the subordinate</dd>
 *  <dt>CmdArguments.BRANCHES{List}<dt>
 *      <dd>The list of Branch objects on the above project that are to be replicated</dd>
 * </dl></code> <br>
 * Note: in case of subordinate projects remote to the master replication configuration the WORKSET and BRANCHES arguments will
 * represent object which do not exist in the base database currently connected to, and thus will have have UIDs. <b>Optional
 * Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.REPL_BASEDB_OBJ {NetBaseDatabase}<dt>
 *  <dd>
 *      A NetBaseDatabase object representing the subordinate site. Any Dimensions site is uniquely identified by
 *      a network node name, database service name, and base database name. This argument must only be set
 *      when defining subordinate projects remote to master configuration. When defining subordinate projects local
 *     to master configuration, this argument will be set automatically to the NetBaseDatabase object representing
 *     the local site.
 *  </dd>
 *  <dt>AdmAttrNames.REPL_IS_ENABLED {Boolean}<dt>
 *  <dd>Whether the replication configuration is to be enabled. Default - Boolean.TRUE</dd>
 *  <dt>AdmAttrNames.REPL_IS_REPLICATES_BACK {Boolean}<dt>
 *  <dd>Whether this subordinate is to replicate branches back to the master. Default - Boolean.FALSE</dd>
 *  <dt>AdmAttrNames.REPL_IS_OFFLINE{Boolean}<dt>
 *  <dd>Whether the replication subordinate is offline. Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateReplItemSubordinateConfigCmd extends DBIOCmd {

    public CreateReplItemSubordinateConfigCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_CONFIG_OBJ, true, ReplItemMasterConfig.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_WORKSET_ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_BASEDB_OBJ, false, AdmCmd.getCurRootObj(NetBaseDatabase.class),
                NetBaseDatabase.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_ENABLED, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_REPLICATES_BACK, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_OFFLINE, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // extract and validate command arguments
        final AdmObject masterConfigObj = (AdmObject) getAttrValue(AdmAttrNames.REPL_CONFIG_OBJ);
        String projectSpec = ValidationHelper.validateWorksetSpec((String) getAttrValue(AdmAttrNames.REPL_WORKSET_ID));

        final AdmObject subordinateSiteObj = (AdmObject) getAttrValue(AdmAttrNames.REPL_BASEDB_OBJ);
        final List branchList = (List) getAttrValue(CmdArguments.BRANCHES);
        final boolean isEnabled = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_ENABLED)).booleanValue();
        final boolean isReplicatesBack = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_REPLICATES_BACK)).booleanValue();
        final boolean isOffline = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_OFFLINE)).booleanValue();
        final boolean isTransfered = true;

        if (masterConfigObj == null) {
            throw new DimMandatoryAttributeException("Error: master replication configuration must be specified.");
        }
        if (subordinateSiteObj == null) {
            throw new DimMandatoryAttributeException("Error: subordinate site must be specified.");
        }

        // check remote project is in the correct format.
        boolean projectSpecGood = false;
        int productSep = projectSpec.indexOf(':');
        if (productSep > 0 && productSep + 1 < projectSpec.length()) {
            projectSpecGood = true;
        }
        if (!projectSpecGood) {
            throw new DimMandatoryAttributeException("Error: project should be in format <product id>:<project id>.");
        }

        // check if master replication configuration exists
        final String configId = masterConfigObj.getId();
        long masterConfigUid = getMasterConfigUid(configId, Constants.REPL_ITEM_CLASS);
        if (masterConfigUid == -1) {
            throw new DimNotExistsException("Error: master item replication configuration " + configId + " does not exist.");
        }

        // check if this master replication configuration is local to the base database we are currently logged on to.
        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        long thisSiteUid = 0;
        if (thisSite != null) {
            thisSiteUid = ((AdmUidObject) thisSite).getUid();
        } 
        if (!isLocalReplConfig(null, masterConfigUid, Constants.REPL_ITEM_CLASS, thisSiteUid)) {
            throw new DimLockedException("Error: remote master item replication configuration " + configId + " is not updatable.");
        }

        // check if subordinate site definition exists
        boolean siteExists = true;
        try {
            // this is done to check if the site exists
            long siteUid = ((AdmUidObject) subordinateSiteObj).getUid();
            if (siteUid <= 0) {
                siteExists = false;
            }
        } catch (AdmException ae) {
            Debug.error(ae);
            siteExists = false;
        }
        if (!siteExists) {
            throw new DimNotExistsException("Error: subordinate base database "
                    + subordinateSiteObj.getAttrValue(AdmAttrNames.SENDER_ID) + " does not exist.");
        }

        final String subordinateSiteId = (String) AdmHelperCmd.getAttributeValue(subordinateSiteObj, AdmAttrNames.SENDER_ID);

        // check whether subordinate project is remote to this base database
        final long subordinateSiteUid = ((AdmUidObject) subordinateSiteObj).getUid();
        final boolean isLocalSubordinate = (subordinateSiteUid == thisSiteUid);

        final AdmObject projectObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(projectSpec, WorkSet.class));
        // if using local replication, then check if project exists
        if (isLocalSubordinate) {
            boolean projectExists = true;
            try {
                // this is done to check if the project exists
                long projectUid = ((AdmUidObject) projectObj).getUid();
                if (projectUid <= 0) {
                    projectExists = false;
                }
            } catch (AdmException ae) {
                projectExists = false;
            }
            if (!projectExists) {
                throw new DimNotExistsException("Error: project " + projectSpec + " does not exist.");
            }
        }
        final String projectId = projectObj.getAdmSpec().getSpec();

        if (isReplicatesBack && (branchList == null || branchList.size() == 0)) {
            throw new DimMandatoryAttributeException("Error: list of branches to be replicated must be specified.");
        }

        if (branchList != null && !branchList.isEmpty()) {
            for (Iterator it = branchList.iterator(); it.hasNext();) {
                AdmObject branch = (AdmObject) it.next();
                if (branch == null || !(branch instanceof Branch)) {
                    throw new DimMandatoryAttributeException("Error: list of branches to be replicated must be specified.");
                }
            }
        }
        // do the work
        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws AdmException {

                String revision = getNextConfigRevision(dbCtx, configId, Constants.REPL_ITEM_CLASS);
                setAttrValue(CmdArguments.INT_SPEC, configId + ";" + revision);

                validateConfigData(dbCtx, configId, revision, projectId, subordinateSiteUid, isLocalSubordinate);

                long configUid = getNewUid(dbCtx);
                insertConfigData(dbCtx, configUid, configId, revision, subordinateSiteUid, subordinateSiteId, projectId, isEnabled,
                        isTransfered, isReplicatesBack, isOffline);

                if (branchList != null && !branchList.isEmpty()) {
                    validateBranchData(dbCtx, configId, revision, branchList, subordinateSiteUid, isLocalSubordinate);
                    insertBranchData(dbCtx, branchList, configUid);
                }
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ReplItemSubordinateConfig.class);
        return retResult;
    }

    private void validateConfigData(DBIO dbCtx, String configId, String revision, String projectId, long subordinateSiteUid,
            boolean isLocalSubordinate) throws AdmException {

        if (replConfigExists(dbCtx, configId, Constants.REPL_ITEM_CLASS, revision)) {
            throw new DimAlreadyExistsException("Error: configuration name " + configId + " has already been specified.");
        }

        if (isLocalSubordinate) {
            if (isLocalSubordinateAlreadyDefined(dbCtx, configId, Constants.REPL_ITEM_CLASS, subordinateSiteUid, projectId)) {
                throw new DimAlreadyExistsException("Error: these subordinate site details have already been specified.");
            }
        } else {
            if (isRemoteSubordinateAlreadyDefined(dbCtx, configId, Constants.REPL_ITEM_CLASS, subordinateSiteUid)) {
                throw new DimAlreadyExistsException("Error: these subordinate site details have already been specified.");
            }
        }
    }

    private boolean isRemoteSubordinateAlreadyDefined(DBIO dbCtx, String configId, int repClass, long baseDbUid)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_SUBORD_CONFIG_IS_ALREADY_DEFINED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(baseDbUid);
        dbCtx.readStart();
        boolean defined = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return defined;
    }

    private boolean isLocalSubordinateAlreadyDefined(DBIO dbCtx, String configId, int repClass, long baseDbUid, String projectId)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_ALREADY_DEFINED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(baseDbUid);
        dbCtx.bindInput(projectId);
        dbCtx.readStart();
        boolean defined = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return defined;
    }

    private boolean replConfigExists(DBIO dbCtx, String configId, int replClass, String revision) throws DBIOException,
            DimBaseException, AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_IS_CONFIG_ALREADY_DEFINED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.bindInput(revision);
        dbCtx.readStart();
        boolean exists = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return exists;
    }

    private String getNextConfigRevision(DBIO dbCtx, String configId, int replClass) throws AdmException {

        String revision = getMaxConfigRevision(dbCtx, configId, replClass);
        if (revision == null) {
            revision = "0";
        } else {
            try {
                int rev = Integer.parseInt(revision);
                revision = new Integer(++rev).toString();
            } catch (NumberFormatException nfe) {
                Debug.error(nfe);
                revision = "0";
            }
        }
        return revision;
    }

    private String getMaxConfigRevision(DBIO dbCtx, String configId, int replClass) throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_GET_MAX_REVISION);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        String lastRevision = (dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getString(1) : null);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return lastRevision;
    }

    private void insertConfigData(DBIO dbCtx, long configUid, String configId, String revision, long subordinateSiteUid,
            String subordinateSiteId, String projectSpec, boolean isEnabled, boolean isTransfered, boolean isReplicatesBack,
            boolean isOffline) throws AdmException {

        SqlUtils.replInsertConfig(dbCtx, configUid, configId, Constants.REPL_ITEM_CLASS, revision, null);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.replInsertConfigDetails(dbCtx, configUid, subordinateSiteUid, null, projectSpec, isEnabled, isTransfered, isReplicatesBack, subordinateSiteId, null, isOffline);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private boolean isSpecialBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_IS_SPECIAL_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private boolean isBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_IS_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private void validateBranchData(DBIO dbCtx, String configId, String revision, List branchList, long subordinateSiteUid,
            boolean isLocalSubordinate) throws AdmException {

        validateBranchList(dbCtx, branchList, subordinateSiteUid, isLocalSubordinate);

        for (Iterator it = branchList.iterator(); it.hasNext();) {
            AdmObject branchObj = (AdmObject) it.next();
            String branchName = branchObj.getId();

            // check if this branch has already been defined for this replication config
            boolean isAssigned = false;
            if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)) {
                isAssigned = isSpecialBranchAssigned(dbCtx, Constants.REPL_ALL_LOCAL_BRANCHES_UID, configId, revision,
                        Constants.REPL_ITEM_CLASS);
            } else if (branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
                isAssigned = isSpecialBranchAssigned(dbCtx, Constants.REPL_ALL_NAMED_BRANCHES_UID, configId, revision,
                        Constants.REPL_ITEM_CLASS);
            } else {
                long branchUid = getBranchUid(dbCtx, branchName);
                isAssigned = isBranchAssigned(dbCtx, branchUid, configId, revision, Constants.REPL_ITEM_CLASS);
            }

            if (isAssigned) {
                throw new DimAlreadyExistsException("Error: the branch name " + branchName
                        + "is already defined for configuration " + configId + ".");
            }
        }
    }

    private void insertBranchData(DBIO dbCtx, List branchList, long configUid) throws AdmException {

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        for (Iterator it = branchList.iterator(); it.hasNext();) {
            AdmObject branchObj = (AdmObject) it.next();
            String branchName = branchObj.getId();

            long relUid = getNewUid(dbCtx);
            long branchUid = getBranchUid(dbCtx, branchName);
            if (branchUid == -1) {
                throw new DimNotExistsException("Error: branch " + branchName + " does not exist.");
            }

            SqlUtils.replAssignBranchToConfig(dbCtx, relUid, configUid, branchUid, userName);
            dbCtx.write(DBIO.DB_DONT_COMMIT);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
        }
    }

    private void validateBranchList(DBIO dbCtx, List branchList, long subordinateSiteUid, boolean isLocalSubordinate)
            throws AdmException {

        Cmd cmd = AdmCmd.getCmd("_internal_validate_branch_list");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, dbCtx);
        cmd.setAttrValue(CmdArguments.BRANCHES, branchList);

        if (!isLocalSubordinate) {
            cmd.setAttrValue(CmdArguments.REPL_BASEDB_UID, new Long(subordinateSiteUid));
            cmd.setAttrValue(CmdArguments.REPL_IS_REMOTE, Boolean.TRUE);
        }
        cmd.execute();
    }

    private long getMasterConfigUid(String configId, int repClass) throws AdmException {

        DBIO dbCtx = new DBIO(wcm_sql.REPL_MASTER_CONFIG_QUERY_UID);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.readStart();
        long configUid = dbCtx.read() ? dbCtx.getLong(1) : -1;
        dbCtx.close();
        return configUid;
    }

    private boolean isLocalReplConfig(DBIO dbCtx, long configUid, int replClass, long siteUid) throws AdmException {

        boolean isOwned = false;
        if (dbCtx != null) {
            dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(replClass);
            dbCtx.bindInput(siteUid);
            dbCtx.readStart();
            isOwned = dbCtx.read(DBIO.DB_DONT_CLOSE);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
        } else {
            dbCtx = new DBIO(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(replClass);
            dbCtx.bindInput(siteUid);
            dbCtx.readStart();
            isOwned = dbCtx.read();
            dbCtx.close();
        }
        return isOwned;
    }

    private long getBranchUid(DBIO dbCtx, String branchName) throws AdmException {

        long branchUid = -1;
        if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_LOCAL_BRANCHES_UID;
        } else if (branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_NAMED_BRANCHES_UID;
        } else {
            DRSClientSysObjAttrUtils drs = new DRSClientSysObjAttrUtils(DRSClientSysObjAttrUtils.SysObjAttrUtilsQueryContext.GetAdmUids);
            drs.setObjClass(DRSClientSysObjAttrUtils.SYSOBJ_NAMED_BRANCH);
            drs.setAdmId(branchName);
            DRSUtils.execute(drs);

            if (drs.hasData() && (drs.getAdmUids() != null) && (drs.getAdmUids().length > 0)) {
            	branchUid = drs.getAdmUids()[0];
            }
        }
        return branchUid;
    }
}
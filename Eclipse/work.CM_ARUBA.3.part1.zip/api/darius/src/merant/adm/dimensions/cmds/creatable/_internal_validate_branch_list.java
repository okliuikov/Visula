/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.serena.dmnet.drs.DRSClientSysObjAttrUtils;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.DmCfgConstants;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidBranchException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.SpecialCharacters;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to validate a branch list for an item replication configuration. An exception will be raised
 * if the branch list contains an invalid branch object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>DBIO_QUERY {DBIO}</dt><dd>DBIO context</dd>
 *  <dt>BRANCHES{List}</dt><dd>List of Branch objects to validate</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>null</dd>
 * </dl></code>
 * @author Vadym Krevs
 */

public class _internal_validate_branch_list extends DBIOCmd {
    public _internal_validate_branch_list() throws AttrException {
        super();
        setAlias("_internal_validate_branch_list");
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, true, DBIO.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPL_BASEDB_UID, false, new Long(0), Long.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPL_IS_REMOTE, false, Boolean.FALSE, Boolean.class));
    }

    List branchList;
    DBIO dbCtx;
    long baseDbUid;
    boolean isRemote;

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        validateCommandParameters();

        validateBranches();

        return null;
    }

    private void validateCommandParameters() throws DimBaseException, AdmException {

        branchList = (List) getAttrValue(CmdArguments.BRANCHES);
        dbCtx = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        baseDbUid = ((Long) getAttrValue(CmdArguments.REPL_BASEDB_UID)).longValue();
        isRemote = ((Boolean) getAttrValue(CmdArguments.REPL_IS_REMOTE)).booleanValue();
    }

    /**
     * Validates branch ownership and existence
     * @throws DimBaseException
     * @throws AdmException
     */
    private void validateBranches() throws DimBaseException, AdmException {

        Set branches = null;
        Cmd cmd = AdmCmd.getCmd("GetSymbol");
        cmd.setAttrValue("symbol", DmCfgConstants.DM_REPL_NO_PROJECT_BRANCH_CHECK);
        String val = (String) cmd.execute();
        boolean checkBranchOwnedBySite = (val == null || val.length() == 0) ? true : false; // flag not set == check
        for (Iterator it = branchList.iterator(); it.hasNext();) {
            AdmObject branchObj = (AdmObject) it.next();
            String branchName = branchObj.getId();

            if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)
                    || branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
                continue;
            }

            if (isRemote) {
                if (isBranchOwnedBySite(branchName, baseDbUid, checkBranchOwnedBySite) || isBranchShared(branchName)) {
                    if (!relateBranch(branchName, baseDbUid)) {
                        throw new DimInvalidBranchException("Error: unable to create branch name.");
                    }
                } else {
                    throw new DimInvalidBranchException("Error: branch " + branchName + " is invalid.");
                }
            } else {
                if (branches == null) {
                    branches = fetchBranches();
                }
                if (branches != null && !branches.contains(branchName)) {
                    throw new DimInvalidBranchException("Error: branch " + branchName + " is not a valid branch.");
                }
            }
        }
    }

    /**
     * Returns a set containing branch names of all branches registered in the base database
     * @return Set of branch names
     * @throws AdmException
     */
    private Set fetchBranches() throws AdmException {
        // set up a set of branch names assigned to this workset
        Set branchNames = null;

        DRSClientSysObjAttrUtils drs = new DRSClientSysObjAttrUtils(DRSClientSysObjAttrUtils.SysObjAttrUtilsQueryContext.GetAdmParams);
        drs.setObjClass(DRSClientSysObjAttrUtils.SYSOBJ_NAMED_BRANCH);
        DRSUtils.execute(drs);

        if (drs.hasData() && drs.getAdmIds() != null && drs.getAdmIds().length > 0) { 
            branchNames = new HashSet(); 
            for (String id: drs.getAdmIds()) { 
                branchNames.add(id); 
            } 
        }
        return branchNames;
    }

    /**
     * Checks whether a branch is owned by the specified site
     * @param branchName
     * @param siteUid
     * @param checkBranchOwnedBySite
     * @return boolean
     * @throws AdmException
     */
    private boolean isBranchOwnedBySite(String branchName, long siteUid, boolean checkBranchOwnedBySite) throws AdmException {
        if (!checkBranchOwnedBySite) {
            return true; // not need check
        }

        if (getBranchUid(dbCtx, branchName) == -1) {
            return true;
        }

        long branchOwnerSiteUid = getBranchSiteUid(branchName);

        if (branchOwnerSiteUid == -1 || siteUid == -1) {
            return false;
        }

        if (branchOwnerSiteUid == siteUid) {
            return true;
        }

        if (!isBranchShared(branchName)) {
            throw new DimInvalidBranchException("Error: the branch " + branchName + " is owned by the base database "
                    + getBaseDbId(branchOwnerSiteUid) + ".");
        }
        return true;
    }

    private String getBaseDbId(long dbUid) throws AdmException {

        dbCtx.resetMessage(wcm_sql.QUERY_NETBASEDB_SENDERID);
        dbCtx.bindInput(dbUid);
        dbCtx.readStart();
        String dbName = null;
        if (dbCtx.read(DBIO.DB_DONT_CLOSE)) {
            dbName = dbCtx.getString(1);
        }
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        if (dbName == null) {
            throw new DimNotExistsException("Error: invalid base database UID " + dbUid);
        }

        return dbName;
    }

    /**
     * Checks if a branch is shared
     * @param dbCtx
     *            DBIO context
     * @param branchName
     *            branch name to check
     * @return boolean true if branch is shared, false otherwise
     * @throws AdmException
     */
    private boolean isBranchShared(String branchName) throws AdmException {

        if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)
                || branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
            return false;
        }

        dbCtx.resetMessage(wcm_sql.REPL_IS_BRANCH_SHARED);
        dbCtx.bindInput(branchName);
        dbCtx.readStart();
        boolean isShared = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return isShared;
    }

    private boolean relateBranch(String branchName, long baseDbUid) throws AdmException {

        // FUNCTION relate_branch(branchname varchar2, remotedb number) RETURN boolean IS
        // counter number := 0;
        // BEGIN
        if (branchName == null || branchName.length() == 0) {
            return false;
        }

        if (StringUtils.containsSpecialChars(branchName, SpecialCharacters.INVALID_BRANCH_CHARS)) {
            throw new DimInvalidBranchException("Error: branch name contains invalid characters "
                    + SpecialCharacters.INVALID_BRANCH_CHARS + ".");
        }

        dbCtx.resetMessage(wcm_sql.REPL_CREATE_BRANCH);
        dbCtx.bindInput(branchName);
        dbCtx.bindInput(AdmCmd.getCurRootObj(User.class).getId());
        dbCtx.bindInput(baseDbUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_IS_BRANCH_VALID);
        dbCtx.bindInput(branchName);
        dbCtx.readStart();
        boolean isValid = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return isValid;
    }

    private long getBranchSiteUid(String branchName) throws AdmException {

        if (branchName == null || branchName.length() == 0) {
            return -1;
        }

        long siteUid = -1;

        dbCtx.resetMessage(wcm_sql.QUERY_BRANCH_SERNDER_UID);
        dbCtx.bindInput(branchName);
        dbCtx.readStart();
        if (dbCtx.read(DBIO.DB_DONT_CLOSE)) {
            siteUid = dbCtx.getLong(1);
        }
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        if (siteUid == -1) {
            NetBaseDatabase localDb = (NetBaseDatabase) AdmCmd.getCurRootObj(NetBaseDatabase.class);
            if (localDb != null) {
                siteUid = ((AdmUidObject) localDb).getAdmUid().getUid();
            }
        }

        return siteUid;
    }

    private long getBranchUid(DBIO dbCtx, String branchName) throws AdmException {
        long branchUid = -1;
        
        DRSClientSysObjAttrUtils drs = new DRSClientSysObjAttrUtils(DRSClientSysObjAttrUtils.SysObjAttrUtilsQueryContext.GetAdmUids);
        drs.setObjClass(DRSClientSysObjAttrUtils.SYSOBJ_NAMED_BRANCH);
        drs.setAdmId(branchName);
        DRSUtils.execute(drs);

        if (drs.hasData() && (drs.getAdmUids() != null) && (drs.getAdmUids().length > 0)) {
        	branchUid = drs.getAdmUids()[0];
        }

        return branchUid;
    }
}

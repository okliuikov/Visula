/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will authorize you to access a remote Dimensions user file area.
 * It will also allow the remote Dimensions user to change their password on that node.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>HOST {String}<dt><dd>The logical node name of the remote machine</dd>
 *  <dt>USER_NAME {String}<dt><dd>The operating system user name</dd>
 *  <dt>USER_PASSWORD {String}<dt><dd>The password of the operating system user</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>USER_NEW_PASSWORD {String}</dt><dd>The new password of the operating system user</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * 
 * @author Peter Raymond
 */
public class AuthCmd extends RPCExecCmd {
    public AuthCmd() throws AttrException {
        super();
        setAlias(Server.AUTH);
        setAttrDef(new CmdArgDef(CmdArguments.HOST, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_PASSWORD, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_NEW_PASSWORD, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.IDM_TOOL, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DELETE, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.GLOBAL, false, Boolean.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String host = (String) getAttrValue(CmdArguments.HOST);
        String user = (String) getAttrValue(CmdArguments.USER_NAME);
        String password = (String) getAttrValue(CmdArguments.USER_PASSWORD);
        String newPassword = (String) getAttrValue(CmdArguments.USER_NEW_PASSWORD);
        String idm_tool = (String) getAttrValue(CmdArguments.IDM_TOOL);
        Boolean delete = (Boolean) getAttrValue(CmdArguments.DELETE);
        Boolean global = (Boolean) getAttrValue(CmdArguments.GLOBAL);

        _cmdStr = "AUTH";
        if (user != null && user.length() > 0) {
        	_cmdStr += " /USER=";
        	_cmdStr += Encoding.escapeSpec(user);
        }
        if (password != null && password.length() > 0) {
        	_cmdStr += " /PASSWORD=";
        	_cmdStr += Encoding.escapeSpec(password);
        }
        if (newPassword != null && newPassword.length() > 0) {
            _cmdStr += " /NEW_PASSWORD=";
            _cmdStr += Encoding.escapeSpec(newPassword);
        }
        if (host != null && host.length() > 0) {
            _cmdStr += " /NETWORK_NODE=";
            _cmdStr += Encoding.escapeSpec(host);
        }
        if (idm_tool != null && idm_tool.length() > 0) {
            _cmdStr += " /IDM_TOOL=";
            _cmdStr += Encoding.escapeSpec(idm_tool);
        }
        if (delete != null && delete.booleanValue()) {
            _cmdStr += " /DELETE";
        }
        if (global != null && global.booleanValue()) {
            _cmdStr += " /GLOBAL";
        }

        password = null;
        newPassword = null;

        return executeRpc();
    }
}

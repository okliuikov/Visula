/*
 * Copyright (C) 2009, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.serena.dmnet.LCNetClnt;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Return the specified attributes of directory entries in the specified remote directory.
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>filePaths {List}</dt>
 *      <dd>
 * 
 *      </dd>
 *  <dt>metadataStrings {List}</dt>
 *      <dd>
 * 
 *      </dd>
 * </dl></code> <b>Returns:</b>
 * @author Pete Bate
 */
public class RPCWriteMetadataCmd extends RPCCmd {

    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCWriteMetadataCmd() throws AttrException {
        super();
        setAlias("RPCWriteMetadataCmd");
        AddArgument("cmd", "RPCWriteMetadataCmd");
        setAttrDef(new CmdArgDef(CmdArguments.FULL_FILEPATHS, true, ArrayList.class));
        setAttrDef(new CmdArgDef(CmdArguments.METADATA_STRINGS, true, ArrayList.class));
        setAttrDef(new CmdArgDef(CmdArguments.DELETE_METADATA, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws DimConnectionException {

        Object result = Boolean.FALSE;
        try {
            List filepaths = (ArrayList) getAttrValue(CmdArguments.FULL_FILEPATHS);
            List metaStrings = (ArrayList) getAttrValue(CmdArguments.METADATA_STRINGS);
            boolean deleteMetadata = ((Boolean) getAttrValue(CmdArguments.DELETE_METADATA)).booleanValue();
            if (filepaths == null || metaStrings == null || filepaths.size() != metaStrings.size()) {
                return null;
            }
            LCNetClnt con = getSession().getConnection();
            if (filepaths.size() == 1) {
                if (con.rpcRFWriteMetadata((String) filepaths.get(0), (String) metaStrings.get(0), deleteMetadata)) {
                    result = Boolean.TRUE;
                }
            } else {
                int ret = con.rpcRFWriteMetadataEx((String[]) filepaths.toArray(new String[filepaths.size()]),
                        (String[]) metaStrings.toArray(new String[metaStrings.size()]));
                if (ret == filepaths.size()) {
                    result = Boolean.TRUE;
                }
            }

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return result;
    }
}
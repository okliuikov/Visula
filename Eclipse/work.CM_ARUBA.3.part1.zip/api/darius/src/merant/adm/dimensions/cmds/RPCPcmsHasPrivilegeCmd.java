/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command determines whether a user has the specified privilege for the object and product
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>USER_NAME {String}<dt><dd>The user to query privilege rules for.</dd>
 *  <dt>PRIVILEGE_UID {Integer}<dt><dd>Privilege ID</dd>
 *  <dt>PRIVILEGE_RULE_PRODUCT {String}<dt><dd>Product name</dd>
 *  <dt>PRIVILEGE_OBJ_TYPE {Integer}<dt><dd>Type of object, change doc, item etc</dd>
 *  <dt>ADM_UID {Long}<dt><dd>The adm object's uid to query for.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>true/false boolean</dd>
 * </dl></code> Created 28/11/2005.
 * @author Paul Smith
 */

public class RPCPcmsHasPrivilegeCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCPcmsHasPrivilegeCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("HasPrivilege");
        AddArgument("cmd", "HasPrivilege");

        setAttrDef(new CmdArgDef(AdmAttrNames.USER_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_UID, true, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_RULE_PRODUCT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_OBJ_TYPE, true, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ADM_UID, true, Long.class));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            boolean hasPrivilege = getSession().getConnection().rpcPcmsHasPrivilege((String) getAttrValue(AdmAttrNames.USER_NAME),
                    ((Integer) getAttrValue(AdmAttrNames.PRIVILEGE_UID)).intValue(),
                    (String) getAttrValue(AdmAttrNames.PRIVILEGE_RULE_PRODUCT),
                    ((Integer) getAttrValue(AdmAttrNames.PRIVILEGE_OBJ_TYPE)).intValue(),
                    ((Long) getAttrValue(AdmAttrNames.ADM_UID)).longValue());

            return Boolean.valueOf(hasPrivilege);

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

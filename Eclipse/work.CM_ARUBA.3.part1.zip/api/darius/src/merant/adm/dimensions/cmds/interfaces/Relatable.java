/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for relatable commands.
 * <p>
 * This applies to any dimensions object that can harbour a relationship with another dimensions object.<br>
 * This is a far reaching command and many former command beans have been integrated into this common polymorphic model. For
 * instance, GetDirectoryItemsCmd is now, QUERY_CHILDREN with a DimDirectory parent and looking for Item.class children.
 * @author Floz
 */
public interface Relatable {
    public static final String DEFINE_RELATIONSHIP = "Relatable.DefineRelationship";
    public static final String IS_RELATED = "Relatable.IsRelated";
    public static final String QUERY_CHILD_COUNT = "Relatable.QueryChildCount";
    public static final String QUERY_CHILD = "Relatable.QueryChild";
    public static final String QUERY_CHILDREN = "Relatable.QueryChildren";
    public static final String QUERY_NEXT_SIBLING = "Relatable.QueryNextSibling";
    public static final String QUERY_PARENT_COUNT = "Relatable.QueryParentCount";
    public static final String QUERY_PARENT = "Relatable.QueryParent";
    public static final String QUERY_PARENTS = "Relatable.QueryParents";
    public static final String QUERY_PREVIOUS_SIBLING = "Relatable.QueryPreviousSibling";
    /** Queries a single object related to the primary object */
    public static final String QUERY_REL = "Relatable.QueryRel";
    /** Queries the potential RelationshipTypes for a pair of Dimensions objects */
    public static final String QUERY_REL_TYPES = "Relatable.QueryRelTypes";
    /** Queries the Relationship object that binds the primary and secondary objects */
    public static final String QUERY_RELATIONSHIP = "Relatable.QueryRelationship";
    /** Queries all Relationship objects that bind the primary and secondary objects */
    public static final String QUERY_RELATIONSHIPS = "Relatable.QueryRelationships";
    /** Queries all objects related to the primary object */
    public static final String QUERY_RELS = "Relatable.QueryRels";
    /** Queries the potentially relatable Types */
    public static final String QUERY_VALID_OBJTYPES = "Relatable.QueryValidObjTypes";
    public static final String RELATE = "Relatable.Relate";
    public static final String UNRELATE = "Relatable.Unrelate";
    public static final String RELATE_PROJECTSTAGE_TO_POLICY = "Relatable.RelateProjectStageToPolicy";
    public static final String RELATE_CMD_TO_SCHEDULED_JOB = "Relatable.RelateCmdToScheduledJob";

    public static final String QUERY_PRODUCTS_WITHOUT_RULESET = "Relatable.QueryProductsWithoutRuleSet";
    public static final String QUERY_PRODUCTS_CHILD_UPLOAD_PROJECTS = "Relatable.QueryProductsChildUploadProjects";

    /** Queries area versions for objects */
    public static final String QUERY_AREA_VERSIONS = "Relatable.QueryAreaVersions";
    /** Queries objects for area versions */
    public static final String QUERY_AREA_VERSIONS_OBJECTS = "Relatable.QueryAreaVersionsObjects";

}

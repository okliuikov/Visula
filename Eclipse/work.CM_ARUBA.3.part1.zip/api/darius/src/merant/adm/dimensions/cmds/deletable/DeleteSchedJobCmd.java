/**
 *
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ScheduledJob;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command deletes specified scheduled job.
 * 
 * <b>Mandatory Arguments:</b> <code>
 * <dl>
 * <dt>ID {String}</dt><dd>Scheduled Job ID name</dd>
 * </dl>
 * </code> <br>
 * <b>Returns:</b> <code>
 * <dl>
 * <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl>
 * </code>
 * 
 * @author kberezovchuk
 * 
 */
public class DeleteSchedJobCmd extends RPCExecCmd {

    public DeleteSchedJobCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE_SCHEDULED_JOB);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseException, AdmException {
        validateAllAttrs();

        String jobID = (String) getAttrValue(AdmAttrNames.ID);

        if (jobID == null || jobID.trim().length() == 0) {
            AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
            if (admObj instanceof ScheduledJob) {
                jobID = admObj.getAdmSpec().getSpec();
            }
        }
        if (jobID == null || jobID.trim().length() == 0) {
            throw new AttrException("Scheduled Job is not specified");
        }

        StringBuffer sb = new StringBuffer("DSJ ");
        sb.append(Encoding.escapeDMCLI(jobID));

        _cmdStr = sb.toString();
        return executeRpc();
    }

}

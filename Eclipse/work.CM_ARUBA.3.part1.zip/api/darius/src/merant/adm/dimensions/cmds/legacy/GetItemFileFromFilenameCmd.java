/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * PVCS:GETITEMFILEFROMFILENAMECM.A-SRC;impulse#1
 * Description:
 * Item GETITEMFILEFROMFILENAMECM.A
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.legacy;

import java.util.List;
import java.util.Vector;

import com.serena.dmnet.RPC;
import com.serena.dmnet.drs.DRSClientGetItemFileFromFilename;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimItemFileNotFoundException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.FileUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Legacy command to obtain an ItemFile given it's filename.
 * <p>
 * This command requires integration into the main framework. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>FILENAME {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ATTRIBUTE_NAMES {String/List}<dt><dd>Attribute name or List of attribute names to query</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions work set container for objects</dd>
 *  <dt>BASELINE {Baseline}<dt><dd>Dimensions baseline container for objects</dd>
 *  <dt>REVISION {String}<dt><dd>Revision of the new item</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmObject}<dt><dd>Populated ItemFile object represented by the specified filename</dd>
 * </dl></code>
 * @author Floz
 */
public class GetItemFileFromFilenameCmd extends DBIOCmd {
    public GetItemFileFromFilenameCmd() throws AttrException {
        super();
        setAlias("GetItemFileFromFilenameCmd");
        setAttrDef(new CmdArgDef(CmdArguments.FILENAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTE_NAMES, true));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, false, Baseline.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REVISION, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ATTRIBUTE_NAMES)) {
            if ((!(attrValue instanceof String)) && (!(attrValue instanceof List))) {
                throw new AttrException("Error: Attribute name should be a singular String or a List of String's", attrDef,
                        attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        String filename = (String) getAttrValue(CmdArguments.FILENAME);
        WorkSet workSet = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        Baseline baseline = (Baseline) getAttrValue(CmdArguments.BASELINE);
        String revision = (String) getAttrValue(AdmAttrNames.REVISION);
        if (revision == null) {
            revision = "%";
        }

        List attrNames = null;
        if (getAttrValue(CmdArguments.ATTRIBUTE_NAMES) instanceof String) {
            attrNames = new Vector();
            attrNames.add(getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
        } else {
            attrNames = new Vector((List) getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
        }

        AdmUid wsetAdmUid = null;
        AdmUid baselineAdmUid = null;
        if (baseline != null) {
            wsetAdmUid = baseline.getAdmUid();
            baselineAdmUid = baseline.getAdmUid();
        } else if (workSet != null) {
            wsetAdmUid = workSet.getAdmUid();
        } else {
            wsetAdmUid = DimSystem.getSystem().getSessionBean().getWorkSetUid();
        }

        if (wsetAdmUid == null) {
            wsetAdmUid = new AdmUid(Constants.GLOBAL_WSET_UID, WorkSet.class);
        }

        // Validate that no attrs are being
        // asked for that are not supported
        attrNames.remove(AdmAttrNames.ADM_UID);
        attrNames.remove(AdmAttrNames.PARENT_UID);
        attrNames.remove(AdmAttrNames.PARENT_DIR_NAME);
        attrNames.remove(AdmAttrNames.PARENT_DIR_UID);
        attrNames.remove(AdmAttrNames.PRODUCT_NAME);
        attrNames.remove(AdmAttrNames.ID);
        attrNames.remove(AdmAttrNames.VARIANT);
        attrNames.remove(AdmAttrNames.TYPE_NAME);
        attrNames.remove(AdmAttrNames.REVISION);
        attrNames.remove(AdmAttrNames.ITEMFILE_FILENAME);
        attrNames.remove(AdmAttrNames.DIMFILE_LENGTH);
        attrNames.remove(AdmAttrNames.ITEM_FILE_VERSION);
        attrNames.remove(AdmAttrNames.CREATE_DATE);
        attrNames.remove(AdmAttrNames.UPDATE_DATE);
        attrNames.remove(AdmAttrNames.DESCRIPTION);
        attrNames.remove(AdmAttrNames.USER_NAME);
        attrNames.remove(AdmAttrNames.ITEM_FILE_VERSION);
        if (attrNames.size() > 0) {
            throw new DimInvalidAttributeException((String) attrNames.get(0));
        }

        String wsFile = FileUtils.getFilename(filename);
        String wsDir = FileUtils.convertToUniDir(FileUtils.getDirectory(filename));
        if (wsDir != null) {
            if (wsDir.charAt((wsDir.length() - 1)) != Constants.DIRPATH_SEP) {
                wsDir = wsDir + Constants.DIRPATH_SEP;
            }

            if (wsDir.charAt(0) == Constants.DIRPATH_SEP) {
                wsDir = wsDir.substring(1);
            }

            if (wsDir.length() == 0) {
                wsDir = null;
            }
        }

        DRSClientGetItemFileFromFilename drsClientGetItemFileFromFilename = new DRSClientGetItemFileFromFilename(
                DRSUtils.getLCNetClntObject());
        drsClientGetItemFileFromFilename.setBaselineUid(baselineAdmUid == null ? Constants.INVALID_UID : baselineAdmUid.getUid());
        drsClientGetItemFileFromFilename.setWorksetUid(wsetAdmUid.getUid());
        drsClientGetItemFileFromFilename.setRevision(revision);
        drsClientGetItemFileFromFilename.setWsFile(wsFile);
        drsClientGetItemFileFromFilename.setWsDir(wsDir);

        DRSQuery drsQuery = new DRSQuery(drsClientGetItemFileFromFilename);
        DRSOutputDataExtractor drsOutputDataExtractor = drsQuery.execute();

        if (drsOutputDataExtractor.hasRPCExecutionFailed()) {
            throw new DRSException("Error during call of DRS function " + DRSClientGetItemFileFromFilename.dataRequestId
                    + " via RPC(" + RPC.RPC_DATA_REQUEST + ")");
        } else if (!drsOutputDataExtractor.isResultEmpty()) {
            ItemFile itemFile = new ItemFile(new AdmUid(drsOutputDataExtractor.getIntValues(DRSParams.OBJ_UID)[0], ItemFile.class,
                    wsetAdmUid));
            itemFile.setAdmSpec(new AdmSpec(drsOutputDataExtractor.getStringValues(DRSParams.ITEM_SPEC)[0], ItemFile.class,
                    wsetAdmUid));
            itemFile.setAttrValue(AdmAttrNames.PARENT_UID, new AdmUid(drsOutputDataExtractor.getIntValues(DRSParams.DIR_UID)[0],
                    DimDirectory.class, wsetAdmUid));
            itemFile.setAttrValue(AdmAttrNames.PARENT_DIR_UID, new AdmUid(
                    drsOutputDataExtractor.getIntValues(DRSParams.DIR_UID)[0], DimDirectory.class, wsetAdmUid));
            itemFile.setAttrValue(AdmAttrNames.PARENT_DIR_NAME, drsOutputDataExtractor.getStringValues(DRSParams.FULL_PATH)[0]);
            itemFile.setAttrValue(AdmAttrNames.ITEMFILE_FILENAME, wsFile);
            itemFile.setAttrValue(AdmAttrNames.DIMFILE_LENGTH,
                    new Integer(drsOutputDataExtractor.getIntValues(DRSParams.LENGTH)[0]));
            itemFile.setAttrValue(AdmAttrNames.ITEM_FILE_VERSION,
                    new Integer(drsOutputDataExtractor.getIntValues(DRSParams.FILE_VERSION)[0]));
            itemFile.setAttrValue(AdmAttrNames.CREATE_DATE, drsOutputDataExtractor.getStringValues(DRSParams.CREATED_DATE_TIME)[0]);
            itemFile.setAttrValue(AdmAttrNames.UPDATE_DATE, drsOutputDataExtractor.getStringValues(DRSParams.UPDATED_DATE_TIME)[0]);
            itemFile.setAttrValue(AdmAttrNames.DESCRIPTION, drsOutputDataExtractor.getStringValues(DRSParams.DESCRIPTION)[0]);
            itemFile.setAttrValue(AdmAttrNames.USER_NAME, drsOutputDataExtractor.getStringValues(DRSParams.USER_NAME)[0]);
            itemFile.setAttrValue(AdmAttrNames.ITEM_FILE_VERSION, drsOutputDataExtractor.getIntValues(DRSParams.FILE_VERSION)[0]);
            itemFile.setAttrValue(AdmAttrNames.ITEM_IS_EXTRACTED, drsOutputDataExtractor.getStringValues(DRSParams.EXTRACTED)[0]);
            return itemFile;
        } else {
            throw new DimItemFileNotFoundException();
        }

    }
}

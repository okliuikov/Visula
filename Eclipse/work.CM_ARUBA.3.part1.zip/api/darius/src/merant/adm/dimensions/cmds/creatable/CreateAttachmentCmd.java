/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Attachment;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Attachment.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>File identifier for the new attachment</dd>
 *  <dt>USER_FILE {String}</dt><dd>File containing the attachment body</dd>
 *  <dt>ADM_SCOPE_OBJECT {AdmObject}</dt><dd>The ChangeDocument to attach to for scope</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}</dt><dd>The description for the new attachment</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateAttachmentCmd extends RPCExecCmd {
    public CreateAttachmentCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_SCOPE_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, "", String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_SCOPE_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument)) {
                throw new AttrException("Error: Scope object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        AdmObject scopeObject = (AdmObject) getAttrValue(CmdArguments.ADM_SCOPE_OBJECT);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);

        StringBuffer sb = new StringBuffer("UC ");
        sb.append(Encoding.escapeSpec(scopeObject.getAdmSpec().getSpec()));
        sb.append(" /ADD_ATTACHMENTS=([FILENAME=");
        sb.append(Encoding.escapeSpec(id));
        sb.append(", USER_FILENAME=");
        sb.append(Encoding.escapeSpec(userFile));
        sb.append(", DESCRIPTION=");
        sb.append(Encoding.escapeSpec(desc));
        sb.append("])");
        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc(), new AdmSpec(id, Attachment.class));
        return retResult;
    }
}

/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.creatable;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.DBLimits;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions local attribute definition and either
 * insert a new global atribute definition or update attributes of an already
 * existing global attribute definition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new global attribute definition</dd>
 *  <dt>TYPE {AdmObject}<dt><dd>Dimensions object type defining attribute scope</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ATTRDEF_ATTRNO {Integer}<dt><dd>Attribute No. Must be unique within the specified scope. If omitted, an automatic number shall be generated</dd>
 *  <dt>ATTRDEF_ATTRTYPE {Integer}<dt><dd>Attribute type. See {@link merant.adm.dimensions.server.core.Constants Constants}</dd>
 *  <dt>ATTRDEF_DATATYPE{Class}<dt><dd>Attribute data type. java.lang.String {default}, java.lang.Number, java.util.Date, java.lang.Integer</dd>
    <dt>ATTRDEF_DISPLAYLENGTH {Integer}<dt><dd>Attribute display length, Default - 25</dd>
 *  <dt>ATTRDEF_ACTUALWIDTH {Integer}<dt><dd>Attribute max display length, Default - 25</dd>
 *  <dt>ATTRDEF_IS_DISPLAY{Boolean}<dt><dd>Whether the attribute is visible to the GUIs (true) or only programmable (false). Default - true</dd>
 *  <dt>ATTRDEF_IS_CATDISP{Boolean}<dt><dd>Whether the attribute can be configured to be visible to pending GUI displays. Default - true</dd>
 *  <dt>ATTRDEF_MVATYPE {Integer}<dt><dd>Attribute MVA type. Reserved.</dd>
 *  <dt>ATTRDEF_PROMPT {String}<dt><dd>User prompt. This argument is required if ATTRDEF_IS_DISPLAY is set to true.</dd>
 *  <dt>ATTRDEF_DISPLAYORDER {Integer}<dt><dd>Order of display.</dd>
 *  <dt>ATTRDEF_DISPLAYWIDTH {Integer}<dt><dd>The width of the edit attribute box in a client GUI</dd>
 *  <dt>ATTRDEF_DISPLAYHEIGHT {Integer}<dt><dd>The height of the edit attribute box in a client GUI</dd>
 *  <dt>ATTRDEF_DEFAULT_VALUE {String}<dt><dd>Default value.</dd>
 *  <dt>ATTRDEF_HELP_MESSAGE {String}<dt><dd>Help message.</dd>
 *  <dt>ATTRDEF_KEEP_UPDATE_HISTORY{Boolean}<dt><dd>Whether to keep history of updates made to this attribute. Default - false</dd>
 *  <dt>ATTRDEF_IS_SENSITIVE{Boolean}<dt><dd>Whether attribute is sensitive. Default - false</dd>
 *  <dt>ATTRDEF_IS_ALLREVS{Boolean}<dt><dd>Whether all revision of an object should have the same value of the attribute. Does not apply to user types. Default - false</dd>
 *  <dt>ATTRDEF_IS_PREVREV{Boolean}<dt><dd>Whether the previous revision of an object should have the same value of the attribute. Does not apply to user types. Default - false</dd>
 *  <dt>ATTRDEF_IS_MANDATORY{Boolean}<dt><dd>Whether the attribute is mandarory. Only applies to user attributes. Default - false</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateLocalAttrDefCmd extends RPCExecCmd {

    public CreateLocalAttrDefCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_ATTRNO, false, new Integer(-1), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_ATTRTYPE, false, new Integer(Constants.ATTR_TYPE_SFSV), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_DATATYPE, false, String.class, Class.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_DISPLAYLENGTH, false, new Integer(25), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_ACTUALWIDTH, false, new Integer(25), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_DISPLAY, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_CATDISP, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_MVATYPE, false, new Integer(Constants.MVA_NULL), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_PROMPT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_DISPLAYORDER, false, new Integer(1), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_DISPLAYWIDTH, false, new Integer(25), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_DISPLAYHEIGHT, false, new Integer(1), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_DEFAULT_VALUE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_HELP_MESSAGE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_ALLREVS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_PREVREV, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_KEEP_UPDATE_HISTORY, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_SENSITIVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_MANDATORY, false, Boolean.FALSE, Boolean.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_START_FIXED_DATE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_END_FIXED_DATE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_START_DAYS, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_END_DAYS, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_LINK_AS_START_TO, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_LINK_AS_END_TO, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    /**
     * @see merant.adm.dimensions.cmds.DBIOCmd#validateAttr(String, AttrDef, Object)
     */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(AdmAttrNames.TYPE)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // check role
        AdmObject typeObj = (AdmObject) getAttrValue(AdmAttrNames.TYPE);
        final long typeUid = ((AdmUidObject) typeObj).getAdmUid().getUid();

        List attrs = AdmHelperCmd.getAttributeValues(typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        final String productName = (String) attrs.get(0);
        final String typeName = (String) attrs.get(1);
        final Class scopeClass = (Class) attrs.get(2);

        if (User.class.equals(scopeClass)) {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_USERMAN")) {
                throw new DimNoPrivilegeException("ADMIN_USERMAN");
            }
        } else {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
                throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
            }
        }

        // extract all attributes
        final String attrName = ValidationHelper.validateAttrId((String) getAttrValue(AdmAttrNames.ID));
        final String userPrompt = ValidationHelper.validateAttrPrompt((String) getAttrValue(AdmAttrNames.ATTRDEF_PROMPT), true);
        final String defaultValue = ValidationHelper.validateDefaultAttrValue(
                (String) getAttrValue(AdmAttrNames.ATTRDEF_DEFAULT_VALUE), true);

        final String helpMessage = ValidationHelper.validateHelpMessage((String) getAttrValue(AdmAttrNames.ATTRDEF_HELP_MESSAGE),
                true);

        final Class attrDataType = (Class) getAttrValue(AdmAttrNames.ATTRDEF_DATATYPE);

        final int attrNumber = ((Integer) getAttrValue(AdmAttrNames.ATTRDEF_ATTRNO)).intValue();
        final int attrType = ((Integer) getAttrValue(AdmAttrNames.ATTRDEF_ATTRTYPE)).intValue();
        final int displayLength = ValidationHelper.validateDisplayLength((Integer) getAttrValue(AdmAttrNames.ATTRDEF_DISPLAYLENGTH))
                .intValue();
        final int maxLength = ValidationHelper.validateMaxLength((Integer) getAttrValue(AdmAttrNames.ATTRDEF_ACTUALWIDTH))
                .intValue();
        final int displayHeight = ValidationHelper.validateDisplayHeight((Integer) getAttrValue(AdmAttrNames.ATTRDEF_DISPLAYHEIGHT))
                .intValue();
        final int displayWidth = ValidationHelper.validateDisplayWidth((Integer) getAttrValue(AdmAttrNames.ATTRDEF_DISPLAYWIDTH))
                .intValue();

        final int mvaType = ((Integer) getAttrValue(AdmAttrNames.ATTRDEF_MVATYPE)).intValue();
        final int displayOrder = ((Integer) getAttrValue(AdmAttrNames.ATTRDEF_DISPLAYORDER)).intValue();

        final boolean isDisplayable = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_IS_DISPLAY)).booleanValue();
        final boolean isCatalog = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_IS_CATDISP)).booleanValue();
        boolean isAllRevisions = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_IS_ALLREVS)).booleanValue();
        boolean isPrevRevision = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_IS_PREVREV)).booleanValue();
        final boolean keepUpdateHistory = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_KEEP_UPDATE_HISTORY)).booleanValue();
        final boolean isSensitive = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_IS_SENSITIVE)).booleanValue();
        final boolean isMandatory = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_IS_MANDATORY)).booleanValue();

        if (User.class.equals(scopeClass) && attrType != Constants.ATTR_TYPE_SFSV) {
            throw new DimInvalidAttributeException("Error: only single-field, single-value attributes can be defined for users.");
        }

        final String typeFlag = TypeUtils.getTypeFlag(scopeClass);

        final String startFixedDate = (String) getAttrValue(AdmAttrNames.ATTRDEF_START_FIXED_DATE);
        final String endFixedDate = (String) getAttrValue(AdmAttrNames.ATTRDEF_END_FIXED_DATE);
        final String startDays = (String) getAttrValue(AdmAttrNames.ATTRDEF_START_DAYS);
        final String endDays = (String) getAttrValue(AdmAttrNames.ATTRDEF_END_DAYS);
        final String startLinkTo = (String) getAttrValue(AdmAttrNames.ATTRDEF_LINK_AS_START_TO);
        final String endLinkTo = (String) getAttrValue(AdmAttrNames.ATTRDEF_LINK_AS_END_TO);

        //
        // check if attribute has already been assigned to the object type
        //
        if (DoesExistHelper.localAttributeExists(attrName, typeUid)) {
            throw new DimAlreadyExistsException("Error: attribute " + attrName + " has already been assigned to the "
                    + TypeUtils.getClassName(scopeClass) + " type " + productName + ":" + typeName);
        }

        //
        // make sure that user prompt is specified if attribte is displayable
        //
        if (isDisplayable && ((userPrompt == null) || userPrompt.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: user prompt must be specified.");
        }

        //
        // default value length cannot exceed max attribute length
        //
        if ((defaultValue != null) && (defaultValue.length() > maxLength)) {
            throw new DimInvalidAttributeException(
                    "Error: the length of the supplied default value exceeds the maximum attribute length");
        }

        //
        // decide whether to ignore ALL_REVSIONS flag
        // NOTE: in 8.x schema we have both keep_history and all_revisions fields
        // KEEP_HISTORY applies to all object types;
        // ALL_REVISIONS applies only to item types and part types unless this is a $GENERIC:PRODUCT part type
        if (!(Part.class.equals(scopeClass) || Item.class.equals(scopeClass))) {
            // isAllRevisions flag applies only to Part types and Item types
            isAllRevisions = false;
            isPrevRevision = false;
        }
        // $GENERIC:PRODUCT part type does not support ALL_REVISIONS flag
        if (Part.class.equals(scopeClass) && Constants.GLOBAL_PRODUCT.equals(productName) && "PRODUCT".equals(typeName)) {
            isAllRevisions = false;
            isPrevRevision = false;
        }

        String mvaTypeFlag = null;
        if (mvaType != Constants.MVA_NULL) {
            mvaTypeFlag = getMVATypeStr(mvaType);
        }

        // Verify if global attribute definition is necessary.
        // Lookup attribute number of the attribute with the given name, if such attribute exists
        int globalAttrNo = findUsedAttrNo(attrName, typeFlag);

        if (-1 != attrNumber) {
            // check a user-supplied attribute number
            if (attrNumber <= 0)
                throw new DimInvalidAttributeException("Error: attribute number must be a positive number.");

            if (attrNumber != globalAttrNo && -1 != globalAttrNo)
                // the global attribute definition's attribute number does not match
                // the supplied local attribute definition's attribute number
                throw new DimInvalidAttributeException("Error: the attribute number of an existing attribute cannot be changed.");

            if (-1 == globalAttrNo)
                // there is no attribute with the given name
                // check if the supplied attribute number is unique
                if (attributeNumberExists(attrNumber, typeFlag))
                    throw new DimAlreadyExistsException("Error: attribute number " + attrNumber
                            + " is already used by another attribute.");
        }

        //figure out max allowed attr no
        int maxAttrNo = DBLimits.getLimits().getMaxAttrNo();
        if (attrNumber == 0 || attrNumber > maxAttrNo) {
            throw new DimBaseCmdException("Error: you have reached the maximum limit of " + maxAttrNo
                    + " of user-defined attributes for " + TypeUtils.getClassName(scopeClass) + " Types.");
        }

        if (globalAttrNo == -1) {
            // Construct the OBJATTR command to create global attribute definition, for example:
            // OBJATTR /ADD "SS348756834568756" /OBJ_CLASS=REQUEST /MAX_LENGTH=25 /DATA_TYPE=DATE

            StringBuffer cmdBuf = new StringBuffer("OBJATTR /ADD ");

            cmdBuf.append(Encoding.escapeDMCLI(attrName));
            cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(scopeClass));
            if (-1 != attrNumber)
                cmdBuf.append(" /ATTR_NO=").append(attrNumber);
            cmdBuf.append(" /MAX_LENGTH=").append(maxLength);
            cmdBuf.append(" /DATA_TYPE=");
            if (String.class.equals(attrDataType))
                cmdBuf.append("CHAR");
            else if (Number.class.equals(attrDataType))
                cmdBuf.append("NUMERIC");
            else if (Integer.class.equals(attrDataType))
                cmdBuf.append("NUMERIC");
            else if (Date.class.equals(attrDataType))
                cmdBuf.append("DATE");

            _cmdStr = cmdBuf.toString();
            executeRpc();

            globalAttrNo = findUsedAttrNo(attrName, typeFlag);
            if (globalAttrNo == -1) {
                throw new DimBaseCmdException("Error when creating global definition of user-defined attribute for " + TypeUtils.getClassName(scopeClass) + " Types.");
            }
        }

        //final int attrNo = findAttributeNumber(attrNumber, attrName, typeFlag);
        setAttrValue(CmdArguments.INT_SPEC, typeUid + ":" + globalAttrNo);

        // Construct OBJATTR command to assign global attribute definition to the specified object type, for example:
        // OBJATTR /ASSIGN "SS348756834568756" /TYPE=SS /PRODUCT="QLARIUS" /OBJ_CLASS=REQUEST /OBJ_TYPE="AZIUBIN232"
        // /PROMPT="SS348756834568756" /DEFAULT="SS348756834568756" /HELP="SS348756834568756" /DISPLAY_LENGTH=25 /HEIGHT=1 /WIDTH=25 /ORDER=0
        // /VISIBLE /PENDING_DISPLAY /NEW_REVISION=DEFAULT_AS_SPEC /NOHISTORY /NOSENSITIVE /RANGE_START="+1" /RANGE_END="+25"

        StringBuffer cmdBuf = new StringBuffer("OBJATTR /ASSIGN ");
        cmdBuf.append(Encoding.escapeDMCLI(attrName));
        cmdBuf.append(" /TYPE=").append(getAttrType(attrType));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));
        cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(scopeClass));
        cmdBuf.append(" /OBJ_TYPE=").append(Encoding.escapeDMCLI(typeName));
        if (null != userPrompt)
            cmdBuf.append(" /PROMPT=").append(Encoding.escapeDMCLI(userPrompt));
        if (null != defaultValue)
            cmdBuf.append(" /DEFAULT=").append(Encoding.escapeDMCLI(defaultValue));
        if (null != helpMessage)
            cmdBuf.append(" /HELP=").append(Encoding.escapeDMCLI(helpMessage));
        cmdBuf.append(" /DISPLAY_LENGTH=").append(displayLength);
        cmdBuf.append(" /HEIGHT=").append(displayHeight);
        cmdBuf.append(" /WIDTH=").append(displayWidth);
        if (null != mvaTypeFlag)
            cmdBuf.append(" /MVA_TYPE=").append(mvaTypeFlag);
        cmdBuf.append(" /ORDER=").append(displayOrder);
        cmdBuf.append(isDisplayable?" /VISIBLE": " /NOVISIBLE");
        cmdBuf.append(isCatalog? " /PENDING_DISPLAY": "/NOPENDING_DISPLAY");
        cmdBuf.append(" /NEW_REVISION=").append(getRevision(isAllRevisions, isPrevRevision));
        cmdBuf.append(keepUpdateHistory? " /HISTORY": " /NOHISTORY");
        cmdBuf.append(isSensitive? " /SENSITIVE": " /NOSENSITIVE");
        cmdBuf.append(isMandatory? " /MANDATORY": " /NOMANDATORY");

        // "Fixed range: from" value is in "DD-MON-YYYY HH24:MI" format, while OBJATTR expects "DD-MON-YYYY HH24:MI:SS".
        if (null != startFixedDate && !startFixedDate.isEmpty())
            cmdBuf.append(" /START_DATE=").append(Encoding.escapeDMCLI(startFixedDate.concat(":00")));

        // "Fixed range: to" value is in "DD-MON-YYYY HH24:MI:SS" format, which is the format OBJATTR expects.
        if (null != endFixedDate && !endFixedDate.isEmpty())
            cmdBuf.append(" /END_DATE=").append(Encoding.escapeDMCLI(endFixedDate));

        if (null != startDays && !startDays.isEmpty())
            cmdBuf.append(" /RANGE_START=").append(Encoding.escapeDMCLI(startDays));
        if (null != endDays && !endDays.isEmpty())
            cmdBuf.append(" /RANGE_END=").append(Encoding.escapeDMCLI(endDays));
        if (null != startLinkTo && !startLinkTo.isEmpty())
            cmdBuf.append(" /ATTR_BEFORE=").append(Encoding.escapeDMCLI(startLinkTo));
        if (null != endLinkTo && !endLinkTo.isEmpty())
            cmdBuf.append(" /ATTR_AFTER=").append(Encoding.escapeDMCLI(endLinkTo));

        if (Date.class.equals(attrDataType)
                && (null == startFixedDate || startFixedDate.isEmpty()) && (null == endFixedDate || endFixedDate.isEmpty())
                && (null == startDays || startDays.isEmpty()) && (null == endDays || endDays.isEmpty())
                && (null == startLinkTo || startLinkTo.isEmpty()) && (null == endLinkTo || endLinkTo.isEmpty()))
            cmdBuf.append(" /OMIT_DATE_VALIDATION");

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, LocalAttributeDefinition.class);

        // Refresh the server attribute cache
        AdmCmd.getCmd(Server.REFRESH_ATTR_CACHE, typeObj).execute();

        return retResult;
    }

    private int findUsedAttrNo(String attrName, String typeFlag) throws DBIOException, AdmException {
        DBIO query = new DBIO(wcm_sql.ATTRDEF_GET_ATTRNO_FROM_NAME_80);
        query.bindInput(attrName);
        query.bindInput(typeFlag);

        int attrNo = -1;
        query.readStart();
        if (query.read()) {
            attrNo = query.getInt(1);
        }
        query.close();
        return attrNo;
    }

    private boolean attributeNumberExists(int attrNumber, String typeFlag) throws DBIOException, AdmException{
        DBIO query = new DBIO(wcm_sql.ATTRDEF_CHECK_ATTRNO_80);
        query.bindInput(attrNumber);
        query.bindInput(typeFlag);
        query.readStart();
        boolean exists = query.read();
        query.close();
        return exists;
    }

    private String getRevision(final boolean isAllRevisions, final boolean isPrevRevision) throws DimInvalidAttributeException {
        if (!isAllRevisions && !isPrevRevision) {
            return "DEFAULT_AS_SPEC";
        } else if (isAllRevisions && !isPrevRevision) {
            return "SAME_FOR_ALL";
         } else if (!isAllRevisions && isPrevRevision) {
            return "UNCONTROLLED";  // "DEFAULT_TO_PREV"
        } else { // if (isAllRevisions && isPrevRevision) {
            return "UNCONTROLLED";
        }
    }

    private String getAttrType(final int attrType) throws DimInvalidAttributeException {
        if (attrType == Constants.ATTR_TYPE_SFSV)
            return "SS";
        else if (attrType == Constants.ATTR_TYPE_SFMV)
            return "SM";
        else if (attrType == Constants.ATTR_TYPE_MFMV)
            return "MM";
        else 
            throw new DimInvalidAttributeException("Error: invalid attribute type value.");
    }

    private String getMVATypeStr(int mvaType) throws DimInvalidAttributeException {
        if (mvaType == Constants.MVA_NULL)
            return "NULL";
        if (mvaType == Constants.MVA_INT)
            return "INT";
        if (mvaType == Constants.MVA_FLOAT)
            return "FLOAT";
        if (mvaType == Constants.MVA_CHAR)
            return "CHAR";
        if (mvaType == Constants.MVA_STRING)
            return "STRING";
        if (mvaType == Constants.MVA_STRING_LITERAL)
            return "STRING";
        if (mvaType == Constants.MVA_DATE)
            return "DATE";

        throw new DimInvalidAttributeException("Error: invalid attribute MVA type value.");
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmComplexSpec;
import merant.adm.dimensions.objects.core.AdmComplexSpecTwin;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmSpecTwin;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidTwin;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

/**
 * This class is a helper class to AdmCmd.java.
 * @author Laurence Martin
 */
public final class AdmHelperCmd {
    // Static methods for AdmObject instances retrieval
    public static AdmObject getObject(AdmBaseId baseId) throws DimBaseException, AdmObjectException, AttrException, AdmException {
        return getObject(baseId, null);
    }

    public static AdmObject getObject(AdmBaseId baseId, Object attrNames) throws DimBaseException, AdmObjectException,
            AttrException, AdmException {
        if (baseId == null) {
            return null;
        }

        Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECT, baseId.getObjType());
        cmd.setAttrValue(CmdArguments.ADM_BASE_ID, baseId);
        if (attrNames != null) {
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        }

        return (AdmObject) cmd.execute();
    }

    public static List getObjects(List baseIds) throws DimBaseException, AdmObjectException, AttrException, AdmException {
        return getObjects(baseIds, null);
    }

    public static List getObjects(List baseIds, Object attrNames) throws DimBaseException, AdmObjectException, AttrException,
            AdmException {
        /**
         * Additional note DJH
         * the above change was made on 8th June 2005, with the addition that a NullPointerException
         * will be thrown for the case that baseIds == null, because from this point onwards it is considered
         * invalid to pass a null list of base Ids into this method.
         */
        if (baseIds == null) {
            throw new NullPointerException("The baseIds argument must not be null.");
        }
        if (baseIds.size() == 0) {
            return new ArrayList();
        }

        Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECTS, ((AdmBaseId) baseIds.get(0)).getObjType());
        cmd.setAttrValue(CmdArguments.ADM_BASE_IDS, baseIds);
        if (attrNames != null) {
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        }

        return (List) cmd.execute();
    }

    /**
     * @param attr object of attribute, for example:
     * {@code Attribute Block [QLARIUS:MULTI_FILED_ATTRIBUTE]}
     * @return The object type to which the attribute belongs, for example
     * {@code Type [QLARIUS:CR-merant.adm.dimensions.objects.ChangeDocument]}
     * @throws AdmException
     */
    public static AdmObject getParentType(AdmObject attr) throws AdmException {
        AdmObject typeObj = null;
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, attr, Type.class);
        AdmBaseId typeId = (AdmBaseId) cmd.execute();  // class merant.adm.dimensions.objects.Type
        if (typeId != null) {
            typeObj = AdmHelperCmd.getObject(typeId, AdmAttrNames.ADM_SPEC);
        }
        return typeObj;
    }

    // Static methods for AdmBaseId instances retrieval
    public static AdmBaseId newAdmBaseId(long uid, Class objType) {
        return new AdmUid(uid, objType);
    }

    public static AdmBaseId newAdmBaseId(long uid, Class objType, Object scope) {
        if (scope != null) {
            if (scope instanceof AdmBaseId) {
                return new AdmUid(uid, objType, (AdmBaseId) scope);
            } else if (scope instanceof List) {
                return new AdmUid(uid, objType, (List) scope);
            }
        }

        return new AdmUid(uid, objType);
    }

    public static AdmBaseId newAdmBaseId(long uid, Class objType, Object scope, AdmBaseId twin) {
        if ((twin != null) && (!(twin instanceof AdmSpecTwin))) {
            return newAdmBaseId(uid, objType, scope);
        }

        AdmBaseId ret = null;
        if (scope != null) {
            if (scope instanceof AdmBaseId) {
                ret = new AdmUidTwin(uid, objType, (AdmBaseId) scope);
            } else if (scope instanceof List) {
                ret = new AdmUidTwin(uid, objType, (List) scope);
            }
        }

        if (ret == null) {
            ret = new AdmUidTwin(uid, objType);
        }

        ((AdmUidTwin) ret).setTwin(twin);
        if (twin != null) {
            ((AdmSpecTwin) twin).setTwin(ret);
        }

        return ret;
    }

    public static AdmBaseId newAdmBaseId(String spec, Class objType) {
        return new AdmSpec(spec, objType);
    }

    public static AdmBaseId newAdmBaseId(String spec, Class objType, Object scope) {
        if (scope != null) {
            if (scope instanceof AdmBaseId) {
                return new AdmSpec(spec, objType, (AdmBaseId) scope);
            } else if (scope instanceof List) {
                return new AdmSpec(spec, objType, (List) scope);
            }
        }

        return new AdmSpec(spec, objType);
    }

    public static AdmBaseId newAdmBaseId(String spec, Class objType, Object scope, AdmBaseId twin) {
        if ((twin != null) && (!(twin instanceof AdmUidTwin))) {
            return newAdmBaseId(spec, objType, scope);
        }

        AdmBaseId ret = null;
        if (scope != null) {
            if (scope instanceof AdmBaseId) {
                ret = new AdmSpecTwin(spec, objType, (AdmBaseId) scope);
            } else if (scope instanceof List) {
                ret = new AdmSpecTwin(spec, objType, (List) scope);
            }
        }

        if (ret == null) {
            ret = new AdmSpecTwin(spec, objType);
        }

        ((AdmSpecTwin) ret).setTwin(twin);
        if (twin != null) {
            ((AdmUidTwin) twin).setTwin(ret);
        }

        return ret;
    }

    public static AdmBaseId newAdmBaseId(List specComponents, Class objType) {
        return new AdmComplexSpec(specComponents, objType);
    }

    public static AdmBaseId newAdmBaseId(List specComponents, Class objType, Object scope) {
        if (scope != null) {
            if (scope instanceof AdmBaseId) {
                return new AdmComplexSpec(specComponents, objType, (AdmBaseId) scope);
            } else if (scope instanceof List) {
                return new AdmComplexSpec(specComponents, objType, (List) scope);
            }
        }

        return new AdmComplexSpec(specComponents, objType);
    }

    public static AdmBaseId newAdmBaseId(List specComponents, Class objType, Object scope, AdmBaseId twin) {
        if ((twin != null) && (!(twin instanceof AdmUidTwin))) {
            return newAdmBaseId(specComponents, objType, scope);
        }

        AdmBaseId ret = null;
        if (scope != null) {
            if (scope instanceof AdmBaseId) {
                ret = new AdmComplexSpecTwin(specComponents, objType, (AdmBaseId) scope);
            } else if (scope instanceof List) {
                ret = new AdmComplexSpecTwin(specComponents, objType, (List) scope);
            }
        }

        if (ret == null) {
            ret = new AdmComplexSpecTwin(specComponents, objType);
        }

        ((AdmComplexSpecTwin) ret).setTwin(twin);
        if (twin != null) {
            ((AdmUidTwin) twin).setTwin(ret);
        }

        return ret;
    }

    // Static methods for AdmObject attribute value retrieval
    public static Object getAttributeValue(AdmObject admObj, String attrName) throws DBIOException, DimBaseException, AdmException {
        return getAttributeValue(admObj, attrName, false);
    }

    public static Object getAttributeValue(AdmObject admObj, String attrName, boolean forceQuery) throws DBIOException,
            DimBaseException, AdmException {
        List attrs = new Vector();
        attrs.add(attrName);
        attrs = getAttributeValues(admObj, attrs, forceQuery);
        if ((attrs == null) || (attrs.size() == 0)) {
            return null;
        }

        return attrs.get(0);
    }

    public static void queryAttribute(AdmObject admObj, String attrName) throws DBIOException, DimBaseException, AdmException {
        queryAttribute(admObj, attrName, false);
    }

    public static void queryAttribute(AdmObject admObj, String attrName, boolean force) throws DBIOException, DimBaseException, AdmException {
        List<String> attrNames = new ArrayList<String>();
        attrNames.add(attrName);
        AdmHelperCmd.queryAttributes(admObj, attrNames, force);
    }

    public static void queryAttributes(AdmObject admObj, List<String> attrNames) throws DBIOException, DimBaseException, AdmException {
        AdmHelperCmd.queryAttributes(admObj, attrNames, false);
    }

    public static void queryAttributes(AdmObject admObj, List<String> attrNames, boolean forceQuery) throws DBIOException, DimBaseException, AdmException {
        if (attrNames == null) {
            throw new IllegalArgumentException("Null list is not allowed.");
        }
        if (!forceQuery) {
            Iterator<String> attrNamesIter = attrNames.iterator();
            while (attrNamesIter.hasNext()) {
                String attrName = attrNamesIter.next();
                Object attrValue = admObj.getAttrValue(attrName);
                if (attrValue != null) {
                    attrNamesIter.remove();
                }
            }
            if (attrNames.isEmpty()) {
                return;
            }
        }
        Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObj);
        cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        cmd.execute();
    }

    public static List getAttributeValues(AdmObject admObj, List attrNames) throws DBIOException, DimBaseException, AdmException {
        return getAttributeValues(admObj, attrNames, false);
    }

    public static List getAttributeValues(AdmObject admObj, List attrNames, boolean forceQuery) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(WithAttrs.GET, admObj);
        cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        if (forceQuery) {
            cmd.setAttrValue(CmdArguments.FORCE_QUERY, Boolean.TRUE);
        }

        return (List) cmd.execute();
    }

    public static List getAttributesValue(List admObjs, String attrName) throws DBIOException, DimBaseException, AdmException {
        return getAttributesValue(admObjs, attrName, false);
    }

    public static List getAttributesValue(List admObjs, String attrName, boolean forceQuery) throws DBIOException,
            DimBaseException, AdmException {
        List attrs = new Vector();
        attrs.add(attrName);
        attrs = getAttributesValues(admObjs, attrs, forceQuery);
        if ((attrs == null) || (attrs.size() == 0)) {
            return null;
        }

        List kid = null;
        List ret = new Vector();
        for (int i = 0; i < attrs.size(); i++) {
            kid = (List) attrs.get(i);
            if ((kid != null) && (kid.size() > 0)) {
                ret.add(kid.get(0));
            }
        }

        return ret;
    }

    public static List getAttributesValues(List admObjs, List attrNames) throws DBIOException, DimBaseException, AdmException {
        return getAttributesValues(admObjs, attrNames, false);
    }

    public static List getAttributesValues(List admObjs, List attrNames, boolean forceQuery) throws DBIOException,
            DimBaseException, AdmException {
        Cmd cmd = AdmCmd.getCmd(WithAttrs.GET, admObjs);
        cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        if (forceQuery) {
            cmd.setAttrValue(CmdArguments.FORCE_QUERY, Boolean.TRUE);
        }

        return (List) cmd.execute();
    }

}

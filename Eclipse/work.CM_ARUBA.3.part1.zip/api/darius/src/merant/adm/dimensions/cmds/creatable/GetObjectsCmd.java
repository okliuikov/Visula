/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.lang.reflect.Constructor;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.AdmUidObjectImpl;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.RequestProviderAttributeDefinition;
import merant.adm.dimensions.objects.Requirement;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmTwin;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will obtain AdmObject's given AdmBaseId's.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_BASE_IDS {List}<dt>
 *  <dd>
 *      Base identifiers for Dimension objects.<p>
 *      Each element can either be an AdmBaseId or
 *      a Relationship object containing an AdmBaseId
 *      as the child of the relationship.
 *  </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ATTRIBUTE_NAMES {String/List}<dt><dd>Attribute name or List of attribute names to query</dd>
 *  <dt>USE_SUPER_QUERY {Boolean}<dt><dd>Force the use of SuperQuery</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing the returned AdmObjects</dd>
 * </dl></code>
 * @author Floz
 */
public class GetObjectsCmd extends AdmCmd {
    public GetObjectsCmd() throws AttrException {
        super();
        setAlias(Creatable.GET_OBJECTS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_BASE_IDS, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTE_NAMES, false));
        setAttrDef(new CmdArgDef(CmdArguments.USE_SUPER_QUERY, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.USE_PARENT, false, Boolean.FALSE, Boolean.class));
    }

    public static AdmObject buildNewObject(AdmBaseId baseId) throws DimBaseException, AdmException {
        if (baseId == null) {
            return null;
        }

        AdmObject newObj = null;
        Constructor cons = null;
        Class consArgClasses[] = new Class[1];
        Object consArgs[] = new Object[1];

        consArgClasses[0] = AdmBaseId.class;
        try {
            cons = baseId.getObjType().getConstructor(consArgClasses);

            if (cons != null) {
                consArgs[0] = baseId;
                newObj = (AdmObject) cons.newInstance(consArgs);
                if ((newObj instanceof AdmUidObjectImpl) && (baseId instanceof AdmTwin) && (((AdmTwin) baseId).getTwin() != null)) {
                    AdmUid uidTwin = null;
                    AdmSpec specTwin = null;
                    if (baseId instanceof AdmUid) {
                        uidTwin = (AdmUid) baseId;
                        specTwin = (AdmSpec) ((AdmTwin) baseId).getTwin();
                    } else {
                        specTwin = (AdmSpec) baseId;
                        uidTwin = (AdmUid) ((AdmTwin) baseId).getTwin();
                    }

                    ((AdmUidObjectImpl) newObj).setAdmUidRaw(uidTwin);
                    ((AdmUidObjectImpl) newObj).setAdmSpec(specTwin);
                }
            }
        } catch (Exception exception) {
            // NoSuchMethodException or InstantiationException
            throw new AdmException(exception);
        }
        return newObj;
    }

    /** @todo Implement using external cache */
    @Override
    public Object execute() throws DimBaseException, AdmException {
        validateAllAttrs();
        List admBaseObjs = (List) getAttrValue(CmdArguments.ADM_BASE_IDS);
        boolean useParent = ((Boolean) getAttrValue(CmdArguments.USE_PARENT)).booleanValue();

        List retObjects = new Vector();

        AdmBaseId baseId = null;
        AdmObject newObj = null;
        Object tmpObj = null;
        for (int i = 0; i < admBaseObjs.size(); i++) {
            tmpObj = admBaseObjs.get(i);
            if (tmpObj != null) {
                baseId = null;
                if (tmpObj instanceof AdmBaseId) {
                    baseId = (AdmBaseId) tmpObj;
                } else if (tmpObj instanceof Relationship) {
                    if (useParent) {
                        baseId = (AdmBaseId) ((AdmObject) tmpObj).getAttrValue(AdmAttrNames.REL_PARENT);
                    } else {
                        baseId = (AdmBaseId) ((AdmObject) tmpObj).getAttrValue(AdmAttrNames.REL_CHILD);
                    }
                }

                if (baseId != null) {
                    newObj = buildNewObject(baseId);
                    if (newObj != null) {
                        retObjects.add(newObj);
                    }
                }
            }
        }

        if (getAttrValue(CmdArguments.ATTRIBUTE_NAMES) != null) {
            Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, retObjects);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
            cmd.setAttrValue(CmdArguments.USE_SUPER_QUERY, getAttrValue(CmdArguments.USE_SUPER_QUERY));
            if (retObjects.get(0) instanceof Requirement) {
                cmd.setAttrDef(new CmdArgDef(CmdArguments.CONTAINER_DETAILS, false, List.class));
                // Retrieve the container details of requirement from the command. Supply this details to the
                // command which fetches requirement attributes. We are doing this because the query
                // which fetches the requirement attributes is not capable of returning container details.
                cmd.setAttrValue(CmdArguments.CONTAINER_DETAILS, getAttrValue(CmdArguments.CONTAINER_DETAILS));
            } else if (retObjects.get(0) instanceof RequestProviderAttributeDefinition) {
                cmd.setAttrDef(new CmdArgDef(CmdArguments.CONTAINER_DETAILS, false, AdmObject.class));
                cmd.setAttrValue(CmdArguments.CONTAINER_DETAILS, getAttrValue(CmdArguments.CONTAINER_DETAILS));
            }

            cmd.execute();
        }

        return retObjects;
    }
}

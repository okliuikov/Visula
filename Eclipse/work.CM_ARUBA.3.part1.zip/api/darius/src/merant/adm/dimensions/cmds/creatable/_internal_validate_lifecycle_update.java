/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimLcInconsistentLifecycleException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to validate a normal lifecycle path.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>DBIO_QUERY {DBIO}</dt>
 *  <dd>
 *      Dimensions DBIO query object to be used. This object defines the transactional scope of the operation.
 *      Any exceptions raised by this command must be handled by the caller.
 *  </dd>
 *  <dt>LIFECYCLE_ID {String}</dt><dd>Dimensions lifecycle ID</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */

public class _internal_validate_lifecycle_update extends DBIOCmd {
    public _internal_validate_lifecycle_update() throws AttrException {
        super();
        setAlias("_internal_validate_lifecycle_update");
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, true, DBIO.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIFECYCLE_ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADDING_TRANSITION, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.DBIO_QUERY)) {
            if (!(attrValue instanceof DBIO)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException, DimBaseCmdException {
        validateAllAttrs();

        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        String lifecycleId = (String) getAttrValue(AdmAttrNames.LIFECYCLE_ID);

        validateLifecycleUpdate(query, lifecycleId);

        return "Operation Completed";
    }

    /**
     * Checks whether a lifecycle update resulted in a consistent lifecycle
     */
    private void validateLifecycleUpdate(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        // FUNCTION IS_LIFECYCLE_UPDATE_OK (lc_id varchar2)

        char type_flag;

        // get distinct type_flag's into a list
        query.resetMessage(wcm_sql.LC_QUERY_OBJECT_CLASSES_USING_LIFECYCLE);
        query.bindInput(lifecycleId);

        query.readStart();
        List typeFlags = null;
        while (query.read(DBIO.DB_DONT_CLOSE)) {
            if (typeFlags == null) {
                typeFlags = new ArrayList();
            }
            typeFlags.add(query.getString(1));
        }
        query.close(DBIO.DB_DONT_RELEASE);

        if (typeFlags != null) {
            // Only check those object classes which use the lifecycle
            for (int i = 0; i < typeFlags.size(); i++) {
                type_flag = ((String) typeFlags.get(i)).charAt(0);
                validateLifecycleConsistency(query, lifecycleId, type_flag);

                // check secondary catalogue
                if (type_flag == 'C') {
                    validateLifecycleConsistency(query, lifecycleId, 'S');
                }
            }
        }

        if (isUsedByType(query, lifecycleId, ChangeDocument.class)) {
            // Check the case where object follows a lifecycle at the part level
            query.resetMessage(wcm_sql.LC_VALIDATE_CHDOCS_USING_PART_LEVEL_LIFECYLES);
            query.bindInput(lifecycleId);
            query.readStart();
            boolean isInvalid = query.read(DBIO.DB_DONT_CLOSE);
            query.close(DBIO.DB_DONT_RELEASE);

            if (isInvalid) {
                throw new DimLcInconsistentLifecycleException("There are existing requests "
                        + "residing at a state which will not be included in the new lifecycle");
            }
        }
    }

    /**
     * Checks if the specified lifecycle is used by an object type [of specified class].
     */
    private boolean isUsedByType(DBIO query, String lifecycleId, Class typeClass) throws DBIOException, DimBaseException,
            AdmException {

        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        query.resetMessage(wcm_sql.LC_IS_USED_BY_OBJECT_CLASS);

        query.bindInput(lifecycleId);
        query.bindInput(typeFlag);

        query.readStart();
        boolean isUsed = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        return isUsed;

    }

    /**
     * For a give type_flag (PCMS Object Class), this function checks whether there
     * are objects of that type with a status not included in the lifecycle
     */
    private void validateLifecycleConsistency(DBIO query, String lifecycleId, char typeFlag) throws DBIOException,
            DimBaseException, AdmException {
        // * FUNCTION IS_LIFECYCLE_CONSISTENT (lc_id varchar2, type_flag varchar2) RETURN boolean IS

        String tablePrefix = getTablePrefix(typeFlag);
        StringBuffer sql = new StringBuffer(512);

        if (typeFlag == 'C' || typeFlag == 'S') {
            sql.append("SELECT DISTINCT status FROM " + tablePrefix + "catalogue ic, obj_types ot ");
        } else {
            sql.append("SELECT DISTINCT status FROM " + tablePrefix + "catalogue ic, " + tablePrefix
                    + "spec_catalogue sc, obj_types ot ");
        }

        sql.append(" WHERE ot.lifecycle_id = :I1 and ot.type_flag = ");

        if (typeFlag == 'S') {
            sql.append("'C'");
        } else {
            sql.append("'" + typeFlag + "'");
        }

        if (typeFlag == 'C' || typeFlag == 'S') {
            sql.append(" AND ic.type_uid = ot.type_uid ");
        } else {
            sql.append(" AND sc.type_uid = ot.type_uid AND ic.obj_spec_uid = sc.obj_spec_uid ");
        }

        sql.append(" AND ic.status NOT IN ('SUSPENDED', '$TO_BE_DEFINED', '$MOVED') "
                + " AND NOT EXISTS (SELECT NULL FROM life_cycles " + "WHERE lifecycle_id = :I1 "
                + "AND (doc_status = ic.status OR next_doc_status = ic.status)" + ") ");
        String queryStr = sql.toString();

        query.resetSQL(queryStr);
        query.bindInput(lifecycleId);
        query.readStart();

        if (query.read(DBIO.DB_DONT_CLOSE)) {
            String status = query.getString(1);
            throw new DimLcInconsistentLifecycleException("There are existing " + getClassName(typeFlag)
                    + " residing at status(es), " + status + ", which will not be included in the new lifecycle.");
        }
    }

    /**
     * Returns the table prefix corresponding to the object type catalogue
     */
    private String getTablePrefix(char typeClass) {
        if (typeClass == 'I') {
            return Constants.TABLE_PREFIX_ITEM_SPEC_CATALOGUE;
        } else if (typeClass == 'C') {
            return Constants.TABLE_PREFIX_CHDOC_CATALOGUE;
        } else if (typeClass == 'S') {
            return Constants.TABLE_PREFIX_SEC_CHDOC_CATALOGUE;
        } else if (typeClass == 'P') {
            return Constants.TABLE_PREFIX_PART_SPEC_CATALOGUE;
        } else if (typeClass == 'B') {
            return Constants.TABLE_PREFIX_BLN_SPEC_CATALOGUE;
        } else if (typeClass == 'W') {
            return Constants.TABLE_PREFIX_WS_SPEC_CATALOGUE;
        } else {
            return "UNKNOWN_";
        }
    }

    /**
     * Returns a human-readable type class name
     */
    private String getClassName(char typeClass) {
        if (typeClass == 'I') {
            return "items";
        } else if (typeClass == 'C' || typeClass == 'S') {
            return "requests";
        } else if (typeClass == 'P') {
            return "design parts";
        } else if (typeClass == 'B') {
            return "baselines";
        } else if (typeClass == 'W') {
            return "projects";
        } else {
            return "Unknown";
        }
    }

}

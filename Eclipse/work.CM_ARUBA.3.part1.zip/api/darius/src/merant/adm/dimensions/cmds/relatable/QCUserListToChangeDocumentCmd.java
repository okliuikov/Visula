/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2004 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.UserList;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all ChangeDocument's related to the UserList object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class QCUserListToChangeDocumentCmd extends QueryRelsCmd {
    public QCUserListToChangeDocumentCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UserList)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(ChangeDocument.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        StringBuffer orderBy = new StringBuffer();
        orderBy.setLength(0);
        if (filter != null) {
            processOrder(filter, orderBy);
        }
        // unless explicitly sorted by change document id, ensure
        // that the query always orders by change document id descending
        if (orderBy.length() == 0) {
            orderBy.append("cmc.product_id ASC, cmc.ch_doc_type ASC, cmc.doc_seq DESC");
        }

        String id = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
        String userName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.USER_NAME);

        DBIO query = null;
        List ret = new ArrayList();

        query = new DBIO(wcm_sql.QUERY_USER_LIST);
        query.bindInput(id);
        query.bindInput(userName);
        query.bindInput(orderBy.toString(), DBIO.DB_ARG_STRING_LITERAL); // sort order string

        query.readStart();
        while (query.read()) {
            long chdocUid = query.getLong(1);
            AdmBaseId uidBaseId = AdmHelperCmd.newAdmBaseId(chdocUid, ChangeDocument.class, null, null);
            addRelation(ret, relationships, admObj.getAdmBaseId(), uidBaseId);
        }

        return ret;
    }

    private void processOrder(FilterImpl f, StringBuffer orderBy) {
        if (f == null) {
            return;
        }
        Collection orders = f.orders();
        if (orders != null && !orders.isEmpty()) {
            boolean comma = false;
            for (Iterator it = orders.iterator(); it.hasNext();) {
                FilterOrder order = (FilterOrder) it.next();
                if (order == null) {
                    continue;
                }
                String attrName = order.getAttrName();

                // The order of the next three IF statements is important so AdmAttrNames.ID
                // processes in the right way:

                // order by change document product?
                if (AdmAttrNames.PRODUCT_NAME.equals(attrName) || AdmAttrNames.ID.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("cmc.product_id");
                    if ((order.getFlags() & FilterOrder.DESCENDING) != 0) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }

                // order by type name ?
                if (AdmAttrNames.TYPE_NAME.equals(attrName) || AdmAttrNames.ID.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("cmc.ch_doc_type");
                    if ((order.getFlags() & FilterOrder.DESCENDING) != 0) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }

                // order by change document seq? (reverse ordering sense if part of ID)
                if (AdmAttrNames.CHDOC_DOC_SEQ.equals(attrName) || AdmAttrNames.ID.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("cmc.doc_seq");
                    if ((AdmAttrNames.CHDOC_DOC_SEQ.equals(attrName) && (order.getFlags() & FilterOrder.DESCENDING) != 0)
                            || (AdmAttrNames.ID.equals(attrName) && (order.getFlags() & FilterOrder.DESCENDING) == 0)) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }

                // order by description?
                if (AdmAttrNames.DESCRIPTION.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("LOWER(cma.attr_1)");
                    if ((order.getFlags() & FilterOrder.DESCENDING) != 0) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }

                // order by status?
                if (AdmAttrNames.STATUS.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("cmc.status");
                    if ((order.getFlags() & FilterOrder.DESCENDING) != 0) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }

                // order by user name?
                if (AdmAttrNames.USER_NAME.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    orderBy.append("cmc.user_name");
                    if ((order.getFlags() & FilterOrder.DESCENDING) != 0) {
                        orderBy.append(" DESC");
                    } else {
                        orderBy.append(" ASC");
                    }
                    comma = true;
                }
            }
        }
    }
}

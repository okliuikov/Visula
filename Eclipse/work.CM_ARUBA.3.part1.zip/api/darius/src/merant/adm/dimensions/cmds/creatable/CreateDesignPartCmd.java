/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions design part.
 * <p>
 * Updated in January 2003 to more closely resemble the CP and CPV command lines that it invokes.<br>
 * The new deterministic factor that decides whether a CP or a CPV occurs is the inclusion of the NEW_VARIANT argument. If this is
 * null, CP is used, if this is not null then CPV is assumed. <b>Mandatory Arguments (Create Part):</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of container for the new part</dd>
 *  <dt>ID {String}</dt><dd>Identifier of the new part</dd>
 *  <dt>VARIANT {String}</dt><dd>Variant of the new part</dd>
 *  <dt>REVISION {String}</dt><dd>Revision (PCS) of the new part</dd>
 *  <dt>TYPE_NAME {String}</dt><dd>Type name (CATEGORY) of the new part</dd>
 *  <dt>PARENT_PART {Part}</dt><dd>Parent part of the new part</dd>
 *  <dt>DESCRIPTION {String}</dt><dd>Description of the new part</dd>
 * </dl></code> <br>
 * <b>Optional Arguments (Create Part):</b> <code><dl>
 *  <dt>{none}</dt>
 * </dl></code> <br>
 * <b>Mandatory Arguments (Create Part Variant):</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of the existing part</dd>
 *  <dt>ID {String}</dt><dd>Identifier of the existing part</dd>
 *  <dt>VARIANT {String}</dt><dd>Variant of the existing part</dd>
 *  <dt>REVISION {String}</dt><dd>Revision (PCS) of the existing part</dd>
 *  <dt>NEW_VARIANT {String}</dt><dd>Variant of the new part</dd>
 * </dl></code> <br>
 * <b>Optional Arguments (Create Part Variant):</b> <code><dl>
 *  <dt>PARENT_VARIANT {String}</dt><dd>Parent variant of the new part</dd>
 *  <dt>DESCRIPTION {String}</dt><dd>Description of the new part</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateDesignPartCmd extends RPCExecCmd {
    public CreateDesignPartCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VARIANT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REVISION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARENT_PART, false, Part.class));
        setAttrDef(new CmdArgDef(CmdArguments.NEW_VARIANT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARENT_VARIANT, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String productName = ((String) getAttrValue(AdmAttrNames.PRODUCT_NAME)).toUpperCase();
        String id = ((String) getAttrValue(AdmAttrNames.ID)).toUpperCase();
        String variant = ((String) getAttrValue(AdmAttrNames.VARIANT)).toUpperCase();
        String revision = (String) getAttrValue(AdmAttrNames.REVISION);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String typeName = (String) getAttrValue(AdmAttrNames.TYPE_NAME);
        AdmObject parentPart = (AdmObject) getAttrValue(CmdArguments.PARENT_PART);
        String newVariant = (String) getAttrValue(CmdArguments.NEW_VARIANT);
        String parentVariant = (String) getAttrValue(CmdArguments.PARENT_VARIANT);

        if (newVariant == null) {
            // Check other CP mandatory arguments
            if (desc == null) {
                throw new DimMandatoryAttributeException("Error: description must be specified.");
            }

            if (typeName == null) {
                throw new DimMandatoryAttributeException("Error: design part category must be specified.");
            }

            if (parentPart == null) {
                throw new DimMandatoryAttributeException("Error: parent design part must be specified.");
            }

            typeName = typeName.toUpperCase();
            setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id + "." + variant + ";" + revision);
            _cmdStr = "CP " + Encoding.escapeSpec((String) getAttrValue(CmdArguments.INT_SPEC));
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(desc);
            _cmdStr += " /CATEGORY=" + Encoding.escapeSpec(typeName);
            _cmdStr += " /PARENT_PART=" + Encoding.escapeSpec(parentPart.getAdmSpec().getSpec());
        } else {
            newVariant = newVariant.toUpperCase();
            _cmdStr = "CPV " + Encoding.escapeSpec(productName + ":" + id + "." + variant + ";" + revision);
            _cmdStr += " /NEW_VARIANT=" + Encoding.escapeSpec(newVariant);
            if (parentVariant != null) {
                parentVariant = parentVariant.toUpperCase();
                _cmdStr += " /PARENT_VARIANT=" + Encoding.escapeSpec(parentVariant);
            }

            if (desc != null) {
                _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(desc);
            }
        }

        _cmdStr += " ";
        _cmdStr += AttributeDefinition.getAttrsCmdStringFromCmd(this);

        AdmResult retResult = new AdmResult(executeRpc());
        if (newVariant != null) {
            // Query for new part variant, cannot assume
            // revision (PCS) inputted is that used!
            Filter filter = new FilterImpl();
            filter.criteria().add(new FilterCriterion(AdmAttrNames.PRODUCT_NAME, productName));
            filter.criteria().add(new FilterCriterion(AdmAttrNames.ID, id));
            filter.criteria().add(new FilterCriterion(AdmAttrNames.VARIANT, newVariant));
            filter.criteria().add(new FilterCriterion(AdmAttrNames.STATUS, Constants.SYS_STATE_OPEN));
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, AdmCmd.getCurRootObj(BaseDatabase.class), Part.class);
            cmd.setAttrValue(CmdArguments.FILTER, filter);
            setAttrValue(CmdArguments.INT_SPEC, AdmHelperCmd.getObject((AdmBaseId) cmd.execute()).getAdmSpec().getSpec());
        }

        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Part.class);
        return retResult;
    }
}

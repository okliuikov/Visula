/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.GlobalStageLifecycleHelper;
import merant.adm.dimensions.cmds.helper.SensitivityHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.AuthPointInfoRequiredException;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimFirstNormalStateNotAtInitialBuildStageException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimLcInconsistentLifecycleException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.LifeCycleStateTransition;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.system.PasswordAuthPointParam;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions LifeCycleStateTransition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteLifecycleStateTransitionCmd extends DBIOCmd {
    public DeleteLifecycleStateTransitionCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LifeCycleStateTransition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_LIFECYCLEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_LIFECYCLEMAN");
        }

        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final String fromState = (String) admObj.getAttrValue(AdmAttrNames.LCSTATETRANS_FROM_STATE);
        final String toState = (String) admObj.getAttrValue(AdmAttrNames.LCSTATETRANS_TO_STATE);
        final String lifecycleId = ((AdmSpec) admObj.getAdmBaseId().getScope()).getSpec();

        if (fromState == null || fromState.trim().length() == 0) {
            throw new DimInvalidAttributeException("Error: FROM_STATE not specified");
        }

        if (toState == null || toState.trim().length() == 0) {
            throw new DimInvalidAttributeException("Error: TO_STATE not specified");
        }

        if (lifecycleId == null || lifecycleId.trim().length() == 0) {
            throw new DimInvalidAttributeException("Error: LIFECYCLE_ID not specified");
        }

        if (!DoesExistHelper.transitionExists(lifecycleId, fromState, toState)) {
            throw new DimAlreadyExistsException("Error: The transition " + fromState + "->" + toState + " doesn't exist");
        }

        // Authentication is handled a bit differently in this class. If a password is supplied
        // on the command then run the XDATA command. Else the tests for sensitive lifecycle
        // states are run in the DBIO transaction below which are rolled back if authentication
        // is required and not supplied.
        boolean tmpPasswordValid = false;
        // YCai 18-May-06, is this correct - if any of the states is sensitive, then ask user for password?
        // if ((PasswordAuthPointInfo) getAttrValue(CmdArguments.AUTH_POINT_INFO) == null)
        // {
        if (SensitivityHelper.isLifecycleStateSensitive(lifecycleId, fromState)
                || SensitivityHelper.isLifecycleStateSensitive(lifecycleId, toState)) {
            PasswordAuthPointParam paramObj = new PasswordAuthPointParam(PasswordAuthPointParam.DELETE);
            paramObj.setLifecycleId(lifecycleId);
            paramObj.setStatus(toState);
            SensitivityHelper.getAuthentication(this, paramObj);
            tmpPasswordValid = true;
        }
        // }
        final boolean passwordValid = tmpPasswordValid;

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws AdmException {

                boolean wasAtInitialBuildStage = isFirstNormalStateAtInitialBuildStage(dbCtx, lifecycleId);

                if (GlobalStageLifecycleHelper.isLifecycleGSL(lifecycleId)) {
                    GlobalStageLifecycleHelper.isTransitionDeletable(dbCtx, lifecycleId, fromState, toState);
                }

                // delete lifecycle state transition
                deleteStateTransition(dbCtx, lifecycleId, fromState, toState, passwordValid);

                // regenerate normal lifecycle path
                generateNormalLifecycle(dbCtx, lifecycleId, false);

                deleteStageLifecycle(dbCtx, lifecycleId, fromState);
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

                deleteStageLifecycle(dbCtx, lifecycleId, toState);
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

                if (GlobalStageLifecycleHelper.isLifecycleGSL(lifecycleId)) {
                    GlobalStageLifecycleHelper.deleteGSLStage(dbCtx, lifecycleId, fromState, toState);
                } else if (wasAtInitialBuildStage) {
                    boolean isStillAtInitialBuildStage = isFirstNormalStateAtInitialBuildStage(dbCtx, lifecycleId);
                    if (!isStillAtInitialBuildStage) {
                        throw new DimFirstNormalStateNotAtInitialBuildStageException(
                                "Error: the first normal lifecycle state is no longer at the initial build stage.");
                    }
                }
            }
        });

        return "Operation Completed";
    }

    private void deleteStageLifecycle(DBIO query, String lifecycleId, String state) throws AdmException {

        query.resetMessage(wcm_sql.DELETE_STAGE_LIFE_CYCLE_BY_STATUSEX);
        query.bindInput(lifecycleId);
        query.bindInput(state);
    }

    private boolean isFirstNormalStateAtInitialBuildStage(DBIO dbCtx, String lifecycleId) throws AdmException {

        dbCtx.resetSQL("SELECT 'X' " + "FROM   norm_lifecycle nl, " + "       stage_lifecycles sl, " + "       stage_catalogue sc "
                + "WHERE  nl.lifecycle_id=:I1 and " + "       nl.state_seq_no=1 and " + "       nl.status=sl.status and "
                + "       sl.lifecycle_id=:I1 and " + "       sl.stage_uid=sc.stage_uid and " + "       sc.stage_seq=1");
        dbCtx.bindInput(lifecycleId);
        dbCtx.readStart();
        boolean isAtDevStage = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAtDevStage;
    }

    /**
     * Checks if a lifecycle state still exists once a transition is removed.
     */
    private boolean isStateAmongstTransitions(DBIO query, String lifecycleId, String state) throws AdmException {

        query.resetSQL("SELECT 'x' FROM life_cycles " + "WHERE lifecycle_id = :I1 "
                + "AND (doc_status = :I2 OR next_doc_status = :I2)");
        query.bindInput(lifecycleId);
        query.bindInput(state);
        query.readStart();
        boolean isValid = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);
        return isValid;
    }

    /**
     * Checks is a lifecycle state is sensitive.
     */
    private boolean isLifecycleStateSensitive(DBIO query, String lifecycleId, String state) throws AdmException {

        query.resetSQL("SELECT NVL(sensitive,'N') FROM lc_state_info WHERE lifecycle_id = :I1 AND status = :I2");
        query.bindInput(lifecycleId);
        query.bindInput(state);

        boolean isSensitive = false;
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            String tmpIsSensitive = query.getString(1);
            if ("Y".equals(tmpIsSensitive)) {
                isSensitive = true;
            }
        }
        query.close(DBIO.DB_DONT_RELEASE);
        return isSensitive;
    }

    /**
     * Removes the entry for a state in the lc_state_info table.
     */
    private void removeFromLcStateInfo(DBIO query, String lifecycleId, String state) throws AdmException {

        SqlUtils.deleteLcStateByStatus(query, lifecycleId, state);
        query.write(DBIO.DB_DONT_COMMIT);
    }

    /**
     * Regenerates and validates normal lifecycle path after an alteration of the lifecycle
     */
    private void generateNormalLifecycle(DBIO query, String lifecycleId, boolean addingTransition) throws DBIOException,
            DimBaseException, AdmException {
        Cmd cmd = AdmCmd.getCmd("_internal_generate_normal_lifecycle");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, query);
        cmd.setAttrValue(AdmAttrNames.LIFECYCLE_ID, lifecycleId);
        cmd.setAttrValue(CmdArguments.ADDING_TRANSITION, (addingTransition ? Boolean.TRUE : Boolean.FALSE));
        cmd.execute();
    }

    private void deleteStateTransition(DBIO query, String lifecycleId, String fromState, String toState, boolean passwordValid)
            throws DimBaseException, AttrException, AdmException {
        // do deletion
        query.resetMessage(wcm_sql.DELETE_LIFE_CYCLE_BY_DOC_NEXT_DOC_STATUS);
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.write(DBIO.DB_DONT_COMMIT);

        // Check if the from state is removed and whether it is sensitive or not.
        if (!isStateAmongstTransitions(query, lifecycleId, fromState)) {
            boolean isSensitive = isLifecycleStateSensitive(query, lifecycleId, fromState);
            if ((isSensitive && passwordValid) || !isSensitive) {
                removeFromLcStateInfo(query, lifecycleId, fromState);
            } else if (isSensitive && !passwordValid) {
                throw new AuthPointInfoRequiredException();
            }
        }

        // Check if the to state is removed and whether it is sensitive or not.
        if (!isStateAmongstTransitions(query, lifecycleId, toState)) {
            boolean isSensitive = isLifecycleStateSensitive(query, lifecycleId, toState);
            if ((isSensitive && passwordValid) || !isSensitive) {
                removeFromLcStateInfo(query, lifecycleId, toState);
            } else if (isSensitive && !passwordValid) {
                throw new AuthPointInfoRequiredException();
            }
        }

        // check for unreachable states
        query.resetSQL("SELECT COUNT(doc_status) FROM life_cycles " + "WHERE lifecycle_id = :I1 " + "AND doc_status = :I2 "
                + "AND NOT EXISTS (SELECT NULL FROM life_cycles " + "WHERE lifecycle_id = :I1 " + "AND next_doc_status = :I2) "
                + "AND NOT EXISTS (SELECT NULL FROM norm_lifecycle " + "WHERE lifecycle_id = :I1 " + "AND status = :I2 "
                + "AND state_seq_no = 1)");
        query.bindInput(lifecycleId);
        query.bindInput(toState);

        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            long counter = query.getLong(1);
            if (counter != 0) {
                throw new DimLcInconsistentLifecycleException("Error: Transition " + fromState + "->" + toState
                        + " cannot be deleted because the deletion will lead to an unreachable path headed by " + toState);
            }
        }
    }

    public static void deleteGSLStage(DBIO query, String lifecycleId, String fromState, String toState) throws DimBaseException,
            AttrException, AdmException {
        String stageToRemove = null;
        // first, is the from state still in the normal lifecycle?
        query.resetSQL("SELECT NULL FROM norm_lifecycle " + "WHERE lifecycle_id=:I1 AND status=:I2");
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.readStart();
        if (!query.read(DBIO.DB_DONT_CLOSE)) {
            stageToRemove = fromState;
        } else {
            query.resetSQL("SELECT NULL FROM norm_lifecycle " + "WHERE lifecycle_id=:I1 AND status=:I2");
            query.bindInput(lifecycleId);
            query.bindInput(toState);
            query.readStart();
            if (!query.read(DBIO.DB_DONT_CLOSE)) {
                stageToRemove = toState;

            }
        }
        if (stageToRemove != null) {
            // doo gud stuf eer
        }
    }
}
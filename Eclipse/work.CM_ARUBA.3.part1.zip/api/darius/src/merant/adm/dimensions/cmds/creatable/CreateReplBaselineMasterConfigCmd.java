/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.drs.DRSClientSysObjAttrUtils;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplBlnMasterConfig;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions master baseline replication configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.ID {String}<dt><dd>Identifier of the new master baseline replication configuration</dd>
 *  <dt>CmdArguments.BRANCHES{List}<dt><dd>The list of Branch objects that are to be replicated.</dd>
 *  <dt>CmdArguments.ITEM_TYPES{List}<dt><dd>The list of (item) Type objects that are to be replicated. This list must not
 *  include item types defined in the $GENERIC product.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.DESCRIPTION{String}<dt><dd>Description</dd>
 *  <dt>AdmAttrNames.REPL_IS_ENABLED{Boolean}<dt><dd>Whether the replication configuration is to be enabled. Default - Boolean.TRUE</dd>
 *  <dt>AdmAttrNames.REPL_IS_OFFLINE{Boolean}<dt><dd>Whether the replication configuration is offline. Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateReplBaselineMasterConfigCmd extends DBIOCmd {
    public CreateReplBaselineMasterConfigCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ITEM_TYPES, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_ENABLED, true, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_OFFLINE, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // extract and validate command arguments
        // extract command parameters
        final String configId = ValidationHelper.validateReplConfigId((String) getAttrValue(AdmAttrNames.ID));
        final String description = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));

        final List branchList = (List) getAttrValue(CmdArguments.BRANCHES);
        final List itemTypeList = (List) getAttrValue(CmdArguments.ITEM_TYPES);
        final boolean isEnabled = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_ENABLED)).booleanValue();
        final boolean isOffline = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_OFFLINE)).booleanValue();
        final boolean isTransfered = true;
        final boolean isReplicatesBack = false;

        if (branchList != null && branchList.size() > 0) {
            for (Iterator it = branchList.iterator(); it.hasNext();) {
                AdmObject branch = (AdmObject) it.next();
                if (branch == null || !(branch instanceof Branch)) {
                    throw new DimMandatoryAttributeException("Error: list of branches to be replicated must be specified.");
                }
            }
        }

        if (itemTypeList != null && itemTypeList.size() > 0) {

            for (Iterator it = itemTypeList.iterator(); it.hasNext();) {
                AdmObject itemType = (AdmObject) it.next();
                if (itemType == null || !(itemType instanceof Type)) {
                    throw new DimMandatoryAttributeException("Error: list of item types to be replicated must be specified.");
                }
                Class parentClass = (Class) AdmHelperCmd.getAttributeValue(itemType, AdmAttrNames.PARENT_CLASS);
                if (!Item.class.equals(parentClass)) {
                    throw new DimMandatoryAttributeException("Error: list of item types to be replicated must be specified.");
                }

                String productId = (String) AdmHelperCmd.getAttributeValue(itemType, AdmAttrNames.PRODUCT_NAME);
                if (Constants.GLOBAL_PRODUCT.equalsIgnoreCase(productId)) {
                    throw new DimInvalidAttributeException("Error: item type $GENERIC:" + itemType.getId()
                            + " is cannot be used to define a replication configuration.");
                }
            }
        }

        setAttrValue(CmdArguments.INT_SPEC, configId + ";0");

        final AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        final String thisSiteId = (thisSite != null) ? (String) AdmHelperCmd.getAttributeValue(thisSite, AdmAttrNames.SENDER_ID) : "";
        final long thisSiteUid = (thisSite != null) ? ((AdmUidObject) thisSite).getAdmUid().getUid() : 0;

        // do the work
        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws Exception {

                validateConfigData(dbCtx, configId, thisSiteUid);
                long configUid = getNewUid(dbCtx);
                insertConfigData(dbCtx, configUid, configId, description, thisSiteUid, thisSiteId, isEnabled, isTransfered,
                        isReplicatesBack, isOffline);

                if (branchList != null && branchList.size() > 0) {
                    validateBranchData(dbCtx, branchList, configId);
                    insertBranchData(dbCtx, branchList, configUid);
                }

                if (itemTypeList != null && itemTypeList.size() > 0) {
                    validateTypeData(dbCtx, itemTypeList, configId);
                    insertTypeData(dbCtx, itemTypeList, configUid);
                }
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ReplBlnMasterConfig.class);
        return retResult;
    }

    private void validateConfigData(DBIO dbCtx, String configId, long siteUid) throws Exception {

        if (masterReplConfigExists(dbCtx, configId, Constants.REPL_BASELINE_CLASS)) {
            throw new DimAlreadyExistsException("Error: the replication configuration " + configId + " has already been defined.");
        }

        String revision = getMaxConfigRevision(dbCtx, configId, Constants.REPL_BASELINE_CLASS);
        if (revision != null) {
            throw new DimAlreadyExistsException("Error: the replication configuration " + configId + " has already been defined.");
        }

        if (isAlreadyDefined(dbCtx, configId, Constants.REPL_BASELINE_CLASS, siteUid)) {
            throw new DimAlreadyExistsException("Error: these replication details have already been specified.");
        }
    }

    private void insertConfigData(DBIO dbCtx, long configUid, String configId, String description, long siteUid, String siteId,
            boolean isEnabled, boolean isTransfered, boolean isReplicatesBack, boolean isOffline) throws Exception {

        SqlUtils.replInsertConfig(dbCtx, configUid, configId, Constants.REPL_BASELINE_CLASS, "0", description);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.replInsertConfigDetails(dbCtx, configUid, siteUid, null, null, isEnabled, isTransfered, isReplicatesBack, siteId, null, isOffline);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private boolean isAlreadyDefined(DBIO dbCtx, String configId, int repClass, long baseDbUid) throws Exception {

        // despite the name of the SQL query, the query does apply for baseline replication configurations
        dbCtx.resetMessage(wcm_sql.REPL_SUBORD_CONFIG_IS_ALREADY_DEFINED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(baseDbUid);
        dbCtx.readStart();
        boolean defined = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return defined;
    }

    private boolean masterReplConfigExists(DBIO dbCtx, String configId, int replClass) throws DBIOException, DimBaseException,
            Exception {

        dbCtx.resetMessage(wcm_sql.REPL_MASTER_CONFIG_DOES_EXIST);

        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        boolean exists = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return exists;
    }

    private String getMaxConfigRevision(DBIO dbCtx, String configId, int replClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_GET_MAX_REVISION);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        String lastRevision = (dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getString(1) : null);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return lastRevision;
    }

    private boolean isSpecialBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass)
            throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_IS_SPECIAL_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private boolean isBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_IS_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private void validateBranchData(DBIO dbCtx, List branchList, String configId) throws Exception {

        validateBranchList(dbCtx, branchList);

        for (Iterator it = branchList.iterator(); it.hasNext();) {
            AdmObject branchObj = (AdmObject) it.next();
            String branchName = branchObj.getId();

            // check if this branch has already been defined for this replication config
            boolean isAssigned = false;
            if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)) {
                isAssigned = isSpecialBranchAssigned(dbCtx, Constants.REPL_ALL_LOCAL_BRANCHES_UID, configId, "0",
                        Constants.REPL_BASELINE_CLASS);
            } else if (branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
                isAssigned = isSpecialBranchAssigned(dbCtx, Constants.REPL_ALL_NAMED_BRANCHES_UID, configId, "0",
                        Constants.REPL_BASELINE_CLASS);
            } else {
                long branchUid = getBranchUid(dbCtx, branchName);
                isAssigned = isBranchAssigned(dbCtx, branchUid, configId, "0", Constants.REPL_BASELINE_CLASS);
            }

            if (isAssigned) {
                throw new DimAlreadyExistsException("Error: the branch name " + branchName
                        + "is already defined for configuration " + configId + ".");
            }

        }
    }

    private void validateBranchList(DBIO dbCtx, List branchList) throws Exception {
        Cmd cmd = AdmCmd.getCmd("_internal_validate_branch_list");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, dbCtx);
        cmd.setAttrValue(CmdArguments.BRANCHES, branchList);
        cmd.execute();
    }

    private void insertBranchData(DBIO dbCtx, List branchList, long configUid) throws Exception {

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        for (Iterator it = branchList.iterator(); it.hasNext();) {
            AdmObject branchObj = (AdmObject) it.next();
            String branchName = branchObj.getId();

            long relUid = getNewUid(dbCtx);
            long branchUid = getBranchUid(dbCtx, branchName);

            dbCtx.resetMessage(wcm_sql.REPL_ASSIGN_BRANCH_TO_CONFIG);
            dbCtx.bindInput(relUid);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(branchUid);
            dbCtx.bindInput(userName);
            dbCtx.write(DBIO.DB_DONT_COMMIT);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
        }
    }

    private boolean isTypeAssigned(DBIO dbCtx, long typeUid, String configId, String revision, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_IS_TYPE_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(typeUid);
        dbCtx.bindInput(Constants.REPL_ITEM_TYPE_REL_CLASS);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private void validateTypeData(DBIO dbCtx, List itemTypeList, String configId) throws Exception {

        for (Iterator it = itemTypeList.iterator(); it.hasNext();) {
            AdmObject typeObj = (AdmObject) it.next();
            String productName = (String) typeObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
            String typeName = (String) typeObj.getAttrValue(AdmAttrNames.ID);
            // check if this item type has already been defined for this replication config
            long typeUid = getItemTypeUid(dbCtx, productName, typeName);
            boolean isAssigned = isTypeAssigned(dbCtx, typeUid, configId, "0", Constants.REPL_BASELINE_CLASS);

            if (isAssigned) {
                throw new DimAlreadyExistsException("Error: the item type " + productName + ":" + typeName
                        + "is already defined for configuration " + configId + ".");
            }

        }
    }

    private void insertTypeData(DBIO dbCtx, List itemTypeList, long configUid) throws Exception {

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        for (Iterator it = itemTypeList.iterator(); it.hasNext();) {

            AdmObject typeObj = (AdmObject) it.next();
            String productName = (String) typeObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
            String typeName = (String) typeObj.getAttrValue(AdmAttrNames.ID);
            // check if this item type has already been defined for this replication config
            long typeUid = getItemTypeUid(dbCtx, productName, typeName);
            if (typeUid == -1) {
                throw new DimNotExistsException("Error: item type " + productName + ":" + typeName + " does not exist.");
            }

            long relUid = getNewUid(dbCtx);

            SqlUtils.replAssignTypeToConfig(dbCtx, relUid, configUid, typeUid, Constants.REPL_ITEM_TYPE_REL_CLASS, userName);
            dbCtx.write(DBIO.DB_DONT_COMMIT);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
        }
    }

    private long getBranchUid(DBIO dbCtx, String branchName) throws Exception {
        long branchUid = -1;
        if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_LOCAL_BRANCHES_UID;
        } else if (branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_NAMED_BRANCHES_UID;
        } else {
            DRSClientSysObjAttrUtils drs = new DRSClientSysObjAttrUtils(DRSClientSysObjAttrUtils.SysObjAttrUtilsQueryContext.GetAdmUids);
            drs.setObjClass(DRSClientSysObjAttrUtils.SYSOBJ_NAMED_BRANCH);
            drs.setAdmId(branchName);
            DRSUtils.execute(drs);

            if (drs.hasData() && (drs.getAdmUids() != null) && (drs.getAdmUids().length > 0)) {
            	branchUid = drs.getAdmUids()[0];
            }
        }

        return branchUid;
    }

    private long getItemTypeUid(DBIO dbCtx, String productName, String typeName) throws Exception {
        dbCtx.resetSQL("SELECT type_uid FROM obj_types WHERE product_id=UPPER(:I1) AND type_name=UPPER(:I2) AND type_flag='I'");
        dbCtx.bindInput(productName);
        dbCtx.bindInput(typeName);
        dbCtx.readStart();
        long typeUid = dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getLong(1) : -1;
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return typeUid;
    }
}

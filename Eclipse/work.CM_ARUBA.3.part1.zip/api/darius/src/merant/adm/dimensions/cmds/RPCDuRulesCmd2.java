/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Get the default values as an array of hashmap entries
 * { "$COMMENT", PCMS_ATTR_COMMENT },
 * { "$DESCRIPTION", PCMS_ATTR_DESCRIPTION },
 * { "$DIRPATH", PCMS_ATTR_DIRPATH },
 * { "$FILENAME", PCMS_ATTR_FILENAME },
 * { "$FORMAT", PCMS_ATTR_FORMAT },
 * { "$ITEM_ID", PCMS_ATTR_OBJ_ID },
 * { "$LIB_FILENAME", PCMS_ATTR_LIB_FILENAME },
 * { "$OWNING_PART_ID", PCMS_ATTR_OWNING_PART_ID },
 * { "$OWNING_PART_PCS", PCMS_ATTR_OWNING_PART_PCS },
 * { "$OWNING_PART_VARIANT", PCMS_ATTR_OWNING_PART_VARIANT },
 * { "$PRODUCT_ID", PCMS_ATTR_PRODUCT_ID },
 * { "$REVISION", PCMS_ATTR_REVISION },
 * { "$STATUS", PCMS_ATTR_STATUS },
 * { "$TYPE", PCMS_ATTR_TYPE_NAME },
 * { "$VARIANT", PCMS_ATTR_VARIANT },
 * { "$WSPATH", PCMS_ATTR_WSPATH }
 */
public class RPCDuRulesCmd2 extends RPCCmd {
    public RPCDuRulesCmd2() throws AdmObjectException, AttrException {
        super();
        setAlias("RPC DuRules2");
        AddArgument("cmd", "PcmsDuRulesCommand2");
        setAttrDef(new CmdArgDef("ruleid", true, "", "", ""));
        setAttrDef(new CmdArgDef("project", true, "", "", ""));
        setAttrDef(new CmdArgDef("product", false, null, "", ""));
        setAttrDef(new CmdArgDef("workset", true, "", "", ""));
        setAttrDef(new CmdArgDef("worksetRoot", true, "", "", ""));
        setAttrDef(new CmdArgDef("contextRoot", false, null, "", ""));
        setAttrDef(new CmdArgDef("filenames", true, "", "", ""));
        setAttrDef(new CmdArgDef("extended", false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef("variables", false, null, "", ""));
    }

    @Override
    public Object execute() throws AdmException {

        String attrs[][][] = null;

        try {
            attrs = getSession().getConnection().rpcDuRules2((String) getAttrValue("ruleid"), (String) getAttrValue("project"),
                    (String) getAttrValue("product"), (String) getAttrValue("workset"), (String) getAttrValue("worksetRoot"),
                    (String) getAttrValue("contextRoot"), (String[]) getAttrValue("filenames"),
                    (String[]) getAttrValue("variables"), ((Boolean) getAttrValue("extended")).booleanValue());
        } catch (AttrException e) {
            return Constants.SERVER_FAIL;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

        Map[] ret = null;
        if (attrs != null) {
            ret = new HashMap[attrs.length];
            for (int i = 0; i < attrs.length; i++) {
                if (attrs[i] != null) {
                    ret[i] = new HashMap();
                    for (int j = 0; j < attrs[i].length; j++) {
                        ret[i].put(attrs[i][j][0], attrs[i][j][1]);
                    }
                }
            }
        }
        return ret;

    }

}

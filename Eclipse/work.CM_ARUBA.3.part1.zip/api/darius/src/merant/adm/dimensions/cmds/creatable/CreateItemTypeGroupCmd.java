/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.ArrayList;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ItemTypeGroup;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions ItemTypeGroup.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name used for role checking</dd>
 *  <dt>ID {String}</dt><dd>Name identifier of the new item type group</dd>
 *  <dt>TYPE_NAME {String}</dt><dd>Initial item type name to associate with this new item type group</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz, vadym Krevs
 */
public class CreateItemTypeGroupCmd extends DBIOCmd {
    public CreateItemTypeGroupCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, true, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(AdmAttrNames.ITEMTYPEGRP_ITEM_TYPE_OBJ)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        String productName = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.PRODUCT_NAME));
        String id = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.ID));

        String typeId = (String) getAttrValue(AdmAttrNames.TYPE_NAME);

        if (!DoesExistHelper.productExists(productName)) {
            throw new DimNotExistsException("Error: product " + productName + " does not exist.");
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        if (DoesExistHelper.itemTypeGroupExists(id)) {
            throw new DimAlreadyExistsException("Error: item type group " + id + " has already been defined.");
        }

        if (!DoesExistHelper.typeExists(productName, typeId, "I")) {
            throw new DimNotExistsException("Error: item type " + typeId + " does not exist in product " + productName);
        }

        if (itemTypeExists(id)) {
            throw new DimAlreadyExistsException("Error: item type group name " + id
                    + " is already used by an item type, please specify another name.");
        }

        DBIO query = SqlUtils.itmtypegrpAdd(id, typeId);
        query.write();

        setAttrValue(CmdArguments.INT_SPEC, id);
        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ItemTypeGroup.class);
        return retResult;
    }

    private boolean itemTypeExists(String itemTypeGroupName) throws DBIOException, DimBaseException, AdmException {
        String queryStr = "SELECT NULL FROM obj_types WHERE type_flag='I' AND type_name=:I1 AND ROWNUM = 1";

        ArrayList inputs = new ArrayList(1);
        inputs.add(itemTypeGroupName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, queryStr);
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }
}

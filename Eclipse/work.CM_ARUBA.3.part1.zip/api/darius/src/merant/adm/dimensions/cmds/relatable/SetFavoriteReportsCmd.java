/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import com.serena.dmnet.Constants;
import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.helper.IDMUtilsHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.objects.IDMReport;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

import java.util.List;

public class SetFavoriteReportsCmd extends AdmCmd {

    public SetFavoriteReportsCmd() throws AttrException {
        super();
        setAlias("SetFavoriteReportsCmd");
        setAttrDef(new CmdArgDef(CmdArguments.USER_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT_UID, true, Long.class));
        setAttrDef(new CmdArgDef(CmdArguments.FAVORITE_REPORTS, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.ACTIVE_FAVORITE_UUID_REPORT, false, String.class));
    }

    @Override
    public Object execute() throws AdmException {
        try {
            String userName = (String) getAttrValue(CmdArguments.USER_NAME);
            String activeUUID = (String) getAttrValue(CmdArguments.ACTIVE_FAVORITE_UUID_REPORT);
            long prodUid = (Long) getAttrValue(CmdArguments.PRODUCT_UID);
            List<IDMReport> reports = (List<IDMReport>) getAttrValue(CmdArguments.FAVORITE_REPORTS);
            IDMUtilsHelper.persistFavoriteReports(Constants.INVALID_UID, Constants.INVALID_UID, prodUid, reports, userName, activeUUID);
        } catch (Exception e) {
            Debug.error(e);
            throw new AdmException(e);
        }
        return merant.adm.dimensions.server.core.Constants.SERVER_OK;
    }
}

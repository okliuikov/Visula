/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2000 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;

import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdFactory;

/**
 * Uses a temporary file as an InputStream, the first overridden InputStream
 * public method call actually opens the file and it is deleted when the stream
 * is closed.
 * The intended use of this class is as follows:
 * Some legacy code exists that copies data to a temporary file, it then needs
 * to return the temporary file's filename back to its caller and the caller
 * must be sure to delete the temporary file.
 * Using this class, the legacy code can be wrapped. Instead of using
 * java.io.File.createTempFile() to create a temporary file, instantiate an
 * object of this class and use getAbsolutePath() to find its filename. When
 * the legacy code has finished writing data into this file, the wrapper can
 * just return this object which acts just like a FileInputStream, but will
 * delete the temporary file when the stream is closed or finalized.
 * 
 * @author David Conneely.
 * 
 */
public class TempFileInputStream extends InputStream {

    public static int BUFFER_SIZE = 1024;
    /**
     * The only constructor creates the temporary file,
     * but doesn't open it yet.
     */
    public TempFileInputStream() throws AdmObjectException, Exception, AttrException, DimBaseCmdException, IOException {
        String fname = TempFileInputStream.getTempFileName();

        file = new File(fname);
        file.createNewFile();
    }

    /**
     * Generates a unique temporary filename.
     */
    public static String getTempFileName() throws AdmObjectException, AdmException, AttrException, DimBaseCmdException {
        String ret = null;

        CmdFactory factory = DimSystem.getSystem().getAdmCmdFactory();
        RPCCmd cmd = (RPCCmd) factory.getCmd("GetTempFile");
        String result = (String) cmd.execute();

        ret = result.substring(Constants.SERVER_OK.length());
        ret = ret.trim();

        return ret;
    }

    /**
     * Find out where the temporary file being used by this stream is.
     * @return The absolute path of the File object that will be used to read from.
     */
    public String getAbsolutePath() {
        return file.getAbsolutePath();
    }

    public String getCanonicalPath() throws IOException {
        return file.getCanonicalPath();
    }

    public String getName() {
        return file.getName();
    }

    public String getParent() {
        return file.getParent();
    }

    public String getPath() {
        return file.getPath();
    }

    public boolean setLastModified(long time) {
        return file.setLastModified(time);
    }

    public boolean setReadOnly() {
        return file.setReadOnly();
    }

    @Override
    public String toString() {
        return file.toString();
    }

    public URL toURL() throws MalformedURLException {
        return file.toURL();
    }

    /**
     * Create the contained FileInputStream if it hasn't been opened
     * yet and delegate the read to it.
     * @param The
     *            byte read from the stream, or -1 if eof.
     */
    @Override
    public int read() throws IOException {
        initStream();
        return is.read();
    }

    @Override
    public int read(byte[] b) throws IOException {
        initStream();
        return is.read(b);
    }

    /**
     * Read the content of the temporary file and delete it.
     */
    public static String readAsString(String fname) throws IOException {
        File f = new File(fname);

        StringBuffer ret = new StringBuffer();
        InputStream fis = null;
        Reader reader = null;
        try {
            fis = new FileInputStream(f);
            reader = new BufferedReader(StringUtils.createEncodingReader(fis));
            char[] buf = new char[BUFFER_SIZE];
            while (true) {
                int size = reader.read(buf);
                if (size < 0) {
                    break;
                }
                ret.append(buf, 0, size);
            }
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    Debug.debug(ex);
                }
            }
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException ex) {
                    Debug.debug(ex);
                }
            }
            f.delete();
        }

        return ret.toString();
    }

    /**
     * Read the content of this temporary file and delete it.
     */
    public String readAsString() throws IOException {
        initStream();

        StringBuffer ret = new StringBuffer();
        Reader reader = null;
        try {
            reader = new BufferedReader(StringUtils.createEncodingReader(is));
            char[] buf = new char[BUFFER_SIZE];
            while (true) {
                int size = reader.read(buf);
                if (size < 0) {
                    break;
                }
                ret.append(buf, 0, size);
            }
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    Debug.debug(ex);
                }
            }
            killStream();
        }

        return ret.toString();
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        initStream();
        return is.read(b, off, len);
    }

    @Override
    public long skip(long n) throws IOException {
        initStream();
        return is.skip(n);
    }

    @Override
    public int available() throws IOException {
        initStream();
        return is.available();
    }

    /**
     * Closes the contained stream and deletes the temporary file
     * when the containing stream is closed.
     */
    @Override
    public void close() throws IOException {
        killStream();
    }

    /**
     * Closes the contained stream and deletes the temporary file
     * when the last reference is released on this object.
     */
    @Override
    public void finalize() throws IOException {
        close();
    }

    /**
     * Helper method to create contained stream.
     */
    private void initStream() throws IOException {
        if (is == null) {
            is = new FileInputStream(file);
        }
    }

    /**
     * Helper method to destroy contained stream.
     */
    private void killStream() throws IOException {
        if (is != null) {
            is.close();
            is = null;
        }
        file.delete();
        file = null;
    }

    private File file = null;

    private FileInputStream is = null;
}

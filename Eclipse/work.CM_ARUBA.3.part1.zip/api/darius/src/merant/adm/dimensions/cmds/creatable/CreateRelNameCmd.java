/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.RelationshipName;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Item Type RelationshipName.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new relationship name</dd>
 *  <dt>DESCRIPTION {String}<dt><dd>description</dd>
 * </dl></code> <br>
 * <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateRelNameCmd extends DBIOCmd {
    public CreateRelNameCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_ITEMRELSMAN")) {
            throw new DimNoPrivilegeException("ADMIN_ITEMRELSMAN");
        }

        String relName = ValidationHelper.validateRelName((String) getAttrValue(AdmAttrNames.ID));
        String description = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));

        if (DoesExistHelper.relationshipNametExists(relName)) {
            throw new DimAlreadyExistsException("Error: relationship name " + relName + " already exists.");
        }

        setAttrValue(CmdArguments.INT_SPEC, relName);

        // if (StringUtils.containsSpecialChars(relName))
        // throw new
        // DimInvalidAttributeException("Error: The relationship name must not contain one or more of the following disallowed characters: "+
        // "<space>\"%/\\$.;-=()[]{}'");

        long relUid = getNewUid();
        String userName = AdmCmd.getCurRootObj(User.class).getId();

        DBIO query = new DBIO(wcm_sql.RELNAME_INSERT);
        query.bindInput(relUid);
        query.bindInput(relName);
        query.bindInput(description != null ? description : "");
        query.bindInput(userName);
        query.write();
        query.close();

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, RelationshipName.class);
        return retResult;
    }
}

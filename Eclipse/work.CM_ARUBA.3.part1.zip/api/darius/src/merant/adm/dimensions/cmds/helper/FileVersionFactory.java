package merant.adm.dimensions.cmds.helper;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;

import com.serena.dmfile.FilePath;
import com.serena.dmfile.FilePlatforms;
import com.serena.dmfile.dto.Triplet;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.server.drs.objects.FileVersion;
import merant.adm.dimensions.server.drs.objects.TreeVersion;
import merant.adm.dimensions.util.DateUtils;

public class FileVersionFactory {

    // <obj_spec_uid, forest_version, parentpath> -> latest FileVersion
    private HashMap<Triplet<Long, Long, String>, FileVersion> cachedFileVersions = new HashMap<Triplet<Long, Long, String>, FileVersion>();


    static FileVersion makeNewFileVersion(final TreeVersion tv, final long objUid, final long objSpecUid, final int type,
            final String path, final String user, final String dateTime, final AdmBaseId scopeBaseId) {

        FileVersion fv = new FileVersion(tv);
        fv.setUid(objUid);
        fv.setSpecUid(objSpecUid);
        fv.setIsFolder(type == 0);
        fv.setUser(user);

        try {
            fv.setDate(DateUtils.parseDate(dateTime, DateUtils.DATE_PATTERN_1));
        } catch (ParseException e) {
            fv.setDate(new Date(0L));
        }

        if (path.isEmpty() || path.equals("/")) {
            fv.setIsRoot(true);
            fv.setPath("/");
            fv.setName("/");
        } else {
            fv.setIsRoot(false);
            fv.setPath(path);
            String[] parts = path.split("/");
            if (parts.length > 0) {
                fv.setName(parts[parts.length - 1]);
            } else {
                fv.setName(path);
            }
        }

        AdmBaseId baseId = AdmHelperCmd.newAdmBaseId(fv.getUid(), fv.isFile() ? ItemFile.class : DimDirectory.class,
                scopeBaseId);
        fv.setAdmBaseId(baseId);
        return fv;
    }

    FileVersion getCachedFileVersion(final long forestVersion, final long objSpecUid, final String parentDir) {
        Triplet<Long, Long, String> key = new Triplet<Long, Long, String>(objSpecUid, forestVersion, parentDir);
        return cachedFileVersions.get(key);
    }

    FileVersion createFileVersion(final TreeVersion tv, final long objUid, final long objSpecUid, final int type,
            final String path, final String user, final String dateTime, final AdmBaseId scopeBaseId) {
        FilePath fp = new FilePath(path, FilePlatforms.UNIX);
        Triplet<Long, Long, String> key = new Triplet<Long, Long, String>(objSpecUid, tv.getForestVersion(),
                fp.getPathFront());
        FileVersion fv = cachedFileVersions.get(key);
        if (fv != null) {
            if (fv.getUid() != objUid || !path.equals(fv.getPath())) {
                cachedFileVersions.remove(key);
                fv = null;
            }
        }
        if (fv == null) {
            fv = makeNewFileVersion(tv, objUid, objSpecUid, type, path, user, dateTime, scopeBaseId);
            cachedFileVersions.put(key, fv);
        }

        return fv;
    }
}

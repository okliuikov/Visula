/*
 * -----------------------------------------------------------------------------
 * Copyright (c) 2005 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Copy default IDE rules
 */
public class RPCCopyRulesCmd extends RPCCmd {
    public RPCCopyRulesCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("RPC CopyDuRules");
        AddArgument("cmd", "PcmsCopyDuRulesCommand");
        setAttrDef(new CmdArgDef("ruleid", true, "", "", ""));
        setAttrDef(new CmdArgDef("ideProject", true, "", "", ""));
        setAttrDef(new CmdArgDef("partId", false, null, "", ""));
    }

    @Override
    public Object execute() throws AdmException {

        boolean rpcret;

        try {
            rpcret = getSession().getConnection().rpcCopyDuRules((String) getAttrValue("ruleid"),
                    (String) getAttrValue("ideProject"), (String) getAttrValue("partId"));
        } catch (AttrException e) {
            return Constants.SERVER_FAIL;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        if (rpcret) {
            return Constants.SERVER_OK;
        } else {
            return Constants.SERVER_FAIL;
        }
    }

}

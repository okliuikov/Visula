/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.serena.dmnet.LCNetClnt;
import com.serena.dmnet.drs.DRSClientFindBranchLinks;
import com.serena.dmnet.drs.DRSClientFindChangesets;
import com.serena.dmnet.drs.DRSClientFindChangesetsByPath;
import com.serena.dmnet.drs.DRSClientListTreeVersions;
import com.serena.dmnet.drs.DRSClientQueryRepositoryVersion;

import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.VrsConstants;
import merant.adm.dimensions.server.core.VrsOptions;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.ChangeSet;
import merant.adm.dimensions.server.drs.objects.ChangeSetHandler;
import merant.adm.dimensions.server.drs.objects.ImportedChangeStep;
import merant.adm.dimensions.server.drs.objects.TreeBranchLink;
import merant.adm.dimensions.server.drs.objects.TreeBranchLinkHandler;
import merant.adm.dimensions.server.drs.objects.TreeVersion;
import merant.adm.dimensions.server.drs.objects.TreeVersionHandler;
import merant.adm.dimensions.server.drs.objects.VersionProperty;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.DateUtils;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.session.Session;

public class RepositoryVersionHelper {

    public static void findLatestTreeVersions(long start, long end, Long[] treeUids, TreeVersionHandler handler, int options)
            throws AdmException {

        DRSClientListTreeVersions drs = new DRSClientListTreeVersions(
                DRSClientListTreeVersions.ForestVersionQueryContext.ListLatestForestVersions);
        if (start <= 0) {
            drs.setStartForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setStartForestVersion(start);
        }

        if (end <= 0) {
            drs.setEndForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setEndForestVersion(end);
        }
        drs.setFilterTreeUids(treeUids);
        drs.setOptions(options);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] changeSetUids = drs.getChangesetUids();
            int[] forestVersions = drs.getForestVersions();
            int[] treeClasses = drs.getTreeClasses();
            String[] treeSpecs = drs.getTreeSpecs();
            int[] treeUids2 = drs.getTreeUids();
            int[] treeVersions = drs.getTreeVersions();

            for (int i = 0; i < forestVersions.length; ++i) {
                TreeVersion tv = new TreeVersion();
                tv.setChangeSetUid(changeSetUids[i]);
                tv.setForestVersion(forestVersions[i]);
                tv.setTreeClass(treeClasses[i]);
                tv.setTreeSpec(treeSpecs[i]);
                tv.setTreeUid(treeUids2[i]);
                tv.setTreeVersion(treeVersions[i]);
                handler.handleTreeVersion(tv);
            }
        }
    }

    public static void findChangeSets(long start, long end, Long[] treeUids, String[] propertyNames,
                                      ChangeSetHandler handler, int options, int changesetOptions) throws AdmException {

        DRSClientFindChangesets drs = new DRSClientFindChangesets();

        if (start <= 0) {
            drs.setStartForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setStartForestVersion(start);
        }

        if (end <= 0) {
            drs.setEndForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setEndForestVersion(end);
        }

        if (treeUids != null && treeUids.length > 0) {
            drs.setFilterTreeUids(treeUids);
        }

        if (propertyNames != null && propertyNames.length > 0) {
            drs.setFilterPropertyNames(propertyNames);
        }

        if ((changesetOptions & VrsOptions.INCLUDE_PROPERTY_CHANGESET_TYPES) != 0) {
            drs.setIncludeProperties(true);
        }

        if ((changesetOptions & VrsOptions.INCLUDE_ALL_CHANGESET_TYPES) != VrsOptions.INCLUDE_ALL_CHANGESET_TYPES) {
            List<Long> changesetTypes = new ArrayList<Long>();
            if ((changesetOptions & VrsOptions.INCLUDE_CONTENT_CHANGESET_TYPES) != 0) {
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_DELIVER));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_UPGRADE));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_HISTORY_ONLY));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_MIGRATED));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_BLD_COLLECTION));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_U141_UPGRADE));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_UNDO));
            }
            if ((changesetOptions & VrsOptions.INCLUDE_BRANCHMERGE_CHANGESET_TYPES) != 0) {
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_BRANCH));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_MERGE));
            }
            if ((changesetOptions & VrsOptions.INCLUDE_PROMOTION_CHANGESET_TYPES) != 0) {
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_PROMOTION));
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_DEMOTION));
            }
            if ((changesetOptions & VrsOptions.INCLUDE_SHELF_CHANGESET_TYPES) != 0) {
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_SHELF));
            }
            if ((changesetOptions & VrsOptions.INCLUDE_UNDO_CHANGESET_TYPES) != 0) {
                changesetTypes.add(new Long(VrsConstants.VRS_CS_TYPE_UNDO));
            }
            Long[] filterChangesetTypes = changesetTypes.toArray(new Long[changesetTypes.size()]);
            drs.setFilterChangesetTypes(filterChangesetTypes);
        }

        drs.setOptions(options);

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            loadChangeSets(drs, handler);
        }
    }

    public static void findChangeSetsByPath(long start, long end, String searchPath, boolean strictPathHistory, boolean recursive,
            int maxCount, boolean includePropertyChangeSets, boolean queryChangeSteps, String[] propertyNames, ChangeSetHandler handler)
            throws AdmException {
        DRSClientFindChangesetsByPath drs = new DRSClientFindChangesetsByPath();

        if (start <= 0) {
            drs.setStartForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setStartForestVersion(start);
        }

        if (end <= 0) {
            drs.setEndForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setEndForestVersion(end);
        }

        drs.setIncludeProperties(includePropertyChangeSets);
        drs.setQueryChangeSteps(queryChangeSteps);
        drs.setRecursive(recursive);
        drs.setStrictPathHistory(strictPathHistory);
        drs.setMaxCount(maxCount);

        if (StringUtils.isBlank(searchPath)) {
            drs.setSearchPath("");
        } else {
            drs.setSearchPath(searchPath);
        }

        if (propertyNames != null && propertyNames.length > 0) {
            drs.setFilterPropertyNames(propertyNames);
        }

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            loadChangeSetsByPath(drs, handler);
        }
    }

    public static void findBranchLinks(long start, long end, Long[] treeUids, TreeBranchLinkHandler handler, int options,
            int linkTypeOptions) throws AdmException {

        DRSClientFindBranchLinks drs = new DRSClientFindBranchLinks();

        if (start <= 0) {
            drs.setStartForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setStartForestVersion(start);
        }

        if (end <= 0) {
            drs.setEndForestVersion(TreeVersion.INVALID_VERSION);
        } else {
            drs.setEndForestVersion(end);
        }

        if (treeUids != null && treeUids.length > 0) {
            drs.setFilterTreeUids(treeUids);
        }

        drs.setOptions(options);
        drs.setLinkTypeOptions(linkTypeOptions);

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            loadBranchLinks(drs, handler);
        }

    }

    public static void findTreeVersions(Long[] versionNumbers, TreeVersionHandler handler) throws AdmException {
        DRSClientListTreeVersions drs = new DRSClientListTreeVersions(
                DRSClientListTreeVersions.ForestVersionQueryContext.QueryForestVersions);

        drs.setFilterForestVersions(versionNumbers);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] changeSetUids = drs.getChangesetUids();
            int[] forestVersions = drs.getForestVersions();
            int[] treeClasses = drs.getTreeClasses();
            String[] treeSpecs = drs.getTreeSpecs();
            int[] treeUids = drs.getTreeUids();
            int[] treeVersions = drs.getTreeVersions();

            for (int i = 0; i < forestVersions.length; ++i) {
                TreeVersion tv = new TreeVersion();
                tv.setChangeSetUid(changeSetUids[i]);
                tv.setForestVersion(forestVersions[i]);
                tv.setTreeClass(treeClasses[i]);
                tv.setTreeSpec(treeSpecs[i]);
                tv.setTreeUid(treeUids[i]);
                tv.setTreeVersion(treeVersions[i]);
                handler.handleTreeVersion(tv);
            }
        }
    }

    public static void findTreeVersions(long treeUid, TreeVersionHandler handler) throws AdmException {
        DRSClientListTreeVersions drs = new DRSClientListTreeVersions(
                DRSClientListTreeVersions.ForestVersionQueryContext.QueryTreeVersions);

        drs.setTreeUid(treeUid);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] changeSetUids = drs.getChangesetUids();
            int[] forestVersions = drs.getForestVersions();
            int[] treeClasses = drs.getTreeClasses();
            String[] treeSpecs = drs.getTreeSpecs();
            int[] treeUids = drs.getTreeUids();
            int[] treeVersions = drs.getTreeVersions();

            for (int i = 0; i < forestVersions.length; ++i) {
                TreeVersion tv = new TreeVersion();
                tv.setChangeSetUid(changeSetUids[i]);
                tv.setForestVersion(forestVersions[i]);
                tv.setTreeClass(treeClasses[i]);
                tv.setTreeSpec(treeSpecs[i]);
                tv.setTreeUid(treeUids[i]);
                tv.setTreeVersion(treeVersions[i]);
                handler.handleTreeVersion(tv);
            }
        }
    }

    public static void findChangeSets(Long[] changeSetUids, Long[] versionNumbers, ChangeSetHandler handler) throws AdmException {

        if (versionNumbers == null && changeSetUids == null) {
            throw new IllegalArgumentException("Either changeSetUids[] or versionNumbers[] is required");
        } else if (versionNumbers != null && changeSetUids != null) {
            throw new IllegalArgumentException("Only one of changeSetUids[] and versionNumbers[] may be specified");
        }
       
        DRSClientFindChangesets drs = new DRSClientFindChangesets();

        if (versionNumbers != null) {
            drs.setFilterForestVersions(versionNumbers);
        }
        if (changeSetUids != null) {
            drs.setFilterChangeSetUids(changeSetUids);
        }

        drs.setIncludeProperties(true); // always return property changesets because user already knows their uid's or versions

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            loadChangeSets(drs, handler);
        }        	
    }

    private static void loadBranchLinks(DRSClientFindBranchLinks drs, TreeBranchLinkHandler handler) throws AdmException {

        int[] branchLinkClasses = drs.getBranchLinkClasses();
        int[] branchLinkSourceForestVersions = drs.getBranchLinkSourceForestVersions();
        int[] branchLinkTargetForestVersions = drs.getBranchLinkTargetForestVersions();

        // int[] branchLinkTypes = drs.getBranchLinkTypes(); // VADYMK:
        // Not used at the moment
        String[] branchLinkFolderScopes = drs.getBranchLinkFolderScopes();

        boolean haveBranchLinks = branchLinkClasses != null && branchLinkClasses.length > 0;
        if (haveBranchLinks) {

            Set<Long> uniqueVersions = new TreeSet<Long>();
            for (int i = 0; i < branchLinkClasses.length; ++i) {
                uniqueVersions.add((long) branchLinkTargetForestVersions[i]);
                uniqueVersions.add((long) branchLinkSourceForestVersions[i]);
            }

            Long[] forestVersions = uniqueVersions.toArray(new Long[uniqueVersions.size()]);
            Map<Long, TreeVersion> versionInfo = new TreeMap<Long, TreeVersion>();
            queryForestVersions(forestVersions, versionInfo);

            for (int i = 0; i < branchLinkClasses.length; ++i) {

                TreeVersion target = versionInfo.get((long) branchLinkTargetForestVersions[i]);
                if (null == target) {
                    throw new AdmException(String.format("Missing tree version data for repository version %d",
                            branchLinkTargetForestVersions[i]));
                }

                TreeBranchLink branchLink = new TreeBranchLink();
                branchLink.setType(branchLinkClasses[i] == 0 ? TreeBranchLink.TYPE.CREATE : TreeBranchLink.TYPE.MERGE);
                branchLink.setTarget(target);

                TreeVersion source = versionInfo.get((long) branchLinkSourceForestVersions[i]);
                if (null != source) {

                    branchLink.setSource(source);
                    branchLink.setFolderScope(branchLinkFolderScopes[i]);
                }

                handler.handleTreeBranchLink(branchLink);
            }
        }
    }

    private static void queryForestVersions(Long[] forestVersions, final Map<Long, TreeVersion> versionInfo) throws AdmException {

        findTreeVersions(forestVersions, new TreeVersionHandler() {

            @Override
            public void handleTreeVersion(TreeVersion version) {
                versionInfo.put(version.getForestVersion(), version);
            }
        });
    }

    private static void loadChangeSets(DRSClientFindChangesets drs, ChangeSetHandler handler) throws AdmException {

        int[] changesetUids = drs.getChangesetUids();
        int[] changesetTypes = drs.getChangesetTypes();
        String[] changesetDatetimes = drs.getChangesetDatetimes();
        String[] changesetAuthors = drs.getChangesetAuthors();
        int[] changesetForestVersions = drs.getChangesetForestVersions();
        int[] changesetTreeUids = drs.getChangesetTreeUids();
        int[] changesetTreeVersions = drs.getChangesetTreeVersions();
        String[] changesetTreeNames = drs.getChangesetTreeNames();
        int[] changesetTreeClasses = drs.getChangesetTreeClasses();
        String[] changesetComments = drs.getChangesetComments();
        int[] propertyCsUids = drs.getPropertyCsUids();
        String[] propertyNames = drs.getPropertyNames();
        String[] propertyValues = drs.getPropertyValues();
        LCNetClnt conn = DRSUtils.getLCNetClntObject();

        final Map<Integer, List<VersionProperty>> changesetPropMap = new HashMap<Integer, List<VersionProperty>>();
        if (propertyCsUids != null) {
            for (int i = 0; i < propertyCsUids.length; ++i) {
                int changesetUid = propertyCsUids[i];
                List<VersionProperty> propList;
                if (changesetPropMap.containsKey(changesetUid))
                    propList = changesetPropMap.get(changesetUid);
                else {
                    propList = new ArrayList<VersionProperty>();
                    changesetPropMap.put(changesetUid, propList);
                }
                VersionProperty vp = new VersionProperty();
                vp.setChangesetUid((long) changesetUid);
                vp.setPropertyName(propertyNames[i]);
                vp.setPropertyValue(propertyValues[i]);

                propList.add(vp);
            }
        }
        boolean haveChangesets = changesetUids != null;
        if (haveChangesets) {

            for (int i = 0; i < changesetUids.length; ++i) {

                TreeVersion tv = new TreeVersion();
                tv.setChangeSetUid(changesetUids[i]);
                tv.setForestVersion(changesetForestVersions[i]);
                tv.setTreeUid(changesetTreeUids[i]);
                tv.setTreeClass(changesetTreeClasses[i]);
                tv.setTreeVersion(changesetTreeVersions[i]);
                tv.setTreeSpec(changesetTreeNames[i]);

                ChangeSet cs = new ChangeSet();
                cs.setUid(changesetUids[i]);
                cs.setTreeVersion(tv);
                cs.setOperationType(changesetTypes[i]);
                cs.setUser(changesetAuthors[i]);

                if (changesetComments != null && changesetComments.length == changesetUids.length) {
                    cs.setComment(changesetComments[i]);
                }

                try {
                    cs.setDate(DateUtils.parseDate(changesetDatetimes[i], DateUtils.DATE_PATTERN_3));
                    cs.setDateTZ(DateUtils.parseDate(changesetDatetimes[i], DateUtils.DATE_PATTERN_3, conn.getRemotePeerTimeZone()));
                } catch (ParseException e) {
                    throw new AdmException(e);
                }

                if (changesetPropMap.containsKey(changesetUids[i])) {
                    cs.setVersionProperties(changesetPropMap.get(changesetUids[i]));
                }

                handler.handleChangeSet(cs);
            }
        }
    }

    
    private static void loadChangeSetsByPath(DRSClientFindChangesetsByPath drs, ChangeSetHandler handler) throws AdmException {
        int[] changesetUids = drs.getChangesetUids();
        int[] changesetForestVersions = drs.getChangesetForestVersions();
        int[] changesetTreeUids = drs.getChangesetTreeUids();
        int[] changesetTreeVersions = drs.getChangesetTreeVersions();
        int[] changesetTreeClasses = drs.getChangesetTreeClasses();
        String[] changesetTreeNames = drs.getChangesetTreeNames();

        // some details info
        int[] changesetTypes = drs.getChangesetTypes();
        String[] changesetDatetimes = drs.getChangesetDatetimes();
        String[] changesetAuthors = drs.getChangesetAuthors();
        String[] comments = drs.getComments();
        int[] propertyCsUids = drs.getPropertyCsUids();
        String[] propertyNames = drs.getPropertyNames();
        String[] propertyValues = drs.getPropertyValues();
        LCNetClnt conn = DRSUtils.getLCNetClntObject();

        Map<Integer, ChangeSet> indexToChangeset = new HashMap<Integer, ChangeSet>();

        final Map<Integer, List<VersionProperty>> changesetPropMap = new HashMap<Integer, List<VersionProperty>>();
        if (propertyCsUids != null) {
            for (int i = 0; i < propertyCsUids.length; ++i) {
                int changesetUid = propertyCsUids[i];
                List<VersionProperty> propList;
                if (changesetPropMap.containsKey(changesetUid))
                    propList = changesetPropMap.get(changesetUid);
                else {
                    propList = new ArrayList<VersionProperty>();
                    changesetPropMap.put(changesetUid, propList);
                }
                VersionProperty vp = new VersionProperty();
                vp.setChangesetUid((long) changesetUid);
                vp.setPropertyName(propertyNames[i]);
                vp.setPropertyValue(propertyValues[i]);

                propList.add(vp);
            }
        }
        boolean haveChangesets = changesetUids != null;
        if (haveChangesets) {

            for (int i = 0; i < changesetUids.length; ++i) {

                TreeVersion tv = new TreeVersion();
                tv.setChangeSetUid(changesetUids[i]);
                tv.setForestVersion(changesetForestVersions[i]);
                tv.setTreeUid(changesetTreeUids[i]);
                tv.setTreeClass(changesetTreeClasses[i]);
                tv.setTreeVersion(changesetTreeVersions[i]);
                tv.setTreeSpec(changesetTreeNames[i]);

                ChangeSet cs = new ChangeSet();
                cs.setUid(changesetUids[i]);
                cs.setTreeVersion(tv);
                cs.setOperationType(changesetTypes[i]);
                cs.setUser(changesetAuthors[i]);
                cs.setComment(comments[i]);

                try {
                    cs.setDate(DateUtils.parseDate(changesetDatetimes[i], DateUtils.DATE_PATTERN_3));
                    cs.setDateTZ(DateUtils.parseDate(changesetDatetimes[i], DateUtils.DATE_PATTERN_3, conn.getRemotePeerTimeZone()));
                } catch (ParseException e) {
                    throw new AdmException(e);
                }
                if (changesetPropMap.containsKey(changesetUids[i])) {
                    cs.setVersionProperties(changesetPropMap.get(changesetUids[i]));
                }

                indexToChangeset.put(i, cs);
                if (!drs.isQueryChangeSteps()) {
                    handler.handleChangeSet(cs);
                }
            }

            if (drs.isQueryChangeSteps()) {
                // steps info
                int[] changesetIndex = drs.getChangesetIndex();
                int[] types = drs.getTypes();
                int[] objUids = drs.getObjUids();
                String[] paths = drs.getPaths();
                String[] revisions = drs.getRevisions();
                String[] requestIds = drs.getRequestIds();

                String[] parentProducts = drs.getParentProducts();
                String[] parentStreams = drs.getParentStreams();
                String[] parentPaths = drs.getParentPaths();
                int[] parentVersions = drs.getParentVersions();

                // assume that every changeset should have at least one changestep if steps query was requested by user
                ChangeSet prevChangeSet = indexToChangeset.get(0);
                for (int i = 0; i < changesetIndex.length; i++) {
                    ImportedChangeStep step = new ImportedChangeStep();
                    step.setType(types[i]);
                    step.setObjUid(objUids[i]);
                    step.setProjectPath(paths[i]);
                    step.setRevision(revisions[i]);
                    step.setOriginalProduct(parentProducts[i]);
                    step.setOriginalStream(parentStreams[i]);
                    step.setOriginalPath(parentPaths[i]);
                    step.setOriginalVersion(parentVersions[i]);

                    step.setRequestIds(new ArrayList<String>());
                    if (requestIds[i].contains(",")) {
                        String[] requests = requestIds[i].split(",");
                        for (int j = 0; j < requests.length; j++) {
                            if (!StringUtils.isBlank(requests[j])) {
                                step.getRequestIds().add(requests[j]);
                            }
                        }
                    } else {
                        if (!StringUtils.isBlank(requestIds[i])) {
                            step.setRequestIds(Arrays.asList(requestIds[i]));
                        }
                    }

                    ChangeSet curChangeSet = indexToChangeset.get(changesetIndex[i]);
                    step.setChangeSet(curChangeSet);
                    curChangeSet.addChangeStep(step);

                    // invoke handle on previous change set that has just created with all steps or on last iteration
                    if (!prevChangeSet.equals(curChangeSet)) {
                        handler.handleChangeSet(prevChangeSet);
                        prevChangeSet = curChangeSet;
                    }
                    if (i == changesetIndex.length - 1) {
                        handler.handleChangeSet(curChangeSet);
                    }
                }
            }
        }
    }

    public static TreeVersion getRepositoryVersion(Date date) throws AdmException {

        DRSClientQueryRepositoryVersion drs = new DRSClientQueryRepositoryVersion();
        if (date != null) {
            drs.setAtDate(DateUtils.formatDate(date));
        }

        DRSUtils.execute(drs);

        TreeVersion tv = new TreeVersion();
        if (drs.hasData()) {
            if (drs.getTreeUid() != Constants.INVALID_UID && drs.getForestVersion() > 0) {
                tv.setChangeSetUid(drs.getChangesetUid());
                tv.setForestVersion(drs.getForestVersion());
                tv.setTreeClass(drs.getTreeClass());
                tv.setTreeSpec(drs.getTreeSpec());
                tv.setTreeUid(drs.getTreeUid());
                tv.setTreeVersion(drs.getTreeVersion());
            }
        }

        return tv;
    }

    public static TreeVersion getRepositoryVersion(long treeUid, long treeVersion) throws AdmException {

        DRSClientQueryRepositoryVersion drs = new DRSClientQueryRepositoryVersion();
        drs.setInputTreeUid(treeUid);
        drs.setInputTreeVersion(treeVersion);

        DRSUtils.execute(drs);

        TreeVersion tv = new TreeVersion();
        if (drs.hasData()) {
            if (drs.getTreeUid() != Constants.INVALID_UID && drs.getForestVersion() > 0) {
                tv.setChangeSetUid(drs.getChangesetUid());
                tv.setForestVersion(drs.getForestVersion());
                tv.setTreeClass(drs.getTreeClass());
                tv.setTreeSpec(drs.getTreeSpec());
                tv.setTreeUid(drs.getTreeUid());
                tv.setTreeVersion(drs.getTreeVersion());
            }
        }
        return tv;
    }

}

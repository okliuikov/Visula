/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.DeploymentViewContext;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.LifeCycleState;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.WorksetArea;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Returns Deployment Job Uids( for the Deployment Queue view )
 */
public class QCDeploymentViewContextToDeploymentViewContextCmd extends RPCCmd {
    public static final String DEPLOYMENT = "DEPLOYMENT";

    /**
     * Constructor defines the command definition and arguements.
     */
    public QCDeploymentViewContextToDeploymentViewContextCmd() throws AdmObjectException, AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_SEC_CLASS, true, Class.class));

    }

    @Override
    public Object execute() throws AdmException {
        AdmObject selectedObject = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List result = new ArrayList();
        if (selectedObject instanceof DeploymentViewContext) {
            DeploymentViewContext context = (DeploymentViewContext) selectedObject;
            List scopes = context.getAdmSpec().getScopeObjects();
            if (scopes != null) {
                AdmBaseId firstScopeObject = scopes.size() > 0 ? (AdmBaseId) scopes.get(0) : null;
                if (firstScopeObject != null) {
                    boolean isAllAreas = false;
                    WorkSet ws = null;
                    if (firstScopeObject.getObjType().equals(BaseDatabase.class)) { // all areas
                        isAllAreas = true;
                    } else if (firstScopeObject.getObjType().equals(WorkSet.class)) { // workset
                        ws = (WorkSet) AdmCmd.getObject(firstScopeObject);
                    }
                    if (scopes.size() == 1) {
                        if (isAllAreas) {
                            fillDeploymentStagesNodesForAllAreas(result, scopes);
                        } else if (ws != null) {
                            fillDeploymentStagesNodes(result, ws, scopes);
                        }
                    } else {
                        AdmBaseId secondScopeObject = scopes.size() > 1 ? (AdmBaseId) scopes.get(1) : null;
                        Stage stage = null;
                        if (secondScopeObject.getObjType().equals(Stage.class)) { // all areas
                            stage = (Stage) AdmCmd.getObject(secondScopeObject);
                        }
                        if (stage != null) {
                            if (scopes.size() == 2) {
                                if (isAllAreas) {
                                    fillAllDeploymentAreasNodes(result, stage, scopes);
                                } else if (ws != null) {
                                    fillDeploymentAreasNodes(result, ws, stage, scopes);
                                }
                            } else {
                                AdmBaseId thirdScopeObject = scopes.size() > 2 ? (AdmBaseId) scopes.get(2) : null;
                                FileArea area = null;
                                if (thirdScopeObject.getObjType().equals(FileArea.class)) { // all areas
                                    area = (FileArea) AdmCmd.getObject(thirdScopeObject);
                                }
                                if (isAllAreas && stage != null && area != null) {
                                    fillProjectsFromWorksetAreas(result, stage, area, scopes);
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    public AdmBaseId getGlobalStageLifecycle() throws AdmException {
        AdmBaseId id = null;
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurRootObj(BaseDatabase.class));
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, LifeCycle.class);

        // set up the filter
        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.IS_GSL, Boolean.TRUE, FilterCriterion.EQUALS));
        cmd.setAttrValue(CmdArguments.FILTER, filter);

        List ids = (List) cmd.execute();
        if (ids != null && ids.size() == 1) {
            id = (AdmBaseId) ids.get(0);
        }
        return id;
    }

    private void fillDeploymentStagesNodesForAllAreas(List children, List scopes) throws AdmException {
        AdmBaseId lifecycleId = getGlobalStageLifecycle();
        List stageIds = null;
        AdmObject lifecycleObj = AdmCmd.getObject(lifecycleId);
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, lifecycleObj, LifeCycleState.class);
        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.LCSTATE_IS_NORM, Boolean.TRUE));
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        stageIds = (List) cmd.execute();
        if (stageIds != null) {
            List stateObjs = AdmCmd.getObjects(stageIds);
            for (int i = 0; i < stateObjs.size(); ++i) {
                LifeCycleState lc_state = (LifeCycleState) stateObjs.get(i);
                Stage stage = new Stage(lc_state.getId());
                List specs = new ArrayList(scopes);
                specs.add(stage.getAdmBaseId());
                children.add(new DeploymentViewContext(stage.getId(), specs));
            }
        }
    }

    private void fillDeploymentStagesNodes(List children, WorkSet rootProject, List scopes) throws AdmException {
        AdmObject root = null;
        String rootClone = "";
        if (rootProject != null) {
            root = rootProject;
            rootClone = root.getAdmBaseId().toCloneString();
        } else {
            root = AdmCmd.getCurRootObj(BaseDatabase.class);
        }

        FilterImpl filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.TYPE_NAME, "DEPLOYMENT"));

        ArrayList deployAreaNames = new ArrayList();
        deployAreaNames.add(AdmAttrNames.STAGE_OBJ);
        deployAreaNames.add(AdmAttrNames.STAGE_UID);

        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, root, FileArea.class);
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        List deployAreas = AdmCmd.getObjects((List) cmd.execute(), deployAreaNames);

        if (deployAreas != null && deployAreas.size() > 0) {
            FileArea deployArea = null;
            Stage stage = null;
            String stageId = "";
            String stageClone = "";
            Integer seqNo = null;
            ArrayList stageIdsUsed = new ArrayList();
            // Used to order the stages correctly by sequence number
            TreeMap stagesTreeMap = new TreeMap();

            // Create Deployment nodes
            for (int i = 0; deployAreas != null && deployAreas.size() > i; i++) {
                deployArea = (FileArea) deployAreas.get(i);
                stage = (Stage) AdmCmd.getAttributeValue(deployArea, AdmAttrNames.STAGE_OBJ);
                seqNo = (Integer) AdmCmd.getAttributeValue(stage, AdmAttrNames.STAGE_SEQ);
                stageId = stage.getDisplayId();

                if (!stageIdsUsed.contains(stageId)) {
                    stagesTreeMap.put(seqNo, stage);
                }
                stageIdsUsed.add(stageId);
            }

            ArrayList stagesList = new ArrayList(stagesTreeMap.values());
            Iterator stagesIterator = stagesList.iterator();

            while (stagesIterator.hasNext()) {
                stage = (Stage) stagesIterator.next();
                List specs = new ArrayList(scopes);
                specs.add(AdmCmd.newAdmBaseId(stage.getId(), Stage.class));
                children.add(new DeploymentViewContext(stage.getId(), specs));
            }
        }
    }

    private void fillAllDeploymentAreasNodes(List children, Stage stage, List scopes) throws AdmException {

        String stageUid = ((AdmUid) AdmCmd.getAttributeValue(stage, AdmAttrNames.ADM_UID)).toString();
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurRootObj(BaseDatabase.class), FileArea.class);
        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.TYPE_NAME, DEPLOYMENT, FilterCriterion.EQUALS));
        if (stageUid != null) {
            filter.criteria().add(new FilterCriterion(AdmAttrNames.STAGE_UID, stageUid, FilterCriterion.EQUALS));
        }
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        List areaObjs = AdmCmd.getObjects((List) cmd.execute());
        for (int i = 0; i < areaObjs.size(); i++) {
            AdmObject deployArea = (AdmObject) areaObjs.get(i);
            String deployAreaId = deployArea.getId();
            String deployAreaDescription = (String) deployArea.getAttrValue(AdmAttrNames.DESCRIPTION);
            if (deployAreaDescription != null && deployAreaDescription.length() > 0) {
                deployAreaId += " [" + deployAreaDescription + "]";
            }
            List specs = new ArrayList(scopes);
            specs.add(deployArea.getAdmBaseId());
            children.add(new DeploymentViewContext(deployAreaId, specs));
        }
    }

    private void fillDeploymentAreasNodes(List children, WorkSet ws, Stage stage, List scopes) throws AdmException {

        String stageUid = ((AdmUid) AdmCmd.getAttributeValue(stage, AdmAttrNames.ADM_UID)).toString();
        FilterImpl filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.STAGE_UID, stageUid));
        filter.orders().add(new FilterOrder(AdmAttrNames.AREA_ID));

        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, ws, WorksetArea.class);
        List attributeNames = new ArrayList();
        attributeNames.add(AdmAttrNames.AREA_ID);
        attributeNames.add(AdmAttrNames.WS_AREA_OFFSET);
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        List wsAreas = AdmCmd.getObjects((List) cmd.execute(), attributeNames);

        if (wsAreas != null && wsAreas.size() > 0) {
            FileArea deployArea = null;
            String deployAreaId = "";
            String deployAreaDirClone = "";
            String deployAreaDescription = "";

            // Create Deployment nodes
            for (int i = 0; wsAreas != null && wsAreas.size() > i; i++) {
                WorksetArea wsArea = (WorksetArea) wsAreas.get(i);
                deployArea = (FileArea) AdmCmd.getObject(AdmCmd.newAdmBaseId((String) wsArea.getAttrValue(AdmAttrNames.AREA_ID),
                        FileArea.class));
                deployAreaId = (String) deployArea.getAttrValue(AdmAttrNames.ID);

                if (deployAreaId != null) {
                    String projAreaOffset = (String) wsArea.getAttrValue(AdmAttrNames.WS_AREA_OFFSET);
                    if (projAreaOffset == null) {
                        projAreaOffset = "";
                    }
                    if ("".equals(projAreaOffset)) {
                        if (!deployAreaId.endsWith("::")) {
                            deployAreaId += "::";
                        }
                    } else {
                        deployAreaId += "::" + projAreaOffset;
                    }
                    deployAreaDescription = (String) deployArea.getAttrValue(AdmAttrNames.DESCRIPTION);
                    if (deployAreaDescription != null && deployAreaDescription.length() > 0) {
                        deployAreaId += " [" + deployAreaDescription + "]";
                    }
                    List specs = new ArrayList(scopes);
                    specs.add(deployArea.getAdmBaseId());
                    children.add(new DeploymentViewContext(deployAreaId, specs));
                }
            }
        }
    }

    private void fillProjectsFromWorksetAreas(List children, Stage stage, FileArea area, List scopes) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, area, WorksetArea.class);
        Filter filter = new FilterImpl();
        filter.orders().add(new FilterOrder(AdmAttrNames.ADM_SPEC));
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        List attributeNames = new ArrayList();
        attributeNames.add(AdmAttrNames.AREA_ID);
        attributeNames.add(AdmAttrNames.WS_AREA_OFFSET);
        List wsAreas = AdmCmd.getObjects((List) cmd.execute(), attributeNames);

        WorksetArea wsArea;
        String spec;
        String offset;
        String displayId;
        for (int i = 0; i < wsAreas.size(); i++) {
            wsArea = (WorksetArea) wsAreas.get(i);
            spec = wsArea.getAdmSpec().getSpec();
            offset = (String) wsArea.getAttrValue(AdmAttrNames.WS_AREA_OFFSET);
            displayId = spec;
            if (offset != null && offset.length() > 0) {
                displayId += " [::" + offset + "]";
            }
            List specs = new ArrayList(scopes);
            specs.add(wsArea.getAdmBaseId());
            children.add(new DeploymentViewContext(displayId, specs));
        }
    }
}
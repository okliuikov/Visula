/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.withattrs;

import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.collections.AdmObjectList;
import merant.adm.dimensions.objects.collections.AdmObjectListImpl;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.Attribute;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Convenience command for batch querying and retrieval of object attributes.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ATTRIBUTE_NAMES {String/List}<dt><dd>Attribute name or List of attribute names to query</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_LIST {AdmObjectList}<dt><dd>Dimensions AdmObject's list</dd>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>FORCE_QUERY {Boolean}<dt><dd>If true, forces query even if value is available</dd>
 *  <dt>REVISE {Boolean}</dt><dd>Sets the revised nature of the user defined attributes</dd>
 *  <dt>USE_SUPER_QUERY {Boolean}</dt><dd>Force the use of SuperQuery</dd>
 *  <dt>MULTIPLE {Boolean}</dt><dd>Used for multiple edit attribute operations</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>List of attribute values</dd>
 * </dl></code>
 * @author Floz
 */
public class GetAttrsCmd extends AdmCmd {
    public GetAttrsCmd() throws AttrException {
        super();
        setAlias(WithAttrs.GET);
        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTE_NAMES, true));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, AdmObjectList.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(CmdArguments.FORCE_QUERY, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.REVISE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.USE_SUPER_QUERY, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.MULTIPLE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ATTRIBUTE_NAMES)) {
            if ((!(attrValue instanceof String)) && (!(attrValue instanceof List))) {
                throw new AttrException("Error: Attribute name should be a singular String or a List of String's", attrDef,
                        attrValue);
            }
        }
    }

    private static void addMVAToMCB(List mcb, Attribute attr) {
        if (mcb.size() == 0) {
            mcb.add(attr);
            return;
        }

        boolean added = false;
        Attribute tmpAttr = null;
        int attrMcbCol = attr.getAttributeDefinition().getMcbColumn();
        for (int i = 0; ((i < mcb.size()) && (!added)); i++) {
            tmpAttr = (Attribute) mcb.get(i);
            if (tmpAttr.getAttributeDefinition().getMcbColumn() >= attrMcbCol) {
                mcb.add(i, attr);
                added = true;
            }
        }

        if (!added) {
            mcb.add(attr);
        }
    }

    /**
     * Regroups such that MVAs that are part of an MCB
     * are placed together in order of their MCB column number
     */
    private static void segregateMCB(List attrs) throws AdmException {
        List mcb = null;
        Attribute attr = null;
        Attribute tmpAttr = null;
        for (int i = 0; i < attrs.size(); i++) {
            attr = (Attribute) attrs.get(i);
            if (attr.getAttributeDefinition().getBlock() != null) {
                mcb = new Vector();
                mcb.add(attr);

                // Locate other attrs within the same MCB
                for (int j = i + 1; j < attrs.size(); j++) {
                    tmpAttr = (Attribute) attrs.get(j);
                    if ((tmpAttr.getAttributeDefinition().getBlock() != null)
                            && tmpAttr.getAttributeDefinition()
                                    .getBlock()
                                    .getAdmSpec()
                                    .equals(attr.getAttributeDefinition().getBlock().getAdmSpec())) {
                        addMVAToMCB(mcb, tmpAttr);
                        attrs.remove(j);
                        j--;
                    }
                }

                attrs.set(i, mcb.get(mcb.size() - 1));
                for (int j = mcb.size() - 2; j >= 0; j--) {
                    attrs.add(i, mcb.get(j));
                }
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObjectList admObjList = (AdmObjectList) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        Boolean useSuperQuery = (Boolean) getAttrValue(CmdArguments.USE_SUPER_QUERY);
        boolean retList = true;
        if (admObj != null) {
            retList = false;
        }

        if ((admObj == null) && (admObjList == null)) {
            throw new DBIOException("Must specify an object or a list of objects!");
        }

        if ((admObj != null) && (admObjList != null)) {
            throw new DBIOException("Cannot specify an object and a list of objects!");
        }

        if (admObjList != null) {
            if (admObjList.size() == 0) {
                throw new DBIOException("Must specify at least one object!");
            }
        } else {
            admObjList = new AdmObjectListImpl();
            admObjList.add(admObj);
        }

        boolean forceQuery = ((Boolean) getAttrValue(CmdArguments.FORCE_QUERY)).booleanValue();

        List attrNames = null;
        if (getAttrValue(CmdArguments.ATTRIBUTE_NAMES) instanceof String) {
            attrNames = new Vector();
            attrNames.add(getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
        } else {
            attrNames = new Vector((List) getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
        }

        List attrsToQuery = null;
        if (forceQuery) {
            attrsToQuery = attrNames;
        } else {
            for (int index = 0; index < admObjList.size(); index++) {
                admObj = (AdmObject) admObjList.get(index);
                for (int i = 0; i < attrNames.size(); i++) {
                    if (admObj.getAttrValue((String) attrNames.get(i)) == null) {
                        if (attrsToQuery == null) {
                            attrsToQuery = new Vector();
                        }

                        if (!attrsToQuery.contains(attrNames.get(i))) {
                            attrsToQuery.add(attrNames.get(i));
                        }
                    }
                }
            }
        }

        if ((attrsToQuery != null) && (attrsToQuery.size() > 0)) {
            Cmd cmd = null;
            if (admObjList.size() > 1) {
                cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObjList);
            } else {
                cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObjList.get(0));
            }

            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrsToQuery);
            cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
            cmd.setAttrValue(CmdArguments.REVISE, getAttrValue(CmdArguments.REVISE));
            cmd.setAttrValue(CmdArguments.USE_SUPER_QUERY, useSuperQuery);
            cmd.setAttrValue(CmdArguments.MULTIPLE, getAttrValue(CmdArguments.MULTIPLE));
            cmd.execute();
        }

        List realRet = new Vector();
        List ret = null;
        for (int index = 0; index < admObjList.size(); index++) {
            ret = new Vector();
            admObj = (AdmObject) admObjList.get(index);

            AttrDef attrDef = null;
            AttributeDefinition tmpAttrDef = null;
            AttributeDefinition userAttrDef = null;
            String attrName = null;
            for (int i = 0; i < attrNames.size(); i++) {
                if (((String) attrNames.get(i)).equals(AdmAttrNames.USER_DEFINED_ATTRIBUTES) && (!useSuperQuery.booleanValue())) {
                    List attrDefs = admObj.getAllAttrDefs();
                    if (attrDefs != null) {
                        for (int j = 0; j < attrDefs.size(); j++) {
                            attrDef = (AttrDef) attrDefs.get(j);
                            attrName = attrDef.getName();
                            if ((attrName != null) && (attrName.length() > 0)
                                    && (attrName.charAt(0) != Constants.NON_USER_DEF_ATTR_CHAR)) {
                                userAttrDef = (AttributeDefinition) attrDef;
                                if ((ret.size() < 1) || (userAttrDef.getDisplayOrder() == 0)) {
                                    ret.add(admObj.getAttrValue(attrName));
                                } else {
                                    for (int k = ret.size() - 1; k >= 0; k--) {
                                        tmpAttrDef = ((Attribute) ret.get(k)).getAttributeDefinition();
                                        if (tmpAttrDef == null) {
                                            ret.add(admObj.getAttrValue(attrName));
                                            break;
                                        } else if (tmpAttrDef.getDisplayOrder() == 0) {
                                            if (k == 0) {
                                                ret.add(k, admObj.getAttrValue(attrName));
                                                break;
                                            } else {
                                                continue;
                                            }
                                        } else if (tmpAttrDef.getDisplayOrder() < userAttrDef.getDisplayOrder()) {
                                            if (k == (ret.size() - 1)) {
                                                ret.add(admObj.getAttrValue(attrName));
                                            } else {
                                                ret.add(k + 1, admObj.getAttrValue(attrName));
                                            }

                                            break;
                                        } else if (tmpAttrDef.getDisplayOrder() > userAttrDef.getDisplayOrder()) {
                                            if (k == 0) {
                                                ret.add(k, admObj.getAttrValue(attrName));
                                                break;
                                            } else {
                                                continue;
                                            }
                                        } else {
                                            ret.add(k, admObj.getAttrValue(attrName));
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                        segregateMCB(ret);
                    }
                } else if (!(((String) attrNames.get(i)).equals(AdmAttrNames.USER_DEFINED_ATTRIBUTE_NUMBERS))) {
                    ret.add(admObj.getAttrValue((String) attrNames.get(i)));
                }
            }

            realRet.add(ret);
        }

        if (retList) {
            return realRet;
        }

        return ret;
    }
}

/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2009 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.LCNetClnt;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.IDMReport;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * 
 * @author pbate
 * 
 *         This command is used to get a list of IDM reports.
 *         <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>WORKSET {AdmUidObject}</dt><dd>the current project</dd>
 * </dl></code> <br>
 *         <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILTER {Filter}</dt><dd>filter the list by (e.g.) title, create date, etc</dd>
 *  <dt>PRODUCT {Product}</dt><dd>Fetching IDM reports by Product, WORKSET argument was ignored</dd>
 * </dl></code> <br>
 *         <b>Returns:</b> <code><dl>
 *  <dt>reports {List}</dt><dd>a list of IDMReports, or null if none are available</dd>
 * </dl></code>
 */
public class RPCGetIDMReportsCmd extends RPCCmd {

    public RPCGetIDMReportsCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("GetIDMReports");
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, true, AdmUidObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT, false, AdmUidObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
    }

    /**
     * Returns a list of IDMReports
     * 
     * @return <code>java.util.List</code>
     * 
     */
    @Override
    public Object execute() throws DimConnectionException, AdmException {
        List reports = null;
        int projUid = -1;
        int prodUid = -1;
        String title = null;
        int level = -1;
        String author = null;
        long createDateFrom = -1;
        long createDateTo = -1;

        try {
            AdmUidObject project = (AdmUidObject) getAttrValue(CmdArguments.WORKSET);
            AdmUidObject product = (AdmUidObject) getAttrValue(CmdArguments.PRODUCT);
            if (product != null) {
                prodUid = (int) product.getAdmUid().getUid();
            } else if (project != null) {
                projUid = (int) project.getAdmUid().getUid();
            }
            Filter filter = (Filter) getAttrValue(CmdArguments.FILTER);
            if (filter != null) {
                Iterator iter = filter.criteria().iterator();
                while (iter.hasNext()) {
                    FilterCriterion criterion = (FilterCriterion) iter.next();
                    if (criterion.getAttrName().equals(AdmAttrNames.CREATE_DATE)) {
                        if (criterion.getFlags() == FilterCriterion.GREATER) {
                            Date createF = (Date) criterion.getValue();
                            if (createF != null) {
                                createDateFrom = createF.getTime();
                            }
                        } else if (criterion.getFlags() == FilterCriterion.LESS) {
                            Date createT = (Date) criterion.getValue();
                            if (createT != null) {
                                createDateTo = createT.getTime();
                            }
                        }
                    } else if (criterion.getAttrName().equals(CmdArguments.LEVEL)) {
                        level = ((Integer) criterion.getValue()).intValue();
                    } else if (criterion.getAttrName().equals(AdmAttrNames.ORIGINATOR)) { // author
                        author = criterion.getValue().toString();
                    } else if (criterion.getAttrName().equals(AdmAttrNames.ID)) { // title
                        title = criterion.getValue().toString();
                    }
                }
            }
            List ret = null;
            if(prodUid != -1) {
                ret = getSession().getConnection().rpcGetIDMReports(projUid, prodUid, title, level, author, createDateFrom, createDateTo);
            } else {
                ret = getSession().getConnection().rpcGetIDMReports(projUid, title, level, author, createDateFrom, createDateTo);
            }
            if (ret != null && ret.size() > 0) {
                Iterator iter = ret.iterator();
                while (iter.hasNext()) {
                    LCNetClnt.IDMReport dmnetRep = (LCNetClnt.IDMReport) iter.next();
                    IDMReport rep = new IDMReport(dmnetRep.getUuid());
                    rep.setAttrValue(AdmAttrNames.ORIGINATOR, dmnetRep.getAuthor());
                    rep.setAttrValue(AdmAttrNames.IDM_NAME, dmnetRep.getName());
                    rep.setAttrValue(AdmAttrNames.IDM_URL, dmnetRep.getURL());
                    if (dmnetRep.getCreateDate() != -1) {
                        rep.setAttrValue(AdmAttrNames.CREATE_DATE, new Date(dmnetRep.getCreateDate()));
                    }
                    if (reports == null) {
                        reports = new ArrayList();
                    }
                    reports.add(rep);
                }
            }

        } catch (AttrException e) {
            reports = null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return reports;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.BrowseTemplate;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

// import merant.adm.dimensions.objects.*;

/**
 * This helper command will relate a BrowseTemplate to a Type.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {BrowseTemplate}<dt><dd>Dimensions BrowseTemplate revision object</dd>
 *  <dt>ADM_PARENT_OBJECT {Type}<dt><dd>Parent Dimensions Type object </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class RelateBrowseTemplateToTypeCmd extends RPCExecCmd {
    public RelateBrowseTemplateToTypeCmd() throws AttrException {
        super();
        setAlias("RelateBrowseTemplateToTypeCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, BrowseTemplate.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, Type.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof BrowseTemplate)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {
        validateAllAttrs();

        // Dimensions browse template
        AdmObject templateObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        List attrs = AdmHelperCmd.getAttributeValues(
                templateObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.REVISION,
                        AdmAttrNames.PARENT_CLASS }));

        String templProductName = (String) attrs.get(0);
        String templName = (String) attrs.get(1);
        String revision = (String) attrs.get(2);
        Class templScope = (Class) attrs.get(3);

        // Dimensions parent object type
        AdmObject typeObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        final Class typeObjClass = (Class) typeObj.getAttrValue(AdmAttrNames.PARENT_CLASS);

        attrs = AdmHelperCmd.getAttributeValues(typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));

        String typeProductName = (String) attrs.get(0);
        String typeName = (String) attrs.get(1);
        Class typeScope = (Class) attrs.get(2);

        if (!templProductName.equals(typeProductName)) {
            throw new DimInvalidAttributeException("Error: Template Revision " + templProductName + ":" + templName + ";"
                    + revision + " and " + TypeUtils.getClassName(typeScope) + " type " + typeProductName + ":" + typeName
                    + " must be defined in the same product.");
        }

        if (!templScope.equals(typeScope)) {
            throw new DimInvalidAttributeException("Error: Template Revision " + templProductName + ":" + templName + ";"
                    + revision + " and " + TypeUtils.getClassName(typeScope) + " type " + typeProductName + ":" + typeName
                    + " must have the same object class");
        }

        // Construct OBJTYPE command
        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /UPDATE ");
        cmdBuf.append(Encoding.escapeDMCLI(typeName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(typeProductName));

        if (!bDeassign) {
            cmdBuf.append(" /TEMPLATE=").append(Encoding.escapeDMCLI(templName));
            cmdBuf.append(" /REVISION=").append(Encoding.escapeDMCLI(revision));
        } else {
            cmdBuf.append(" /TEMPLATE=\"\"");
        }

        if (typeObjClass.equals(Item.class)) {
            cmdBuf.append(" /OBJ_CLASS=ITEM");
        } else if (typeObjClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else {
            throw new DimInvalidAttributeException("Error: Template Revision " + templProductName + ":" + templName + ";"
                    + revision + " cannot be assigned to specified object type.");
        }

        _cmdStr = cmdBuf.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }

}

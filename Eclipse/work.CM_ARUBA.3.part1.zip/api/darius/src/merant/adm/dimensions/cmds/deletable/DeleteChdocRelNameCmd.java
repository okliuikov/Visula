/*
 * Copyright (C) 2002, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ChdocRelationshipName;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions request relationship name object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteChdocRelNameCmd extends DBIOCmd {
    public DeleteChdocRelNameCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChdocRelationshipName)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        long relUid = ((AdmUidObject) admObj).getAdmUid().getUid();

        List attrs = AdmHelperCmd.getAttributeValues(admObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID }));

        String productName = (String) attrs.get(0);
        String relName = (String) attrs.get(1);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

        if (isUsedByObjects(relUid)) {
            throw new DimAlreadyExistsException("Cannot delete relationship " + relName
                    + " as it is currently used in request relationships.");
        }

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            // delete relationship
            query.resetMessage(wcm_sql.CHDOC_RELNAME_DELETE_REL_TYPES);
            query.bindInput(relUid);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

            // delete delete relationship object
            query.resetMessage(wcm_sql.CHDOC_RELNAME_DELETE_DEF);
            query.bindInput(relUid);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return "Operation Completed";
    }

    public static boolean isUsedByObjects(long relNameUid) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(3);
        inputs.add(new Long(relNameUid));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CHDOC_RELNAME_IS_USED));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.GlobalAttributeDefinition;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Global Attribute Definition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteGlobalAttrDefCmd extends DBIOCmd {
    public DeleteGlobalAttrDefCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof GlobalAttributeDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String attrName = admObj.getId();
        Class attrScopeClass = (Class) admObj.getAttrValue(AdmAttrNames.PARENT_CLASS);

        // this command does no role checking as it will only be used as part
        // of deleting a local attribute definition
        String attrScope = TypeUtils.getTypeFlag(attrScopeClass);

        if (!DoesExistHelper.globalAttributeExists(attrName, attrScope)) {
            throw new DimAlreadyExistsException("Error: " + TypeUtils.getClassName(attrScopeClass) + " attribute " + attrName
                    + " does not exist.");
        }

        int attrNo = ((Integer) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_ATTRNO)).intValue();

        int attrCount = countAssignedAttrs(attrNo, attrScope);

        if (attrCount > 0) {
            throw new DimAlreadyExistsException("Error: Cannot delete " + TypeUtils.getClassName(attrScopeClass)
                    + " Type global attribute definition " + attrName + " as it is currently being used " + attrCount
                    + " local attribute definitions.");
        }

        DBIO query = SqlUtils.attrdefDeleteAttrdef80(attrNo, attrScope);
        query.write();
        return "Operation Completed";
    }

    private int countAssignedAttrs(int attrNo, String typeFlag) throws DBIOException, AdmObjectException, DimBaseException {
        DBIO query = new DBIO(wcm_sql.ATTRDEF_COUNT_ATTR_USAGE_80);
        query.bindInput(attrNo);
        query.bindInput(typeFlag);
        query.readStart();
        int count = 0;
        if (query.read()) {
            count = query.getInt(1);
        }
        query.close();
        return count;
    }

}
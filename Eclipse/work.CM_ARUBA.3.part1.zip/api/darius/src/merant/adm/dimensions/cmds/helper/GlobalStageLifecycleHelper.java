/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;
import java.util.List;

import com.serena.dmnet.drs.DRSClientStageLcHelper;
import com.serena.dmnet.drs.DRSClientStageLcHelper.StageLcQueryContext;
import com.serena.dmnet.drs.DRSClientSysObjAttrUtils;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimInvalidLcStateException;
import merant.adm.dimensions.exception.DimLcInconsistentLifecycleException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.LifeCycleStateTransition;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

/**
 * @author PBate
 *
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class GlobalStageLifecycleHelper { 

    public static AdmBaseId getGlobalStageLifecycle() throws AdmException {
        AdmObject currentDb = AdmCmd.getCurRootObj(BaseDatabase.class);
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, currentDb);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, LifeCycle.class);

        // set up the filter
        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.IS_GSL, Boolean.TRUE, FilterCriterion.EQUALS));
        cmd.setAttrValue(CmdArguments.FILTER, filter);

        List ids = (List) cmd.execute();
        AdmBaseId id = null;
        if (ids != null && ids.size() == 1) {
            id = (AdmBaseId) ids.get(0);
        }
        return id;
    }

    public static boolean isLifecycleGSL(LifeCycle lifecycle) {
        boolean ret = false;
        try {
            Boolean isGSL = (Boolean) AdmHelperCmd.getAttributeValue(lifecycle, AdmAttrNames.IS_GSL, true);
            if (isGSL != null) {
                ret = isGSL.booleanValue();
            }
        } catch (AdmException ae) {
        }
        return ret;
    }

    public static boolean isLifecycleGSL(String lifecycleId) {
        boolean ret = false;
        try {
            LifeCycle lifecycle = (LifeCycle) AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(lifecycleId, LifeCycle.class));
            return isLifecycleGSL(lifecycle);
        } catch (AdmException ae) {
        }
        return ret;
    }

    public static void insertGSLStage(DBIO query, String newBeginState, String newEndState) throws AdmException, DBIOException,
            DimBaseException {
        List stages = new ArrayList();
        int index = -1;
        String stageToAdd = null;
        query.resetSQL("SELECT obj_id from stage_catalogue ORDER BY stage_seq");
        query.readStart();

        while (query.read(DBIO.DB_DONT_CLOSE)) {
            stages.add(query.getString(1));
        }
        query.close(DBIO.DB_DONT_RELEASE);
        if (stages.contains(newBeginState)) {
            // if the stage catalogue already contains both stages, don't add anything
            if (stages.contains(newEndState)) {
                return;
            }
            index = stages.indexOf(newBeginState) + 2;// index is 1-based, not 0-based
            stageToAdd = newEndState;
        } else if (stages.contains(newEndState)) {
            index = stages.indexOf(newEndState) + 1;// index is 1-based, not 0-based
            stageToAdd = newBeginState;
        }

        if (stageToAdd != null && index > 0) {
            // first update the seq numbers
            for (int i = stages.size(); i >= index; i--) {
                updateStageParams(query, i + 1, (String)stages.get(i - 1), null);
                query.write(DBIO.DB_DONT_COMMIT);
            }

            insertStage(query, stageToAdd, index);
        } else if (stages.size() == 0) {
            // if GSL has no entries (*should* never happen) allow user to regenerate it
            insertStage(query, newBeginState, 1);
            insertStage(query, newEndState, 2);
        } else {
            // should never get here...
            throw new DimInvalidLcStateException("Cannot add a transition to " + " the Global Stage Lifecycle with two new stages.");
        }

    }

    private static void insertStage(DBIO query, String stageToAdd, int index) throws AdmObjectException, DBIOException,
            DimBaseException {
        String newAlias = generateStageAlias(query, stageToAdd);
        // add the stage
        query.resetMessage(wcm_sql.STAGE_CREATE);
        query.bindInput(stageToAdd); // :I1
        query.bindInput(newAlias); // :I2
        query.bindInput(index); // :I3
        AdmObject user = AdmCmd.getCurRootObj(User.class);
        query.bindInput(user.getId()); // :I4
        String description = stageToAdd;
        if (!description.endsWith("stage")) {
            description += " stage";
        }
        query.bindInput(description); // :I5 = description;
        query.write(DBIO.DB_DONT_COMMIT);
    }

    private static String generateStageAlias(DBIO query, String newStage) throws AdmObjectException, DBIOException,
            DimBaseException {

        final String alphas = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        String newAlias = newStage.toUpperCase();
        if (newAlias.length() > 3) {
            newAlias = newAlias.substring(0, 3);
        }

        if (!stageAliasExists(query, newAlias)) {
            return newAlias;
        }

        for (int i = 0; i < alphas.length(); i++) {
            String testAlias = newAlias.substring(0, 2) + alphas.charAt(i);
            if (!stageAliasExists(query, testAlias)) {
                return testAlias;
            }
        }

        throw new DimInUseException("Failed to generate a unique alias for the '" + newStage);
    }

    private static boolean stageAliasExists(DBIO query, String newAlias) throws AdmObjectException, DBIOException, DimBaseException {

        query.resetSQL("SELECT NULL FROM stage_catalogue WHERE stage_alias=:I1");
        query.bindInput(newAlias);
        query.readStart();
        return query.read(DBIO.DB_DONT_CLOSE);
    }

    public static void updateStageId(DBIO query, String oldState, String newState) throws DimBaseException, AttrException,
            AdmException {

        // VADYMK: this is truly horrible
        final String dummyStage = "$$$ DUMMY !!! STAGE $$$";
        // 1. insert a dummy stage
        insertStage(query, dummyStage, -1);
        // 2. rename to dummy stage
        internalUpdateStageId(query, oldState, dummyStage);

        // 3. update the stage_catalogue
        updateStageParams(query, null, oldState, newState);
        query.write(DBIO.DB_DONT_COMMIT);

        // 4. rename dummy stage to new stage
        internalUpdateStageId(query, dummyStage, newState);

        // 5. delete dummy stage
        deleteStage(query, dummyStage);
        query.write(DBIO.DB_DONT_COMMIT);
    }

    private static void internalUpdateStageId(DBIO query, String oldState, String newState) throws DimBaseException, AttrException,
            AdmException {

        DRSClientStageLcHelper drs = new DRSClientStageLcHelper(DRSUtils.getLCNetClntObject(),
                StageLcQueryContext.UpdateStageWsFiles);
        drs.setOldStage(oldState);
        drs.setNewStage(newState);
        new DRSQuery(drs).execute();

        // finally, update item_catalogue
        query.resetMessage(wcm_sql.UPDATE_ITEM_CATALOGUE_STAGE);
        query.bindInput(oldState);
        query.bindInput(newState);
        query.write(DBIO.DB_DONT_COMMIT);

        // NEW!!! also need to update cm_catalogue, sec_cm_catalogue and wsrel_attributes
        query.resetMessage(wcm_sql.UPDATE_CM_CATALOGUE_STAGE);
        query.bindInput(oldState);
        query.bindInput(newState);
        query.write(DBIO.DB_DONT_COMMIT);

        query.resetMessage(wcm_sql.UPDATE_SEC_CM_CATALOGUE_STAGE);
        query.bindInput(oldState);
        query.bindInput(newState);
        query.write(DBIO.DB_DONT_COMMIT);

        query.resetMessage(wcm_sql.UPDATE_BLN_WSET_RELS_STAGE);
        query.bindInput(oldState);
        query.bindInput(newState);
        query.write(DBIO.DB_DONT_COMMIT);

        drs = new DRSClientStageLcHelper(DRSUtils.getLCNetClntObject(), StageLcQueryContext.UpdateStageWsHistory);
        drs.setOldStage(oldState);
        drs.setNewStage(newState);
        new DRSQuery(drs).execute();

    }

    public static void deleteGSLStage(DBIO query, String lifecycleId, String fromState, String toState) throws DimBaseException,
            AttrException, AdmException {
        String stageToRemove = null;
        // first, is the from state still in the normal lifecycle?
        query.resetSQL("SELECT NULL FROM norm_lifecycle " + "WHERE lifecycle_id=:I1 AND status=:I2");
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.readStart();
        if (!query.read(DBIO.DB_DONT_CLOSE)) {
            stageToRemove = fromState;
        } else {
            query.resetSQL("SELECT NULL FROM norm_lifecycle " + "WHERE lifecycle_id=:I1 AND status=:I2");
            query.bindInput(lifecycleId);
            query.bindInput(toState);
            query.readStart();
            if (!query.read(DBIO.DB_DONT_CLOSE)) {
                stageToRemove = toState;
            }
        }
        if (stageToRemove != null) {
            deleteGSLStage(query, stageToRemove);
        } else {
            // that will be the end of that...
            // UNLESS the GSL only has one or two stages left - then we should disallow it
            int normLcCount = getNormLifecycleCount(query, lifecycleId);
            if (!fromState.equals(toState)) {
                if (normLcCount == 2) {
                    throw new DimInvalidLcStateException("Cannot remove both ends" + " of transition from Global Stage Lifecycle.");
                }
            } else {
                if (normLcCount == 1) {
                    throw new DimInvalidLcStateException("Cannot remove transition" + " from single stage Global Stage Lifecycle.");
                }
            }

        }
    }

    public static void deleteGSLStage(DBIO query, String state) throws DBIOException, DimBaseException, AdmException {
        // first, check that the stage is not being used by any
        // items/baselines/requests
        query.resetSQL("SELECT NULL FROM item_catalogue WHERE stage_id=:I1");
        query.bindInput(state);
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            throw new DimInUseException("Cannot delete the stage '" + state + "' as there are items residing at this stage");
        }

        DRSClientStageLcHelper drs = new DRSClientStageLcHelper(DRSUtils.getLCNetClntObject(),
                StageLcQueryContext.StageUsedByWsFiles);
        drs.setStage(state);

        DRSOutputDataExtractor output = new DRSQuery(drs).execute();
        if (output.isResultEmpty()) {
            throw new DRSException("Cannot delete the stage '" + state + "' because status of items not received");
        }

        boolean isUsed = output.getIntValues(DRSParams.USED)[0] == 1 ? true : false;
        if (isUsed) {
            throw new DimInUseException("Cannot delete the stage '" + state + "' as there are items residing at this stage");
        }

        // change documents
        query.resetSQL("SELECT NULL FROM cm_catalogue WHERE stage_id=:I1");
        query.bindInput(state);
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            throw new DimInUseException("Cannot delete the stage '" + state + "' as there are requests residing at this stage");
        }

        query.resetSQL("SELECT NULL FROM sec_cm_catalogue WHERE stage_id=:I1");
        query.bindInput(state);
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            throw new DimInUseException("Cannot delete the stage '" + state + "' as there are requests residing at this stage");
        }

        // baselines
        query.resetSQL("SELECT NULL FROM bln_wset_rels WHERE stage_id=:I1");
        query.bindInput(state);
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            throw new DimInUseException("Cannot delete the stage '" + state + "' as there are baselines residing at this stage");
        }

        // change records
        drs = new DRSClientStageLcHelper(DRSUtils.getLCNetClntObject(), StageLcQueryContext.StageUsedByWsHistory);
        drs.setStage(state);

        output = new DRSQuery(drs).execute();
        if (output.isResultEmpty()) {
            throw new DRSException("Cannot delete the stage '" + state + "' because status of project structure change records"
                    + " not received");
        }
        isUsed = output.getIntValues(DRSParams.USED)[0] == 1 ? true : false;
        if (isUsed) {
            throw new DimInUseException("Cannot delete the stage '" + state
                    + "' as there are project structure change records residing at this stage");
        }

        // prevent stages being deleted if there are two or less than two entries in the stage catalogue
        if (getGSLStageCount(query) < 2) {
            throw new DimInvalidLcStateException("Global Stage Lifecycle must contain at least one stage.");
        }

        // retrieve the list of stages
        List stages = new ArrayList();
        int index = -1;
        query.resetSQL("SELECT obj_id from stage_catalogue ORDER BY stage_seq");
        query.readStart();
        while (query.read(DBIO.DB_DONT_CLOSE)) {
            stages.add(query.getString(1));
        }
        query.close(DBIO.DB_DONT_RELEASE);
        index = stages.indexOf(state) + 1;// index is 1-based, not 0-based

        if (index > 0) {
            // now remove the stage from the stage_catalogue
            deleteStage(query, state);
            query.write(DBIO.DB_DONT_COMMIT);

            // and then update the seq numbers
            for (int i = index; i < stages.size(); i++) {
                updateStageParams(query, i, (String)stages.get(i), null);
                query.write(DBIO.DB_DONT_COMMIT);
            }
        }
        if (getGSLStageCount(query) == 1) {
            String gsl_id = "";
            DRSClientSysObjAttrUtils drs2 = new DRSClientSysObjAttrUtils(DRSClientSysObjAttrUtils.SysObjAttrUtilsQueryContext.GetAdmParams);
            drs2.setObjClass(DRSClientSysObjAttrUtils.SYSOBJ_GLOBAL_LIFECYCLE);
            DRSUtils.execute(drs2);

            if (drs2.hasData() && (drs2.getAdmIds() != null) && (drs2.getAdmIds().length > 0)) {
            	gsl_id = drs2.getAdmIds()[0];
            }
            String stage = getInitialGSLStageId(query);

            AdmObject originator = AdmCmd.getObject(new AdmSpec(Constants.ORIGINATOR, RoleDefinition.class));
            List roleList = new ArrayList(1);
            roleList.add(originator);

            // create a circular normal transition for the remaining stage.
            Cmd cmd = AdmCmd.getCmd(Creatable.CREATE, LifeCycleStateTransition.class);
            cmd.setAttrValue(AdmAttrNames.LIFECYCLE_ID, gsl_id);
            cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_FROM_STATE, stage);
            cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_TO_STATE, stage);
            cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_AUTH_ROLES, roleList);
            cmd.setAttrValue(AdmAttrNames.LCSTATETRANS_IS_NORM, Boolean.TRUE);
            cmd.execute();
        }
    }

    private static void deleteStage(DBIO query, String stageId)
            throws DimBaseException, AttrException, AdmException {

        query.resetMessage(wcm_sql.STAGE_DELETE);
        query.bindInput(stageId);
    }

    private static void updateStageParams(DBIO query, Integer stageSeq, String oldState, String newState)
            throws DimBaseException, AttrException, AdmException {

        query.resetMessage(wcm_sql.STAGE_UPDATE);
        query.bindInputOrNull(stageSeq); // stage_seq
        query.bindInputOrNull(newState); // new obj_id
        query.bindInput(oldState);       // old obj_id
    }

    public static boolean GSLStageExists(DBIO query, String state) throws AdmObjectException, DBIOException, DimBaseException {
        boolean ret = false;
        query.resetSQL("SELECT 'X' from stage_catalogue WHERE obj_id=:I1");
        query.bindInput(state);
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            ret = true;
        }
        query.close(DBIO.DB_DONT_RELEASE);
        return ret;
    }

    public static void isTransitionDeletable(DBIO query, String lifecycleId, String fromState, String toState) throws AdmException {
        // check that the transition isn't normal
        query.resetSQL("SELECT NULL FROM life_cycles WHERE lifecycle_id=:I1 AND "
                + "doc_status=:I2 AND next_doc_status=:I3 AND norm_lc='Y'");
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            // if the transition is normal, we may be able to delete it providing the toState
            // is the last state and there are no off-normal transitions leading to or from it
            query.resetSQL("SELECT NULL FROM norm_lifecycle WHERE lifecycle_id=:I1 AND status=:I2 AND "
                    + "state_seq_no=(SELECT MAX(state_seq_no) FROM norm_lifecycle WHERE lifecycle_id=:I1)");
            query.bindInput(lifecycleId);
            query.bindInput(toState);
            query.readStart();
            if (query.read(DBIO.DB_DONT_CLOSE)) {
                // therefore IS the final state
                query.resetSQL("SELECT NULL FROM life_cycles WHERE lifecycle_id=:I1 AND "
                        + "(doc_status=:I2 OR next_doc_status=:I2) AND norm_lc='N'");
                query.bindInput(lifecycleId);
                query.bindInput(toState);
                query.readStart();
                if (query.read(DBIO.DB_DONT_CLOSE)) {
                    // there are off-normal transitions to or from the toState - throw an exception
                    throw new DimLcInconsistentLifecycleException("Cannot remove a "
                            + "normal transition from Global Stage Lifecycle.");
                }
            } else {
                // not the final state - throw an exception
                throw new DimLcInconsistentLifecycleException("Cannot remove a " + "normal transition from Global Stage Lifecycle.");
            }
        }
    }

    public static int getGSLStageCount(DBIO query) throws AdmException {
        int ret = 0;
        query.resetSQL("SELECT COUNT(*) FROM stage_catalogue");
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            ret = query.getInt(1);
        }
        return ret;
    }

    public static String getInitialGSLStageId(DBIO query) throws AdmException {
        String stage = "";
        query.resetSQL("SELECT obj_id FROM stage_catalogue");
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            stage = query.getString(1);
        }
        return stage;
    }

    public static int getNormLifecycleCount(DBIO query, String lifecycleId) throws AdmException {
        int ret = 0;
        query.resetSQL("SELECT COUNT(*) FROM norm_lifecycle where lifecycle_id=:I1");
        query.bindInput(lifecycleId);
        query.readStart();
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            ret = query.getInt(1);
        }
        return ret;
    }

}

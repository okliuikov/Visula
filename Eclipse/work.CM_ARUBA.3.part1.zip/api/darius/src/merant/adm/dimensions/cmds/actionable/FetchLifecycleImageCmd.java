/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.LifeCycleImage;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will fetch the image file representing the lifecycle that this
 * Dimensions object is following. If this Dimensions object is an instance of
 * LifeCycleImage class, then the image corresponding to the image revision will
 * be fetched (which might not be the default image revision assigned to a lifecycle).
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object.</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename to contain the lifecycle image.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Peter Raymond
 */
public class FetchLifecycleImageCmd extends RPCExecCmd {
    public FetchLifecycleImageCmd() throws AttrException {
        super();
        setAlias(Actionable.FETCH_LC_IMAGE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument) && !(attrValue instanceof Item) && !(attrValue instanceof Baseline)
                    && !(attrValue instanceof WorkSet) && !(attrValue instanceof Part) && !(attrValue instanceof ItemFile)
                    && !(attrValue instanceof LifeCycle) && !(attrValue instanceof LifeCycleImage)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        String lifecycle = null;

        StringBuffer buff = null;

        long lc_uid = 0;

        // Get the lifecycle name from the object.
        if (admObj instanceof LifeCycle) {
            lifecycle = admObj.getId();
        } else if (admObj instanceof LifeCycleImage) {
            AdmObject lifecycleObj = AdmHelperCmd.getObject(admObj.getAdmBaseId().getScope());
            lifecycle = lifecycleObj.getId();

            lc_uid = ((AdmUidObject) admObj).getAdmUid().getUid();
        } else {
            lifecycle = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.LIFECYCLE_ID);
        }

        // query for default lifecycle image revision UID unless admObj is a LifeCycleImage
        if (lc_uid == 0) {
            // Do a DBIO query to find the lifecycle image_uid!
            try {
                DBIO query = new DBIO(wcm_sql.QUERY_LC_IMAGE_UID);
                query.bindInput(lifecycle);
                query.readStart();
                if (!query.read()) {
                    throw new DimBaseCmdException("Failed to query details of the lifecycle " + lifecycle);
                }

                lc_uid = query.getLong(1);
            } catch (Exception ex) {
                throw new DimBaseCmdException("Failed to query detailed of the lifecycle " + lifecycle);
            }
        }

        // * XDATA has replaced the old DATA command
        buff = new StringBuffer("XDATA \"FETCH_DBFILE\" /PARAMETER=(");
        buff.append("CLASS=70, ");
        buff.append("ATTR=70, ");
        buff.append("UID=" + lc_uid + ", ");
        buff.append("USER_FILENAME=" + Encoding.escapeDMCLI(userFile) + ")");

        _cmdStr = new String(buff);

        return executeRpc();
    }
}

/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2001 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.actionable;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.serena.dmfile.dto.Pair;

import merant.adm.dimensions.cmds.CmdBuilder;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will promote a Dimensions object.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_LIST {AdmObject}<dt><dd>List of Dimensions objects</dd>
 *  <dt>WORKSET {String}<dt><dd>Workset name.  If not provided, current workset is taken</dd>
 *  <dt>COMMENT {String}<dt><dd>Comment</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {Boolean}<dt><dd>Whether child requests should be deployed as well</dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Paul
 */
public class PromoteToStageCmd extends RPCExecCmd {

    public static final String LATEST = "<LATEST>";

    private File userFile = null;

    public PromoteToStageCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DEPLOY, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.ITEM, false, AdmObject.class));
        // Only used when promoting requests
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.DEPLOY_AREAS, false, List.class)); // list of file area objects
        setAttrDef(new CmdArgDef(CmdArguments.SCHEDULE_DATETIME, false, String.class)); // ISO8601 format in the UTC timezone -
                                                                                        // 'YYYY'-'MM'-'DD'T'HH24':'MI':'SS'.'sss'Z'
        // Only used when CM is integrated with SDA
        setAttrDef(new CmdArgDef(CmdArguments.SDA_PROCESS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.SDA_DEPLOY_COMPONENT, false, Pair.class));
        setAttrDef(new CmdArgDef(CmdArguments.SDA_COMPONENTS, false, Map.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((attrValue != null) && (!(attrValue instanceof Item)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof Baseline))) {
                throw new AttrException("Error: PromoteToStageCmd - object type is not supported!", attrDef, attrValue);
            }
        }
    }
    
    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        String obj = executeRpc();
        try {
            if (userFile != null && userFile.exists()) {
                userFile.delete();
            }
        } catch (Exception e) {
            Debug.error(e);
            throw new AdmException(e);
        }

        return obj;
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        String stageID = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        List<String> objectListAsString = new ArrayList<String>();
        List<AdmObject> admObjects = (List<AdmObject>) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        List<AdmObject> areas = (List<AdmObject>) getAttrValue(CmdArguments.DEPLOY_AREAS);
        Boolean traverseChildRequests = (Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS);
        Boolean deploy = (Boolean) getAttrValue(AdmAttrNames.DEPLOY);
        String sdaProcess = (String) getAttrValue(CmdArguments.SDA_PROCESS);
        Pair<String, String> sdaDeployComponent = (Pair<String, String>) getAttrValue(CmdArguments.SDA_DEPLOY_COMPONENT);
        Map<String, String> sdaComponents = (Map<String, String>) getAttrValue(CmdArguments.SDA_COMPONENTS);

        StringBuffer sb = new StringBuffer();
        boolean useUserFileNameQualifier = false;
        AdmObject tempAdmObj = null;
        if (admObj == null && (admObjects == null || admObjects.size() == 0)) {
            throw new DimMandatoryAttributeException("Error: Object or list of objects must be specified.");
        }
        // We will allow either admObject or list of admObject. Not both.
        if (admObj != null && (admObjects != null && admObjects.size() > 0)) {
            throw new DimMandatoryAttributeException("Error: Please provide either object or list of objects. Not both.");
        }

        if (admObjects != null && admObjects.size() > 1) {
            useUserFileNameQualifier = true;
        }

        if (admObj != null) {
            tempAdmObj = admObj;
        } else {
            tempAdmObj = admObjects.get(0);
        }
        try {
            if (useUserFileNameQualifier) {
                if (admObjects.get(0) instanceof Item || admObjects.get(0) instanceof Baseline
                        || admObjects.get(0) instanceof ChangeDocument) {
                    for (int i = 0; i < admObjects.size(); i++) {
                        objectListAsString.add(admObjects.get(i).getAdmSpec().getSpec());
                    }
                } else {
                    throw new UnsupportedOperationException("The objects selected cannot be promoted. ");
                }
                userFile = preview ? null : getUserFile(objectListAsString);
            }

            if (tempAdmObj instanceof Item) {
                sb.append("PMI ");
            } else if (tempAdmObj instanceof ChangeDocument) {
                sb.append("PMRQ ");
            } else if (tempAdmObj instanceof Baseline) {
                sb.append("PMBL ");
            } else {
                throw new UnsupportedOperationException("The object selected cannot be promoted. ");
            }

            if (!useUserFileNameQualifier) {
                sb.append(Encoding.escapeDMCLI(tempAdmObj.getAdmSpec().getSpec()));
            }
            if (stageID != null && stageID.length() > 0) {
                sb.append(" /STAGE=" + Encoding.escapeDMCLI(stageID));
            }
            if (project != null) {
                sb.append(" /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec()));
            }
            if (comment != null && comment.length() > 0) {
                sb.append(" /COMMENT=" + Encoding.escapeDMCLI(comment));
            }
            if (traverseChildRequests != null) {
                if (traverseChildRequests.booleanValue()) {
                    sb.append(" /NOCANCEL_TRAVERSE");
                } else {
                    sb.append(" /CANCEL_TRAVERSE");
                }
            }

            String scheduled_date = (String) getAttrValue(CmdArguments.SCHEDULE_DATETIME);
            if (scheduled_date != null) {
                sb.append(" /DEPLOY_START_TIME=\"");
                sb.append(scheduled_date);
                sb.append("\"");
            }

            if (useUserFileNameQualifier) {
                sb.append(" /USER_FILENAME="
                        + Encoding.escapeDMCLI(preview ? "selected-objects.listingfile" : userFile.getAbsolutePath()));
            }

            if (areas != null && areas.size() > 0) {
                sb.append(" /AREA_LIST=(");
                String area = "";

                for (int i = 0; i < areas.size(); i++) {
                    area = areas.get(i).getId();
                    if (i > 0) {
                        sb.append(",");
                    }
                    sb.append(Encoding.escapeDMCLI(area));
                }
                sb.append(")");
            }

            if ((areas != null && areas.size() == 0) || (deploy != null && !deploy.booleanValue())) {
                sb.append(" /NODEPLOY");
            }

            if (sdaProcess != null && sdaProcess.length() > 0) {
                sb.append(" /SDA_PROCESS=").append(Encoding.escapeDMCLI(sdaProcess));
            }

            if (sdaDeployComponent != null) {
                sb.append(CmdBuilder.createParameter("/SDA_DEPLOY_COMPONENT", sdaDeployComponent));
            }

            if (sdaComponents != null && sdaComponents.size() > 0) {
                sb.append(CmdBuilder.createParameter("/SDA_COMPONENTS", sdaComponents));
            }

            _cmdStr = sb.toString();
        } catch (IOException ioe) {
            throw new AdmException(ioe);
        }
    }

    static File getUserFile(List<String> list) throws IOException {
        StringBuffer objList = new StringBuffer();
        if (list != null && list.size() > 0) {
            File file = File.createTempFile("safe_to_delete", ".tmp");
            Writer writer = null;
            PrintWriter printWriter = null;
            OutputStream os = null;
            try {
                // Always write in UTF8
                os = new FileOutputStream(file);
                writer = StringUtils.createUTF8EncodingWriter(os);
                printWriter = new PrintWriter(writer);
                for (int i = 0; i < list.size(); i++) {
                    printWriter.println(list.get(i));
                }
            } finally {
                if(printWriter != null) {
                    printWriter.close();
                }
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException ex) {
                        Debug.debug(ex);
                    }
                }
                if (os != null) {
                    try {
                        os.close();
                    } catch (IOException ex) {
                        Debug.debug(ex);
                    }
                }
            }
            return file;
        } else {
            return null;
        }
    }
}

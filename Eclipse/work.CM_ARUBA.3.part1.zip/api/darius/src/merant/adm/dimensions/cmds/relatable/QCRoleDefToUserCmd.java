/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.serena.dmnet.PcmsUserRoleInfo;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.helper.ProjectHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all User's related to the RoleDefinition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>CANDIDATE {Boolean}</dt>
 *      <dd>
 *          If true, returns candidate users,
 *          otherwise users that hold the specified role
 *      </dd>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Floz
 */
public class QCRoleDefToUserCmd extends QueryRelsCmd {
    public QCRoleDefToUserCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.CANDIDATE, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.NOWSET, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof RoleDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(User.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();

        AdmUidObject relType = null;
        if ((filter != null) && filter.hasAttr(CmdArguments.ADM_REL_TYPE)) {
            relType = (AdmUidObject) filter.get(CmdArguments.ADM_REL_TYPE);
        }

        queryRoleDefinitionUsers(ret, relationships, admObj, filter, relType);

        return ret;
    }

    private void queryRoleDefinitionUsers(List ret, boolean relationships, AdmObject roleDef, FilterImpl filter,
            AdmUidObject relType) throws DBIOException, DimBaseException, AdmException {
        if ((ret == null) || (roleDef == null) || (filter == null)) {
            throw new DBIOException("Error, invalid parameter when querying assigned users.");
        }

        if (!filter.hasAttr(CmdArguments.ADM_SCOPE_OBJECT)) {
            throw new DBIOException("Error, requires scope object filter.");
        }

        boolean candidate = ((Boolean) getAttrValue(CmdArguments.CANDIDATE)).booleanValue();
        boolean nowset = ((Boolean) getAttrValue(CmdArguments.NOWSET)).booleanValue();
        AdmObject scopeObject = (AdmObject) filter.get(CmdArguments.ADM_SCOPE_OBJECT);
        if ((!(scopeObject instanceof Baseline)) && (!(scopeObject instanceof WorkSet)) && (!(scopeObject instanceof Part))
                && (!(scopeObject instanceof ChangeDocument)) && (!(scopeObject instanceof Item))) {
            throw new DBIOException("Scope object is of unsupported type!");
        }

        String assigntype = "*";
        if (relType != null) {
            if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_DELEGATED) {
                assigntype = "N";
            } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_REAL) {
                assigntype = "Y";
            }
        }

        String capability = "*";
        if (filter.hasAttr(AdmAttrNames.REL_CAPABILITY)) {
            capability = (String) filter.get(AdmAttrNames.REL_CAPABILITY);
        }

        String objclass = "";
        if (scopeObject instanceof Baseline) {
            objclass = "B";
        } else if (scopeObject instanceof ChangeDocument) {
            objclass = "C";
        } else if (scopeObject instanceof Item) {
            objclass = "I";
        } else if (scopeObject instanceof WorkSet) {
            objclass = "W";
        } else if (scopeObject instanceof Part) {
            objclass = "P";
        }

        Cmd cmd = getCmd("PcmsGetUserRoles");
        cmd.setAttrValue("assigntype", assigntype);
        cmd.setAttrValue("capability", capability);
        cmd.setAttrValue("objclass", objclass);
        cmd.setAttrValue("role", roleDef.getId());
        cmd.setAttrValue("objuid", String.valueOf(((AdmUidObject) scopeObject).getAdmUid().getUid()));
        cmd.setAttrValue("candidate", candidate ? "Y" : "N");
        cmd.setAttrValue("nowset", nowset ? "Y" : "N");

        List<PcmsUserRoleInfo> result = (List<PcmsUserRoleInfo>) cmd.execute();
        if (result != null) {
            String curUserId = "";
            String curAssignType = "";
            String curCapability = "";
            String curProjectName = "";

            AdmObject realRelType = null;
            AdmObject delegatedRelType = null;
            AdmObject curRelType = null;
            AdmObject newRel = null;

            Set<Long> projectUidsSet = new HashSet<Long>();
            for (PcmsUserRoleInfo uri : result) {
                long projectUid = uri.getWorksetUid();
                if (projectUid > 0) {
                    projectUidsSet.add(projectUid);
                }
            }

            List<AdmObject> projects = ProjectHelper.getProjectsFromUids(projectUidsSet);
            Map<Long, String> projectNames = new HashMap<Long, String>();
            for (AdmObject project : projects) {
                AdmUid uid = (AdmUid) project.getAttrValue(AdmAttrNames.ADM_UID);
                projectNames.put(uid.getUid(), project.getAdmSpec().getSpec());
            }

            for (PcmsUserRoleInfo uri : result) {

                curUserId = uri.getUser();
                curAssignType = uri.getFromTree();
                curCapability = uri.getCapability();
                curProjectName = projectNames.get(uri.getWorksetUid());
                if (curProjectName == null) {
                    curProjectName = "";
                }

                if (curAssignType.equals("Y")) {
                    if (realRelType == null) {
                        realRelType = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_REAL,
                                RelationshipType.class));
                    }

                    curRelType = realRelType;
                } else if ((!curAssignType.equals("O")) && (!curAssignType.equals("P"))) {
                    if (delegatedRelType == null) {
                        delegatedRelType = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_DELEGATED,
                                RelationshipType.class));
                    }

                    curRelType = delegatedRelType;
                }

                newRel = addRelation(ret, relationships, roleDef.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(curUserId, User.class, null, null), curRelType);

                if (newRel != null) {
                    newRel.setAttrValue(AdmAttrNames.REL_CAPABILITY, curCapability);
                    newRel.setAttrValue(AdmAttrNames.REL_ROLE_WORKSET, curProjectName);
                }
            }
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ReplOutwardTransfer;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Replication Outward Transfer's related to the BaseDatabase object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class QCBaseDbaseToReplOutwardTransferCmd extends QueryRelsCmd {
    public QCBaseDbaseToReplOutwardTransferCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof BaseDatabase)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(ReplOutwardTransfer.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    final String MATCH_ALL = "%";

    // initialize filter
    String filterConfigId = MATCH_ALL;
    int filterReplClass = Constants.REPL_ITEM_CLASS; // default to item replication
    String filterStartDate = "01-JAN-1990 12:00:00"; // if filter value is NULL, use this value
    String filterEndDate = null;// "05-DEC-2003 12:00:00";
    String filterDbService = MATCH_ALL;
    String filterNodeName = MATCH_ALL;
    String filterBaseDbName = MATCH_ALL;
    String filterTargetWorksetId = MATCH_ALL;

    // initialize sort keys
    StringBuffer orderBy = new StringBuffer();
    boolean orderByReplDateSpecified = false;

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {

        if (filter != null) {
            processFilter(filter);
            processOrder(filter);
        }
        // unless explicitly sorted by replication date, ensure
        // that the query always orders by replication date descending
        if (orderBy.length() == 0) {
            orderBy.append("repl_date DESC");
        } else if (!orderByReplDateSpecified) {
            orderBy.append(", repl_date DESC");
        }

        List ret = new ArrayList();

        DBIO query = null;
        if (filterEndDate != null) {
            query = new DBIO(wcm_sql.REPL_QUERY_OUTWARD_TRANSFERS);
        } else {
            // added slightly modified query as TO_DATE(TO_CHAR(SYSDATE)) was barfing on sqlsvr & DB2
            query = new DBIO(wcm_sql.REPL_QUERY_OUTWARD_TRANSFERS_SYSDATE);
        }

        query.bindInput(filterReplClass); // 56 - item replication, 58 - baseline replication, 61 - change document replication
        query.bindInput(filterConfigId); // replication configuration Id
        query.bindInput("'" + filterStartDate + "'", DBIO.DB_ARG_STRING_LITERAL); // start date
        if (filterEndDate != null) {
            query.bindInput("'" + filterEndDate + "'", DBIO.DB_ARG_STRING_LITERAL); // end date
        }
        /*
         * else
         * //query.bindInput("TO_CHAR(SYSDATE+5,'DD-MON-YYYY HH24:MI:SS')", DBIO.DB_ARG_STRING_LITERAL);
         * query.bindInput("TO_CHAR(SYSDATE,'DD-MON-YYYY HH24:MI:SS')", DBIO.DB_ARG_STRING_LITERAL);//+1
         */
        query.bindInput(filterTargetWorksetId); // workset Id
        query.bindInput(filterNodeName); // node name
        query.bindInput(filterDbService); // db service (Oracle SID or ODBC datasource)
        query.bindInput(filterBaseDbName); // base database name
        query.bindInput(orderBy.toString(), DBIO.DB_ARG_STRING_LITERAL); // sort order string
        query.readStart();

        while (query.read()) {
            long uid = query.getLong(1);
            String id = query.getString(2);
            String revision = query.getString(3);
            String typeName = (filterReplClass == Constants.REPL_ITEM_CLASS
                    ? "IR" : (filterReplClass == Constants.REPL_BASELINE_CLASS ? "BR" : "CR"));

            AdmBaseId specBaseId = AdmHelperCmd.newAdmBaseId("$GENERIC:" + id + "." + (new Long(uid)).toString() + "-" + typeName
                    + ";" + revision, ReplOutwardTransfer.class, null, null);
            AdmBaseId uidBaseId = AdmHelperCmd.newAdmBaseId(uid, ReplOutwardTransfer.class, null, specBaseId);
            addRelation(ret, relationships, admObj.getAdmBaseId(), uidBaseId);
        }

        return ret;
    }

    private void processOrder(FilterImpl f) {

        if (f == null) {
            return;
        }

        Collection orders = f.orders();

        if (orders != null && !orders.isEmpty()) {
            boolean comma = false;
            for (Iterator it = orders.iterator(); it.hasNext();) {
                FilterOrder order = (FilterOrder) it.next();
                if (order == null) {
                    continue;
                }
                String attrName = order.getAttrName();

                // order by replication configuration ID ?
                if (AdmAttrNames.ID.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("config_id DESC");
                    } else {
                        orderBy.append("config_id ASC");
                    }
                    comma = true;
                }

                // order by replication date?
                if (AdmAttrNames.REPL_START_DATE.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("repl_date DESC");
                    } else {
                        orderBy.append("repl_date ASC");
                    }
                    comma = true;
                    orderByReplDateSpecified = true;
                }

                // order by node name?
                if (AdmAttrNames.REPL_NODE_NAME.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("node_name DESC");
                    } else {
                        orderBy.append("node_name ASC");
                    }
                    comma = true;
                }

                // order by base database name?
                if (AdmAttrNames.REPL_BASEDB_NAME.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("base_db DESC");
                    } else {
                        orderBy.append("base_db ASC");
                    }
                    comma = true;

                }

                // order by data source name ?
                if (AdmAttrNames.REPL_DB_SERVICE.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("db_service DESC");
                    } else {
                        orderBy.append("db_service ASC");
                    }
                    comma = true;
                }
            }
        }
    }

    private void processFilter(FilterImpl f) {

        if (f == null) {
            return;
        }

        Collection crits = f.criteria();

        if (crits != null && !crits.isEmpty()) {
            for (Iterator it = crits.iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit == null) {
                    continue;
                }
                String attrName = crit.getAttrName();

                // filter by replication configuration ID ?
                if (AdmAttrNames.ID.equals(attrName) && crit.getValue() != null) {
                    filterConfigId = crit.getValue().toString();
                }

                // filter by replication configuration class? Item/Baseline/Chdoc
                if (AdmAttrNames.PARENT_CLASS.equals(attrName) && crit.getValue() != null) {

                    Object obj = crit.getValue();
                    Class objClass = Item.class;

                    if (obj instanceof Class) {
                        objClass = (Class) obj;
                    } else if (obj instanceof String) {
                        try {
                            objClass = Class.forName((String) obj);
                        } catch (ClassNotFoundException cnfe) {
                            Debug.error("Exception: " + cnfe);
                            objClass = Item.class;
                        }
                    }

                    if (Item.class.equals(objClass)) {
                        filterReplClass = Constants.REPL_ITEM_CLASS;
                    } else if (Baseline.class.equals(objClass)) {
                        filterReplClass = Constants.REPL_BASELINE_CLASS;
                    } else if (ChangeDocument.class.equals(objClass)) {
                        filterReplClass = Constants.REPL_CHDOC_CLASS;
                    }
                }

                // filter by start date?
                if (AdmAttrNames.REPL_START_DATE.equals(attrName) && crit.getValue() != null) {
                    filterStartDate = crit.getValue().toString();
                }

                // filter by end date?
                if (AdmAttrNames.REPL_END_DATE.equals(attrName) && crit.getValue() != null) {
                    filterEndDate = crit.getValue().toString();
                }

                // filter by DataSource name?
                if (AdmAttrNames.REPL_DB_SERVICE.equals(attrName) && crit.getValue() != null) {
                    filterDbService = crit.getValue().toString();
                }

                // filter by node name?
                if (AdmAttrNames.REPL_NODE_NAME.equals(attrName) && crit.getValue() != null) {
                    filterNodeName = crit.getValue().toString();
                }

                // filter by base database name?
                if (AdmAttrNames.REPL_BASEDB_NAME.equals(attrName) && crit.getValue() != null) {
                    filterBaseDbName = crit.getValue().toString();
                }

                // filter by workset/baseline ID?
                if (AdmAttrNames.REPL_TARGET_WORKSET_OR_BASELINE_ID.equals(attrName) && crit.getValue() != null) {
                    filterTargetWorksetId = crit.getValue().toString();
                }
            }
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidRoleException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will assign a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions user object to be registered/deregistered as tool manager</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, removes the tool manager assignment<br>
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class RegisterToolManagerCmd extends DBIOCmd {
    public RegisterToolManagerCmd() throws AttrException {
        super();
        setAlias(Assignable.REGISTER_TOOL_MANAGER);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPLACE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof User))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_USERMAN")) {
            throw new DimNoPrivilegeException("ADMIN_USERMAN");
        }

        validateAllAttrs();

        User admObj = (User) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean remove = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        String userName = admObj.getId();

        if (!userExists(userName)) {
            throw new DimAlreadyExistsException("Error: user " + userName + " does not exist.");
        }

        boolean isToolMan = isToolManager(userName);
        if (isToolMan && !remove) {
            throw new DimInvalidRoleException("Error: user " + userName + " is already a TOOL-MANAGER.");
        }

        if (!remove) {
            doInsertToolManager(userName);
        } else {
            long toolManCount = countToolManagers();
            if (toolManCount > 1) {
                doRemoveToolManager(userName);
            } else {
                throw new DimInvalidRoleException(
                        "Error: there must always exist at least one TOOL-MANAGER per Dimensions Base Database.");
            }
        }

        // FIXME_DVDC copied and pasted from AssignCmd - this should be a utility method:
        Object key = null;
        Object value = null;
        List removeKeys = new ArrayList();
        List keys = getCache().getKeys();
        for (int i = 0; i < keys.size(); i++) {
            key = keys.get(i);
            if (key == null) {
                continue;
            }

            if (key instanceof List) {
                if (((List) key).size() > 0) {
                    value = ((List) key).get(0);
                    if ((value != null) && (value instanceof String)) {
                        if (value.equals(Constants.HAS_ROLE_CACHE_KEY) || value.equals(Constants.HAS_ANY_ROLE_CACHE_KEY)) {
                            removeKeys.add(key);
                        }
                    }
                }
            } else if (key instanceof String) {
                if (((String) key).startsWith(Constants.IS_TOOL_MANAGER_CACHE_KEY)) {
                    removeKeys.add(key);
                }
            }
        }

        for (int i = 0; i < removeKeys.size(); i++) {
            getCache().remove(removeKeys.get(i));
        }

        // Remove any caching from
        // within the user objects
        if (admObj != null) {
            admObj.setAttrValue(Constants.HAS_ROLE_CACHE_KEY, null);
        }

        // And out of paranoia - remove from the current user as well
        getCurRootObj(User.class).setAttrValue(Constants.HAS_ROLE_CACHE_KEY, null);

        return new AdmResult("Operation completed");
    }

    private void doInsertToolManager(String userName) throws DBIOException, DimBaseException, AdmException {
        DBIO query = new DBIO(wcm_sql.TOOL_MANAGER_ADD);
        query.bindInput(userName);
        query.write();
        query.commit();
    } 

    private long countToolManagers() throws DBIOException, DimBaseException, AdmException {
        String queryStr = "select count(*) from rm_users where user_name IS NOT NULL AND (role = '$TOOL-MANAGER' or role = 'TOOL-MANAGER')";
        DBIO query = new DBIO(queryStr);
        query.readStart();

        long count = 0;
        if (query.read()) {
            count = query.getLong(1);
        }
        return count;
    }

    private void doRemoveToolManager(String userName) throws DBIOException, DimBaseException, AdmException {
        DBIO query = new DBIO(wcm_sql.TOOL_MANAGER_DELETE);
        query.bindInput(userName);
        query.write();
        query.commit();
    }

    private boolean userExists(String userName) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(userName);

        String queryStr = "SELECT user_uid FROM users_profile WHERE user_name=:I1 AND privilege_level>=0";
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, queryStr);
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    private boolean isToolManager(String userName) throws DBIOException, DimBaseException, AdmException {
        String queryStr = "select null from rm_users "
                + "where user_name=:I1 and (role = '$TOOL-MANAGER' or role = 'TOOL-MANAGER')";
        DBIO query = new DBIO(queryStr);
        query.bindInput(userName);
        query.readStart();
        return query.read();
    }

}

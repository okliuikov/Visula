/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimReservedWordException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Template;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions BaselineTemplate.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name used exclusively for role checking</dd>
 *  <dt>ID {String}</dt><dd>Name identifier of the new baseline template</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author Floz
 */
public class CreateBaselineTemplateCmd extends DBIOCmd {

    public CreateBaselineTemplateCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_CLASS, false, Item.class, Class.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        String id = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ID), AdmDmLengths.DM_L_TEMPLATE);

        Class scopeClass = (Class) getAttrValue(AdmAttrNames.PARENT_CLASS);
        if (!(Item.class.equals(scopeClass) || ChangeDocument.class.equals(scopeClass))) {
            throw new DimInvalidAttributeException("Error: unsupported baseline template type: " + scopeClass);
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        // check whether the specifed template name is a reserved word
        if (id.equals(Constants.BLINET_ID_MERGED) || id.equals(Constants.BLINET_ID_REVISED)) {
            throw new DimReservedWordException("Error: baseline template " + id + " is a reserved template name.");
        }

        // check whether baseline template already exists
        if (DoesExistHelper.baselineTemplateExists(id)) {
            throw new DimAlreadyExistsException("Error: baseline template " + id + " has already been defined.");
        }

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        DBIO query = new DBIO(wcm_sql.CREATE_BLINET);
        query.bindInput(id);
        query.bindInput(TypeUtils.getTypeFlag(scopeClass));
        query.bindInput(userName);
        query.write();
        query.commit();

        setAttrValue(CmdArguments.INT_SPEC, id);
        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Template.class);
        return retResult;
    }
}
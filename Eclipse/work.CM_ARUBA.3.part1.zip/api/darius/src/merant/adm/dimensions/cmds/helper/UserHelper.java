/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpecTwin;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;

/**
 * @author abollmann
 *         Quick method to get the user objects for a list of user ids instead of using AdmCmd.getObjects()
 *         which is running one query per user id passed in.
 */
public class UserHelper {

    public static List getUserObjects(List userIds) throws DBIOException {
        String ret = null;
        String userString = "";
        List userObjs = new ArrayList();
        for (int i = 0; i < userIds.size(); i++) {
            if (!(userIds.get(i) instanceof AdmSpecTwin)) {
                throw new DBIOException("Must specify a list of AdmSpecTwin objects!");
            }
            userString += "'" + (((AdmSpecTwin) userIds.get(i)).getSpec()) + "',";
        }
        userString = userString.substring(0, userString.length() - 1);
        try {
            DBIO dbio = new DBIO("SELECT user_uid" + " FROM users_profile" + " WHERE user_name in (:I1)");
            dbio.bindInput(userString, DBIO.DB_ARG_STRING_LITERAL);
            try {
                dbio.readStart();
                while (dbio.read()) {
                    long uid = dbio.getLong(1);
                    AdmUid uidObj = new AdmUid(uid, User.class);
                    AdmObject userObj = new User(uidObj);
                    userObjs.add(userObj);
                }
            } finally {
                dbio.close();
            }
        } catch (AdmException ae) {
        }
        return userObjs;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015 Serena. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.assignable;

import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.framework.AttrException;

public class ReplaceAssignedUsersToWorksetCmd extends AssignUsersToWorksetCmd {
    public ReplaceAssignedUsersToWorksetCmd() throws AttrException {
        super();
        setAlias(Assignable.REPLACE_ASSIGNED_USERS_TO_WORKSET);
    }

    @Override
    protected String getFlag() {
        return "/REPLACE";
    }
}

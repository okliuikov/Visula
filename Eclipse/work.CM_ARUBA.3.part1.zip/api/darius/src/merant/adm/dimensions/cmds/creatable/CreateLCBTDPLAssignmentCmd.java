/*
 * Copyright (C) 2001, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.LCBTDPLAssignment;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions LCBTDPLAssignment.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>LCBT_PART_OBJ{AdmObject}<dt><dd>Dimensions Part object for which the assignment is to be created</dd>
 *  <dt>LCBT_RELATED_TYPE_OBJ {AdmObject}<dt><dd>Dimensions Type object for which the assignment is to be created</dd>
 *  <dt>LCBT_RELATED_LC_OBJ{AdmObject}<dt><dd>Dimensions Lifecycle object for which the assignment is to be created</dd>
 *  <dt>LCBT_RELATED_BT_OBJ {AdmObject}<dt><dd>Dimensions Browse Template object for which the assignment is to be created</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateLCBTDPLAssignmentCmd extends DBIOCmd {
    public CreateLCBTDPLAssignmentCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.LCBT_PART_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCBT_RELATED_TYPE_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCBT_RELATED_LC_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCBT_RELATED_BT_OBJ, true, AdmObject.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject typeObj = (AdmObject) getAttrValue(AdmAttrNames.LCBT_RELATED_TYPE_OBJ);
        AdmObject partObj = (AdmObject) getAttrValue(AdmAttrNames.LCBT_PART_OBJ);
        AdmObject btObj = (AdmObject) getAttrValue(AdmAttrNames.LCBT_RELATED_BT_OBJ);
        AdmObject lcObj = (AdmObject) getAttrValue(AdmAttrNames.LCBT_RELATED_LC_OBJ);

        // verify type
        List attrs = AdmHelperCmd.getAttributeValues(typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        String productName = (String) attrs.get(0);
        String typeName = (String) attrs.get(1);
        Class typeClass = (Class) attrs.get(2);
        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

        if (!ChangeDocument.class.equals(typeClass)) {
            throw new DimAlreadyExistsException("Dimensions object type " + productName + ":" + typeName
                    + " is not a request type.");
        }

        if (!DoesExistHelper.typeExists(productName, typeName, typeFlag)) {
            throw new DimAlreadyExistsException("Dimensions request type " + productName + ":" + typeName + " does not exist");
        }

        long typeUid = ((AdmUidObject) typeObj).getAdmUid().getUid();

        // verify browse template
        attrs = AdmHelperCmd.getAttributeValues(
                btObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.PARENT_CLASS, AdmAttrNames.ID,
                        AdmAttrNames.REVISION }));

        int objClass = 41;
        String btProductName = (String) attrs.get(0);
        Class btTypeClass = (Class) attrs.get(1);
        String templateName = (String) attrs.get(2);
        String revision = (String) attrs.get(3);

        if (!ChangeDocument.class.equals(btTypeClass)) {
            throw new DimAlreadyExistsException("Browse template " + templateName + ":" + revision
                    + " is not a request browse template.");
        }

        if (!productName.equals(btProductName)) {
            throw new DimInvalidAttributeException("Dimensions request type " + productName + ":" + typeName
                    + " and request browse template " + templateName + ";" + revision + " must be defined in the same product.");
        }

        long btUid = getBrowseTemplateUid(productName, templateName, objClass, revision);
        if (btUid == 0) {
            throw new DimAlreadyExistsException("Browse template revision " + templateName + ";" + revision + " does not exist.");
        }

        // verify lifecycle
        String lcName = lcObj.getId();
        if (!DoesExistHelper.lifecycleExists(lcName)) {
            throw new DimAlreadyExistsException("Lifecycle " + lcName + " does not exist.");
        }

        // verify design part
        attrs = AdmHelperCmd.getAttributeValues(partObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.VARIANT }));

        String partProductName = (String) attrs.get(0);
        String partName = (String) attrs.get(1);
        String partVariant = (String) attrs.get(2);

        if (!productName.equals(partProductName)) {
            throw new DimInvalidAttributeException("Dimensions request type " + productName + ":" + typeName + " and design part "
                    + partName + "." + partVariant + " must be defined in the same product.");
        }

        long partUid = getPartUid(productName, partName, partVariant);
        if (partUid == 0) {
            throw new DimInvalidAttributeException("Design part " + productName + ":" + partName + "." + partVariant
                    + " does not exist.");
        }

        if (partLevelAssignmentExists(partUid, typeUid)) {
            throw new DimAlreadyExistsException("A lifecycle has already been assigned to this design part.");
        }

        long relUid = getNewUid();

        setAttrValue(CmdArguments.INT_SPEC, partUid + ":" + typeUid);

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            // insert part level assignment definition
            query.resetMessage(wcm_sql.PART_LEVEL_ASSIGNMENT_INSERT_REL);
            query.bindInput(relUid);
            query.bindInput(partUid);
            query.bindInput(typeUid);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

            // insert lifecycle + browse template data
            query.resetMessage(wcm_sql.PART_LEVEL_ASSIGNMEMT_INSERT_REL_ATTRS);
            query.bindInput(relUid);
            query.bindInput(lcName);
            query.bindInput(btUid);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, LCBTDPLAssignment.class);
        return retResult;
    }

    private long getBrowseTemplateUid(String productName, String templateName, int objClass, String revision) throws AdmException {
        DBIO query = new DBIO(wcm_sql.CPL_BROWSE_TEMPLATE_QUERY_UID);
        query.bindInput(productName);
        query.bindInput(templateName);
        query.bindInput(objClass);
        query.bindInput(revision);
        query.readStart();

        long uid = 0;
        if (query.read()) {
            uid = query.getLong(1);
        }
        query.close();
        return uid;
    }

    private long getPartUid(String productName, String partName, String partVariant) throws AdmException {
        DBIO query = new DBIO(wcm_sql.DESIGN_PART_EXISTS);
        query.bindInput(productName);
        query.bindInput(partName);
        query.bindInput(partVariant);
        query.readStart();

        long uid = 0;
        if (query.read()) {
            uid = query.getLong(1);
        }
        query.close();
        return uid;
    }

    private boolean partLevelAssignmentExists(long partUid, long typeUid) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList(2);
        inputs.add(new Long(partUid));
        inputs.add(new Long(typeUid));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.PART_LEVEL_ASSIGNMENT_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

}

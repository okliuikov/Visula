/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ItemTypeGroup;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate an Item Type to an Item Type Group.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {Type}<dt><dd>Dimensions Item Type object</dd>
 *  <dt>ADM_PARENT_OBJECT {ItemTypeGroup}<dt><dd>Parent Dimensions Item Type Group object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @todo This class uses a copy of the same AdmUid & AdmSpec instanciation methods as QueryChildrenCmd.java
 * @author Floz
 */
public class RelateItemTypeToItemTypeGroupCmd extends DBIOCmd {
    public RelateItemTypeToItemTypeGroupCmd() throws AttrException {
        super();
        setAlias("RelateItemTypeToItemTypeGroupCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, Type.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, ItemTypeGroup.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof ItemTypeGroup)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Dimensions item type group
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);

        // Dimensions item type
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        String itemTypeGroupName = admParentObj.getId();
        if (!DoesExistHelper.itemTypeGroupExists(itemTypeGroupName)) {
            throw new DimNotExistsException("Error: item type group " + itemTypeGroupName + " does not exist.");
        }

        if (DoesExistHelper.itemTypeGroupIsInUse(itemTypeGroupName, true)) {
            throw new DimInUseException(
                    "Error: you cannot modify an item type group used by a template which has been used for a release.");
        }

        String productName = StringUtils.adjustValue((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME),
                AdmDmLengths.DM_L_PRODUCT_ID);

        String typeName = admObj.getId();

        if (!DoesExistHelper.typeExists(productName, typeName, "I")) {
            throw new DimNotExistsException("Error: item type " + productName + ":" + typeName + " does not exist.");
        }

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            if (!bDeassign) {
                query = SqlUtils.itmtypegrpAdd(itemTypeGroupName, typeName);
                query.write(DBIO.DB_DONT_COMMIT);
                query.close(DBIO.DB_DONT_RELEASE);
            } else {
                // deassign
                query.resetMessage(wcm_sql.ITMTYPEGRP_REMOVE);
                query.bindInput(itemTypeGroupName);
                query.bindInput(typeName);
                query.write(DBIO.DB_DONT_COMMIT);
                query.close(DBIO.DB_DONT_RELEASE);

                query.resetMessage(wcm_sql.ITMTYPEGRP_EXISTS);
                query.bindInput(itemTypeGroupName);
                query.readStart();
                boolean hasItemTypes = query.read(DBIO.DB_DONT_CLOSE);
                query.close(DBIO.DB_DONT_RELEASE);

                if (!hasItemTypes) {
                    throw new DimNotExistsException("Error: there must be at least one item type assigned to this item type group.");
                }
            }
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return new AdmResult("Operation completed");
    }
}

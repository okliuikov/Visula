/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.FileAreaFile;
import merant.adm.dimensions.objects.Format;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StreamUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt>
 *  <dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PROJECT {String}<dt><dd>Project specification in which you want to delete a directory (only used for directory)</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of requests to be related</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class DeleteCmd extends RPCExecCmd {

    public DeleteCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RECURSIVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE_ITEMS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLEAN, false, Boolean.FALSE, Boolean.class)); // PRUNE directories during file delete
        setAttrDef(new CmdArgDef(CmdArguments.USER_DIRECTORY, false, String.class)); // used for PRUNE directories during file
                                                                                     // delete up to specified directory
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Baseline)) && (!(attrValue instanceof Branch)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof Customer)) && (!(attrValue instanceof DimDirectory))
                    && (!(attrValue instanceof Format)) && (!(attrValue instanceof Item)) && (!(attrValue instanceof Part))
                    && (!(attrValue instanceof Release)) && (!(attrValue instanceof WorkSet))
                    && (!(attrValue instanceof FileAreaFile))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String project = (String) getAttrValue(AdmAttrNames.PROJECT);
        Boolean recurse = (Boolean) getAttrValue(CmdArguments.RECURSIVE);
        Boolean remove_items = (Boolean) getAttrValue(CmdArguments.REMOVE_ITEMS);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        Boolean prune = (Boolean) getAttrValue(CmdArguments.CLEAN);
        String user_dir = (String) getAttrValue(CmdArguments.USER_DIRECTORY);
        boolean isStreamProject = false; // may be set to true below - see "} else if (admObj instanceof WorkSet) {"

        if (admObj instanceof Baseline) {
            _cmdStr = "DBL ";
        } else if (admObj instanceof Branch) {
            _cmdStr = "RMVB ";
        } else if (admObj instanceof ChangeDocument) {
            _cmdStr = "DCH ";
        } else if (admObj instanceof Customer) {
            _cmdStr = "RCU " + Encoding.escapeSpec((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID));
            _cmdStr += " /LOCATION="
                    + Encoding.escapeSpec((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.CUSTOMER_LOCATION));
            _cmdStr += " /PROJECT="
                    + Encoding.escapeSpec((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.CUSTOMER_PROJECT));
        } else if (admObj instanceof DimDirectory) {
            _cmdStr = "DWSD ";
        } else if (admObj instanceof Format) {
            _cmdStr = "RMDF ";
        } else if (admObj instanceof Item) {
            _cmdStr = "DI ";
        } else if (admObj instanceof Part) {
            _cmdStr = "DPV ";
        } else if (admObj instanceof Release) {
            _cmdStr = "DREL ";
        } else if (admObj instanceof WorkSet) {
            isStreamProject = StreamUtils.isStream(admObj.getAdmSpec().getSpec());
            _cmdStr = isStreamProject ? "DS " : "RWS ";
        } else if (admObj instanceof FileAreaFile) {
            _cmdStr = "DELF";
            if (prune) {
                _cmdStr += " /PRUNE";
            }
            if (user_dir != null && user_dir.trim().length() > 0) {
                _cmdStr += " /USER_DIR=" + Encoding.escapeSpec(user_dir);
            }
            _cmdStr += " /FILENAME=";
        }

        if (!(admObj instanceof Customer)) {
            String spec = admObj.getAdmSpec().getSpec();
            _cmdStr += Encoding.escapeSpec(spec);
        }
        if (admObj instanceof DimDirectory || admObj instanceof Item) {
            if (project != null && project.length() > 0) {
                _cmdStr += " /WORKSET=" + Encoding.escapeSpec(project);
            }
            if (admObj instanceof DimDirectory) {
                if (recurse != null && recurse.booleanValue()) {
                    _cmdStr += " /RECURSIVE";
                }
                if (remove_items != null && remove_items.booleanValue()) {
                    _cmdStr += " /REMOVE_ITEMS";
                }
                if (chdocs != null && chdocs.length() > 0) {
                    _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
                }
            }
        }
        return executeRpc();
    }
}

/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Vector;

import com.serena.dmfile.FilePath;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will rename a Dimensions object.
 * <p>
 * NOTE: When renaming ItemFile's, the ID parameter should be the new project filename (ITEMFILE_FILENAME) not the database id as it
 * is for other objects. If PARENT_RELATIVE is false, ID may specify a path and filename, and the command can change both directory
 * and filename. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions object</dd>
 *  <dt>ID {String}</dt><dd>New identifier for the object. In the case of DimDirectory
 *                         objects this should be the last path component. In the case
 *                         of ItemFile objects this should be the filename component. If
 *                         PARENT_RELATIVE is false ID can contain both path and filename
 *                         components and the opertaion will not be relative to the parent
 *                         directory</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PARENT_RELATIVE {Boolean}</dt><dd>Rename is relative to the parent directory</dd>
 *  <dt>PROJECT {String}</dt><dd>Project spec in which a directory should be renamed</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of requests to be related</dd>
 * </dl></code> <br>
 * <b>Optional Customer Arguments:</b> <code><dl>
 *  <dt>CUSTOMER_LOCATION {String}</dt><dd>New location attribute for the customer</dd>
 *  <dt>CUSTOMER_PROJECT {String}</dt><dd>New project attribute for the customer</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class RenameCmd extends RPCExecCmd {
    public RenameCmd() throws AttrException {
        super();
        setAlias(Creatable.RENAME);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARENT_RELATIVE, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));

        // Optional Customer Arguments
        setAttrDef(new CmdArgDef(AdmAttrNames.CUSTOMER_LOCATION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CUSTOMER_PROJECT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Baseline)) && (!(attrValue instanceof Customer)) && (!(attrValue instanceof DimDirectory))
                    && (!(attrValue instanceof Item)) && (!(attrValue instanceof ItemFile)) && (!(attrValue instanceof Part))
                    && (!(attrValue instanceof User)) && (!(attrValue instanceof WorkSet))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        boolean isRelative = ((Boolean) getAttrValue(CmdArguments.PARENT_RELATIVE)).booleanValue();
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);

        if ((admObj instanceof Baseline) || (admObj instanceof Customer) || (admObj instanceof Part) || (admObj instanceof User)
                || (admObj instanceof WorkSet)) {
            // the "relative stuff" only makes sense for files & folders.
            isRelative = false;
        }

        String param;
        if (isRelative) {
            // Only file & folder names (ItemFile & DimDirectory) will come this path
            // through the code, since "relative" doesn't make sense for other classes.
            char chSep = FilePath.getDirSep(DimSystem.getSystem().getSessionBean().getServerOs());

            // attempt to check new filename for validity:
            if (id == null || id.length() == 0) {
                throw new DimBaseCmdException("New name not specified");
            }
            if (id.indexOf(Constants.DIRPATH_SEP) != -1 || id.indexOf(chSep) != -1) {
                throw new DimBaseCmdException("New name contains directory separator");
            }

            // get the parent directory:
            String parentDirName = (String) admObj.getAttrValue(AdmAttrNames.PARENT_DIR_NAME);
            if (parentDirName == null) {
                if (admObj instanceof ItemFile || admObj instanceof DimDirectory) {
                    Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObj);
                    Vector cmdArgs = new Vector();
                    if (admObj instanceof ItemFile) {
                        cmdArgs.add(AdmAttrNames.ITEMFILE_FILENAME);
                    }
                    cmdArgs.add(AdmAttrNames.PARENT_DIR_NAME);
                    cmdArgs.add(AdmAttrNames.FULL_PATH_NAME);
                    cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, cmdArgs);
                    cmd.execute();
                    parentDirName = (String) admObj.getAttrValue(AdmAttrNames.PARENT_DIR_NAME);
                }
                if (parentDirName == null) {
                    parentDirName = "";
                }
            }

            // combine the parent directory name with the rename ID:
            if (parentDirName.length() > 0) {
                while (parentDirName.length() > 0
                        && (parentDirName.charAt(0) == Constants.DIRPATH_SEP || parentDirName.charAt(0) == chSep)) {
                    parentDirName = parentDirName.substring(1, parentDirName.length());
                }
                while (parentDirName.length() > 0
                        && (parentDirName.charAt(parentDirName.length() - 1) == Constants.DIRPATH_SEP || parentDirName.charAt(parentDirName.length() - 1) == chSep)) {
                    parentDirName = parentDirName.substring(0, parentDirName.length() - 1);
                }

            }
            if (parentDirName.length() > 0) {
                param = parentDirName + Constants.DIRPATH_SEP + id;
            } else {
                param = id;
            }
        } else {
            // Renames to file & folder names, as well as ordinary ID & Specification
            // changes for baselines, worksets, users, design parts can come this way.
            if (id != null && id.length() > 0) {
                param = id;
            } else {
                param = "";
            }
        }

        param = CmdUtils.relPathForCmd(param);

        // admObj should always be one of these types if validation has succeeded:
        if (admObj instanceof Customer) {
            String location = (String) getAttrValue(AdmAttrNames.CUSTOMER_LOCATION);
            String project = (String) getAttrValue(AdmAttrNames.CUSTOMER_PROJECT);
            _cmdStr = "UCU " + Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID));
            _cmdStr += " /LOCATION="
                    + Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.CUSTOMER_LOCATION));
            _cmdStr += " /PROJECT="
                    + Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.CUSTOMER_PROJECT));
            _cmdStr += ((id != null) && (id.length() > 0)) ? " /NEW_NAME=" + Encoding.escapeDMCLI(id) : "";
            _cmdStr += ((location != null) && (location.length() > 0)) ? " /NEW_LOCATION=" + Encoding.escapeDMCLI(location) : "";
            _cmdStr += ((project != null) && (project.length() > 0)) ? " /NEW_PROJECT=" + Encoding.escapeDMCLI(project) : "";
        } else if (admObj instanceof DimDirectory) {
            String tmp = CmdUtils.relPathForCmd(admObj.getAdmSpec().getSpec());
            _cmdStr = "MWSD " + Encoding.escapeDMCLI(tmp) + " " + Encoding.escapeDMCLI(param);
            String dirProject = (String) getAttrValue(AdmAttrNames.PROJECT);
            if (dirProject != null) {
                _cmdStr += " /WORKSET=" + Encoding.escapeSpec(dirProject);
            }
            if ((chdocs != null) && (chdocs.length() > 0)) {
                _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
            }
        } else if (admObj instanceof ItemFile) {
            _cmdStr = "SWF " + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()) + " /WS_FILENAME=" + Encoding.escapeDMCLI(param);
            if ((chdocs != null) && (chdocs.length() > 0)) {
                _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
            }
        } else if (admObj instanceof User) {
            _cmdStr = "RREG " + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()) + " /USER=" + Encoding.escapeDMCLI(id);
        } else if ((admObj instanceof Baseline) || (admObj instanceof Item) || (admObj instanceof Part)
                || (admObj instanceof WorkSet)) {
            _cmdStr = "RENAME";
            String spec = admObj.getAdmSpec().toString();
            if (admObj instanceof Baseline) {
                _cmdStr += " /BASELINE=";
            } else if (admObj instanceof Item) {
                _cmdStr += " /ITEMID=";
            } else if (admObj instanceof Part) {
                _cmdStr += " /PART=";
            } else if (admObj instanceof WorkSet) {
                _cmdStr += " /WORKSET=";
            }
            _cmdStr += Encoding.escapeDMCLI(spec);
            _cmdStr += " /NEW_ID=" + Encoding.escapeDMCLI(id);
        }
        return executeRpc();
    }
}

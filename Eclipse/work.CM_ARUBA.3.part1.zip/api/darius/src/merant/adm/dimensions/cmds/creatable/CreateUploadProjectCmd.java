/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.UploadProject;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Upload Project object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Upload project id of the new upload project</dd>
 *  <dt>ID {String}</dt><dd>Name identifier of the new upload project</dd>
 *  <dt>EXTENSION {String}</dt><dd>Extension for the new upload exclusion</dd>
 * </dl></code> <br>
 * <b>Required Role:</b> <code><dl>
 *  <dt>CREATE(Item.class)</dt><dd>Current implementation performs a CI where role checks are performed</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 * @todo Remove hard-coded parameters (like variant)
 */
public class CreateUploadProjectCmd extends RPCExecCmd {
    public CreateUploadProjectCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EXTENSION, true, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String prod = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);

        setAttrValue(CmdArguments.INT_SPEC, prod + ":" + id + ";" + extension);

        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(prod, Product.class)));
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Part.class);
        AdmObject part = AdmHelperCmd.getObject((AdmBaseId) cmd.execute());

        cmd = AdmCmd.getCmd(Creatable.CREATE, Item.class);
        cmd.setAttrValue(AdmAttrNames.PRODUCT_NAME, prod);
        cmd.setAttrValue(AdmAttrNames.VARIANT, "A");
        cmd.setAttrValue(AdmAttrNames.TYPE_NAME, "PROJECT");
        cmd.setAttrValue(AdmAttrNames.REVISION, "1");
        cmd.setAttrValue(CmdArguments.OWNING_PART, part);
        cmd.setAttrValue(CmdArguments.WS_FILE, id);
        cmd.execute();

        AdmResult retResult = new AdmResult("Created upload project \"" + id + "\" successfully");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, UploadProject.class);
        return retResult;
    }
}

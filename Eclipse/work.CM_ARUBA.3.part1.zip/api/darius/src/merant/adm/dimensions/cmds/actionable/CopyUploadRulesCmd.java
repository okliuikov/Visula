/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.UploadExclusion;
import merant.adm.dimensions.objects.UploadInclusion;
import merant.adm.dimensions.objects.UploadProject;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will copy upload inclusions and exclusions of an existing Dimensions upload
 * project to another existing Dimensions upload project.
 * <p>
 * Only those inclusions/exclusions that are not already defined for the target upload project will be copied.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Dimensions upload project the inclusions/exclusions are to be copied from</dd>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions upload project the inclusions/exclusions are to be copied to</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class CopyUploadRulesCmd extends DBIOCmd {
    public CopyUploadRulesCmd() throws AttrException {
        super();
        setAlias(Actionable.COPY_UPLOAD_RULES);
        setAttrDef(new CmdArgDef(CmdArguments.CREATE_PROD_UPLOAD_RULE, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UploadProject) && !(attrValue instanceof Product)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if ((!(attrValue instanceof UploadProject))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        String targetExt = "";
        AdmObject targetProjObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject sourceProjObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        boolean isProdUploadRuleCreation = getAttrValue(CmdArguments.CREATE_PROD_UPLOAD_RULE) == null
                ? false : (Boolean) getAttrValue(CmdArguments.CREATE_PROD_UPLOAD_RULE);

        String targetClone = targetProjObj.getAdmBaseId().toCloneString();
        String sourceClone = sourceProjObj.getAdmBaseId().toCloneString();
        if (targetClone.equals(sourceClone)) {
            throw new DimInvalidAttributeException(
                    "Error: cannot copy upload inclusions/exclusions from an upload project to itself");
        }

        String sourceId = (String) AdmHelperCmd.getAttributeValue(sourceProjObj, AdmAttrNames.ID);
        String sourceProductName = (String) AdmHelperCmd.getAttributeValue(sourceProjObj, AdmAttrNames.PRODUCT_NAME);
        if (sourceProductName.equals(Constants.GLOBAL_PRODUCT) && !sourceId.equals(Constants.GLOBAL_ID)) {
            sourceProductName = sourceId;
            sourceId = Constants.GLOBAL_ID;
        }

        if (isProdUploadRuleCreation) {
            targetExt = (String) AdmHelperCmd.getAttributeValue(sourceProjObj, AdmAttrNames.EXTENSION);
            if (targetExt.indexOf("-") != -1) {
                targetExt = targetExt.substring(0, targetExt.indexOf("-") + 1) + targetProjObj.getAttrValue(AdmAttrNames.ADM_UID);
            } else {
                targetExt = targetExt + "-" + targetProjObj.getAttrValue(AdmAttrNames.ADM_UID);
            }
        } else {
            targetExt = (String) AdmHelperCmd.getAttributeValue(targetProjObj, AdmAttrNames.EXTENSION);
        }

        String targetProjId = "0";
        String targetId = (String) AdmHelperCmd.getAttributeValue(targetProjObj, AdmAttrNames.ID);
        String targetProductName = (String) AdmHelperCmd.getAttributeValue(targetProjObj, AdmAttrNames.PRODUCT_NAME);
        if (!targetProductName.equals(Constants.GLOBAL_PRODUCT) || !targetId.equals(Constants.GLOBAL_ID)) {
            targetProjId = ((Long) AdmHelperCmd.getAttributeValue(targetProjObj, AdmAttrNames.SPEC_UID)).toString();
        }

        if (targetProductName.equals(Constants.GLOBAL_PRODUCT) && !targetId.equals(Constants.GLOBAL_ID)) {
            targetProductName = targetId;
            targetId = Constants.GLOBAL_ID;
        }

        if (targetProjId.equals("0")) {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UPLOADMAN")) {
                throw new DimNoPrivilegeException("ADMIN_UPLOADMAN");
            }
        } else {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", targetProductName)) {
                throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", targetProductName);
            }
        }

        List attrNames = new ArrayList();
        attrNames.add(AdmAttrNames.UPLINC_FORMAT);
        attrNames.add(AdmAttrNames.UPLINC_PART);
        attrNames.add(AdmAttrNames.UPLINC_PART_ID);
        attrNames.add(AdmAttrNames.UPLINC_SEQ);
        attrNames.add(AdmAttrNames.UPLINC_TYPE);
        attrNames.add(AdmAttrNames.UPLINC_EXCLUDE);

        // Get list of inclusions to copy...
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, sourceProjObj, UploadInclusion.class);
        List inclusions = AdmHelperCmd.getObjects((List) cmd.execute(), attrNames);

        // Get list of exclusions to copy...
        cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, sourceProjObj, UploadExclusion.class);
        List exclusions = AdmHelperCmd.getObjects((List) cmd.execute());

        List<String> validItemTypes = getValidItemTypes(targetProductName);
        String itemType = "";
        Long seq = isProdUploadRuleCreation ? 0L : new Long(Integer.MAX_VALUE);
        for (int i = 0; inclusions != null && i < inclusions.size(); i++) {
            if (isProdUploadRuleCreation) {
                seq += 1;
            }
            AdmObject inclusion = (AdmObject) inclusions.get(i);

            // If the product does not have a valid item type which the upload rule has then, ignore that item type while creating
            // upload rule inclusion
            AdmBaseId typeBaseId = (AdmBaseId) inclusion.getAttrValue(AdmAttrNames.UPLINC_TYPE);
            itemType = (typeBaseId != null) ? (String) AdmHelperCmd.getAttributeValue(AdmHelperCmd.getObject(typeBaseId),
                    AdmAttrNames.ID) : null;
            if (isProdUploadRuleCreation && !validItemTypes.contains(itemType)) {
                itemType = "";
            }

            // If the product is the same then pass the part id in else don't...
            String partId = "";
            if (sourceProductName.equals(targetProductName)) {
                partId = (String) inclusion.getAttrValue(AdmAttrNames.UPLINC_PART_ID);
            }

            try {
                cmd = AdmCmd.getCmd(Creatable.CREATE, UploadInclusion.class);
                cmd.setAttrValue(AdmAttrNames.ID, inclusion.getId());
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, targetProjObj);
                cmd.setAttrValue(AdmAttrNames.UPLINC_TYPE,
                        itemType.equals("") ? null : inclusion.getAttrValue(AdmAttrNames.UPLINC_TYPE));
                cmd.setAttrValue(AdmAttrNames.UPLINC_PART, partId);
                cmd.setAttrValue(AdmAttrNames.UPLINC_FORMAT, inclusion.getAttrValue(AdmAttrNames.UPLINC_FORMAT));
                cmd.setAttrValue(AdmAttrNames.UPLINC_SEQ, seq);
                cmd.setAttrValue(AdmAttrNames.EXTENSION, targetExt);
                cmd.setAttrValue(CmdArguments.CREATE_PROD_UPLOAD_RULE, isProdUploadRuleCreation);
                cmd.setAttrValue(AdmAttrNames.UPLINC_EXCLUDE, inclusion.getAttrValue(AdmAttrNames.UPLINC_EXCLUDE));
                cmd.execute();
            } catch (DimAlreadyExistsException dbcEx) {
                // Catch if inclusion already exists so others still can be created.
            }
        }

        for (int i = 0; exclusions != null && i < exclusions.size(); i++) {
            AdmObject exclusion = (AdmObject) exclusions.get(i);
            try {
                cmd = AdmCmd.getCmd(Creatable.CREATE, UploadExclusion.class);
                cmd.setAttrValue(AdmAttrNames.ID, exclusion.getId());
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, targetProjObj);
                cmd.setAttrValue(AdmAttrNames.EXTENSION, targetExt);
                cmd.execute();
            } catch (DimAlreadyExistsException dbcEx) {
                // Catch if exclusion already exists so others still can be created.
            }
        }

        return new AdmResult("Operation completed");
    }

    private List getValidItemTypes(String productId) throws DBIOException, DimBaseException, AdmException {
        DBIO query = null;
        List<String> itemTypes = new ArrayList<String>();

        query = new DBIO(wcm_sql.GET_VALID_ITEM_TYPES_FOR_PRODUCT);
        query.bindInput(productId);
        query.readStart();
        String itemType = "";

        while (query.read()) {
            itemType = query.getString(1);
            if (!itemTypes.contains(itemType)) {
                itemTypes.add(itemType);
            }
        }

        return itemTypes;
    }
}

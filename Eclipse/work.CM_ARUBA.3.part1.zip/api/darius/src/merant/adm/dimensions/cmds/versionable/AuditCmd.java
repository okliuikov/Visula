/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Perform a build audit.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions project(workset) object</dd>
 *  <dt>STAGE_ID {AdmObject}</dt><dd>Specifies the stage name</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>AREA_ID {AdmObject}</dt><dd>Specifies the area name</dd>
 *  <dt>USER_FILE {String}</dt><dd>Contains any output from the audit</dd>
 *  <dt>REPAIR_BUILD_AREA {Boolean}</dt><dd>Determines whether the /FIX qualifier is added to the command</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Pauls
 */
public class AuditCmd extends RPCExecCmd {
    public AuditCmd() throws AttrException {
        super();
        setAlias(Versionable.AUDIT);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_FILTER_ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPAIR_BUILD_AREA, false, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: AuditCmd - Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String stageID = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        String areaID = (String) getAttrValue(AdmAttrNames.AREA_ID);
        String areaFilterID = (String) getAttrValue(AdmAttrNames.AREA_FILTER_ID);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        boolean repairBuildArea = ((Boolean) getAttrValue(AdmAttrNames.REPAIR_BUILD_AREA)).booleanValue();
        StringBuffer sb = new StringBuffer();

        sb.append("AUDIT " + Encoding.escapeSpec(admObj.getAdmSpec().getSpec()));
        sb.append(" /STAGE=" + Encoding.escapeDMCLI(stageID));

        // If we do not specify this then all areas for the stage will be audited
        if (areaID != null && !areaID.equals("")) {
            sb.append(" /AREA=" + Encoding.escapeDMCLI(areaID));
        }

        if (areaFilterID != null && !areaFilterID.equals("")) {
            sb.append(" /FILTER =" + Encoding.escapeDMCLI(areaFilterID));
        }

        if (userFile != null) {
            sb.append(" /USER_FILE=" + Encoding.escapeSpec(userFile));
        }

        if (repairBuildArea) {
            sb.append(" /FIX");
        }

        _cmdStr = sb.toString();

        return executeRpc();
    }
}

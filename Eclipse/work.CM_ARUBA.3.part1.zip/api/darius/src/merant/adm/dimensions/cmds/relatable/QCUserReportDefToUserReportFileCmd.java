/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.UserReportDefinition;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all UserReportFiles used by a UserReportDefinition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT  {AdmObject}</dt><dd>Dimensions primary object (UserReportDefinition)
 * </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS  {Class}</dt><dd>Dimensions child object class
 * (UserReportFile)</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class QCUserReportDefToUserReportFileCmd extends QueryRelsCmd {
    public QCUserReportDefToUserReportFileCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UserReportDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(UserReportFile.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        // TODO: filtering + sorting
        String reportId = admObj.getId();
        String opSys = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.URD_OP_SYS);

        List ret = new ArrayList();

        DBIO query = getDBIO(reportId, opSys, filter);
        query.readStart();

        AdmBaseId reportFileId = null;

        long uid = 0;
        List uids = new ArrayList();

        while (query.read()) {
            uid = query.getLong(1);
            Long Uid = new Long(uid);
            if (!uids.contains(Uid)) {
                uids.add(Uid);
                // NOTE: we put UserReportDefinition's AdmBaseId as scope objects of each
                // UserReportFile. This will enable retrieval of the URF_IS_HEAD_REPORT property
                reportFileId = AdmHelperCmd.newAdmBaseId(uid, admSecClass, admObj.getAdmBaseId());
                QueryRelsCmd.addRelation(ret, relationships, admObj.getAdmBaseId(), reportFileId);
            }
        }

        return ret;
    }

    private DBIO getDBIO(String reportId, String opSys, FilterImpl filter) throws AdmException {
        String reportFileId = "";
        String revision = "";
        String exportFilename = "";
        boolean isHead = false;

        // set up common SQL buffer
        StringBuffer sb = new StringBuffer();
        sb.append("SELECT uri.item_uid, uri.head, cc.obj_id, cc.revision, ca.attr_1 ");
        sb.append("FROM user_report_items uri, cpl_catalogue cc, cpl_attributes ca ");
        sb.append("WHERE uri.report_name=:I1 AND uri.op_sys=:I2 AND uri.item_uid=cc.obj_uid ");
        sb.append("AND cc.obj_uid=ca.obj_uid AND ca.seq=1");

        if (filter != null) {

            // loop over filter criteria
            for (Iterator it = filter.criteria().iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit.getValue() == null) {
                    continue;
                }

                // this criterion is from user_report_items table
                if (crit.getAttrName().equals(AdmAttrNames.URF_IS_HEAD_REPORT)) {
                    sb.append(" AND uri.head = :I3 ");
                    isHead = ((Boolean) crit.getValue()).booleanValue();
                }

                // the criteria below are from cpl_catalogue/cpl_attributes tables
                if (crit.getAttrName().equals(AdmAttrNames.ID)) {
                    sb.append(" AND cc.obj_id = :I4");
                    reportFileId = (String) crit.getValue();
                }

                if (crit.getAttrName().equals(AdmAttrNames.REVISION)) {
                    sb.append(" AND cc.revision = :I5");
                    revision = (String) crit.getValue();
                }

                if (crit.getAttrName().equals(AdmAttrNames.URF_EXPORT_FILENAME)) {
                    sb.append(" AND ca.attr_1 = :I6");
                    exportFilename = (String) crit.getValue();
                }
            }
            if (filter.orders().size() > 0) {
                sb.append(" ORDER BY ");
                boolean first = true;
                for (Iterator it = filter.orders().iterator(); it.hasNext();) {
                    if (first) {
                        first = false;
                    } else {
                        sb.append(", ");
                    }

                    FilterOrder order = (FilterOrder) it.next();
                    if (order.getAttrName().equals(AdmAttrNames.URF_IS_HEAD_REPORT)) {
                        sb.append("2");
                    } else if (order.getAttrName().equals(AdmAttrNames.ID)) {
                        sb.append("3");
                    }
                    if (order.getAttrName().equals(AdmAttrNames.REVISION)) {
                        sb.append("4");
                    } else if (order.getAttrName().equals(AdmAttrNames.URF_EXPORT_FILENAME)) {
                        sb.append("5");
                    }

                    switch (order.getFlags()) {
                    case FilterOrder.ASCENDING:
                        sb.append(" ASC");
                        break;
                    case FilterOrder.DESCENDING:
                        sb.append(" DESC");
                        break;
                    default:
                        break;
                    }
                }
            }
        }

        String queryStr = sb.toString();
        DBIO query = new DBIO(queryStr);
        query.bindInput(reportId);
        query.bindInput(opSys);
        if (filter != null) {
            query.bindInput(isHead ? "Y" : "N");
            query.bindInput(reportId);
            query.bindInput(revision);
            query.bindInput(exportFilename);
        }

        return query;
    }

}

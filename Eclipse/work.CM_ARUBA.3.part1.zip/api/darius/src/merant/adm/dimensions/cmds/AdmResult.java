/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * PVCS:ADMRESULTS JAVA.A-SRC;impulse#1
 * Description:
 * Item ADMRESULTS JAVA.A
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

/**
 * This class should be used as a basis for all
 * extended Adm commands results.
 * @author Floz
 */
public class AdmResult {
    public AdmResult() {
    }

    public AdmResult(String resultMsg) {
        setResultMsg(resultMsg);
    }

    public AdmResult(Object userData) {
        setUserData(userData);
    }

    public AdmResult(String resultMsg, Object userData) {
        setResultMsg(resultMsg);
        setUserData(userData);
    }

    private String _resultMsg;

    protected void setResultMsg(String resultMsg) {
        _resultMsg = resultMsg;
    }

    public String getResultMsg() {
        return _resultMsg;
    }

    private Object _userData;

    protected void setUserData(Object userData) {
        _userData = userData;
    }

    public Object getUserData() {
        return _userData;
    }

    @Override
    public String toString() {
        return getResultMsg();
    }
}

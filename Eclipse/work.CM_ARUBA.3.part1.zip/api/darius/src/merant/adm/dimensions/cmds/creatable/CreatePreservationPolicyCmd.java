/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.PreservationPolicy;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Preservation Policy object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new preservation policy</dd>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Identifier of the product that the new preservation policy will be associated with</dd>
 *  <dt>DEFAULT_RULE {String}</dt><dd>Specifies how the build targets will be preserved</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}</dt><dd>Description of the new preservation policy</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Pauls
 */
public class CreatePreservationPolicyCmd extends RPCExecCmd {
    public CreatePreservationPolicyCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DEFAULT_RULE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        String id = (String) getAttrValue(AdmAttrNames.ID);
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String defaultRule = (String) getAttrValue(AdmAttrNames.DEFAULT_RULE);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String preservationPolicySpec = productName + ":" + id;

        _cmdStr = "DPRP ";
        _cmdStr += Encoding.escapeDMCLI(preservationPolicySpec);
        _cmdStr += " /DEFAULT_RULE=" + defaultRule;
        if (desc != null) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(desc);
        }
        _cmdStr += " /ADD";

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id);
        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, PreservationPolicy.class);
        return retResult;
    }
}

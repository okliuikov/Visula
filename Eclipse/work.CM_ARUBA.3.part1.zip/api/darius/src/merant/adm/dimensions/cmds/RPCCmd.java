/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.util.HashMap;
import java.util.Map;

import merant.adm.dimensions.system.DimSystem;
import merant.adm.session.Session;

/**
 * A cmd that acts as a proxy by providing a session and a place
 * to store arguments. This used to be what got passed across the
 * network (as a properties file or XML-RPC) to msgserver.
 */
public abstract class RPCCmd extends AdmCmd {
    private Session session;
    protected Map<String, String> m_table;

    public void setSession(Session s) {
        session = s;
    }

    /**
     * If session is set then return the session value else get it from the DimSystem.
     * This lets both the old and new code work and also use any session value which
     * was set using the setSession method.
     */
    public Session getSession() {
        if (session != null) {
            return session;
        }
        return (Session) DimSystem.getSystem().getSession(); // get from system

    }

    public RPCCmd() {
        m_table = new HashMap<String, String>();
    }

    public void AddArgument(String key, String value) {
        m_table.put(key, value);
    }

}

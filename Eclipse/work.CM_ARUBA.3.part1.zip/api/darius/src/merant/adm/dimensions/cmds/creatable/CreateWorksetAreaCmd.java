/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Workset Area assignment.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>AREA_ID {FileArea}</dt><dd>area for assignment</dd>
 *  <dt>PROJECT {WorkSet}</dt><dd>workset for assignment</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WS_AREA_OFFSET {String}</dt><dd>The relative location</dd>
 *  <dt>WS_AREA_DEPLOY_BY_DEFAULT {Boolean}</dt><dd>Deploy by default flag</dd>
 *  <dt>WSET_IS_COPY_ON_DEPLOY {Boolean}</dt><dd>Deployment transfer flag, true for copy, false for move</dd>
 *  <dt>WS_AREA_SEQ_NUM {String}</dt><dd>Sequence order of area assignment</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author skorneychuk
 */
public class CreateWorksetAreaCmd extends RPCExecCmd {

    public CreateWorksetAreaCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WS_AREA_OFFSET, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WS_AREA_DEPLOY_BY_DEFAULT, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_IS_COPY_ON_DEPLOY, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WS_AREA_SEQ_NUM, false, -1, Integer.class));
        setAttrDef(new CmdArgDef(CmdArguments.POPULATE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_FILTER_ID, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String areaSpec = (String) getAttrValue(AdmAttrNames.AREA_ID);
        String projSpec = (String) getAttrValue(AdmAttrNames.PROJECT_NAME);
        StringBuffer sb = new StringBuffer();
        sb.append("RAWS ");
        sb.append(Encoding.escapeDMCLI(areaSpec));
        sb.append(" /WORKSET=");
        sb.append(Encoding.escapeDMCLI(projSpec));
        String relLocation = (String) getAttrValue(AdmAttrNames.WS_AREA_OFFSET);
        String areaFilterID = (String) getAttrValue(AdmAttrNames.AREA_FILTER_ID);
        if (relLocation != null) {
            sb.append(" /RELATIVE_LOCATION=");
            sb.append(Encoding.escapeDMCLI(relLocation));
        }
        Boolean dbd = (Boolean) getAttrValue(AdmAttrNames.WS_AREA_DEPLOY_BY_DEFAULT);
        if (dbd != null && dbd.booleanValue()) {
            sb.append(" /DEFAULT");
        } else {
            sb.append(" /NODEFAULT");
        }

        Boolean dtransfer = (Boolean) getAttrValue(AdmAttrNames.WSET_IS_COPY_ON_DEPLOY);
        if (dtransfer != null) {
            if (dtransfer.booleanValue()) {
                sb.append(" /COPY_ON_DEPLOY");
            } else {
                sb.append(" /NOCOPY_ON_DEPLOY");
            }
        }

        Integer seqNum = (Integer) getAttrValue(AdmAttrNames.WS_AREA_SEQ_NUM);
        if (seqNum != null) {
            if (seqNum.intValue() >= 0) {
                sb.append(" /SEQ=" + seqNum);
            } else {
                sb.append(" /SEQ=DEFAULT");
            }
        }

        Boolean populate = (Boolean) getAttrValue(CmdArguments.POPULATE);
        if (populate != null && populate.booleanValue()) {
            sb.append(" /POPULATE"); // /NOPOPULATE is default
        }
        Boolean keep = (Boolean) getAttrValue(CmdArguments.KEEP);
        if (keep != null && !keep.booleanValue()) {
            sb.append(" /NOKEEP"); // /KEEP is default
        }

        if (areaFilterID != null) {
            sb.append(" /FILTER =" + Encoding.escapeDMCLI(areaFilterID));
        }
        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }

}
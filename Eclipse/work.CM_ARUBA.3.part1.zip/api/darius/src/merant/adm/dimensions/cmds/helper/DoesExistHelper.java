/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2002 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.Cmd;

/**
 * This class contains helper methods checking whether various Dimensions objects exist
 */
public class DoesExistHelper {

    /**
     * Checks whether the specified item type group is in use
     * @param itemTypeGroupName
     *            item type group name to check
     * @return true if there is a matching baselinetemplate, false otherwise
     */
    public static boolean itemTypeGroupIsInUse(String itemTypeGroupName, boolean byRelease) throws DimBaseCmdException,
            AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(itemTypeGroupName);

        int sqlNo;
        if (byRelease) {
            sqlNo = wcm_sql.ITMTYPEGRP_INUSE_BYR;
        } else {
            sqlNo = wcm_sql.ITMTYPEGRP_INUSE_BYRT;
        }

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(sqlNo));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified item type group exists
     * @param itemTypeGroupName
     *            item type group name to check
     * @return true if there is a matching group exists, false otherwise
     */
    public static boolean itemTypeGroupExists(String itemTypeGroupName) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(itemTypeGroupName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ITMTYPEGRP_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified release template is in use
     * @param templateId
     *            templateId to check
     * @return true if there is a matching baselin etemplate, false otherwise
     */
    public static boolean releaseTemplateIsInUse(String templateId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(templateId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.RELEASET_INUSE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified release template exists
     * @param templateId
     *            templateId to check
     * @return true if there is a matching baselin etemplate, false otherwise
     */
    public static boolean releaseTemplateExists(String templateId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(templateId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.RELEASET_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified baseline template is in use
     * @param templateId
     *            templateId to check
     * @return true if there is a matching baselin etemplate, false otherwise
     */
    public static boolean baselineTemplateIsInUse(String templateId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(templateId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.BLINET_INUSE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified baseline template exists
     * @param templateId
     *            templateId to check
     * @return true if there is a matching baselin etemplate, false otherwise
     */
    public static boolean baselineTemplateExists(String templateId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(templateId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.BLINET_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified priming relationsip exists
     * @param typeUid
     *            UID of the primable chdoc type
     * @param primedTypeUid
     *            UID of the primed chdoc type
     * @return true if there is a matching priming relatioship, false otherwise
     */
    public static boolean primingExists(long typeUid, long primedTypeUid) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        ArrayList inputs = new ArrayList(2);
        inputs.add(new Long(typeUid));
        inputs.add(new Long(primedTypeUid));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.PRIMING_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified item to item relationship type exists
     * @param relNameUid
     *            UID of the relationship name
     * @param parentTypeUid
     *            UID of the parent item type
     * @param childTypeUid
     *            UID of the child item type
     * @return true if there is a matching item to item relationship type, false otherwise
     */
    public static boolean itemRelTypeExists(long relNameUid, long parentTypeUid, long childTypeUid) throws DimBaseCmdException,
            AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(3);
        inputs.add(new Long(relNameUid));
        inputs.add(new Long(parentTypeUid));
        inputs.add(new Long(childTypeUid));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ITEMRELTYPE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified chdoc relationship name exists
     * @param productName
     *            the product to check
     * @param relName
     *            the name of the relationship to check
     * @return true if there is a product with this name, false otherwise
     */
    public static boolean chdocRelationshipNametExists(String productName, String relName) throws DimBaseCmdException,
            AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productName);
        inputs.add(relName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CHDOC_RELNAME_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified relationship name exists
     * @param relName
     *            the name of the relationship to check
     * @return true if there is a product with this name, false otherwise
     */
    public static boolean relationshipNametExists(String relName) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(relName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.RELNAME_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified product exists
     * @param productName
     *            the name of the product to check
     * @return true if there is a product with this name, false otherwise
     */
    public static boolean productExists(String productName) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CPL_PRODUCT_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified stage exists
     * @param id
     *            the name of the stage to check
     * @return true if there already exists a stage with this id
     */
    public static boolean stageExists(String id) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(id);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.STAGE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified stage reference area exists
     * @return true if there already exists a stage reference area for this node name and directory
     */
    public static boolean buildAreaExists(String networkNode, String directory) throws DimBaseCmdException, AdmObjectException,
            AdmException {

        ArrayList inputs = new ArrayList();
        inputs.add(networkNode);
        inputs.add(directory);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.STAGEREFAREA_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified stage reference area exists
     * @return true if there already exists a stage reference area for this node name and directory
     */
    public static boolean buildAreaExists(String buildAreaId) throws DimBaseCmdException, AdmObjectException, AdmException {

        ArrayList inputs = new ArrayList();
        inputs.add(buildAreaId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.STAGEREFAREA_EXISTS_BY_ID));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified project stage exists
     * @return true if there already exists a project stage for the project and stage
     */
    public static boolean projectStageExists(long projectUID, long stageUID) throws DimBaseCmdException, AdmObjectException,
            AdmException {

        ArrayList inputs = new ArrayList();
        inputs.add(new Long(projectUID));
        inputs.add(new Long(stageUID));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.PROJECT_STAGE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified validset exists
     * @param productName
     *            the name of the product to check
     * @param validsetName
     *            the name of the validset to check
     * @return true if there is a validset with this name in the specified product, false otherwise
     */
    public static boolean validsetExists(String productName, String validsetName) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productName);
        inputs.add(validsetName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CPL_VS_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks if a role already exists
     * @param roleName
     *            the name of the role to check
     * @return true if the specified role exists
     */
    public static boolean roleExists(String roleName) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(roleName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, "SELECT role FROM rm_roles WHERE role=:I1");
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks if a role already exists
     * @param roleName
     *            the name of the role to check
     * @param productName
     *            the product to check
     * @return true if the specified role exists
     */
    public static boolean roleExists(String productName, String roleName) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productName);
        inputs.add(roleName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CPL_ROLE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks if a profile already exists
     * @param profileName
     *            the name of the profile to check
     * @return true if the specified profile exists
     */
    public static boolean profileExists(String profileName) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(profileName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, "SELECT obj_id FROM profile_catalogue WHERE lower(obj_id) = lower(:I1)");
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks if a lifecycle already exists
     * @param lifecycleId
     *            the name of the lifecyle to check
     * @return true if the specified lifecycle exists
     */
    public static boolean lifecycleExists(String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(lifecycleId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CPL_CHECK_LIFECYCLE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks if an object type already exists
     * @param productName
     *            the name of the product to check
     * @param typeName
     *            the name of the type to check
     * @param typeFlag
     *            I,C,P,B,W,U - depenfing on the object type
     * @return true if the specified object type exists
     */
    public static boolean typeExists(String productName, String typeName, String typeFlag) throws DBIOException, DimBaseException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productName);
        inputs.add(typeName);
        inputs.add(typeFlag);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CPL_CHECK_OBJ_TYPE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks if a lifecycle state transition already exists in the specified lifecycle
     * @param lifecycleId
     *            the name of the lifecycle to check
     * @param fromState
     *            the FROM state
     * @param toState
     *            the TO state
     */
    public static boolean transitionExists(String lifecycleId, String fromState, String toState) throws DBIOException,
            DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(lifecycleId);
        inputs.add(fromState);
        inputs.add(toState);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, "SELECT lifecycle_id FROM life_cycles " + "WHERE lifecycle_id = :I1 AND "
                + "doc_status = :I2 AND " + "next_doc_status = :I3");
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists a validset with the specified name in the specified product BUT with
     * a different UID
     * @param vsUid
     *            the UID of an existing validset in the specified product
     * @param productName
     *            the name of the product to check
     * @param validsetName
     *            the name of the validset to check
     * @return true if there is a corresponding validset, false otherwise
     */
    public static boolean otherValidsetExists(long vsUid, String productName, String validsetName) throws DBIOException,
            DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productName);
        inputs.add(validsetName);
        inputs.add(new Long(vsUid));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CPL_CHECK_OTHER_VS_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists a global attribute definition
     * @param attrName
     *            attribute name to check
     * @param attrScope
     *            Dimensions object class defining attribute scope (I,C,B,P,W,U)
     * @return true if there is a corresponding attribute definition
     */
    public static boolean globalAttributeExists(String attrName, String attrScope) throws DBIOException, DimBaseException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(attrName);
        inputs.add(attrScope);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRDEF_CHECK_EXISTS_80));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists a local attribute definition
     * @param attrName
     *            attribute name to check
     * @param typeUid
     *            UID of a Dimensions type
     * @return true if there is a corresponding attribute association
     */
    public static boolean localAttributeExists(String attrName, long typeUid) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(attrName);
        inputs.add(new Long(typeUid));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRDEF_CHECK_LOCAL_EXISTS_80));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists a local attribute definition
     * @param attrNo
     *            attribute number to check
     * @param typeUid
     *            UID of a Dimensions type
     * @return true if there is a corresponding attribute association
     */
    public static boolean localAttributeExists(int attrNo, long typeUid) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(new Long(attrNo));
        inputs.add(new Long(typeUid));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        // this query does not have to change for 8.0 schema!
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRDEF_CHECK_LOCAL_ATTRNO_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists an attribute block
     * @param productName
     *            product name
     * @param blockName
     *            block name
     * @return true if there is a corresponding block attribute
     */
    public static boolean attributeBlockExists(String productName, String blockName) throws DBIOException, DimBaseException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productName);
        inputs.add(blockName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRBLOCK_CHECK_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists an update rules object corresponding to the type
     * @param typeUid
     *            UID of a Dimensions object type
     * @param scope
     *            object type scope
     * @return true if there is a corresponding block attribute
     */
    public static boolean updateRuleObjectExists(long typeUid, String scope) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(new Long(typeUid));
        inputs.add(scope);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_GET_RULE_UID));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists a user report definition
     * @param reportId
     *            user report identifier
     * @param opSys
     *            operating system identifier
     * @return true if there is a corresponding user report definition
     */
    public static boolean userReportDefExists(String reportId, String opSys) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(reportId);
        inputs.add(opSys);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.URD_DOES_EXIST));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists a workset with the given spec
     * @param productId
     *            product identifier
     * @param worksetId
     *            workset identifier
     * @return boolean true/false
     * @throws DBIOException
     * @throws DimBaseException
     * @throws AdmException
     */
    public static boolean worksetExists(String productId, String worksetId) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(productId);
        inputs.add(worksetId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.QUERY_WORKSET_UID));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether there exists a branch with the given name
     * @param branchId
     *            branch identifier
     * @return boolean true/false
     * @throws DBIOException
     * @throws DimBaseException
     * @throws AdmException
     */
    public static boolean branchExists(String branchId) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(branchId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.REPL_IS_BRANCH_VALID));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether a master replication configuration exists
     * @param configId
     *            configuration identifier
     * @param replClass
     *            replication class. @see merant.adm.dimensions.server.core.Constants
     * @return boolean
     * @throws DBIOException
     * @throws DimBaseException
     * @throws AdmException
     */
    public static boolean masterReplConfigExists(String configId, int replClass) throws DBIOException, DimBaseException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(configId);
        inputs.add(new Long(replClass));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.REPL_MASTER_CONFIG_DOES_EXIST));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether a replication configuration exists
     * @param configId
     *            configuration identifier
     * @param replClass
     *            replication class. @see merant.adm.dimensions.server.core.Constants
     * @param revision
     *            configuration revision ('0' - master, otherwise subordinate)
     * @return boolean
     * @throws DBIOException
     * @throws DimBaseException
     * @throws AdmException
     */
    public static boolean replConfigExists(String configId, int replClass, String revision) throws DBIOException, DimBaseException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(configId);
        inputs.add(new Long(replClass));
        inputs.add(revision); // Fix for DEF219641, input as string, not number!

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.REPL_IS_CONFIG_ALREADY_DEFINED));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified lifecycle state exists
     * @param lifecycleId
     *            lifecycle id
     * @param status
     *            lifecycle state id
     * @return true if there already exists a lifecycle state with this id
     */
    public static boolean lifecycleStateExists(String lifecycleId, String status) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(lifecycleId);
        inputs.add(status);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CPL_LC_STATE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified project exists
     * @param projectId
     *            project Id
     * @return true if there already exists a project with this id
     */
    public static boolean projectExists(String projectId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(projectId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.BUILD_PROJECT_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified user exists
     * @param userId
     *            user Id
     * @return true if there already exists a user with this id
     */
    public static boolean userExists(String userId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(userId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.USER_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified build type exists
     * @param buildProjectId
     *            build project Id
     * @return true if there already exists a build project with this id
     */
    public static boolean buildProjectExists(String buildProjectId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(buildProjectId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.BUILD_PROJ_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified network node exists
     * @param netNodeId
     *            name of the network node to check
     * @return true if there already exists a network node with this id
     */
    public static boolean netNodeExists(String netNodeId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(netNodeId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ADMSYS_NETNODE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified change document exists
     * @param chdocId
     *            change document Id
     * @return true if there already exists a change document with this id
     */
    public static boolean changeDocumentExists(String chdocId) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(chdocId);
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CHDOC_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified user list exists
     * @param userName
     *            user name user list is associated to
     * @param userListId
     *            user list Id
     * @return true if there already exists a user list with this id
     */
    public static boolean userListExists(String userName, String userListId) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(userListId);
        inputs.add(userName);
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.USER_LIST_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified change document exist in the specified user list
     * @param userListUid
     *            change document uid
     * @param chdocUid
     *            user list uid
     * @return true if change document exists in the user list
     */
    public static boolean userListContainChangeDocumentExists(long userListUid, long chdocUid) throws DimBaseCmdException,
            AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(new Long(userListUid));
        inputs.add(new Long(chdocUid));
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.CHDOC_EXISTS_IN_USER_LIST));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified file area exists
     * @param areaId
     *            file area ID
     * @return true if there already exists a file area with this ID
     */
    public static boolean fileAreaExists(String areaId) throws DimBaseCmdException, AdmObjectException, AdmException {

        ArrayList inputs = new ArrayList();
        inputs.add(areaId);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.FILEAREA_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    public static boolean fileAreaFilterExists(String id) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(id);
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.FILEAREAFILTER_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    public static boolean fileAreaFilterIsInUse(String id) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(id);
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.FILEAREAFILTER_INUSE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified CM activated list exists
     * @param userName
     *            user name CM activate list is associated to
     * @param userListId
     *            user list Id
     * @return true if there already exists a CM activate list with this id
     */
    public static boolean doesCMActivatedListExist(String userName, String actListId) throws DimBaseCmdException,
            AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(actListId);
        inputs.add(userName);
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.WORKING_CM_LIST_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified IDM activate list exists
     * @param userName
     *            user name IDM activate list is associated to
     * @param userListId
     *            user list Id
     * @return true if there already exists an IDM activate list with this id
     */
    public static boolean doesIDMActivatedListExist(String userName, String actListId) throws DimBaseCmdException,
            AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(actListId);
        inputs.add(userName);
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.WORKING_IDM_LIST_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks whether the specified PersistentReport UID still exists
     * @param uid
     *            PersistentReport UID to check whether it still exists
     * @return true if the PersistentReport of the specified UID still exists
     */
    public static boolean doesPersistentReportExist(long uid) throws DimBaseCmdException, AdmObjectException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(new Long(uid));
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.PERSISTENT_REPORT_DOES_EXIST));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    public static String getFileAreaFiltersWithItemType(String typeName) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        String areaFilterName = "";
        StringBuffer sql = new StringBuffer(
                "SELECT afc.area_filter_id FROM area_filter_catalogue afc, area_filter_rules afr, obj_types ot ");
        sql.append("WHERE afr.type_uid = ot.type_uid AND afc.area_filter_uid = afr.area_filter_uid AND ot.type_name = :I1");
        DBIO query = new DBIO(sql.toString());
        query.bindInput(typeName);
        query.readStart();
        while (query.read()) {
            areaFilterName += query.getString(1);
            areaFilterName += ", ";
        }
        if (areaFilterName.endsWith(", ")) {
            areaFilterName = areaFilterName.substring(0, areaFilterName.length() - 2);
        }
        return areaFilterName;
    }

    public static String getBaselineTemplatesUsingType(String typeName, Class clz) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        String templates = "";
        String sql = "SELECT template_id FROM baseline_templates_def WHERE ";
        if (Item.class.equals(clz)) {
            sql += "item_type=:I1";
        } else if (ChangeDocument.class.equals(clz)) {
            sql += "chdoc_type=:I1";
        } else {
            return templates;
        }
        DBIO query = new DBIO(sql);
        query.bindInput(typeName);
        query.readStart();
        while (query.read()) {
            templates += query.getString(1);
            templates += ", ";
        }
        if (templates.endsWith(", ")) {
            templates = templates.substring(0, templates.length() - 2);
        }
        return templates;
    }

    public static String getReleaseTemplatesUsingType(String typeName) throws DimBaseCmdException, AdmObjectException, AdmException {
        String templates = "";
        String sql = "SELECT template_id FROM release_template WHERE item_type=:I1";
        DBIO query = new DBIO(sql);
        query.bindInput(typeName);
        query.readStart();
        while (query.read()) {
            templates += query.getString(1);
            templates += ", ";
        }
        if (templates.endsWith(", ")) {
            templates = templates.substring(0, templates.length() - 2);
        }
        return templates;
    }

    public static String getItemTypeGroupsUsingType(String typeName) throws DimBaseCmdException, AdmObjectException, AdmException {
        String templates = "";
        String sql = "SELECT item_type_group FROM item_type_groups WHERE item_type=:I1";
        DBIO query = new DBIO(sql);
        query.bindInput(typeName);
        query.readStart();
        while (query.read()) {
            templates += query.getString(1);
            templates += ", ";
        }
        if (templates.endsWith(", ")) {
            templates = templates.substring(0, templates.length() - 2);
        }
        return templates;
    }
}

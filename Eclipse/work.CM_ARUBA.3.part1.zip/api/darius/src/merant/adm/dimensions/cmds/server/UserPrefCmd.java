/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimWrongServerVersionException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will get info about current user preferences using SUP.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PREF_NAMES</dt><dd>List of String objects.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PREF_VALUES</dt><dd>List of String objects corresponding to PREF_NAMES, which will be set.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List of the old user preference values in the order supplied.</dd>
 * </dl></code>
 * @author David Conneely
 */
public class UserPrefCmd extends RPCExecCmd {
    public UserPrefCmd() throws AttrException {
        super();
        setAlias(Server.USER_PREF);
        setAttrDef(new CmdArgDef(CmdArguments.PREF_NAMES, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.PREF_VALUES, false, List.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        // always use "/USER" so no special behaviour for Tool Manager:
        String user = Encoding.escapeSpec(AdmCmd.getCurRootObj(User.class).getId());
        _cmdStr = "SUP /USER=" + user;
        String res;
        try {
            res = executeRpc();
        } catch (DimBaseCmdException e) {
            // rethrow this exception:
            throw new DimWrongServerVersionException("SUP command requires Dimensions 7.1 server");
        }

        Map map = new HashMap();
        int sol = Constants.SERVER_OK.length();
        while (sol < res.length()) {
            int eol = res.indexOf('\n', sol);
            if (eol == -1) {
                eol = res.length();
            }
            String line = res.substring(sol, eol);
            int sep = line.indexOf('=');
            if (sep != -1) {
                map.put(line.substring(0, sep), line.substring(sep + 1));
            }
            sol = eol + 1;
        }

        List names = (List) getAttrValue(CmdArguments.PREF_NAMES);
        List ret = new ArrayList(names.size());
        Iterator it = names.iterator();
        while (it.hasNext()) {
            ret.add(map.get(it.next()));
        }

        List values = (List) getAttrValue(CmdArguments.PREF_VALUES);
        if (values != null && values.size() != 0 && values.size() == names.size()) {
            StringBuffer sb = new StringBuffer();
            sb.append("SUP /USER=");
            sb.append(user);
            sb.append(" /PREFERENCES=(");
            it = names.iterator();
            Iterator itVal = values.iterator();
            while (it.hasNext() && itVal.hasNext()) {
                sb.append(Encoding.escapeSpec((String) it.next()));
                sb.append("=");
                sb.append(Encoding.escapeSpec((String) itVal.next()));
                if (it.hasNext() && itVal.hasNext()) {
                    sb.append(", ");
                }
            }
            sb.append(")");
            _cmdStr = sb.toString();
            try {
                res = executeRpc();
            } catch (DimBaseCmdException e) {
                // rethrow this exception:
                throw new DimWrongServerVersionException("Preference not recognized by Dimensions server.");
            }
        }
        return ret;
    }
}

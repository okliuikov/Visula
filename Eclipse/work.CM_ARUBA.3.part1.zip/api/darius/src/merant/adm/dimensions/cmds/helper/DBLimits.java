/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.helper;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DBLimitsFileNotFoundException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.exception.DimDatabaseConnectException;
import merant.adm.dimensions.exception.DimInvalidPropertyException;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmObjectException;

/**
 * Various database schema limits
 * 
 * @author vadymk
 */
public class DBLimits {
    /**
     * Predefined Oracle-specific DB schema limits.
     */
    private static final DBLimits ORACLE = new DBLimits(DBIO.DBMS_ORACLE);

    /**
     * Predefined MS SQL Server-specific DB schema limits.
     */
    private static final DBLimits MSSQL = new DBLimits(DBIO.DBMS_MSSQL);

    /**
     * Predefined PostgreSQL DB schema limits.
     */
    private static final DBLimits POSTGRESQL = new DBLimits(DBIO.DBMS_POSTGRESQL);

    // property key names for database limits
    private static final String SL_MAX_ATTR_NO = "attribute.maxno";
    private static final String SL_MAX_ATTR_LENGTH = "attribute.maxlength";
    private static final String SL_MAX_ATTR_DISPLAY_LENGTH = "attribute.maxdisplaylength";
    private static final String SL_MAX_VALIDSET_VALUE_LENGTH = "attribute.maxvalidsetvaluelength";

    // property key prefixes corresponding to database types
    private static final String SL_KEY_PREFIX_ORACLE = "dbms.oracle.";
    private static final String SL_KEY_PREFIX_UDB = "dbms.udb.";
    private static final String SL_KEY_PREFIX_MSSQL = "dbms.mssql.";
    private static final String SL_KEY_PREFIX_POSTGRESQL = "dbms.postgresql.";

    private static final String LIMITS_FILE = "/merant/adm/dimensions/cmds/helper/DBLimits.properties";
    private static Properties limitsFile;

    private int maxAttrNo;
    private int maxAttrLength;
    private int maxAttrDisplayLength;
    private int maxValidsetValueLength;

    /**
     * Constructs a DB schema limits object that corresponds to the specified
     * RDBMS type
     * 
     * @param dbType
     *            an identifier of an RDBMS supported by Dimensions
     * @see merant.adm.dimensions.server.dbio.DBIO
     */
    private DBLimits(int dbType) {
        populateLimits(dbType);
    }

    /**
     * Returns the default DB schema limits object that corresponds to the
     * implicit connection.
     * 
     * @return a DB limits object
     */
    public static DBLimits getLimits() throws DimConnectionException {
        int dbType;
        try {
            DBIO dbCtx = new DBIO();
            dbType = dbCtx.getDBType();
        } catch (DBIOException e) {
            dbType = DBIO.DBMS_ERR;
        } catch (DimDatabaseConnectException ddce) {
            dbType = DBIO.DBMS_ERR;
        } catch (DimInvalidPropertyException dipe) {
            dbType = DBIO.DBMS_ERR;
        } catch (AdmObjectException aoe) {
            dbType = DBIO.DBMS_ERR;
        }
        return getLimits(dbType);
    }

    public static DBLimits getLimits(DBIO dbCtx) throws DimConnectionException {
        int dbType;
        try {
            dbType = dbCtx.getDBType();
        } catch (DBIOException e) {
            dbType = DBIO.DBMS_ERR;
        }
        return getLimits(dbType);
    }

    public static DBLimits getLimits(int dbType) {
        DBLimits ret = null;
        if (DBIO.DBMS_ORACLE == dbType) {
            ret = DBLimits.ORACLE;
        } else if (DBIO.DBMS_MSSQL == dbType) {
            ret = DBLimits.MSSQL;
        } else if (DBIO.DBMS_POSTGRESQL == dbType) {
            ret = DBLimits.POSTGRESQL;
        }
        return ret;
    }

    /**
     * Returns the maximum number of attributes supported by this connection
     * 
     * @return a strictly positive integer
     */
    public int getMaxAttrNo() {
        return maxAttrNo;
    }

    /**
     * Returns the maximum length of an attribute value
     * 
     * @return a strictly positive number
     */
    public int getMaxAttrLength() {
        return maxAttrLength;
    }

    /**
     * Returns the maximum display length of an attribute value
     * 
     * @return the maximum display length for attribute definition.
     */
    public int getMaxAttrDisplayLength() {
        return maxAttrDisplayLength;
    }

    /**
     * Returns the maximum validset value display length.
     * 
     * @return the maximum valid set value display length.
     */
    public int getMaxValidsetValueLength() {
        return maxValidsetValueLength;
    }

    /**
     * Loads the DB schema limits corresponding to the requested RDBMS type.
     */
    private void populateLimits(int dbType) {
        if (limitsFile == null) {
            loadLimitsFile();
        }
        String keyPrefix = null;
        switch (dbType) {
        case DBIO.DBMS_ORACLE:
            keyPrefix = SL_KEY_PREFIX_ORACLE;
            break;
        case DBIO.DBMS_MSSQL:
            keyPrefix = SL_KEY_PREFIX_MSSQL;
            break;
        case DBIO.DBMS_POSTGRESQL:
            keyPrefix = SL_KEY_PREFIX_POSTGRESQL;
            break;
        default:
            // DBIO.DBMS_DB2 corresponds to DB/2 v7 for z/OS, and
            // DBIO.DBMS_UDB corresponds to DB/2 UDB, which are unsupported.
            throw new IllegalArgumentException("Invalid DBMS type " + dbType);
        }
        maxAttrNo = DBLimits.getIntProperty(keyPrefix + SL_MAX_ATTR_NO, 56);
        maxAttrLength = DBLimits.getIntProperty(keyPrefix + SL_MAX_ATTR_LENGTH, 128);
        maxAttrDisplayLength = DBLimits.getIntProperty(keyPrefix + SL_MAX_ATTR_DISPLAY_LENGTH, 1978);
        maxValidsetValueLength = DBLimits.getIntProperty(keyPrefix + SL_MAX_VALIDSET_VALUE_LENGTH, 1000);
    }

    /**
     * Loads the properties used by the DB Limits object.
     */
    private static void loadLimitsFile() {
        URL res = DBLimits.class.getResource(LIMITS_FILE);
        if (res == null) {
            throw new DBLimitsFileNotFoundException();
        }
        limitsFile = new Properties();
        try {
            InputStream is = res.openStream();
            limitsFile.load(is);
            is.close();
        } catch (IOException e) {
            Debug.error("darius: cannot load Dimensions schema limits properties from \"" + res + "\"");
            throw new DBLimitsFileNotFoundException(e.getMessage());
        }
    }

    /**
     * This method returns the integer value of a given property.
     * 
     * @param key
     *            The property key.
     */
    private static int getIntProperty(String key, int def) {
        String str = getStringProperty(key, null);
        if (str == null || str.length() == 0) {
            return def;
        }
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /**
     * This method returns the String value of a given property.
     * 
     * @param key
     *            The property key.
     */
    private static String getStringProperty(String key, String def) {
        String str = limitsFile.getProperty(key);
        // only returns an empty string if the default is null or empty
        if (str == null || (str.length() == 0 && def != null)) {
            return def;
        } else {
            return str;
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.File;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will add/import an image revision into the lifecycle image
 * gallery.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions lifecycle object</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename of the lifecycle image.</dd>
 *  <dt>REVISION {String}<dt><dd>lifecycle image revision.</dd>
 * </dl></code><br>
 * <b>Option Arguments: </b> <code><dl>
 *  <dt>REPLACE {Boolean}<dt><dd>If true, then the specified image shall replace the existing image revision</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class UpdateLifecycleImageCmd extends RPCExecCmd {
    public UpdateLifecycleImageCmd() throws AttrException {
        super();
        setAlias(Actionable.UPDATE_LC_IMAGE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REVISION, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPLACE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LifeCycle)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_LIFECYCLEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_LIFECYCLEMAN");
        }

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String lifecycleId = admObj.getId();
        String fileName = (String) getAttrValue(CmdArguments.USER_FILE);
        String revision = (String) getAttrValue(CmdArguments.REVISION);

        boolean bImport = false; // not update

        if (lifecycleId.equals(Constants.STAGE_LIFECYCLE_NAME)) {
            revision = Constants.STAGE_LIFECYCLE_NAME; // YC: delete...jsp title bar will show this.
            try {
                if (imageRevisionExists(new DBIO(false), lifecycleId, revision)) {
                    bImport = true; // update
                }
            } catch (Exception e) {
                Debug.error(e.getMessage(), e);
            }
        } else {
            bImport = ((Boolean) getAttrValue(CmdArguments.REPLACE)).booleanValue();
        }

        // validate arguments
        if (revision != null) {
            revision = revision.trim().toUpperCase();
        }
        if (revision == null || revision.length() == 0) {
            throw new DimInvalidAttributeException("Error: image revision number is not specified.");
        }

        if (fileName != null) {
            fileName = fileName.trim();
        }
        if (fileName == null || fileName.length() == 0) {
            throw new DimInvalidAttributeException("Error: image filename is not specified.");
        }

        File imageFile = new File(fileName);
        if (!imageFile.exists()) {
            throw new DimInvalidAttributeException("Error: image file does not exist.");
        }

        StringBuffer cmdBuf = new StringBuffer("LIFECYCLE ");
        cmdBuf.append(Encoding.escapeDMCLI(lifecycleId));
        if (bImport)
            cmdBuf.append(" /IMPORT_IMAGE ");
        else
            cmdBuf.append(" /ADD_IMAGE ");

        cmdBuf.append(" /FILENAME=").append(Encoding.escapeDMCLI(fileName));
        cmdBuf.append(" /REVISION=").append(Encoding.escapeDMCLI(revision));

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }

    /**
     * Checks if lifecycle image revision already exists
     */
    private boolean imageRevisionExists(DBIO query, String lifecycleId, String revision) throws Exception {
        long imageUid = getImageRevisionUid(query, lifecycleId, revision);
        return (imageUid != 0);
    }

    /**
     * Returns UID of an existing image revision identifier
     */
    private long getImageRevisionUid(DBIO query, String lifecycleId, String revision) throws Exception {
        query.resetMessage(wcm_sql.CPL_QUERY_LC_IMAGE_REV_UID);
        query.bindInput(lifecycleId);
        query.bindInput(revision);

        query.readStart();

        long imageUid = 0;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            imageUid = query.getLong(1);
        }
        query.close(DBIO.DB_DONT_RELEASE);
        return imageUid;
    }
}

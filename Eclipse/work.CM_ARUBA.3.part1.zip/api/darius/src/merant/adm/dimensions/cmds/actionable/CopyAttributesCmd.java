/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will copy attributes of an existing Dimensions object type to
 * the list of attributes currently defined for another existing Dimensions object type.
 * <p>
 * Only those attributes that are not already defined for the target object type will be copied.
 * <p>
 * This command is not supported for User object types. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Dimensions object type the attributes are to be copied from</dd>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object type the attributes are to be copied to</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CopyAttributesCmd extends DBIOCmd {
    public CopyAttributesCmd() throws AttrException {
        super();
        setAlias(Actionable.COPY_ATTRIBUTES);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));

        // this is an internal argument for transcational execution of the command
        // and MUST NOT be used by darius callees
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, false, DBIO.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Type))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if ((!(attrValue instanceof Type))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject toTypeObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        long toTypeUid = ((AdmUidObject) toTypeObj).getAdmUid().getUid();

        List attrs = AdmHelperCmd.getAttributeValues(toTypeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));

        String toProductName = (String) attrs.get(0);
        String toTypeName = (String) attrs.get(1);
        Class toScopeClass = (Class) attrs.get(2);
        String toTypeFlag = TypeUtils.getTypeFlag(toScopeClass);

        if (User.class.equals(toScopeClass)) {
            throw new DimInvalidAttributeException("Error: copying attributes is not supported for user object types");
        }

        if (!DoesExistHelper.typeExists(toProductName, toTypeName, toTypeFlag)) {
            throw new DimAlreadyExistsException("Error: Dimensions " + TypeUtils.getClassName(toScopeClass) + "Type "
                    + toProductName + ":" + toTypeName + " does not exist");
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", toProductName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", toProductName);
        }

        AdmObject fromTypeObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        long fromTypeUid = ((AdmUidObject) fromTypeObj).getAdmUid().getUid();

        attrs = AdmHelperCmd.getAttributeValues(fromTypeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));

        String fromProductName = (String) attrs.get(0);
        String fromTypeName = (String) attrs.get(1);
        Class fromScopeClass = (Class) attrs.get(2);
        String fromTypeFlag = TypeUtils.getTypeFlag(fromScopeClass);

        if (!DoesExistHelper.typeExists(fromProductName, fromTypeName, fromTypeFlag)) {
            throw new DimAlreadyExistsException("Error: Dimensions " + TypeUtils.getClassName(fromScopeClass) + "Type "
                    + fromProductName + ":" + fromTypeName + " does not exist");
        }

        if (!toScopeClass.equals(fromScopeClass)) {
            throw new DimInvalidAttributeException("Error: Dimensions object types " + fromProductName + ":" + fromTypeName
                    + " and " + toProductName + ":" + toTypeName + " must have the same object class");
        }

        if ((toTypeUid == fromTypeUid) || (toProductName.equalsIgnoreCase(fromProductName) && toTypeName.equals(fromTypeName))) {
            throw new DimInvalidAttributeException("Error: cannot copy attributes from Dimensions "
                    + TypeUtils.getClassName(fromScopeClass) + " Type " + fromProductName + ":" + fromTypeName + " to itself");
        }

        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        if (query != null) {
            doCopyTypeAttrs(query, fromTypeFlag, fromTypeUid, toTypeUid);
        } else {
            boolean doCommit = true;
            try {
                query = new DBIO(false);
                doCopyTypeAttrs(query, fromTypeFlag, fromTypeUid, toTypeUid);
            } catch (Exception e) {
                if (query != null) {
                    try {
                        query.rollback();
                    } catch (Exception ex) {
                        Debug.error(ex);
                    }
                    doCommit = false;
                }
                Debug.error(e);
                throw new AdmException(e);
            } finally {
                if (query != null && doCommit) {
                    try {
                        query.commit();
                    } catch (Exception ex) {
                        Debug.error(ex);
                        throw new DimBaseCmdException(ex.toString());
                    }
                }
            }
        }

        // Refresh the server attribute cache
        AdmCmd.getCmd(Server.REFRESH_ATTR_CACHE, toTypeObj).execute();

        return new AdmResult("Operation completed");
    }

    private void doCopyTypeAttrs(DBIO query, String typeFlag, long fromTypeUid, long toTypeUid) throws DBIOException,
            DimBaseException, AdmObjectException {

        SqlUtils.copyTypeAttrs(query, typeFlag, fromTypeUid, toTypeUid);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.resetValidSetFields(query, toTypeUid);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);
    }
}

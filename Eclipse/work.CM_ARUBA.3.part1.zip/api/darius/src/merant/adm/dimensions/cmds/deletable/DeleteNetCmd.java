/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.NetCodeSet;
import merant.adm.dimensions.objects.NetContact;
import merant.adm.dimensions.objects.NetFileSys;
import merant.adm.dimensions.objects.NetInstance;
import merant.adm.dimensions.objects.NetNode;
import merant.adm.dimensions.objects.NetNodeConnection;
import merant.adm.dimensions.objects.NetObject;
import merant.adm.dimensions.objects.NetOpSys;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Network object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class DeleteNetCmd extends RPCExecCmd {
    public DeleteNetCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof NetBaseDatabase)) && (!(attrValue instanceof NetCodeSet))
                    && (!(attrValue instanceof NetContact)) && (!(attrValue instanceof NetFileSys))
                    && (!(attrValue instanceof NetInstance)) && (!(attrValue instanceof NetNode))
                    && (!(attrValue instanceof NetNodeConnection)) && (!(attrValue instanceof NetObject))
                    && (!(attrValue instanceof NetOpSys))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        if (admObj instanceof NetBaseDatabase) {
            AdmObject netInstance = (AdmObject) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.NETBASEDB_INSTANCE);
            String netNode = (String) AdmHelperCmd.getAttributeValue(netInstance, AdmAttrNames.NETINSTANCE_NODE);
            String netInstanceId = (String) AdmHelperCmd.getAttributeValue(netInstance, AdmAttrNames.ID);
            _cmdStr = "DBDB /BDB_NAME=" + Encoding.escapeSpec(admObj.getId()) + " /DB_SERVICE="
                    + Encoding.escapeSpec(netInstanceId) + " /NN_NAME=" + Encoding.escapeSpec(netNode);
        } else if (admObj instanceof NetCodeSet) {
            _cmdStr = "DCST /CDST_NUMBER=" + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        } else if (admObj instanceof NetContact) {
            _cmdStr = "DCO /CO_NAME=" + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        } else if (admObj instanceof NetFileSys) {
            _cmdStr = "DFS /FS_NAME=" + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        } else if (admObj instanceof NetInstance) {
            String netNode = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.NETINSTANCE_NODE);
            String id = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
            _cmdStr = "DINS";
            _cmdStr += " /NN_NAME=" + Encoding.escapeSpec(netNode);
            _cmdStr += " /DB_SERVICE=" + Encoding.escapeSpec(id);
        } else if (admObj instanceof NetNode) {
            _cmdStr = "DNN /NN_NAME=" + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        } else if (admObj instanceof NetNodeConnection) {
            List scopeObjects = AdmHelperCmd.getObjects(admObj.getAdmBaseId().getScopeObjects());
            _cmdStr = "DNC /SERVER_NAME=\"" + ((AdmObject) scopeObjects.get(0)).getAdmSpec().getSpec() + "\"";
            _cmdStr += " /CLIENT_NAME=\"" + ((AdmObject) scopeObjects.get(1)).getAdmSpec().getSpec() + "\"";
            _cmdStr += " /NWO_NAME=\"" + ((AdmObject) scopeObjects.get(2)).getAdmSpec().getSpec() + "\"";
        } else if (admObj instanceof NetObject) {
            _cmdStr = "DNWO /NWO_NAME=" + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        } else if (admObj instanceof NetOpSys) {
            _cmdStr = "DOS /OS_NAME=" + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        }

        return executeRpc();
    }
}

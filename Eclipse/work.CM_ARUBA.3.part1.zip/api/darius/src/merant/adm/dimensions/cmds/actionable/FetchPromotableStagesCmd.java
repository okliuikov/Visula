package merant.adm.dimensions.cmds.actionable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.PcmsPromotableStages;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.helper.IDeploymentViewConstants;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class FetchPromotableStagesCmd extends RPCCmd implements IDeploymentViewConstants {
    public FetchPromotableStagesCmd() throws AttrException {
        super();
        setAlias(Actionable.FETCH_PROMOTABLE_STAGES);

        // int promoteOrDemote, int[] objectUids, int[] projectUids, int[] objectClasses
        setAttrDef(new CmdArgDef(CmdArguments.DEPLOY_RPC_FLAG, false, Integer.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.PROJECT_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.PROJECT_UIDS, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.DEPLOY_RPC_FLAG)) {
            if (attrValue != null) {
                int value = -1;
                try {
                    value = ((Integer) attrValue).intValue();
                } catch (NumberFormatException nfe) {
                }
                if (!(value == Constants.PSOP_DEPLOY || value == Constants.PSOP_DEMOTE || value == Constants.PSOP_PROMOTE || value == Constants.PSOP_ROLL_BACK)) {
                    throw new AttrException("Error: FetchPromotableStagesCmd - the operation value is invalid or out of range!",
                            attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.ADM_OBJECT_LIST)) {
            List list = (List) attrValue;
            for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                Object object = iterator.next();
                if (object == null) {
                    throw new AttrException("Error: FetchPromotableStagesCmd - null in object list is not supported!", attrDef,
                            attrValue);
                } else if (!(object instanceof Item || object instanceof ChangeDocument || object instanceof Baseline)) {
                    throw new AttrException("Error: FetchPromotableStagesCmd - adm object list contains unsupported type!",
                            attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.PROJECT_LIST) && attrValue != null) {
            List list = (List) attrValue;
            for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                Object object = iterator.next();
                if (object == null) {
                    throw new AttrException("Error: FetchPromotableStagesCmd - null in project list is not supported!", attrDef,
                            attrValue);
                } else if (!(object instanceof WorkSet)) {
                    throw new AttrException("Error: FetchPromotableStagesCmd - project list contains wrong type!", attrDef,
                            attrValue);
                }
            }
        } else if (name.equals(CmdArguments.PROJECT_UIDS) && attrValue != null) {
            List list = (List) attrValue;
            for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                Object object = iterator.next();
                if (object == null) {
                    throw new AttrException("Error: FetchPromotableStagesCmd - null in project uids list is not supported!",
                            attrDef, attrValue);
                } else {
                    try {
                        Integer.parseInt(object.toString()); // can be Integer, Long or String.
                    } catch (NumberFormatException nfe) {
                        throw new AttrException("Error: FetchPromotableStagesCmd - project uids list contains illegal value!",
                                attrDef, attrValue);
                    }
                }
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        Boolean traverseChildRequests = (Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS);

        List<AdmObject> admObjects = (List<AdmObject>) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        int[] objectUids = new int[admObjects.size()];
        int[] objectClasses = new int[objectUids.length];
        AdmObject obj;
        for (int i = 0; i < admObjects.size(); i++) {
            obj = admObjects.get(i);
            objectUids[i] = (int) ((AdmUid) obj.getAttrValue(AdmAttrNames.ADM_UID)).getUid();
            if (obj instanceof Item || obj instanceof ItemFile) {
                objectClasses[i] = Constants.ITEM_CLASS;
            } else if (obj instanceof ChangeDocument) {
                objectClasses[i] = Constants.CHDOC_CLASS;
            } else if (obj instanceof Baseline) {
                objectClasses[i] = Constants.BASELINE_CLASS;
            }
        }

        int[] projectUids = new int[objectUids.length];
        WorkSet ws = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        List<AdmObject> projects = (List<AdmObject>) getAttrValue(CmdArguments.PROJECT_LIST);
        List uids = (List) getAttrValue(CmdArguments.PROJECT_UIDS);
        boolean hasProjects = false;
        if (ws != null) {
            int uid = (int) ((AdmUid) ws.getAttrValue(AdmAttrNames.ADM_UID)).getUid();
            for (int i = 0; i < projectUids.length; i++) {
                projectUids[i] = uid;
            }
            hasProjects = true;
        } else if (projects != null && projects.size() > 0) {
            if (projects.size() != objectUids.length) {
                throw new AdmException("Error: FetchPromotableStagesCmd - projects length must equal to the object list's length!");
            }
            for (int i = 0; i < projects.size(); i++) {
                obj = projects.get(i);
                projectUids[i] = (int) ((AdmUid) obj.getAttrValue(AdmAttrNames.ADM_UID)).getUid();
            }
            hasProjects = true;
        } else if (uids != null && uids.size() > 0) {
            if (uids.size() != objectUids.length) {
                throw new AdmException(
                        "Error: FetchPromotableStagesCmd - project uids length must equal to the object list's length!");
            }
            for (int i = 0; i < uids.size(); i++) {
                projectUids[i] = Integer.parseInt(uids.get(i).toString());
            }
            hasProjects = true;
        }
        if (!hasProjects) {
            throw new AdmException("Error: FetchPromotableStagesCmd - project or projects or projectUids must be specified!");
        }

        int flags = 0;
        if (traverseChildRequests != null && traverseChildRequests) {
            flags |= LDAF_TRAVERSE_CHILD_REQUESTS;
        }

        Integer mode = (Integer) getAttrValue(CmdArguments.DEPLOY_RPC_FLAG);
        int rpcFlag = Constants.PSOP_PROMOTE;
        if (mode != null) {
            rpcFlag = mode.intValue();
        }
        Object[] ret = null;
        try {
            PcmsPromotableStages results = getSession().getConnection().rpcPromotableStages(rpcFlag, objectUids, objectClasses,
                    projectUids, flags);
            int reasonCode = results.getReasonCode();
            int[] stageUids = results.getStageUids();
            ret = new Object[2];
            ret[0] = new Integer(reasonCode);
            if (stageUids != null && stageUids.length > 0) {
                String[] stageNames = results.getStageNames();
                List<Stage> stages = new ArrayList<Stage>();
                Stage stage;
                for (int i = 0; i < stageUids.length; i++) {
                    AdmBaseId baseId = AdmCmd.newAdmBaseId(stageUids[i], Stage.class);
                    stage = (Stage) AdmCmd.getObject(baseId, null);
                    stage.setAttrValue(AdmAttrNames.STAGE_ID, stageNames[i]);
                    stages.add(stage);
                }
                ret[1] = stages;
            }
        } catch (IOException ioe) {
            throw new AdmException(ioe);
        }
        return ret;
    }
}
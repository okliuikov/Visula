/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import com.serena.dmnet.RPC;
import com.serena.dmnet.drs.DRSClientIsItemInWset;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will determine if the specified objects are related.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Parent Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_REL_TYPE {RelationshipType}<dt><dd>Relationship type object</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Boolean}<dt><dd>'true', if relationship exists.  'false' otherwise.</dd>
 * </dl></code>
 * @author Floz
 */
public class IsRelatedCmd extends DBIOCmd {
    public IsRelatedCmd() throws AttrException {
        super();
        setAlias(Relatable.IS_RELATED);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_REL_TYPE, false, RelationshipType.class));
    }

    /** @todo Find a way to validate when dependencies exist between arguments */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Item)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject parentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);

        boolean exists = false;
        if (admObj instanceof Item) {
            if (parentObj instanceof WorkSet) {
                DRSClientIsItemInWset drsClientIsItemInWset = new DRSClientIsItemInWset(DRSUtils.getLCNetClntObject());
                drsClientIsItemInWset.setItemUid(((AdmUidObject) admObj).getAdmUid().getUid());
                drsClientIsItemInWset.setWsetUid(((AdmUidObject) parentObj).getAdmUid().getUid());
                DRSQuery drsQuery = new DRSQuery(drsClientIsItemInWset);
                DRSOutputDataExtractor drsOutputDataExtractor = drsQuery.execute();

                if (!drsOutputDataExtractor.isResultEmpty()
                        && drsOutputDataExtractor.isOutputParameterPresent(DRSParams.ITEM_IN_WSET)) {
                    if (drsOutputDataExtractor.getIntValues(DRSParams.ITEM_IN_WSET)[0] == -1) {
                        throw new DRSException("Error during call of DRS function " + DRSClientIsItemInWset.dataRequestId
                                + " via RPC(" + RPC.RPC_DATA_REQUEST + ")");
                    }
                    exists = (drsOutputDataExtractor.getIntValues(DRSParams.ITEM_IN_WSET)[0]) == 1; // 1 = item in workset, 0 = item
                                                                                                    // not in work set, -1 = error.
                }
            }
        }

        return Boolean.valueOf(exists);
    }
}

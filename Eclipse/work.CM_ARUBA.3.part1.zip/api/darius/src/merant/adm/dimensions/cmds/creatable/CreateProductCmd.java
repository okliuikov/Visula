/*
 * Copyright (C) 2001-2003, 2006, 2016, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.SecurityZone;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions product (Define New Product).
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * 	<dt>PRODUCT_NAME {String}<dt><dd>Product name identifier of the new product</dd>
 * 	<dt>VARIANT {String}<dt><dd>Variant of the new product</dd>
 * 	<dt>REVISION {String}<dt><dd>Revision (PCS) for the new product</dd>
 * 	<dt>DESCRIPTION {String}<dt><dd>Description for the new product</dd>
 * 	<dt>PRODUCT_MANAGER {User}<dt><dd>Product Manager for the new product</dd>
 *      <dt>BASED_ON {String}<dt><dd>Product name of an existing product on which the new one is to be based</dd>
 *      <dt>COPY_IPDS {Boolean}<dt>
 *      <dd>
 *         If true, copies IPDs from the BASED_ON_PRODUCT to the new product.<br>
 *         Note: By default, IPDs are not copied to the new product from the BASED_ON_PRODUCT.
 *      </dd>
 *      <dt>COPY_STRUCTURE {Boolean}<dt>
 *      <dd>
 *         If true, copies structure from the BASED_ON_PRODUCT to the new product.<br>
 *         Note: By default, structure is not copied to the new product from the BASED_ON_PRODUCT.
 *      </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 * 	<dt>PARTS_CONTROLLER {User}<dt><dd>Parts Controller for the new product (defaults to same as Product Manager)</dd>
 * 	<dt>CHANGE_MANAGER {User}<dt><dd>Change Manager for the new product (defaults to same as Product Manager)</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 * 	<dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateProductCmd extends RPCExecCmd {
    public CreateProductCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VARIANT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REVISION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT_MANAGER, true, User.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARTS_CONTROLLER, false, User.class));
        setAttrDef(new CmdArgDef(CmdArguments.CHANGE_MANAGER, false, User.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASED_ON, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COPY_IPDS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.COPY_STRUCTURE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTES_STRING, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.SDA_APPLICATION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.SDA_PROCESS, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String productName = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.PRODUCT_NAME));
        String variant = (String) getAttrValue(AdmAttrNames.VARIANT);
        String revision = (String) getAttrValue(AdmAttrNames.REVISION);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        User productManager = (User) getAttrValue(CmdArguments.PRODUCT_MANAGER);
        User partsController = (User) getAttrValue(CmdArguments.PARTS_CONTROLLER);
        User changeManager = (User) getAttrValue(CmdArguments.CHANGE_MANAGER);
        String basedOnProduct = (String) getAttrValue(CmdArguments.BASED_ON);
        boolean copyIPDs = ((Boolean) getAttrValue(CmdArguments.COPY_IPDS)).booleanValue();
        boolean copyStructure = ((Boolean) getAttrValue(CmdArguments.COPY_STRUCTURE)).booleanValue();
        String sdaApplication = (String) getAttrValue(AdmAttrNames.SDA_APPLICATION);
        String sdaProcess = (String) getAttrValue(AdmAttrNames.SDA_PROCESS);

        if (desc == null || desc.length() == 0) {
            throw new DimInvalidAttributeException("Error: A description for the new product must be specified.");
        }

        if (DoesExistHelper.productExists(productName)) {
            throw new DimAlreadyExistsException("Error: Product " + productName + " already exists.");
        }

        setAttrValue(CmdArguments.INT_SPEC, productName);

        StringBuffer sb = new StringBuffer("DNP ");
        sb.append(Encoding.escapeSpec(productName));
        sb.append(" /VARIANT=").append(Encoding.escapeSpec(variant));
        sb.append(" /PCS=").append(Encoding.escapeSpec(revision));
        sb.append(" /DESCRIPTION=").append(Encoding.escapeSpec(desc));
        sb.append(" /PRODUCT_MANAGER=").append(Encoding.escapeSpec(productManager.getId()));
        if (partsController != null) {
            sb.append(" /PARTS_CONTROLLER=").append(Encoding.escapeSpec(partsController.getId()));
        }

        if (changeManager != null) {
            sb.append(" /CHANGE_MANAGER=").append(Encoding.escapeSpec(changeManager.getId()));
        }

        // check if based_on_product was specified
        if (basedOnProduct != null && basedOnProduct.length() != 0) {
            sb.append(" /BASED_ID=").append(Encoding.escapeSpec(basedOnProduct));
        }

        if (copyIPDs) {
            sb.append(" /IPDS");
        }

        if (copyStructure) {
            sb.append(" /STRUCTURE=ALL");
        }

        // check if callee specified user-defined attributes via setAttrDef/setAttrValue combination
        String attrQual = AttributeDefinition.getAttrsCmdStringFromCmd(this);
        if (attrQual != null && attrQual.length() != 0) {
            sb.append(" ");
            sb.append(attrQual);
        } else {
            // check if callee specifed user-defined attributes directly by passing /ATTRIBUTES=(..) string.
            attrQual = (String) getAttrValue(CmdArguments.ATTRIBUTES_STRING);
            if (attrQual != null && attrQual.length() != 0) {
                sb.append(" ");
                sb.append(attrQual);
            }
        }

        if (!StringUtils.isEmpty(sdaApplication)) {
            sb.append(" /SDA_APPLICATION=").append(Encoding.escapeDMCLI(sdaApplication));
        }

        if (!StringUtils.isEmpty(sdaProcess)) {
            sb.append(" /SDA_PROCESS=").append(Encoding.escapeDMCLI(sdaProcess));
        }

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Product.class);

        // ensure that the user's security zone gets updated, so as to
        // include the new product ID if appropriate:
        DimSystem.getSystem().getSessionBean().refreshRootObj(SecurityZone.class);

        return retResult;
    }
}

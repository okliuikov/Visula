/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.File;
import java.io.IOException;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithBody;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will fetch the user report file revision.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object (UserReportFile)</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename to contain the report file.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class FetchReportFileCmd extends RPCExecCmd {
    public FetchReportFileCmd() throws AttrException {
        super();
        setAlias(Actionable.FETCH_REPORT_FILE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UserReportFile)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String fileName = (String) getAttrValue(CmdArguments.USER_FILE);

        long reportFileUid = ((AdmUidObject) admObj).getAdmUid().getUid();

        fileName = StringUtils.adjustValue(fileName, 2000, false);
        if (fileName == null || fileName.length() == 0) {
            throw new DimInvalidAttributeException("Error: the filename the report is to be exported to must be specified.");
        }

        if (!canCreateFile(fileName)) {
            throw new DimBaseCmdException("Error: cannot create file " + fileName);
        }

        int objClass = 42;
        int attrNo = 10005;

        Object ret = fetch_dbfile(reportFileUid, objClass, attrNo, isBinary(fileName), fileName);

        return ret;
    }

    private Object fetch_dbfile(long fileUid, int objClass, int attrNo, boolean binaryMode, String userFilename)
            throws AdmException {

        // * XDATA has replaced the old DATA command
        StringBuffer buff = new StringBuffer("XDATA \"FETCH_DBFILE\" /PARAMETER=(");
        buff.append("CLASS=" + objClass + ", ");
        buff.append("ATTR=" + attrNo + ", ");
        buff.append("UID=" + fileUid + ", ");
        buff.append("USER_FILENAME=" + Encoding.escapeDMCLI(userFilename) + ")");
        this._cmdStr = new String(buff);

        return executeRpc();
    }

    private boolean isBinary(String filename) {
        boolean isText = true;
        try {
            Cmd cmd = AdmCmd.getCmd(WithBody.GET_CONTENT_TYPE);
            cmd.setAttrValue(CmdArguments.FILENAME, filename);
            Boolean ret = (Boolean) cmd.execute();
            if (ret != null) {
                isText = ret.booleanValue();
            }
        } catch (Exception e) {
            Debug.error(e);
        }

        return !isText;
    }

    private boolean canCreateFile(String filename) {
        boolean can = false;
        try {
            File f = new File(filename);
            if (f.exists()) {
                // the filesystem already contains a file with this name - can we write to the file?
                can = f.canWrite();
            } else {
                if (f.createNewFile()) {
                    can = true;
                    f.delete();
                }
            }
        } catch (IOException e) {
            Debug.error(e);
        }

        return can;
    }
}
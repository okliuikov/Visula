/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Moves a whole VM Archive file into the Dimensions Library.
 * 
 * @author Stephen Sitton
 */
public class RPCMoveArchiveFile extends RPCCmd {
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCMoveArchiveFile() throws AdmObjectException, AttrException {
        super();
        setAlias("MoveArchiveFile");
        AddArgument("cmd", "LibOpenRawDelta");
        setAttrDef(new CmdArgDef("library_node", true, "", "Node of the item library", ""));
        setAttrDef(new CmdArgDef("library_name", true, "", "Unidir-name of the item library", ""));
        setAttrDef(new CmdArgDef("filename", true, "", "Unidir-name of the item to be access in the library", ""));
        setAttrDef(new CmdArgDef("obj_spec_uid", true, "", "Item Identifer", ""));
        setAttrDef(new CmdArgDef("user_filename", true, "", "Name of the userfile to copy over", ""));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            boolean ret = getSession().getConnection().rpcMoveArchiveFile((String) getAttrValue("library_node"),
                    (String) getAttrValue("library_name"), (String) getAttrValue("filename"),
                    (String) getAttrValue("obj_spec_uid"), (String) getAttrValue("user_filename"));
            String sret;
            if (ret) {
                sret = Constants.SERVER_OK;
            } else {
                sret = Constants.SERVER_FAIL;
            }

            return sret;

        } catch (AttrException e) {
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

        return null;
    }
}

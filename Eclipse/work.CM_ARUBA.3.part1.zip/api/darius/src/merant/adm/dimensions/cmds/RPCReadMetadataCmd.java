/*
 * Copyright (C) 2012, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import com.serena.dmnet.LCNetClnt;
import com.serena.dmnet.LCNetClnt.RFReadMetaTypes;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Return the metadata from the filepath
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>file path {String}</dt>
 *      <dd>
 * 
 *      </dd>
 *  <dt>metadata type {RFReadMetaTypes}</dt>
 *      <dd>
 * 
 *      </dd>
 * </dl></code> <b>Returns: metadata in string or null</b>
 */
public class RPCReadMetadataCmd extends RPCCmd {

    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCReadMetadataCmd() throws AttrException {
        super();
        setAlias("RPCReadMetadataCmd");
        AddArgument("cmd", "RPCReadMetadataCmd");
        setAttrDef(new CmdArgDef(CmdArguments.FULL_FILEPATH, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.METADATA_TYPE, true, RFReadMetaTypes.class));
        setAttrDef(new CmdArgDef(CmdArguments.AREA_PATH_ONLY, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.FULL_FILEPATH)) {
            String filepath = (String) attrValue;
            if (filepath == null) {
                throw new AttrException("Error: File path is null", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.METADATA_TYPE)) {
            RFReadMetaTypes type = (RFReadMetaTypes) attrValue;
            if (type == null) {
                throw new AttrException("Error: type is null", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimConnectionException, AttrException {
        String result = null;
        try {
            String filepath = (String) getAttrValue(CmdArguments.FULL_FILEPATH);
            RFReadMetaTypes type = (RFReadMetaTypes) getAttrValue(CmdArguments.METADATA_TYPE);
            boolean isAreaOnly = ((Boolean) getAttrValue(CmdArguments.AREA_PATH_ONLY)).booleanValue();

            if (type != RFReadMetaTypes.ROOT && isAreaOnly) {
                throw new AttrException("Error: using of area name for type different from root is not supported");
            }

            LCNetClnt con = getSession().getConnection();
            result = con.rpcRFReadMetadata(filepath, type, isAreaOnly);
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return result;
    }
}
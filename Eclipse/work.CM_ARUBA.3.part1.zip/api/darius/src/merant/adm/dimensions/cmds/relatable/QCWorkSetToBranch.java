/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Branch's related to the WorkSet object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * 
 * @author Floz
 */
public class QCWorkSetToBranch extends QueryRelsCmd {
    public QCWorkSetToBranch() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(Branch.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();

        DBIO query = null;
        long uid = ((WorkSet) admObj).getAdmUid().getUid();

        if (isDefault) {
            if (uid == Constants.GLOBAL_WSET_UID) {
                /** @todo default workset for global workset */
                addRelation(ret, relationships, admObj.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(0, admSecClass, null, AdmHelperCmd.newAdmBaseId("", admSecClass, null, null)));
            } else {
                query = new DBIO(wcm_sql.QUERY_WORKSET_DEFAULT_BRANCH);
                query.bindInput(uid);
                query.readStart();
                if (query.read()) {
                    addRelation(
                            ret,
                            relationships,
                            admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admSecClass, null,
                                    AdmHelperCmd.newAdmBaseId(query.getString(2), admSecClass, null, null)));
                }
            }
        } else {
            if (uid == Constants.GLOBAL_WSET_UID) {
                boolean isQueryNonStream = false;
                if (filter != null && filter.criteria() != null) {
                    Iterator itr = filter.criteria().iterator();
                    while (itr.hasNext()) {
                        FilterCriterion fc = (FilterCriterion) itr.next();
                        if (fc.getAttrName().equals(AdmAttrNames.NON_STREAM_BRANCH_NAME)) {
                            isQueryNonStream = true;
                            break;
                        }
                    }
                }
                if (isQueryNonStream) {
                    query = new DBIO(wcm_sql.QUERY_ALL_NON_STREAM_BRANCHES);
                } else {
                    query = new DBIO(wcm_sql.QUERY_ALL_BRANCHES);
                }
            } else {
                query = new DBIO(wcm_sql.QUERY_WORKSET_BRANCHES);
                query.bindInput(uid);
            }

            query.readStart();
            while (query.read()) {
                addRelation(
                        ret,
                        relationships,
                        admObj.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(query.getLong(1), admSecClass, null,
                                AdmHelperCmd.newAdmBaseId(query.getString(2), admSecClass, null, null)));
            }
        }

        return ret;
    }
}

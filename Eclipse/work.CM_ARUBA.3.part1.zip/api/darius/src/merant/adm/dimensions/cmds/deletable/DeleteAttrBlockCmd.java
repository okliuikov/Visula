/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeBlock;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Attribute Block object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteAttrBlockCmd extends RPCExecCmd {
    public DeleteAttrBlockCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof AttributeBlock)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    /**
     * @return the text description of the result, for example:
     * <pre>
     * SUCCESS: Operation completed
     * Operation completed
     * </pre>
     */
    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final String blockName = admObj.getId();

        String productName = (String) admObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
        if (null == productName) {
            productName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
            if (null == productName) {
                throw new DimBaseCmdException("Error: failed to query block attribute parent product");
            }
        }

        AdmObject typeObj = AdmHelperCmd.getParentType(admObj);
        if (null == typeObj) {
            throw new DimBaseCmdException("Error: failed to query block attribute parent type");
        }
        final String typeName = typeObj.getId();

        Class scopeClass = (Class) typeObj.getAttrValue(AdmAttrNames.PARENT_CLASS);
        if (null == scopeClass) {
            scopeClass = (Class) AdmHelperCmd.getAttributeValue(typeObj, AdmAttrNames.PARENT_CLASS);
            if (null == scopeClass) {
                throw new DimBaseCmdException("Error: failed to query block attribute parent class");
            }
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

         // Construct  OBJATTR command, for example:
         // OBJATTR /DEASSIGN /TYPE=MM "MM743563" /PRODUCT="QLARIUS" /OBJ_CLASS=ITEM /OBJ_TYPE="DAT"

        StringBuffer cmdBuf = new StringBuffer("OBJATTR /DEASSIGN /TYPE=MM ");

        cmdBuf.append(Encoding.escapeDMCLI(blockName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));
        cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(scopeClass));
        cmdBuf.append(" /OBJ_TYPE=").append(Encoding.escapeDMCLI(typeName));

        _cmdStr = cmdBuf.toString();
        String retResult = executeRpc();
        return retResult;
    }
}
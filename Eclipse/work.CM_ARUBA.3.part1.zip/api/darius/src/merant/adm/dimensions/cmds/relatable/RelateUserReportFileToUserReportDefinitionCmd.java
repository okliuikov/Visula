/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.UserReportDefinition;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will assign a UserReportFile to a UserReportDefinition.
 * <p>
 * Moreover, if the URF_IS_HEAD_REPORT attribute of the UserReportFile is set to Boolean.TRUE, then this report file will be marked
 * as a "head" report file, i.e. a report file that runs the report. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {LifeCycle}<dt><dd>Dimensions UserReportFile object</dd>
 *  <dt>ADM_PARENT_OBJECT {Type}<dt><dd>Parent Dimensions UserReportDefinition object </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class RelateUserReportFileToUserReportDefinitionCmd extends DBIOCmd {
    public RelateUserReportFileToUserReportDefinitionCmd() throws AttrException {
        super();
        setAlias("RelateUserReportFileToUserReportDefinitionCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, UserReportFile.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, UserReportDefinition.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UserReportFile)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof UserReportDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPORTMAN")) {
            throw new DimNoPrivilegeException("ADMIN_REPORTMAN");
        }

        validateAllAttrs();

        // Dimensions user report file
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        // Dimensions user report definition
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        List attrs = AdmHelperCmd.getAttributeValues(admParentObj,
                Arrays.asList(new Object[] { AdmAttrNames.ID, AdmAttrNames.URD_OP_SYS }));

        String reportId = (String) attrs.get(0);
        String opSys = (String) attrs.get(1);

        if (!DoesExistHelper.userReportDefExists(reportId, opSys)) {
            throw new DimNotExistsException("Error: user report definition " + reportId + ";" + opSys + " does not exist.");
        }

        attrs = AdmHelperCmd.getAttributeValues(admObj, Arrays.asList(new Object[] { AdmAttrNames.ID, AdmAttrNames.REVISION }));

        String reportFileId = (String) attrs.get(0);
        String revision = (String) attrs.get(1);

        long reportFileUid = getReportFileUid(reportFileId, revision);
        if (reportFileUid == 0) {
            throw new DimNotExistsException("Error: user report file" + reportFileId + ";" + revision + " does not exist.");
        }

        Boolean runsReport = (Boolean) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.URF_IS_HEAD_REPORT);

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            if (!bDeassign) {
                String isHead = Boolean.TRUE.equals(runsReport) ? "Y" : "N";

                if (Boolean.TRUE.equals(runsReport)) {
                    // we are goign to assign a head report, so deassign the previous head report
                    query.resetMessage(wcm_sql.URD_UNSET_HEAD_REPORT);
                    query.bindInput(reportId);
                    query.bindInput(opSys);
                    query.bindInput(reportFileUid);
                    query.write(DBIO.DB_DONT_COMMIT);
                    query.close(DBIO.DB_DONT_RELEASE);
                }
                // first assume that the report file has already been assigned to the report definition
                query.resetMessage(wcm_sql.URD_RESET_HEAD_REPORT);
                query.bindInput(isHead);
                query.bindInput(reportId);
                query.bindInput(opSys);
                query.bindInput(reportFileUid);
                int rowsAffected = query.write(DBIO.DB_DONT_COMMIT);
                query.close(DBIO.DB_DONT_RELEASE);

                if (rowsAffected == 0) {
                    // this means that this report file wasn't previously assigned to the report definition
                    query.resetMessage(wcm_sql.URD_INSERT_HEAD_REPORT);
                    query.bindInput(reportId);
                    query.bindInput(opSys);
                    query.bindInput(reportFileUid);
                    query.bindInput(isHead);
                    rowsAffected = query.write(DBIO.DB_DONT_COMMIT);
                    if (rowsAffected == 0) {
                        throw new DBIOException("Error: failed to assign report file " + reportFileId + ";" + revision
                                + " from report " + reportId + ";" + opSys);
                    }
                    query.close(DBIO.DB_DONT_RELEASE);
                }
            } else {
                // deassign report file from the report definition
                query.resetMessage(wcm_sql.URD_DEASSIGN_REPORT);
                query.bindInput(reportId);
                query.bindInput(opSys);
                query.bindInput(reportFileUid);
                int rowsAffected = query.write(DBIO.DB_DONT_COMMIT);
                if (rowsAffected == 0) {
                    throw new DBIOException("Error: failed to deassign report file " + reportFileId + ";" + revision
                            + " from report " + reportId + ";" + opSys);
                }
                query.close(DBIO.DB_DONT_RELEASE);
            }

            // verify that there is still at least one head report file
            query.resetSQL("SELECT COUNT(*) FROM user_report_items WHERE report_name =:I1 AND op_sys=:I2 AND head='Y'");
            query.bindInput(reportId);
            query.bindInput(opSys);
            query.readStart();
            int headItemCount = 0;
            if (query.read(DBIO.DB_DONT_CLOSE)) {
                headItemCount = query.getInt(1);
            }
            query.close(DBIO.DB_DONT_RELEASE);

            if (headItemCount > 1) {
                throw new DBIOException("Error: there must be exactly one report file to be used for running the report.");
            }
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return new AdmResult("Operation completed");
    }

    private long getReportFileUid(String reportFileId, String revision) throws AdmException {
        long reportUid = 0;
        DBIO query = new DBIO(wcm_sql.URF_QUERY_UID);
        query.bindInput(reportFileId);
        query.bindInput(42);
        query.bindInput(revision);
        query.readStart();
        if (query.read(DBIO.DB_IGNORE_REST)) {
            reportUid = query.getLong(1);
        }
        query.close();
        return reportUid;

    }
}

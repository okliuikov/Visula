/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2004 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Group;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will assign a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ROLE {RoleDefinition}<dt><dd>Dimensions role definition object for this assignment</dd>
 *  <dt>SITE {String}<dt><dd>Allows the request to be delegated to a replication site rather than a specific user (cannot be used with ROLE)</dd>
 *  <dd>You must specify one of the following:</dd>
 *  <dt>USER {User}<dt><dd>Dimensions user object for the assignment if this is a single assignment</dd>
 *  <dt>USER_LIST {User/List}<dt><dd>List of Dimensions user objects for the assignment</dd>
 *  <dt>USER_LIST_IDS {String/List}<dt><dd>List of ID Strings of Dimensions users for the assignment</dd>
 *  <dd>You can also specify:</dd>
 *  <dt>REMOVE_USER_LIST {User/List}<dt><dd>List of users to be removed</dd>
 *  <dt>REMOVE_USER_LIST_IDS {String/List}<dt><dd>List of ID Strings of Dimensions users to be removed</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Part Id to assign role to.</dd>
 *  <dt>VARIANT {String}<dt><dd>Part Variant to assign role to.</dd>
 *  <dt>REAL {Boolean}<dt><dd>If true assigns role as Real else as Candidate</dd>
 *  <dt>CAPABILITY {String}<dt><dd>Capability for this assignment, S, L or P</dd>
 *  <dt>REPLACE {Boolean}<dt>
 *  <dd>
 *      If true, replaces the existing assignments with the ones
 *      specified.
 *  </dd>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, removes the existing specified assignment<br>
 *      For convenience nested in the Deassign command
 *  </dd>
 *  <dt>REPORT {Boolean}<dt>
 *  <dd>
 *      If true, only reports the affect the assign would make<br>
 *  </dd>
 *  <dt>WORKSET {WorkSet}<dt><dd>Assigning a role to a particular WorkSet</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class AssignCmd extends RPCExecCmd {
    public AssignCmd() throws AttrException {
        super();
        setAlias(Assignable.ASSIGN);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VARIANT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ROLE, true, RoleDefinition.class));
        setAttrDef(new CmdArgDef(CmdArguments.SITE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REAL, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CAPABILITY, false, Constants.CAP_SECONDARY, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_ITEMS, false, null, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPLACE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPORT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));

        // Add CAPABILITY valid set values
        getAttrDef(CmdArguments.CAPABILITY).addValidSetValue(Constants.CAP_SECONDARY);
        getAttrDef(CmdArguments.CAPABILITY).addValidSetValue(Constants.CAP_LEADER);
        getAttrDef(CmdArguments.CAPABILITY).addValidSetValue(Constants.CAP_PRIMARY);

        // Various ways of specifying the users...
        // setAttrDef(new CmdArgDef(CmdArguments.USER, false, null, User.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER, false, null, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_LIST, false, null, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_LIST_IDS, false, null, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE_USER_LIST, false, null, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE_USER_LIST_IDS, false, null, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ROLE_ASSIGN_GROUP_UID, false, null, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Item)) && (!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof Part))
                    && (!(attrValue instanceof Product))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.USER)) {
            if (attrValue != null) {
                if (!(attrValue instanceof User) && !(attrValue instanceof Group)) {
                    throw new AttrException("Object type is not supported!", attrDef, attrValue);
                }
            }
        }

    }

    private void buildDelegateCmd(AdmObject admObj, AdmObject user, List user_objs, List user_ids, RoleDefinition roleDef,
            String capability, Boolean delegateItems) throws DimBaseCmdException, AdmObjectException, AdmException {
        if (admObj instanceof Item) {
            _cmdStr = "DLGI ";
        } else if (admObj instanceof ChangeDocument) {
            _cmdStr = "DLGC ";
        }

        _cmdStr += Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());
        _cmdStr += " /ROLE=";
        _cmdStr += Encoding.escapeDMCLI((String) roleDef.getAttrValue(AdmAttrNames.ID));
        _cmdStr += " /USER_LIST=(";

        if (user != null) {
            _cmdStr += Encoding.escapeDMCLI(user.getAdmSpec().getSpec());
        } else if (user_objs != null) {
            boolean fNeedComma = false;
            for (int j = 0; j < user_objs.size(); j++) {
                User u = (User) user_objs.get(j);
                if (u != null) {
                    if (fNeedComma) {
                        _cmdStr += ",";
                    }
                    _cmdStr += Encoding.escapeDMCLI(u.getAdmSpec().getSpec());
                    fNeedComma = true;
                }
            }
        } else if (user_ids != null) {
            boolean fNeedComma = false;
            for (int j = 0; j < user_ids.size(); j++) {
                String u = (String) user_ids.get(j);
                if (u != null) {
                    if (fNeedComma) {
                        _cmdStr += ",";
                    }
                    _cmdStr += Encoding.escapeDMCLI(u);
                    fNeedComma = true;
                }
            }
        }

        _cmdStr += ") /CAPABILITY=";
        _cmdStr += Encoding.escapeDMCLI(capability);
        if (admObj instanceof ChangeDocument && delegateItems != null) {
            if (delegateItems.booleanValue()) {
                _cmdStr += " /DELEGATE_ITEMS";
            } else {
                _cmdStr += " /NODELEGATE_ITEMS";
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String partId = (String) getAttrValue(AdmAttrNames.ID);
        String partVar = (String) getAttrValue(AdmAttrNames.VARIANT);
        RoleDefinition roleDef = (RoleDefinition) getAttrValue(CmdArguments.ROLE);
        String site = (String) getAttrValue(CmdArguments.SITE);
        boolean real = ((Boolean) getAttrValue(CmdArguments.REAL)).booleanValue();
        String capability = (String) getAttrValue(CmdArguments.CAPABILITY);
        boolean remove = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();
        boolean replace = ((Boolean) getAttrValue(CmdArguments.REPLACE)).booleanValue();
        boolean report = ((Boolean) getAttrValue(CmdArguments.REPORT)).booleanValue();
        WorkSet workset = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        Boolean delegateItems = (Boolean) getAttrValue(CmdArguments.RELATED_ITEMS);

        AdmObject userOrGroup = (AdmObject) getAttrValue(CmdArguments.USER);
        List user_objs = (List) getAttrValue(CmdArguments.USER_LIST);
        List user_ids = (List) getAttrValue(CmdArguments.USER_LIST_IDS);
        List remove_objs = (List) getAttrValue(CmdArguments.REMOVE_USER_LIST);
        List remove_ids = (List) getAttrValue(CmdArguments.REMOVE_USER_LIST_IDS);
        String roleAssignGroupName = (String) getAttrValue(AdmAttrNames.ROLE_ASSIGN_GROUP_UID);

        if (admObj instanceof Part) {
            _cmdStr = "AUR ";
            _cmdStr += Encoding.escapeDMCLI(userOrGroup.getAdmSpec().getSpec());
            _cmdStr += " /ROLE=";
            _cmdStr += Encoding.escapeDMCLI((String) roleDef.getAttrValue(AdmAttrNames.ID));
            _cmdStr += " /TYPE=";
            _cmdStr += Encoding.escapeDMCLI((real) ? "R" : "C");
            _cmdStr += " /PART=";

            String productName = null;
            String id = null;
            String variant = null;

            List attrNames = new ArrayList(3);
            attrNames.add(AdmAttrNames.PRODUCT_NAME);
            attrNames.add(AdmAttrNames.ID);
            attrNames.add(AdmAttrNames.VARIANT);

            Cmd cmd = AdmCmd.getCmd(WithAttrs.GET, admObj);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
            List attrs = (List) cmd.execute();
            if ((attrs != null) && (attrs.size() > 0)) {
                productName = attrs.get(0) != null ? attrs.get(0).toString() : null;
                id = attrs.get(1) != null ? attrs.get(1).toString() : null;
                variant = attrs.get(2) != null ? attrs.get(2).toString() : null;
            }

            String partSpec = productName + ':' + id;
            if (variant != null && variant.length() > 0) {
                partSpec += "." + variant;
            }
            _cmdStr += Encoding.escapeDMCLI(partSpec);

            _cmdStr += " /CAPABILITY=";
            _cmdStr += Encoding.escapeDMCLI(capability);
            if (workset != null) {
                _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(workset.getAdmSpec().getSpec());
            }

            if (remove) {
                _cmdStr += " /DELETE";
            } else {
                _cmdStr += " /ADD";
            }

            if (report) {
                _cmdStr += " /REPORT";
            }
        } else if (admObj instanceof Product) {
            _cmdStr = "AUR ";
            if (roleAssignGroupName != null && roleAssignGroupName.length() > 0) {
                // remove role assigned to a group
                _cmdStr += Encoding.escapeDMCLI(roleAssignGroupName);
            } else {
                // remove role assigned to a user
                _cmdStr += Encoding.escapeDMCLI(userOrGroup.getAdmSpec().getSpec());
            }
            _cmdStr += " /ROLE=";
            _cmdStr += Encoding.escapeDMCLI((String) roleDef.getAttrValue(AdmAttrNames.ID));
            _cmdStr += " /TYPE=";
            _cmdStr += Encoding.escapeDMCLI((real) ? "R" : "C");
            _cmdStr += " /PART=";

            String productName = admObj.getId();
            String partSpec = productName + ':' + partId;
            if (partVar != null && partVar.length() > 0) {
                partSpec += "." + partVar;
            } else if (partId.indexOf(".") != -1) {
                partSpec += "."; // If variant is not specified and if the part ID contains "." then we add a trailing "." to
                                 // indicate that the "." in the part ID is not the variant.
            }
            _cmdStr += Encoding.escapeDMCLI(partSpec);

            _cmdStr += " /CAPABILITY=";
            _cmdStr += Encoding.escapeDMCLI(capability);
            if (workset != null) {
                _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(workset.getAdmSpec().getSpec());
            }

            if (remove) {
                _cmdStr += " /DELETE";
            } else {
                _cmdStr += " /ADD";
            }

            if (report) {
                _cmdStr += " /REPORT";
            }
        } else if (admObj instanceof ChangeDocument) {
            String o = null;

            if ((roleDef == null) && (site != null)) {
                _cmdStr = "DLGC ";
                _cmdStr += Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());
                _cmdStr += " /SITE=";
                _cmdStr += Encoding.escapeDMCLI(site);

                if (remove) {
                    _cmdStr += " /DELETE";
                } else if (replace) {
                    _cmdStr += " /REPLACE";
                } else {
                    _cmdStr += " /ADD";
                }

                if (delegateItems.booleanValue()) {
                    _cmdStr += " /DELEGATE_ITEMS";
                } else {
                    _cmdStr += " /NODELEGATE_ITEMS";
                }

                if (workset != null) {
                    _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(workset.getAdmSpec().getSpec());
                }

                o = executeRpc();
            } else {
                if ((userOrGroup != null) || (user_objs != null && user_objs.size() != 0)
                        || (user_ids != null && user_ids.size() != 0)) {
                    buildDelegateCmd(admObj, userOrGroup, user_objs, user_ids, roleDef, capability, delegateItems);

                    if (remove) {
                        _cmdStr += " /DELETE";
                    } else if (replace) {
                        _cmdStr += " /REPLACE";
                    } else {
                        _cmdStr += " /ADD";
                    }
                }

                if ((remove_objs != null && remove_objs.size() != 0) || (remove_ids != null && remove_ids.size() != 0)) {
                    // Remove last since it might be removed from your list...

                    buildDelegateCmd(admObj, null, remove_objs, remove_ids, roleDef, capability, delegateItems);

                    _cmdStr += " /DELETE";
                }

                if (workset != null) {
                    _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(workset.getAdmSpec().getSpec());
                }

                o = executeRpc();
            }

            return o;
        } else if (admObj instanceof Item) {
            String o = null;

            if ((userOrGroup != null) || (user_objs != null && user_objs.size() != 0) || (user_ids != null && user_ids.size() != 0)) {
                buildDelegateCmd(admObj, userOrGroup, user_objs, user_ids, roleDef, capability, delegateItems);

                if (remove) {
                    _cmdStr += " /DELETE";
                } else if (replace) {
                    _cmdStr += " /REPLACE";
                } else {
                    _cmdStr += " /ADD";
                }

                o = executeRpc();
            }

            if ((remove_objs != null && remove_objs.size() != 0) || (remove_ids != null && remove_ids.size() != 0)) {
                // Remove last since it might be removed from your list...

                buildDelegateCmd(admObj, null, remove_objs, remove_ids, roleDef, capability, delegateItems);

                _cmdStr += " /DELETE";

                o = executeRpc();
            }

            return o;
        }

        // Execute command and if successful
        // Remove any cached role values
        String ret = executeRpc();
        Object key = null;
        Object value = null;
        List removeKeys = new ArrayList();
        List keys = getCache().getKeys();
        for (int i = 0; i < keys.size(); i++) {
            key = keys.get(i);
            if (key == null) {
                continue;
            }

            if (key instanceof List) {
                if (((List) key).size() > 0) {
                    value = ((List) key).get(0);
                    if ((value != null) && (value instanceof String)) {
                        if (value.equals(Constants.HAS_ROLE_CACHE_KEY) || value.equals(Constants.HAS_ANY_ROLE_CACHE_KEY)) {
                            removeKeys.add(key);
                        }
                    }
                }
            } else if (key instanceof String) {
                if (((String) key).startsWith(Constants.IS_TOOL_MANAGER_CACHE_KEY)) {
                    removeKeys.add(key);
                }
            }
        }

        for (int i = 0; i < removeKeys.size(); i++) {
            getCache().remove(removeKeys.get(i));
        }

        // Remove any caching from
        // within the user objects
        if (userOrGroup != null) {
            userOrGroup.setAttrValue(Constants.HAS_ROLE_CACHE_KEY, null);
        }

        if (user_objs != null) {
            for (int i = 0; i < user_objs.size(); i++) {
                ((AdmObject) user_objs.get(i)).setAttrValue(Constants.HAS_ROLE_CACHE_KEY, null);
            }
        }

        if (remove_objs != null) {
            for (int i = 0; i < remove_objs.size(); i++) {
                ((AdmObject) remove_objs.get(i)).setAttrValue(Constants.HAS_ROLE_CACHE_KEY, null);
            }
        }

        // And out of paranoia - remove from the current user as well
        getCurRootObj(User.class).setAttrValue(Constants.HAS_ROLE_CACHE_KEY, null);

        // YC: to fix DEF51250
        if (ret != null && ret instanceof String) {
            String retMsg = ret;
            final String duCompleted = "Operation completed\nOperation completed";
            if (retMsg.endsWith(duCompleted)) {
                ret = retMsg.substring(0, retMsg.indexOf(duCompleted) + 19);
            }
        }

        return ret;
    }
}

/*
 * Copyright 2001-2003, 2010 Serena Software.
 * All rights reserved.
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
package merant.adm.dimensions.cmds.legacy;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.creatable.CreateSchedJobCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ScheduledJob;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will run the legacy deploy to a stage of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {String}<dt><dd>Project name. If not provided, current project is taken</dd>
 *  <dt>COMMENT {String}<dt><dd>Comment</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {Boolean}<dt><dd>Whether child requests should be deployed as well</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 */
public class DeployToStageCmd extends RPCExecCmd {

    public DeployToStageCmd() throws AttrException {
        super();
        setAlias("DeployToStageCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.SCHEDULE_DATETIME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLIENT_TIMEZONE_OFFSET, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLIENT_TIMESTAMP_LABEL, false, String.class));
        // Only used when deploying requests
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.class));
        // Only used when deployment is scheduling
        setAttrDef(new CmdArgDef(CmdArguments.SCHEDULED_JOB, false, ScheduledJob.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Item)) && (!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof Baseline))) {
                throw new AttrException("Error: DeployToStageCmd - object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        String stageID = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        String scheduledOnTime = (String) getAttrValue(CmdArguments.SCHEDULE_DATETIME);
        String clientTZOffset = (String) getAttrValue(CmdArguments.CLIENT_TIMEZONE_OFFSET);
        String clientTimestampLabel = (String) getAttrValue(CmdArguments.CLIENT_TIMESTAMP_LABEL);
        Boolean traverseChildRequests = (Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS);
        StringBuffer sb = new StringBuffer();
        if (admObj instanceof Item) {
            sb.append("DPI ");
        } else if (admObj instanceof ChangeDocument) {
            sb.append("DPR ");
        } else if (admObj instanceof Baseline) {
            sb.append("DPB ");
        }
        sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
        if (stageID != null && stageID.length() > 0) {
            sb.append(" /STAGE=" + Encoding.escapeDMCLI(stageID));
        }
        if (project != null) {
            sb.append(" /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec()));
        }
        if (comment != null && comment.length() > 0) {
            sb.append(" /COMMENT=" + Encoding.escapeDMCLI(comment));
        }
        if (traverseChildRequests != null) {
            if (traverseChildRequests.booleanValue()) {
                sb.append(" /NOCANCEL_TRAVERSE");
            } else {
                sb.append(" /CANCEL_TRAVERSE");
            }
        }
        _cmdStr = sb.toString();

        AdmObject currentJob = (AdmObject) getAttrValue(CmdArguments.SCHEDULED_JOB);
        if (scheduledOnTime != null && scheduledOnTime.length() > 0 && currentJob == null) {
            String jobID = "SchedJob_" + AdmCmd.getCurRootObj(User.class).getId() + "_" + clientTimestampLabel;

            Cmd cmd = AdmCmd.getCmd(Creatable.CREATE_SCHEDULED_JOB, ScheduledJob.class);
            cmd.setAttrValue(AdmAttrNames.ID, jobID);
            cmd.setAttrValue(AdmAttrNames.START_TIME, scheduledOnTime);
            cmd.setAttrValue(AdmAttrNames.REPEAT, ""); // could be changed in future
            cmd.setAttrValue(AdmAttrNames.TIMEZONE, clientTZOffset);
            cmd.setAttrValue(AdmAttrNames.DESCRIPTION, comment);
            String retResult = (String) cmd.execute();

            if (retResult.startsWith(Constants.SERVER_OK)) {
                currentJob = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(jobID, ScheduledJob.class));
                setAttrValue(CmdArguments.SCHEDULED_JOB, currentJob);
            } else {
                return retResult;
            }
        }

        if (currentJob != null) {
            Cmd cmd = AdmCmd.getCmd(Relatable.RELATE_CMD_TO_SCHEDULED_JOB);
            cmd.setAttrValue(AdmAttrNames.ID, currentJob.getAdmSpec().getSpec());
            cmd.setAttrValue(CmdArguments.COMMAND, _cmdStr);
            cmd.setAttrValue(CmdArguments.USER_NAME, AdmCmd.getCurRootObj(User.class).getId());
            String retResult = (String) cmd.execute();

            if (retResult.startsWith(Constants.SERVER_OK)) {
                cmd = AdmCmd.getCmd(Actionable.EDIT_SCHEDULED_JOB);
                cmd.setAttrValue(AdmAttrNames.ID, currentJob.getAdmSpec().getSpec());
                cmd.setAttrValue(AdmAttrNames.STATUS, CreateSchedJobCmd.ACTIVE);
                return cmd.execute();
            } else {
                cmd = AdmCmd.getCmd(Deletable.DELETE_SCHEDULED_JOB);
                cmd.setAttrValue(AdmAttrNames.ID, currentJob.getAdmSpec().getSpec());
                cmd.execute();
                return retResult;
            }
        }
        return executeRpc();
    }
}

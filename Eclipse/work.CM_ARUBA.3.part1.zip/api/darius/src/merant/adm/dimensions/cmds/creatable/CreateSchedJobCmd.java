/**
 */
package merant.adm.dimensions.cmds.creatable;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Locale;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ScheduledJob;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command should create scheduled job.
 * 
 * The command to be executed with this job should be related to the job
 * with RCSJ command.
 * <b>Mandatory Arguments:</b> <code>
 * <dl>
 * <dt>ID {String}</dt><dd>Scheduled Job ID name</dd>
 * <dt>START_TIME {String}</dt><dd>Scheduled Job start time</dd>
 * </dl>
 * </code> <br>
 * <b>Optional Arguments:</b> <code>
 * <dl>
 * <dt>REPEAT {String}</dt><dd>Scheduled Job repeat period</dd>
 * <dt>TIMEZONE {String}</dt><dd>Scheduled Job timezone offset</dd>
 * <dt>DESCRIPTION {String}</dt><dd>Scheduled Job description</dd>
 * <dt>JOB_STATUS {String}</dt><dd>Scheduled Job status {ACTIVE | INACTIVE}</dd>
 * </dl>
 * </code> <br>
 * <b>Returns:</b> <code>
 * <dl>
 * <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl>
 * </code>
 * 
 * @author kberezovchuk
 * 
 */
public class CreateSchedJobCmd extends RPCExecCmd {
    public static final int[] VALID_MINUTES_ARRAY = new int[] { 0, 10, 20, 30, 40, 50, 60 };
    public static final int[] VALID_HOURS_ARRAY = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
    public static final int[] VALID_DAYS_ARRAY = new int[] { 0, 1, 2, 3, 4, 5, 6, 7 };

    public static final String ACTIVE = "ACTIVE";
    public static final String INACTIVE = "INACTIVE";
    public static final String FINISHED = "FINISHED";

    public CreateSchedJobCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE_SCHEDULED_JOB);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.START_TIME, true, String.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.REPEAT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TIMEZONE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STATUS, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (attrValue == null || ((String) attrValue).length() == 0) {
            return;
        }

        if (name.equals(AdmAttrNames.START_TIME)) {
            DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.US); // Format pattern uses US locale, as UI element
                                                                                 // (calendar) uses it
            try {
                df.parse((String) attrValue);
            } catch (ParseException e) {
                throw new AttrException("Error: CreateSchedJobCmd - wrong start time parameter!", attrDef, attrValue);
            }
        } else if (name.equals(AdmAttrNames.REPEAT)) {
            String repeatStr = (String) attrValue;

            int timePart = -1;
            int[] validTimeParts = null;

            int index = -1;
            if ((index = repeatStr.indexOf("MINUTES")) > 1) { // time part should not start from 1 index, even if indexOf() is OK
                try {
                    timePart = Integer.parseInt(repeatStr.substring(0, index).trim());
                    validTimeParts = VALID_MINUTES_ARRAY;
                } catch (NumberFormatException e) {
                }
            } else if ((index = repeatStr.indexOf("HOURS")) > 1) {
                try {
                    timePart = Integer.parseInt(repeatStr.substring(0, index).trim());
                    validTimeParts = VALID_HOURS_ARRAY;
                } catch (NumberFormatException e) {
                }
            } else if ((index = repeatStr.indexOf("DAYS")) > 1) {
                try {
                    timePart = Integer.parseInt(repeatStr.substring(0, index).trim());
                    validTimeParts = VALID_DAYS_ARRAY;
                } catch (NumberFormatException e) {
                }
            } else {
                throw new AttrException("Error: CreateSchedJobCmd - wrong repeat parameter!", attrDef, attrValue);
            }

            if (Arrays.binarySearch(validTimeParts, timePart) < 0) {
                throw new AttrException("Error: CreateSchedJobCmd - wrong repeat parameter!", attrDef, attrValue);
            }
        } else if (name.equals(AdmAttrNames.TIMEZONE)) {
            try {
                Integer.parseInt((String) attrValue);
            } catch (NumberFormatException e) {
                throw new AttrException("Error: CreateSchedJobCmd - wrong timezone offset parameter!", attrDef, attrValue);
            }
        } else if (name.equals(AdmAttrNames.STATUS)) {
            String status = (String) attrValue;
            if (!ACTIVE.equals(status) && !INACTIVE.equals(status)) {
                throw new AttrException("Error: CreateSchedJobCmd - wrong status parameter!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        String jobID = (String) getAttrValue(AdmAttrNames.ID);
        String startTime = (String) getAttrValue(AdmAttrNames.START_TIME);
        String repeat = (String) getAttrValue(AdmAttrNames.REPEAT);
        String timeZoneOffset = (String) getAttrValue(AdmAttrNames.TIMEZONE);
        String description = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String status = (String) getAttrValue(AdmAttrNames.STATUS);

        StringBuffer sb = new StringBuffer("CSJ ");
        sb.append(Encoding.escapeDMCLI(jobID));
        sb.append(" /START_TIME=").append(Encoding.escapeDMCLI(startTime));
        if (repeat != null && repeat.length() > 0) {
            sb.append(" /REPEAT=").append(Encoding.escapeDMCLI(repeat));
        }
        if (timeZoneOffset != null && timeZoneOffset.length() > 0) {
            sb.append(" /TIME_ZONE=").append(Encoding.escapeDMCLI(timeZoneOffset));
        }
        if (description != null && description.length() > 0) {
            sb.append(" /JOB_DESC=").append(Encoding.escapeDMCLI(description));
        }
        if (status != null && status.length() > 0) {
            sb.append(" /JOB_STATUS=").append(Encoding.escapeDMCLI(status));
        }

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ScheduledJob.class);
        return retResult;
    }
}

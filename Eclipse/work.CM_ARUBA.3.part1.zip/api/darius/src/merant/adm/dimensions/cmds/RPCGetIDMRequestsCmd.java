package merant.adm.dimensions.cmds;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

import java.io.IOException;

public class RPCGetIDMRequestsCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCGetIDMRequestsCmd() throws AttrException {
        super();
        setAlias("GetIDMRequests");
        AddArgument("cmd", "GetIDMRequests");
        setAttrDef(new CmdArgDef(CmdArguments.REQUEST_NAMES, true, String[].class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
    }

    @Override
    public int[] execute() throws AdmException {

        try {
            String[] requestNames = ((String[]) getAttrValue(CmdArguments.REQUEST_NAMES));
            return getSession().getConnection().rpcGetIDMRequests(requestNames);
        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

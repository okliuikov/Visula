/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.AttributeBlock;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will assign a LocalAttributeDefinition to a AttributeBlock.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {LocalAttributeDefinition}<dt><dd>Dimensions LocalAttributeDefinition object</dd>
 *  <dt>ADM_PARENT_OBJECT {AttributeBlock}<dt><dd>Parent Dimensions AttributeBlock object class</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class RelateLocalAttrDefToAttrBlockCmd extends RPCExecCmd {
    public RelateLocalAttrDefToAttrBlockCmd() throws AttrException {
        super();
        setAlias("RelateLocalAttrDefToAttrBlockCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, LocalAttributeDefinition.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AttributeBlock.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LocalAttributeDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof AttributeBlock)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {
        validateAllAttrs();

        // Dimensions local attribute definition
        AdmObject attrObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // Dimensions attribute block
        AdmObject attrBlockObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        Integer columnNoObj = (Integer) attrBlockObj.getAttrValue(AdmAttrNames.ATTRBLOCK_ATTR_COLUMN_NO);
        if (columnNoObj == null) {
            throw new DimInvalidAttributeException("Error: attribute column number must be specified");
        }

        int columnNo = columnNoObj.intValue();
        if (columnNo < 0) {
            throw new DimInvalidAttributeException("Error: attribute column number must be >0");
        }

        boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        // get relevant attribute block attributes
        List attrValues = AdmHelperCmd.getAttributeValues(attrBlockObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID }));
        String productName = (String) attrValues.get(0);
        String blockName = (String) attrValues.get(1);

        // get type object
        AdmObject parentType = AdmHelperCmd.getParentType(attrBlockObj);
        if (parentType == null) {
            throw new DimAlreadyExistsException("Error: attribute block " + productName + ":" + blockName
                    + " does not have a parent type");
        }

        long blockTypeUid = ((AdmUidObject) parentType).getAdmUid().getUid();
        attrValues = AdmHelperCmd.getAttributeValues(parentType,
                Arrays.asList(new Object[] { AdmAttrNames.PARENT_CLASS, AdmAttrNames.ID }));
        Class scopeClass = (Class) attrValues.get(0);
        String typeName = (String) attrValues.get(1);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

        // get relevant attribute definition attributes
        attrValues = AdmHelperCmd.getAttributeValues(
                attrObj,
                Arrays.asList(new Object[] { AdmAttrNames.ATTRDEF_TYPE_UID, AdmAttrNames.ID, AdmAttrNames.ATTRDEF_ATTRTYPE }));

        long typeUid = ((Long) attrValues.get(0)).longValue();
        String attrName = (String) attrValues.get(1);
        int attrType = ((Integer) attrValues.get(2)).intValue();

        if (attrType != Constants.ATTR_TYPE_SFMV) {
            throw new DimInvalidAttributeException(
                    "Error: only single-field, multi-value attributes can be assigned to or deassigned from an attribute block");
        }

        if (typeUid != blockTypeUid) {
            throw new DimInvalidAttributeException("Error: attribute block and attribute must be defined in the same type.");
        }

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJATTR /TYPE=\"MM\" /UPDATE ");
        cmdBuf.append(Encoding.escapeDMCLI(blockName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));
        cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(scopeClass));
        cmdBuf.append(" /OBJ_TYPE=").append(Encoding.escapeDMCLI(typeName));

        // This function is invoked particularly for every attribute,
        // therefore /ATTRIBUTES will never contain more than one SM-attribute here
        cmdBuf.append(" /ATTRIBUTES=(").append(Encoding.escapeDMCLI(attrName)).append(")");
        cmdBuf.append(bDeassign ? " /REMOVE" : " /APPEND");

        if (!bDeassign)
            cmdBuf.append(" /ATTRIBUTES_BLOCK_COL_NO=").append(columnNoObj.toString());

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }
}

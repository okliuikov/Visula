/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.assignable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.MailNotificationRule;
import merant.adm.dimensions.objects.MailSubscription;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will subscribe or unsubscribe groups to a mail notification.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * <dt>ADM_OBJECT {AdmObject}<dt><dd>mailNotificationRule to subscribe groups to</dd>
 * <dt>NOTIF_SUBSCRIBERS {List}<dt><dd>Groups to subscribe or unscribe to mail notification</dd>
 * <dt>IS_GROUP_SUB_TO_NOTIF {Boolean}<dt><dd>Flag to determine whether to subcribe or unsubscribe groups to mail notification</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt><dt><dd></dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author yudong cai
 */
public class SubscribeUsersToMailNotifCmd extends RPCExecCmd {

    public SubscribeUsersToMailNotifCmd() throws AttrException {
        super();
        setAlias(Assignable.SUBSCRIBE_USERS_TO_MAILNOTIF);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NOTIF_SUBSCRIBERS, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.IS_USER_SUB_TO_NOTIF, true, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DIGEST, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EXCLUDE_INITIATOR, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_ID, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof MailNotificationRule) && !(attrValue instanceof MailSubscription)) {
                throw new AttrException("SubscribeUsersToMailNotifCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject notif = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List subscribersList = (List) getAttrValue(AdmAttrNames.NOTIF_SUBSCRIBERS);
        Boolean isSubUsers = (Boolean) getAttrValue(AdmAttrNames.IS_USER_SUB_TO_NOTIF);
        Boolean isDigest = (Boolean) getAttrValue(AdmAttrNames.DIGEST);
        Boolean isExcludeInitiator = (Boolean) getAttrValue(AdmAttrNames.EXCLUDE_INITIATOR);

        StringBuffer sb = new StringBuffer();

        // We are subscribing users
        if (isSubUsers.booleanValue()) {
            sb.append("SUB ");
        }
        // We are deassigning groups
        else {
            sb.append("USUB ");
        }

        sb.append(Encoding.escapeSpec(notif.getAdmSpec().getSpec()));

        sb.append(" /USER_LIST=");

        if (subscribersList != null && subscribersList.size() > 0) {
            sb.append("(");
            String name = "";

            for (int i = 0; i < subscribersList.size(); i++) {
                name = (String) subscribersList.get(i);
                if (i > 0) {
                    sb.append(",");
                }
                sb.append(Encoding.escapeSpec(name));
            }
            sb.append(")");
        } else {
            sb.append(Encoding.escapeSpec(""));
        }

        if (isSubUsers.booleanValue() && isDigest != null && isDigest.booleanValue()) {
            sb.append(" /DIGEST");
        }

        if (isSubUsers.booleanValue() && isExcludeInitiator != null && isExcludeInitiator.booleanValue()) {
            sb.append(" /EXCLUDE_INITIATOR");
        }

        String project = (String) getAttrValue(AdmAttrNames.PROJECT_NAME);
        String stage = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        String area = (String) getAttrValue(AdmAttrNames.AREA_ID);
        if (project != null && project.length() > 0) {
            sb.append(" /WORKSET=");
            sb.append(Encoding.escapeDMCLI(project));
        }

        if (stage != null && stage.length() > 0) {
            sb.append(" /STAGE=");
            sb.append(Encoding.escapeDMCLI(stage));
        }

        if (area != null && area.length() > 0) {
            sb.append(" /AREA=");
            sb.append(Encoding.escapeDMCLI(area));
        }

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, User.class);
        return retResult;
    }
}

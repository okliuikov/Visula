/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.IOException;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.TempFileOutputStream;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will action a Dimensions object.
 * <p>
 * This will directly issue an ATTRIBUTES=(...) qualifier if connected to a 7.1 or greater server. Otherwise it falls back to
 * issuing a WithAttrs.UPDATE. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>STATUS {String}<dt><dd>Status name for the object to be actioned to</dd>
 *  <dt>COMMENT {String}<dt><dd>Action comment to be associated with the actioned object</dd>
 *  <dt>ACTION_CHECK {Boolean}<dt><dd>If <code>true</code> then only a check will be performed (Change Docs only)</dd>
 * <dt>CLOSURE_CHECK {Boolean}
 * <dt>
 * <dd>If <code>true</code> then only a check whether the specified request can be actioned to the final state in its normal
 * lifecycle (Change Docs only)</dd>
 * <dt>ROLE {RoleDefinition}
 * <dt>
 * <dd>Dimensions role definition object for this assignment</dd>
 * <dt>USER_LIST {User/List}
 * <dt>
 * <dd>List of Dimensions user objects for the assignment</dd>
 * <dt>REMOVE_USER_LIST {User/List}
 * <dt>
 * <dd>List of users to have assignments removed</dd>
 * <dt>ITEM_FILTER {String}
 * <dt>
 * <dd>Partial item specification for item actioning (Baseline only)</dd>
 * <dt>BRANCH {Boolean}
 * <dt>
 * <dd>If <code>false</code> then trunk items will be actioned (Baseline only)</dd>
 * <dt>PROJECT {String}
 * <dt>
 * <dd>Project to be used to find the item. If not supplied, current project is taken</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class ActionCmd extends RPCExecCmd {
    private boolean _execution = false;
    private TempFileOutputStream _ts = null;

    public ActionCmd() throws AttrException {
        super();
        setAlias(Actionable.ACTION);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.STATUS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ACTION_CHECK, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLOSURE_CHECK, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.ROLE, false, RoleDefinition.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE_USER_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.ITEM_FILTER, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCH, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, false, String.class));
    }

    @Override
    public void finalize() throws IOException {
        if (_ts != null) {
            _ts.close();
        }
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Baseline)) && (!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof Item))
                    && (!(attrValue instanceof WorkSet))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    public void buildCmd(AdmObject admObj, String status) throws AdmObjectException {
        if (admObj instanceof Baseline) {
            _cmdStr = "ABL";
        } else if (admObj instanceof ChangeDocument) {
            _cmdStr = "AC";
        } else if (admObj instanceof Item) {
            _cmdStr = "AI";
        } else if (admObj instanceof WorkSet) {
            _cmdStr = "AWS";
        }

        _cmdStr += " " + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());

        if ((status != null) && (status.length() > 0)) {
            _cmdStr += " /STATUS=\"" + status + "\"";
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String status = (String) getAttrValue(CmdArguments.STATUS);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        Boolean action_check = (Boolean) getAttrValue(CmdArguments.ACTION_CHECK);
        Boolean closure_check = (Boolean) getAttrValue(CmdArguments.CLOSURE_CHECK);
        RoleDefinition role = (RoleDefinition) getAttrValue(CmdArguments.ROLE);
        List userList = (List) getAttrValue(CmdArguments.USER_LIST);
        List removeUserList = (List) getAttrValue(CmdArguments.REMOVE_USER_LIST);
        String itemFilter = (String) getAttrValue(CmdArguments.ITEM_FILTER);
        Boolean branch = (Boolean) getAttrValue(CmdArguments.BRANCH);
        String project = (String) getAttrValue(AdmAttrNames.PROJECT);

        buildCmd(admObj, status);

        if ((admObj instanceof Baseline) && (itemFilter != null) && (itemFilter.length() > 0)) {
            _cmdStr += " /ITEM_FILTER=" + Encoding.escapeDMCLI(itemFilter);
            if ((branch != null) && (branch.booleanValue())) {
                _cmdStr += " /LATEST";
            } else {
                _cmdStr += " /TRUNK";
            }
        }

        if (admObj instanceof ChangeDocument) {
            if ((action_check != null) && action_check.booleanValue()) {
                _cmdStr += " /ACTION_CHECK";
            } else if ((closure_check != null) && closure_check.booleanValue()) {
                _cmdStr += " /CLOSURE_CHECK";
            }
            if (project != null) {
                _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(project);
            }

        }

        if ((comment != null) && (comment.length() > 0)) {
            if (admObj instanceof ChangeDocument) {
                if (_execution) /* For "AC" execution */
                {
                    try {
                        _ts = new TempFileOutputStream();
                        _ts.writeString(comment);
                        _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(_ts.getAbsolutePath());
                    } catch (IOException ioException) {
                        throw new AdmException(ioException);
                    }
                } else {
                    _cmdStr += " /DESCRIPTION=[temporary file name]";
                }
            } else {
                _cmdStr += " /COMMENT=" + Encoding.escapeDMCLI(comment);
            }
        }

        if ((admObj instanceof ItemFile)) {
            if (project != null && project.length() > 0) {
                _cmdStr += " /WORKSET=" + Encoding.escapeSpec(project);
            }
        }

        String attrs = AttributeDefinition.getAttrsCmdStringFromCmd(this);
        if ((attrs != null) && (attrs.length() > 0)) {
            _cmdStr += " " + attrs;
        }
    }

    @Override
    public Object execute() throws AdmException, DimBaseCmdException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        RoleDefinition role = (RoleDefinition) getAttrValue(CmdArguments.ROLE);
        List userList = (List) getAttrValue(CmdArguments.USER_LIST);
        List removeUserList = (List) getAttrValue(CmdArguments.REMOVE_USER_LIST);

        Cmd cmd = null;

        // Now perform any required delegation...
        if ((role != null) && ((userList != null) || (removeUserList != null))) {
            cmd = AdmCmd.getCmd(Assignable.ASSIGN, admObj);
            cmd.setAttrValue(CmdArguments.ROLE, role);
            if (userList != null) {
                cmd.setAttrValue(CmdArguments.USER_LIST, userList);
            }

            if (removeUserList != null) {
                cmd.setAttrValue(CmdArguments.REMOVE_USER_LIST, removeUserList);
            }

            cmd.execute();
        }

        _execution = true;
        String ret = executeRpc();
        _execution = false;

        try {
            if (_ts != null) {
                _ts.close();
                _ts = null;
            }
        } catch (IOException ioException) {
            throw new AdmException(ioException);
        }

        return ret;
    }
}

/**
 *
 */
package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command relates a command string with specified scheduled job,
 * created with CSJ command.
 * 
 * <b>Mandatory Arguments:</b> <code>
 * <dl>
 * <dt>ID {String}</dt><dd>Scheduled Job ID name</dd>
 * <dt>COMMAND {String}</dt><dd>Command string to execute</dd>
 * <dt>USER_NAME {String}</dt><dd>Current user name</dd>
 * </dl>
 * </code> <br>
 * <b>Returns:</b> <code>
 * <dl>
 * <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl>
 * </code>
 * 
 * @author kberezovchuk
 * 
 */
public class RelateToSchedJobCmd extends RPCExecCmd {

    public RelateToSchedJobCmd() throws AttrException {
        super();
        setAlias(Relatable.RELATE_CMD_TO_SCHEDULED_JOB);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMAND, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_NAME, true, String.class));
    }

    @Override
    public Object execute() throws DimBaseException, AdmException {
        validateAllAttrs();

        String jobID = (String) getAttrValue(AdmAttrNames.ID);
        String command = (String) getAttrValue(CmdArguments.COMMAND);
        String user = (String) getAttrValue(CmdArguments.USER_NAME);

        StringBuffer sb = new StringBuffer("RCSJ ");
        sb.append(Encoding.escapeDMCLI(jobID));
        sb.append(" /CMD=").append(Encoding.escapeDMCLI(command));
        sb.append(" /USER=").append(Encoding.escapeDMCLI(user));

        _cmdStr = sb.toString();
        return executeRpc();
    }

}

package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.serena.dmfile.dto.Pair;
import com.serena.dmnet.drs.DRSClientSdaUtils;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DmCfgConstants;
import merant.adm.dimensions.cmds.RPCGetSymbolCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.DefaultDemotionParams;
import merant.adm.dimensions.server.drs.objects.LastPromotionParams;
import merant.adm.dimensions.server.drs.objects.SdaApplication;
import merant.adm.dimensions.server.drs.objects.SdaBaselineDeployLink;
import merant.adm.dimensions.server.drs.objects.SdaComponent;
import merant.adm.dimensions.server.drs.objects.SdaEnvironment;
import merant.adm.dimensions.server.drs.objects.SdaJobLinks;
import merant.adm.dimensions.server.drs.objects.SdaPipeline;
import merant.adm.dimensions.server.drs.objects.SdaProcess;
import merant.adm.dimensions.server.drs.objects.SdaVersion;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.Cmd;

/**
 * Helper functions for work with SDA<br/>
 * Helper functions that <b>use communication with SDA</b> have <b>safe</b> equivalents.<br/>
 * For example, {@link #getApplications()} has safe equivalent {@link #getApplicationsSafe()} that doesn't throw
 * {@link AdmException}.<br/>
 * Other functions (like {@link #hasSdaIntegration()} or {@link #hasProductsMappedToSdaOrCm(BaseDatabase)}) don't have safe
 * equivalents.
 * @author apitukh
 * 
 */
public class SdaIntegrationHelper {

    public static boolean hasSdaIntegration() throws AdmException {
        Cmd getSymbolCmd = AdmCmd.getCmd(RPCGetSymbolCmd.ALIAS);
        getSymbolCmd.setAttrValue(CmdArguments.SYMBOL, DmCfgConstants.DM_SDA_URL);
        String dmSdaUrl = (String) getSymbolCmd.execute();
        return dmSdaUrl != null;
    }

    public static boolean hasSdaIntegrationSafe() {
        try {
            return hasSdaIntegration();
        } catch (AdmException e) {
            Debug.error(e);
        }
        return false;
    }

    public static List<SdaApplication> getApplications() throws AdmException {
        List<SdaApplication> applications = new ArrayList<SdaApplication>();
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetApplications);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getNames().length; i++) {
                applications.add(new SdaApplication(drs.getIds()[i], drs.getNames()[i]));
            }
        }
        return applications;
    }

    public static List<SdaApplication> getApplicationsSafe() {
        try {
            return getApplications();
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaApplication>();
    }

    public static List<SdaApplication> getSortedApplications() throws AdmException {
        List<SdaApplication> applications = SdaIntegrationHelper.getApplications();
        Collections.sort(applications, new Comparator<SdaApplication>() {
            @Override
            public int compare(SdaApplication o1, SdaApplication o2) {
                return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
            }
        });
        return applications;
    }

    public static List<SdaApplication> getSortedApplicationsSafe() {
        try {
            return getSortedApplications();
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaApplication>();
    }

    public static List<SdaEnvironment> getEnvironments() throws AdmException {
        List<SdaEnvironment> environments = new ArrayList<SdaEnvironment>();
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetEnvironments);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getNames().length; i++) {
                environments.add(new SdaEnvironment(drs.getIds()[i], drs.getNames()[i]));
            }
        }
        return environments;
    }

    public static List<SdaEnvironment> getEnvironmentsSafe() {
        try {
            return getEnvironments();
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaEnvironment>();
    }

    public static List<SdaEnvironment> getSortedEnvironmentsSafe() {
        List<SdaEnvironment> envs = SdaIntegrationHelper.getEnvironmentsSafe();
        Collections.sort(envs, new Comparator<SdaEnvironment>() {
            @Override
            public int compare(SdaEnvironment o1, SdaEnvironment o2) {
                return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
            }
        });
        return envs;
    }

    public static List<SdaPipeline> getPipelines() throws AdmException {
        List<SdaPipeline> pipelines = new ArrayList<SdaPipeline>();
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetPipelines);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getNames().length; i++) {
                pipelines.add(new SdaPipeline(drs.getIds()[i], drs.getNames()[i], drs.getEnvNames()[i]));
            }
        }
        return pipelines;
    }

    public static List<SdaPipeline> getPipelinesSafe() {
        try {
            return getPipelines();
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaPipeline>();
    }

    public static List<SdaPipeline> getSortedPipelinesSafe() {
        List<SdaPipeline> pipelines = SdaIntegrationHelper.getPipelinesSafe();
        Collections.sort(pipelines, new Comparator<SdaPipeline>() {
            @Override
            public int compare(SdaPipeline o1, SdaPipeline o2) {
                return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
            }
        });
        return pipelines;
    }

    public static String getApplicationNameById(String applicationId) throws AdmException {
        if (applicationId == null) {
            return null;
        }
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetApplicationNameById);
        drs.setApplicationId(applicationId);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            return drs.getApplicationName();
        }
        return null;
    }

    public static String getApplicationNameByIdSafe(String applicationId) {
        try {
            return getApplicationNameById(applicationId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return null;
    }

    public static String getApplicationNameFromActiveApplications(String applicationId) throws AdmException {
        if (applicationId == null) {
            return null;
        }
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetApplications);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getIds().length; i++) {
                if (drs.getIds()[i].equals(applicationId)) {
                    return drs.getNames()[i];
                }
            }
        }
        return null;
    }

    public static String getApplicationNameFromActiveApplicationsSafe(String applicationId) {
        try {
            return getApplicationNameFromActiveApplications(applicationId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return null;
    }

    public static String getProcessNameFromActiveApplications(String applicationId, String processId) throws AdmException {
        if (applicationId == null || processId == null) {
            return null;
        }
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetApplicationProcesses);
        drs.setApplicationId(applicationId);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getIds().length; i++) {
                if (drs.getIds()[i].equals(processId)) {
                    return drs.getNames()[i];
                }
            }
        }
        return null;
    }

    public static String getProcessNameFromActiveApplicationsSafe(String applicationId, String processId) {
        try {
            return getProcessNameFromActiveApplications(applicationId, processId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return null;
    }

    /**
     * @param baseDatabase
     * @return Pair object where the first boolean is "hasProductsMappedToSda" and the second boolean is "hasProductsMappedToCm"
     * @throws AdmException
     */
    public static Pair<Boolean, Boolean> hasProductsMappedToSdaOrCm(BaseDatabase baseDatabase) throws AdmException {
        Pair<Boolean, Boolean> result = new Pair<Boolean, Boolean>(false, false);

        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, baseDatabase, Product.class);
        // get base identifiers of children
        List baseIds = (List) cmd.execute();

        // convert base identifiers to objects
        List<String> attrNames = new ArrayList<String>();
        attrNames.add(AdmAttrNames.SDA_APPLICATION);
        List<Product> products = AdmCmd.getObjects(baseIds, attrNames);

        for (Product product : products) {
            if (product.getAttrValue(AdmAttrNames.SDA_APPLICATION) != null) {
                result.setFirst(true);
            } else {
                result.setSecond(true);
            }
        }
        return result;
    }

    public static SdaApplication isSdaEnabled(int objectType, String objectId) throws AdmException {
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.IsSdaEnabled);
        drs.setObjectType(objectType);
        drs.setObjectId(objectId);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getApplicationId() != null && drs.getApplicationName() != null) {
            return new SdaApplication(drs.getApplicationId(), drs.getApplicationName());
        }
        return null;
    }

    public static SdaApplication isSdaEnabled(AdmObject admObject) throws AdmException {
        int objectType = -1;
        if (admObject instanceof Item) {
            objectType = 2;
        } else if (admObject instanceof Baseline) {
            objectType = 4;
        } else if (admObject instanceof ChangeDocument) {
            objectType = 8;
        } else {
            throw new IllegalArgumentException("isSdaEnabledSafe function works only with Item, Baseline or ChangeDocument");
        }
        return isSdaEnabled(objectType, admObject.getAdmSpec().getSpec());
    }

    public static SdaApplication isSdaEnabledSafe(int objectType, String objectId) {
        try {
            return isSdaEnabled(objectType, objectId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return null;
    }

    public static SdaApplication isSdaEnabledSafe(AdmObject admObject) {
        try {
            return isSdaEnabled(admObject);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return null;
    }

    public static SdaEnvironment getEnvironment(String stageId, String applicationId) throws AdmException {
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetEnvironment);
        drs.setStageId(stageId);
        drs.setApplicationId(applicationId);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getEnvId() != null && drs.getEnvName() != null) {
            return new SdaEnvironment(drs.getEnvId(), drs.getEnvName());
        }
        return null;
    }

    public static SdaEnvironment getEnvironmentSafe(String stageId, String applicationId) {
        try {
            return getEnvironment(stageId, applicationId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return null;
    }

    public static List<SdaProcess> getProcesses(String applicationId) throws AdmException {
        List<SdaProcess> processes = new ArrayList<SdaProcess>();
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetApplicationProcesses);
        drs.setApplicationId(applicationId);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getNames().length; i++) {
                processes.add(new SdaProcess(drs.getIds()[i], drs.getNames()[i]));
            }
        }
        return processes;
    }

    public static List<SdaProcess> getSortedProcesses(String applicationId) throws AdmException {
        List<SdaProcess> processes = SdaIntegrationHelper.getProcesses(applicationId);
        Collections.sort(processes, new Comparator<SdaProcess>() {
            @Override
            public int compare(SdaProcess o1, SdaProcess o2) {
                return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
            }
        });
        return processes;
    }

    public static List<SdaProcess> getProcessesSafe(String applicationId) {
        try {
            return getProcesses(applicationId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaProcess>();
    }

    public static List<SdaProcess> getSortedProcessesSafe(String applicationId) {
        List<SdaProcess> processes = SdaIntegrationHelper.getProcessesSafe(applicationId);
        Collections.sort(processes, new Comparator<SdaProcess>() {
            @Override
            public int compare(SdaProcess o1, SdaProcess o2) {
                return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
            }
        });
        return processes;
    }

    public static List<SdaComponent> getComponents(String processId) throws AdmException {
        List<SdaComponent> components = new ArrayList<SdaComponent>();
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetProcessComponents);
        drs.setProcessId(processId);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getNames().length; i++) {
                components.add(new SdaComponent(drs.getIds()[i], drs.getNames()[i]));
            }
        }
        return components;
    }

    public static List<SdaComponent> getComponentsSafe(String processId) {
        try {
            return getComponents(processId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaComponent>();
    }

    public static List<SdaComponent> getSortedComponents(String processId) throws AdmException {
        List<SdaComponent> components = SdaIntegrationHelper.getComponents(processId);
        Collections.sort(components, new Comparator<SdaComponent>() {
            @Override
            public int compare(SdaComponent o1, SdaComponent o2) {
                return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
            }
        });
        return components;
    }

    public static List<SdaComponent> getSortedComponentsSafe(String processId) {
        try {
            return getSortedComponents(processId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaComponent>();
    }

    public static List<SdaVersion> getVersions(String componentId) throws AdmException {
        List<SdaVersion> versions = new ArrayList<SdaVersion>();
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetComponentVersions);
        drs.setComponentId(componentId);
        DRSUtils.execute(drs);
        if (drs.hasData() && drs.getNames() != null && drs.getIds() != null) {
            for (int i = 0; i < drs.getNames().length; i++) {
                versions.add(new SdaVersion(drs.getIds()[i], drs.getNames()[i]));
            }
        }
        return versions;
    }

    public static List<SdaVersion> getVersionsSafe(String componentId) {
        try {
            return getVersions(componentId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaVersion>();
    }

    public static List<SdaVersion> getSortedVersions(String componentId) throws AdmException {
        List<SdaVersion> versions = SdaIntegrationHelper.getVersions(componentId);
        Collections.sort(versions, new Comparator<SdaVersion>() {
            @Override
            public int compare(SdaVersion o1, SdaVersion o2) {
                return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
            }
        });
        return versions;
    }

    public static List<SdaVersion> getSortedVersionsSafe(String componentId) {
        try {
            return getSortedVersions(componentId);
        } catch (AdmException e) {
            Debug.error(e);
        }
        return new ArrayList<SdaVersion>();
    }

    public static void handleEvent(String eventId, String jsonContent) throws AdmException {
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.HandleEvent);
        drs.setEventId(eventId);
        drs.setValue(jsonContent);
        DRSUtils.execute(drs);
    }

    public static SdaJobLinks getJobLinks(int jobUid) throws AdmException {
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetJobLinks);
        drs.setJobUid(jobUid);
        DRSUtils.execute(drs);

        if (drs.hasData()) {
            return new SdaJobLinks(drs.getProcessName(), drs.getProcessLink(), drs.getComponentName(), drs.getComponentLink());
        }

        return null;
    }

    public static boolean isSdaEnabled(Product product, boolean checkIntegration) throws AdmException {
        if (product == null) {
            return false;
        }
        if (checkIntegration && !SdaIntegrationHelper.hasSdaIntegration()) {
            return false;
        }
        boolean isSdaEnabled = false;
        String sdaApplication = (String) AdmCmd.getAttributeValue(product, AdmAttrNames.SDA_APPLICATION);
        if (sdaApplication != null) {
            isSdaEnabled = true;
        }
        return isSdaEnabled;
    }

    public static boolean isSdaEnabled(WorkSet workset, boolean checkIntegration) throws AdmException {
        if (workset == null) {
            return false;
        }
        if (checkIntegration && !SdaIntegrationHelper.hasSdaIntegration()) {
            return false;
        }
        boolean isSdaEnabled = false;
        String productName = (String) AdmCmd.getAttributeValue(workset, AdmAttrNames.PRODUCT_NAME);
        if (productName != null) {
            AdmBaseId id = new AdmSpec(productName, Product.class);
            Product product = (Product) AdmCmd.getObject(id);
            isSdaEnabled = isSdaEnabled(product, false);
        }
        return isSdaEnabled;
    }

    public static boolean isSdaEnabled(WorkSet workset) throws AdmException {
        return isSdaEnabled(workset, true);
    }

    public static boolean isSdaEnabled(Stage stage) throws AdmException {
        if (stage == null) {
            return false;
        }
        boolean isSdaEnabled = false;
        String pipeline = (String) AdmCmd.getAttributeValue(stage, AdmAttrNames.SDA_PIPELINE);
        String env = (String) AdmCmd.getAttributeValue(stage, AdmAttrNames.SDA_ENV);
        if (pipeline != null || env != null) {
            isSdaEnabled = true;
        }
        return isSdaEnabled;
    }

    public static boolean isSdaEnabled(Product product) throws AdmException {
        return isSdaEnabled(product, true);
    }

    public static List<Product> getAllNonSdaMappedProducts() throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurBaseDatabase());
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Product.class);
        List productIds = (List) cmd.execute();
        if (productIds == null || productIds.isEmpty()) {
            return new ArrayList<Product>();
        }
        List<Product> products = AdmCmd.getObjects(productIds);
        if (products == null) {
            return new ArrayList<Product>();
        }
        Iterator<Product> it = products.iterator();
        while (it.hasNext()) {
            Product product = it.next();
            if (SdaIntegrationHelper.isSdaEnabled(product, false)) {
                it.remove();
            }
        }
        return products;
    }

    public static List<String> getAllNonSdaMappedProductNames() throws AdmException {
        List<String> productNames = new ArrayList<String>();
        List<Product> nonSdaMappedProducts = getAllNonSdaMappedProducts();
        if (nonSdaMappedProducts != null) {
            for (Product nonSdaMappedProduct : nonSdaMappedProducts) {
                if (nonSdaMappedProduct != null) {
                    productNames.add(nonSdaMappedProduct.getId());
                }
            }
        }
        return productNames;
    }

    public static boolean isCurWorksetSdaEnabled() throws AdmException {
        WorkSet curWorkset = AdmCmd.getCurWorkSet();
        if (curWorkset == null) {
            return false;
        }
        return isSdaEnabled(curWorkset);
    }

    public static SdaBaselineDeployLink getBaselineDeployLink(String baselineSpec) throws AdmException {
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetBaselineDeployLink);
        drs.setBaselineSpec(baselineSpec);
        DRSUtils.execute(drs);

        if (drs.hasData()) {
            return new SdaBaselineDeployLink(drs.getComponentName(), drs.getComponentLink());
        }

        return null;
    }

    public static LastPromotionParams getLastPromotionParams(String baselineSpec) throws AdmException {
        if (baselineSpec == null) {
            return null;
        }
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetLastPromotionParams);
        drs.setBaselineSpec(baselineSpec);
        DRSUtils.execute(drs);

        if (drs.hasData()) {
            return new LastPromotionParams(drs.getProcessId(), drs.getComponentId(), drs.getComponentVersion(),
                    drs.getComponentIds(), drs.getVersionIds());
        }

        return null;
    }

    public static DefaultDemotionParams getDefaultDemotionParams(String baselineSpec) throws AdmException {
        if (baselineSpec == null) {
            return null;
        }
        DRSClientSdaUtils drs = new DRSClientSdaUtils(DRSClientSdaUtils.SdaUtilsQueryContext.GetDefaultDemotionParams);
        drs.setBaselineSpec(baselineSpec);
        DRSUtils.execute(drs);

        if (drs.hasData()) {
            return new DefaultDemotionParams(drs.getProcessId(), drs.getComponentIds(), drs.getVersionIds());
        }

        return null;
    }

}

/*
 * Copyright (C) 2003, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ReplBlnSubordinateConfig;
import merant.adm.dimensions.objects.ReplChdocSubordinateConfig;
import merant.adm.dimensions.objects.ReplItemSubordinateConfig;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Subordinate Replication Configuration object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteReplSubordinateCmd extends DBIOCmd {

    public DeleteReplSubordinateCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReplItemSubordinateConfig) && !(attrValue instanceof ReplBlnSubordinateConfig)
                    && !(attrValue instanceof ReplChdocSubordinateConfig)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        final AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        final String configId = admObj.getId();
        final Class parentClass = (Class) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
        final int repClass = (Item.class.equals(parentClass) ? Constants.REPL_ITEM_CLASS : (Baseline.class.equals(parentClass)
                ? Constants.REPL_BASELINE_CLASS : Constants.REPL_CHDOC_CLASS));

        final String revision = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.REVISION);

        if (revision.startsWith("0")) {
            throw new DimNotExistsException(
                    "The configuration definition you have selected is the master and cannot be deleted here.");
        }

        if (!DoesExistHelper.masterReplConfigExists(configId, repClass)) {
            throw new DimNotExistsException("The "
                    + (repClass == Constants.REPL_ITEM_CLASS ? "item" : (repClass == Constants.REPL_BASELINE_CLASS
                            ? "baseline" : "request")) + " replication configuration " + configId + " does not exist.");
        }
        if (!DoesExistHelper.replConfigExists(configId, repClass, revision)) {
            throw new DimNotExistsException("The subordinate definition to be deleted does not exist.");
        }

        final long configUid = ((AdmUidObject) admObj).getUid();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {
                if (isSubordinateInUse(dbCtx, configId, repClass)) {
                    throw new DimInUseException("The subordinate definition to be deleted is currently in use.");
                }

                deleteReplConfig(dbCtx, configUid, configId, repClass);
            }
        });

        return "Operation Completed";
    }

    private boolean isSubordinateInUse(DBIO dbCtx, String configId, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_IN_USE);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.readStart();
        boolean inUse = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return inUse;
    }

    private void deleteReplConfig(DBIO dbCtx, long configUid, String configId, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_BRANCH_OR_TYPE_ASSIGNMENTS);
        dbCtx.bindInput(configUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_CONFIG_DETAILS);
        dbCtx.bindInput(configUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_CONFIG);
        dbCtx.bindInput(configUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }
}

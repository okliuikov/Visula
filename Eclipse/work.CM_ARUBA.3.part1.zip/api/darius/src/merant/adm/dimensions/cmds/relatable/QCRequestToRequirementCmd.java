/*
 * Copyright (C), 2005-2006, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.relatable;

import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.Requirement;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.QueryConstants;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;

/**
 * This command will query the children of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId or Relationship instances</dd>
 * </dl></code>
 * 
 * 
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
public class QCRequestToRequirementCmd extends QueryRelsCmd {
    public QCRequestToRequirementCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_CHILDREN);
        // * I don't think we need this.
        // x setAttrDef(new CmdArgDef(CmdArguments.ADM_CHILD_CLASS, true,
        // x Class.class));
        // x setAttrDef(new CmdArgDef(CmdArguments.MULTIPLE, false, Boolean.FALSE,
        // x Boolean.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean relationships = ((Boolean) getAttrValue(CmdArguments.RELATIONSHIPS)).booleanValue();

        List ret = new Vector();
        try {
            SuperQuery sq = new SuperQuery();

            sq.setObjectType(Requirement.class);
            sq.setScope(new AdmBaseId(WorkSet.class));

            // specify the attributes we want back

            sq.addSelect(AdmAttrNames.ADM_UID, QueryConstants.ALWAYS_INCLUDE); // Dimensions requirement object id
            sq.addSelect(AdmAttrNames.ADM_SPEC, QueryConstants.ALWAYS_INCLUDE);

            sq.addRel(admObj);

            sq.addDefaultOrder();

            sq.readStart();

            while (sq.read()) {
                addRelation(
                        ret,
                        relationships,
                        admObj.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(sq.getLong(1), Requirement.class, admObj.getAdmBaseId(),
                                AdmHelperCmd.newAdmBaseId(sq.getString(2), Requirement.class, admObj.getAdmBaseId())));
            }
        } catch (DimConnectionException e) {
            // * XXX - chrisp - temporary code to catch exception that is thrown
            // * when trying to close the connection in rpcDBclose().
            // * The underlying problem needs to be found, but this will
            // * temporarily fix the issue.
        }

        return ret;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.UploadEnvironment;
import merant.adm.dimensions.objects.UploadExclusion;
import merant.adm.dimensions.objects.UploadInclusion;
import merant.adm.dimensions.objects.UploadProject;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Upload object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class DeleteUploadCmd extends RPCExecCmd {
    public DeleteUploadCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof UploadEnvironment)) && (!(attrValue instanceof UploadExclusion))
                    && (!(attrValue instanceof UploadInclusion)) && (!(attrValue instanceof UploadProject))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    private String getItemProduct(long itemSpecUid) throws AdmException {
        AdmObject product = null;
        DBIO query = new DBIO(wcm_sql.QUERY_UPLPROJ_PRODUCT);
        query.bindInput(itemSpecUid);
        query.readStart();
        if (query.read()) {
            product = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getString(1), Product.class));
        }

        query.close();

        return (String) AdmHelperCmd.getAttributeValue(product, AdmAttrNames.ID);
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        DBIO query = null;

        if (admObj instanceof UploadEnvironment) {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UPLOADMAN")) {
                throw new DimNoPrivilegeException("ADMIN_UPLOADMAN");
            }

            String id = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
            String extension = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.EXTENSION);
            query = new DBIO(wcm_sql.DELETE_UPLENV);
            query.bindInput(id);
            query.bindInput(extension);
            query.write();
            query.commit();
        } else if (admObj instanceof UploadExclusion) {
            String uploadProjId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
            String id = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
            String extension = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.EXTENSION);

            if (uploadProjId.equals("0") || extension.startsWith("$")) {
                // Start DEF173973
                if (uploadProjId.equals("0") && extension.startsWith("mrg-")) {// For all product specific Dimensions Clients upload
                                                                               // projects.
                    AdmBaseId prodBaseId = AdmHelperCmd.newAdmBaseId(
                            Long.parseLong(extension.substring(extension.indexOf("-") + 1)), Product.class);
                    String prodId = AdmHelperCmd.getObject(prodBaseId, AdmAttrNames.ID).getId();
                    if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", prodId)) {
                        throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", prodId);
                    }// End DEF173973
                } else {
                    // Ensure that we have the privilege to do this
                    if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UPLOADMAN")) {
                        throw new DimNoPrivilegeException("ADMIN_UPLOADMAN");
                    }
                }
            } else {
                String itemProductName = getItemProduct(Long.valueOf(uploadProjId).longValue());
                // Ensure that we have the privilege to do this
                if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", itemProductName)) {
                    throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", itemProductName);
                }
            }

            query = new DBIO(wcm_sql.DELETE_UPLOAD_EXCLUSION);
            query.bindInput(id);
            query.bindInput("$$" + extension);
            query.bindInput(uploadProjId);
            query.write();
            query.commit();
        } else if (admObj instanceof UploadInclusion) {
            String uploadProjId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
            String id = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
            String extension = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.EXTENSION);

            if (uploadProjId.equals("0") || extension.startsWith("$")) {
                // Start DEF173973
                if (uploadProjId.equals("0") && extension.startsWith("mrg-")) {// For all product specific Dimensions Clients upload
                                                                               // projects.
                    AdmBaseId prodBaseId = AdmHelperCmd.newAdmBaseId(
                            Long.parseLong(extension.substring(extension.indexOf("-") + 1)), Product.class);
                    String prodId = AdmHelperCmd.getObject(prodBaseId, AdmAttrNames.ID).getId();
                    if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", prodId)) {
                        throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", prodId);
                    }// End DEF173973
                } else {
                    // Ensure that we have the privilege to do this
                    if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UPLOADMAN")) {
                        throw new DimNoPrivilegeException("ADMIN_UPLOADMAN");
                    }
                }
            } else {
                String itemProductName = getItemProduct(Long.valueOf(uploadProjId).longValue());
                // Ensure that we have the privilege to do this
                if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", itemProductName)) {
                    throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", itemProductName);
                }
            }

            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_PARENT, admObj);
            cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, UploadProject.class);
            AdmObject uploadProject = AdmHelperCmd.getObject((AdmBaseId) cmd.execute());
            int startResequenceIndex = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.UPLINC_SEQ)).intValue();

            // wcm_sql.GET_UPLOAD_INCLUSIONS guarantees us an ordering by
            // sequence but add the filter anyway - for future compatibility
            Filter filter = new FilterImpl();
            filter.orders().add(new FilterOrder(AdmAttrNames.UPLINC_SEQ, FilterOrder.ASCENDING));
            cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, uploadProject, UploadInclusion.class);
            cmd.setAttrValue(CmdArguments.FILTER, filter);
            List uploadInclusions = AdmHelperCmd.getObjects((List) cmd.execute(), AdmAttrNames.UPLINC_SEQ);
            if ((uploadInclusions == null) || (uploadInclusions.size() < 1)) {
                throw new DimBaseCmdException("Error, no existing inclusions found!");
            }

            boolean doCommit = true;
            try {
                query = new DBIO(false);
                query.resetMessage(wcm_sql.DELETE_UPLOAD_INCLUSION);
                query.bindInput(id);
                query.bindInput("$$" + extension);
                query.bindInput(uploadProjId);
                query.write(DBIO.DB_DONT_COMMIT);
                query.close(DBIO.DB_DONT_RELEASE);

                for (int i = startResequenceIndex; i < uploadInclusions.size(); i++) {

                    String ext = "$$" + extension;
                    String uploadInclusion = (String)((AdmObject)uploadInclusions.get(i)).getAttrValue(AdmAttrNames.ID);
                    long num = ((Long) ((AdmObject) uploadInclusions.get(i)).getAttrValue(AdmAttrNames.UPLINC_SEQ)).longValue() - 1;

                    SqlUtils.updateUploadInclusionSeq(query, ext, uploadProjId, uploadInclusion, num);

                    query.write(DBIO.DB_DONT_COMMIT);
                    query.close(DBIO.DB_DONT_RELEASE);
                }
            } catch (Exception e) {
                if (query != null) {
                    try {
                        query.rollback();
                    } catch (Exception ex) {
                        Debug.error(ex);
                    }

                    doCommit = false;
                }

                Debug.error(e);
                throw new AdmException(e);
            } finally {
                if ((query != null) && doCommit) {
                    try {
                        query.commit();
                    } catch (Exception ex) {
                        Debug.error(ex);
                        throw new DimBaseCmdException(ex.toString());
                    }
                }
            }
        } else if (admObj instanceof UploadProject) {
            final String extension = (String) admObj.getAttrValue(AdmAttrNames.EXTENSION);
            // Check for upload product
            if (!extension.startsWith("mrg") && extension.contains("-")) {
                // Deletion of product upload rule set
                new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
                    @Override
                    public void execute(DBIO dbCtx) throws Exception {
                        dbCtx.resetMessage(wcm_sql.DELETE_ALL_UPLOAD_INCLUSION);
                        dbCtx.bindInput("$$" + extension);
                        dbCtx.bindInput("0");
                        dbCtx.write(DBIO.DB_DONT_COMMIT);
                        dbCtx.close(DBIO.DB_DONT_RELEASE);

                        dbCtx.resetMessage(wcm_sql.DELETE_ALL_UPLOAD_EXCLUSION);
                        dbCtx.bindInput("$$" + extension);
                        dbCtx.bindInput("0");
                        dbCtx.write(DBIO.DB_DONT_COMMIT);
                        dbCtx.close(DBIO.DB_DONT_RELEASE);
                    }
                });
            } else {
                // Default upload project deletion
                query = new DBIO(wcm_sql.QUERY_UPLPROJ_ITEMSPEC);
                query.bindInput(((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.SPEC_UID)).longValue());
                while (query.read()) {
                    AdmCmd.getCmd(Deletable.DELETE,
                            AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getString(1), Item.class))).execute();
                }
            }
        }

        return "Operation completed successfully";
    }
}

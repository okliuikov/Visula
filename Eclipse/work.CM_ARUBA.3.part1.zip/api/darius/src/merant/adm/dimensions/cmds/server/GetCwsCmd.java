/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.serena.dmnet.ProjectContext;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will get info about the current workset.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>None</dt> * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>None</dt>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List of the following connection information:<br />
 *       the current workset spec (java.lang.String)<br />
 *       the current workset object (AdmObject)<br/>
 *       the current workset root directory (java.lang.String)<br />
 *       the current workset design part spec (java.lang.String)<br />
 *       the current workset design part object (AdmObject)<br />
 *       the current working request id (java.lang.String)<br />
 *       the current working request object (AdmObject)<br />
 *       the current root project spec (java.lang.String)<br />
 *       the current root project object (AdmObject)<br />
 *       the current library cache area id (java.lang.String)<br />
 *       the current library cache area object (AdmObject)<br />
 *       the current default version branch name (java.lang.String)<br />
 *       the current default version branch object (AdmObject)<br />
 *       (values may be null or blank if undefined).</dd>
 * </dl></code>
 * @author Peter Raymond, David Conneely, Peter Bate
 */
public class GetCwsCmd extends RPCExecCmd {
    public GetCwsCmd() throws AttrException {
        super();
        setAlias(Server.GET_CWS);
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_DEFAULT, false));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        List ret = null;
        boolean blnIsDefault = false; // Default workset
        try {
            if (getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT) != null) {
                blnIsDefault = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT)).booleanValue();
            }
            if (blnIsDefault) {// fetch default workset
                ret = new ArrayList(1);
                // kludge to prevent stage projects being viewed in web client (DEF95215)
                StringBuffer queryString = new StringBuffer("SELECT up.workset_uid FROM users_profile up, ws_catalogue wc ");
                queryString.append("WHERE up.user_name= :I1 AND up.workset_uid=wc.obj_uid AND NVL(wc.visible,'Y')='Y'");
                DBIO query = new DBIO(queryString.toString());
                query.bindInput((AdmCmd.getCurRootObj(User.class)).getId());
                query.readStart();
                if (query.read()) {
                    ret.add(new Long(query.getLong(1)));
                }
            } else {
                ProjectContext pc = getSession().getConnection().rpcGetProjectContext();
                if (pc != null) {
                    // 1: get project
                    int projUid = pc.getProjectUid();
                    AdmObject project = null;
                    String projectSpec = "";
                    if (projUid != Constants.INVALID_UID) {
                        // don't query for attributes
                        project = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(projUid, WorkSet.class));
                        String product = pc.getProjectProduct();
                        String id = pc.getProjectId();
                        projectSpec = product + ":" + id;
                        // fill in the attrs
                        if (project != null) {
                            project.setAttrValue(AdmAttrNames.ID, id);
                            project.setAttrValue(AdmAttrNames.PRODUCT_NAME, product);
                        }
                    }

                    // 2: get project root dir
                    String projectRootDir = pc.getProjectWorkArea();
                    // fill in the attrs
                    if (project != null) {
                        project.setAttrValue(AdmAttrNames.WSET_USER_DIR, projectRootDir);
                    }

                    // 3: get default part
                    int partUid = pc.getPartUid();
                    AdmObject part = null;
                    String partSpec = "";
                    if (partUid != Constants.INVALID_UID) {
                        part = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(partUid, Part.class));
                        String product = pc.getPartProduct();
                        String id = pc.getPartId();
                        String revision = pc.getPartRevision();
                        String variant = pc.getPartVariant();
                        partSpec = product + ":" + id + "." + variant + ";" + revision;
                    }

                    // 4: get default request
                    int requestUid = pc.getRequestUid();
                    AdmObject request = null;
                    String requestId = "";
                    if (requestUid != Constants.INVALID_UID) {
                        request = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(requestUid, ChangeDocument.class));
                        requestId = pc.getRequestId();
                    }

                    // 5: get root project
                    int rootProjUid = pc.getRootProjectUid();
                    AdmObject rootProject = null;
                    String rootProjSpec = "";
                    if (rootProjUid != Constants.INVALID_UID) {
                        rootProject = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(rootProjUid, WorkSet.class));
                        String product = pc.getRootProjectProduct();
                        String id = pc.getRootProjectId();
                        rootProjSpec = product + ":" + id;
                    }

                    // 6: get default library cache area
                    int libCacheUid = pc.getLibraryCacheAreaUid();
                    AdmObject libraryCacheArea = null;
                    String libCacheId = "";
                    if (libCacheUid != Constants.INVALID_UID) {
                        libraryCacheArea = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(libCacheUid, FileArea.class));
                        libCacheId = pc.getLibraryCacheArea();
                    }

                    // 7: get default version branch name
                    int branchUid = pc.getBranchUid();
                    AdmObject branch = null;
                    String branchName = "";
                    if (branchUid != Constants.INVALID_UID) {
                        branch = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(branchUid, Branch.class));
                        branchName = pc.getBranchName();
                    }

                    ret = new ArrayList(13);

                    ret.add(projectSpec);
                    ret.add(project);
                    ret.add(projectRootDir);
                    ret.add(partSpec);
                    ret.add(part);
                    ret.add(requestId);
                    ret.add(request);
                    ret.add(rootProjSpec);
                    ret.add(rootProject);
                    ret.add(libCacheId);
                    ret.add(libraryCacheArea);
                    ret.add(branchName);
                    ret.add(branch);
                }
            }

        } catch (IOException ioe) {
            Debug.error(ioe);
            // throw new DimConnectionException(ioe);
        }

        return ret;
    }
}

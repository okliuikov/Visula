/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.helper;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.serena.dmfile.ItemMetadata;
import com.serena.dmfile.MetadataStrings;
import com.serena.dmnet.Constants;
import com.serena.dmnet.RFScan;
import com.serena.dmnet.RFScanResult;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCScanAreaCmd;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.FileAreaDirectory;
import merant.adm.dimensions.objects.FileAreaFile;
import merant.adm.dimensions.objects.FileAreaFileMVS;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.util.FileAreaDirectoryComparator;
import merant.adm.dimensions.util.FileAreaFileComparator;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

/**
 * This class contains helper methods for file area operations.
 */
public class FileAreaHelper {

    /**
     * Scans the root directories of the specified <code>FileArea</code> location.
     * @param FileArea
     *            object to scan for directories.
     * @return List FileAreaDirectory objects for each sub directory.
     */

    public static List scanFileAreaDirectories(FileArea faObj) throws AttrException, AdmException {

        List dirs = null;
        if (faObj != null) {

            // scan the directories
            // PS dirs = scanDirectories(getAreaPath(faObj), faObj);
            String faObjPath = faObj.getAdmSpec().getSpec() + "::";
            dirs = scanDirectories(faObjPath, faObj);
        }
        return dirs;
    }

    /**
     * Scans directories beneath the specified <code>FileAreaDirectory</code> location.
     * @param fadObj
     *            FileAreaDirectory object to scan for directories.
     * @return List of FileAreaDirectory objects for each sub directory.
     */
    public static List scanFileAreaDirectories(FileAreaDirectory fadObj) throws AttrException, AdmException {
        // scan the directories
        String fadSpec = fadObj.getAdmSpec().getSpec();
        int colonColonIndex = fadSpec.indexOf("::");
        FileArea fileArea = null;
        if (colonColonIndex > -1) {
            String fileAreaId = fadSpec.substring(0, colonColonIndex);
            fileArea = new FileArea(new AdmSpec(fileAreaId, FileArea.class));
        }
        return scanDirectories(fadSpec, fileArea);
    }

    public static boolean isOnMVSArea(AdmObject obj) throws AdmException {
        if (obj == null) {
            return false;
        }

        FileArea fileArea = null;
        if (obj instanceof FileAreaFile || obj instanceof FileAreaDirectory) {
            String fadSpec = obj.getAdmSpec().getSpec();
            int colonColonIndex = fadSpec.indexOf("::");
            if (colonColonIndex > -1) {
                String fileAreaId = fadSpec.substring(0, colonColonIndex);
                fileArea = new FileArea(new AdmSpec(fileAreaId, FileArea.class));
            }
        } else if (obj instanceof FileArea) {
            fileArea = (FileArea) obj;
        }

        if (fileArea != null) {
            Cmd cmd = AdmCmd.getCmd(Server.QUERY_IS_AREA_ON_MVS_NODE, fileArea);
            Object ret = cmd.execute();
            if (ret instanceof Boolean) {
                return ((Boolean) ret).booleanValue();
            }
        }
        return false;
    }

    /**
     * Scan for directories beneath the specified area path.
     * @param areaPath
     *            String path to scan for directories.
     * @param faObj
     *            FileArea object to add as scope on the return directory objects.
     * @return List FileAreaDirectory objects for each directory beneath the area path.
     */
    private static List scanDirectories(String areaPath, FileArea faObj) throws AttrException, AdmException {

        String faObjSpec = faObj.getAdmSpec().getSpec();

        // build array of attributes we need for each directory
        int[] attrNos = { RFScan.RF_ATTR_FULLPATH, RFScan.RF_ATTR_FILENAME, RFScan.RF_ATTR_DIR_HAS_SUBDIRS };

        // only want directories so only that flag is passed
        int flags = RFScan.RF_SCAN_AREA_FLAGS_INCLUDE_DIRS;

        boolean isMVSArea = isOnMVSArea(faObj);

        if (isMVSArea) {
            attrNos = new int[] { RFScan.RF_ATTR_FILENAME, RFScan.RF_ATTR_FILEPATH };
            flags = RFScan.RF_SCAN_AREA_FLAGS_MVS_INCLUDE_DATASETS | RFScan.RF_SCAN_AREA_FLAGS_INCLUDE_DIRS
                    | RFScan.RF_SCAN_AREA_FLAGS_RECURSIVE;
        }

        // scan for directories
        RFScanResult result = (RFScanResult) scanArea(areaPath, flags, attrNos, null);
        List dirs = new ArrayList();
        if (result != null) {
            if (result.status != Constants.PCMS_OK) {
                if (result.errorMessages != null && result.errorMessages.length > 0) {
                    String error = result.errorMessages[0];
                    dirs.add(new AdmException(error));
                }
                return dirs;
            }

            String[][] fileAttrs = result.fileAttrs;

            if (fileAttrs != null) {

                // for each result create a FileAreaDirectory object with the required data needed
                for (int i = 0; fileAttrs != null && fileAttrs.length > i; i++) {
                    FileAreaDirectory fad = new FileAreaDirectory();
                    if (isMVSArea) {
                        String fadDSName = fileAttrs[i][0];
                        String fadDSPath = fileAttrs[i][1];
                        fad.setAdmSpec(new AdmSpec(faObjSpec + "::" + fadDSPath, FileAreaDirectory.class)); // RF_ATTR_FULLPATH
                        fad.setAttrValue(AdmAttrNames.ID, fadDSName); // RF_ATTR_FILENAME
                        fad.setAttrValue(AdmAttrNames.AREA_DIRS_HAS_SUBDIRS, Boolean.FALSE);
                    } else {
                        String fadFullPath = fileAttrs[i][0];
                        // PS fad.setAdmSpec(new AdmSpec(fadFullPath, FileAreaDirectory.class)); // RF_ATTR_FULLPATH
                        fad.setAdmSpec(new AdmSpec(faObjSpec + "::" + fadFullPath, FileAreaDirectory.class)); // RF_ATTR_FULLPATH
                        fad.setAttrValue(AdmAttrNames.ID, fileAttrs[i][1]); // RF_ATTR_FILENAME
                        String hasSubDirs = fileAttrs[i][2]; // RF_ATTR_DIR_HAS_SUBDIRS
                        fad.setAttrValue(AdmAttrNames.AREA_DIRS_HAS_SUBDIRS, (((hasSubDirs == null) || hasSubDirs.equals("Y"))
                                ? Boolean.TRUE : Boolean.FALSE));
                    }
                    // add the FileArea object as a scope for this object
                    fad.getAdmBaseId().setScope(faObj.getAdmBaseId());
                    dirs.add(fad);
                }
            }
            Collections.sort(dirs, new FileAreaDirectoryComparator());
        }
        return dirs;
    }

    /**
     * Scans the root files of the specified <code>FileArea</code> location.
     * @param FileArea
     *            object to scan for files.
     * @param List
     *            of attribute names representing the columns to query.
     * @return List FileAreaFile objects beneather the file area location.
     */
    public static List scanFileAreaFiles(FileArea faObj, List attributeNames, Filter filter) throws AttrException, AdmException {

        List dirs = null;
        if (faObj != null) {
            String faObjPath = faObj.getAdmSpec().getSpec() + "::";
            // scan the directories
            dirs = scanFiles(faObjPath, faObj, attributeNames, filter, null, false, false);
        }

        return dirs;
    }

    /**
     * Scans files beneath the specified <code>FileAreaDirectory</code> location.
     * @param fadObj
     *            FileAreaDirectory object to scan for files.
     * @return List FileAreaFile objects beneather the file area location.
     */
    public static List scanFileAreaFiles(FileAreaDirectory fadObj, List attributeNames, Filter filter) throws AttrException, AdmException {
        // scan the directories
        String fadSpec = fadObj.getAdmSpec().getSpec();
        int colonColonIndex = fadSpec.indexOf("::");
        FileArea fileArea = null;
        if (colonColonIndex > -1) {
            String fileAreaId = fadSpec.substring(0, colonColonIndex);
            fileArea = new FileArea(new AdmSpec(fileAreaId, FileArea.class));
        }
        return scanFiles(fadSpec, fileArea, attributeNames, filter, null, false, false); // because it's directory (on the tree selected),
                                                                                 // we don't currently need to query more for mvs
                                                                                 // dataset and stats
    }

    /**
     * Scans the area to obtain properties for a particular <code>FileAreaFile</code> object.
     * @param fafObj
     *            FileAreaFile object to get properties from.
     * @return FileAreaFile object populated with the properties.
     */
    public static FileAreaFile getFileAreaFileProperties(FileAreaFile fafObj, boolean isMVSArea) throws AttrException, AdmException {
        String fafSpec = fafObj.getAdmSpec().getSpec();
        String areaPath = fafSpec;
        String[] inclusions = new String[1];
        if (isMVSArea) {
            int colonColonIndex = fafSpec.indexOf("::");
            if (colonColonIndex > -1) {
                inclusions[0] = fafSpec.substring(colonColonIndex + 2);
            } else {
                inclusions[0] = fafSpec;
            }
        } else {
            // the spec of a FileAreaFile object contains the full path
            File file = new File(fafObj.getAdmSpec().getSpec());

            // get the parent path without the filename
            areaPath = file.getParent();

            // setup the inclusions, we only want one file to be returned
            String filename = file.getName();
            if (areaPath == null) {
                int index = -1;
                if (filename != null && (index = filename.indexOf("::")) != -1) {
                    areaPath = filename.substring(0, index + 2);
                    filename = filename.substring(index + 2);
                }
            }
            inclusions[0] = filename;
        }
        // scan the area for file and details needed populated
        List files = scanFiles(areaPath, (FileArea) AdmHelperCmd.getObject(fafObj.getAdmBaseId().getScope()), null, null, inclusions,
                true, true);

        // there should only be only file returned so get the first one in the list
        if ((files != null) && (files.size() > 0)) {
            Object obj = files.get(0);
            if (obj instanceof AdmException) {
                throw (AdmException) obj;
            } else if (obj instanceof FileAreaFile) {
                fafObj = (FileAreaFile) obj;
            }
        }
        return fafObj;

    }

    private static Map FAF_ATTRS_MAP_GET = new HashMap<String, Integer>(15);
    private static Map FAF_ATTRS_MAP_SET = new HashMap<Integer, String>(15);
    private static Map FAF_ATTRS_MAP_SET_PROPS = new HashMap<Integer, String>(15);
    private static Map MVS_ATTRS_MAP_GET = new HashMap<String, Integer>(21);
    private static Map MVS_ATTRS_MAP_SET = new HashMap<Integer, String>(21);
    private static Map MVS_ATTRS_MAP_SET_PROPS = new HashMap<Integer, String>(21);

    static {
        // non-mvs specific attrs (GET)
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_CAN_EXECUTE, RFScan.RF_ATTR_CAN_EXECUTE);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_CAN_READ, RFScan.RF_ATTR_CAN_READ);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_CAN_WRITE, RFScan.RF_ATTR_CAN_WRITE);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_CREATE_DATE, RFScan.RF_ATTR_CREATTIME_STR);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_MODIFIED_DATE, RFScan.RF_ATTR_MODTIME_STR);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_PERMISSIONS, RFScan.RF_ATTR_PERMISSIONS);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_SIZE, RFScan.RF_ATTR_SIZE);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.ADM_SPEC, RFScan.RF_ATTR_FULLPATH);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.ID, RFScan.RF_ATTR_FILENAME);

        // non-mvs specific attrs (SET)
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_CAN_EXECUTE, AdmAttrNames.AREA_FILE_CAN_EXECUTE);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_CAN_READ, AdmAttrNames.AREA_FILE_CAN_READ);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_CAN_WRITE, AdmAttrNames.AREA_FILE_CAN_WRITE);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_CREATTIME_STR, AdmAttrNames.AREA_FILE_CREATE_DATE);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_MODTIME_STR, AdmAttrNames.AREA_FILE_MODIFIED_DATE);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_PERMISSIONS, AdmAttrNames.AREA_FILE_PERMISSIONS);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_SIZE, AdmAttrNames.AREA_FILE_SIZE);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_FULLPATH, AdmAttrNames.ADM_SPEC);
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_FILENAME, AdmAttrNames.ID);

        // non-mvs property based attrs (SET)
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_FULLPATH, AdmAttrNames.ADM_SPEC);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_FILENAME, AdmAttrNames.ID);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_SIZE, AdmAttrNames.AREA_FILE_SIZE);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_CREATTIME_STR, AdmAttrNames.AREA_FILE_CREATE_DATE);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_MODTIME_STR, AdmAttrNames.AREA_FILE_MODIFIED_DATE);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_ACCESSTIME_STR, AdmAttrNames.AREA_FILE_ACCESS_DATE);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_PERMISSIONS, AdmAttrNames.AREA_FILE_PERMISSIONS);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_CHANGE_TYPE, AdmAttrNames.AREA_FILE_CHANGE_TYPE);

        // non-mvs specific property metadata attrs (SET)
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED, AdmAttrNames.AREA_FILE_ITEMEXTRACTED);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_REVISION, AdmAttrNames.AREA_FILE_ITEMREVISION);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_SPEC, AdmAttrNames.AREA_FILE_ITEMSPEC);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_STATUS, AdmAttrNames.AREA_FILE_ITEMSTATUS);
        FAF_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM, AdmAttrNames.PROJECT_NAME);

        // mvs specific attrs (GET)
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_MEMBERNAME, RFScan.RF_ATTR_MEMBER);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_PRIMARYNAME, RFScan.RF_ATTR_PNAME);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_FULLNAME, RFScan.RF_ATTR_FULLNAME);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_IS_ALIAS, RFScan.RF_ATTR_IS_ALIAS);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_IS_PROGRAM, RFScan.RF_ATTR_IS_PROGRAM);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_CREDATE, RFScan.RF_ATTR_STATS_CREDATE);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_ISPF_OK, RFScan.RF_ATTR_STATS_VALID);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_MAJVER, RFScan.RF_ATTR_STATS_MAJVER);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_MINVER, RFScan.RF_ATTR_STATS_MINVER);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_MODDATE, RFScan.RF_ATTR_STATS_MODDATE);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_MODIFIED, RFScan.RF_ATTR_STATS_MODIFIED);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_MODTIME, RFScan.RF_ATTR_STATS_MODTIME);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_SZCURRENT, RFScan.RF_ATTR_STATS_SZCURRENT);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_SZINITIAL, RFScan.RF_ATTR_STATS_SZINITIAL);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.MVS_MEMBER_STATS_USERID, RFScan.RF_ATTR_STATS_USERID);

        // mvs specific attrs (SET)
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_MEMBER, AdmAttrNames.AREA_FILE_MEMBERNAME);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_PNAME, AdmAttrNames.AREA_FILE_PRIMARYNAME);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_FULLNAME, AdmAttrNames.MVS_MEMBER_FULLNAME);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_IS_ALIAS, AdmAttrNames.MVS_MEMBER_IS_ALIAS);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_IS_PROGRAM, AdmAttrNames.MVS_MEMBER_IS_PROGRAM);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_CREDATE, AdmAttrNames.MVS_MEMBER_STATS_CREDATE);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_VALID, AdmAttrNames.MVS_MEMBER_STATS_ISPF_OK);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_MAJVER, AdmAttrNames.MVS_MEMBER_STATS_MAJVER);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_MINVER, AdmAttrNames.MVS_MEMBER_STATS_MINVER);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_MODDATE, AdmAttrNames.MVS_MEMBER_STATS_MODDATE);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_MODIFIED, AdmAttrNames.MVS_MEMBER_STATS_MODIFIED);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_MODTIME, AdmAttrNames.MVS_MEMBER_STATS_MODTIME);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_SZCURRENT, AdmAttrNames.MVS_MEMBER_STATS_SZCURRENT);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_SZINITIAL, AdmAttrNames.MVS_MEMBER_STATS_SZINITIAL);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_STATS_USERID, AdmAttrNames.MVS_MEMBER_STATS_USERID);

        // change type attr - dependant upon metadata (GET)
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_CHANGE_TYPE, RFScan.RF_ATTR_CHANGE_TYPE);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_CHANGE_TYPE, RFScan.RF_ATTR_CHANGE_TYPE);

        // change type attr - dependant upon metadata (SET)
        FAF_ATTRS_MAP_SET.put(RFScan.RF_ATTR_CHANGE_TYPE, AdmAttrNames.AREA_FILE_CHANGE_TYPE);
        MVS_ATTRS_MAP_SET.put(RFScan.RF_ATTR_CHANGE_TYPE, AdmAttrNames.AREA_FILE_CHANGE_TYPE);

        // metadata attrs (GET)
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMEXTRACTED, RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMEXTRACTED, RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMREVISION, RFScan.PSEUDO_RF_ATTR_REVISION);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMREVISION, RFScan.PSEUDO_RF_ATTR_REVISION);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMSPEC, RFScan.PSEUDO_RF_ATTR_SPEC);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMSPEC, RFScan.PSEUDO_RF_ATTR_SPEC);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMSTATUS, RFScan.PSEUDO_RF_ATTR_STATUS);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.AREA_FILE_ITEMSTATUS, RFScan.PSEUDO_RF_ATTR_STATUS);
        FAF_ATTRS_MAP_GET.put(AdmAttrNames.PROJECT_NAME, RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM);
        MVS_ATTRS_MAP_GET.put(AdmAttrNames.PROJECT_NAME, RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM);

        // metadata attrs (SET)
        FAF_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED, AdmAttrNames.AREA_FILE_ITEMEXTRACTED);
        MVS_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED, AdmAttrNames.AREA_FILE_ITEMEXTRACTED);
        FAF_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_REVISION, AdmAttrNames.AREA_FILE_ITEMREVISION);
        MVS_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_REVISION, AdmAttrNames.AREA_FILE_ITEMREVISION);
        FAF_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_SPEC, AdmAttrNames.AREA_FILE_ITEMSPEC);
        MVS_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_SPEC, AdmAttrNames.AREA_FILE_ITEMSPEC);
        FAF_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_STATUS, AdmAttrNames.AREA_FILE_ITEMSTATUS);
        MVS_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_STATUS, AdmAttrNames.AREA_FILE_ITEMSTATUS);
        FAF_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM, AdmAttrNames.PROJECT_NAME);
        MVS_ATTRS_MAP_SET.put(RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM, AdmAttrNames.PROJECT_NAME);

        // mvs specific property based attrs (SET)
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_MEMBER, AdmAttrNames.AREA_FILE_MEMBERNAME);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_CHANGE_TYPE, AdmAttrNames.AREA_FILE_CHANGE_TYPE);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_PNAME, AdmAttrNames.AREA_FILE_PRIMARYNAME);

        // mvs specific property based data set attrs (SET)
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_VOLSER, AdmAttrNames.MVS_DATA_SET_VOLUME_SERIAL);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_LRECL, AdmAttrNames.MVS_DATA_SET_LARGEST_RECORD);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_BLKSIZE, AdmAttrNames.MVS_DATA_SET_BLKSIZE);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_RECFM, AdmAttrNames.MVS_DATA_SET_RECORD_FORMAT);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_DSORG, AdmAttrNames.MVS_DATA_SET_ORGANISATION);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_ALLOCUNIT, AdmAttrNames.MVS_DATA_SET_ALLOCATION_UNIT);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_PRIMALC, AdmAttrNames.MVS_DATA_SET_FIRST_EXTENT_SIZE);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_SECALC, AdmAttrNames.MVS_DATA_SET_OTHER_EXTENTS_SIZE);

        // mvs specific property based member attrs (SET)
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_VALID, AdmAttrNames.MVS_MEMBER_STATS_ISPF_OK);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_USERID, AdmAttrNames.MVS_MEMBER_STATS_USERID);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_CREDATE, AdmAttrNames.MVS_MEMBER_STATS_CREDATE);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_MODDATE, AdmAttrNames.MVS_MEMBER_STATS_MODDATE);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_MODTIME, AdmAttrNames.MVS_MEMBER_STATS_MODTIME);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_SZCURRENT, AdmAttrNames.MVS_MEMBER_STATS_SZCURRENT);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_MAJVER, AdmAttrNames.MVS_MEMBER_STATS_MAJVER);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.RF_ATTR_STATS_MINVER, AdmAttrNames.MVS_MEMBER_STATS_MINVER);

        // mvs specific property metadata attrs (SET)
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED, AdmAttrNames.AREA_FILE_ITEMEXTRACTED);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_REVISION, AdmAttrNames.AREA_FILE_ITEMREVISION);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_SPEC, AdmAttrNames.AREA_FILE_ITEMSPEC);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_STATUS, AdmAttrNames.AREA_FILE_ITEMSTATUS);
        MVS_ATTRS_MAP_SET_PROPS.put(RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM, AdmAttrNames.PROJECT_NAME);
    }

    private final static int[] MVS_DATA_SET_ATTRS = new int[] { RFScan.RF_ATTR_VOLSER, RFScan.RF_ATTR_LRECL,
            RFScan.RF_ATTR_BLKSIZE, RFScan.RF_ATTR_RECFM, RFScan.RF_ATTR_DSORG, RFScan.RF_ATTR_ALLOCUNIT, RFScan.RF_ATTR_PRIMALC,
            RFScan.RF_ATTR_SECALC };

    private final static int[] MVS_MEMBER_STATS_ATTRS = new int[] { RFScan.RF_ATTR_STATS_VALID, RFScan.RF_ATTR_STATS_USERID,
            RFScan.RF_ATTR_STATS_CREDATE, RFScan.RF_ATTR_STATS_MODDATE, RFScan.RF_ATTR_STATS_MODTIME,
            RFScan.RF_ATTR_STATS_SZCURRENT, RFScan.RF_ATTR_STATS_MAJVER, RFScan.RF_ATTR_STATS_MINVER };

    // Converts a List of AdmAttrNames to an arrary of RFScan.RF_ATTR's
    private static List<Integer> getAttrNosFromNames(List attributeNames, boolean isMVSArea, boolean showMVSDataSetFields,
            boolean showMVSMemberStats) throws AttrException {
        List<Integer> attrList = new ArrayList<Integer>();
        if (attributeNames == null) {
            if (!isMVSArea) {
                attrList.add(RFScan.RF_ATTR_FULLPATH);
                attrList.add(RFScan.RF_ATTR_FILENAME);
                attrList.add(RFScan.RF_ATTR_SIZE);
                attrList.add(RFScan.RF_ATTR_CREATTIME_STR);
                attrList.add(RFScan.RF_ATTR_MODTIME_STR);
                attrList.add(RFScan.RF_ATTR_ACCESSTIME_STR);
                attrList.add(RFScan.RF_ATTR_PERMISSIONS);
                attrList.add(RFScan.RF_ATTR_CHANGE_TYPE);
                attrList.add(RFScan.RF_ATTR_METADATA);
                return attrList;
            }

            attrList.add(RFScan.RF_ATTR_MEMBER);
            attrList.add(RFScan.RF_ATTR_CHANGE_TYPE);
            attrList.add(RFScan.RF_ATTR_PNAME);
            attrList.add(RFScan.RF_ATTR_METADATA);

            if (showMVSDataSetFields) {
                for (int attr : MVS_DATA_SET_ATTRS) {
                    attrList.add(attr);
                }
            }

            if (showMVSMemberStats) {
                for (int attr : MVS_MEMBER_STATS_ATTRS) {
                    attrList.add(attr);
                }
            }
        } else {
            // Loop the attribute names, to convert to numbers
            String attrName = null;
            Map<String, Integer> attrsMap = (isMVSArea) ? MVS_ATTRS_MAP_GET : FAF_ATTRS_MAP_GET;
            for (int i = 0; i < attributeNames.size(); i++) {
                attrName = (String) attributeNames.get(i);
                if (!attrsMap.containsKey(attrName)) {
                    attrName = "Invalid attribute name: " + attrName;
                    throw new AttrException(attrName);
                }

                attrList.add(attrsMap.get(attrName).intValue());
            }

            // loop to discover what we have
            boolean hasChangeType = false;
            boolean hasFullPath = false;
            boolean hasMember = false;
            boolean metaRequired = false;
            for (int i = 0; i < attrList.size(); i++) {
                switch (attrList.get(i).intValue()) {
                case RFScan.RF_ATTR_CHANGE_TYPE:
                    hasChangeType = true;
                    metaRequired = true;
                    break;
                case RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED:
                case RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM:
                case RFScan.PSEUDO_RF_ATTR_REVISION:
                case RFScan.PSEUDO_RF_ATTR_SPEC:
                case RFScan.PSEUDO_RF_ATTR_STATUS:
                    metaRequired = true;
                    break;
                case RFScan.RF_ATTR_FULLPATH:
                    hasFullPath = true;
                    break;
                case RFScan.RF_ATTR_MEMBER:
                    hasMember = true;
                    break;
                default:
                    break;
                }
            }

            // add metadata ... only when required
            if (metaRequired) {
                attrList.add(RFScan.RF_ATTR_METADATA);
                if (!hasChangeType) {
                    attrList.add(RFScan.RF_ATTR_CHANGE_TYPE);
                }
            }

            // attr that sets the AdmSpec is always required
            if (isMVSArea) {
                if (!hasMember) {
                    attrList.add(RFScan.RF_ATTR_MEMBER);
                }
            } else {
                if (!hasFullPath) {
                    attrList.add(RFScan.RF_ATTR_FULLPATH);
                }
            }
        }

        return attrList;
    }

    private static ItemMetadata getItemMetadataFromFileAttrs(String[] fileAttrs, List<Integer> attrList) throws AttrException {
        int index = -1;
        for (int i = 0; ((i < attrList.size()) && (index == -1)); i++) {
            if (attrList.get(i) == RFScan.RF_ATTR_METADATA) {
                index = i;
            }
        }

        if (index == -1) {
            throw new AttrException("No metadata string found!");
        }

        return (ItemMetadata) MetadataStrings.read(fileAttrs[index]);
    }

    private static void setAttrValuesFromRFScan(FileAreaFile faf, String[] fileAttrs, List<Integer> attrList, boolean isMVSArea,
            boolean hasAttrNames, String nodename, String areaPath, String[] inclusions) throws AttrException, AdmObjectException {
        if ((fileAttrs == null) || (attrList == null)) {
            throw new AttrException("Null input array!");
        }

        if (fileAttrs.length != attrList.size()) {
            throw new AttrException("Queried attributes size is not equal to that expected!");
        }

        ItemMetadata im = null;
        Map<Integer, String> attrsMap = null;
        if (hasAttrNames) {
            attrsMap = (isMVSArea) ? MVS_ATTRS_MAP_SET : FAF_ATTRS_MAP_SET;
        } else {
            attrsMap = (isMVSArea) ? MVS_ATTRS_MAP_SET_PROPS : FAF_ATTRS_MAP_SET_PROPS;
        }

        int attr = 0;
        for (int i = 0; i < attrList.size(); i++) {
            attr = attrList.get(i);
            if (attr == RFScan.RF_ATTR_METADATA) {
                if (!hasAttrNames) {
                    // add all pseudo columns to populate from metadata
                    attrList.add(RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED);
                    attrList.add(RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM);
                    attrList.add(RFScan.PSEUDO_RF_ATTR_REVISION);
                    attrList.add(RFScan.PSEUDO_RF_ATTR_SPEC);
                    attrList.add(RFScan.PSEUDO_RF_ATTR_STATUS);
                }

                continue; // RF_ATTR_METADATA added for query, but isn't a column
            }

            if (!attrsMap.containsKey(attr)) {
                String errStr = "Invalid attribute number: " + attr;
                throw new AttrException(errStr);
            }

            switch (attr) {
            case RFScan.RF_ATTR_CHANGE_TYPE: {
                // realistically the only combinations there should be in web client will be modified
                // and moved. The code below may need to be presented better for this scenerio.
                String ctStr = "";
                int ct = (Integer.valueOf(fileAttrs[i])).intValue();
                if ((ct & RFScan.CHANGETYPE_UNCHANGED) != 0) {
                    ctStr += "Unchanged";
                } else if ((ct & RFScan.CHANGETYPE_MODIFICATION) != 0) {
                    ctStr += "Modified";
                }

                if ((ct & RFScan.CHANGETYPE_DELETION) != 0) {
                    if (ctStr.length() > 0) {
                        ctStr += ",";
                    }

                    ctStr += "Deleted";
                } else if ((ct & RFScan.CHANGETYPE_ADDITION) != 0) {
                    if (ctStr.length() > 0) {
                        ctStr += ",";
                    }

                    ctStr += "Added";
                }

                if ((ct & RFScan.CHANGETYPE_MOVE) != 0) {
                    if (ctStr.length() > 0) {
                        ctStr += ",";
                    }

                    ctStr += "Moved";
                }

                faf.setAttrValue(AdmAttrNames.AREA_FILE_CHANGE_TYPE, ctStr);
            }
                break;
            case RFScan.RF_ATTR_FULLPATH:
                faf.setAdmSpec(new AdmSpec(nodename + "::" + fileAttrs[i], FileAreaFile.class));
                break;
            case RFScan.RF_ATTR_MEMBER: {
                String filename = fileAttrs[i];
                int areaPathIndex = areaPath.indexOf("(");
                String areaSubPath = areaPath;
                if ((areaPathIndex > -1) && (inclusions != null)) {
                    areaSubPath = areaPath.substring(0, areaPathIndex);
                }

                String fullFileName = areaSubPath + '(' + filename + ')';
                faf.setAdmSpec(new AdmSpec(fullFileName, FileAreaFileMVS.class));
                faf.setAttrValue(AdmAttrNames.ID, filename);
                faf.setAttrValue(AdmAttrNames.AREA_FILE_MEMBERNAME, filename);
                faf.setAttrValue(AdmAttrNames.AREA_FILE_PATH, areaSubPath);
            }
                break;
            case RFScan.RF_ATTR_SIZE: {
                // get the format of the size
                String sizeTmp = fileAttrs[i];
                double size = ((sizeTmp != null) ? (Double.valueOf(sizeTmp)).doubleValue() : 0);
                String sizeStr = "";
                if ((0 <= size) && (size <= 1023)) {
                    sizeStr = (long) size + " bytes";
                } else if (size >= 1024) {
                    // this should be rounded up so it matches size shown in Explorer
                    BigDecimal bd = new BigDecimal(size / 1024);
                    bd = bd.setScale(0, BigDecimal.ROUND_HALF_EVEN);
                    sizeStr = (long) bd.doubleValue() + " KB";
                }

                faf.setAttrValue(AdmAttrNames.AREA_FILE_SIZE, sizeStr);
            }
                break;
            case RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED:
            case RFScan.PSEUDO_RF_ATTR_REVISION:
            case RFScan.PSEUDO_RF_ATTR_SPEC:
            case RFScan.PSEUDO_RF_ATTR_STATUS:
            case RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM: {
                // Since these are only 'pseudo' attributes, they return nothing from the RPC,
                // so we need to populate the values from the metadata string instead
                if (im == null) {
                    im = getItemMetadataFromFileAttrs(fileAttrs, attrList);
                }

                switch (attr) {
                case RFScan.PSEUDO_RF_ATTR_IS_EXTRACTED:
                    faf.setAttrValue(AdmAttrNames.AREA_FILE_ITEMEXTRACTED, ((im.isExtracted()) ? Boolean.TRUE : Boolean.FALSE));
                    break;
                case RFScan.PSEUDO_RF_ATTR_REVISION: {
                    // revision is needed for the content column which must be parsed from the spec
                    String rev = "";
                    String itemSpec = im.getItemSpec();
                    if (itemSpec != null) {
                        int index = itemSpec.lastIndexOf(';');
                        if ((index != -1) && ((index + 1) < itemSpec.length())) {
                            rev = itemSpec.substring(index + 1);
                        }
                    }

                    faf.setAttrValue(AdmAttrNames.AREA_FILE_ITEMREVISION, rev);
                }
                    break;
                case RFScan.PSEUDO_RF_ATTR_SPEC:
                    faf.setAttrValue(AdmAttrNames.AREA_FILE_ITEMSPEC, im.getItemSpec());
                    break;
                case RFScan.PSEUDO_RF_ATTR_STATUS:
                    faf.setAttrValue(AdmAttrNames.AREA_FILE_ITEMSTATUS, im.getItemStatus());
                    break;
                case RFScan.PSEUDO_RF_ATTR_PROJECT_STREAM:
                    faf.setAttrValue(AdmAttrNames.PROJECT_NAME, im.getProject());
                    break;
                default:
                    break;
                }
            }
                break;
            default:
                faf.setAttrValue(attrsMap.get(attr), fileAttrs[i]);
                break;
            }
        }
    }

    /**
     * Scan for files beneath the specified area path.
     * @param areaPath
     *            String path to scan for files.
     * @param faObj
     *            FileArea object to add as scope on the return file objects.
     * @return List FileAreaFile objects for each files beneath thes area path.
     */
    private static List scanFiles(String areaPath, FileArea faObj, List attributeNames, Filter filter, String[] inclusions,
            boolean showMVSDataSetFields, boolean showMVSMemberStats) throws AttrException, AdmException {

        // build array of attributes we need for each file
        boolean isMVSArea = isOnMVSArea(faObj);
        List<Integer> attrList = getAttrNosFromNames(attributeNames, isMVSArea, showMVSDataSetFields, showMVSMemberStats);

        // turn into primitive array for RPC
        int idx = 0;
        int[] attrNos = new int[attrList.size()];
        for (Integer intg : attrList) {
            attrNos[idx++] = intg.intValue();
        }

        // only want files so only that flag is passed
        int flags = RFScan.RF_SCAN_AREA_FLAGS_INCLUDE_FILES;

        // if there are inclusions then we know we need the properties of a file so we
        // need to add an extra flag
        if (inclusions != null) {
            flags |= RFScan.RF_SCAN_AREA_FLAGS_LITERAL_PATTERN;
        }

        if (isMVSArea) {
            if (inclusions != null) {
                flags = RFScan.RF_SCAN_AREA_FLAGS_MVS_INCLUDE_MEMBERS | RFScan.RF_SCAN_AREA_FLAGS_LITERAL_PATTERN
                        | RFScan.RF_SCAN_AREA_FLAGS_MVS_INCLUDE_ALIASES;
            } else {
                flags = RFScan.RF_SCAN_AREA_FLAGS_MVS_INCLUDE_MEMBERS | RFScan.RF_SCAN_AREA_FLAGS_RETURN_ABSOLUTE_PATHS
                        | RFScan.RF_SCAN_AREA_FLAGS_MVS_INCLUDE_ALIASES;
            }
        }

        // scan for files
        RFScanResult result = (RFScanResult) scanArea(areaPath, flags, attrNos, inclusions);
        List files = new ArrayList();

        if (result != null) {
            if (result.status != Constants.PCMS_OK) {
                if (result.errorMessages != null && result.errorMessages.length > 0) {
                    String error = result.errorMessages[0];
                    files.add(new AdmException(error));
                }
                return files;
            }

            String[][] fileAttrs = result.fileAttrs;

            if (fileAttrs != null) {
                String nodename = areaPath.substring(0, areaPath.indexOf("::"));
                String filepath = areaPath.substring(areaPath.indexOf("::") + 2, areaPath.length());
                boolean hasAttrNames = (attributeNames != null) ? true : false;

                // for each result create a FileAreaFile object with the required data needed
                for (int i = 0; (fileAttrs != null) && (fileAttrs.length > i); i++) {
                    FileAreaFile faf = (isMVSArea) ? new FileAreaFileMVS() : new FileAreaFile();
                    setAttrValuesFromRFScan(faf, fileAttrs[i], attrList, isMVSArea, hasAttrNames, nodename, areaPath, inclusions);
                    faf.setAttrValue(AdmAttrNames.AREA_FILE_NODENAME, nodename);
                    if (!isMVSArea) {
                        faf.setAttrValue(AdmAttrNames.AREA_FILE_PATH, filepath);
                    }

                    // add the FileArea object as a scope for this object
                    faf.getAdmBaseId().setScope(faObj.getAdmBaseId());
                    files.add(faf);
                }
            }
            Collections.sort(files, new FileAreaFileComparator(filter));
        }

        return files;
    }

    /**
     * Scan for file and/or directories beneath a file area path.
     * @param areaPath
     *            String path to scan for files/directories.
     * @param flags
     *            int bitwise options associated with the scan command.
     * @param attrNos
     *            int[] attributes required for the returned files/directories.
     * @return Object result from executing the scan area RPC command.
     */
    public static Object scanArea(String areaPath, int flags, int[] attrNos, String[] inclusions) throws AttrException,
            AdmException {

        Cmd cmd = new RPCScanAreaCmd();
        cmd.setAttrValue("areapath", areaPath);

        // add flag for whether we want files and/or directories
        cmd.setAttrValue("flags", new Integer(flags));

        // add required attributes
        cmd.setAttrValue("attrnos", attrNos);

        // add inclusion patterns
        if (inclusions != null) {
            cmd.setAttrValue("inclusionpatterns", inclusions);
        }

        // scan for directories and/or files
        return cmd.execute();
    }

    /**
     * Create a Dimensions FileAreaFile object from a full path.
     * @param filePath
     *            the full path (including area node and '::') of the file.
     * @return FileAreaFile the dimensions object corresponding to the filePath.
     * @throws AdmObjectException
     *             if the filePath is invalid.
     */
    public static FileAreaFile createFileAreaFile(String filePath) throws AdmObjectException {
        FileAreaFile faf = null;
        if ((filePath != null)) {
            if (filePath.indexOf("::") != -1) {
                faf = new FileAreaFile(new AdmSpec(filePath, FileAreaFile.class));
            } else {
                throw new AdmObjectException("The file path does not correspond to a file area file.");
            }
        }
        return faf;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import com.serena.dmnet.PcmsRSAttrs;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Get the role section names via Message Server
 */
public class RPCPcmsGetRSAttrs extends RPCCmd {
    /** Used to request the default role section name */
    public static final String DEFAULT = "$DEFAULT";

    public RPCPcmsGetRSAttrs() throws AdmObjectException, AttrException {
        super();
        setAlias("RPC GetRSAttrs");
        AddArgument("cmd", "PcmsGetRSAttrs");
        setAttrDef(new CmdArgDef("uidObject", true, AdmUidObject.class));
        setAttrDef(new CmdArgDef("typeObject", true, AdmUidObject.class));
        setAttrDef(new CmdArgDef("role", true, "", "", ""));
        setAttrDef(new CmdArgDef("status", true, "", "", ""));
        setAttrDef(new CmdArgDef("user", true, "", "", ""));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            String role = (String) getAttrValue("role");
            AdmUidObject uidObject = (AdmUidObject) getAttrValue("uidObject");
            long uidObjectUid = uidObject == null ? 0 : uidObject.getAdmUid().getUid();
            PcmsRSAttrs rsAttrs = getSession().getConnection().rpcPcmsGetRSAttrs(uidObjectUid,
                    ((AdmUidObject) getAttrValue("typeObject")).getAdmUid().getUid(), (String) getAttrValue("role"),
                    (String) getAttrValue("status"), (String) getAttrValue("user"));

            String ret;

            if (rsAttrs != null) {
                ret = Constants.SERVER_OK;

                if (role != null && role.equals("$DEFAULT")) {
                    ret += rsAttrs.getroleSection();
                }

                int[] attrs = rsAttrs.getAttrs();
                for (int i = 0; i < attrs.length; i++) {
                    if (i == 0) {
                        ret += attrs[i];
                    } else {
                        ret += " " + attrs[i];
                    }
                }
            } else {
                ret = Constants.SERVER_ERROR;
            }

            return ret;

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

    }

}

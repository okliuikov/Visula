/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.serena.dmfile.StringPath;
import com.serena.dmfile.dto.Triplet;
import com.serena.dmnet.drs.DRSClientGenerateStreamInitials;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;

public class ProjectHelper {

    public static List<AdmObject> getProjectsFromUids(Collection<Long> projectUids) throws DimBaseException, AdmObjectException,
            AttrException, AdmException {

        List<AdmBaseId> ids = new ArrayList<AdmBaseId>();
        for (Long uid : projectUids) {
            ids.add(AdmCmd.newAdmBaseId(uid, WorkSet.class));
        }

        @SuppressWarnings("unchecked")
        List<AdmObject> worksets = AdmCmd.getObjects(ids);
        return worksets;
    }

    public static List<AdmObject> getProjectsFromSpecs(Collection<String> projectNames) throws DimBaseException,
            AdmObjectException, AttrException, AdmException {

        List<AdmBaseId> ids = new ArrayList<AdmBaseId>();
        for (String name : projectNames) {
            ids.add(AdmCmd.newAdmBaseId(name, WorkSet.class));
        }

        @SuppressWarnings("unchecked")
        List<AdmObject> worksets = AdmCmd.getObjects(ids);
        return worksets;
    }

    public static Triplet<String, String, String> queryDerivedStreamInitials(String baseSpec, String workArea, String folder)
            throws AdmException {
        Triplet<String, String, String> result = new Triplet<String, String, String>();
        DRSClientGenerateStreamInitials query = new DRSClientGenerateStreamInitials();

        if (StringPath.isNullorEmpty(baseSpec)) {
            throw new AdmException("Specification of base stream should not be null or empty.");
        }

        query.setBaseSpec(baseSpec);
        query.setWorkArea(workArea);
        query.setFolder(folder);

        DRSUtils.execute(query);

        if (query.hasData()) {
            String streamId = query.getStreamId();
            String branchId = query.getBranchId();
            String description = query.getDescription();

            result.setFirst(streamId != null ? streamId : "");
            result.setSecond(branchId != null ? branchId : "");
            result.setThird(description != null ? description : "");
        } else {
            result.setFirst("");
            result.setSecond("");
            result.setThird("");
        }

        return result;
    }

}

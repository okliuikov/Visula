/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Release.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Identifier of the new release</dd>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of container for the new release</dd>
 *  <dt>RELEASE_BLN_ID {String}</dt><dd>Baseline spec of the new release</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}</dt><dd>Description of the new release</dd>
 *  <dt>DIRECTORY {String}</dt><dd>Directory of the new release</dd>
 *  <dt>EXPAND {Boolean}</dt><dd>Expands header substitution variables</dd>
 *  <dt>FILENAME {String}</dt><dd>Filename of the new release</dd>
 *  <dt>OVERWRITE {Boolean}</dt><dd>Should the Fetch overwrite a writeable file on disk</dd>
 *  <dt>RELEASE {Release}</dt><dd>Previous release to delta the new release against</dd>
 *  <dt>TEMPLATE_ID {String}</dt><dd>Template id of the new release</dd>
 *  <dt>TOUCH {Boolean}</dt><dd>Updates the modification time to the current system time</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateReleaseCmd extends RPCExecCmd {
    public CreateReleaseCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELEASE_BLN_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DIRECTORY, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.EXPAND, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILENAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.OVERWRITE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELEASE, false, Release.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TEMPLATE_ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.TOUCH, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    private String filename;

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String baselineId = (String) getAttrValue(AdmAttrNames.RELEASE_BLN_ID);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String dir = (String) getAttrValue(CmdArguments.DIRECTORY);
        boolean expand = ((Boolean) getAttrValue(CmdArguments.EXPAND)).booleanValue();
        filename = (String) getAttrValue(CmdArguments.FILENAME);
        boolean overwrite = ((Boolean) getAttrValue(CmdArguments.OVERWRITE)).booleanValue();
        AdmObject release = (AdmObject) getAttrValue(CmdArguments.RELEASE);
        String templateId = (String) getAttrValue(AdmAttrNames.TEMPLATE_ID);
        boolean touch = ((Boolean) getAttrValue(CmdArguments.TOUCH)).booleanValue();

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id);
        _cmdStr = "REL " + Encoding.escapeDMCLI((String) getAttrValue(CmdArguments.INT_SPEC));
        _cmdStr += " /BASELINE=" + Encoding.escapeDMCLI(baselineId);
        _cmdStr += ((desc != null) && (desc.length() > 0)) ? " /DESCRIPTION=" + Encoding.escapeDMCLI(desc) : "";
        _cmdStr += ((dir != null) && (dir.length() > 0)) ? " /DIRECTORY=" + Encoding.escapeDMCLI(dir) : "";
        _cmdStr += (expand) ? " /EXPAND" : " /NOEXPAND";
        _cmdStr += ((filename != null) && (filename.length() > 0)) ? " /FILENAME=" + Encoding.escapeDMCLI(filename) : "";
        _cmdStr += (overwrite) ? " /OVERWRITE" : "";
        _cmdStr += (release != null) ? " /DELTA /PREV_RELEASE=" + Encoding.escapeDMCLI(release.getId()) : "";
        _cmdStr += ((templateId != null) && (templateId.length() > 0)) ? " /TEMPLATE_ID=" + Encoding.escapeDMCLI(templateId) : "";
        _cmdStr += (touch) ? " /TOUCH" : "";
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        AdmResult retResult = new AdmResult(executeRpc());
        if ((filename == null) || (filename.length() < 1)) {
            AdmCmd.populateBaseIdFromAdmResult(this, retResult, Release.class);
        }
        return retResult;
    }
}

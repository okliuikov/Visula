/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.system.PasswordAuthPointInfo;
import merant.adm.dimensions.system.PasswordAuthPointParam;
import merant.adm.exception.AdmException;
import merant.adm.framework.Cmd;

/**
 * This class contains helper methods for sensitivity checks.
 */
public class SensitivityHelper {

    /**
     * Checks whether any states on a lifecycle are sensitive
     * @param lifecycleId
     *            lifecycle id
     * @return true if any states of the lifecycle are sensitive, false otherwise
     */
    public static boolean doesLifecycleHaveSensitiveStates(String lifecycleId) throws AdmException {
        DBIO dbSen = new DBIO("SELECT 'x' FROM lc_state_info WHERE lifecycle_id = :I1 AND sensitive = 'Y'");
        dbSen.bindInput(lifecycleId);
        dbSen.readStart();
        boolean anySensitive = dbSen.read();
        dbSen.close();
        return anySensitive;
    }

    /**
     * Checks whether any attributes related to a Type are sensitive
     * @param typeUid
     *            the objects type uid
     * @return true if any of the attributes related to the Type are sensitive, false otherwise
     */
    public static boolean doesTypeHaveSensitiveAttributes(long typeUid) throws AdmException {
        DBIO dbSen = new DBIO("SELECT 'x' FROM user_obj_attributes WHERE type_uid = :I1 AND sensitive = 'Y'");
        dbSen.bindInput(typeUid);
        dbSen.readStart();
        boolean anySensitive = dbSen.read();
        dbSen.close();
        return anySensitive;
    }

    /**
     * Gets user authentication
     * @param cmd
     *            The command being run
     */
    public static void getAuthentication(AdmCmd cmd, PasswordAuthPointParam paramObj) throws AdmException {
        Cmd authPointCmd = AdmCmd.getCmd(Server.AUTH_POINT_INFO_REQUESTED);
        if ((PasswordAuthPointInfo) cmd.getAttrValue(CmdArguments.AUTH_POINT_INFO) != null) {
            authPointCmd.setAttrValue(CmdArguments.AUTH_POINT_INFO, cmd.getAttrValue(CmdArguments.AUTH_POINT_INFO));
        }
        authPointCmd.setAttrValue(CmdArguments.AUTH_POINT_PARAM, paramObj);
        Object authPointStatus = authPointCmd.execute();
    }

    /**
     * Checks whether the sensitivity of an attribute has changed
     * @param userSelection
     *            selection to check
     * @param attrNo
     *            attribute number
     * @param typeUid
     *            type uid related to the attribute
     * @return true if the sensitivity of an attribute has changed, false otherwise
     */
    public static boolean hasAttributeSensitivityChanged(boolean userSelection, int attrNo, long typeUid) throws AdmException {
        DBIO dbSen = new DBIO("SELECT NVL(sensitive,'N') FROM user_obj_attributes WHERE attr_no = :I1 AND type_uid = :I2");
        dbSen.bindInput(attrNo);
        dbSen.bindInput(typeUid);

        boolean curIsSensitive = false;
        dbSen.readStart();
        if (dbSen.read()) {
            String tmpIsSensitive = dbSen.getString(1);
            if ("Y".equals(tmpIsSensitive)) {
                curIsSensitive = true;
            }
        }
        dbSen.close();
        return (curIsSensitive != userSelection);
    }

    /**
     * Checks whether the sensitivity of a lifecycle state has changed
     * @param userSelection
     *            selection to check
     * @param lifecycleId
     *            lifecycle id
     * @param status
     *            lifecycle state to check
     * @return true if the sensitivity of a lifecycle state has changed, false otherwise
     */
    public static boolean hasLifecycleStateSensitivityChanged(boolean userSelection, String lifecycleId, String status)
            throws AdmException {
        DBIO dbSen = new DBIO("SELECT NVL(sensitive,'N') FROM lc_state_info WHERE lifecycle_id = :I1 AND status = :I2");
        dbSen.bindInput(lifecycleId);
        dbSen.bindInput(status);

        boolean curIsSensitive = false;
        dbSen.readStart();
        if (dbSen.read()) {
            String tmpIsSensitive = dbSen.getString(1);
            if ("Y".equals(tmpIsSensitive)) {
                curIsSensitive = true;
            }
        }
        dbSen.close();
        return (curIsSensitive != userSelection);
    }

    /**
     * Checks whether an attribute is sensitive
     * @param attrNo
     *            attribute number
     * @param typeUid
     *            type uid related to the attribute
     * @return true if attribute is sensitive, false otherwise
     */
    public static boolean isAttributeSensitive(int attrNo, long typeUid) throws AdmException {
        DBIO dbSen = new DBIO("SELECT NVL(sensitive,'N') FROM user_obj_attributes WHERE attr_no = :I1 AND type_uid = :I2");
        dbSen.bindInput(attrNo);
        dbSen.bindInput(typeUid);

        boolean isSensitive = false;
        dbSen.readStart();
        if (dbSen.read()) {
            String tmpIsSensitive = dbSen.getString(1);
            if ("Y".equals(tmpIsSensitive)) {
                isSensitive = true;
            }
        }
        dbSen.close();
        return isSensitive;
    }

    /**
     * Checks whether a lifecycle state is sensitive
     * @param lifecycleId
     *            lifecycle id
     * @param status
     *            lifecycle state to check
     * @return true if lifecycle state is sensitive, false otherwise
     */
    public static boolean isLifecycleStateSensitive(String lifecycleId, String status) throws AdmException {
        DBIO dbSen = new DBIO("SELECT NVL(sensitive,'N') FROM lc_state_info WHERE lifecycle_id = :I1 AND status = :I2");
        dbSen.bindInput(lifecycleId);
        dbSen.bindInput(status);

        boolean isSensitive = false;
        dbSen.readStart();
        if (dbSen.read()) {
            String tmpIsSensitive = dbSen.getString(1);
            if ("Y".equals(tmpIsSensitive)) {
                isSensitive = true;
            }
        }
        dbSen.close();
        return isSensitive;
    }
}

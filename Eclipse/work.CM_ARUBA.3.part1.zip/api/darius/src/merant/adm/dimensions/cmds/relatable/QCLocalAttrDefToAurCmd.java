/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.AttributeUpdateRule;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.UpdateRulesObject;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

/**
 * Queries all AttributeUpdateRules's related to the LocalAttributeDefinition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class QCLocalAttrDefToAurCmd extends QueryRelsCmd {
    public QCLocalAttrDefToAurCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LocalAttributeDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(AttributeUpdateRule.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        int attrNo = ((Integer) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_ATTRNO)).intValue();
        long typeUid = -1;

        // special handling for PCMS_CHDOC_DETAIL_DESC
        if (attrNo == Constants.ATTRDEF_PCMS_CHDOC_DETAIL_DESC_UID) {
            typeUid = ((Long) admObj.getAttrValue(AdmAttrNames.ATTRDEF_TYPE_UID)).longValue();
        } else {
            typeUid = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_TYPE_UID)).longValue();
        }

        AdmObject parentType = getTypeFromUID(typeUid);
        long ruleUid = getRuleObjectUid(parentType);

        List ret = new ArrayList();
        DBIO query = getDBIO(ruleUid, attrNo, filter);
        if (query == null) {
            return ret;
        }

        query.readStart();
        while (query.read()) {
            String roleName = query.getString(3);
            String curStatus = query.getString(4);
            String newStatus = query.getString(5);
            String spec = ruleUid + ":" + attrNo + ":" + roleName;
            if (curStatus != null) {
                spec += ":" + curStatus;
                if (newStatus != null) {
                    spec += ":" + newStatus;
                }
            }

            addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(spec, admSecClass));
        }

        return ret;
    }

    private long getRuleObjectUid(AdmObject typeObj) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, typeObj);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, UpdateRulesObject.class);
        AdmBaseId ruleBaseId = (AdmBaseId) cmd.execute();

        if (ruleBaseId == null) {
            // create rules object
            cmd = AdmCmd.getCmd(Creatable.CREATE, UpdateRulesObject.class);
            cmd.setAttrValue(AdmAttrNames.TYPE, typeObj);
            AdmResult cmdResult = (AdmResult) cmd.execute();
            ruleBaseId = (AdmBaseId) cmdResult.getUserData();
            if (ruleBaseId == null) {
                throw new DBIOException("Error: failed to create attribute update rules object");
            }
        }

        AdmObject rulesObj = AdmHelperCmd.getObject(ruleBaseId, AdmAttrNames.ADM_UID);
        long rulesObjectUid = ((AdmUidObject) rulesObj).getAdmUid().getUid();
        return rulesObjectUid;
    }

    private AdmObject getTypeFromUID(long typeUid) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurRootObj(BaseDatabase.class), Type.class);
        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.ADM_UID, new Long(typeUid)));
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        List baseIds = (List) cmd.execute();
        if ((baseIds != null) && (baseIds.size() > 0)) {
            AdmBaseId baseId = (AdmBaseId) baseIds.get(0);
            if (baseId != null) {
                AdmObject typeObj = AdmHelperCmd.getObject(
                        baseId,
                        Arrays.asList(new String[] { AdmAttrNames.ADM_SPEC, AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID,
                                AdmAttrNames.PARENT_CLASS }));

                return typeObj;
            }
        }

        return null;
    }

    private DBIO getDBIO(long ruleUid, int attrNo, FilterImpl filter) throws AdmException {
        String roleName = null;
        String curStatus = null;
        String newStatus = null;
        String isDisplayable = null;
        String isMandatory = null;
        String isUpdatable = null;

        StringBuffer sb = new StringBuffer();
        sb.append("SELECT ca.obj_uid, ca.attr_1, ca.attr_2, ca.attr_3, ca.attr_7, ");
        sb.append("NVL(ca.attr_6,'N'), NVL(ca.attr_4,'N'), NVL(ca.attr_5,'N') FROM cpl_attributes ca ");
        sb.append(" WHERE ca.obj_uid=:I1 AND ca.attr_1=TO_CHAR(:I2)");

        if (filter != null) {
            for (Iterator it = filter.criteria().iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit.getValue() == null) {
                    continue;
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_OBJECT_UID)) {
                    if (((Long) crit.getValue()).longValue() != ruleUid) {
                        return null;
                    }
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_ROLE_NAME)) {
                    sb.append(" AND ca.attr_2 = :I3");
                    roleName = (String) crit.getValue();
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_ATTRNO)) {
                    if (((Integer) crit.getValue()).intValue() != attrNo) {
                        return null;
                    }
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_CURRENT_STATUS)) {
                    // VADYMK: ensure that we can handle NULLs
                    sb.append(" AND NVL(ca.attr_3,'$$$&&&') = :I4");
                    curStatus = (String) crit.getValue();
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_NEW_STATUS)) {
                    // VADYMK: ensure that we can handle NULLs
                    sb.append(" AND NVL(ca.attr_7,'$$$&&&') = :I5");
                    newStatus = (String) crit.getValue();
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_IS_DISPLAYABLE)) {
                    sb.append(" AND NVL(attr_6,'N') = :I6");
                    if (((Boolean) crit.getValue()).booleanValue()) {
                        isDisplayable = "Y";
                    } else {
                        isDisplayable = "N";
                    }
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_IS_MANDATORY)) {
                    sb.append(" AND NVL(attr_4,'N') = :I7");
                    if (((Boolean) crit.getValue()).booleanValue()) {
                        isMandatory = "Y";
                    } else {
                        isMandatory = "N";
                    }
                }

                if (crit.getAttrName().equals(AdmAttrNames.ATTRRULE_IS_UPDATABLE)) {
                    sb.append(" AND NVL(attr_5,'N') = :I8");
                    if (((Boolean) crit.getValue()).booleanValue()) {
                        isUpdatable = "Y";
                    } else {
                        isUpdatable = "N";
                    }
                }
            }

            if (filter.orders().size() > 0) {
                sb.append(" ORDER BY ");
                boolean first = true;
                for (Iterator it = filter.orders().iterator(); it.hasNext();) {
                    if (first) {
                        first = false;
                    } else {
                        sb.append(", ");
                    }

                    FilterOrder order = (FilterOrder) it.next();
                    if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_OBJECT_UID)) {
                        sb.append("1");
                    } else if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_ATTRNO)) {
                        sb.append("2");
                    } else if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_ROLE_NAME)) {
                        sb.append("3");
                    } else if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_CURRENT_STATUS)) {
                        sb.append("4");
                    } else if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_NEW_STATUS)) {
                        sb.append("5");
                    } else if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_IS_DISPLAYABLE)) {
                        sb.append("6");
                    } else if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_IS_MANDATORY)) {
                        sb.append("7");
                    } else if (order.getAttrName().equals(AdmAttrNames.ATTRRULE_IS_UPDATABLE)) {
                        sb.append("8");
                    }

                    switch (order.getFlags()) {
                    case FilterOrder.ASCENDING:
                        sb.append(" ASC");
                        break;
                    case FilterOrder.DESCENDING:
                        sb.append(" DESC");
                        break;
                    default:
                        break;
                    }
                }
            }
        }

        String queryStr = sb.toString();
        DBIO query = new DBIO(queryStr);
        query.bindInput(ruleUid);
        query.bindInput(attrNo);

        if (filter != null) {
            // Can be null so use appropriate implementation
            query.bindInput(roleName, String.class);
            query.bindInput(curStatus, String.class);
            query.bindInput(newStatus, String.class);
            query.bindInput(isDisplayable, String.class);
            query.bindInput(isMandatory, String.class);
            query.bindInput(isUpdatable, String.class);
        }

        return query;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Cancel check out for a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILENAME {String}<dt><dd>Specifies the name of the workset filename</dd>
 *  <dt>WORKSET {WorkSet}<dt><dd>Specifies the workset containing the object to cancel</dd>
 *  <dt>USER_FILE {String}<dt><dd>Specifies the local file name where the checked out item is located now (might have changed)</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class CancelCheckOutCmd extends RPCExecCmd {
    public CancelCheckOutCmd() throws AttrException {
        super();
        setAlias(Versionable.CANCEL);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILENAME, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        // CIU defaults to KEEP
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WRITE_METADATA, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.PERMS, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Item)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String filename = (String) getAttrValue(CmdArguments.FILENAME);
        WorkSet workset = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        String userFileName = (String) getAttrValue(CmdArguments.USER_FILE);
        boolean keep = ((Boolean) getAttrValue(CmdArguments.KEEP)).booleanValue();
        boolean metaData = ((Boolean) getAttrValue(CmdArguments.WRITE_METADATA)).booleanValue();
        String perms = (String) getAttrValue(CmdArguments.PERMS);

        if (admObj instanceof Item) {
            _cmdStr = "CIU ";
        }

        _cmdStr += Encoding.escapeSpec(admObj.getAdmSpec().getSpec());

        String id = (String) admObj.getAttrValue(AdmAttrNames.ID);
        if (((id == null) || (id.length() == 0)) && (filename != null) && (filename.length() > 0)) {
            _cmdStr += " /FILENAME=" + Encoding.escapeSpec(filename);
        }

        if (workset != null) {
            _cmdStr += " /WORKSET=" + Encoding.escapeSpec(workset.getAdmSpec().getSpec());
        }

        if (userFileName != null && userFileName.length() > 0) {
            _cmdStr += " /USER_FILENAME=" + Encoding.escapeSpec(userFileName);
        }

        _cmdStr += (keep) ? " /KEEP" : " /NOKEEP";

        _cmdStr += metaData ? "" : " /NOMETADATA";

        if (perms != null && perms.length() > 0) {
            _cmdStr += " /PERMS=" + Encoding.escapeDMCLI(perms);
        }
    }
    
    @Override
    public Object execute() throws AdmException {
        return executeRpc();
    }
    
}

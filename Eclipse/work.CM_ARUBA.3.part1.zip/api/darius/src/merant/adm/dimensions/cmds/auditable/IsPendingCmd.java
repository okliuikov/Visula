/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.auditable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Determines if the specified Dimensions object is pending the User.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions object for pending status check</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>USER {User}</dt><dd>Dimensions user object for the pending status check (defaults to current user)</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Boolean}</dt><dd>Returns true if the Dimensions object is pending the user.</dd>
 * </dl></code>
 * @author Floz
 */
public class IsPendingCmd extends DBIOCmd {
    public IsPendingCmd() throws AttrException {
        super();
        setAlias(Auditable.IS_PENDING);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER, false, AdmCmd.getCurRootObj(User.class), User.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Baseline)) && (!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof Item))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        User user = (User) getAttrValue(CmdArguments.USER);

        DBIO query = null;
        if (admObj instanceof Baseline) {
            query = new DBIO(wcm_sql.IS_PENDING_BLINE);
        } else if (admObj instanceof ChangeDocument) {
            query = new DBIO(wcm_sql.IS_PENDING_CHDOC);
        } else if (admObj instanceof Item) {
            query = new DBIO(wcm_sql.IS_PENDING_ITEM);
        }

        query.bindInput(user.getAdmSpec().getSpec());
        query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
        query.readStart();
        boolean ret = query.read();
        query.close();
        return Boolean.valueOf(ret);
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.dao.ValidsetDAO;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Validset;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Validset.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new validset</dd>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Product to create the Validset</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>VALIDSET_NUM_COLS {Integer}<dt>
 *  <dd>
 *    The number of columns in the validset. This argument is required unless BASED_ON is specified
 *  </dd>
 *  <dt>DESCRIPTION {String}<dt><dd>Description for the new validset</dd>
 *  <dt>VALIDSET_VALIDATION_ERR_MSG {String}<dt><dd>Validation error message</dd>
 *  <dt>BASED_ON {Validset}<dt>
 *  <dd>
 *     An existing validset object on which the new one is to be based. If this argument is specified,
 *     then VALIDSET_NUM_COLS, if specified, wil be ignored.
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateValidsetCmd extends DBIOCmd {
    public CreateValidsetCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VALIDSET_NUM_COLS, false, new Integer(1), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VALIDSET_VALIDATION_ERR_MSG, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASED_ON, false, Validset.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        final String id = ValidationHelper.validateValidsetId((String) getAttrValue(AdmAttrNames.ID));

        final String description = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));

        final String validationErrorMessage = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.VALIDSET_VALIDATION_ERR_MSG));

        final Integer numColumns = ValidationHelper.validateValidsetNumCols((Integer) getAttrValue(AdmAttrNames.VALIDSET_NUM_COLS));

        final String productName = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.PRODUCT_NAME));

        final Validset basedOn = (Validset) getAttrValue(CmdArguments.BASED_ON);

        if (!DoesExistHelper.productExists(productName)) {
            throw new DimAlreadyExistsException("Error: product " + productName + " does not exist.");
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_VALIDSETMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_VALIDSETMAN", productName);
        }

        if (DoesExistHelper.validsetExists(productName, id)) {
            throw new DimAlreadyExistsException("Error: valid set " + productName + ":" + id + " already exists.");
        }

        Integer parentNumColumns = null;
        if (basedOn != null) {
            String parentProductName = (String) AdmHelperCmd.getAttributeValue(basedOn, AdmAttrNames.PRODUCT_NAME);
            String parentValidsetName = basedOn.getId();
            if (!DoesExistHelper.validsetExists(parentProductName, parentValidsetName)) {
                throw new DimAlreadyExistsException("Error: valid set " + parentProductName + ":" + parentValidsetName
                        + " does not exists.");
            }

            parentNumColumns = (Integer) AdmHelperCmd.getAttributeValue(basedOn, AdmAttrNames.VALIDSET_NUM_COLS);
        }
        final int numCols1 = parentNumColumns != null ? parentNumColumns.intValue() : numColumns.intValue();
        final long parentVsUid = basedOn != null ? ((AdmUidObject) basedOn).getUid() : -1;

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id);

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {

                ValidsetDAO dao = new ValidsetDAO(dbCtx);

                long vsUid = dao.getNewUid();

                dao.create(vsUid, id, productName, numCols1, description, validationErrorMessage);

                if (basedOn != null) {
                    dao.copyValues(vsUid, parentVsUid);
                }
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Validset.class);
        return retResult;
    }
}

/*
 * Copyright 2006, 2007 Serena Software, Inc.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.serena.dmnet.drs.DRSClientQCDimDirToDimDir;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.AdmUidObjectImpl;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries DimDirectory objects related to the specified DimDirectory object.<br/>
 * If the recursive flag is set then ALL the dirs and subdirs for the DimDirectory object are returned
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions project container for objects</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>AdmAttrNames.RELTYPE_IS_DEFAULT</dt><dd>Reltype is default</dd>
 *  <dt>AdmAttrNames.RELTYPE_IS_PEDIGREE</dt><dd>Reltype is pedigree</dd>
 *  <dt> "COUNT"</dt><dd>Count</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>CmdArguments.RECURSIVE {Boolean}</dt><dd>If true, will get dirs and all sub-dirs recursively from parent dir</dd>
 *  <dt>CmdArguments.INCLUDE_ROOT (Boolean)</dt><dd>If true, will include the root of the query in the results. Defaults to true</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * 
 * @author PaulS
 */
public class QCDimDirToDimDirCmd extends QueryRelsCmd {
    public QCDimDirToDimDirCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.RECURSIVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.INCLUDE_ROOT, false, Boolean.TRUE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof DimDirectory)) {
                throw new AttrException("Error: QCDimDirToDimDirCmd - this parent object type is not supported!", attrDef,
                        attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(DimDirectory.class))) {
                throw new AttrException("Error: QCDimDirToDimDirCmd - this child object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();
        Class admChildClass = (Class) getAttrValue(CmdArguments.ADM_CHILD_CLASS);

        Boolean isRecursive = ((Boolean) getAttrValue(CmdArguments.RECURSIVE));
        Boolean includeRoot = ((Boolean) getAttrValue(CmdArguments.INCLUDE_ROOT));
        if (includeRoot == null) {
            includeRoot = Boolean.TRUE;
        }

        // Go through the usual super query route
        if (!isRecursive.booleanValue()) {
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_RELS, admObj, admChildClass);

            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, getAttrValue(CmdArguments.ADM_CHILD_CLASS));
            cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
            cmd.setAttrValue(CmdArguments.RELATIONSHIPS, getAttrValue(CmdArguments.RELATIONSHIPS));
            cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
            cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT, getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT));
            cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE));
            cmd.setAttrValue("COUNT", getAttrValue("COUNT"));
            return (List) cmd.execute();
        }

        ArrayList subDirs = new ArrayList();
        long dirUid = ((AdmUidObject) admObj).getAdmUid().getUid();

        AdmBaseId containerAdmBaseId = admObj.getAdmBaseId().getScope();
        AdmUid containerAdmUid = ((AdmUidObject) AdmHelperCmd.getObject(containerAdmBaseId)).getAdmUid();
        long containerUid = containerAdmUid.getUid();
        Class<? extends AdmUidObjectImpl> containerClass = containerAdmBaseId.getObjType();

        DRSClientQCDimDirToDimDir dg = new DRSClientQCDimDirToDimDir(DRSUtils.getLCNetClntObject());
        dg.setContainerUid(containerUid);
        dg.setDirUid(dirUid);
        dg.setIncludeRoot(includeRoot);

        boolean isCorrectType = false;
        if (containerClass.equals(WorkSet.class)) {
            dg.setContainerType(pcmsApiMap.get("WorkSet"));
            isCorrectType = true;
        } else if (containerClass.equals(Baseline.class)) {
            dg.setContainerType(pcmsApiMap.get("Baseline"));
            isCorrectType = true;
        }

        if (isCorrectType) {
            DRSOutputDataExtractor output = new DRSQuery(dg).execute();
            if (!output.isResultEmpty()) {
                int[] uids = output.getIntValues(DRSParams.DIR_UIDS);
                String[] pathes = output.getStringValues(DRSParams.DIR_PATHES);
                for (int i = 0; i < uids.length; i++) {
                    addRelation(
                            ret,
                            relationships,
                            admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(uids[i], admSecClass, containerAdmUid,
                                    AdmHelperCmd.newAdmBaseId(pathes[i], admSecClass, null, null)));
                }
            }
        }
        return ret;
    }
}

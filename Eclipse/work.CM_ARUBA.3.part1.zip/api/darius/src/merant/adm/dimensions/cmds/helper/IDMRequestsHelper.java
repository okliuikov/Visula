/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2019 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.helper;

import com.serena.dmnet.drs.DRSClientChangeRequests;
import com.serena.dmnet.drs.DRSClientIdmUtils;
import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.helper.IDMRequestsHelper;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.*;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;

import java.util.*;

public class IDMRequestsHelper {

    public static final String COLUMN_TITLE_CREATE_DATE = "Create Date";
    public static final String COLUMN_TITLE_UPDATE_DATE = "Update Date";
    public static final String COLUMN_TITLE_TITLE = "Title";
    public static final String COLUMN_TITLE_TYPE = "Type";
    public static final String COLUMN_TITLE_STATUS = "Status";
    public static final String COLUMN_TITLE_RELATIONSHIP = "Relationship";
    public static final String COLUMN_TITLE_OWNER = "Owner";
    public static final String COLUMN_TITLE_AUTHOR = "Author";
    public static final String COLUMN_TITLE_ID = "External ID";
    public static final String COLUMN_TITLE_SPEC = "Name";
    public static final String COLUMN_TITLE_DESCRIPTION = "Description";
    public static final String COLUMN_TITLE_BROWSE_URL = "Browse URL";
    public static final String N_A = "N/A";
    public static final String COLUMN_SORT_DESC_KEY = "desc";
    public static final int COLUMN_SORT_ASC = 1;
    public static final int COLUMN_SORT_DESC = 0;

    public static IDMUtilsHelper.ExternalRequestPage queryExtRequestsByReportId(String reportId,
                                                                                long prodUid,
                                                                                long toolUid,
                                                                                Map<Long, Integer> attrMap,
                                                                                int filterFlags,
                                                                                int sortAttr,
                                                                                int sortOrder,
                                                                                List<Long> paginationInfo,
                                                                                Collection<FilterCriterion> criteria
    ) throws Exception {
        List<Long> filterAttrs = new ArrayList<Long>();
        List<String> filterVals = new ArrayList<String>();
        prepareDRSFiltersByCriteria(toolUid, prodUid, criteria, filterAttrs, filterVals);

        return queryExternalRequestsByReportId(
                prodUid,
                toolUid,
                filterAttrs,
                filterVals,
                filterFlags,
                sortAttr,
                sortOrder,
                attrMap,
                paginationInfo,
                new ArrayList<String>(),
                reportId
        );
    }

    public static void prepareDRSFiltersByCriteria(long toolUid, long prodUid, Collection<FilterCriterion> criteria,
                                                   List<Long> filterAttrs, List<String> filterVals) {
        if (criteria != null && !criteria.isEmpty()) {
            for (FilterCriterion criterion : criteria) {
                Long drsAttr = remapToDrsAttr(criterion.getAttrName());
                if (drsAttr != null) {
                    filterAttrs.add(drsAttr);
                    boolean bAddPercents = false;
                    // Octane Title field filter should use %like% format to search as "Contains" condition
                    if (drsAttr == DRSClientIdmUtils.ATTR_TITLE) {
                        RequestProvider provider = IDMUtilsHelper.getRequestProvider(toolUid, prodUid, Constants.INVALID_UID);
                        if (provider != null)
                            bAddPercents = true;
                    }

                    String val = (String) criterion.getValue();
                    if (bAddPercents)
                        filterVals.add("%" + val + "%");
                    else
                        filterVals.add(val);
                }
            }
        }
    }

    public static List<ExternalRequest> queryExtRequestsAttrs(long prodUid, long toolUid, List<ExternalRequest> relObjs, Map<Long, Integer> attrMap) {
        String[] inIds = {};
        Long[] inUids = new Long[relObjs.size()];
        try {
            for(int i = 0; i < relObjs.size(); i++) {
                inUids[i] = relObjs.get(i).getUid();
            }
            List<ExternalRequest> externalRequests = getIdmRequestsWithAttrs(inIds, inUids, prodUid, toolUid, attrMap);
            if(externalRequests != null && externalRequests.size() > 0) {
                relObjs = enrichExtRequestsAttrs(relObjs, externalRequests, attrMap);
            }
        } catch (AdmException e) {
            Debug.error(e);
            enrichByDefaultAttrs(relObjs, attrMap);
        }
        return relObjs;
    }

    private static List<ExternalRequest> enrichByDefaultAttrs(List<ExternalRequest> relObjs, Map<Long, Integer> attrMap) {
        try {
            for (ExternalRequest relObj : relObjs) {
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_TITLE)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TITLE, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_STATUS)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_STATUS, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_TYPE)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TYPE, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_BROWSE_URL)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_BROWSE_URL, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_ID)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_ID, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_RELATIONSHIP)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_RELATIONSHIP, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_CREATE_DATE)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_CREATE_DATE, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_AUTHOR)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_AUTHOR, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_OWNER)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_OWNER, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_UPDATE_DATE)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_UPDATE_DATE, N_A);
                }
                if (attrMap.containsKey(DRSClientIdmUtils.ATTR_DESCRIPTION)) {
                    relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_DESCRIPTION, N_A);
                }
            }
        } catch (Exception e) {
            Debug.error(e);
        }
        return relObjs;
    }

    private static List<ExternalRequest> enrichExtRequestsAttrs(List<ExternalRequest> relObjs, List<ExternalRequest> externalRequests, Map<Long, Integer> attrMap) throws AdmObjectException {
        for(ExternalRequest relObj : relObjs) {
            for (ExternalRequest externalRequest : externalRequests) {
                if (relObj.getUid() == externalRequest.getUid()) {
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_TITLE)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TITLE, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TITLE));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_STATUS)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_STATUS, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_STATUS));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_TYPE)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TYPE, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TYPE));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_BROWSE_URL)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_BROWSE_URL, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_BROWSE_URL));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_ID)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_ID, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_ID));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_RELATIONSHIP)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_RELATIONSHIP, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_RELATIONSHIP));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_CREATE_DATE)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_CREATE_DATE, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_CREATE_DATE));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_AUTHOR)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_AUTHOR, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_AUTHOR));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_OWNER)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_OWNER, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_OWNER));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_UPDATE_DATE)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_UPDATE_DATE, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_UPDATE_DATE));
                    }
                    if (attrMap.containsKey(DRSClientIdmUtils.ATTR_DESCRIPTION)) {
                        relObj.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_DESCRIPTION, externalRequest.getAttrValue(AdmAttrNames.EXTERNAL_REQUEST_DESCRIPTION));
                    }
                    break;
                }
            }
        }
        return relObjs;
    }

    public static Map<String, Integer> queryExtRequestsByChangeSetUid(Long changeSetUid) {
        Map<String, Integer> result = null;
        if(changeSetUid == null) {
            return result;
        }
        DRSClientChangeRequests drs = new DRSClientChangeRequests();
        drs.setChangeSetUid(changeSetUid);
        try {
            DRSUtils.execute(drs);
            if (drs.hasData()) {
                int[] requestTypes = drs.getObjTypes();
                String[] requestSpecs = drs.getRequestIds();
                int[] requestUids = drs.getRequestUids();
                if(requestTypes != null
                        && requestUids != null
                        && requestSpecs != null
                        && requestTypes.length == requestSpecs.length
                        && requestTypes.length == requestUids.length) {
                    result = new HashMap<String, Integer>(requestSpecs.length);
                    for(int i = 0; i < requestSpecs.length; i++) {
                        if(((Integer) requestTypes[i]).equals(com.serena.dmnet.Constants.PCMS_EXTERNALREQUEST)) {
                            result.put(requestSpecs[i], requestUids[i]);
                        }
                    }
                }
            }
        } catch (Exception e) {
            Debug.error(e);
        }
        return result;
    }

    public static ExternalRequest getIdmRequestByProdOrToolUid(String requestId, long prodUid, long toolUid) throws AdmException {
        return getIdmRequestByProdOrToolUid(requestId, prodUid, toolUid, initAllDRSAttributesMap());
    }

    public static ExternalRequest getIdmRequestByProdOrToolUid(String requestId, long prodUid, long toolUid, Map<Long, Integer> attrs) throws AdmException {
        ExternalRequest result = null;
        String[] inIds = {requestId};
        Long[] inUids = {};
        List<ExternalRequest> externalRequests = getIdmRequestsWithAttrs(inIds, inUids, prodUid, toolUid, attrs);
        if (externalRequests != null && externalRequests.size() > 0) {
            result = externalRequests.get(0);
        }
        return result;
    }

    public static List<ExternalRequest> getIdmRequestsWithAttrs(String[] inIds, Long[] inUids, long prodUid, long toolUid, Map<Long, Integer> attrMap) throws AdmException {
        List<ExternalRequest> externalRequests = null;
        DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetRequestsAttrs);
        List<Long> attrs = new ArrayList<Long>(attrMap.keySet());
        drs.setAttrs(attrs.toArray(new Long[attrs.size()]));
        drs.setInUids(inUids);
        drs.setInIds(inIds);
        drs.setWsetUid(toolUid);
        drs.setProductUid(prodUid);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            List<String> allAttrVals = drs.getAttrVals() != null ? Arrays.asList(drs.getAttrVals()) : new ArrayList<String>();
            String[] ids = drs.getIds();
            int[] uids = drs.getUids();
            if(ids.length > 0) {
                int attrsStart = 0;
                int attrsEnd = attrMap.size();
                List<IDMUtilsHelper.IdmRequestWithAttrs> idmRequests = new ArrayList<IDMUtilsHelper.IdmRequestWithAttrs>(ids.length);
                for(int i = 0; i < ids.length; i++) {
                    int uid = -1;
                    if(uids != null) {
                        uid = uids[i];
                    }
                    idmRequests.add(new IDMUtilsHelper.IdmRequestWithAttrs(-1, uid, null, allAttrVals.subList(attrsStart, attrsEnd),
                            null, null, null));
                    attrsStart = attrsEnd;
                    attrsEnd += attrMap.size();
                }
                externalRequests = mapRequestsList(idmRequests, attrMap);
            }
        }
        return externalRequests;
    }

    public static IDMUtilsHelper.ExternalRequestPage getIdmRequests(long productUid, long toolUid, IDMUtilsHelper.SearchMode searchMode,
                                                       List<String> entities, List<Long> filterAttrs, List<String> filterVals,
                                                       int filterFlags, int sortBy, int sortOrder, List<Long> pgInfo) throws AdmException {
        return search(productUid, toolUid, filterAttrs, filterVals, searchMode, initPickerDRSAttributesMap(),
                null, entities, filterFlags, sortBy, sortOrder, pgInfo);
    }

    public static IDMUtilsHelper.ExternalRequestPage getWorkingListIdmRequests(long requestProviderUid, String userName,
                                                                  List<String> entities, List<Long> filterAttrs,
                                                                  List<String> filterValues, int filterFlags, int sortBy,
                                                                  int sortOrder, List<Long> pgInfo) throws AdmException {
        IDMUtilsHelper.ExternalRequestPage externalRequestPage = new IDMUtilsHelper.ExternalRequestPage();
        Map<Long, Integer> attrMap = initPickerDRSAttributesMap();
        IDMUtilsHelper.IdmRequestPage idmRequestPage = getIdmRequestsBySearchMode(
                requestProviderUid, userName, attrMap, sortBy, sortOrder, pgInfo, entities, filterAttrs,
                filterValues, filterFlags, IDMUtilsHelper.SearchMode.WORKING_LIST);
        List<IDMUtilsHelper.IdmRequestWithAttrs> requests = idmRequestPage.getRequestList();
        externalRequestPage.setRequestList(mapRequestsList(requests, attrMap));
        externalRequestPage.setTotalRequests(idmRequestPage.getTotalRequests());
        return externalRequestPage;
    }

    public static IDMUtilsHelper.IdmRequestPage getIdmRequestsBySearchMode(
            long requestProviderUid, String userName, Map<Long, Integer> attrMap, int sortAttr,
            int sortOrder, List<Long> paginationInfo, Collection<FilterCriterion> criteria, IDMUtilsHelper.SearchMode searchMode) throws AdmException {

        List<Long> filterAttrs = new ArrayList<Long>();
        List<String> filterVals = new ArrayList<String>();
        prepareDRSFiltersByCriteria(requestProviderUid, Constants.INVALID_UID, criteria, filterAttrs, filterVals);

        return getIdmRequestsBySearchMode(requestProviderUid, userName, attrMap, sortAttr, sortOrder, paginationInfo,
                new ArrayList<String>(), filterAttrs, filterVals, DRSClientIdmUtils.IDM_FILTER_DEFAULT_FLAG, searchMode);
    }

    public static IDMUtilsHelper.IdmRequestPage getIdmRequestsBySearchMode(
            long requestProviderUid, String userName, Map<Long, Integer> attrMap, int sortAttr,
            int sortOrder, List<Long> paginationInfo, List<String> entities, List<Long> filterAttrs,
            List<String> filterValues, int filterFlags, IDMUtilsHelper.SearchMode searchMode) throws AdmException {
        return IDMUtilsHelper.searchRequestsWithAttrs(
                searchMode,
                Constants.INVALID_UID,
                requestProviderUid,
                filterAttrs,
                filterValues,
                filterFlags,
                sortAttr,
                sortOrder,
                new ArrayList<Long>(attrMap.keySet()),
                paginationInfo,
                entities,
                new ArrayList<String>(),
                userName
        );
    }

    private static IDMUtilsHelper.ExternalRequestPage search(long productUid, long toolUid, List<Long> filterAttrs,
                                                List<String> filterValues, IDMUtilsHelper.SearchMode searchMode,
                                                Map<Long, Integer> attrMap, String userName, List<String> entities,
                                                int filterFlags, int sortBy, int sortOrder, List<Long> pgInfo) throws AdmException {
        IDMUtilsHelper.IdmRequestPage idmRequestPage = IDMUtilsHelper.searchRequestsWithAttrs(
                searchMode, productUid, toolUid, filterAttrs,
                filterValues, filterFlags, sortBy, sortOrder, new ArrayList<Long>(attrMap.keySet()),
                pgInfo, entities, new ArrayList<String>(), userName);
        List<IDMUtilsHelper.IdmRequestWithAttrs> requests = idmRequestPage.getRequestList();
        IDMUtilsHelper.ExternalRequestPage externalRequestPage = new IDMUtilsHelper.ExternalRequestPage();
        externalRequestPage.setRequestList(mapRequestsList(requests, attrMap));
        externalRequestPage.setTotalRequests(idmRequestPage.getTotalRequests());
        return externalRequestPage;
    }

    public static List<ExternalRequest> mapRequestsList(List<IDMUtilsHelper.IdmRequestWithAttrs> idmRequests, Map<Long,
            Integer> attrMap) throws AdmException {
        if(idmRequests != null && idmRequests.size() > 0) {
            List<ExternalRequest> externalRequestList = new ArrayList<ExternalRequest>(idmRequests.size());
            for (IDMUtilsHelper.IdmRequestWithAttrs idmRequest : idmRequests) {
                ExternalRequest externalRequest = new ExternalRequest();
                AdmUid admUid = new AdmUidTwin(idmRequest.getUid(), ExternalRequest.class);
                externalRequest.setAdmUid(admUid);
                AdmSpec admSpec = new AdmSpecTwin(idmRequest.getAttrValues().get(attrMap.get(DRSClientIdmUtils.ATTR_SPEC)), ExternalRequest.class);
                externalRequest.setAdmSpec(admSpec);
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_TITLE)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TITLE, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_TITLE)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_STATUS)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_STATUS, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_STATUS)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_TYPE)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_TYPE, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_TYPE)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_BROWSE_URL)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_BROWSE_URL, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_BROWSE_URL)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_ID)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_ID, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_ID)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_RELATIONSHIP)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_RELATIONSHIP, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_RELATIONSHIP)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_CREATE_DATE)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_CREATE_DATE, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_CREATE_DATE)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_AUTHOR)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_AUTHOR, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_AUTHOR)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_OWNER)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_OWNER, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_OWNER)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_UPDATE_DATE)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_UPDATE_DATE, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_UPDATE_DATE)));
                }
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_DESCRIPTION)) {
                    externalRequest.setAttrValue(AdmAttrNames.EXTERNAL_REQUEST_DESCRIPTION, idmRequest.getAttrValues()
                            .get(attrMap.get(DRSClientIdmUtils.ATTR_DESCRIPTION)));
                }
                externalRequestList.add(externalRequest);
            }
            return  externalRequestList;
        } else {
            return new ArrayList<ExternalRequest>();
        }
    }

    public static Map<Long, Integer> initPickerDRSAttributesMap() {
        return new LinkedHashMap<Long, Integer>() {{
            put(DRSClientIdmUtils.ATTR_SPEC, 0);
            put(DRSClientIdmUtils.ATTR_TITLE, 1);
            put(DRSClientIdmUtils.ATTR_STATUS, 2);
            put(DRSClientIdmUtils.ATTR_UPDATE_DATE, 3);
            put(DRSClientIdmUtils.ATTR_BROWSE_URL, 4);
            put(DRSClientIdmUtils.ATTR_OWNER, 5);
            put(DRSClientIdmUtils.ATTR_CREATE_DATE, 6);
            put(DRSClientIdmUtils.ATTR_AUTHOR,7);
        }};
    }

    private static Map<Long, Integer> initAllDRSAttributesMap() {
        return new LinkedHashMap<Long, Integer>() {{
            put(DRSClientIdmUtils.ATTR_SPEC, 0);
            put(DRSClientIdmUtils.ATTR_TITLE, 1);
            put(DRSClientIdmUtils.ATTR_STATUS, 2);
            put(DRSClientIdmUtils.ATTR_TYPE, 3);
            put(DRSClientIdmUtils.ATTR_BROWSE_URL, 4);
            put(DRSClientIdmUtils.ATTR_ID, 5);
            put(DRSClientIdmUtils.ATTR_RELATIONSHIP, 6);
            put(DRSClientIdmUtils.ATTR_CREATE_DATE, 7);
            put(DRSClientIdmUtils.ATTR_AUTHOR, 8);
            put(DRSClientIdmUtils.ATTR_OWNER, 9);
            put(DRSClientIdmUtils.ATTR_UPDATE_DATE, 10);
            put(DRSClientIdmUtils.ATTR_DESCRIPTION, 11);
        }};
    }

    public static IDMUtilsHelper.ExternalRequestPage queryExternalRequestsByReportId(final long productUid,
                                                                                     final long toolUid,
                                                                                     final List<Long> filterAttrs,
                                                                                     final List<String> filterValues,
                                                                                     final int filterFlags,
                                                                                     final int sortAttr,
                                                                                     final int sortOrder,
                                                                                     final Map<Long, Integer> attrMap,
                                                                                     final List<Long> paginationInfo,
                                                                                     final List<String> entities,
                                                                                     final String reportId) throws AdmException {
        List<Long> attrs = new ArrayList<Long>(attrMap.keySet());
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetReportRequestsWithAttrs);
        drs.setReportId(reportId);
        drs.setAttrs(attrs.toArray(new Long[attrs.size()]));
        drs.setWsetUid(Constants.INVALID_UID);
        drs.setProductUid(productUid);
        drs.setToolUid(toolUid);
        drs.setFilterFlags(filterFlags);
        drs.setSortAttr(sortAttr);
        drs.setSortOrder(sortOrder);

        if (filterAttrs != null && !filterAttrs.isEmpty()) {
            drs.setFilterAttrs(filterAttrs.toArray(new Long[filterAttrs.size()]));
        } else {
            drs.setFilterAttrs(new Long[] {});
        }

        if (filterValues != null && !filterValues.isEmpty()) {
            drs.setFilterValues(filterValues.toArray(new String[filterValues.size()]));
        } else {
            drs.setFilterValues(new String[] {});
        }

        if (paginationInfo != null && !paginationInfo.isEmpty()) {
            drs.setPaginationInfo(paginationInfo.toArray(new Long[paginationInfo.size()]));
        } else {
            drs.setPaginationInfo(new Long[] {});
        }

        if (entities != null && !entities.isEmpty()) {
            drs.setFilteredEntities(entities.toArray(new String[entities.size()]));
        } else {
            drs.setFilteredEntities(new String[] {});
        }

        DRSUtils.execute(drs);

        IDMUtilsHelper.ExternalRequestPage page = null;
        if (drs.hasData()) {
            page = parseExtReqByReportIdData(drs, new IDMUtilsHelper.ExternalRequestPage(), attrMap);
        }
        return page;
    }

    private static IDMUtilsHelper.ExternalRequestPage parseExtReqByReportIdData(DRSClientIdmUtils drs, IDMUtilsHelper.ExternalRequestPage page, Map<Long, Integer> attrMap) throws AdmException {
        page.setTotalRequests(drs.getTotalRequests());
        if (drs.getAttrVals() == null) {
            return page;
        }
        final int[] outUids = drs.getUids();
        final String[] outColumns = drs.getReportColumns() != null ? drs.getReportColumns() : new String[0];
        final int[] outColumnAttrs = drs.getReportColumnsAttrs() != null ? drs.getReportColumnsAttrs() : new int[0];
        Set<Long> outColumnAttrsSet = new LinkedHashSet<Long>();
        if(outColumnAttrs != null && outColumnAttrs.length > 0) {
            for(int atr : outColumnAttrs) {
                if (atr != 0) {
                    outColumnAttrsSet.add((long) atr);
                }
            }
        }
        Map<Long, Integer> filteredAttrMap = new LinkedHashMap<Long, Integer>();
        for(Long mapAttr : attrMap.keySet()) {
            if(!(outColumnAttrsSet.contains(mapAttr))) {
                filteredAttrMap.put(mapAttr, attrMap.get(mapAttr));
            }
        }
        List<String> titlesList = addCustomizedTitles(outColumns, attrMap, outColumnAttrsSet, outColumnAttrs);
        List columnslist = new ArrayList();
        columnslist.add(titlesList);
        final List<String> allAttrVals = drs.getAttrVals() != null ? Arrays.asList(drs.getAttrVals()) : new ArrayList<String>();
        final List<String> allGridVals = drs.getReportValues() != null ? Arrays.asList(drs.getReportValues()) : new ArrayList<String>();
        int attrsStart = 0;
        int attrsEnd = attrMap.size();
        int gridValStart = 0;
        int gridValEnd = outColumns.length;
        for (int i = 0; i < outUids.length; i++) {
            final List<String> attrsVals = allAttrVals.subList(attrsStart, attrsEnd);
            attrsStart = attrsEnd;
            attrsEnd += attrsVals.size();
            List<String> gridValsWithAttr = new ArrayList<String>();
            if(!allGridVals.isEmpty()) {
                gridValsWithAttr.addAll(allGridVals.subList(gridValStart, gridValEnd));
            }
            gridValStart = gridValEnd;
            gridValEnd += outColumns.length;
            String requestSpec = null;
            if (attrMap.containsKey(DRSClientIdmUtils.ATTR_SPEC)) {
                requestSpec = attrsVals.get(attrMap.get(DRSClientIdmUtils.ATTR_SPEC));
            }
            if (requestSpec != null && !(requestSpec.isEmpty())) {
                page.getRequestList().add(parseIdmReportRow(filteredAttrMap, requestSpec, gridValsWithAttr, columnslist, attrsVals));
            }
        }
        return page;
    }

    private static ExternalRequest parseIdmReportRow(Map<Long, Integer> filteredAttrMap, String requestSpec, List<String> gridValsWithAttr, List columnslist, List<String> attrsVals) throws AdmException {
        ExternalRequest externalRequest = (ExternalRequest) AdmCmd.getObject(AdmCmd.newAdmBaseId(requestSpec, ExternalRequest.class));
        externalRequest.setAttrValue(AdmAttrNames.IDM_NAME, requestSpec);
        externalRequest.setAttrValue(AdmAttrNames.IDM_REQ_COLUMNS, columnslist);
        String[] gridValsArr = new String[0];
        for(Long filteredAttr : filteredAttrMap.keySet()) {
            gridValsWithAttr.add(attrsVals.get(filteredAttrMap.get(filteredAttr)));
        }
        externalRequest.setAttrValue(AdmAttrNames.IDM_REQ_GRIDVALS, gridValsWithAttr.toArray(gridValsArr));
        return externalRequest;
    }

    private static List<String> addCustomizedTitles(String[] outColumns, Map<Long, Integer> attrMap, Set<Long> outColumnAttrsSet, int[] outColumnAttrs) {
        List<String> titlesList = new ArrayList<String>();
        if(outColumns != null && outColumns.length > 0) {
            for(int j= 0; j <  outColumnAttrs.length; j++) {
                titlesList.add(remapColumnTitleByAttr((long) outColumnAttrs[j], outColumns[j]));
            }
        }
        if(attrMap != null && attrMap.size() > 0) {
            for (Integer i = 0; i < attrMap.size(); i++) {
                if(attrMap.containsKey(DRSClientIdmUtils.ATTR_AUTHOR) && attrMap.get(DRSClientIdmUtils.ATTR_AUTHOR).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_AUTHOR))) {
                    titlesList.add(COLUMN_TITLE_AUTHOR);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_OWNER) && attrMap.get(DRSClientIdmUtils.ATTR_OWNER).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_OWNER))) {
                    titlesList.add(COLUMN_TITLE_OWNER);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_RELATIONSHIP) && attrMap.get(DRSClientIdmUtils.ATTR_RELATIONSHIP).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_RELATIONSHIP))) {
                    titlesList.add(COLUMN_TITLE_RELATIONSHIP);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_STATUS) && attrMap.get(DRSClientIdmUtils.ATTR_STATUS).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_STATUS))) {
                    titlesList.add(COLUMN_TITLE_STATUS);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_TYPE) && attrMap.get(DRSClientIdmUtils.ATTR_TYPE).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_TYPE))) {
                    titlesList.add(COLUMN_TITLE_TYPE);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_TITLE) && attrMap.get(DRSClientIdmUtils.ATTR_TITLE).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_TITLE))) {
                    titlesList.add(COLUMN_TITLE_TITLE);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_UPDATE_DATE) && attrMap.get(DRSClientIdmUtils.ATTR_UPDATE_DATE).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_UPDATE_DATE))) {
                    titlesList.add(COLUMN_TITLE_UPDATE_DATE);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_CREATE_DATE) && attrMap.get(DRSClientIdmUtils.ATTR_CREATE_DATE).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_CREATE_DATE))) {
                    titlesList.add(COLUMN_TITLE_CREATE_DATE);
                } else if(attrMap.containsKey(DRSClientIdmUtils.ATTR_SPEC) && attrMap.get(DRSClientIdmUtils.ATTR_SPEC).equals(i) && !(outColumnAttrsSet.contains(DRSClientIdmUtils.ATTR_SPEC))) {
                    titlesList.add(COLUMN_TITLE_SPEC);
               }
            }
        }
        return titlesList;
    }

    private static String remapColumnTitleByAttr(Long attr, String title) {
        if(attr == null) {
            return title;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_AUTHOR)) {
            return COLUMN_TITLE_AUTHOR;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_OWNER)) {
            return COLUMN_TITLE_OWNER;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_RELATIONSHIP)) {
            return COLUMN_TITLE_RELATIONSHIP;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_STATUS)) {
            return COLUMN_TITLE_STATUS;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_TYPE)) {
            return COLUMN_TITLE_TYPE;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_TITLE)) {
            return COLUMN_TITLE_TITLE;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_UPDATE_DATE)) {
            return COLUMN_TITLE_UPDATE_DATE;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_SPEC)) {
            return COLUMN_TITLE_SPEC;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_BROWSE_URL)) {
            return COLUMN_TITLE_BROWSE_URL;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_ID)) {
            return COLUMN_TITLE_ID;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_DESCRIPTION)) {
            return COLUMN_TITLE_DESCRIPTION;
        } else if(attr.equals(DRSClientIdmUtils.ATTR_CREATE_DATE)) {
            return COLUMN_TITLE_CREATE_DATE;
        } else {
            return title;
        }
    }

    private static Long remapToDrsAttr(String attr) {
        if(attr == null) {
            return null;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_AUTHOR)) {
            return DRSClientIdmUtils.ATTR_AUTHOR;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_OWNER)) {
            return DRSClientIdmUtils.ATTR_OWNER;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_STATUS)) {
            return DRSClientIdmUtils.ATTR_STATUS;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_TYPE)) {
            return DRSClientIdmUtils.ATTR_TYPE;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_TITLE)) {
            return DRSClientIdmUtils.ATTR_TITLE;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_UPDATE_DATE)) {
            return DRSClientIdmUtils.ATTR_UPDATE_DATE;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_NAME)) {
            return DRSClientIdmUtils.ATTR_SPEC;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_ID)) {
            return DRSClientIdmUtils.ATTR_ID;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_CREATE_DATE)) {
            return DRSClientIdmUtils.ATTR_CREATE_DATE;
        } else if(attr.equals(AdmAttrNames.EXTERNAL_REQUEST_TEXT_SEARCH)) {
            return DRSClientIdmUtils.ATTR_TEXT_SEARCH;
        } else {
            return null;
        }
    }
}

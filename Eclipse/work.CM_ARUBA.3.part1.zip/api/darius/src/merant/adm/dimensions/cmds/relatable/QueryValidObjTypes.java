/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * PVCS:QUERYPARENTSCMD JAVA.A-SRC;impulse#6
 * Description:
 * Item QUERYPARENTSCMD JAVA.A
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Iterator;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will query the potentially relatable Types.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_CLASS {Class}<dt><dd>Dimensions object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing filter information</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId's of Types's</dd>
 * </dl></code>
 * @author Floz
 */
public class QueryValidObjTypes extends DBIOCmd {
    public QueryValidObjTypes() throws AttrException {
        super();
        setAlias(Relatable.QUERY_VALID_OBJTYPES);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_CLASS, false, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
    }

    /** @todo Find a way to validate when dependencies exist between arguments */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue != null) {
                if ((!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof Item)) && (!(attrValue instanceof Type))) {
                    throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.ADM_OBJECT_CLASS)) {
            if (attrValue != null) {
                if ((!(attrValue.equals(ChangeDocument.class))) && (!(attrValue.equals(Item.class)))
                        && (!(attrValue.equals(ItemFile.class)))) {
                    throw new AttrException("Error: Object class is not supported!", attrDef, attrValue);
                }
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Class admObjClass = (Class) getAttrValue(CmdArguments.ADM_OBJECT_CLASS);
        Filter filter = (Filter) getAttrValue(CmdArguments.FILTER);

        AdmObject type = null;
        if (admObj instanceof Type) {
            type = admObj;
        } else {
            type = (AdmObject) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TYPE);
        }

        String productName = (String) AdmHelperCmd.getAttributeValue(type, AdmAttrNames.PRODUCT_NAME);
        String typeName = (String) AdmHelperCmd.getAttributeValue(type, AdmAttrNames.ID);
        Class parentClass = (Class) AdmHelperCmd.getAttributeValue(type, AdmAttrNames.PARENT_CLASS);

        Cmd cmd = null;
        DBIO query = null;
        String parentProductName = null;
        Vector retBaseIds = new Vector();

        if (parentClass.equals(ChangeDocument.class)) {
            if (admObjClass.equals(ChangeDocument.class) || admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                String typeFlag = null;
                if (admObjClass.equals(ChangeDocument.class)) {
                    typeFlag = "C";
                } else if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                    typeFlag = "I";
                }

                boolean basedOn = false;
                if (admObjClass.equals(ChangeDocument.class) && (filter != null)) {
                    Iterator it = filter.criteria().iterator();
                    while (it.hasNext()) {
                        FilterCriterion crit = (FilterCriterion) it.next();
                        if (CmdArguments.BASED_ON.equals(crit.getAttrName())) {
                            Boolean b = (Boolean) crit.getValue();
                            if (b != null) {
                                basedOn = b.booleanValue();
                            }
                        }
                    }
                }

                if (basedOn) {
                    query = new DBIO(getChdocBasedOnSQL());
                    query.bindInput(((AdmUidObject) type).getAdmUid().getUid());
                } else {
                    query = new DBIO(getChdocSQL());
                    query.bindInput(productName);
                    query.bindInput(typeName);
                    query.bindInput(typeFlag);
                }

                query.readStart();
                while (query.read()) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), Type.class, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), Type.class, null, null)));
                }
            }
        } else if (parentClass.equals(Item.class) || parentClass.equals(ItemFile.class)) {
            if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                query = new DBIO(getItemToItemSQL());
                query.bindInput(productName);
                query.bindInput(typeName);

                query.readStart();
                while (query.read()) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), Type.class, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), Type.class, null, null)));
                }
            }
        }

        return retBaseIds;
    }

    private String getChdocSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT ot.type_uid, cvr.obj_product_id||':'||cvr.obj_type||'-'||DECODE(cvr.rel_type, 'C', ");
        query.append("'merant.adm.dimensions.objects.ChangeDocument', 'I', 'merant.adm.dimensions.objects.Item') ");
        query.append("FROM obj_types ot, cm_valid_rels cvr WHERE cvr.product_id = :I1 AND cvr.ch_doc_type = :I2 AND ");
        query.append("cvr.rel_type = :I3 AND ot.product_id = cvr.obj_product_id AND ot.type_name = cvr.obj_type AND ");
        query.append("ot.type_flag = cvr.rel_type");
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getChdocBasedOnSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT ot.type_uid, ot.product_id||':'||ot.type_name||'-merant.adm.dimensions.objects.ChangeDocument'");
        query.append(" FROM obj_types ot, cplrel_attributes ca, cpl_rels cr WHERE cr.obj_uid = :I1 AND");
        query.append(" cr.rel_class = 40001 AND ot.type_uid = cr.related_uid");
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getItemToItemSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT ot2.type_uid, ot2.product_id||':'||ot2.type_name||'-merant.adm.dimensions.objects.Item' ");
        query.append("FROM cpl_catalogue cc, cpl_attributes ca, obj_types ot, obj_types ot2 WHERE ot.product_id = :I1 AND ");
        query.append("ot.type_name = :I2 AND ot.type_flag = 'I' AND ca.attr_3 = TO_CHAR(ot.type_uid) AND ot2.type_flag = 'I' AND ");
        query.append("ca.attr_4 = TO_CHAR(ot2.type_uid) AND ca.obj_uid = cc.obj_uid AND cc.obj_class=9");
        String sql = new String(query);
        query = null;
        return sql;
    }
}

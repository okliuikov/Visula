/*
 * Copyright (C), 2012, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.List;

import com.serena.dmnet.LCNetClnt;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;
import merant.adm.session.Session;

/**
 * This command sets baseline flags.
 * <b>Mandatory Arguments:</b> <code>
 *   <dt>PRODUCT</dt><dd>Product name of the baseline to update the flag of</dd>
 *   <dt>BASELINE</dt><dd>Id of the baseline to update the flag of</dd>
 *   <dt>FLAG_NUMBERS</dt><dd>List of attribute numbers to update flags with</dd>
 *   <dt>FLAG_VALUES</dt><dd>List of attribute values to update flags with</dd>
 * </code> <br>
 * <b>Optional Arguments:</b> <code>
 *  <dl>
 *  </dl>
 * </code> <br>
 * <b>Returns:</b> <code>
 *  <dl>
 *   <dt>Boolean</dt>
 *   <dd>Returns true on success</dd>
 *  </dl>
 * </code>
 * @author Floz
 */
public class RPCSetBaselineFlagsCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCSetBaselineFlagsCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("SetBaselineFlags");
        AddArgument("cmd", "SetBaselineFlags");
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.FLAG_NUMBERS, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.FLAG_VALUES, true, List.class));
    }

    @Override
    public Object execute() throws AdmException {
        try {
            String product = ((String) getAttrValue(CmdArguments.PRODUCT));
            String baseline = ((String) getAttrValue(CmdArguments.BASELINE));
            List flagNumbers = ((List) getAttrValue(CmdArguments.FLAG_NUMBERS));
            List flagValues = ((List) getAttrValue(CmdArguments.FLAG_VALUES));

            Session session = (Session) DimSystem.getSystem().getSession();
            session.getConnection().rpcSetBaselineFlags(product, baseline, flagNumbers.size(),
                    LCNetClnt.collectionToIntArray(flagNumbers), LCNetClnt.collectionToIntArray(flagValues));

            return Boolean.TRUE;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

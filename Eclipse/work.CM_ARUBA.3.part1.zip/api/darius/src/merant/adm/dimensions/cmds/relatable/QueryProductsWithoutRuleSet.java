/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2012 Serena Software Europe Ltd. All rights reserved.
 * -----------------------------------------------------------------------------
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will query all the products in the base database which has not got product ruleset already created.
 * <p>
 * 
 * 
 */
public class QueryProductsWithoutRuleSet extends DBIOCmd {
    public QueryProductsWithoutRuleSet() throws AttrException {
        super();
        setAlias(Relatable.QUERY_PRODUCTS_WITHOUT_RULESET);
        setAttrDef(new CmdArgDef(AdmAttrNames.EXTENSION, true, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);
        List retBaseIds = new ArrayList();
        DBIO query = new DBIO(wcm_sql.GET_PRODUCTS_WITHOUT_DEFAULT_RULES);
        query.bindInput("$$" + extension + "-");
        query.readStart();
        while (query.read()) {
            retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), Product.class, null,
                    AdmHelperCmd.newAdmBaseId(query.getString(2), Product.class, null, null)));
        }
        return retBaseIds;
    }

}

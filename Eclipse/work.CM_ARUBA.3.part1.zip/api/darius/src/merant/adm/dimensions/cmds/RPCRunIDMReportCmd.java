/*
 * Copyright (C) 2009, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.LCNetClnt;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * 
 * @author pbate
 * 
 *         This command is used to run an IDM report.
 *         <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>WORKSET {AdmUidObject}</dt><dd>the current project</dd>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>the IDM report</dd>
 * </dl></code> <br>
 *         <b>Returns:</b> <code><dl>
 *  <dt>requests {List}</dt><dd>a list of External Requests, or null if none are available</dd>
 * </dl></code>
 */
public class RPCRunIDMReportCmd extends RPCCmd {

    public RPCRunIDMReportCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("RunIDMReport");
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, true, AdmUidObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    /**
     * Returns a list of External Requests
     * 
     * @return <code>java.util.List</code>
     * 
     */
    @Override
    public Object execute() throws DimConnectionException, AdmException {
        List requests = null;
        int projUid = -1;
        String uuid = null;

        try {
            AdmUidObject project = (AdmUidObject) getAttrValue(CmdArguments.WORKSET);
            projUid = (int) project.getAdmUid().getUid();

            AdmObject report = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
            uuid = report.getId();

            LCNetClnt.IDMReportResults results = getSession().getConnection().rpcRunIDMReport(projUid, uuid);
            if (results != null) {
                List colResults = results.getIDMCols();
                List cols = null;
                if (colResults != null && colResults.size() > 0) {
                    Iterator iter = colResults.iterator();
                    List colNames = new ArrayList();
                    List colTypes = new ArrayList();
                    while (iter.hasNext()) {
                        LCNetClnt.IDMReportResults.IDMColumn col = (LCNetClnt.IDMReportResults.IDMColumn) iter.next();
                        colNames.add(col.getDisplayName());
                        colTypes.add(Integer.valueOf(col.getColType()));
                    }
                    if (cols == null) {
                        cols = new ArrayList();
                    }
                    cols.add(colNames);
                    cols.add(colTypes);
                }
                List ret = results.getIDMRequests();
                if (ret != null && ret.size() > 0) {
                    Iterator iter = ret.iterator();
                    while (iter.hasNext()) {
                        LCNetClnt.IDMReportResults.IDMRequest dmnetReq = (LCNetClnt.IDMReportResults.IDMRequest) iter.next();
                        ExternalRequest req = (ExternalRequest) AdmCmd.getObject(AdmCmd.newAdmBaseId(dmnetReq.getName(),
                                ExternalRequest.class));
                        // ExternalRequest req = new ExternalRequest();
                        req.setAttrValue(AdmAttrNames.ID, dmnetReq.getId());
                        req.setAttrValue(AdmAttrNames.IDM_NAME, dmnetReq.getName());
                        req.setAttrValue(AdmAttrNames.IDM_URL, dmnetReq.getURL());
                        if (dmnetReq.getCreateDate() != -1) {
                            req.setAttrValue(AdmAttrNames.CREATE_DATE, new Date(dmnetReq.getCreateDate()));
                        }
                        req.setAttrValue(AdmAttrNames.IDM_REQ_GRIDVALS, dmnetReq.getGridVals());
                        if (cols != null) {
                            req.setAttrValue(AdmAttrNames.IDM_REQ_COLUMNS, cols);
                        }
                        if (requests == null) {
                            requests = new ArrayList();
                        }
                        requests.add(req);
                    }
                }
            }

        } catch (AttrException e) {
            requests = null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return requests;
    }
}

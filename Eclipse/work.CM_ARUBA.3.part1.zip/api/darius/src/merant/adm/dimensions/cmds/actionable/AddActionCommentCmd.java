/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.IOException;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.TempFileOutputStream;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will add an action description to a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>USER_FILE {String}<dt><dd>File containing action comment</dd>
 *  <dt>ACTION_COMMENT {String}<dt><dd>Text of the action comment</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class AddActionCommentCmd extends RPCExecCmd {
    public AddActionCommentCmd() throws AttrException {
        super();
        setAlias(Actionable.ADD_COMMENT);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ACTION_COMMENT, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        String actionComment = (String) getAttrValue(CmdArguments.ACTION_COMMENT);

        if (admObj instanceof ChangeDocument) {
            _cmdStr = "UC";
        }

        _cmdStr += " " + Encoding.escapeSpec(admObj.getAdmSpec().getSpec()) + " ";

        String ret = null;
        try {
            TempFileOutputStream ts = null;
            if (userFile != null && userFile.length() > 0) {
                _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(userFile);
            } else {
                ts = new TempFileOutputStream();
                ts.writeString(actionComment);
                _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(ts.getAbsolutePath());
            }

            ret = executeRpc();

            if (ts != null) {
                ts.close();
            }
        } catch (IOException ioException) {
            throw new AdmException(ioException);
        }
        return ret;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.SecChangeDocument;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

/**
 * Queries attribute definition objects related to the Type object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class QCTypeToLocalAttrDefCmd extends QueryRelsCmd {
    public QCTypeToLocalAttrDefCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(LocalAttributeDefinition.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();
        Filter filt = filter;
        if (filt == null) {
            filt = new FilterImpl();
        }

        AdmUid uid = (AdmUid) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ADM_UID);
        filt.criteria().add(new FilterCriterion(AdmAttrNames.ATTRDEF_TYPE_UID, new Long(uid.getUid())));

        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurRootObj(BaseDatabase.class));
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, admSecClass);
        cmd.setAttrValue(CmdArguments.FILTER, filt);
        List admBaseIds = (List) cmd.execute();
        if (admBaseIds != null) {
            for (int i = 0; i < admBaseIds.size(); i++) {
                addRelation(ret, relationships, admObj.getAdmBaseId(), (AdmBaseId) admBaseIds.get(i));
            }

        }

        // make sure that this bloody system attribute can be filtered out
        if (filt == null
                || filterMatches(filt, Constants.ATTRDEF_PCMS_CHDOC_DETAIL_DESC_UID, Constants.ATTRDEF_PCMS_CHDOC_DETAIL_DESC)) {
            // add special PCMS_CHDOC_DETAIL_DESC attribute
            Class typeClass = (Class) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
            if (ChangeDocument.class.equals(typeClass) || SecChangeDocument.class.equals(typeClass)) {
                AdmBaseId baseId = AdmHelperCmd.newAdmBaseId(uid.getUid() + ":" + Constants.ATTRDEF_PCMS_CHDOC_DETAIL_DESC_UID,
                        LocalAttributeDefinition.class);
                addRelation(ret, relationships, admObj.getAdmBaseId(), baseId);
            }
        }

        return ret;
    }

    private boolean filterMatches(Filter filter, int attrNo, String attrName) {
        if (filter == null) {
            return false;
        }
        Collection crits = filter.criteria();

        if (crits != null && crits.size() > 0) {
            for (Iterator it = crits.iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit == null) {
                    continue;
                }

                if (AdmAttrNames.ATTRDEF_ATTRNO.equals(crit.getAttrName())) {
                    Object value = crit.getValue();
                    if (value instanceof Integer && ((Integer) value).intValue() == attrNo) {
                        return true;
                    }
                }
                if (AdmAttrNames.ID.equals(crit.getAttrName())) {
                    Object value = crit.getValue();
                    if (value instanceof String && ((String) value).equalsIgnoreCase(attrName)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}

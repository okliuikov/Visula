/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.helper.UserDisplayFormatter;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.ProfileAssignment;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all ProfileAssignment's related to the Base Database object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 *  </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Peter Bate
 */
public class QCBaseDbaseToProfileAssignmentCmd extends QueryRelsCmd {
    public QCBaseDbaseToProfileAssignmentCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.USER_DISPLAY_FORMATTER, false, UserDisplayFormatter.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof BaseDatabase)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(ProfileAssignment.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();

        if (filter != null) {
            filter = (FilterImpl) filter.clone();
        } else {
            filter = new FilterImpl();
        }

        // for order id+fullusername/fullusername+id
        for (Iterator it = filter.orders().iterator(); it.hasNext();) {
            FilterOrder order = (FilterOrder) it.next();
            if (order.getAttrName().equals(AdmAttrNames.PROFILE_ASSIGN_USERNAME) || order.getAttrName().equals(AdmAttrNames.USER_NAME_FORMATED)) {
                filter.orders().add(new FilterOrder(AdmAttrNames.ROLE_ASSIGN_FULLUSERNAME, order.getFlags()));
            }
        }

        UserDisplayFormatter formatter = (UserDisplayFormatter) getAttrValue(CmdArguments.USER_DISPLAY_FORMATTER);
        DBIO query = getDBIO(filter, formatter);
        query.readStart();
        List specComponents = null;
        while (query.read()) {
        	String userId = query.getString(2);
            String fullUserName = query.getString(3);

            specComponents = new ArrayList();
            specComponents.add(query.getString(1));
            specComponents.add(userId);

            //Preload User object display label, which can be in different formats.
            if (formatter != null) {
                specComponents.add(formatter.buildUserDisplayName(userId, fullUserName));
            } else {
                specComponents.add(null);
            }
            addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(specComponents, admSecClass));
        }

        return ret;
    }

    private DBIO getDBIO(FilterImpl filter, UserDisplayFormatter formatter) throws AdmException {
        String usergroupname = "";
        String profile = "";

        StringBuffer sb = new StringBuffer();
        sb.append("SELECT pc.obj_id, up.user_name, up.full_user_name FROM profile_catalogue pc, users_profile up, profile_assignments pa ");
        sb.append("WHERE pc.obj_uid = pa.profile_uid AND up.user_uid = pa.assign_uid AND pa.assign_type=256 ");

        StringBuffer sb2 = new StringBuffer();
        sb2.append("UNION ALL ");
        sb2.append("SELECT pc.obj_id, gc.group_name, gc.description FROM profile_catalogue pc, group_catalogue gc, profile_assignments pa ");
        sb2.append("WHERE pc.obj_uid = pa.profile_uid AND gc.group_uid = pa.assign_uid AND pa.assign_type=13");
        for (Iterator it = filter.criteria().iterator(); it.hasNext();) {
            FilterCriterion crit = (FilterCriterion) it.next();
            if (crit.getValue() == null) {
                continue;
            }

            if (crit.getAttrName().equals(AdmAttrNames.PROFILE_ASSIGN_USERNAME) ||
            		crit.getAttrName().equals(AdmAttrNames.USER_NAME_FORMATED)) {

                sb.append(" AND ");
                sb2.append(" AND ");

                if (crit.getValue() instanceof List) {
                    sb.append(" (");
                    sb2.append(" (");
                    for (int i = 0; i < ((List) crit.getValue()).size(); i++) {
                        if (i > 0) {
                            sb.append(" OR ");
                            sb2.append(" OR ");
                        }
                        sb.append("(up.user_name = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                        sb2.append("(gc.group_name = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                    }
                    sb.append(") ");
                    sb2.append(") ");
                } else {
                    sb.append(" up.user_name = \'" + (String) crit.getValue() + "\' ");
                    sb2.append(" gc.group_name = \'" + (String) crit.getValue() + "\' ");
                }
            }
            if (crit.getAttrName().equals(AdmAttrNames.PROFILE_ASSIGN_PROFILE)) {

                sb.append(" AND ");
                sb2.append(" AND ");

                if (crit.getValue() instanceof List) {
                    sb.append(" (");
                    sb2.append(" (");
                    for (int i = 0; i < ((List) crit.getValue()).size(); i++) {
                        if (i > 0) {
                            sb.append(" OR ");
                            sb2.append(" OR ");
                        }
                        sb.append("(pc.obj_id = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                        sb2.append("(pc.obj_id = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                    }
                    sb.append(") ");
                    sb2.append(") ");
                } else {
                    sb.append("pc.obj_id = \'" + (String) crit.getValue() + "\' ");
                    sb2.append("pc.obj_id = \'" + (String) crit.getValue() + "\' ");
                }
            }
        }

        sb.append(sb2);

        if (filter.orders().size() > 0) {

            boolean first = true;
            for (Iterator it = filter.orders().iterator(); it.hasNext();) {
                if (first) {
                    sb.append(" ORDER BY ");
                    first = false;
                } else {
                    sb.append(", ");
                }
                FilterOrder order = (FilterOrder) it.next();
                if (order.getAttrName().equals(AdmAttrNames.PROFILE_ASSIGN_USERNAME) ||
                        order.getAttrName().equals(AdmAttrNames.USER_NAME_FORMATED)) {
                    if (formatter != null && formatter.isUserIdFirst())
                        sb.append("2");
                    else
                        sb.append("3");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_FULLUSERNAME)) {
                    if (formatter != null && formatter.isUserIdFirst())
                        sb.append("3");
                    else
                        sb.append("2");
                } else if (order.getAttrName().equals(AdmAttrNames.PROFILE_ASSIGN_PROFILE)) {
                    sb.append("1");
                }
                int direction = order.getFlags() & (FilterOrder.ASCENDING | FilterOrder.DESCENDING);
                switch (direction) {
                case FilterOrder.ASCENDING:
                    sb.append(" ASC");
                    break;
                case FilterOrder.DESCENDING:
                    sb.append(" DESC");
                    break;
                default:
                    break;
                }
            }
        } else {
            // default sort order
            sb.append(" ORDER BY 1");
        }

        String queryStr = sb.toString();
        DBIO query = new DBIO(queryStr);
        return query;
    }
}

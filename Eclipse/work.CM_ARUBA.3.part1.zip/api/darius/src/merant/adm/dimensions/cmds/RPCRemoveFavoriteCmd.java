package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class RPCRemoveFavoriteCmd extends RPCCmd {
    public RPCRemoveFavoriteCmd() throws AdmObjectException, AttrException {
        setAlias("RemoveFavorite");
        setAttrDef(new CmdArgDef(AdmAttrNames.FAV_UID, true, Long.class));
    }

    @Override
    public Object execute() throws AdmException {
        try {
            int favUid = ((Long) getAttrValue(AdmAttrNames.FAV_UID)).intValue();
            int result = getSession().getConnection().rpcRemoveFavourite(favUid);

            if (result == Constants.PCMS_OK) {
                return "Operation Success";
            }
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

        return "Operation Failed";
    }
}

/*
 * Copyright 2000, 2006 Serena Software, Inc.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Get the default values as per upload rules via Message Server
 */
public class RPCDuRulesCmd extends RPCCmd {

    public RPCDuRulesCmd() throws AttrException {
        super();
        setAlias("RPC DuRules");
        AddArgument("cmd", "PcmsDuRulesCommand");
        setAttrDef(new CmdArgDef("ruleid", true, "", "", ""));
        setAttrDef(new CmdArgDef("newfilename", true, "", "", ""));
        setAttrDef(new CmdArgDef("product", false, String.class, "", ""));
        setAttrDef(new CmdArgDef("options", false, Integer.class, "", ""));
    }

    @Override
    public Object execute() throws AdmException {
        String attrs[][] = null;
        try {
            Integer options = (Integer) getAttrValue("options");
            attrs = getSession().getConnection().rpcDuRules((String) getAttrValue("ruleid"), (String) getAttrValue("newfilename"),
                    (String) getAttrValue("product"), (options != null ? options.intValue() : 0));
            if (attrs == null) {
                return Constants.SERVER_FAIL;
            }
        } catch (AttrException e) {
            return Constants.SERVER_FAIL;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        String ret = Constants.SERVER_OK;
        for (int i = 0; i < attrs.length; i++) {
            ret = ret + attrs[i][0] + "=" + attrs[i][1] + "\007";
        }
        return ret;
    }

}

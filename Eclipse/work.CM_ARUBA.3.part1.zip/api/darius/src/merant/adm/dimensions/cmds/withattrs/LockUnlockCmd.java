/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010, Serena Software Europe, Ltd. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.withattrs;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Locks/unlocks specific item in the stream/the whole stream or project.
 * If there are no item/filename set - locks/unlocks the whole stream/project, otherwise
 * the lock is applied to the latest revision in the stream.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions stream/project object</dd>
 *  <dt>LOCKED {Boolean}</dt><dd>If true the stream/project is locked otherwise unlocked</dd>
 * </dl></code> <b>Optional Arguments:</b> <code><dl>
 *  <dt>ITEM {Item}</dt><dd>Item to apply lock/unlock</dd>
 *  <dt>FILENAME {String}</dt><dd>Item filename</dd>
 * </dl></code>
 *
 * <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 *
 * @author kberezovchuk
 */
public class LockUnlockCmd extends RPCExecCmd {
    public LockUnlockCmd() throws AttrException {
        super();
        setAlias(WithAttrs.LOCK_UNLOCK);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LOCKED, true, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.ITEM, false, Item.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILENAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.SESSION_LOCK, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCK_IN_ALL_STREAMS, false, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean lock = ((Boolean) getAttrValue(AdmAttrNames.LOCKED)).booleanValue();

        if (lock) {
            _cmdStr = "LCK";
        } else {
            _cmdStr = "ULCK";
        }

        Item item = (Item) getAttrValue(CmdArguments.ITEM);
        String filename = (String) getAttrValue(CmdArguments.FILENAME);
        if (item != null || filename != null) {
            _cmdStr += (item != null) ? " ITEM " + Encoding.escapeDMCLI(item.getAdmSpec().getSpec()) : "";
            _cmdStr += !StringUtils.isBlank(filename) ? " FILENAME " + Encoding.escapeDMCLI(filename) : "";
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());

            Boolean allStreams = (Boolean)getAttrValue(AdmAttrNames.LCK_IN_ALL_STREAMS);
            if (allStreams != null && Boolean.TRUE.equals(allStreams)) {
                _cmdStr += " /ALL";
            }
        } else {
            _cmdStr += " WORKSET " + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());
            Boolean scope = (Boolean) getAttrValue(CmdArguments.SESSION_LOCK);
            if (Boolean.TRUE.equals(scope)) {
                _cmdStr += " /SCOPE=SESSION";
            }
        }
        return executeRpc();
    }
}

/*
 * Copyright (C), 2005-2006, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.relatable;

import merant.adm.framework.AttrException;

/**
 * This command will query the children of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId or Relationship instances</dd>
 * </dl></code>
 * 
 * 
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

// Implementation of QCWorksetToRequirementCmd & QCReqColToReqCmd are similar
// They can be different but for now to not "Copy & Paste" & "change AdmCommands.xml" we are extending existing implementation
public class QCWorksetToRequirementCmd extends QCReqColToReqCmd {
    public QCWorksetToRequirementCmd() throws AttrException {
        super();
    }
}
/*
 * public class QCWorksetToRequirementCmd extends QueryRelsCmd {
 * public QCWorksetToRequirementCmd() throws AttrException {
 * super();
 * setAlias(Relatable.QUERY_CHILDREN);
 * //* I don't think we need this.
 * //x setAttrDef(new CmdArgDef(CmdArguments.ADM_CHILD_CLASS, true,
 * //x Class.class));
 * //x setAttrDef(new CmdArgDef(CmdArguments.MULTIPLE, false, Boolean.FALSE,
 * //x Boolean.class));
 * }
 * public Object execute()
 * throws DBIOException, DimBaseException, AdmException
 * {
 * validateAllAttrs();
 * AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
 * boolean relationships = ((Boolean) getAttrValue(CmdArguments.RELATIONSHIPS)).booleanValue();
 * FilterImpl filter = (FilterImpl) getAttrValue((CmdArguments.FILTER));
 * List ret = new Vector();
 * ArrayList containerDetails = new ArrayList();
 * try
 * {
 * SuperQuery sq = new SuperQuery(SuperQuery.USE_SQML);
 * sq.setObjectType(Requirement.class);
 * sq.setScope(new AdmBaseId(WorkSet.class));
 * // specify the attributes we want back
 * sq.addSelect(AdmAttrNames.CLASS_UID); // class id
 * sq.addSelect(AdmAttrNames.RTM_ID); // object id
 * sq.addSelect(AdmAttrNames.ADM_UID); // Dimensions requirement object id
 * sq.addSelect(AdmAttrNames.ADM_SPEC);
 * sq.addSelect(AdmAttrNames.RTM_COL_TYPE);
 * sq.addSelect(AdmAttrNames.RTM_COL_SPEC);
 * sq.addRel(admObj);
 * if (filter != null)
 * {
 * Collection c = filter.criteria();
 * if (c != null)
 * {
 * for (Iterator it = c.iterator(); it.hasNext();)
 * {
 * FilterCriterion fc = (FilterCriterion) it.next();
 * //* Only add filters that are not
 * if (fc != null
 * && fc.getValue() != null
 * && ((String) fc.getValue()).length() > 0)
 * {
 * //* We don't care about flags in the ALM integration
 * sq.addWhere(fc.getAttrName(),
 * (String) fc.getValue());
 * }
 * }
 * }
 * }
 * //* Look in the current workset.
 * // Don't needed as admObj always exists and refers to Project
 * // sq.addRel(AdmCmd.getCurRootObj(WorkSet.class));
 * sq.addDefaultOrder();
 * try
 * {
 * sq.readStart();
 * while (sq.read())
 * {
 * containerDetails.add(new String[]{sq.getString(5),sq.getString(6)});// Store the container details of requirements to use when
 * querying requirement attributes
 * addRelation(ret, relationships, admObj.getAdmBaseId(),
 * AdmHelperCmd.newAdmBaseId(sq.getLong(3), Requirement.class, admObj.getAdmBaseId(),
 * AdmHelperCmd.newAdmBaseId(sq.getString(4), Requirement.class, admObj.getAdmBaseId(), null)));
 * }
 * }
 * catch (IndexOutOfBoundsException e)
 * {
 * // This Exception throw in case when Project does not have attached Requirement collection
 * // SuperQuery bug ?
 * }
 * setAttrDef(new CmdArgDef(CmdArguments.CONTAINER_DETAILS, false, List.class));
 * setAttrValue(CmdArguments.CONTAINER_DETAILS, containerDetails);// Set the container details of requirements in the command so
 * that it can be retrieved later to supply to the command which retrieves the requirement attributes
 * }
 * catch (DimConnectionException e)
 * {
 * //* XXX - chrisp - temporary code to catch exception that is thrown
 * //* when trying to close the connection in rpcDBclose().
 * //* The underlying problem needs to be found, but this will
 * //* temporarily fix the issue.
 * Debug.error(e.getMessage(), e);
 * }
 * return ret;
 * }
 * }
 */
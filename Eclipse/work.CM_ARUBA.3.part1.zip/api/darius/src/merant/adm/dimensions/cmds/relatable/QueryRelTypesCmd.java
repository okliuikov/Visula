/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2001 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.*;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will query the potential RelationshipTypes for a pair of Dimensions objects.
 * <p>
 * When querying object relationship types that are based upon object type, then use the ADM_OBJECT & ADM_PARENT_OBJECT arguments.
 * If querying based just on object class, then use the ADM_OBJECT_CLASS & ADM_PARENT_CLASS arguments. You may also use the
 * ADM_PARENT_OBJECT & ADM_PARENT_CLASS arguments. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>{null}<dt><dd>void</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Parent Dimensions object</dd>
 *  <dt>ADM_OBJECT_CLASS {Class}<dt><dd>Dimensions object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}<dt><dd>Parent Dimensions object class</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId's of RelationshipType's</dd>
 * </dl></code>
 * @author Floz
 */
public class QueryRelTypesCmd extends DBIOCmd {
    public QueryRelTypesCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_REL_TYPES);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_CLASS, false, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_CLASS, false, Class.class));
    }

    /** @todo Find a way to validate when dependencies exist between arguments */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue != null) {
                if (attrValue instanceof Type) {
                    Class parentClass = null;
                    try {
                        parentClass = (Class) AdmHelperCmd.getAttributeValue((AdmObject) attrValue, AdmAttrNames.PARENT_CLASS);
                    } catch (Exception e) {
                    }
                    if ((parentClass == null)
                            || ((!(parentClass.equals(Baseline.class))) && (!(parentClass.equals(ChangeDocument.class)))
                                    && (!(parentClass.equals(Item.class))) && (!(parentClass.equals(ItemFile.class))))) {
                        throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                    }
                } else if ((!(attrValue instanceof Baseline)) && (!(attrValue instanceof ChangeDocument))
                        && (!(attrValue instanceof DimDirectory)) && (!(attrValue instanceof Item))
                        && (!(attrValue instanceof Part)) && (!(attrValue instanceof WorkSet))
                        && (!(attrValue instanceof ExternalRequest))) {
                    throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (attrValue != null) {
                if (attrValue instanceof Type) {
                    Class parentClass = null;
                    try {
                        parentClass = (Class) AdmHelperCmd.getAttributeValue((AdmObject) attrValue, AdmAttrNames.PARENT_CLASS);
                    } catch (Exception e) {
                    }
                    if ((parentClass == null)
                            || ((!(parentClass.equals(ChangeDocument.class))) && (!(parentClass.equals(Item.class))) && (!(parentClass.equals(ItemFile.class))))) {
                        throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                    }
                } else if ((!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof DimDirectory))
                        && (!(attrValue instanceof Item)) && (!(attrValue instanceof Part))
                        && (!(attrValue instanceof WorkSet)) && (!(attrValue instanceof ExternalRequest))) {
                    throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.ADM_OBJECT_CLASS)) {
            if (attrValue != null) {
                if ((!(attrValue.equals(Baseline.class))) && (!(attrValue.equals(ChangeDocument.class)))
                        && (!(attrValue.equals(DimDirectory.class))) && (!(attrValue.equals(Item.class)))
                        && (!(attrValue.equals(ItemFile.class))) && (!(attrValue.equals(Part.class)))
                        && (!(attrValue.equals(WorkSet.class))) && (!(attrValue.equals(ExternalRequest.class)))) {
                    throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.ADM_PARENT_CLASS)) {
            if (attrValue != null) {
                if ((!(attrValue.equals(ChangeDocument.class))) && (!(attrValue.equals(DimDirectory.class)))
                        && (!(attrValue.equals(Item.class))) && (!(attrValue.equals(ItemFile.class)))
                        && (!(attrValue.equals(Part.class))) && (!(attrValue.equals(WorkSet.class)))
                        && (!(attrValue.equals(Baseline.class))) && (!(attrValue.equals(Requirement.class)))
                        && (!(attrValue.equals(ExternalRequest.class)))) {
                    throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                }
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        Class admObjClass = (Class) getAttrValue(CmdArguments.ADM_OBJECT_CLASS);
        Class admParentClass = (Class) getAttrValue(CmdArguments.ADM_PARENT_CLASS);

        Cmd cmd = null;
        DBIO query = null;
        String parentProductName = null;
        Vector retBaseIds = new Vector();

        // Implementation for Type{Item}->Class{Item}
        if ((admParentObj != null) && (admParentObj instanceof Type)) {
            Class parentClass = (Class) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PARENT_CLASS);
            if (parentClass.equals(Item.class) || parentClass.equals(ItemFile.class)) {
                if ((admObjClass != null) && (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class))) {
                    parentProductName = (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PRODUCT_NAME);
                    String parentTypeName = (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.ID);

                    query = new DBIO(getItemTypeToItemClassRelTypesSQL());
                    query.bindInput(parentProductName);
                    query.bindInput(parentTypeName);

                    query.readStart();
                    while (query.read()) {
                        retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), RelationshipType.class, null,
                                AdmHelperCmd.newAdmBaseId(query.getString(2), RelationshipType.class, null, null)));
                    }

                    return retBaseIds;
                }
            }
        }

        // Implementation for Class{Item}->Type{Item}
        if ((admParentClass != null) && (admParentClass.equals(Item.class) || admParentClass.equals(ItemFile.class))) {
            if ((admObj != null) && (admObj instanceof Type)) {
                Class childClass = (Class) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
                if (childClass.equals(Item.class) || childClass.equals(ItemFile.class)) {
                    String childProductName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
                    String childTypeName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);

                    query = new DBIO(getItemClassToItemTypeRelTypesSQL());
                    query.bindInput(childProductName);
                    query.bindInput(childTypeName);

                    query.readStart();
                    while (query.read()) {
                        retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), RelationshipType.class, null,
                                AdmHelperCmd.newAdmBaseId(query.getString(2), RelationshipType.class, null, null)));
                    }

                    return retBaseIds;
                }
            }
        }

        // Currently Type's are not directly required and so
        // redirect using the PARENT_CLASS attribute of the Type
        if ((admObj != null) && (admObj instanceof Type)) {
            cmd = AdmCmd.getCmd(Relatable.QUERY_REL_TYPES);
            cmd.setAttrValue(CmdArguments.ADM_OBJECT_CLASS, AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS));
            if ((admParentObj != null) && (admParentObj instanceof Type)) {
                cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS,
                        AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PARENT_CLASS));
            } else {
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
            }

            List subBaseIds = (List) cmd.execute();
            if ((subBaseIds != null) && (subBaseIds.size() > 0)) {
                retBaseIds.addAll(subBaseIds);
            }
        } else if ((admParentObj != null) && (admParentObj instanceof Type) && (admObj != null)) {
            cmd = AdmCmd.getCmd(Relatable.QUERY_REL_TYPES, admObj);
            cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PARENT_CLASS));
            List subBaseIds = (List) cmd.execute();
            if ((subBaseIds != null) && (subBaseIds.size() > 0)) {
                retBaseIds.addAll(subBaseIds);
            }
        } else if ((admObj != null) && (admParentObj != null)) {
            if ((admParentObj instanceof Item) && (admObj instanceof Item)) {
                parentProductName = (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PRODUCT_NAME);
                String parentTypeName = (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.TYPE_NAME);
                String childProductName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
                String childTypeName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TYPE_NAME);

                query = new DBIO(getItemToItemRelTypesSQL());
                query.bindInput(parentProductName);
                query.bindInput(parentTypeName);
                query.bindInput(childProductName);
                query.bindInput(childTypeName);

                query.readStart();
                while (query.read()) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), RelationshipType.class, null, null)));
                }
            } else {
                cmd = AdmCmd.getCmd(Relatable.QUERY_REL_TYPES);
                cmd.setAttrValue(CmdArguments.ADM_OBJECT_CLASS, admObj.getClass());
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                List subBaseIds = (List) cmd.execute();
                if ((subBaseIds != null) && (subBaseIds.size() > 0)) {
                    retBaseIds.addAll(subBaseIds);
                }
            }
        } else if ((admObjClass != null) && (admParentObj != null)) {
            if ((admParentObj instanceof ChangeDocument || admParentObj instanceof Type)
                    && admObjClass.equals(ChangeDocument.class)) {
                parentProductName = (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PRODUCT_NAME);
                query = new DBIO(getChdocToChdocClassRelTypesSQL());
                query.bindInput(parentProductName);

                // Add DEPENDENT as a hard-coded reltype
                retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_DEPENDENT, RelationshipType.class, null,
                        AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_DEPENDENT, RelationshipType.class, null, null)));

                // Add INFO as a hard-coded reltype
                retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_INFO, RelationshipType.class, null,
                        AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_INFO, RelationshipType.class, null, null)));

                query.readStart();
                while (query.read()) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), RelationshipType.class, null, null)));
                }
            } else if ((admParentObj instanceof Item) && (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class))) {
                parentProductName = (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PRODUCT_NAME);
                String parentTypeName = (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.TYPE_NAME);

                query = new DBIO(getItemToItemClassRelTypesSQL());
                query.bindInput(parentProductName);
                query.bindInput(parentTypeName);

                query.readStart();
                while (query.read()) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), RelationshipType.class, null, null)));
                }
            } else {
                cmd = AdmCmd.getCmd(Relatable.QUERY_REL_TYPES);
                cmd.setAttrValue(CmdArguments.ADM_OBJECT_CLASS, admObjClass);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, admParentObj.getClass());
                List subBaseIds = (List) cmd.execute();
                if ((subBaseIds != null) && (subBaseIds.size() > 0)) {
                    retBaseIds.addAll(subBaseIds);
                }
            }
        } else if ((admObjClass != null) && (admParentClass != null)) {
            if (admParentClass.equals(ChangeDocument.class)) {
                if (admObjClass.equals(Baseline.class)) {
                    // Add Affected as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_AFFECTED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_AFFECTED, RelationshipType.class, null, null)));

                    // Add Affected(revised) as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_AFFECTED_REVISED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_AFFECTED_REVISED, RelationshipType.class, null, null)));

                    // Add Information as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_INFO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_INFO, RelationshipType.class, null, null)));

                    // Add In Response To as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_IN_RESPONSE_TO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_IN_RESPONSE_TO, RelationshipType.class, null, null)));

                    // Add In Response To(revised) as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_IN_RESPONSE_TO_REVISED, RelationshipType.class,
                            null, AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_IN_RESPONSE_TO_REVISED, RelationshipType.class,
                                    null, null)));
                } else if (admObjClass.equals(ChangeDocument.class)) {
                    query = new DBIO(getChdocClassToChdocClassRelTypesSQL());

                    // Add DEPENDENT as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_DEPENDENT, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_DEPENDENT, RelationshipType.class, null, null)));

                    // Add INFO as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_INFO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_INFO, RelationshipType.class, null, null)));

                    query.readStart();
                    while (query.read()) {
                        retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), RelationshipType.class, null,
                                AdmHelperCmd.newAdmBaseId(query.getString(2), RelationshipType.class, null, null)));
                    }
                } else if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_AFFECTED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_AFFECTED, RelationshipType.class, null, null)));

                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_IN_RESPONSE_TO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_IN_RESPONSE_TO, RelationshipType.class, null, null)));

                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_INFO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_INFO, RelationshipType.class, null, null)));
                }
            } else if (admParentClass.equals(DimDirectory.class)) {
                if (admObjClass.equals(DimDirectory.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));
                } else if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));
                }
            } else if (admParentClass.equals(Item.class) || admParentClass.equals(ItemFile.class)) {
                if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                    query = new DBIO(getItemClassToItemClassRelTypesSQL());
                    query.readStart();
                    while (query.read()) {
                        retBaseIds.add(AdmHelperCmd.newAdmBaseId(query.getLong(1), RelationshipType.class, null,
                                AdmHelperCmd.newAdmBaseId(query.getString(2), RelationshipType.class, null, null)));
                    }
                }
            } else if (admParentClass.equals(Part.class)) {
                if (admObjClass.equals(ChangeDocument.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_AFFECTED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_AFFECTED, RelationshipType.class, null, null)));
                } else if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));

                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_USAGE, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_USAGE, RelationshipType.class, null, null)));
                } else if (admObjClass.equals(Part.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));

                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_USAGE, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_USAGE, RelationshipType.class, null, null)));
                }
            } else if (admParentClass.equals(WorkSet.class)) {
                if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));
                } else if (admObjClass.equals(WorkSet.class)) {
                    // Add INFO as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_INFO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_INFO, RelationshipType.class, null, null)));

                    // Add USAGE as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_USAGE, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_USAGE, RelationshipType.class, null, null)));
                } else if (admObjClass.equals(Baseline.class)) {
                    // Add INFO as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_INFO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_INFO, RelationshipType.class, null, null)));

                    // Add USAGE as a hard-coded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_USAGE, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_USAGE, RelationshipType.class, null, null)));

                } else if (admObjClass.equals(ChangeDocument.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));
                } else if (admObjClass.equals(ExternalRequest.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));
                }
            } else if (admParentClass.equals(Requirement.class)) {
                if (admObjClass.equals(ChangeDocument.class)) {
                    // * Add Breakdown as a hardcoded reltype
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));
                }
            } else if (admParentClass.equals(Baseline.class) && admObjClass.equals(Baseline.class)) {
                // * Add Usage as a hardcoded reltype
                retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_USAGE, RelationshipType.class, null,
                        AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_USAGE, RelationshipType.class, null, null)));
            } else if (admParentClass.equals(ExternalRequest.class)) {
                if (admObjClass.equals(WorkSet.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_OWNED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_OWNED, RelationshipType.class, null, null)));
                } else if (admObjClass.equals(Baseline.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_AFFECTED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_AFFECTED, RelationshipType.class, null, null)));
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_AFFECTED_REVISED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_AFFECTED_REVISED, RelationshipType.class, null, null)));
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_IN_RESPONSE_TO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_IN_RESPONSE_TO, RelationshipType.class, null, null)));
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_IN_RESPONSE_TO_REVISED, RelationshipType.class,
                            null, AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_IN_RESPONSE_TO_REVISED, RelationshipType.class,
                                    null, null)));
                } else if (admObjClass.equals(Item.class) || admObjClass.equals(ItemFile.class)) {
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_AFFECTED, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_AFFECTED, RelationshipType.class, null, null)));
                    retBaseIds.add(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_IN_RESPONSE_TO, RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_IN_RESPONSE_TO, RelationshipType.class, null, null)));
                }
            }
        }

        return retBaseIds;
    }

    private String getChdocToChdocClassRelTypesSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT reltype_uid, reltype_name FROM user_rel_types WHERE ");
        query.append("product_id=:I1 AND (parent_class_uid=");
        query.append(String.valueOf(Constants.RELTYPE_UID_DEPENDENT));
        query.append(" OR parent_class_uid=");
        query.append(String.valueOf(Constants.RELTYPE_UID_INFO));
        query.append(") ");
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getChdocClassToChdocClassRelTypesSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT reltype_uid, reltype_name FROM user_rel_types WHERE ");
        query.append("parent_class_uid=");
        query.append(String.valueOf(Constants.RELTYPE_UID_DEPENDENT));
        query.append(" OR parent_class_uid=");
        query.append(String.valueOf(Constants.RELTYPE_UID_INFO));
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getItemToItemRelTypesSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT cc.obj_uid, cc.obj_id FROM cpl_catalogue cc, cpl_attributes ca, obj_types ot, obj_types ot2 ");
        query.append("WHERE ot.product_id=:I1 AND ot.type_name=:I2 AND ot.type_flag='I' AND ca.attr_3 = TO_CHAR(ot.type_uid) AND ");
        query.append("ot2.product_id=:I3 AND ot2.type_name=:I4 AND ot2.type_flag = 'I' AND ca.attr_4 = TO_CHAR(ot2.type_uid) AND ");
        query.append("ca.obj_uid = cc.obj_uid AND cc.obj_class=9");
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getItemToItemClassRelTypesSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT cc.obj_uid, cc.obj_id FROM cpl_catalogue cc, cpl_attributes ca, obj_types ot, obj_types ot2 ");
        query.append("WHERE ot.product_id=:I1 AND ot.type_name=:I2 AND ot.type_flag='I' AND ca.attr_3 = TO_CHAR(ot.type_uid) AND ");
        query.append("ot2.type_flag = 'I' AND ca.attr_4 = TO_CHAR(ot2.type_uid) AND ");
        query.append("ca.obj_uid = cc.obj_uid AND cc.obj_class=9");
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getItemClassToItemClassRelTypesSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT obj_uid, obj_id FROM cpl_catalogue ");
        query.append("WHERE obj_class=9");
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getItemClassToItemTypeRelTypesSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT cc.obj_uid, cc.obj_id FROM cpl_catalogue cc, cpl_attributes ca, obj_types ot WHERE ot.product_id=:I1 AND ");
        query.append("ot.type_name=:I2 AND ot.type_flag='I' AND ca.attr_4 = TO_CHAR(ot.type_uid) AND ca.obj_uid = cc.obj_uid AND cc.obj_class=9 ");
        query.append(" ORDER BY 2");
        String sql = new String(query);
        query = null;
        return sql;
    }

    private String getItemTypeToItemClassRelTypesSQL() {
        StringBuffer query = new StringBuffer();
        query.append("SELECT DISTINCT cc.obj_uid, cc.obj_id FROM cpl_catalogue cc, cpl_attributes ca, obj_types ot WHERE ot.product_id=:I1 AND ");
        query.append("ot.type_name=:I2 AND ot.type_flag='I' AND ca.attr_3 = TO_CHAR(ot.type_uid) AND ca.obj_uid = cc.obj_uid AND cc.obj_class=9 ");
        query.append("ORDER BY 2");
        String sql = new String(query);
        query = null;
        return sql;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttrRuleException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimInvalidRoleException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.AttributeUpdateRule;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.UpdateRulesObject;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions AttributeUpdateRule.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>TYPE{AdmObject}<dt><dd>Dimensions Type object for which the attribute update rule is to be created</dd>
 *  <dt>ID{String}<dt><dd>Dimensions Attribute name</dd>
 *  <dt>ATTRRULE_ROLE_NAME{String}<dt><dd>User role</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ATTRRULE_IS_DISPLAYABLE{Boolean}<dt>
 *  <dd>Whether the attribute is displayable in the attribute's role section. Default - Boolean.TRUE</dd>
 *  <dt>ATTRRULE_CURRENT_STATUS{String}<dt>
 *  <dd>What state the object must reside in order to allow or disallow updates to the attribute. A null value
 *     is taken to mean any lifecycle state. Default - null</dd>
 *  <dt>ATTRRULE_IS_UPDATABLE{Boolean}<dt>
 *  <dd>Whether the attribute is updatable at the state specified by ATTRRULE_CURRENT_STATUS. Default - Boolean.FALSE</dd>
 *  <dt>ATTRRULE_IS_MANDATORY{Boolean}<dt>
 *  <dd>Whether the attribute must have a value when actioned to the state specified by ATTRRULE_NEW_STATUS. Default - Boolean.FALSE</dd>
 *  <dt>ATTRRULE_NEW_STATUS{String}<dt>
 *  <dd>What state the object must reside in order to require a value of the attribute. A null value
 *     is taken to mean any lifecycle state. This attribute is invalid for product level attributes and will raise an exception. Default - null</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateAttrUpdateRuleCmd extends DBIOCmd {
    public CreateAttrUpdateRuleCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE, true, Type.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRRULE_ROLE_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRRULE_IS_DISPLAYABLE, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRRULE_CURRENT_STATUS, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRRULE_IS_UPDATABLE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRRULE_NEW_STATUS, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRRULE_IS_MANDATORY, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject typeObj = (AdmObject) getAttrValue(AdmAttrNames.TYPE);
        String attrName = (String) getAttrValue(AdmAttrNames.ID);
        String roleName = (String) getAttrValue(AdmAttrNames.ATTRRULE_ROLE_NAME);
        boolean isDislayable = ((Boolean) getAttrValue(AdmAttrNames.ATTRRULE_IS_DISPLAYABLE)).booleanValue();
        String currentState = (String) getAttrValue(AdmAttrNames.ATTRRULE_CURRENT_STATUS);
        boolean isUpdatable = ((Boolean) getAttrValue(AdmAttrNames.ATTRRULE_IS_UPDATABLE)).booleanValue();
        String newState = (String) getAttrValue(AdmAttrNames.ATTRRULE_NEW_STATUS);
        boolean isMandatory = ((Boolean) getAttrValue(AdmAttrNames.ATTRRULE_IS_MANDATORY)).booleanValue();

        long typeUid = ((AdmUidObject) typeObj).getAdmUid().getUid();
        List attrs = AdmHelperCmd.getAttributeValues(
                typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS,
                        AdmAttrNames.LIFECYCLE_ID }));
        String productName = (String) attrs.get(0);
        String typeName = (String) attrs.get(1);
        Class typeClass = (Class) attrs.get(2);
        String lifecycleId = (String) attrs.get(3);
        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        // VALIDATE_ENTRY - BEGIN
        // type must exist
        if (!DoesExistHelper.typeExists(productName, typeName, typeFlag)) {
            throw new DimAlreadyExistsException("Error: Dimensions " + TypeUtils.getClassName(typeClass) + "Type " + productName
                    + ":" + typeName + " does not exist");
        }

        // type must have a lifecycle
        if (lifecycleId == null || lifecycleId.length() == 0) {
            throw new DimInvalidAttributeException("Error: " + TypeUtils.getClassName(typeClass) + " Type " + productName + ":"
                    + typeName
                    + " does not have a lifecycle. Attribute rules are defined in relation to lifecycle roles and states.");
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

        // validate attribute name
        attrName = StringUtils.adjustValue(attrName, AdmDmLengths.DM_L_ATTR_VARIABLE);
        if (attrName == null || attrName.length() == 0) {
            throw new DimInvalidAttributeException("Error: attribute name must be specified");
        }

        // validate role
        roleName = StringUtils.adjustValue(roleName, AdmDmLengths.DM_L_ROLE);
        if (roleName == null || roleName.length() == 0) {
            throw new DimInvalidAttributeException("Error: user role must be specified");
        }

        if (Constants.GLOBAL_PRODUCT.equals(productName) && "PRODUCT".equals(typeName) && Part.class.equals(typeClass)) {
            if (!isValidProductLevelRole(roleName)) {
                throw new DimInvalidAttrRuleException("Error: role name " + roleName
                        + " is invalid for a product level attribute update rule");
            }
        } else if (!isValidRole(lifecycleId, roleName)) {
            throw new DimInvalidAttrRuleException("Error: role name " + roleName + " is invalid");
        }

        // validate attrno
        AdmObject attrObj = getLocalAttrDef(attrName, typeObj);
        if (attrObj == null) {
            throw new DimAlreadyExistsException("Error: " + TypeUtils.getClassName(typeClass) + " Type " + productName + ":"
                    + typeName + " attribute + " + attrName + " does not exist.");
        }

        int attrNo = ((Integer) attrObj.getAttrValue(AdmAttrNames.ATTRDEF_ATTRNO)).intValue();

        if (!isValidAttrNo(typeUid, attrNo)) {
            throw new DimAlreadyExistsException("Error: " + TypeUtils.getClassName(typeClass) + " Type " + productName + ":"
                    + typeName + " attribute + " + attrName + " does not exist.");
        }

        if (attrNo == Constants.ATTRDEF_PCMS_CHDOC_DETAIL_DESC_UID && isDislayable) {
            throw new DimInvalidAttrRuleException(
                    "Error: Cannot include system attribute PCMS_CHDOC_DETAIL_DESC in any role section.");
        }

        // create the update rule object corresponding to the type
        long ruleObjUid = getRuleObjectUid(typeObj);

        // validate current state if specified
        currentState = StringUtils.adjustValue(currentState, AdmDmLengths.DM_L_STATUS);
        if (currentState != null && currentState.length() == 0) {
            currentState = null;
        }
        if (currentState != null) {
            if (Constants.GLOBAL_PRODUCT.equals(productName) && "PRODUCT".equals(typeName) && Part.class.equals(typeClass)) {
                if (!isValidProductLevelFromState(currentState)) {
                    throw new DimInvalidAttrRuleException("Error: current status " + currentState
                            + " is invalid for a product level attribute");
                }
            } else if (!isValidFromState(lifecycleId, currentState)) {
                throw new DimInvalidAttrRuleException("Error: current status " + currentState + " is invalid");
            }

            if (Constants.SYS_STATE_PENDING.equals(currentState) && !isUpdatable) {
                throw new DimInvalidAttrRuleException("Error: rule Updateable=False is not currently supported for status $PENDING");
            }

            if (Constants.SYS_STATE_TO_BE_DEFINED.equals(currentState) && !Constants.ORIGINATOR.equals(roleName)) {
                throw new DimInvalidAttrRuleException(
                        "Error: Current Status $TO_BE_DEFINED is only applicable to the role $ORIGINATOR");
            }
        }

        // validate new state if specified
        newState = StringUtils.adjustValue(newState, AdmDmLengths.DM_L_STATUS);
        if (newState != null && newState.length() == 0) {
            newState = null;
        }
        if (currentState != null && newState != null) {
            if (newState != null) {
                if (Constants.GLOBAL_PRODUCT.equals(productName) && "PRODUCT".equals(typeName) && Part.class.equals(typeClass)) {
                    throw new DimInvalidAttrRuleException("Error: new status " + newState
                            + " is invalid for a product level attribute update rule");
                }
                if (!isValidToState(lifecycleId, newState)) {
                    if ((!currentState.equals(Constants.TO_BE_DEFINED)) || (!isValidFromState(lifecycleId, newState))) {
                        throw new DimInvalidAttrRuleException("Error: new status " + newState + " is invalid");
                    }
                }
            }
        }
        boolean isValid = true;

        // validate transition
        if (currentState != null && !currentState.equals(Constants.SYS_STATE_PENDING)
                && !currentState.equals(Constants.SYS_STATE_TO_BE_DEFINED) && newState != null && roleName != null) {
            if (!isValidTransition(lifecycleId, currentState, newState, roleName)) {
                // needs to be a warning rather than throw an exception
                isValid = false;
                /*
                 * throw new DimInvalidAttrRuleException(
                 * "Error: Attribute rule does not correspond to a valid transition.");
                 */
            }
        }

        if (isMandatory && !isUpdatable) {
            throw new DimInvalidAttrRuleException("Error: Cannot have a rule where Updateable=False and Mandatory=True");
        }

        if (attrNo != Constants.ATTRDEF_PCMS_CHDOC_DETAIL_DESC_UID && isMandatory && !isDislayable) {
            throw new DimInvalidAttrRuleException("Error: Attribute " + attrName
                    + "is not included in the Role Section and yet a value for it is mandatory.");
        }

        if (newState != null && currentState == null) {
            throw new DimInvalidAttrRuleException(
                    "Error: Because New Status is specified then Current Status must also be specified.");
        }

        if (newState != null && currentState != null && currentState.equals(newState)) {
            throw new DimInvalidAttrRuleException("Error: New Status must not be the same as Current Status.");
        }

        if (currentState == null && newState == null && isMandatory) {
            throw new DimInvalidAttrRuleException(
                    "Error: You have specified 'attribute must have a value' but not specified a Current Status.");
        }

        // check is "updatable" is consistent; USE a different query WHEN UPDATING!
        boolean isInconsistent = checkUpdateableConsistency(ruleObjUid, attrNo, roleName, currentState, isUpdatable);
        if (isInconsistent && !isUpdatable) {
            throw new DimInvalidRoleException("Error: Inconsistency detected - found a rule for the attribute " + attrName
                    + " and role " + roleName + " where Updateable is True rather than False.");
        } else if (isInconsistent && isUpdatable) {
            throw new DimInvalidRoleException("Error: Inconsistency detected - found a rule for the attribute " + attrName
                    + " and role " + roleName + " where Updateable is False rather than True.");
        }

        if (duplicatesExist(ruleObjUid, attrNo, roleName, currentState, newState)) {
            throw new DimAlreadyExistsException("Error: this rule already exists");
        }

        // VALIDATE_ENTRY - END

        // form specification for the attribute rule
        String spec = ruleObjUid + ":" + attrNo + ":" + roleName;
        if (currentState != null) {
            spec += ":" + currentState;
            if (newState != null) {
                spec += ":" + newState;
            }
        }

        setAttrValue(CmdArguments.INT_SPEC, spec);

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);
            // do insert
            query.resetMessage(wcm_sql.ATTRRULE_INSERT_NORMAL_RULE);
            query.bindInput(ruleObjUid); // obj_uid
            query.bindInput(attrNo); // attr_1
            query.bindInput(roleName); // attr_2
            query.bindInput(currentState, String.class); // attr_3
            query.bindInput(isMandatory ? "Y" : "N"); // attr_4
            query.bindInput(isUpdatable ? "Y" : "N"); // attr_5
            query.bindInput(isDislayable ? "Y" : "N"); // attr_6
            query.bindInput(newState, String.class); // attr_7
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

            // do post_insert
            if (Constants.GLOBAL_PRODUCT.equals(productName) && "PRODUCT".equals(typeName) && Part.class.equals(typeClass)) {
                doCopyRulesX(query, typeFlag, typeUid);
            }
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }
        AdmResult retResult = null;
        if (isValid) {
            retResult = new AdmResult("Operation completed");
        } else {
            retResult = new AdmResult("Operation completed with warnings - "
                    + "Attribute rule does not correspond to a valid transition between states '" + currentState + "' and '"
                    + newState + "' for role '" + roleName + "'.");
        }
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, AttributeUpdateRule.class);
        return retResult;
    }

    private long getRuleObjectUid(AdmObject typeObj) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, typeObj);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, UpdateRulesObject.class);
        AdmBaseId ruleBaseId = (AdmBaseId) cmd.execute();

        if (ruleBaseId == null) {
            // create rules object
            cmd = AdmCmd.getCmd(Creatable.CREATE, UpdateRulesObject.class);
            cmd.setAttrValue(AdmAttrNames.TYPE, typeObj);
            AdmResult cmdResult = (AdmResult) cmd.execute();
            ruleBaseId = (AdmBaseId) cmdResult.getUserData();
            if (ruleBaseId == null) {
                throw new DBIOException("Error: failed to create attribute update rules object");
            }
        }

        AdmObject rulesObj = AdmHelperCmd.getObject(ruleBaseId, AdmAttrNames.ADM_UID);
        long rulesObjectUid = ((AdmUidObject) rulesObj).getAdmUid().getUid();
        return rulesObjectUid;
    }

    private boolean duplicatesExist(long ruleObjUid, int attrNo, String roleName, String currentState, String newState)
            throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(new Long(ruleObjUid));
        inputs.add(new Integer(attrNo));
        inputs.add(roleName);
        inputs.add(currentState != null ? currentState : "$$$&&&");
        inputs.add(newState != null ? newState : "$$$&&&");

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_CHECK_FOR_DUPLICATES_ON_INSERT));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    private boolean checkUpdateableConsistency(long ruleObjUid, int attrNo, String roleName, String currentState,
            boolean isUpdatable) throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(new Long(ruleObjUid));
        inputs.add(new Integer(attrNo));
        inputs.add(roleName);
        inputs.add(currentState != null ? currentState : "$$$&&&");
        inputs.add(isUpdatable ? "Y" : "N");

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_CHECK_UPDATEABLE_CONSISTENCY_ON_INSERT));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Check if the "ATTRIBUTE_NUMBER" of an attribute rule is valid
     */
    private boolean isValidAttrNo(long typeUid, int attrNo) throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(new Long(typeUid));
        inputs.add(new Integer(attrNo));

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_IS_VALID_ATTRNO_80));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Check if the "USER ROLE" of an product level attribute rule is valid
     */
    private boolean isValidProductLevelRole(String roleName) throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(roleName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_IS_VALID_PRODUCT_LEVEL_ROLE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Check if the "USER ROLE" of an attribuet rule is valid
     */
    private boolean isValidRole(String lifecycleId, String roleName) throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(lifecycleId);
        inputs.add(roleName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_IS_VALID_ROLE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Check if the "CURRENT STATUS" of an product level attribuet rule is valid
     */
    private boolean isValidProductLevelFromState(String state) throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(state);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_IS_VALID_PRODUCT_LEVEL_FROM_STATE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Check if the "CURRENT STATUS" of an attribuet rule is valid
     */
    private boolean isValidFromState(String lifecycleId, String state) throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(lifecycleId);
        inputs.add(state);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_IS_VALID_FROM_STATE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Check if the "NEW_STATUS" of an attribute rule is valid
     */
    private boolean isValidToState(String lifecycleId, String state) throws AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(lifecycleId);
        inputs.add(state);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.ATTRRULE_IS_VALID_TO_STATE));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Check if the transition is valid
     */
    private boolean isValidTransition(String lifecycleId, String fromState, String toState, String roleName) throws AdmException {
        DBIO query = new DBIO("SELECT lifecycle_id FROM life_cycles " + "WHERE lifecycle_id = :I1 AND doc_status = :I2 "
                + "AND next_doc_status = :I3 AND role = :I4");

        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.bindInput(roleName);

        query.readStart();
        boolean exists = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        return exists;
    }

    private AdmObject getLocalAttrDef(String attrName, AdmObject typeObj) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, typeObj, LocalAttributeDefinition.class);
        Filter filt = new FilterImpl();
        Collection criteria = filt.criteria();
        criteria.add(new FilterCriterion(AdmAttrNames.ID, attrName));
        cmd.setAttrValue(CmdArguments.FILTER, filt);

        AdmBaseId baseId = (AdmBaseId) cmd.execute();
        AdmObject attrObj = null;
        if (baseId != null) {
            attrObj = AdmHelperCmd.getObject(baseId, Arrays.asList(new Object[] { AdmAttrNames.ATTRDEF_ATTRNO }));
        }

        return attrObj;
    }

    class TypeData {
        long typeUid;
        String typeName;
        String productName;
        String lifecycleId;

        public TypeData(long typeUid, String typeName, String productName, String lifecycleId) {
            this.typeUid = typeUid;
            this.typeName = typeName;
            this.productName = productName;
            this.lifecycleId = lifecycleId;
        }
    }

    private void doCopyRulesX(DBIO query, String typeFlag, long fromTypeUid) throws AdmException {
        query.resetMessage(wcm_sql.LIST_PART_PRODUCT_TYPES);

        LinkedList list = new LinkedList();

        query.readStart();
        while (query.read(DBIO.DB_DONT_CLOSE)) {
            TypeData td = new TypeData(query.getLong(1), query.getString(2), query.getString(3), query.getString(4));
            list.add(td);
        }
        query.close(DBIO.DB_DONT_RELEASE);

        if (list.size() > 0) {
            for (Iterator iter = list.iterator(); iter.hasNext();) {

                TypeData element = (TypeData) iter.next();

                long toTypeUid = element.typeUid; // iUid
                String toTypeName = element.typeName; // / typeName
                String toProductName = element.productName;
                String toLifecycleId = element.lifecycleId;

                query.resetMessage(wcm_sql.ATTRRULE_GET_RULE_UID);
                query.bindInput(toTypeUid);
                query.bindInput(typeFlag);
                query.readStart();

                long toRulesObjectUid = -1;
                if (query.read(DBIO.DB_DONT_CLOSE)) {
                    toRulesObjectUid = query.getLong(1);
                }
                query.close(DBIO.DB_DONT_RELEASE);

                if (toRulesObjectUid == -1) {
                    toRulesObjectUid = createAttribRulesObject(query, toProductName, typeFlag, toTypeName, toTypeUid);
                }

                copyObjectAttributeRules(query, "P", fromTypeUid, toLifecycleId, toTypeUid, toRulesObjectUid);
            }
        }
    }

    private void copyObjectAttributeRules(DBIO query, String typeFlag, long fromTypeUid, String toLifecycleId, long toTypeUid,
            long toRulesObjectUid) throws AdmException {

        SqlUtils.attrruleDeleteRuleDetails(query, toRulesObjectUid);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.copyTypeAttrRules(query, typeFlag, fromTypeUid, toLifecycleId, toTypeUid, toRulesObjectUid);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);
    }

    private long createAttribRulesObject(DBIO query, String productName, String typeFlag, String typeName, long typeUid)
            throws AdmObjectException, DBIOException, DimBaseException, AdmException {

        int objClass = 1;
        char scope = typeFlag.charAt(0);

        if (scope == 'C') {
            objClass = 1;
        } else if (scope == 'I') {
            objClass = 50;
        } else if (scope == 'P') {
            objClass = 51;
        } else if (scope == 'B') {
            objClass = 53;
        } else if (scope == 'U') {
            objClass = 54;
        } else if (scope == 'W') {
            objClass = 61;
        }

        String userId = ((User) AdmCmd.getCurRootObj(User.class)).getId();

        long rulesUid = getNewUid(query);

        query.resetMessage(wcm_sql.ATTRRULE_INSERT_RULE_OBJECT);
        query.bindInput(rulesUid);
        query.bindInput(typeName);
        query.bindInput(objClass);
        query.bindInput(productName);
        query.bindInput(userId);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.attrruleRelateToType(query, typeUid, rulesUid, objClass);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        return rulesUid;

    }

}

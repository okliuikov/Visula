/*
 * Copyright 2003, 2006 Serena Software, Inc.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.versionable;

import java.io.File;
import java.util.List;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.Options;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Perform a build.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions Baseline object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>BUILD_AREA {String}</dt><dd>Build area ID</dd>
 *  <dt>AUDIT {Boolean}</dt><dd>Signifies an audit if true</dd>
 *  <dt>BATCH {Boolean}</dt><dd>Signifies a batch job if true</dd>
 *  <dt>BUILD_CONFIG {String}</dt><dd>Build config ID</dd>
 *  <dt>BUILD_OPTIONS {String}</dt><dd>Build options</dd>
 *  <dt>BUILDTARGET_LIST {List(AdmObject)}</dt><dd>Optional List of BuildTarget objects</dd>
 *  <dt>CAPTURE_BUILD_OUTPUTS {Boolean}</dt><dd>Signifies whether to capture outputs</dd>
 *  <dt>CLEAN {Boolean}</dt><dd>Clean the area before each build</dd>
 *  <dt>RELATED_CHDOCS {String}</dt><dd>Change Documents</dd>
 *  <dt>TOUCH {Boolean}</dt><dd>Apply system date/time to downloaded files</dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Pauls
 */
public class BuildBaselineCmd extends RPCExecCmd {
    private File tempTgtFile = null;

    public BuildBaselineCmd() throws AttrException {
        super();
        setAlias(Versionable.BUILD_BASELINE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.BATCH, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_CONFIG_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_OPTIONS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BUILDTARGET_LIST, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_AREA, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CAPTURE_BUILD_OUTPUTS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CAPTURE_BUILD_PROJECT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLEAN, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.LOCK, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.TOUCH, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_PASSWORD, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Baseline)) {
                throw new AttrException("Error: BuildBaselineCmd Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(AdmAttrNames.BUILD_CONFIG_ID)) {
            if (!(attrValue instanceof String)) {
                throw new AttrException("Error: BuildBaselineCmd Object type is not supported!", attrDef, attrValue);
            }
            if (attrValue == null) {
                throw new AttrException("Error: BuildBaselineCmd attribute is not specified!", attrDef, attrValue);
            }
        }

        if (name.equals(AdmAttrNames.BUILD_AREA)) {
            if (!(attrValue instanceof String)) {
                throw new AttrException("Error: BuildBaselineCmd Object type is not supported!", attrDef, attrValue);
            }
            if (attrValue == null) {
                throw new AttrException("Error: BuildBaselineCmd attribute is not specified!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        try {
            return executeRpc(null, null, true).getStructuredResult();
        } finally {
            if (tempTgtFile != null && tempTgtFile.exists()) {
                if (!tempTgtFile.delete()) {
                    tempTgtFile.deleteOnExit();
                }
            }
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String buildAreaID = (String) getAttrValue(AdmAttrNames.BUILD_AREA);
        boolean clean = ((Boolean) getAttrValue(CmdArguments.CLEAN)).booleanValue();
        boolean lock = ((Boolean) getAttrValue(CmdArguments.LOCK)).booleanValue();
        boolean batch = ((Boolean) getAttrValue(CmdArguments.BATCH)).booleanValue();
        String buildConfigID = (String) getAttrValue(AdmAttrNames.BUILD_CONFIG_ID);
        String buildOptions = (String) getAttrValue(AdmAttrNames.BUILD_OPTIONS);
        List buildTargets = (List) getAttrValue(CmdArguments.BUILDTARGET_LIST);
        String changeDocuments = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        boolean capture = ((Boolean) getAttrValue(CmdArguments.CAPTURE_BUILD_OUTPUTS)).booleanValue();
        String captureProject = (String) getAttrValue(CmdArguments.CAPTURE_BUILD_PROJECT);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        boolean touch = ((Boolean) getAttrValue(CmdArguments.TOUCH)).booleanValue();
        String user_name = (String) getAttrValue(CmdArguments.USER_NAME);
        String user_pwd = (String) getAttrValue(CmdArguments.USER_PASSWORD);

        StringBuffer sb = new StringBuffer();
        sb.append("BLDB " + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));

        sb.append(" /AREA=" + Encoding.escapeDMCLI(buildAreaID));

        // This string should include the version of the config as well
        if (buildConfigID != null && !buildConfigID.equals("")) {
            sb.append(" /BUILD_CONFIG=" + Encoding.escapeDMCLI(buildConfigID));
        }

        if (buildOptions != null && !buildOptions.equals("")) {
            sb.append(" /BUILD_OPTIONS=" + buildOptions);
        }

        if (capture) {
            sb.append(" /CAPTURE");

            // Only add chg docs if we are capturing outputs
            if (changeDocuments != null && !changeDocuments.equals("")) {
                if (changeDocuments.startsWith("\"") && changeDocuments.endsWith("\"")) {
                    sb.append(" /CHANGE_DOC_IDS=(" + changeDocuments + ")");
                } else {
                    sb.append(" /CHANGE_DOC_IDS=(" + Encoding.escapeDMCLI(changeDocuments) + ")");
                }
            }
            if (captureProject != null && captureProject.trim().length() > 0) {
                sb.append(" /TARGET_PROJECT=" + Encoding.escapeDMCLI(captureProject));
            }
        } else {
            sb.append(" /NOCAPTURE");
        }

        if (buildTargets != null && buildTargets.size() > 0) {
            if (buildTargets.size() > Options.getLimitNumberItemsToUseFiles()) {
                String targetFileName = "";
                if (preview) {
                    targetFileName = "<temporary_file_targets>";
                } else {
                    tempTgtFile = BuildCmd.getTempFile(buildTargets);
                    if (tempTgtFile != null) {
                        targetFileName = tempTgtFile.getAbsolutePath();
                    }
                }
                sb.append(" /TARGETS_LIST=" + Encoding.escapeDMCLI(targetFileName));
            } else {
                sb.append(" /TARGETS=(");
                for (int i = 0; i < buildTargets.size(); i++) {
                    if (i > 0) {
                        sb.append(", ");
                    }
                    sb.append(Encoding.escapeDMCLI((String) buildTargets.get(i)));
                }
                sb.append(")");
            }
        }

        sb.append(touch ? " /TOUCH" : "");

        if (user_name != null && user_name.trim().length() > 0) {
            sb.append(" /USER=" + Encoding.escapeDMCLI(user_name));
        }

        if (user_pwd != null && user_pwd.trim().length() > 0) {
            if (preview) {
                user_pwd = "*****";
            }
            sb.append(" /PASSWORD=" + Encoding.escapeDMCLI(user_pwd));
        }

        if (userFile != null && !userFile.equals("")) {
            sb.append(" /USER_FILENAME=" + Encoding.escapeDMCLI(userFile));
            if (!userFile.endsWith(".htm") && !userFile.endsWith(".html")) {
                sb.append(" /HTML_FRAGMENT");
            }
        }

        sb.append(batch ? " /WAIT" : " /NOWAIT");
        sb.append(clean ? " /BUILD_CLEAN" : " /NOBUILD_CLEAN");
        sb.append(lock ? " /LOCK_SEARCH_PATH" : "");

        _cmdStr = sb.toString();
    }
}

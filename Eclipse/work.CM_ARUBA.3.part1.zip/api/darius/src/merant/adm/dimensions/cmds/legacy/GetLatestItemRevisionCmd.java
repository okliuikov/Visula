/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * PVCS:GETITEMFILEFROMFILENAMECM.A-SRC;impulse#1
 * Description:
 * Item GETITEMFILEFROMFILENAMECM.A
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.legacy;

import com.serena.dmnet.RPC;
import com.serena.dmnet.drs.DRSClientGetLatestItemRevision;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimItemFileNotFoundException;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Legacy command to obtain an latest revision of ItemFile.
 * <p>
 * 
 * Used as workaround to CheckInCmd (RI command) as it doesn't returns ItemSpec in case when DM CM configured in
 * "Check in only changed revisions" mode and check-in performed with the same contents as in the repository and check-in/RI command
 * itself performs CIU (Cancel Item Update) command or stays in the same revision.
 * 
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ITEM {Item}<dt><dd>Dimensions object</dd>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmObject}<dt><dd>Populated ItemFile object represented the latest version of the specified Item</dd>
 * </dl></code>
 */
public class GetLatestItemRevisionCmd extends DBIOCmd {
    public GetLatestItemRevisionCmd() throws AttrException {
        super();
        setAlias("GetLatestItemRevisionCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ITEM, true, Item.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        Item item = (Item) getAttrValue(CmdArguments.ITEM);
        WorkSet project = (WorkSet) getAttrValue(CmdArguments.WORKSET);

        String itemProductId = (String) item.getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String itemId = (String) item.getAttrValue(AdmAttrNames.ID);
        String itemVariant = (String) item.getAttrValue(AdmAttrNames.VARIANT);
        String itemTypeName = (String) item.getAttrValue(AdmAttrNames.TYPE_NAME);
        AdmUid wsetAdmUid = project.getAdmUid();

        // Prepare DRS query

        DRSClientGetLatestItemRevision drsClientGetLatestItemRevision = new DRSClientGetLatestItemRevision(
                DRSUtils.getLCNetClntObject());
        drsClientGetLatestItemRevision.setProductId(itemProductId);
        drsClientGetLatestItemRevision.setItemId(itemId);
        drsClientGetLatestItemRevision.setItemVariant(itemVariant);
        drsClientGetLatestItemRevision.setItemTypeName(itemTypeName);
        drsClientGetLatestItemRevision.setWorksetUid(wsetAdmUid.getUid());

        DRSQuery drsQuery = new DRSQuery(drsClientGetLatestItemRevision);
        DRSOutputDataExtractor drsOutputDataExtractor = drsQuery.execute();
        if (drsOutputDataExtractor.hasRPCExecutionFailed()) {
            throw new DRSException("Error during call of DRS function " + DRSClientGetLatestItemRevision.dataRequestId
                    + " via RPC(" + RPC.RPC_DATA_REQUEST + ")");
        } else if (!drsOutputDataExtractor.isResultEmpty()) {
            ItemFile itemFile = new ItemFile(new AdmUid(drsOutputDataExtractor.getIntValues(DRSParams.OBJ_UID)[0], ItemFile.class,
                    wsetAdmUid));
            itemFile.setAdmSpec(new AdmSpec(drsOutputDataExtractor.getStringValues(DRSParams.ITEM_SPEC)[0], ItemFile.class,
                    wsetAdmUid));
            itemFile.setAttrValue(AdmAttrNames.PARENT_UID, new AdmUid(drsOutputDataExtractor.getIntValues(DRSParams.DIR_UID)[0],
                    DimDirectory.class, wsetAdmUid));
            itemFile.setAttrValue(AdmAttrNames.PARENT_DIR_UID, new AdmUid(
                    drsOutputDataExtractor.getIntValues(DRSParams.DIR_UID)[0], DimDirectory.class, wsetAdmUid));
            itemFile.setAttrValue(AdmAttrNames.PARENT_DIR_NAME, drsOutputDataExtractor.getStringValues(DRSParams.FULL_PATH)[0]);
            itemFile.setAttrValue(AdmAttrNames.ITEMFILE_FILENAME, drsOutputDataExtractor.getStringValues(DRSParams.FILE_NAME)[0]);
            itemFile.setAttrValue(AdmAttrNames.DIMFILE_LENGTH,
                    new Integer(drsOutputDataExtractor.getIntValues(DRSParams.LENGTH)[0]));
            itemFile.setAttrValue(AdmAttrNames.ITEM_FILE_VERSION,
                    new Integer(drsOutputDataExtractor.getIntValues(DRSParams.FILE_VERSION)[0]));
            itemFile.setAttrValue(AdmAttrNames.CREATE_DATE, drsOutputDataExtractor.getStringValues(DRSParams.CREATED_DATE_TIME)[0]);
            itemFile.setAttrValue(AdmAttrNames.UPDATE_DATE, drsOutputDataExtractor.getStringValues(DRSParams.UPDATED_DATE_TIME)[0]);
            itemFile.setAttrValue(AdmAttrNames.DESCRIPTION, drsOutputDataExtractor.getStringValues(DRSParams.DESCRIPTION)[0]);
            itemFile.setAttrValue(AdmAttrNames.USER_NAME, drsOutputDataExtractor.getStringValues(DRSParams.OBJ_USER_NAME)[0]);
            itemFile.setAttrValue(AdmAttrNames.ITEM_FILE_VERSION, drsOutputDataExtractor.getIntValues(DRSParams.FILE_VERSION)[0]);
            itemFile.setAttrValue(AdmAttrNames.ITEM_IS_EXTRACTED, drsOutputDataExtractor.getStringValues(DRSParams.EXTRACTED)[0]);
            return itemFile;
        } else {
            throw new DimItemFileNotFoundException();
        }
    }
}

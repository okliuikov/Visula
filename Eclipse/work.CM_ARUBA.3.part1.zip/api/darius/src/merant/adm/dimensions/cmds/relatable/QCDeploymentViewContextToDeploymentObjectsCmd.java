/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.serena.dmnet.ListDeploymentViewResult;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.helper.IDeploymentViewConstants;
import merant.adm.dimensions.cmds.helper.RangeInfo;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.DeploymentHistoryRecord;
import merant.adm.dimensions.objects.DeploymentJob;
import merant.adm.dimensions.objects.DeploymentViewContext;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.ScheduledJob;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Returns list of pending deployments for ( Requests , Baselines or Items )
 */
public class QCDeploymentViewContextToDeploymentObjectsCmd extends RPCCmd implements IDeploymentViewConstants {
    private static int GLOBAL_FLAG_USE_CACHE = 0x00;
    private static int GLOBAL_FLAG_IGNORE_CACHE = 0x01;

    private static Map attrNamesToNumbers;
    static {
        attrNamesToNumbers = new HashMap(SuperQuery.getAttrToNumMap());
        attrNamesToNumbers.put(AdmAttrNames.PROMOTED_DATE, new Integer(-4901));
        attrNamesToNumbers.put(AdmAttrNames.PROMOTED_BY, new Integer(-4902));
        attrNamesToNumbers.put(AdmAttrNames.DEPLOYED_DATE, new Integer(-4903));
        attrNamesToNumbers.put(AdmAttrNames.DEPLOYED_BY, new Integer(-4904));
        attrNamesToNumbers.put(AdmAttrNames.RELATED_ITEM_UID, new Integer(-4905));
        attrNamesToNumbers.put(AdmAttrNames.RELATED_ITEM_SPEC_UID, new Integer(-4906));
        attrNamesToNumbers.put(AdmAttrNames.HISTORY_EVENT_DATE, new Integer(-4907));
        attrNamesToNumbers.put(AdmAttrNames.HISTORY_EVENT_USER, new Integer(-4908));
        attrNamesToNumbers.put(AdmAttrNames.HISTORY_EVENT_TYPE, new Integer(-4909));
        attrNamesToNumbers.put(AdmAttrNames.HISTORY_EVENT_DESC, new Integer(-4910));
        attrNamesToNumbers.put(AdmAttrNames.HISTORY_EVENT_RESULT, new Integer(-4911));
        attrNamesToNumbers.put(AdmAttrNames.QUEUED_DATE, new Integer(-4912));
        attrNamesToNumbers.put(AdmAttrNames.QUEUED_BY, new Integer(-4913));
        attrNamesToNumbers.put(AdmAttrNames.DEPLOY_CHANGE_SET_UID, new Integer(-4914));
        attrNamesToNumbers.put(AdmAttrNames.QUEUED_JOB_TYPE, new Integer(-4915));
        attrNamesToNumbers.put(AdmAttrNames.OBJECT_CLASS, new Integer(-5018));
        attrNamesToNumbers.put(AdmAttrNames.ID, new Integer(-2));
        attrNamesToNumbers.put(AdmAttrNames.ADM_SPEC, new Integer(-218));
        attrNamesToNumbers.put(AdmAttrNames.ITEMFILE_FILENAME, new Integer(-201));
        attrNamesToNumbers.put(AdmAttrNames.FULL_PATH_NAME, new Integer(-212));
        attrNamesToNumbers.put(AdmAttrNames.DESCRIPTION, new Integer(-6)); // for baseline & request (=title)
        attrNamesToNumbers.put(AdmAttrNames.STATUS, new Integer(-8)); // aka state
        attrNamesToNumbers.put(AdmAttrNames.STAGE_ID, new Integer(-221));
        attrNamesToNumbers.put(AdmAttrNames.FROM_STAGE, new Integer(-4916));
        attrNamesToNumbers.put(AdmAttrNames.TO_STAGE, new Integer(-4917));
        attrNamesToNumbers.put(AdmAttrNames.CSJ_JOB_NAME, new Integer(-4919));
        attrNamesToNumbers.put(AdmAttrNames.DEPLOY_AREA_VERSION, new Integer(-4923));
        attrNamesToNumbers.put(AdmAttrNames.PARENT_JOB_ID, new Integer(-4925));
        attrNamesToNumbers.put(AdmAttrNames.AREA_ID, new Integer(-5350));
        attrNamesToNumbers.put(AdmAttrNames.PROJECT_NAME, new Integer(-5157)); // i.e. project spec
        attrNamesToNumbers.put(AdmAttrNames.PRODUCT_NAME, new Integer(-1));
        attrNamesToNumbers.put(AdmAttrNames.CREATE_DATE, new Integer(-401));
        attrNamesToNumbers.put(AdmAttrNames.ORIGINATOR, new Integer(-402));
        attrNamesToNumbers.put(AdmAttrNames.JOB_NAME, new Integer(-5337));
        attrNamesToNumbers.put(AdmAttrNames.START_TIME, new Integer(-5338));
        attrNamesToNumbers.put(AdmAttrNames.REVISION, new Integer(-5));
        attrNamesToNumbers.put(AdmAttrNames.WSET_IS_STREAM, new Integer(-914));
        attrNamesToNumbers.put(AdmAttrNames.HISTORY_ORDER_UID, new Integer(-4918));
        attrNamesToNumbers.put(AdmAttrNames.SDA_APPLICATION, new Integer(-10004));
        attrNamesToNumbers.put(AdmAttrNames.SDA_ENV, new Integer(-10005));
        attrNamesToNumbers.put(AdmAttrNames.SDA_PROCESS, new Integer(-10006));
        attrNamesToNumbers.put(AdmAttrNames.SDA_PIPELINE, new Integer(-10007));
        attrNamesToNumbers.put(AdmAttrNames.SDA_COMPONENT, new Integer(-10008));
        attrNamesToNumbers.put(AdmAttrNames.SDA_VERSION, new Integer(-10009));
        attrNamesToNumbers.put(AdmAttrNames.SDA_RUN_APP_REQUEST, new Integer(-10010));
        attrNamesToNumbers.put(AdmAttrNames.SDA_COMPONENT_ID, new Integer(-10011));
        attrNamesToNumbers.put(AdmAttrNames.SDA_APP_PROCESS_REQUEST_URL, new Integer(-10012));
        attrNamesToNumbers.put(AdmAttrNames.SDA_COMPONENT_HISTORY_URL, new Integer(-10013));
    }

    /**
     * Constructor defines the command definition and arguements.
     */
    public QCDeploymentViewContextToDeploymentObjectsCmd() throws AdmObjectException, AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class)); // this should be DeploymentViewContext class
        setAttrDef(new CmdArgDef(CmdArguments.ADM_CHILD_CLASS, true, Class.class)); // this should be ChangeDoc, Baseline, Item,
                                                                                    // DeploymentJob or DeploymentHistoryRecord
                                                                                    // classes
        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTE_NAMES, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.DATA_RANGE_INFO, true, RangeInfo.class));
        setAttrDef(new CmdArgDef(CmdArguments.DEPLOYMENT_DATA_REQUESTED_MODE, true, Integer.class));
        // optional parameters
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, FilterImpl.class));
        setAttrDef(new CmdArgDef(CmdArguments.USE_CACHE, false, Boolean.class));
    }

    @Override
    public Object execute() throws AdmException {

        List list = new ArrayList();
        DeploymentViewContext dvc = (DeploymentViewContext) getAttrValue(CmdArguments.ADM_OBJECT);
        Class childClass = (Class) getAttrValue(CmdArguments.ADM_CHILD_CLASS);
        List attributes = (List) getAttrValue(CmdArguments.ATTRIBUTE_NAMES);
        RangeInfo range = (RangeInfo) getAttrValue(CmdArguments.DATA_RANGE_INFO);
        int mode = getMode(childClass, (Integer) getAttrValue(CmdArguments.DEPLOYMENT_DATA_REQUESTED_MODE));
        List columnIds = new ArrayList();
        prepareColumns(attributes, columnIds);
        Filter filter = (Filter) getAttrValue(CmdArguments.FILTER);
        List filterColumns = new ArrayList();
        List filterValues = new ArrayList();
        List filterCriterias = new ArrayList();
        prepareFilters(filter, filterColumns, filterValues, filterCriterias);
        List sortColumns = new ArrayList();
        List sortFlags = new ArrayList();
        prepareSortings(filter, sortColumns, sortFlags);

        int flag = GLOBAL_FLAG_IGNORE_CACHE;
        Boolean use_cache = (Boolean) getAttrValue(CmdArguments.USE_CACHE);
        if (use_cache != null && use_cache.booleanValue()) {
            flag = GLOBAL_FLAG_USE_CACHE;
        }

        try {
            boolean fetched = false;
            do {

                ListDeploymentViewResult listResults = getSession().getConnection().rpcDeploymentView(getProjectUID(dvc),
                        getStageUID(dvc), getAreaUID(dvc), getObjectUID(dvc), getClassID(childClass), mode, flag,
                        listToIntArray(filterColumns), (String[]) filterValues.toArray(new String[filterValues.size()]),
                        listToIntArray(filterCriterias), listToIntArray(sortColumns), listToIntArray(sortFlags),
                        range.getRowStart(), range.getRowCount(), listToIntArray(columnIds));

                range.setResultCode(listResults.getResultCode());
                range.setTotalCount(listResults.getTotalCount());
                int[] classesUids = listResults.getObjectClasses();
                int[] objectUids = listResults.getObjectUids();
                int[] projectUids = listResults.getProjectUids();

                String[][] values = listResults.getValues();
                if (objectUids != null && objectUids.length > 0) {
                    fetched = true;
                    for (int i = 0; i < objectUids.length && i < values.length; i++) {
                        Class objClass = childClass;
                        if (i < classesUids.length) {
                            objClass = getObjectClass(classesUids[i], childClass);
                        }
                        AdmObject admObj = AdmCmd.getObject(AdmCmd.newAdmBaseId(objectUids[i], objClass));
                        String[] row_values = values[i];
                        int j = 0;
                        for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
                            String attrName = (String) iterator.next();
                            if (j < row_values.length) {
                                admObj.setAttrValue(attrName, row_values[j]);
                            }
                            j++;
                        }
                        if (i < classesUids.length) {
                            admObj.setAttrValue(AdmAttrNames.PARENT_CLASS, objClass);
                        }
                        admObj.setAttrValue(AdmAttrNames.PROJECT_UID, Integer.valueOf(projectUids[i]));

                        list.add(admObj);
                    }
                } else {
                    if (range.getTotalCount() == 0) {
                        fetched = true;
                    } else {
                        long rs = range.getTotalCount() - range.getRowCount();
                        range.setRowStart(rs > 0 ? rs : 0);
                    }
                }
            } while (!fetched);
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return list;
    }

    private int getMode(Class childClass, Integer mode) {
        int result = mode.intValue();
        if (ChangeDocument.class.equals(childClass)) {
            result = result | CLASS_REQUEST;
        } else if (Baseline.class.equals(childClass)) {
            result = result | CLASS_BASELINE;
        } else if (ItemFile.class.equals(childClass)) {
            result = result | CLASS_ITEM;
        } else if (DeploymentJob.class.equals(childClass)) {
            // TODO check if we need anything here
        } else if (DeploymentHistoryRecord.class.equals(childClass)) {
            // TODO check if we need anything here
        }
        return result;
    }

    private int getClassID(Class childClass) {
        if (ChangeDocument.class.equals(childClass)) {
            return CLASS_REQUEST;
        } else if (Baseline.class.equals(childClass)) {
            return CLASS_BASELINE;
        } else if (ItemFile.class.equals(childClass)) {
            return CLASS_ITEM;
        } else if (DeploymentJob.class.equals(childClass)) {
            return CLASS_DEPLOYMENT_JOB;
        } else if (DeploymentHistoryRecord.class.equals(childClass)) {
            return CLASS_DEPLOYMENT_HISTORY_RECORD;
        }
        return -1;
    }

    private Class getObjectClass(int classID, Class defClass) {
        switch (classID) {
        case CLASS_ITEM:
            return ItemFile.class;
        case CLASS_REQUEST:
            return ChangeDocument.class;
        case CLASS_BASELINE:
            return Baseline.class;
        case CLASS_WORKSET:
            return WorkSet.class;
        case CLASS_SCHEDULED_JOB:
            return ScheduledJob.class;
        }
        return defClass;
    }

    private int getObjectUID(DeploymentViewContext dvc) throws AdmException {
        if (dvc == null) {
            return -1;
        }
        return getAdmUID(dvc.getObjectAdmObject());
    }

    private int getAreaUID(DeploymentViewContext dvc) throws AdmException {
        if (dvc == null) {
            return -1;
        }
        return getAdmUID(dvc.getAreaAdmObject());
    }

    private int getStageUID(DeploymentViewContext dvc) throws AdmException {
        if (dvc == null) {
            return -1;
        }
        return getAdmUID(dvc.getStageAdmObject());
    }

    private int getProjectUID(DeploymentViewContext dvc) throws AdmException {
        if (dvc == null) {
            return -1;
        }
        return getAdmUID(dvc.getWorksetAdmObject());
    }

    private int getAdmUID(AdmObject admObj) throws AdmException {
        if (admObj != null) {
            AdmUid uid = (AdmUid) AdmCmd.getAttributeValue(admObj, AdmAttrNames.ADM_UID);
            if (uid != null) {
                return (int) uid.getUid();
            }
        }
        return -1;
    }

    private int[] listToIntArray(List list) {
        if (list == null) {
            return null;
        }
        int[] result = new int[list.size()];
        int i = 0;
        for (Iterator iter = list.iterator(); iter.hasNext();) {
            result[i++] = ((Integer) (iter.next())).intValue();
        }
        return result;
    }

    private void prepareColumns(List attributes, List columnIds) {
        if (attributes == null) {
            return;
        }
        for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
            String attrName = (String) iterator.next();
            Object num = attrNamesToNumbers.get(attrName);
            if (num instanceof Integer) {
                columnIds.add(num);
            } else {
                columnIds.add(new Integer(0));
            }
        }
    }

    private void prepareSortings(Filter filter, List sortColumns, List sortFlags) {
        if (filter == null) {
            return;
        }
        for (Iterator iterator = filter.orders().iterator(); iterator.hasNext();) {
            FilterOrder fo = (FilterOrder) iterator.next();
            String attrName = fo.getAttrName();
            Object num = attrNamesToNumbers.get(attrName);
            if (num instanceof Integer) {
                sortColumns.add(num);
                sortFlags.add(new Integer(fo.getFlags()));
            }
        }
    }

    private void prepareFilters(Filter filter, List filterColumns, List filterValues, List filterCriterias) {
        if (filter == null) {
            return;
        }
        for (Iterator iterator = filter.criteria().iterator(); iterator.hasNext();) {
            FilterCriterion crit = (FilterCriterion) iterator.next();
            String attrName = crit.getAttrName();
            Object num = attrNamesToNumbers.get(attrName);
            if (num instanceof Integer) {
                filterColumns.add(num);
                Object value = crit.getValue();
                filterValues.add(value != null ? value.toString() : "");
                filterCriterias.add(new Integer(crit.getFlags()));
            }
        }
    }

}

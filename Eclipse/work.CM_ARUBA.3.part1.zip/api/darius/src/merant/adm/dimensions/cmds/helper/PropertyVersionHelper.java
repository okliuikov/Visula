package merant.adm.dimensions.cmds.helper;

import java.util.List;

import com.serena.dmnet.drs.DRSClientQueryPathProperties;
import com.serena.dmnet.drs.DRSClientQueryVersionProperties;
import com.serena.dmnet.drs.DRSClientQueryVersionProperties.VersionPropertiesQueryContext;

import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.VersionProperty;
import merant.adm.dimensions.server.drs.objects.VersionPropertyHandler;
import merant.adm.exception.AdmException;

public class PropertyVersionHelper {

    public static void getPathProperties(long version, long wsetUid, List<String> paths, List<String> filters, int options,
            VersionPropertyHandler handler) throws AdmException {
        DRSClientQueryPathProperties drs = new DRSClientQueryPathProperties();
        drs.setForestVersion(version);
        drs.setWsetUid(wsetUid);
        drs.setOptions(options);
        drs.setPaths(paths.toArray(new String[paths.size()]));
        if (filters != null && filters.size() > 0) {
            drs.setFilters(filters.toArray(new String[filters.size()]));
        }

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] indexes = drs.getOutPathIndexes();
            String[] propNames = drs.getPropertyNames();
            String[] propVals = drs.getPropertyValues();

            for (int i = 0; i < indexes.length; ++i) {
                int idx = indexes[i];
                VersionProperty vp = new VersionProperty();
                vp.setPath(paths.get(idx));
                vp.setPropertyName(propNames[i]);
                vp.setPropertyValue(propVals[i]);
                handler.handlePropertyVersion(vp);
            }
        }
    }

    public static void getVersionPropertiesByChangesetUids(Long[] changesetUids, int options, VersionPropertyHandler handler)
            throws AdmException {
        DRSClientQueryVersionProperties drs = new DRSClientQueryVersionProperties(
                VersionPropertiesQueryContext.QueryByChangeSetsUids);
        drs.setChangesetUids(changesetUids);
        drs.setOptions(options);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] outChangesets = drs.getOutChangesetUids();
            String[] propNames = drs.getOutPropertyNames();
            String[] propVals = drs.getOutPropertyValues();

            for (int i = 0; i < propNames.length; ++i) {
                VersionProperty vp = new VersionProperty();
                vp.setChangesetUid((long) outChangesets[i]);
                vp.setPropertyName(propNames[i]);
                vp.setPropertyValue(propVals[i]);
                handler.handlePropertyVersion(vp);
            }
        }
    }

    public static void getVersionPropertiesByForestVersions(Long[] forestVersions, int options, VersionPropertyHandler handler)
            throws AdmException {
        DRSClientQueryVersionProperties drs = new DRSClientQueryVersionProperties(
                VersionPropertiesQueryContext.QueryByForestVersions);
        drs.setForestVersions(forestVersions);
        drs.setOptions(options);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] outVersions = drs.getOutForestVersions();
            String[] propNames = drs.getOutPropertyNames();
            String[] propVals = drs.getOutPropertyValues();

            for (int i = 0; i < propNames.length; ++i) {
                VersionProperty vp = new VersionProperty();
                vp.setForestVersion((long) outVersions[i]);
                vp.setPropertyName(propNames[i]);
                vp.setPropertyValue(propVals[i]);
                handler.handlePropertyVersion(vp);
            }
        }
    }
    
    public static void getVersionPropertiesByTreeUids(long fromForestVersion, long toForestVersion, Long[] treeUids, final String[] propertyNames, int options, VersionPropertyHandler handler)
            throws AdmException {
        DRSClientQueryVersionProperties drs = new DRSClientQueryVersionProperties(
                VersionPropertiesQueryContext.QueryByTreeUids);
        drs.setFromForestVersion(fromForestVersion);
        drs.setToForestVersion(toForestVersion);
        drs.setTreeUids(treeUids);
        drs.setPropertyNames(propertyNames);
        drs.setOptions(options);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] outVersions = drs.getOutForestVersions();
            String[] propNames = drs.getOutPropertyNames();
            String[] propVals = drs.getOutPropertyValues();

            for (int i = 0; i < propNames.length; ++i) {
                VersionProperty vp = new VersionProperty();
                vp.setForestVersion((long) outVersions[i]);
                vp.setPropertyName(propNames[i]);
                vp.setPropertyValue(propVals[i]);
                handler.handlePropertyVersion(vp);
            }
        }
    }
}

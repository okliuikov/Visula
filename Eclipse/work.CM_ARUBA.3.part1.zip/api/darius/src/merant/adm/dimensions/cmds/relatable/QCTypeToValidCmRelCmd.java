/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.ValidCMRelationship;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Valid CM relationships defined to the chdoc type object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Vadymk
 */
public class QCTypeToValidCmRelCmd extends QueryRelsCmd {

    // initialize filter
    final String MATCH_ALL = "%";
    String objectClass = MATCH_ALL;
    String relatedObjectTypeName = MATCH_ALL;
    String relatedObjectProductName = MATCH_ALL;
    StringBuffer orderBy = new StringBuffer();
    boolean isDM10OrGreater;

    public QCTypeToValidCmRelCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
            AdmObject typeObj = (AdmObject) attrValue;
            try {
                Class typeClass = (Class) typeObj.getAttrValue(AdmAttrNames.PARENT_CLASS);
                if (!ChangeDocument.class.equals(typeClass)) {
                    throw new AttrException("Error: Object type class is not supported!", attrDef, attrValue);
                }
            } catch (AdmObjectException e) {
                Debug.error(e);
                throw new AttrException(e.getMessage());
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(ValidCMRelationship.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {

        List ret = new Vector();

        boolean isParent = true; // default to FROM PARENT direction
        if (filter != null) {
            // search for REL_CHILD == Boolean.TRUE in the filter
            Collection criteria = filter.criteria();
            if ((criteria != null) && (!criteria.isEmpty())) {
                for (Iterator it = criteria.iterator(); it.hasNext();) {
                    FilterCriterion crit = (FilterCriterion) it.next();
                    if (crit == null) {
                        continue;
                    }

                    String attrName = crit.getAttrName();
                    if (AdmAttrNames.REL_CHILD.equals(attrName)) {
                        Boolean attrValue = (Boolean) crit.getValue();
                        if (Boolean.TRUE.equals(attrValue)) {
                            isParent = false;
                            break;
                        }
                    }
                }
            }
        }

        if (CmdUtils.compareVersions(CmdUtils.getSchemaVersion(), "10.1") >= 0) {
            // 10.x or greater schema
            isDM10OrGreater = true;
        } else {
            isDM10OrGreater = false;
            if (!isParent) {
                throw new DBIOException("Error: Query for child relationships is not supported here when pre-10 schema!");
            }
        }

        if (isDM10OrGreater) {
            orderBy.append(" cvr.rel_type, ot.product_id, ot.type_name");
        } else {
            orderBy.append("cvr.rel_type, cvr.obj_product_id, cvr.obj_type");
        }

        if (filter != null) {
            processFilter(filter);
            processOrder(filter);
        }

        String productId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
        String typeName = admObj.getId();

        DBIO query = null;
        if (isDM10OrGreater) {
            // 10.x or greater schema
            if (isParent) {
                query = new DBIO(wcm_sql.VALIDCMREL_LIST_10);
            } else {
                query = new DBIO(wcm_sql.VALIDCMREL_LIST_10_PARENTS);
            }

            long typeUid = ((AdmUidObject) admObj).getAdmUid().getUid();
            query.bindInput(typeUid);
        } else {
            // 9.x schema
            query = new DBIO(wcm_sql.VALIDCMREL_LIST);
            query.bindInput(productId);
            query.bindInput(typeName);
        }

        // These inputs are the same for DM10 and previously
        query.bindInput(objectClass);
        query.bindInput(relatedObjectTypeName);
        query.bindInput(relatedObjectProductName);
        query.bindInput(orderBy.toString(), DBIO.DB_ARG_STRING_LITERAL);

        query.readStart();
        List specComponents = null;
        while (query.read()) {
            specComponents = new ArrayList(5);
            if (isParent) {

                // What we selected is the parent type
                specComponents.add(productId); // AdmAttrNames.CMREL_TYPE_PRODUCT_NAME
                specComponents.add(typeName); // AdmAttrNames.CMREL_TYPE_ID

                // What we queried is the child type
                specComponents.add(query.getString(1)); // AdmAttrNames.CMREL_RELATED_TYPE_PRODUCT_NAME
                specComponents.add(query.getString(2)); // AdmAttrNames.CMREL_RELATED_TYPE_ID

            } else {

                // What we queried is the parent type
                specComponents.add(query.getString(1)); // AdmAttrNames.CMREL_TYPE_PRODUCT_NAME
                specComponents.add(query.getString(2)); // AdmAttrNames.CMREL_TYPE_ID

                // What we selected is the child type
                specComponents.add(productId); // AdmAttrNames.CMREL_RELATED_TYPE_PRODUCT_NAME
                specComponents.add(typeName); // AdmAttrNames.CMREL_RELATED_TYPE_ID

            }

            specComponents.add(query.getString(3)); // AdmAttrNames.TYPE_NAME
            addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(specComponents, admSecClass));
        }

        return ret;
    }

    private void processFilter(FilterImpl f) {

        if (f == null) {
            return;
        }

        Collection crits = f.criteria();

        if (crits != null && !crits.isEmpty()) {
            for (Iterator it = crits.iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit == null) {
                    continue;
                }
                String attrName = crit.getAttrName();

                // filter by product name of the related object ?
                if (AdmAttrNames.CMREL_RELATED_TYPE_PRODUCT_NAME.equals(attrName) && crit.getValue() != null) {
                    relatedObjectProductName = crit.getValue().toString();
                }

                // filter by type name of the related object ?
                if (AdmAttrNames.CMREL_RELATED_TYPE_ID.equals(attrName) && crit.getValue() != null) {
                    relatedObjectTypeName = crit.getValue().toString();
                }

                // filter by class of the related object (ChangeDocument/Item) ?
                if (AdmAttrNames.CMREL_RELATED_TYPE_PARENT_CLASS.equals(attrName) && crit.getValue() != null) {
                    String className = crit.getValue().toString();
                    if (className.endsWith("Item")) {
                        objectClass = "I";
                    } else if (className.endsWith("ChangeDocument")) {
                        objectClass = "C";
                    }
                }
            }
        }
    }

    private void processOrder(FilterImpl f) {

        if (f == null) {
            return;
        }

        Collection orders = f.orders();

        if (orders != null && !orders.isEmpty()) {
            // don't use the previously created orderBy Stringbuffer any more, as there is a different order
            // in the filter
            orderBy = new StringBuffer();
            boolean comma = false;
            for (Iterator it = orders.iterator(); it.hasNext();) {
                FilterOrder order = (FilterOrder) it.next();
                if (order == null) {
                    continue;
                }
                String attrName = order.getAttrName();

                // order by related object product id ?
                if (AdmAttrNames.CMREL_RELATED_TYPE_PRODUCT_NAME.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if (isDM10OrGreater) {
                        orderBy.append("ot.product id ");
                    } else {
                        orderBy.append("cvr.obj_product_id ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("DESC");
                    } else {
                        orderBy.append("ASC");
                    }
                    comma = true;
                }

                // order by related object type name?
                if (AdmAttrNames.CMREL_RELATED_TYPE_ID.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("cvr.rel_type DESC");
                    } else {
                        orderBy.append("cvr.rel_type ASC");
                    }
                    comma = true;

                }

                // order by related object class?
                if (AdmAttrNames.CMREL_RELATED_TYPE_PARENT_CLASS.equals(attrName)) {
                    if (comma) {
                        orderBy.append(", ");
                    }
                    if (isDM10OrGreater) {
                        orderBy.append("ot.type_name ");
                    } else {
                        orderBy.append("cvr.obj_type ");
                    }
                    if ((order.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING) {
                        orderBy.append("DESC");
                    } else {
                        orderBy.append("ASC");
                    }
                    comma = true;
                }
            }
        }
    }

}

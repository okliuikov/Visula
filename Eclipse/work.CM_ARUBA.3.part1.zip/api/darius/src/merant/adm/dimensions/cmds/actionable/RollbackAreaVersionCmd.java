/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.AreaVersion;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will roll back specified area version at specified date and time.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object - AreaVersion</dd>
 *  <dt>WORKSET {String}<dt><dd>Workset name.  If not provided, current workset is taken</dd>
 *  <dt>COMMENT {String}<dt><dd>Comment</dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author skorneychuk
 */
public class RollbackAreaVersionCmd extends RPCExecCmd {
    public RollbackAreaVersionCmd() throws AttrException {
        super();
        setAlias(Actionable.ROLLBACK_AREA_VERSION);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));// area version
        setAttrDef(new CmdArgDef(CmdArguments.SCHEDULE_DATETIME, false, String.class)); // ISO8601 format in the UTC timezone -
                                                                                        // 'YYYY'-'MM'-'DD'T'HH24':'MI':'SS'.'sss'Z'
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, AdmObject.class)); // workset scope
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class)); // reason for deployment
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue != null && (!(attrValue instanceof AreaVersion))) {
                throw new AttrException("Error: RollbackAreaVersionCmd - object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        StringBuffer sb = new StringBuffer();
        boolean useUserFileNameQualifier = false;
        if (admObj == null) {
            throw new DimMandatoryAttributeException("Error: Area Version must be specified.");
        }

        sb.append("SRAV ");

        sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));

        sb.append(" /FORCE ");

        if (project != null) {
            sb.append(" /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec()));
        }
        if (comment != null && comment.length() > 0) {
            sb.append(" /COMMENT=" + Encoding.escapeDMCLI(comment));
        }
        String scheduled_date = (String) getAttrValue(CmdArguments.SCHEDULE_DATETIME);
        if (scheduled_date != null) {
            sb.append(" /DEPLOY_START_TIME=\"");
            sb.append(scheduled_date);
            sb.append("\"");
        }

        _cmdStr = sb.toString();
    }
    
    @Override
    public Object execute() throws AdmException {
        return executeRpc();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimLockedException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplBlnMasterConfig;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate an Item Type to a Baseline Replication Configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {Type}<dt><dd>Dimensions Type object</dd>
 *  <dt>ADM_PARENT_OBJECT {ItemTypeGroup}<dt><dd>Parent Dimensions Baseline Replication Configuration object (only master)</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadymk
 */
public class RelateItemTypeToBlnReplCfgCmd extends DBIOCmd {

    public RelateItemTypeToBlnReplCfgCmd() throws AttrException {
        super();
        setAlias("RelateItemTypeToBlnReplCfgCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, Type.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof ReplBlnMasterConfig)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // Dimensions baseline replication configuration
        final AdmObject configObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        // Dimensions item type
        final AdmObject itemTypeObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        // determine replication configuration attributes
        List attrs = AdmHelperCmd.getAttributeValues(configObj,
                Arrays.asList(new Object[] { AdmAttrNames.ID, AdmAttrNames.REVISION }));
        final String configId = (String) attrs.get(0);
        final String revision = (String) attrs.get(1);

        // make sure that the replication configuration actually exists
        if (!DoesExistHelper.replConfigExists(configId, Constants.REPL_BASELINE_CLASS, revision)) {
            throw new DimNotExistsException("Error: baseline replication configuration " + configId + " does not exists.");
        }

        final long configUid = ((AdmUidObject) configObj).getUid();
        long replSiteUid = ((Long) AdmHelperCmd.getAttributeValue(configObj, AdmAttrNames.REPL_BASEDB_UID)).longValue();

        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        long thisSiteUid = 0;
        if (thisSite != null) {
            thisSiteUid = ((AdmUidObject) thisSite).getUid();
        }

        if (!isLocalReplConfig(null, configUid, Constants.REPL_BASELINE_CLASS, thisSiteUid)) {
            throw new DimLockedException("Error: remote baseline replication configuration " + configId + " is not updatable.");
        }

        if (!"0".equals(revision)) {
            throw new DimLockedException("Error: remote baseline subordinate is not updatable.");
        }

        // determine item type attributes
        final String productName = (String) AdmHelperCmd.getAttributeValue(itemTypeObj, AdmAttrNames.PRODUCT_NAME);
        final String typeName = itemTypeObj.getId();

        Class typeClass = (Class) AdmHelperCmd.getAttributeValue(itemTypeObj, AdmAttrNames.PARENT_CLASS);
        if (!Item.class.equals(typeClass)) {
            throw new DimInvalidAttributeException("Error: type " + productName + ":" + typeName + " is not an item type.");
        }

        if (!DoesExistHelper.typeExists(productName, typeName, "I")) {
            throw new DimNotExistsException("Error: item type " + productName + ":" + typeName + " does not exist.");
        }

        if (Constants.GLOBAL_PRODUCT.equals(productName)) {
            throw new DimInvalidAttributeException("Error: item type " + productName + ":" + typeName
                    + " is invalid for this replication configuration.");
        }

        final long typeUid = ((AdmUidObject) itemTypeObj).getUid();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws Exception {

                // check if this type has already been defined for this replication config
                boolean isAlreadyAssigned = isTypeAssigned(dbCtx, typeUid, configId, revision, Constants.REPL_BASELINE_CLASS);

                if (!bDeassign) {

                    if (isAlreadyAssigned) {
                        throw new DimAlreadyExistsException("Error: item type " + productName + ":" + typeName
                                + " has already been assigned to the baseline replication configuration " + configId + ".");
                    }

                    // assign the type
                    String userName = AdmCmd.getCurRootObj(User.class).getId();
                    long relUid = getNewUid(dbCtx);
                    SqlUtils.replAssignTypeToConfig(dbCtx, relUid, configUid, typeUid, Constants.REPL_ITEM_TYPE_REL_CLASS, userName);
                    dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);
                } else {
                    // check if type has already been assigned
                    if (!isAlreadyAssigned) {
                        throw new DimNotExistsException("Error: item type " + productName + ":" + typeName
                                + " has not been assigned to the baseline replication configuration " + configId + ".");
                    }

                    // deassign the type from the replication configuration
                    SqlUtils.replDeassignTypeFromConfig(dbCtx, configUid, typeUid, Constants.REPL_ITEM_TYPE_REL_CLASS);
                    dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);

                    // no need to check if any types are still assigned
                }
                // update audit trail
                SqlUtils.updateSysobj(dbCtx, configUid, AdmCmd.getCurRootObj(User.class).getId());
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

            }
        });

        return new AdmResult("Operation completed");
    }

    private boolean isTypeAssigned(DBIO dbCtx, long typeUid, String configId, String revision, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_IS_TYPE_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(typeUid);
        dbCtx.bindInput(Constants.REPL_ITEM_TYPE_REL_CLASS);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private boolean isLocalReplConfig(DBIO dbCtx, long configUid, int replClass, long siteUid) throws AdmException {

        if (dbCtx != null) {
            dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(replClass);
            dbCtx.bindInput(siteUid);
            dbCtx.readStart();
            boolean isOwned = dbCtx.read(DBIO.DB_DONT_CLOSE);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
            return isOwned;
        }
        dbCtx = new DBIO(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
        dbCtx.bindInput(configUid);
        dbCtx.bindInput(replClass);
        dbCtx.bindInput(siteUid);
        dbCtx.readStart();
        boolean isOwned = dbCtx.read();
        dbCtx.close();
        return isOwned;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will return a Dimensions parent object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_PARENT_CLASS {Class}<dt><dd>Parent Dimensions object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions work set container for objects</dd>
 *  <dt>RELATIONSHIPS {Boolean}<dt><dd>If true, command returns a Relationship rather than an AdmBaseId</dd>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELTYPE_IS_PEDIGREE {Boolean}<dt><dd>If true, returns pedigree object relationship</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmBaseId/Relationship}<dt><dd>AdmBaseId or Relationship representing the parent</dd>
 * </dl></code>
 * @author Floz
 */
public class QueryParentCmd extends AdmCmd {
    public QueryParentCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_PARENT);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATIONSHIPS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_PEDIGREE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_PARENTS, getAttrValue(CmdArguments.ADM_OBJECT));
        cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, getAttrValue(CmdArguments.ADM_PARENT_CLASS));
        cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
        cmd.setAttrValue(CmdArguments.RELATIONSHIPS, getAttrValue(CmdArguments.RELATIONSHIPS));
        cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
        cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE));

        List parents = (List) cmd.execute();
        if ((parents == null) || (parents.size() == 0)) {
            return null;
        }

        return parents.get(0);
    }
}

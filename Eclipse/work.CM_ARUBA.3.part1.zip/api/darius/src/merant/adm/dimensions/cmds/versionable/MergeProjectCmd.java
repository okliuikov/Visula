/*
 * %HEADER%
 * Copyright (C) 2004, Merant. All rights reserved.
 */
package merant.adm.dimensions.cmds.versionable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Performs a merge(or a lesser compare) on a set of objects.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>BRANCHES {List}</dt><dd>List of objects to compare</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>BASE {AdmObject}</dt><dd>An ancestor to calculate differences against</dd>
 *  <dt>REPORT {Boolean}</dt><dd>Specifies that a human-readable report be returned</dd>
 *  <dt>TARGET {AdmBaseId}</dt><dd>A Target object to merge to</dd>
 *  <dt>TYPE_NAME {String}<dt><dd>The workset type of the target workset (default is "WORKSET")</dd>
 *  <dt>DESCRIPTION {String}<dt><dd>Description of the target work set</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{InputStream/AdmResult}</dt><dd>Access to the delta's if compare, otherwise AdmResult</dd>
 * </dl></code>
 * @author Floz
 */
public class MergeProjectCmd extends AdmCmd {
    public MergeProjectCmd() throws AttrException {
        super();
        setAlias(Versionable.MERGE);
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASE, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPORT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.TARGET, false, AdmBaseId.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.BRANCHES)) {
            List branches = (List) attrValue;
            if (branches.size() == 0) {
                throw new AttrException("Error: Nothing has been specified to compare!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.BASE) && attrValue != null) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: Base object type is not supported!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.TARGET) && attrValue != null) {
            if (!(((AdmBaseId) attrValue).getObjType().equals(WorkSet.class))) {
                throw new AttrException("Error: Target object type is not supported!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.DESCRIPTION) && attrValue != null) {
            if (!(attrValue instanceof String)) {
                throw new AttrException("Error: Description object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        List branches = (List) getAttrValue(CmdArguments.BRANCHES);
        AdmObject base = (AdmObject) getAttrValue(CmdArguments.BASE);
        boolean report = ((Boolean) getAttrValue(CmdArguments.REPORT)).booleanValue();
        AdmBaseId targetBaseId = (AdmBaseId) getAttrValue(CmdArguments.TARGET);
        String type = (String) getAttrValue(AdmAttrNames.TYPE_NAME);
        String desc = (String) getAttrValue(CmdArguments.DESCRIPTION);
        String request = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);

        if (branches.size() == 1 && base == null) {
            throw new DimBaseCmdException("Must specify at least one object to compare with the specified object!");
        }

        List derivatives = branches;
        AdmObject ancestor = base;
        if (ancestor == null) {
            ancestor = (AdmObject) branches.get(0);
            derivatives = derivatives.subList(1, derivatives.size());
        }

        if (ancestor instanceof WorkSet) {
            Cmd cmd = AdmCmd.getCmd("_internal_mws");
            cmd.setAttrValue("base", ancestor.getAdmSpec().getSpec());
            cmd.setAttrValue("branch", ((AdmObject) derivatives.get(0)).getAdmSpec().getSpec());
            if (report) {
                cmd.setAttrValue("report", Boolean.TRUE);
            } else if (targetBaseId != null) {
                cmd.setAttrValue("target", targetBaseId.toString());
                if (type != null) {
                    cmd.setAttrValue("type", type);
                }
            }
            cmd.setAttrValue("description", desc);

            cmd.setAttrValue(CmdArguments.RELATED_CHDOCS, request);

            return new AdmResult((String) cmd.execute(), targetBaseId);
        }

        return null;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.serena.dmnet.drs.DRSClientQueryRequestWorksetsRelations;
import com.serena.dmnet.drs.DRSClientQueryRequestWorksetsRelations.RequestsToWorksetsQueryContext;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.creatable.GetObjectsCmd;
import merant.adm.dimensions.objects.AdmUidObjectImpl;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmUidTwin;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.session.Session;

/**
 * Request relations helper
 * 
 * @author rrodway
 */
public class StructureHistoryHelper {
    public static Map<AdmUidObjectImpl, List<WorkSet>> getRequestProjectRelations(Set<AdmUidObjectImpl> requests)
            throws AdmException {
        Map<AdmUidObjectImpl, List<WorkSet>> result = new HashMap<AdmUidObjectImpl, List<WorkSet>>();
        if (requests == null || requests.isEmpty()) {
            return null;
        }
        Map<Number, AdmUidObjectImpl> uidrequest = new HashMap<Number, AdmUidObjectImpl>(requests.size());
        for (AdmUidObjectImpl request : requests) {
            uidrequest.put(request.getUid(), request);
        }

        DRSClientQueryRequestWorksetsRelations drs = new DRSClientQueryRequestWorksetsRelations(
                RequestsToWorksetsQueryContext.WorksetsFromRequestsUids);
        drs.setRequestUids(uidrequest.keySet());
        DRSUtils.execute(drs);

        if (!drs.hasData()) {
            for (AdmUidObjectImpl request : requests) {
                result.put(request, new ArrayList<WorkSet>(0));
            }
            return result;
        }

        Map<Number, Entry<int[], String[]>> drsResult = drs.getRequestUidsToWorksets();
        for (Entry<Number, AdmUidObjectImpl> uidrequestEntry : uidrequest.entrySet()) {
            Entry<int[], String[]> uidspecEntry = drsResult.get(uidrequestEntry.getKey());

            if (uidspecEntry == null) {
                throw new AdmException("Inconsistence between input/output parameters after execution of DRS "
                        + DRSClientQueryRequestWorksetsRelations.dataRequestId);
            }

            int[] uids = uidspecEntry.getKey();
            String[] specs = uidspecEntry.getValue();

            if (uids == null || specs == null || uids.length != specs.length) {
                throw new AdmException("Inconsistence between input/output parameters after execution of DRS "
                        + DRSClientQueryRequestWorksetsRelations.dataRequestId);
            }

            // invalid request check
            if (uids.length > 0 && uids[0] == -1) {
                continue;
            }

            List<WorkSet> worksets = new ArrayList<WorkSet>(uids.length);
            for (int i = 0; i < uids.length; i++) {
                AdmUidTwin wsBaseId = new AdmUidTwin(uids[i], WorkSet.class);
                AdmSpec wsSpec = new AdmSpec(specs[i], WorkSet.class);
                wsBaseId.setTwin(wsSpec);
                WorkSet relatedWorkset = (WorkSet) GetObjectsCmd.buildNewObject(wsBaseId);
                worksets.add(relatedWorkset);
            }
            result.put(uidrequestEntry.getValue(), worksets);
        }
        return result;
    }

    public static Map<String, List<WorkSet>> getRequestProjectRelationsBySpecs(Set<String> requestSpecs) throws AdmException {
        Map<String, List<WorkSet>> result = new HashMap<String, List<WorkSet>>();

        if (requestSpecs == null || requestSpecs.isEmpty()) {
            return result;
        }

        DRSClientQueryRequestWorksetsRelations drs = new DRSClientQueryRequestWorksetsRelations(
                RequestsToWorksetsQueryContext.WorksetsFromRequestsSpecs);
        drs.setRequestSpecs(requestSpecs);
        DRSUtils.execute(drs);

        if (!drs.hasData()) {
            for (String spec : requestSpecs) {
                result.put(spec, new ArrayList<WorkSet>(0));
            }
            return result;
        }

        Map<String, Entry<int[], String[]>> drsResult = drs.getRequestSpecsToWorksets();
        for (String spec : requestSpecs) {
            Entry<int[], String[]> uidspecEntry = drsResult.get(spec);

            if (uidspecEntry == null) {
                throw new AdmException("Inconsistence between input/output parameters after execution of DRS "
                        + DRSClientQueryRequestWorksetsRelations.dataRequestId);
            }

            int[] uids = uidspecEntry.getKey();
            String[] specs = uidspecEntry.getValue();

            if (uids == null || specs == null || uids.length != specs.length) {
                throw new AdmException("Inconsistence between input/output parameters after execution of DRS "
                        + DRSClientQueryRequestWorksetsRelations.dataRequestId);
            }

            // invalid request check
            if (uids.length > 0 && uids[0] == -1) {
                continue;
            }

            List<WorkSet> worksets = new ArrayList<WorkSet>(uids.length);
            for (int i = 0; i < uids.length; i++) {
                AdmUidTwin wsBaseId = new AdmUidTwin(uids[i], WorkSet.class);
                AdmSpec wsSpec = new AdmSpec(specs[i], WorkSet.class);
                wsBaseId.setTwin(wsSpec);
                WorkSet relatedWorkset = (WorkSet) GetObjectsCmd.buildNewObject(wsBaseId);
                worksets.add(relatedWorkset);
            }
            result.put(spec, worksets);
        }
        return result;
    }

    /**
     * Get structure history for a given change document scoped by workset
     * 
     * @param changeDoc
     *            change document
     * @param workSet
     *            workset
     * @return structure history
     */
    public static List getStructureHistory(ChangeDocument changeDoc, WorkSet workSet) {
        List ret = null;

        try {
            long wsUid;

            if (workSet == null) {
                wsUid = ((WorkSet) AdmCmd.getCurRootObj(WorkSet.class)).getAdmUid().getUid();
            } else {
                wsUid = workSet.getAdmUid().getUid();
            }
            ret = ((Session) DimSystem.getSystem().getSession()).getConnection().rpcGetStructureHistoryRev(
                    changeDoc.getAdmUid().getUid(), wsUid);
        } catch (IOException ioe) {
            Debug.error(ioe);
        } catch (AdmException ae) {
            Debug.error(ae);
        }
        return ret;
    }
}

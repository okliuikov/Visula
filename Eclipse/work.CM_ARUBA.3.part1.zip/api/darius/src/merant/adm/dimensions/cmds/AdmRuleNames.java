/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

/**
 * Methodless Interface of final Strings for
 * Dimensions rules names.<br>
 * This class holds a public static final String
 * for every known rule for all objects.<br>
 * @author Floz
 */
public interface AdmRuleNames {
    public static final String IS_MANDATORY = "AdmRuleNames.IS_MANDATORY";
    public static final String IS_UPDATEABLE = "AdmRuleNames.IS_UPDATEABLE";
    public static final String IS_DISPLAYABLE = "AdmRuleNames.IS_DISPLAYABLE";
    public static final String CAN_RELATE_ITEMS_AS_AFFECTED = "AdmRuleNames.CAN_RELATE_ITEMS_AS_AFFECTED";
    public static final String CAN_RELATE_ITEMS_AS_IRT = "AdmRuleNames.CAN_RELATE_ITEMS_AS_IRT";
    public static final String CAN_RELATE_PARTS = "AdmRuleNames.CAN_RELATE_PARTS";
    public static final String CAN_RELATE_CHDOCS = "AdmRuleNames.CAN_RELATE_CHDOCS";
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will request ownership of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>NETBASEDB {NetBaseDatabase}<dt><dd>Site to delegate the Dimensions object to</dd>
 *  <dt>CANCEL {Boolean}<dt><dd>If true, cancels the existing specified delegation</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class RequestOwnershipCmd extends RPCExecCmd {
    public RequestOwnershipCmd() throws AttrException {
        super();
        setAlias(Assignable.REQUEST_OWNERSHIP);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.NETBASEDB, false, null, NetBaseDatabase.class));
        setAttrDef(new CmdArgDef(CmdArguments.CANCEL, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject baseDbObj = (AdmObject) getAttrValue(CmdArguments.NETBASEDB);
        boolean cancel = ((Boolean) getAttrValue(CmdArguments.CANCEL)).booleanValue();

        if (baseDbObj != null) {
            _cmdStr = "DLGC ";
            _cmdStr += Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());
            _cmdStr += " /SITE=" + Encoding.escapeDMCLI(baseDbObj.getAdmSpec().getSpec());
            if (cancel) {
                _cmdStr += " /DELETE";
            }
        } else {
            _cmdStr = "REQC ";
            _cmdStr += Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());

            if (cancel) {
                _cmdStr += " /CANCEL";
            }
        }

        return executeRpc();
    }
}

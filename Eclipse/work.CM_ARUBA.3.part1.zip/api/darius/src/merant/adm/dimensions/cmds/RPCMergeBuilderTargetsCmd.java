package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Calls the Builder get-dependencies RPC.
 */
public class RPCMergeBuilderTargetsCmd extends RPCCmd {
    public RPCMergeBuilderTargetsCmd() throws AdmObjectException, AttrException {
        setAlias("MergeBuilderTargets");
        setAttrDef(new CmdArgDef("targetWsSpec", true, "", "", ""));
        setAttrDef(new CmdArgDef("tmpWsSpec", true, "", "", ""));
        setAttrDef(new CmdArgDef("changeDocs", true, "", "", ""));
    }

    @Override
    public Object execute() throws AdmException {
        int ret_code = -1;
        try {
            String targetProject = (String) getAttrValue("targetWsSpec");
            String tmpProject = (String) getAttrValue("tmpWsSpec");
            String changeDocs = (String) getAttrValue("changeDocs");
            ret_code = getSession().getConnection().rpcMergeBuilderTargets(targetProject, tmpProject, changeDocs);
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return new Integer(ret_code);
    }
}

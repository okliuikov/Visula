/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetContact;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Network Contact object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new contact</dd>
 *  <dt>NETCONTACT_ADDRESS {String}</dt><dd>Address of the new contact</dd>
 *  <dt>EMAIL {String}</dt><dd>Email of the new contact</dd>
 *  <dt>NETCONTACT_FULL_NAME {String}</dt><dd>Full name of the new contact</dd>
 *  <dt>NETCONTACT_ID {String}</dt><dd>Id of the new contact</dd>
 *  <dt>NETCONTACT_TITLE {String}</dt><dd>Title of the new contact</dd>
 *  <dt>NETCONTACT_TYPE {String}</dt><dd>Type of the new contact</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateNetContactCmd extends RPCExecCmd {
    public CreateNetContactCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETCONTACT_ADDRESS, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EMAIL, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETCONTACT_FULL_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETCONTACT_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETCONTACT_TITLE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETCONTACT_TYPE, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String address = (String) getAttrValue(AdmAttrNames.NETCONTACT_ADDRESS);
        String email = (String) getAttrValue(AdmAttrNames.EMAIL);
        String fullName = (String) getAttrValue(AdmAttrNames.NETCONTACT_FULL_NAME); // Not currently used
        String contactId = (String) getAttrValue(AdmAttrNames.NETCONTACT_ID);
        String title = (String) getAttrValue(AdmAttrNames.NETCONTACT_TITLE);
        String type = (String) getAttrValue(AdmAttrNames.NETCONTACT_TYPE);

        setAttrValue(CmdArguments.INT_SPEC, id);

        _cmdStr = "CCO ";
        _cmdStr += " /CO_NAME=" + Encoding.escapeSpec(id);

        if (address != null) {
            _cmdStr += " /ADDRESS=" + Encoding.escapeSpec(address);
        }

        if (email != null) {
            _cmdStr += " /EMAIL=" + Encoding.escapeSpec(email);
        }

        if (contactId != null) {
            _cmdStr += " /CONTACT_ID=" + Encoding.escapeSpec(contactId);
        }

        if (title != null) {
            _cmdStr += " /TITLE=" + Encoding.escapeSpec(title);
        }

        if (type != null) {
            _cmdStr += " /CONTACT_TYPE=" + Encoding.escapeSpec(type);
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, NetContact.class);
        return retResult;
    }
}

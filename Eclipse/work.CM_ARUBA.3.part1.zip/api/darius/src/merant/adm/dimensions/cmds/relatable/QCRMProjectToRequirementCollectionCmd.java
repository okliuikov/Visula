/*
 * Copyright (C), 2005-2006, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.objects.RMProject;
import merant.adm.dimensions.objects.RequirementCollection;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * This command will query the children of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId or Relationship instances</dd>
 * </dl></code>
 * 
 * 
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
public class QCRMProjectToRequirementCollectionCmd extends QueryRelsCmd {
    public QCRMProjectToRequirementCollectionCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_CHILDREN);
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof RMProject)) {
                throw new AttrException("Error: QCRMProjectToRequirementCollection - Parent object type is not supported!",
                        attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(RequirementCollection.class))) {
                throw new AttrException("Error: QCRMProjectToRequirementCollection - Child object object type is not supported!",
                        attrDef, attrValue);
            }
        }
    }

}

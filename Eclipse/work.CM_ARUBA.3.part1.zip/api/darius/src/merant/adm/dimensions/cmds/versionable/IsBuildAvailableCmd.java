/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.versionable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.BuildProject;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Calculates whether build functionality is available.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>BASELINE {AdmObject}</dt><dd>Dimensions Baseline object</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Boolean}</dt><dd>Returns true if build functionality is available</dd>
 * </dl></code>
 * @author Floz
 * @todo System wide check. Only possible once OpenMake is detectable.
 */
public class IsBuildAvailableCmd extends AdmCmd {
    public IsBuildAvailableCmd() throws AttrException {
        super();
        setAlias(Versionable.IS_BUILD_AVAILABLE);
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.BASELINE)) {
            if (!(attrValue instanceof Baseline)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject baseline = (AdmObject) getAttrValue(CmdArguments.BASELINE);

        // TODO: Once OpenMake is detectable, execute
        // system wide check and return false if failed!

        // If Baseline is specified use this - otherwise
        // use the current WorkSet.
        AdmObject admObj = baseline;
        if (admObj == null) {
            admObj = AdmCmd.getCurRootObj(WorkSet.class);
        }

        // Return false if unable to find parent Project
        AdmObject project = AdmHelperCmd.getObject((AdmBaseId) AdmCmd.getCmd(Relatable.QUERY_PARENT, admObj, BuildProject.class));
        if (project == null) {
            return Boolean.FALSE;
        }

        // Return false if unable to find any parent BuildProjects
        List buildProjectIds = (List) AdmCmd.getCmd(Relatable.QUERY_PARENTS, project, BuildProject.class);
        if ((buildProjectIds == null) || (buildProjectIds.size() < 1)) {
            return Boolean.FALSE;
        }

        // We have fulfilled all requirements,
        // therefore return true!
        return Boolean.TRUE;
    }
}

/*
 * Copyright (C) 2002, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidRuleException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.BaselineTemplateRule;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions BaselineTemplateRule.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name used exclusively for role checking</dd>
 *  <dt>TEMPLATE_ID {String}</dt><dd>Baseline Template name of the parent for the new rule</dd>
 *  <dt>ID {String}</dt><dd>Name identifier of the new baseline template</dd>
 *  <dt>BLINETR_MINSTATUS {String}</dt><dd>Minimum status of the new baseline template</dd>
 *  <dt>BLINETR_BLINE_CODE_OBJ {String}</dt><dd>Optional baseline rule state selector</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author Floz
 */
public class CreateBaselineTemplateRuleCmd extends DBIOCmd {

    public CreateBaselineTemplateRuleCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TEMPLATE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BLINETR_MINSTATUS, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BLINETR_BLINE_CODE_OBJ, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_CLASS, false, Item.class, Class.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        String productId = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.PRODUCT_NAME), AdmDmLengths.DM_L_PRODUCT_ID);
        String templateId = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.TEMPLATE_ID), AdmDmLengths.DM_L_TEMPLATE);
        String typeName = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ID), AdmDmLengths.DM_L_TYPE_NAME);
        String minStatus = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.BLINETR_MINSTATUS), AdmDmLengths.DM_L_STATUS);
        Class scopeClass = (Class) getAttrValue(AdmAttrNames.PARENT_CLASS);

        AdmObject ruleStateSelector = (AdmObject) getAttrValue(AdmAttrNames.BLINETR_BLINE_CODE_OBJ);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        // validate baseline template rule details - if we get an exception,
        // then the rule is invalid
        Cmd cmd = AdmCmd.getCmd("_internal_validate_baseline_template_rule");
        cmd.setAttrValue(AdmAttrNames.PRODUCT_NAME, productId);
        cmd.setAttrValue(AdmAttrNames.TEMPLATE_ID, templateId);
        cmd.setAttrValue(AdmAttrNames.ID, typeName);
        cmd.setAttrValue(AdmAttrNames.PARENT_CLASS, scopeClass);
        cmd.setAttrValue(AdmAttrNames.BLINETR_MINSTATUS, minStatus);
        cmd.setAttrValue(AdmAttrNames.BLINETR_BLINE_CODE_OBJ, ruleStateSelector);
        cmd.setAttrValue(CmdArguments.UPDATE, Boolean.FALSE);
        boolean isValidNormalStatus = ((Boolean) cmd.execute()).booleanValue();

        String baselineCodeFlag = "0";
        if (isValidNormalStatus && ruleStateSelector != null) {
            baselineCodeFlag = (String) AdmHelperCmd.getAttributeValue(ruleStateSelector, AdmAttrNames.BLINECODE_FLAG);
        }

        // validate baseline code flag
        if (ChangeDocument.class.equals(scopeClass)) {
            if (null != baselineCodeFlag && !(("1".equals(baselineCodeFlag)) || ("3".equals(baselineCodeFlag)))) {
                throw new DimInvalidRuleException(
                        "Error: only EQS and SUP status selectors can be used with request baseline template rules.");
            }
        }

        // Now insert into database...
        DBIO query = new DBIO(wcm_sql.CREATE_BLINETR);
        query.bindInput(templateId);
        if (Item.class.equals(scopeClass)) {
            query.bindInput(typeName);
            query.bindInput(null, String.class);
        } else {
            query.bindInput(null, String.class);
            query.bindInput(typeName);
        }
        query.bindInput(minStatus);
        query.bindInput(baselineCodeFlag);
        query.write();
        query.commit();

        setAttrValue(CmdArguments.INT_SPEC, templateId + ":" + typeName);
        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, BaselineTemplateRule.class);
        return retResult;
    }
}

/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import com.serena.dmfile.xml.WorkareaScanContainer;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class RPCScanRemoteAreaExCmd extends RPCCmd {

    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCScanRemoteAreaExCmd() throws AttrException {
        super();
        setAlias("RPCScanRemoteAreaExCmd");
        AddArgument("cmd", "RPCScanRemoteAreaExCmd");
        setAttrDef(new CmdArgDef("areapath", true, "", "", ""));
        setAttrDef(new CmdArgDef("arearoot", true, "", "", ""));
        setAttrDef(new CmdArgDef("flags", true, "", "", ""));
        setAttrDef(new CmdArgDef("attrnos", true, "", "", ""));
        setAttrDef(new CmdArgDef("inclusionpatterns", false, "", "", ""));
        setAttrDef(new CmdArgDef("exclusionpatters", false, "", "", ""));
    }

    @Override
    public Object execute() throws DimConnectionException {

        try {
            Object inclusion = getAttrValue("inclusionpatterns");
            Object exclusion = getAttrValue("exclusionpatters");
            WorkareaScanContainer wsc = getSession().getConnection().rpcReadAreaChangesEx2((String) getAttrValue("areapath"),
                    (String) getAttrValue("arearoot"), ((Integer) getAttrValue("flags")).intValue(),
                    (((inclusion != null) && (inclusion instanceof String[])) ? (String[]) inclusion : null),
                    (((exclusion != null) && (exclusion instanceof String[])) ? (String[]) exclusion : null));

            return wsc;
        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for withattrs commands.
 * <p>
 * This applies to any dimensions object that can contain attributes. Where attribute spans the concept of system, user and many
 * former member variables of the old object model.
 * @author Floz
 */
public interface WithAttrs {
    public static final String GET = "WithAttrs.Get";
    public static final String GET_DEFS = "WithAttrs.GetDefs";
    public static final String QUERY = "WithAttrs.Query";
    public static final String QUERY_DEFS = "WithAttrs.QueryDefs";
    public static final String UPDATE = "WithAttrs.Update";
    public static final String LOCK_UNLOCK = "WithAttrs.LockUnlock";
}

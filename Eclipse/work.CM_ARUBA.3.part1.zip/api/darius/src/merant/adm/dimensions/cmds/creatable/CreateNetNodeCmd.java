/*
 * Copyright (C) 2002-2003, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */

package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetNode;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Network Node object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new node</dd>
 *  <dt>NETNODE_OPSYS {String}</dt><dd>Identifier of the operating system to be associated with the new node</dd>
 *  <dt>NETNODE_LOGICAL {Boolean}</dt><dd>Logical name of the new node</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}</dt><dd>Description of the new node</dd>
 *  <dt>NETNODE_CONTACT {String}</dt><dd>Identifier of the contact to be associated with the new node</dd>
 *  <dt>NETNODE_PHYSICAL_NAME {String}</dt><dd>Physical name of the new node</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateNetNodeCmd extends RPCExecCmd {
    public CreateNetNodeCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODE_OPSYS, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODE_LOGICAL, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODE_CONTACT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODE_PHYSICAL_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        String id = (String) getAttrValue(AdmAttrNames.ID);
        String netOpSysId = (String) getAttrValue(AdmAttrNames.NETNODE_OPSYS);
        boolean netLogical = ((Boolean) getAttrValue(AdmAttrNames.NETNODE_LOGICAL)).booleanValue();
        String netContactId = (String) getAttrValue(AdmAttrNames.NETNODE_CONTACT);
        String netPhysicalName = (String) getAttrValue(AdmAttrNames.NETNODE_PHYSICAL_NAME);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);

        setAttrValue(CmdArguments.INT_SPEC, id);

        _cmdStr = "CNN ";
        _cmdStr += " /NN_NAME=" + Encoding.escapeDMCLI(id);
        _cmdStr += " /OS_NAME=" + Encoding.escapeDMCLI(netOpSysId);
        _cmdStr += " /LOGICAL=" + Encoding.escapeDMCLI(netLogical ? "Y" : "N");

        if (netContactId != null && netContactId.length() > 0) {
            _cmdStr += " /CO_NAME=" + Encoding.escapeDMCLI(netContactId);
        }
        if (netPhysicalName != null && netPhysicalName.length() > 0) {
            _cmdStr += " /PHYSICAL_NAME=" + Encoding.escapeDMCLI(netPhysicalName);
        }
        if (desc != null) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(desc);
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, NetNode.class);
        return retResult;
    }
}

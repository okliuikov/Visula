/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate a LifeCycle to a Type.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {LifeCycle}<dt><dd>Dimensions LifeCycle object</dd>
 *  <dt>ADM_PARENT_OBJECT {Type}<dt><dd>Parent Dimensions Type object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @todo This class uses a copy of the same AdmUid & AdmSpec instanciation methods as QueryChildrenCmd.java
 * @author Floz
 */
public class RelateLifeCycleToTypeCmd extends RPCExecCmd {
    public RelateLifeCycleToTypeCmd() throws AttrException {
        super();
        setAlias("RelateLifeCycleToTypeCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, LifeCycle.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, Type.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LifeCycle)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
            AdmObject typeObj = (AdmObject) attrValue;
            try {
                if (AdmHelperCmd.getAttributeValue(typeObj, AdmAttrNames.PARENT_CLASS) == null) {
                    throw new AttrException("Error: parent class not specified");
                }
                if (AdmHelperCmd.getAttributeValue(typeObj, AdmAttrNames.PRODUCT_NAME) == null) {
                    throw new AttrException("Error: product not specified");
                }
                if (AdmHelperCmd.getAttributeValue(typeObj, AdmAttrNames.ID) == null) {
                    throw new AttrException("Error: type name not specified");
                }
                if (AdmHelperCmd.getAttributeValue(typeObj, AdmAttrNames.ADM_UID) == null) {
                    throw new AttrException("Error: type UID not specified");
                }
            } catch (AdmException ae) {
                throw new AttrException(ae.getMessage());
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {

        validateAllAttrs();

        // Dimensions lifecycle
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // Dimensions object type
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        String lifecycleId = StringUtils.adjustValue(admObj.getId(), AdmDmLengths.DM_L_LIFECYCLE);

        String productName = StringUtils.adjustValue(
                (String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PRODUCT_NAME), AdmDmLengths.DM_L_PRODUCT_ID);

        String typeName = StringUtils.adjustValue(admParentObj.getId(), AdmDmLengths.DM_L_TYPE_NAME);
        Class typeClass = (Class) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.PARENT_CLASS);
        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        long typeUid = ((AdmUidObject) admParentObj).getAdmUid().getUid();

        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /UPDATE ");
        cmdBuf.append(Encoding.escapeDMCLI(typeName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));

        if (typeClass.equals(Item.class)) {
        	cmdBuf.append(" /OBJ_CLASS=ITEM");
        } else if (typeClass.equals(ChangeDocument.class)) {
        	cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else if (typeClass.equals(Baseline.class)) {
        	cmdBuf.append(" /OBJ_CLASS=BASELINE");
        } else if (typeClass.equals(Part.class)) {
        	cmdBuf.append(" /OBJ_CLASS=PART");
        } else if (typeClass.equals(WorkSet.class)) {
        	cmdBuf.append(" /OBJ_CLASS=PROJECT");
        }
      
        if (bDeassign)
        	cmdBuf.append(" /LIFECYCLE=\"\"");
        else if (lifecycleId != null)
        	cmdBuf.append(" /LIFECYCLE=").append(Encoding.escapeDMCLI(lifecycleId));
        
        _cmdStr = cmdBuf.toString();        
        AdmResult retResult = new AdmResult(executeRpc());

        if (!bDeassign) {
            admParentObj.setAttrValue(AdmAttrNames.LIFECYCLE_ID, lifecycleId);
        } else {
            admParentObj.setAttrValue(AdmAttrNames.LIFECYCLE_ID, null);
        }

        return retResult;
    }
}

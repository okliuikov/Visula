/*
 * %HEADER%
 * Copyright (C) 2004, Merant. All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdBuilder;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
// import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions work set.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Product name of container for the new work set</dd>
 *  <dt>ID {String}<dt><dd>Identifier of the new work set</dd>
 *  <dt>DESCRIPTION {String}<dt><dd>Description of the new work set</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>TYPE_NAME {String}<dt><dd>The project type (default is "WORKSET")</dd>
 *  <dt>WSET_IS_BRANCH {Boolean}<dt><dd>Is the project a branch or trunk (default is false/trunk)?</dd>
 *  <dt>WSET_IS_ENFORCED_REV {Boolean}<dt><dd>Are revision names mandatory (default is false/auto_rev)?</dd>
 *  <dt>WSET_IS_MANUAL_DEPLOYMENT {Integer}<dt><dd>deployment model of this project?</dd>
 *  <dt>WSET_IS_COPY_ON_DEPLOY {Boolean}<dt><dd>Does deployment copy files (as opposed to moving) between areas?</dd>
 *  <dt>WSET_IS_KEEP_STAGE {Boolean}<dt><dd>When creating a project based on another project, this option allow to avoid resetting the stage of item revisions in the new project to the initial stage .</dd>
 *  <dt>WSET_CM_RULES_USAGE {String}<dt><dd>Whether cm_rules are enabled/disabled for items on a per-project basis</dd>
 *  <dt>LOCKED {Boolean}<dt><dd>Is the project locked (default is false/not locked)?</dd>
 *  <dt>BRANCHES {List}<dt><dd>List of named branch names (String) related to the project. </dd>
 *  <dt>BRANCH {String}<dt><dd>An existing branch to be the default branch.</dd>
 *  <dt>WORKSET {AdmObject}<dt><dd>An existing project to base this new project on.</dd>
 *  <dt>BASELINE {AdmObject}<dt><dd>An existing baseline to base this new project on.</dd>
 *  <dt>PROJECT {AdmObject}<dt><dd>An existing Dimensions 9.1 OldProject to be associated with this project.</dd>
 *  <dt>POPULATE {Boolean}<dt><dd>If true populates the build area</dd>
 *  <dt>USER_FILE {String}<dt><dd>Location of report from populating build area</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 *
 * @author David Conneely
 */
public class CreateWorkSetCmd extends RPCExecCmd {
    public CreateWorkSetCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DESCRIPTION, true, String.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_IS_BRANCH, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_IS_ENFORCED_REV, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_IS_MANUAL_DEPLOYMENT, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_IS_COPY_ON_DEPLOY, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_IS_KEEP_STAGE, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_CM_RULES_USAGE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LOCKED, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCH, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, false, Baseline.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET_VERSION, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_IS_PARALLEL_EXTRACT, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_PATH_CONTROL, false, Boolean.class));

        // deprecated as of Dimensions 12.1, but still supported within dmclient (for now)
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_DEPLOY_METHOD, false, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

        setAttrDef(new CmdArgDef(CmdArguments.WSET_IS_STREAM, false, Boolean.class));

        setAttrDef(new CmdArgDef(CmdArguments.WSET_IS_TOPIC_STREAM, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.TOPIC_STREAM_USERS_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, List.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.VISIBLE, false, Boolean.class));

        setAttrDef(new CmdArgDef(CmdArguments.COPY_BUILD_CONFIGURATION, false, Boolean.class));

        setAttrDef(new CmdArgDef(CmdArguments.IMPORT_ALL_REVISIONS, false, Boolean.class));

        setAttrDef(new CmdArgDef(CmdArguments.FORCE, false, Boolean.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.CREATE_DATE, false, String.class));

    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, WorkSet.class);

        // Set other project flag - Lock
        AdmObject wset = AdmHelperCmd.getObject((AdmBaseId) retResult.getUserData());

        Boolean isLocked = (Boolean) getAttrValue(AdmAttrNames.LOCKED);
        Boolean isVisible = (Boolean) getAttrValue(AdmAttrNames.VISIBLE);
        wset.setAttrValue(AdmAttrNames.LOCKED, isLocked);

        List attrNames = new ArrayList();

        if (isLocked != null) {
            attrNames.add(AdmAttrNames.LOCKED);
        }

        if (isVisible != null) {
            attrNames.add(AdmAttrNames.VISIBLE);
            wset.setAttrValue(AdmAttrNames.VISIBLE, isVisible);
        }

        if (attrNames.size() != 0) {
            Cmd cmd = AdmCmd.getCmd(WithAttrs.UPDATE, wset);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
            cmd.execute();
        }

        return retResult;
    }

    public void preparePersonalStreamCommand(String productName, String id, String desc, String defBranch, AdmObject projectObj,
            AdmObject baselineObj, String cm_rules, Boolean pathControl, Integer worksetVersion) throws AdmException {
        _cmdStr = "CPS " + Encoding.escapeDMCLI(productName + ":" + id);

        if (desc != null) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(desc);
        }

        if (defBranch != null) {
            _cmdStr += " /DEFAULT_BRANCH=" + Encoding.escapeDMCLI(defBranch);
        }

        if (projectObj != null) {

            _cmdStr += " /STREAM=";

            if (worksetVersion != null) {
                _cmdStr += Encoding.escapeDMCLI(projectObj.getAdmSpec().getSpec() + ";" + worksetVersion);
            } else {
                _cmdStr += Encoding.escapeDMCLI(projectObj.getAdmSpec().getSpec());
            }
        }

        if (baselineObj != null) {
            _cmdStr += " /BASELINE=" + Encoding.escapeDMCLI(baselineObj.getAdmSpec().getSpec());
        }

        if (cm_rules != null) {
            if (cm_rules.equals("X")) {
                _cmdStr += " /DEFAULT_CM_RULES";
            } else if (cm_rules.equals("Y")) {
                _cmdStr += " /CM_RULES";
            } else if (cm_rules.equals("N")) {
                _cmdStr += " /NOCM_RULES";
            }
        }

        if (pathControl != null) {
            if (pathControl.booleanValue()) {
                _cmdStr += " /PATH_CONTROL";
            } else {
                _cmdStr += " /NOPATH_CONTROL";
            }
        }

        String attrs = AttributeDefinition.getAttrsCmdStringFromCmd(this);
        if (attrs != null && attrs.length() > 0) {
            _cmdStr += " " + attrs;
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String type = (String) getAttrValue(AdmAttrNames.TYPE_NAME);
        String desc = (String) getAttrValue(CmdArguments.DESCRIPTION);
        Boolean isBranch = (Boolean) getAttrValue(AdmAttrNames.WSET_IS_BRANCH);
        Boolean isForceRev = (Boolean) getAttrValue(AdmAttrNames.WSET_IS_ENFORCED_REV);
        Integer deploymentModel = (Integer) getAttrValue(AdmAttrNames.WSET_IS_MANUAL_DEPLOYMENT);
        Boolean isCopyOnDeployment = (Boolean) getAttrValue(AdmAttrNames.WSET_IS_COPY_ON_DEPLOY);
        Boolean isKeepStage = (Boolean) getAttrValue(AdmAttrNames.WSET_IS_KEEP_STAGE);
        Boolean isParallelExtract = (Boolean) getAttrValue(AdmAttrNames.WSET_IS_PARALLEL_EXTRACT);

        String cm_rules = (String) getAttrValue(AdmAttrNames.WSET_CM_RULES_USAGE);
        @SuppressWarnings("unchecked")
        List<String> namedBranches = (List<String>) getAttrValue(CmdArguments.BRANCHES);
        String defBranch = (String) getAttrValue(CmdArguments.BRANCH);
        AdmObject projectObj = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        AdmObject baselineObj = (AdmObject) getAttrValue(CmdArguments.BASELINE);
        Integer worksetVersion = (Integer) getAttrValue(CmdArguments.WORKSET_VERSION);
        Boolean pathControl = (Boolean) getAttrValue(AdmAttrNames.WSET_PATH_CONTROL);
        Boolean deployMethodIsRequest = (Boolean) getAttrValue(AdmAttrNames.WSET_DEPLOY_METHOD);
        Boolean isStreamObj = (Boolean) getAttrValue(CmdArguments.WSET_IS_STREAM);
        boolean isStream = isStreamObj != null && isStreamObj.booleanValue() ? true : false;
        @SuppressWarnings("unchecked")
        List<String> users = (List<String>) getAttrValue(CmdArguments.TOPIC_STREAM_USERS_LIST);
        @SuppressWarnings("unchecked")
        List<String> requests = (List<String>) getAttrValue(CmdArguments.RELATED_CHDOCS);

        Boolean isTopicStreamObj = (Boolean) getAttrValue(CmdArguments.WSET_IS_TOPIC_STREAM);
        boolean isTopicStream = Boolean.TRUE.equals(isTopicStreamObj);

        Boolean copyBuildConfig = (Boolean) getAttrValue(CmdArguments.COPY_BUILD_CONFIGURATION);
        Boolean importAllRevisions = (Boolean) getAttrValue(CmdArguments.IMPORT_ALL_REVISIONS);
        Boolean force = (Boolean) getAttrValue(CmdArguments.FORCE);
        String creationDate = (String) getAttrValue(AdmAttrNames.CREATE_DATE);

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id);
        if (isStream) {
            if(isTopicStream && StringUtils.isEmpty(productName)){
                _cmdStr = "CS " + Encoding.escapeDMCLI(id);
            }else{
                _cmdStr = "CS " + Encoding.escapeDMCLI(productName + ":" + id);
            }
        } else {
            _cmdStr = "DWS " + Encoding.escapeDMCLI(productName + ":" + id);
            isTopicStream = false;
        }
        if (desc != null) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(desc);
        }
        if (!isStream && (isBranch != null)) {
            _cmdStr += (isBranch.booleanValue()) ? " /BRANCH" : " /TRUNK";
        }
        if (isTopicStream) {
        	_cmdStr += " /TOPIC";
        }
        if (users != null && users.size() > 0) {
            _cmdStr += CmdBuilder.createParameter(" /USERS", users);
        }
        if (requests != null && requests.size() > 0) {
            _cmdStr += CmdBuilder.createParameter(" /TOPIC_REQUESTS", requests);
        }
        if (!isStream && (isForceRev != null)) {
            if (isForceRev.booleanValue()) {
                _cmdStr += " /AUTO_REV";
            } else {
                _cmdStr += " /NOAUTO_REV";
            }
        }

        if (defBranch != null) {
            _cmdStr += " /DEFAULT_BRANCH=" + Encoding.escapeDMCLI(defBranch);
        }

        if (creationDate != null) {
            _cmdStr += " /DATE=" + Encoding.escapeDMCLI(creationDate);
        }

        if (!isStream) {
            if (namedBranches != null && namedBranches.size() > 0) {
                _cmdStr += CmdBuilder.createParameter("/VALID_BRANCHES", namedBranches);
            }
        }

        if (projectObj != null) {
            if (isStream) {
                _cmdStr += " /STREAM=";
            } else {
                _cmdStr += " /WORKSET=";
            }

            if (worksetVersion != null) {
                _cmdStr += Encoding.escapeDMCLI(projectObj.getAdmSpec().getSpec() + ";" + worksetVersion);
            } else {
                _cmdStr += Encoding.escapeDMCLI(projectObj.getAdmSpec().getSpec());
            }
        }
        if (baselineObj != null) {
            _cmdStr += " /BASELINE=" + Encoding.escapeDMCLI(baselineObj.getAdmSpec().getSpec());
        }

        if (projectObj != null) {
            if (copyBuildConfig != null && copyBuildConfig.booleanValue()) {
                _cmdStr += " /COPY_CONFIG";
            } else {
                _cmdStr += " /NOCOPY_CONFIG";
            }
        }
        if (type != null && type.length() > 0) {
            _cmdStr += " /TYPE=\"" + type + "\"";
        }

        if (!isStream && deploymentModel != null) {
            if (deploymentModel.intValue() == Constants.MANUAL_DEPLOYMENT_MODEL) {
                // _cmdStr += " /DEPLOYMENT_MODEL=\"MANUAL\"";
                _cmdStr += " /USE_LOCAL_STAGES";

            } else {
                // _cmdStr += " /DEPLOYMENT_MODEL=\"AUTOMATIC\"";
                _cmdStr += " /NOUSE_LOCAL_STAGES";
            }
        }

        if (isCopyOnDeployment != null) {
            if (isCopyOnDeployment.booleanValue()) {
                _cmdStr += " /COPY_ON_DEPLOY";
            } else {
                _cmdStr += " /NOCOPY_ON_DEPLOY";
            }
        }

        if (!isStream && isKeepStage != null) {
            if (isKeepStage.booleanValue()) {
                _cmdStr += " /KEEP_STAGE";
            }
        }

        if (!isStream && isParallelExtract != null) {
            if (isParallelExtract.booleanValue()) {
                _cmdStr += " /PARALLEL_EXTRACT";
            } else {
                _cmdStr += " /NOPARALLEL_EXTRACT";
            }
        }

        if (!isTopicStream && cm_rules != null) {
            if (cm_rules.equals("X")) {
                _cmdStr += " /DEFAULT_CM_RULES";
            } else if (cm_rules.equals("Y")) {
                _cmdStr += " /CM_RULES";
            } else if (cm_rules.equals("N")) {
                _cmdStr += " /NOCM_RULES";
            }
        }

        if (!isTopicStream && pathControl != null) {
            if (pathControl.booleanValue()) {
                _cmdStr += " /PATH_CONTROL";
            } else {
                _cmdStr += " /NOPATH_CONTROL";
            }
        }

        if (deployMethodIsRequest != null
                && (deploymentModel == null || deploymentModel.intValue() == Constants.MANUAL_DEPLOYMENT_MODEL)) {
            if (deployMethodIsRequest.booleanValue()) {
                _cmdStr += " /DEPLOYMENT_METHOD=REQUEST";
            } else {
                _cmdStr += " /DEPLOYMENT_METHOD=BASELINE";
            }
        }

        if (isStream && importAllRevisions != null) {
            if (importAllRevisions.booleanValue()) {
                _cmdStr += " /ALL";
            }
        }

        if (force != null) {
            if (force.booleanValue()) {
                _cmdStr += " /FORCE";
            } else {
                _cmdStr += " /NOFORCE";
            }
        }

        String attrs = AttributeDefinition.getAttrsCmdStringFromCmd(this);
        if (attrs != null && attrs.length() > 0) {
            _cmdStr += " " + attrs;
        }
    }
}

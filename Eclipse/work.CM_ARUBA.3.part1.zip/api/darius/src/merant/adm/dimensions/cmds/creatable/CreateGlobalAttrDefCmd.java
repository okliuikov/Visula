/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.creatable;

import java.util.Date;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DBLimits;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.GlobalAttributeDefinition;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.SpecialCharacters;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions global attribute definition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new global attribute definition</dd>
 *  <dt>TYPE {AdmObject}<dt><dd>Dimensions object type defining attribute scope</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ATTRDEF_ATTRNO {Integer}<dt><dd>Attribute No. Must be unique within the specified scope. If omitted, an automatic number shall be generated</dd>
 *  <dt>ATTRDEF_DATATYPE{Class}<dt><dd>Attribute data type. java.lang.String {default}, java.lang.Number, java.util.Date, java.lang.Integer</dd>
 *  <dt>ATTRDEF_ACTUALWIDTH {Integer}<dt><dd>Attribute max display length, Default - 25</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author Vadym Krevs
 */
public class CreateGlobalAttrDefCmd extends DBIOCmd {
    public CreateGlobalAttrDefCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_ATTRNO, false, new Integer(-1), Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_DATATYPE, false, String.class, Class.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_ACTUALWIDTH, false, new Integer(25), Integer.class));
        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    /**
     * @see merant.adm.dimensions.cmds.DBIOCmd#validateAttr(String, AttrDef, Object)
     */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(AdmAttrNames.TYPE)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // check role
        AdmObject typeObj = (AdmObject) getAttrValue(AdmAttrNames.TYPE);
        String productName = (String) typeObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
        Class typeClass = (Class) typeObj.getAttrValue(AdmAttrNames.PARENT_CLASS);

        if (User.class.equals(typeClass)) {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_USERMAN")) {
                throw new DimNoPrivilegeException("ADMIN_USERMAN");
            }
        } else {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
                throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
            }
        }

        // extract all attributes
        String attrName = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ID), 25);
        int attrNo = ((Integer) getAttrValue(AdmAttrNames.ATTRDEF_ATTRNO)).intValue();
        Class attrDataType = (Class) getAttrValue(AdmAttrNames.ATTRDEF_DATATYPE);
        int maxLength = ((Integer) getAttrValue(AdmAttrNames.ATTRDEF_ACTUALWIDTH)).intValue();

        // validate some of the attributes
        String attrClass = "C";
        if (Number.class.equals(attrDataType)) {
            attrClass = "N";
        } else if (Date.class.equals(attrDataType)) {
            attrClass = "D";
        } else if (Integer.class.equals(attrDataType)) {
            attrClass = "I";
        }

        if (attrName.length() < 1 || attrName.length() > 25) {
            throw new DimInvalidAttributeException("Error: attribute name length must be in range 1 to 25 characters.");
        }

        if (StringUtils.containsSpecialChars(attrName, SpecialCharacters.INVALID_ATTR_CHARS)) {
            throw new DimInvalidAttributeException(
                    "Error: The attribute name must not contain one or more of the following disallowed characters: "
                            + SpecialCharacters.INVALID_ATTR_CHARS + " or a space character");
        }

        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        if (DoesExistHelper.globalAttributeExists(attrName, typeFlag)) {
            throw new DimAlreadyExistsException("Error: " + TypeUtils.getClassName(typeClass) + " attribute " + attrName
                    + " already exists.");
        }

        String attrScope = typeClass.getName();
        setAttrValue(CmdArguments.INT_SPEC, attrName + "-" + attrScope);

        if (attrNo != -1) {
            // check if it already exists
            if (attributeNumberExists(attrNo, typeFlag)) {
                throw new DimAlreadyExistsException("Error: there already exists an attribute with number " + attrNo);
            }
        } else {
            attrNo = findUnsedAttrNo(typeFlag);
            if (attrNo == 0 || attrNo > DBLimits.getLimits().getMaxAttrNo()) {
                throw new DimBaseCmdException("Error: you have reached the maximum limit of user-defined attributes for "
                        + TypeUtils.getClassName(typeClass) + " Types.");
            }
        }

        try {
            DBIO query = SqlUtils.globalAttrInsertDef80(attrNo, typeFlag, attrName, maxLength, attrClass);
            query.write();
        } catch (DBIOException e) {
            Debug.error(e);
            throw e;
        }

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, GlobalAttributeDefinition.class);
        return retResult;
    }

    private int findUnsedAttrNo(String typeFlag) throws DBIOException, AdmObjectException, DimBaseException {
        DBIO query = new DBIO(wcm_sql.ATTRDEF_FIND_UNUSED_ATTRNO_80);
        query.bindInput(typeFlag);
        query.readStart(DBIO.DB_IGNORE_REST);
        int attrNo = 0;
        if (query.read()) {
            attrNo = query.getInt(1);
        }
        query.close();
        return attrNo;
    }

    private boolean attributeNumberExists(int attrNumber, String typeFlag) throws DBIOException, AdmObjectException,
            DimBaseException {
        DBIO query = new DBIO(wcm_sql.ATTRDEF_CHECK_ATTRNO_80);
        query.bindInput(attrNumber);
        query.bindInput(typeFlag);
        query.readStart();
        boolean exists = query.read();
        query.close();
        return exists;
    }
}

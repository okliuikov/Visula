/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2002 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.helper.UserDisplayFormatter;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.RoleAssignment;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.collections.IQueryRange;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all RoleAssignment's related to the Product object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions project container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Floz
 */
public class QCProductToRoleAssignmentCmd extends QueryRelsCmd {
    public QCProductToRoleAssignmentCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.QUERY_RANGE, false, IQueryRange.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_DISPLAY_FORMATTER, false, UserDisplayFormatter.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Product)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(RoleAssignment.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();

        if (filter != null) {
            filter = (FilterImpl) filter.clone();
        } else {
            filter = new FilterImpl();
        }

        filter.criteria()
                .add(new FilterCriterion(AdmAttrNames.ROLE_ASSIGN_PRODUCT, admObj.getAttrValue(AdmAttrNames.PRODUCT_NAME), FilterCriterion.EQUALS));

        for (Iterator it = filter.orders().iterator(); it.hasNext();) {
            FilterOrder order = (FilterOrder) it.next();
            if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_USERNAME) || order.getAttrName().equals(AdmAttrNames.USER_NAME_FORMATED)) {
                filter.orders().add(new FilterOrder(AdmAttrNames.ROLE_ASSIGN_FULLUSERNAME, order.getFlags()));
            }
        }

        IQueryRange queryRange = (IQueryRange) getAttrValue(CmdArguments.QUERY_RANGE);
        UserDisplayFormatter formatter = (UserDisplayFormatter) getAttrValue(CmdArguments.USER_DISPLAY_FORMATTER);
        retrieveData(admObj, admSecClass, filter, relationships, queryRange, formatter, ret);
        return ret;
    }

    private void retrieveData(AdmObject admObj, Class admSecClass, FilterImpl filter, boolean relationships,
                              IQueryRange queryRange, UserDisplayFormatter formatter, List ret) throws AdmException {
        int total = 0;
        if (queryRange != null) {
            DBIO query = getDBIOForCount(filter);
            query.readStart();
            if (query.read()) {
                total = query.getInt(1);
            }
            query.close();
            queryRange.setSize(total);
        }
        DBIO query = getDBIOForData(filter, formatter);
        query.readStart();
        List specComponents = null;
        int size = 0;
        while (query.read()) {
            if (queryRange == null || queryRange.isInRange(size)) {
                specComponents = new ArrayList();

                String userId = query.getString(1);
                String fullUserName = query.getString(2);

                specComponents.add(userId);
                specComponents.add(query.getString(3));
                specComponents.add(query.getString(4));
                specComponents.add(query.getString(5));
                specComponents.add(query.getString(6));
                specComponents.add(query.getString(7));
                specComponents.add(query.getString(8));
                specComponents.add(query.getString(9));
                specComponents.add(query.getString(10));
                specComponents.add(query.getString(11)); // ycai, new for group uid

                //Preload User object display label, which can be in different formats.
                if (formatter != null) {
                    specComponents.add(formatter.buildUserDisplayName(userId, fullUserName));
                } else {
                    specComponents.add(null);
                }

                addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(specComponents, admSecClass));
            }
            size++;
            if (total > 0 && queryRange != null && queryRange.isOverRange(size)) {
                break;
            }
        }
        query.close();
    }

    private DBIO getDBIOForData(FilterImpl filter, UserDisplayFormatter formatter) throws AdmException {
        return internal_getDBIO(
                "SELECT ru.user_name, up.full_user_name, ru.role, ru.product_id, ru.workset_id, ru.part_id, ru.part_variant, ru.part_pcs, ru.leader, ru.assign_type, ru.group_uid  FROM rm_users ru, users_profile up",
                filter, true, true, formatter);
    }

    private DBIO getDBIOForCount(FilterImpl filter) throws AdmException {
        return internal_getDBIO("SELECT count(*) FROM  rm_users ru", filter, false, false, null);
    }

    private DBIO internal_getDBIO(String select_from, FilterImpl filter, boolean useOrder, boolean needUserFullName,
                                  UserDisplayFormatter formatter) throws AdmException {

        String username = "";
        String role = "";
        String productId = "";
        String projectId = "";
        String partId = "";
        String partVariant = "";
        String partPcs = "";
        String leader = "";
        String assignType = "";
        String groupUid = "";
        String groupName = "";

        StringBuilder sb = new StringBuilder(select_from);

        boolean addAnd = false;
        boolean addWhere = true;

        // Remove duplicated attribute criteria. Such criteria share the same bind value anyway.
        Map<String, FilterCriterion> deduplicatedCriteria = new LinkedHashMap<String, FilterCriterion>();
        for (Iterator it = filter.criteria().iterator(); it.hasNext();) {
            FilterCriterion crit = (FilterCriterion) it.next();
            deduplicatedCriteria.put(crit.getAttrName(), crit);
        }

        for (FilterCriterion crit : deduplicatedCriteria.values()) {
            if (crit.getValue() == null) {
                continue;
            }
            if (addWhere) {
                sb.append(" WHERE ");
                addWhere = false;
            }
            if (needUserFullName) {
                sb.append(" ru.user_name = up.user_name(+) ");
                addAnd = true;
                needUserFullName = false;
            }

            // Assume that by default (when no flags are specified for filter criterion) the SQL operator is "LIKE".
            // When "LIKE" SQL operator should not be used, but "=" instead, it is now necessary to pass EQUALS flag.
            String like = 0 == (crit.getFlags() & FilterCriterion.EQUALS)? "LIKE" : "=";

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_USERNAME) || crit.getAttrName().equals(AdmAttrNames.USER_NAME_FORMATED)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                addAnd = true;
                if (crit.getValue() instanceof List) {
                    sb.append(" (");
                    for (int i = 0; i < ((List) crit.getValue()).size(); i++) {
                        if (i > 0) {
                            sb.append(" OR ");
                        }
                        sb.append("(ru.user_name = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                    }
                    sb.append(") AND 'A' = :I1");
                    username = "A";
                } else {
                    sb.append(" ru.user_name ").append(like).append(" :I1");
                    username = (String) crit.getValue();
                }
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_GROUP_UID)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                addAnd = true;
                groupUid = (String) crit.getValue();
                // Sadly old code says ROLE_ASSIGN_GROUP_UID can be both group_uid and group_name
                if (groupUid.matches("-?\\d+")) // When just digits in a string, check both group_uid and group_name
                    sb.append(" (ru.group_uid = TO_NUMBER(:I10) OR ");
                else
                    sb.append(" (");
                sb.append("ru.group_uid IN (SELECT gc.group_uid FROM GROUP_CATALOGUE gc WHERE gc.group_name = :I10)) ");
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_GROUP_NAME)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                addAnd = true;
                sb.append(" (ru.group_uid IN (SELECT gc.group_uid FROM GROUP_CATALOGUE gc WHERE gc.group_name ").append(like).append(" :I11)) ");
                groupName = (String) crit.getValue();
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_ROLE)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                addAnd = true;
                if (crit.getValue() instanceof List) {
                    sb.append(" (");
                    for (int i = 0; i < ((List) crit.getValue()).size(); i++) {
                        if (i > 0) {
                            sb.append(" OR ");
                        }
                        sb.append("(ru.role = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                    }
                    sb.append(") AND 'A' = :I2");
                    role = "A";
                } else {
                    sb.append("ru.role ").append(like).append(" :I2 ");
                    role = (String) crit.getValue();
                }
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PRODUCT)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                sb.append("ru.product_id ").append(like).append(" :I3");
                addAnd = true;
                productId = (String) crit.getValue();
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_WORKSET_ID)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                sb.append(" ru.workset_id ").append(like).append(" :I4 ");
                addAnd = true;
                projectId = (String) crit.getValue();
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PART_ID)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                addAnd = true;
                if (crit.getValue() instanceof List) {
                    sb.append(" (");
                    for (int i = 0; i < ((List) crit.getValue()).size(); i++) {
                        if (i > 0) {
                            sb.append(" OR ");
                        }
                        sb.append("(ru.part_id = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                    }
                    sb.append(") AND 'A' = :I5");
                    partId = "A";
                } else {
                    sb.append("ru.part_id ").append(like).append(" :I5");
                    partId = (String) crit.getValue();
                }
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PART_VAR)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                addAnd = true;
                if (crit.getValue() instanceof List) {
                    sb.append(" (");
                    for (int i = 0; i < ((List) crit.getValue()).size(); i++) {
                        if (i > 0) {
                            sb.append(" OR ");
                        }
                        sb.append("(ru.part_variant = \'" + ((String) ((List) crit.getValue()).get(i)) + "\')");
                    }
                    sb.append(") AND 'A' = :I6");
                    partVariant = "A";
                } else {
                    sb.append("ru.part_variant ").append(like).append(" :I6");
                    partVariant = (String) crit.getValue();
                }
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PART_PCS)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                sb.append("ru.part_pcs  ").append(like).append("  :I7");
                addAnd = true;
                partPcs = (String) crit.getValue();
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_CAP)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                sb.append("ru.leader ").append(like).append(" :I8");
                addAnd = true;
                leader = (String) crit.getValue();
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_TYPE)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                sb.append("ru.assign_type ").append(like).append(" :I9");
                addAnd = true;
                assignType = (String) crit.getValue();
            }

            if (crit.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_USERS_ONLY)) {
                if (addAnd) {
                    sb.append(" AND ");
                }
                sb.append("ru.user_name IS NOT NULL"); // skip empty user_name (group roles)
                addAnd = true;
            }
        } 

        if (useOrder && filter.orders().size() > 0) {
            sb.append(" ORDER BY ");
            boolean first = true;
            for (Iterator it = filter.orders().iterator(); it.hasNext();) {
                if (first) {
                    first = false;
                } else {
                    sb.append(", ");
                }
                FilterOrder order = (FilterOrder) it.next();
                if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_USERNAME) || order.getAttrName().equals(AdmAttrNames.USER_NAME_FORMATED)) {
                    if (formatter != null && formatter.isUserIdFirst())
                        sb.append("1");
                    else
                        sb.append("2");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_FULLUSERNAME)) {
                    if (formatter != null && formatter.isUserIdFirst())
                        sb.append("2");
                    else
                        sb.append("1");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_ROLE)) {
                    sb.append("3");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PRODUCT)) {
                    sb.append("4");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_WORKSET_ID)) {
                    sb.append("5");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PART_ID)) {
                    sb.append("6");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PART_VAR)) {
                    sb.append("7");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_PART_PCS)) {
                    sb.append("8");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_CAP)) {
                    sb.append("9");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_TYPE)) {
                    sb.append("10");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_GROUP_UID)) {
                    sb.append("11");
                } else if (order.getAttrName().equals(AdmAttrNames.ROLE_ASSIGN_GROUP_NAME)) {
                    sb.append("12");
                }
                int direction = order.getFlags() & (FilterOrder.ASCENDING | FilterOrder.DESCENDING);
                switch (direction) {
                case FilterOrder.ASCENDING:
                    sb.append(" ASC");
                    break;
                case FilterOrder.DESCENDING:
                    sb.append(" DESC");
                    break;
                default:
                    break;
                }
            }
        }

        String queryStr = sb.toString();
        DBIO query = new DBIO(queryStr);
        query.bindInput(username);
        query.bindInput(role);
        query.bindInput(productId);
        query.bindInput(projectId);
        query.bindInput(partId);
        query.bindInput(partVariant);
        query.bindInput(partPcs);
        query.bindInput(leader);
        query.bindInput(assignType);
        query.bindInput(groupUid);
        query.bindInput(groupName);
        return query;
    }
}

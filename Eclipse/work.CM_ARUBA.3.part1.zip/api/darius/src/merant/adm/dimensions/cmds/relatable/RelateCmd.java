/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.serena.dmfile.FilePath;
import com.serena.dmfile.progress.CancelMonitor;
import com.serena.dmfile.progress.ProgressListener;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.TempFileOutputStream;
import merant.adm.dimensions.cmds.interfaces.AdmCmdEvents;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimWrongServerVersionException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.BaselineCode;
import merant.adm.dimensions.objects.BaselineTemplateRule;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.BrowseTemplate;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.ChdocRelationshipName;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.FileAreaDirectory;
import merant.adm.dimensions.objects.Format;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemTypeGroup;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.LifeCycleImage;
import merant.adm.dimensions.objects.LifeCycleState;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.NetCodeSet;
import merant.adm.dimensions.objects.NetFileSys;
import merant.adm.dimensions.objects.NetInstance;
import merant.adm.dimensions.objects.NetNode;
import merant.adm.dimensions.objects.NetNodeConnection;
import merant.adm.dimensions.objects.NetObject;
import merant.adm.dimensions.objects.NetProtocol;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.RelationshipName;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.ReplBlnMasterConfig;
import merant.adm.dimensions.objects.ReplBlnSubordinateConfig;
import merant.adm.dimensions.objects.ReplChdocMasterConfig;
import merant.adm.dimensions.objects.ReplChdocSubordinateConfig;
import merant.adm.dimensions.objects.ReplItemMasterConfig;
import merant.adm.dimensions.objects.ReplItemSubordinateConfig;
import merant.adm.dimensions.objects.Requirement;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.UserReportDefinition;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.Validset;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.AdmObjectList;
import merant.adm.dimensions.objects.collections.AdmObjectListImpl;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmComplexSpec;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.AttributeBlock;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;
import merant.adm.framework.CmdExecutionListener;

/**
 * This command will relate two Dimensions objects.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Parent Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_LIST {AdmObjectList}</dt><dd>Dimensions AdmObject's list</dd>
 *  <dt>ADM_REL_TYPE {AdmObject}<dt><dd>Relationship type object</dd>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 *  <dt>COMMENT {String}<dt><dd>Comment to be applied to operation</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}<dt><dd>If true, sets default object preferences</dd>
 *  <dt>RELTYPE_IS_USAGE {Boolean}<dt><dd>If true (only used by Part-Item/Part), (un)relates as Usage</dd>
 *  <dt>WSET_USER_DIR {String}<dt><dd>User directory when setting the default work set scope</dd>
 *  <dt>RESET {Boolean}<dt><dd>If true, workset is changed. If false, only default chdocs are set on the workset, but the workset is not changed </dd>
 *  <dt>DEFAULT_CHDOC {String}<dt><dd>Id of Change Document to be set as default Change Document for the current workset</dd>
 *  <dt>DEFAULT_PART {String}<dt><dd>Spec of Part to be set as default working Part for the project</dd>
 *  <dt>PENDING {Boolean}<dt><dd>For (un)relating Parts and Change Documents, this indicates the pending list should be recalculated</dd>
 *  <dt>ALL {Boolean}<dt><dd>For removing items from workset, this indicates whether all item revisions of the
 *                           given item should be removed or just the selected one>/dd>
 *  <dt>PROJECT {String}<dt><dd>Project used if relating items to a part</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of requests to be related</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @todo Deprecate RELTYPE_IS_DEFAULT, RELTYPE_IS_USAGE etc...
 * @author Floz
 */
public class RelateCmd extends RPCExecCmd {
    public RelateCmd() throws AttrException {
        super();
        setAlias(Relatable.RELATE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ROOT_PROJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, AdmObjectList.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_REL_TYPE, false, AdmUidObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_DEFAULT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_USAGE, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.WSET_USER_DIR, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCH, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WS_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RESET, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.DEFAULT_CHDOC, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DEFAULT_PART, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EXTENSION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PENDING, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CHECK, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.LIBRARY_CACHE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODECONNECTION_DIRECT_FILE_COPY, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODECONNECTION_FILE_COMPRESSION, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));

        // VADYMK: the next 3 arguments are used by RelateLocalAttrDefToValidsetCmd
        // BEGIN
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_VALIDATION_GROUP_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_LOVCOLUMN, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_AUTOPOPULATED, false, Boolean.TRUE, Boolean.class));
        // END

        // PJB: the next 3 arguments are used by RelateFileAreaToWorksetCmd
        // BEGIN
        setAttrDef(new CmdArgDef(CmdArguments.AREA_REL_LOCATION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.POPULATE, false, Boolean.class));
        // END

        // AB: this is used for remove item from workset command
        setAttrDef(new CmdArgDef(CmdArguments.ALL, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, false, String.class));

        // for AIWS, baseline spec
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, false, String.class));
    }

    /** @todo Find a way to validate when dependencies exist between arguments */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT) && (attrValue != null)) {
            if ((!(attrValue instanceof Baseline)) && (!(attrValue instanceof Branch))
                    && (!(attrValue instanceof BaselineTemplateRule)) && (!(attrValue instanceof BrowseTemplate))
                    && (!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof Customer))
                    && (!(attrValue instanceof FileArea)) && (!(attrValue instanceof FileAreaDirectory))
                    && (!(attrValue instanceof Format)) && (!(attrValue instanceof Item)) && (!(attrValue instanceof LifeCycle))
                    && (!(attrValue instanceof LifeCycleImage)) && (!(attrValue instanceof NetBaseDatabase))
                    && (!(attrValue instanceof NetNodeConnection)) && (!(attrValue instanceof NetObject))
                    && (!(attrValue instanceof Part)) && (!(attrValue instanceof Product)) && (!(attrValue instanceof Requirement))
                    && (!(attrValue instanceof Stage)) && (!(attrValue instanceof Type))
                    && (!(attrValue instanceof UserReportFile)) && (!(attrValue instanceof WorkSet))
                    && (!(attrValue instanceof LocalAttributeDefinition)) && (!(attrValue instanceof ExternalRequest))) {
                throw new AttrException("Child object type (" + attrValue.getClass() + ") is not supported", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if ((!(attrValue instanceof AttributeBlock)) && (!(attrValue instanceof BaselineCode))
                    && (!(attrValue instanceof Baseline)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof ExternalRequest)) && (!(attrValue instanceof Item))
                    && (!(attrValue instanceof ItemTypeGroup)) && (!(attrValue instanceof LifeCycle))
                    && (!(attrValue instanceof LifeCycleState)) && (!(attrValue instanceof NetCodeSet))
                    && (!(attrValue instanceof NetFileSys)) && (!(attrValue instanceof NetInstance))
                    && (!(attrValue instanceof NetNode)) && (!(attrValue instanceof NetProtocol)) && (!(attrValue instanceof Part))
                    && (!(attrValue instanceof Release)) && (!(attrValue instanceof ReplBlnMasterConfig))
                    && (!(attrValue instanceof ReplBlnSubordinateConfig)) && (!(attrValue instanceof ReplItemMasterConfig))
                    && (!(attrValue instanceof ReplItemSubordinateConfig)) && (!(attrValue instanceof ReplChdocMasterConfig))
                    && (!(attrValue instanceof ReplChdocSubordinateConfig)) && (!(attrValue instanceof Requirement))
                    && (!(attrValue instanceof Type)) && (!(attrValue instanceof User))
                    && (!(attrValue instanceof UserReportDefinition)) && (!(attrValue instanceof Validset))
                    && (!(attrValue instanceof WorkSet))) {
                throw new AttrException("Parent object type (" + attrValue.getClass() + ") is not supported", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_REL_TYPE)) {
            if (attrValue != null) {
                if ((!(attrValue instanceof RelationshipType)) && (!(attrValue instanceof ChdocRelationshipName))
                        && (!(attrValue instanceof RelationshipName))) {
                    throw new AttrException("Relationship object type (" + attrValue.getClass() + ") is not supported", attrDef,
                            attrValue);
                }
            }
        }
    }

    private Object internalExecute(AdmObject admParentObj, AdmObject admObj, AdmUidObject relType, boolean remove, boolean do_pend)
            throws DimBaseCmdException, AdmObjectException, AdmException {
        Object retResult = null;
        boolean refreshWorkSet = false;
        StringBuffer sb = new StringBuffer();
        String comment = (String) getAttrValue(CmdArguments.COMMENT);

        // Always first process by admParentObj (and never by admObj) to make sure that we do not accidentally hide
        // existing/future specializations of Relatable.RELATE.
        //
        // TODO: use AdmCommands.xml to figure out which subclass Relatable.RELATE is to be used to do the job
        //

        if (admParentObj instanceof NetCodeSet || admParentObj instanceof NetFileSys) {
            if (admObj instanceof NetNodeConnection) {
                List scopeObjects = AdmHelperCmd.getObjects(admObj.getAdmBaseId().getScopeObjects());
                sb.append("UNC /SERVER_NAME=");
                sb.append(Encoding.escapeDMCLI(((AdmObject) scopeObjects.get(0)).getAdmSpec().getSpec()));
                sb.append(" /CLIENT_NAME=");
                sb.append(Encoding.escapeDMCLI(((AdmObject) scopeObjects.get(1)).getAdmSpec().getSpec()));
                sb.append(" /NWO_NAME=");
                sb.append(Encoding.escapeDMCLI(((AdmObject) scopeObjects.get(2)).getAdmSpec().getSpec()));

                if (!remove) {
                    if (admParentObj instanceof NetCodeSet) {
                        sb.append(" /CDST_NUMBER=");
                    } else if (admParentObj instanceof NetFileSys) {
                        sb.append(" /FS_NAME=");
                    }
                    sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                } else {
                    if (admParentObj instanceof NetCodeSet) {
                        sb.append(" /CDST_NUMBER=NULL");
                    } else if (admParentObj instanceof NetFileSys) {
                        sb.append(" /FS_NAME=NULL");
                    }
                }
                Boolean directFileCopy = (Boolean) getAttrValue(AdmAttrNames.NETNODECONNECTION_DIRECT_FILE_COPY);
                Boolean fileCompression = (Boolean) getAttrValue(AdmAttrNames.NETNODECONNECTION_FILE_COMPRESSION);
                if (directFileCopy != null) {
                    sb.append((directFileCopy.booleanValue()) ? " /DIRECT_FILE_COPY" : " /NODIRECT_FILE_COPY");
                }
                if (fileCompression != null) {
                    sb.append((fileCompression.booleanValue()) ? " /FILE_COMPRESSION" : " /NOFILE_COMPRESSION");
                }
            }
        } else if (admParentObj instanceof ReplItemMasterConfig || admParentObj instanceof ReplItemSubordinateConfig) {
            if (admObj instanceof Branch) {
                // (de)assign branch to/from item replication configuration
                Cmd cmd = AdmCmd.getCmd("RelateBranchToItemReplCfgCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof ReplBlnMasterConfig || admParentObj instanceof ReplBlnSubordinateConfig) {
            if (admObj instanceof Branch) {
                // (de)assign branch to/from baseline replication configuration
                Cmd cmd = AdmCmd.getCmd("RelateBranchToBlnReplCfgCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            } else if (admObj instanceof Type) {
                // (de)assign an item type to/from baseline replication configuration
                Cmd cmd = AdmCmd.getCmd("RelateItemTypeToBlnReplCfgCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof ReplChdocMasterConfig || admParentObj instanceof ReplChdocSubordinateConfig) {
            if (admObj instanceof Type) {
                // (de)assign an change document type to/from change document replication configuration
                Cmd cmd = AdmCmd.getCmd("RelateChdocTypeToChdocReplCfgCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof LifeCycleState) {
            if (admObj instanceof Stage) {
                Cmd cmd = AdmCmd.getCmd("RelateStageToLifeCycleStateCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof AttributeBlock) {
            if (admObj instanceof LocalAttributeDefinition) {
                Cmd cmd = AdmCmd.getCmd("RelateLocalAttrDefToAttrBlockCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof Baseline) {
            if (admObj instanceof Baseline) {
                String relLocation = (String) getAttrValue(CmdArguments.AREA_REL_LOCATION);
                sb.append(remove ? "XBBL " : "RBBL ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /BASELINE=");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                if (relLocation != null) {
                    sb.append(" /RELATIVE_LOCATION=");
                    sb.append(Encoding.escapeDMCLI(relLocation));
                }
            }
        } else if (admParentObj instanceof BaselineCode) {
            if (admObj instanceof BaselineTemplateRule) {
                // Note: There is no unrelate only relate (meaning replace)
                Cmd cmd = AdmCmd.getCmd("_internal_relate_blnt_to_blnc", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                retResult = cmd.execute();
            }
        } else if (admParentObj instanceof ItemTypeGroup) {
            if (admObj instanceof Type) {
                Class typeClass = (Class) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
                if (Item.class.equals(typeClass)) {
                    Cmd cmd = AdmCmd.getCmd("RelateItemTypeToItemTypeGroupCmd", admObj);
                    cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                    cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                    retResult = ((AdmResult) cmd.execute()).getResultMsg();
                }
            }
        } else if (admParentObj instanceof NetInstance) {
            if (admObj instanceof NetBaseDatabase) {
                sb.append(remove ? "DBDB " : "UBDB ");
                sb.append(" /BDB_NAME=");
                sb.append(Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID)));
                sb.append(" /DB_SERVICE=");
                sb.append(Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.ID)));
                sb.append(" /NN_NAME=");
                sb.append(Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.NETINSTANCE_NODE)));
            }
        } else if (admParentObj instanceof NetNode) {
            if (admObj instanceof NetObject) {
                sb.append(remove ? "DNDO " : "CNDO ");
                sb.append(" /NWO_NAME=");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /NN_NAME=");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
            }
        } else if (admParentObj instanceof NetProtocol) {
            if (admObj instanceof NetObject) {
                if (!remove) {
                    sb.append("UNWO ");
                    sb.append(" /NWO_NAME=");
                    sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                    sb.append(" /PROTOCOL=");
                    sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                }
            }
        } else if (admParentObj instanceof Item) {
            if (admObj instanceof Item) {
                if (relType == null) {
                    throw new DimBaseCmdException("A relationship does not exist between these two objects.");
                }
                sb.append(remove ? "XII " : "RII ");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(" ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /RELATIONSHIP=");
                sb.append(Encoding.escapeDMCLI(relType.getId()));
                if (!remove) {
                    if (comment != null && comment.length() != 0) {
                        sb.append(" /COMMENT=");
                        sb.append(Encoding.escapeDMCLI(comment));
                    }
                }
                String projectId = (String) getAttrValue(AdmAttrNames.PROJECT);
                if (projectId != null && projectId.length() > 0) {
                    sb.append(" /WORKSET=");
                    sb.append(Encoding.escapeDMCLI(projectId));
                }
            }
        } else if (admParentObj instanceof ChangeDocument) {
            if (relType == null && !(admObj instanceof Part)) {
                throw new DimBaseCmdException("A relationship does not exist between these two objects.");
            }
            if (admObj instanceof Baseline) {
                sb.append(remove ? "XBCD " : "RBCD ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /CHANGE_DOC_IDS=(");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(")");
                if (relType != null) {
                    if (((RelationshipType) relType).getAdmUid().getUid() == Constants.RELTYPE_UID_AFFECTED) {
                        sb.append(" /AFFECTED");
                    } else if (((RelationshipType) relType).getAdmUid().getUid() == Constants.RELTYPE_UID_INFO) {
                        sb.append(" /INFO");
                    } else if (((RelationshipType) relType).getAdmUid().getUid() == Constants.RELTYPE_UID_IN_RESPONSE_TO) {
                        sb.append(" /IN_RESPONSE_TO");
                    }
                }
            } else if (admObj instanceof ChangeDocument) {
                sb.append(remove ? "XCCD " : "RCCD ");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(" /CHANGE_DOC_IDS=(");
                if (admObj.getAdmSpec() instanceof AdmComplexSpec) {
                    List specComponents = Encoding.parseSpecList(admObj.getAdmSpec().getSpec(), "");
                    for (int i = 0; i < specComponents.size(); i++) {
                        if (i > 0) {
                            sb.append(", ");
                        }
                        sb.append(Encoding.escapeDMCLI((String) specComponents.get(i)));
                    }
                } else {
                    sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                }
                sb.append(")");
                if (relType != null) {
                    if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_DEPENDENT) {
                        sb.append(" /DEPEND");
                    } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_INFO) {
                        sb.append(" /INFO");
                    } else {
                        sb.append(" /RELATIONSHIP=");
                        sb.append(Encoding.escapeDMCLI(relType.getId()));
                    }
                }
            } else if (admObj instanceof Item) {
                sb.append(remove ? "XICD " : "RICD ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /CHANGE_DOC_IDS=(");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(")");
                if (relType != null) {
                    if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_IN_RESPONSE_TO) {
                        sb.append(" /IN_RESPONSE_TO");
                    } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_INFO) {
                        sb.append(" /INFO");
                    } else {
                        sb.append(" /AFFECTED");
                    }
                }
                sb.append(" /WORKSET=");
                String projectId = (String) this.getAttrValue(AdmAttrNames.PROJECT);
                if (projectId != null && projectId.length() > 0) {
                    sb.append(Encoding.escapeDMCLI(projectId));
                } else {
                    sb.append(" $GENERIC:$GLOBAL");
                }
            } else if (admObj instanceof Part) {
                sb.append(remove ? "XPCD " : "RPCD ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /CHANGE_DOC_IDS=(");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(")");
                if (do_pend) {
                    sb.append(" /PEND");
                }
            } else if (admObj instanceof Requirement) {
                sb.append(remove ? "XRCD " : "RRCD ");
                // * @TODO - chrisp - This needs to be the actual db id for now,
                // * but will change to specs in a future version of the API
                String chdoc_spec = ((AdmUidObject) admParentObj).getAdmSpec().getSpec();
                String req_spec = ((AdmUidObject) admObj).getAdmSpec().getSpec();

                // * Make sure our requirement object has all its attributes.
                Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObj);
                cmd.setAttrValue(
                        CmdArguments.ATTRIBUTE_NAMES,
                        Arrays.asList(new String[] { AdmAttrNames.RTM_COL_SPEC, AdmAttrNames.RTM_PROJ_NAME,
                                AdmAttrNames.RTM_PROJ_DBNAME, AdmAttrNames.RTM_PROJ_URL, }));
                cmd.execute();
                // TODO : test these changes

                String rtmProjName = (String) admObj.getAttrValue(AdmAttrNames.RTM_PROJ_NAME);
                String rtmProjDbName = (String) admObj.getAttrValue(AdmAttrNames.RTM_PROJ_DBNAME);
                String rtmProjUrl = (String) admObj.getAttrValue(AdmAttrNames.RTM_PROJ_URL);
                String containerName = (String) admObj.getAttrValue(AdmAttrNames.RTM_COL_SPEC);
                if (containerName == null)// One of the cases is where you create a new change doc by selecting a requirement in web
                                          // client.
                {
                    containerName = (String) admObj.getAttrValue(CmdArguments.CONTAINER_NAME);
                }

                sb.append(" /CHANGE_DOC_ID=" + Encoding.escapeDMCLI(String.valueOf(chdoc_spec)) + "");
                sb.append(" /REQUIREMENT_ID=" + Encoding.escapeDMCLI(String.valueOf(req_spec)) + "");
                sb.append(" /CONTAINER_NAME=" + Encoding.escapeDMCLI(String.valueOf(containerName)) + "");
                sb.append(" /RM_DBNAME=" + Encoding.escapeDMCLI(String.valueOf(rtmProjDbName)) + "");
                sb.append(" /RM_PROJECTNAME=" + Encoding.escapeDMCLI(String.valueOf(rtmProjName)) + "");
                sb.append(" /RM_URL=" + Encoding.escapeDMCLI(String.valueOf(rtmProjUrl)) + "");
            }
        } else if (admParentObj instanceof ExternalRequest) {
            if (relType == null) {
                throw new DimBaseCmdException("A relationship does not exist between these two objects.");
            }
            if (admObj instanceof Item) {
                sb.append(remove ? "XICD " : "RICD ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /CHANGE_DOC_IDS=(");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(")");
                if (relType != null) {
                    if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_IN_RESPONSE_TO) {
                        sb.append(" /IN_RESPONSE_TO");
                    } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_INFO) {
                        sb.append(" /INFO");
                    } else {
                        sb.append(" /AFFECTED");
                    }
                }
                sb.append(" /WORKSET=");
                String projectId = (String) this.getAttrValue(AdmAttrNames.PROJECT);
                if (projectId != null && projectId.length() > 0) {
                    sb.append(Encoding.escapeDMCLI(projectId));
                } else {
                    sb.append(" $GENERIC:$GLOBAL");
                }
            }
        } else if (admParentObj instanceof LifeCycle) {
            if (admObj instanceof LifeCycleImage) {
                Cmd cmd = AdmCmd.getCmd("RelateImageToLifeCycleCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, getAttrValue(CmdArguments.ADM_PARENT_OBJECT));
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof Type) {
            if (admObj instanceof LifeCycle) {
                Cmd cmd = AdmCmd.getCmd("RelateLifeCycleToTypeCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            } else if (admObj instanceof BrowseTemplate) {
                Cmd cmd = AdmCmd.getCmd("RelateBrowseTemplateToTypeCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof Validset) {
            if (admObj instanceof LocalAttributeDefinition) {
                Cmd cmd = AdmCmd.getCmd("RelateLocalAttrDefToValidsetCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, admParentObj);
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                cmd.setAttrValue(AdmAttrNames.ATTRDEF_VALIDATION_GROUP_NAME,
                        getAttrValue(AdmAttrNames.ATTRDEF_VALIDATION_GROUP_NAME));
                cmd.setAttrValue(AdmAttrNames.ATTRDEF_LOVCOLUMN, getAttrValue(AdmAttrNames.ATTRDEF_LOVCOLUMN));
                cmd.setAttrValue(AdmAttrNames.ATTRDEF_IS_AUTOPOPULATED, getAttrValue(AdmAttrNames.ATTRDEF_IS_AUTOPOPULATED));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof User) {
            if (admObj instanceof Product) {
                boolean isDefault = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT)).booleanValue();
                if (isDefault) {
                    try {
                        // set default product:
                        Cmd cmd = AdmCmd.getCmd(Server.USER_PREF);
                        cmd.setAttrValue(CmdArguments.PREF_NAMES, Collections.singletonList("PRODUCT"));
                        cmd.setAttrValue(CmdArguments.PREF_VALUES, Collections.singletonList(admObj.getId()));
                        cmd.execute();
                        DimSystem.getSystem().getSessionBean().refreshRootObj(Product.class);
                        // "manually" update the current product to the default one:
                        AdmObject defObj = DimSystem.getSystem().getSessionBean().getDefRootObj(Product.class);
                        DimSystem.getSystem().getSessionBean().setCurRootObj(defObj);
                        retResult = "Operation completed successfully.";
                    } catch (DimWrongServerVersionException e) {
                        // "manually" update the default and current product to the requested one:
                        DimSystem.getSystem().getSessionBean().setCurRootObj(admObj);
                        retResult = "This server only allows the product to be changed within this session.\n"
                                + "Operation completed successfully.";
                    }
                } else {
                    DimSystem.getSystem().getSessionBean().setCurRootObj(admObj);
                    DimSystem.getSystem().getSessionBean().refreshRootObj(Product.class);
                    retResult = "Operation completed successfully.";
                }
            } else if (admObj instanceof WorkSet) {
                boolean isDefault = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT)).booleanValue();
                boolean isReset = ((Boolean) getAttrValue(CmdArguments.RESET)).booleanValue();
                String chdoc = (String) getAttrValue(CmdArguments.DEFAULT_CHDOC);
                String branch = (String) getAttrValue(CmdArguments.BRANCH);
                String libraryCacheArea = (String) getAttrValue(CmdArguments.LIBRARY_CACHE);
                AdmObject rootProj = (AdmObject) getAttrValue(CmdArguments.ROOT_PROJECT);
                String part = (String) getAttrValue(CmdArguments.DEFAULT_PART);

                sb.append("SCWS ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(isDefault ? " /DEFAULT" : " /NODEFAULT");
                if (rootProj != null) {
                    sb.append(" /ROOT_PROJECT=" + Encoding.escapeDMCLI(rootProj.getAdmSpec().getSpec()));
                }
                if (chdoc != null) {
                    sb.append(" /CHANGE=" + Encoding.escapeDMCLI(chdoc));
                }
                if (branch != null) {
                    sb.append(" /USER_BRANCH=" + Encoding.escapeDMCLI(branch));
                }
                if (libraryCacheArea != null) {
                    sb.append(" /LIBRARY_CACHE=" + Encoding.escapeDMCLI(libraryCacheArea));
                }
                if (part != null) {
                    sb.append(" /PART=" + Encoding.escapeDMCLI(part));
                }
                sb.append(isReset ? "" : " /NORESET");

                String userDir = (String) getAttrValue(AdmAttrNames.WSET_USER_DIR);
                if (userDir == null || userDir.length() == 0) {
                    Cmd cmd = AdmCmd.getCmd(WithAttrs.GET, admObj);
                    cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, AdmAttrNames.WSET_USER_DIR);
                    List l = (List) cmd.execute();
                    userDir = (l != null && l.size() != 0) ? ((String) l.get(0)) : null;
                }
                if (userDir != null && userDir.length() != 0) {
                    boolean doCheck = ((Boolean) getAttrValue(CmdArguments.CHECK)).booleanValue();
                    sb.append(" /DIR=");
                    sb.append(Encoding.escapeDMCLI(userDir));
                    sb.append((doCheck && !FilePath.hasNodeName(userDir)) ? " /CHECK" : " /NOCHECK");
                }
                refreshWorkSet = true;

                sb.append(" /USERS=(");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(")");
            }
        } else if (admParentObj instanceof WorkSet) {
            if (admObj instanceof Branch) {
                boolean isDefault = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT)).booleanValue();
                if (isDefault) {
                    sb.append("SWS ");
                    sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                    sb.append(" /DEFAULT_BRANCH=");
                    sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                } else {
                    AdmObjectList admObjList = new AdmObjectListImpl();
                    admObjList.add(admObj);
                    retResult = multipleExecute(admParentObj, admObjList, relType, remove, do_pend);
                }
            } else if (admObj instanceof Item) {
                String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
                sb.append(remove ? "RIWS " : "AIWS ");
                String newSpec = "";
                if (((Boolean) this.getAttrValue(CmdArguments.ALL)).booleanValue()) {
                    String spec = admObj.getAdmSpec().getSpec();

                    int index = spec.indexOf(";");
                    if (index != -1) {
                        newSpec = spec.substring(0, index + 1);
                        newSpec += "*";
                    }
                } else {
                    newSpec = admObj.getAdmSpec().getSpec();
                }
                sb.append(Encoding.escapeDMCLI(newSpec));
                sb.append(" /WORKSET=");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                String wsFile = (String) getAttrValue(CmdArguments.WS_FILE);
                if (wsFile != null && wsFile.length() > 0) {
                    sb.append(" /WS_FILENAME=");
                    sb.append(Encoding.escapeDMCLI(CmdUtils.relPathForCmd(wsFile)));
                }
                if ((chdocs != null) && (chdocs.length() > 0)) {
                    sb.append(" /CHANGE_DOC_IDS=(" + chdocs + ")");
                }

                String baseline = (String) getAttrValue(CmdArguments.BASELINE);
                if (baseline != null && baseline.length() > 0) {
                    sb.append(" /BASELINE=");
                    sb.append(Encoding.escapeDMCLI(CmdUtils.relPathForCmd(baseline)));
                }
            } else if (admObj instanceof FileArea) {
                sb.append(remove ? "XAWS " : "RAWS ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /WORKSET=");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                String relLocation = (String) getAttrValue(CmdArguments.AREA_REL_LOCATION);
                if (relLocation != null && relLocation.length() > 0 && !remove) {
                    sb.append(" /RELATIVE_LOCATION=");
                    sb.append(Encoding.escapeDMCLI(relLocation));
                }
                Boolean populate = (Boolean) getAttrValue(CmdArguments.POPULATE);
                if (populate != null && populate.booleanValue() && !remove) {
                    sb.append(" /POPULATE"); // /NOPOPULATE is default
                }
                Boolean keep = (Boolean) getAttrValue(CmdArguments.KEEP);
                if (keep != null && !keep.booleanValue()) {
                    sb.append(" /NOKEEP"); // /KEEP is default
                }
            } else if (admObj instanceof Baseline) {
                sb.append(remove ? "XBWS " : "RBWS ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /WORKSET=");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                if (!remove) {
                    String relLocation = (String) getAttrValue(CmdArguments.AREA_REL_LOCATION);
                    if (relLocation != null && relLocation.length() > 0) {
                        sb.append(" /RELATIVE_LOCATION=");
                        sb.append(Encoding.escapeDMCLI(relLocation));
                    }
                }
            } else if (admObj instanceof WorkSet) {
                sb.append(remove ? "XWWS " : "RWWS ");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(" /WORKSET=");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                if (!remove) {
                    String relLocation = (String) getAttrValue(CmdArguments.AREA_REL_LOCATION);
                    if (relLocation != null && relLocation.length() > 0) {
                        sb.append(" /RELATIVE_LOCATION=");
                        sb.append(Encoding.escapeDMCLI(relLocation));
                    }
                }
            } else if (admObj instanceof ChangeDocument || admObj instanceof ExternalRequest) {
                sb.append(remove ? "XWCD " : "RWCD ");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(" /CHANGE_DOC_IDS=(");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(")");
            }
        } else if (admParentObj instanceof Part) {
            if (admObj instanceof Part) {
                Boolean objUsage = (Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_USAGE);
                boolean isUsage = (objUsage == null) ? true : objUsage.booleanValue();
                if (isUsage) {
                    sb.append(remove ? "URP " : "RP ");
                    sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                    sb.append(" /PARENT_PART=");
                    sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                } else {
                    sb.append("MDR ");
                    sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                    sb.append(" /PARENT_PART=");
                    sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                }
            } else if (admObj instanceof Item) {
                boolean isUsage = true;
                if (relType == null) {
                    Boolean objUsage = (Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_USAGE);
                    isUsage = (objUsage == null) ? true : objUsage.booleanValue();
                } else {
                    if (relType.getId().equals("Owned")) {
                        isUsage = false;
                    }
                }
                if (isUsage) {
                    sb.append(remove ? "XIP " : "RIP ");
                    sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                    sb.append(" /PART=");
                    sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                    String project = (String) getAttrValue(AdmAttrNames.PROJECT);
                    if (project != null && project.length() > 0) {
                        sb.append(" /WORKSET=");
                        sb.append(Encoding.escapeDMCLI(project));
                    }
                } else {
                    sb.append("MIP ");
                    sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                    sb.append(" /PART=");
                    sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));

                    String project = (String) getAttrValue(AdmAttrNames.PROJECT);
                    if (project != null && project.length() > 0) {
                        sb.append(" /WORKSET=");
                        sb.append(Encoding.escapeDMCLI(project));
                    }
                }
            } else if (admObj instanceof ChangeDocument) {
                sb.append(remove ? "XPCD " : "RPCD ");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(" /CHANGE_DOC_IDS=(");
                sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));
                sb.append(")");
                if (do_pend) {
                    sb.append(" /PEND");
                }
            }
        } else if (admParentObj instanceof Release) {
            if (admObj instanceof Customer) {
                sb.append(remove ? "WRC " : "FRC ");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(" /CUSTOMER=" + Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID)));
                sb.append(" /LOCATION="
                        + Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.CUSTOMER_LOCATION)));
                sb.append(" /PROJECT="
                        + Encoding.escapeDMCLI((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.CUSTOMER_PROJECT)));
                if (!remove && comment != null && comment.length() != 0) {
                    sb.append(" /DESCRIPTION=" + Encoding.escapeDMCLI(comment));
                }
            }
        } else if (admParentObj instanceof UserReportDefinition) {
            if (admObj instanceof UserReportFile) {
                Cmd cmd = AdmCmd.getCmd("RelateUserReportFileToUserReportDefinitionCmd", admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, getAttrValue(CmdArguments.ADM_PARENT_OBJECT));
                cmd.setAttrValue(CmdArguments.REMOVE, getAttrValue(CmdArguments.REMOVE));
                retResult = ((AdmResult) cmd.execute()).getResultMsg();
            }
        } else if (admParentObj instanceof Requirement) {
            if (admObj instanceof ChangeDocument) {
                sb.append(remove ? "XRCD " : "RRCD ");
                String chdoc_spec = ((AdmUidObject) admObj).getAdmSpec().getSpec();
                String req_spec = ((AdmUidObject) admParentObj).getAdmSpec().getSpec();

                // * Make sure our requirement object has all its attributes.
                Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, admParentObj);
                cmd.setAttrValue(
                        CmdArguments.ATTRIBUTE_NAMES,
                        Arrays.asList(new String[] { AdmAttrNames.RTM_COL_SPEC, AdmAttrNames.RTM_PROJ_NAME,
                                AdmAttrNames.RTM_PROJ_DBNAME, AdmAttrNames.RTM_PROJ_URL, }));
                cmd.execute();
                // TODO : test these changes

                String containerName = (String) admParentObj.getAttrValue(AdmAttrNames.RTM_COL_SPEC);
                String rtmProjName = (String) admParentObj.getAttrValue(AdmAttrNames.RTM_PROJ_NAME);
                String rtmProjDbName = (String) admParentObj.getAttrValue(AdmAttrNames.RTM_PROJ_DBNAME);
                String rtmProjUrl = (String) admParentObj.getAttrValue(AdmAttrNames.RTM_PROJ_URL);

                sb.append(" /CHANGE_DOC_ID=" + Encoding.escapeDMCLI(String.valueOf(chdoc_spec)) + "");
                sb.append(" /REQUIREMENT_ID=" + Encoding.escapeDMCLI(String.valueOf(req_spec)) + "");
                sb.append(" /CONTAINER_NAME=" + Encoding.escapeDMCLI(String.valueOf(containerName)) + "");
                sb.append(" /RM_DBNAME=" + Encoding.escapeDMCLI(String.valueOf(rtmProjDbName)) + "");
                sb.append(" /RM_PROJECTNAME=" + Encoding.escapeDMCLI(String.valueOf(rtmProjName)) + "");
                sb.append(" /RM_URL=" + Encoding.escapeDMCLI(String.valueOf(rtmProjUrl)) + "");
            }
        }

        // some commands have already been executed:
        if (retResult != null) {
            return retResult;
        }

        _cmdStr = sb.toString();
        retResult = executeRpc();
        if (refreshWorkSet) {
            DimSystem.getSystem().getSessionBean().refreshRootObj(WorkSet.class);
        }

        return retResult;
    }

    private Object multipleExecute(AdmObject admParentObj, AdmObjectList admObjList, AdmUidObject relType, boolean remove,
            boolean do_pend) throws DimBaseCmdException, AdmObjectException, AdmException {
        AdmObject admObj = (AdmObject) admObjList.get(0);

        String retResult = null;
        boolean refreshWorkSet = false;
        StringBuffer sb = null;
        TempFileOutputStream ts = null;

        if (admParentObj instanceof WorkSet) {
            if (admObj instanceof Branch) {
                Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admParentObj);
                cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Branch.class);
                List existingBranches = AdmHelperCmd.getObjects((List) cmd.execute());
                if (existingBranches == null) {
                    existingBranches = new ArrayList(0);
                }

                boolean found = false;
                List newBranches = null;
                if (remove) {
                    newBranches = new ArrayList();
                    for (int i = 0; i < existingBranches.size(); i++) {
                        AdmObject existingObj = (AdmObject) existingBranches.get(i);
                        found = false;
                        for (int j = 0; j < admObjList.size() && !found; j++) {
                            AdmObject listObj = (AdmObject) admObjList.get(j);
                            if (existingObj.getAdmSpec().getSpec().equals(listObj.getAdmSpec().getSpec())) {
                                found = true;
                            }
                        }
                        if (!found) {
                            newBranches.add(existingBranches.get(i));
                        }
                    }
                } else {
                    newBranches = new ArrayList(existingBranches);
                    for (int i = 0; i < admObjList.size(); i++) {
                        AdmObject listObj = (AdmObject) admObjList.get(i);
                        found = false;
                        for (int j = 0; j < existingBranches.size() && !found; j++) {
                            AdmObject existingObj = (AdmObject) existingBranches.get(j);
                            if (existingObj.getAdmSpec().getSpec().equals(listObj.getAdmSpec().getSpec())) {
                                found = true;
                            }
                        }
                        if (!found) {
                            newBranches.add(admObjList.get(i));
                        }
                    }
                }

                sb = new StringBuffer();
                sb.append("SWS ");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));
                sb.append(" /VALID_BRANCHES=(");
                if (newBranches.size() == 0) {
                    sb.append(".");
                } else {
                    for (int i = 0; i < newBranches.size(); i++) {
                        if (i > 0) {
                            sb.append(", ");
                        }
                        sb.append(Encoding.escapeDMCLI(((AdmObject) newBranches.get(i)).getAdmSpec().getSpec()));
                    }
                }
                sb.append(")");
            } else if (admObj instanceof Item) /* AIWS/RIWS with multiple items */
            {
                StringBuffer specs = new StringBuffer();
                for (int i = 0; i < admObjList.size(); i++) {
                    specs.append(Encoding.escapeDMCLI(((Item) admObjList.get(i)).getAdmSpec().getSpec()) + "\n");
                }

                try {
                    ts = new TempFileOutputStream();
                    ts.writeString(specs.toString());
                } catch (IOException ioException) {
                    throw new AdmException(ioException);
                }

                sb = new StringBuffer();
                sb.append(remove ? "RIWS " : "AIWS ");
                sb.append("/USER_ITEMLIST=" + Encoding.escapeDMCLI(ts.getAbsolutePath()));
                sb.append(" /WORKSET=");
                sb.append(Encoding.escapeDMCLI(admParentObj.getAdmSpec().getSpec()));

                String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
                if ((chdocs != null) && (chdocs.length() > 0)) {
                    sb.append(" /CHANGE_DOC_IDS=(" + chdocs + ")");
                }

                String baseline = (String) getAttrValue(CmdArguments.BASELINE);
                if (baseline != null && baseline.length() > 0) {
                    sb.append(" /BASELINE=");
                    sb.append(Encoding.escapeDMCLI(CmdUtils.relPathForCmd(baseline)));
                }

                ProgressListener progress = null;
                try {
                    progress = (ProgressListener) getAttrValue(CmdArguments.PROGRESS);
                    CancelMonitor cancelMonitor = (CancelMonitor) getAttrValue(CmdArguments.CANCEL_MONITOR);
                    if (progress != null) {
                        // set the listener
                        _cmdStr = "SET PROGRESS ON";
                        executeRpc();
                    }
                    // now run the real command
                    _cmdStr = sb.toString();
                    retResult = executeRpc(progress, cancelMonitor);

                    if (ts != null) {
                        ts.close();
                    }
                } catch (Exception e) {
                    throw new AdmException(e);
                } finally {
                    // turn progress off
                    if (progress != null) {
                        _cmdStr = "SET PROGRESS OFF";
                        executeRpc();
                    }
                }

                if (refreshWorkSet) {
                    DimSystem.getSystem().getSessionBean().refreshRootObj(WorkSet.class);
                }

                return retResult;
            }
        }

        // some commands have already been executed:
        if (retResult != null) {
            return retResult;
        }

        if (sb == null) {
            return null;
        }

        _cmdStr = sb.toString();
        retResult = executeRpc();
        if (refreshWorkSet) {
            DimSystem.getSystem().getSessionBean().refreshRootObj(WorkSet.class);
        }

        return retResult;
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObjectList admObjList = (AdmObjectList) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        AdmUidObject relType = (AdmUidObject) getAttrValue(CmdArguments.ADM_REL_TYPE);
        boolean remove = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();
        boolean do_pend = ((Boolean) getAttrValue(CmdArguments.PENDING)).booleanValue();

        if (admObj == null && admObjList == null) {
            throw new DimBaseCmdException("Must specify an object or a list of objects");
        }

        if (admObj != null && admObjList != null) {
            throw new DimBaseCmdException("Cannot specify an object and a list of objects");
        }

        // implement assignment/deassignment of data format(s) to/from item/chdoc types
        if (admParentObj instanceof Type) {
            if (admObj != null && admObj instanceof Format) {
                Class parentClass = (Class) admParentObj.getAttrValue(AdmAttrNames.PARENT_CLASS);
                if (Item.class.equals(parentClass)) {
                    AdmObjectList formats = new AdmObjectListImpl();
                    formats.add(admObj);
                    return internalExecuteRelateTypeToFormats(admParentObj, formats, remove);
                } else if (ChangeDocument.class.equals(parentClass)) {
                    String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);
                    if (remove) {
                        admObj = null;
                    }
                    return internalExecuteRelateChDocTypeToFormat(admParentObj, admObj, extension);
                } else {
                    throw new DimBaseCmdException("Cannot assign a data format to an unsupported object type");
                }
            }
            if (admObjList != null && admObjList.size() > 0) {
                Object obj = admObjList.get(0);
                if (obj != null && obj instanceof Format) {
                    Class parentClass = (Class) admParentObj.getAttrValue(AdmAttrNames.PARENT_CLASS);
                    if (Item.class.equals(parentClass)) {
                        return internalExecuteRelateTypeToFormats(admParentObj, admObjList, remove);
                    } else if (ChangeDocument.class.equals(parentClass)) {
                        String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);
                        AdmObject formatObj = (AdmObject) admObjList.get(0);
                        if (remove) {
                            formatObj = null;
                        }
                        return internalExecuteRelateChDocTypeToFormat(admParentObj, formatObj, extension);
                    } else {
                        throw new DimBaseCmdException("Cannot assign a data format to an unsupported object type");
                    }
                }
            }
        }

        if (admObjList != null) {
            if (admObjList.size() == 0) {
                throw new DimBaseCmdException("Must specify at least one object");
            }

            Object retObjects = multipleExecute(admParentObj, admObjList, relType, remove, do_pend);
            if (retObjects == null) {
                setCanCancel(true);
                int status = fireExecutionEvent(this, this, null, AdmCmdEvents.PRE);
                if (canCancel() && (status == CmdExecutionListener.ABORT || status == CmdExecutionListener.CANCEL)) {
                    return null;
                }

                retObjects = new ArrayList();
                status = fireExecutionEvent(this, this, new Long(admObjList.size()), AdmCmdEvents.PROGRESS_SIZE);
                if (canCancel() && (status == CmdExecutionListener.ABORT || status == CmdExecutionListener.CANCEL)) {
                    return null;
                }

                Object result = null;
                for (int i = 0; i < admObjList.size(); i++) {
                    status = fireExecutionEvent(this, this, null, AdmCmdEvents.PRE);
                    if (canCancel() && (status == CmdExecutionListener.ABORT || status == CmdExecutionListener.CANCEL)) {
                        return null;
                    }

                    result = internalExecute(admParentObj, (AdmObject) admObjList.get(i), relType, remove, do_pend);
                    ((List) retObjects).add(result);

                    status = fireExecutionEvent(this, this, result, AdmCmdEvents.POST);
                    if (canCancel() && (status == CmdExecutionListener.ABORT || status == CmdExecutionListener.CANCEL)) {
                        return null;
                    }

                    status = fireExecutionEvent(this, this, new Long(i), AdmCmdEvents.PROGRESS);
                    if (canCancel() && (status == CmdExecutionListener.ABORT || status == CmdExecutionListener.CANCEL)) {
                        return null;
                    }
                }

                status = fireExecutionEvent(this, this, retObjects, AdmCmdEvents.POST);
                if (canCancel() && (status == CmdExecutionListener.ABORT || status == CmdExecutionListener.CANCEL)) {
                    return null;
                }
            }
            return retObjects;
        }
        return internalExecute(admParentObj, admObj, relType, remove, do_pend);
    }

    private Object internalExecuteRelateTypeToFormats(AdmObject admParentObj, List admObjList, boolean remove)
            throws DimBaseCmdException, AdmObjectException, AdmException {
        String productName = (String) admParentObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String typeName = (String) admParentObj.getAttrValue(AdmAttrNames.ID);

        StringBuffer sb = new StringBuffer();

        sb.append("ADF ");
        sb.append(Encoding.escapeDMCLI(productName));
        sb.append(" /ITEM_TYPE=");
        sb.append(Encoding.escapeDMCLI(typeName));

        Collection formats = admObjList;
        if (remove) {
            Set existingFormats = getAssignedFormatsSet(productName, typeName);
            if (existingFormats != null) {
                if (formats != null && formats.size() > 0) {
                    for (Iterator it = formats.iterator(); it.hasNext();) {
                        AdmObject admObj = (AdmObject) it.next();
                        String formatId = (String) admObj.getAttrValue(AdmAttrNames.ID);
                        existingFormats.remove(formatId);
                    }
                }
            }
            formats = existingFormats;
        } else {
            Set existingFormats = getAssignedFormatsSet(productName, typeName);
            if (existingFormats == null) {
                existingFormats = new HashSet();
            }
            if (formats != null && formats.size() > 0) {
                for (Iterator it = formats.iterator(); it.hasNext();) {
                    AdmObject admObj = (AdmObject) it.next();
                    String formatId = (String) admObj.getAttrValue(AdmAttrNames.ID);
                    existingFormats.add(formatId);
                }
            }
            formats = existingFormats;
        }

        if (formats == null || formats.size() == 0) {
            sb.append(" /FORMAT_LIST=.");
        } else {
            sb.append(" /FORMAT_LIST=(");
            boolean addComma = false;
            for (Iterator it = formats.iterator(); it.hasNext();) {
                if (addComma) {
                    sb.append(',');
                }
                Object obj = it.next();
                if (obj instanceof AdmObject) {
                    AdmObject format = (AdmObject) obj;
                    String formatId = (String) format.getAttrValue(AdmAttrNames.ID);
                    sb.append(Encoding.escapeDMCLI(formatId));
                } else if (obj instanceof String) {
                    String formatId = (String) obj;
                    sb.append(Encoding.escapeDMCLI(formatId));
                }
                addComma = true;
            }
            sb.append(')');
        }

        _cmdStr = sb.toString();
        return executeRpc();
    }

    private Object internalExecuteRelateChDocTypeToFormat(AdmObject admParentObj, AdmObject formatObj, String extension)
            throws DimBaseCmdException, AdmObjectException, AdmException {
        String productName = (String) admParentObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String typeName = (String) admParentObj.getAttrValue(AdmAttrNames.ID);

        StringBuffer sb = new StringBuffer();

        sb.append("ACF ");
        sb.append(Encoding.escapeDMCLI(productName));
        sb.append(" /TYPE=");
        sb.append(Encoding.escapeDMCLI(typeName));

        if (formatObj == null) {
            sb.append(" /FORMAT=.");
        } else {
            String formatId = (String) formatObj.getAttrValue(AdmAttrNames.ID);
            sb.append(" /FORMAT=");
            sb.append(Encoding.escapeDMCLI(formatId));
        }

        if (extension != null && extension.length() > 0) {
            sb.append(" /EXTENSION=");
            sb.append(Encoding.escapeDMCLI(extension));
        }

        _cmdStr = sb.toString();
        return executeRpc();
    }

    private Set getAssignedFormatsSet(String productName, String typeName) throws DimBaseCmdException, AdmObjectException,
            AdmException {
        // get a list of assigned format's AdmBaseIds
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, DimSystem.getSystem().getSessionBean().getCurRootObj(BaseDatabase.class));
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Format.class);

        Filter filter = new FilterImpl();
        filter.criteria().add(
                new FilterCriterion(CmdArguments.ADM_SCOPE_OBJECT, AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(productName
                        + ':' + typeName + "-" + Item.class.getName(), Type.class))));
        cmd.setAttrValue(CmdArguments.FILTER, filter);

        List formats = (List) cmd.execute();
        if (formats == null || formats.size() == 0) {
            return null;
        }

        // get format ID's
        List attrNames = new ArrayList(1);
        attrNames.add(AdmAttrNames.ID);

        cmd = AdmCmd.getCmd(Creatable.GET_OBJECTS, Format.class);
        cmd.setAttrValue(CmdArguments.ADM_BASE_IDS, formats);
        cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        formats = (List) cmd.execute();

        if (formats == null || formats.size() == 0) {
            return null;
        }

        // convert the list of format objects into a Set of format Ids
        HashSet formatSet = new HashSet();
        for (Iterator it = formats.iterator(); it.hasNext();) {
            AdmObject admObj = (AdmObject) it.next();
            String formatId = (String) admObj.getAttrValue(AdmAttrNames.ID);
            formatSet.add(formatId);
        }
        return formatSet;
    }
}

package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.List;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Calls the Builder get-dependencies RPC.
 */
public class RPCGetSystemAttributeDefinitionsCmd extends RPCCmd {
    private static int[] EMPTY_INT_ARRAY = new int[0];

    public RPCGetSystemAttributeDefinitionsCmd() throws AdmObjectException, AttrException {
        setAlias("GetSystemAttributeDefinitions");
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_CLASS, true, Integer.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {

        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(AdmAttrNames.PARENT_CLASS)) {
            if (attrValue != null && attrValue instanceof Integer) {
                int objClass = ((Integer) attrValue).intValue();
                if (objClass != Constants.CHDOC_CLASS && objClass != Constants.ITEM_CLASS && objClass != Constants.BASELINE_CLASS
                        && objClass != Constants.WORKSET_CLASS) {
                    throw new AttrException("RPCGetSystemAttrDefs class type is not defined!", attrDef, attrValue);
                }
            } else {
                throw new AttrException("RPCGetSystemAttrDefs class type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException {
        List sysAttrDefs = null;
        try {
            int objClass = ((Integer) getAttrValue(AdmAttrNames.PARENT_CLASS)).intValue();
            int locale = 0;
            int language = 0;
            int charSet = 0;
            sysAttrDefs = getSession().getConnection().rpcGetSystemAttrDefs(objClass, locale, language, charSet);
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return sysAttrDefs;
    }
}

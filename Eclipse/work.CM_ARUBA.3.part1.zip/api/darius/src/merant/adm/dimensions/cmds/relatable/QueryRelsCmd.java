/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2002 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.serena.dmnet.RPC;
import com.serena.dmnet.drs.DRSClientQueryRelsRecursiveItems;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Attachment;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.NetConfig;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.SecurityZone;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.core.AdmUidTwin;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.QueryConstants;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.StreamUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all objects related to the primary object.
 * <p>
 * Where the natural direction of the relationship is not clear, use PARENT_RELATIVE for direction. <b>Mandatory Arguments:</b>
 * <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PARENT_RELATIVE {Boolean}</dt><dd>If true, enforces the return of parent relations</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 *  <dt>RELTYPE_IS_PEDIGREE {Boolean}<dt><dd>If true, returns pedigree object relationships</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Floz
 */
public class QueryRelsCmd extends DBIOCmd {
    public QueryRelsCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_RELS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_SEC_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARENT_RELATIVE, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATIONSHIPS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_DEFAULT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_PEDIGREE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef("COUNT", false, Boolean.FALSE, Boolean.class)); // Not for public use.
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        init();

        FilterImpl filter = (FilterImpl) getAttrValue(CmdArguments.FILTER);
        if (filter != null) {
            filter = (FilterImpl) filter.clone();
        }

        boolean relationships = ((Boolean) getAttrValue(CmdArguments.RELATIONSHIPS)).booleanValue();
        boolean isDefault = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT)).booleanValue();
        boolean count = ((Boolean) getAttrValue("COUNT")).booleanValue();
        boolean isSecClassUidObj = AdmUidObject.class.isAssignableFrom(_admSecClass);
        boolean isPedigree = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE)).booleanValue();

        // If pedigree then defer to _internal_pedigree
        if (isPedigree) {
            return internalPedigree(_admObj, _admSecClass, _queryChildren.booleanValue(), filter, relationships, count,
                    isSecClassUidObj);
        }

        // Otherwise it's SuperQuery time
        Object o = internalExecute(_admObj, _admSecClass, _queryChildren.booleanValue(), filter, relationships, isDefault, count,
                isSecClassUidObj);
        
        if (filter != null) {
            // Pass back any maximum row count.
            FilterImpl original_filter = (FilterImpl)getAttrValue(CmdArguments.FILTER);
            if (original_filter != null) {
                original_filter.setMaximumFound(filter.getMaximumFound());
            }
        }
        
        return o;
    }

    private AdmObject _admObj = null;
    private Class _admSecClass = null;
    private Boolean _queryChildren = null;

    private void init() throws AdmException {
        if (_admObj != null) {
            return;
        }

        _admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Class admSecClass = (Class) getAttrValue(CmdArguments.ADM_SEC_CLASS);
        Boolean queryParent = (Boolean) getAttrValue(CmdArguments.PARENT_RELATIVE);

        boolean queryChildren = true;
        if (queryParent != null) {
            queryChildren = !queryParent.booleanValue();
        }

        _admSecClass = admSecClass;
        _queryChildren = (queryChildren ? Boolean.TRUE : Boolean.FALSE);
    }

    private List internalPedigree(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean count, boolean isSecClassUidObj) throws DBIOException, DimBaseException, AdmException {
        Cmd cmd = AdmCmd.getCmd("_internal_pedigree", admObj, admSecClass);
        cmd.setAttrValue("QUERY_CHILDREN", (queryChildren ? Boolean.TRUE : Boolean.FALSE));
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        List admObjs = null;
        Object o = cmd.execute();
        if(o != null) {
            admObjs = AdmHelperCmd.getObjects((List) o);
        }
        if (admObjs == null) {
            return null;
        }

        List ret = new ArrayList();
        if (count) {
            for (int i = 0; i < admObjs.size(); i++) {
                ret.add(Boolean.TRUE);
            }
        } else {
            AdmObject relatedObj = null;
            for (int i = 0; i < admObjs.size(); i++) {
                relatedObj = (AdmObject) admObjs.get(i);
                if (!isSecClassUidObj) {
                    addRelation(ret, relationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(relatedObj.getAdmSpec().getSpec(), admSecClass));
                } else if (!relationships) {
                    addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(
                            ((AdmUidObject) relatedObj).getAdmUid().getUid(), admSecClass, getBaseUid(),
                            AdmHelperCmd.newAdmBaseId(relatedObj.getAdmSpec().getSpec(), admSecClass, null, null)));
                } else {
                    addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(
                            ((AdmUidObject) relatedObj).getAdmUid().getUid(), admSecClass, getBaseUid(),
                            AdmHelperCmd.newAdmBaseId(relatedObj.getAdmSpec().getSpec(), admSecClass, null, null)),
                            AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_PEDIGREE, RelationshipType.class, null,
                                    AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_ID_PEDIGREE, RelationshipType.class, null, null)));
                }
            }
        }

        return ret;
    }

    protected static void staticExecute(List retBaseIds, AdmObject admObj, Class admSecClass, AdmBaseId baseId,
            boolean queryChildren, boolean recursive, FilterImpl filter, boolean relationships, boolean isDefault, boolean count,
            boolean isSecClassUidObj) throws DBIOException, DimBaseException, AdmException {
        int[] relFlags = CmdUtils.processFilterRelationships(filter);

        // All this extra stuff is currently only relevant for Baseline -> Baseline or
        // Workset -> Baseline or Workset -> Workset (or the reverse)
        boolean isWBStructure = false;
        if (queryChildren) {
            isWBStructure = ((admObj instanceof Baseline && Baseline.class.equals(admSecClass))
                    || (admObj instanceof WorkSet && Baseline.class.equals(admSecClass)) || (admObj instanceof WorkSet && WorkSet.class.equals(admSecClass)));
        } else /* !queryChildren */{
            isWBStructure = ((admObj instanceof Baseline && Baseline.class.equals(admSecClass))
                    || (admObj instanceof Baseline && WorkSet.class.equals(admSecClass)) || (admObj instanceof WorkSet && WorkSet.class.equals(admSecClass)));
        }

        if (isWBStructure && relFlags.length > 0) {
            // If usage or info relationship types have been set on the filter, to enable
            // derived relationships to be picked up as well, the caller must have specified FILTER_DERVIED on the filter
            // A filter with CmdArguments.FILTER_INFO, CmdArguments.FILTER_USAGE and CmdArguments.FILTER_DERIVED
            // is functionaly equivalent to a filter with none of those settings
            if (filter.hasAttr(CmdArguments.FILTER_DERIVED)) {
                CmdUtils.removeFromFilter(filter, CmdArguments.FILTER_DERIVED);
                queryRelations(0, retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive, filter, relationships,
                        isDefault, count, isSecClassUidObj);
            }

            // query for any of the new usage or info relationship types that have been set on the filter
            for (int i = 0; i < relFlags.length; i++) {
                queryRelations(relFlags[i], retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive, filter,
                        relationships, isDefault, count, isSecClassUidObj);
            }

        } else if (isWBStructure && filter != null && filter.hasAttr(CmdArguments.FILTER_DERIVED)) {
            // only derived relationships were requested
            CmdUtils.removeFromFilter(filter, CmdArguments.FILTER_DERIVED);
            queryRelations(0, retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive, filter, relationships, isDefault,
                    count, isSecClassUidObj);
        } else if (admObj instanceof WorkSet && WorkSet.class.equals(admSecClass) && filter != null
                && filter.hasAttr(CmdArguments.FILTER_CONTRIBUTER) && StreamUtils.isStream(admObj.getAdmSpec().getSpec())) {
            // query for 'Contributer' relationship.
            queryRelations(0, retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive, filter, relationships, isDefault,
                    count, isSecClassUidObj);
        } else {

            // DEF107131: For Directory-Item displays scoped by Baseline the FILTER_I_LATEST filter criterion dramatically slows
            // down the query.
            // Therefore, for Release baselines, a solution is to remove the FILTER_I_LATEST filter criterion from the filter.
            // As Release baselines only contain one revision for any given item this shouldn't affect results returned.
            // For Design and Archive baselines we also need to remove the filter, but we also need to fudge the results returned to
            // weed out duplicate revisions.
            // NB: kludgeBaselineItemDisplay() assumes that AdmBaseIds are returned rather than Relationship objects. Therefore if
            // the 'relationships'
            // flag is set the code will skip kludgeBaselineItemDisplay() and revert to the 'old' (DM10.1.0 GA) path of execution.
            boolean kludgeItemDisplay = false;
            if (!isWBStructure && baseId != null && baseId.getObjType().equals(Baseline.class)
                    && (admSecClass.equals(ItemFile.class) || admSecClass.equals(Item.class)) && !relationships && filter != null
                    && filter.hasAttr(CmdArguments.FILTER_I_LATEST)) {
                CmdUtils.removeFromFilter(filter, CmdArguments.FILTER_I_LATEST);
                Object obj = AdmCmd.getAttributeValue(AdmCmd.getObject(baseId), AdmAttrNames.BLINE_MODE);
                if (obj == null
                        || (obj != null && obj instanceof AdmObject && !((AdmObject) obj).getId().equals(
                                Constants.BLINEMODE_ID_RELEASE))) {
                    kludgeItemDisplay = true;
                }
            }
            // if no relationship filter settings were specified or if the filter was null, query all kinds of relationship
            // query derived rels
            queryRelations(0, retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive, filter, relationships, isDefault,
                    count, isSecClassUidObj);
            if (isWBStructure) {
            	// Each subsequent query overwrites existing total value,
            	// so need to accumulate it before each query to have combined total.
                int maximumFound = 0;
                boolean maximumNeeded = filter != null && filter.getMaximumNeeded();

                if (!(admObj instanceof Baseline && admSecClass.equals(Baseline.class))) {

                    // no longer needs to query USAGE and INFO relationship types for BLN to BLN rels, because the default sql in
                    // admschema.xml can query all the types in one go.

                    if (maximumNeeded) {
                        maximumFound += filter.getMaximumFound();
                    }
                    // query usage rels
                    queryRelations(QueryConstants.USAGE, retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive, filter,
                            relationships, isDefault, count, isSecClassUidObj);

                    // query info rels
                    // Aug 06, YCai: checked AdmSchema.xml, there is no "INFO" flag for
                    // baseline-baseline and workset-workset relationships.
                    if (!(admObj instanceof WorkSet && WorkSet.class.equals(admSecClass))) {
                        if (maximumNeeded) {
                            maximumFound += filter.getMaximumFound();
                        }
                        queryRelations(QueryConstants.INFO, retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive,
                                filter, relationships, isDefault, count, isSecClassUidObj);
                    }
                } else if (retBaseIds.size() == 0) {
                    // There is a problem with querying bln-bln rels with superquery - if the bln_rels table is empty then the query
                    // will ALWAYS return zero results. Therefore we should double-check to see if there are any 'Based On' bln
                    // rels.
                    if (filter == null) {
                        filter = new FilterImpl();
                    }
                    filter.criteria().add(new FilterCriterion(Constants.RELTYPE_ID_BASED_ON));
                    if (maximumNeeded) {
                        maximumFound += filter.getMaximumFound();
                    }
                    queryRelations(0, retBaseIds, admObj, admSecClass, baseId, queryChildren, recursive, filter, relationships,
                            isDefault, count, isSecClassUidObj);
                }
                if (maximumNeeded) {
                	filter.setMaximumFound(filter.getMaximumFound() + maximumFound);
                }
            }
            if (kludgeItemDisplay && retBaseIds != null && retBaseIds.size() > 1) {
                retBaseIds = kludgeBaselineItemDisplay(retBaseIds);
            }
        }
    }

    protected static void queryRelations(int relFlag, List retBaseIds, AdmObject admObj, Class admSecClass, AdmBaseId baseId,
            boolean queryChildren, boolean recursive, FilterImpl filter, boolean relationships, boolean isDefault, boolean count,
            boolean isSecClassUidObj) throws DBIOException, DimBaseException, AdmException {

        /*
         * if has rel flags
         * for each flag
         * results += query(flags)
         * end for
         * else
         * results = query(flags)
         * end if
         * return results
         */

        SuperQuery query = new SuperQuery();
        query.setScope(baseId);
        query.setObjectType(admSecClass);

        if (isSecClassUidObj) {
            // Every time the uid is the same as the admspec
            // make sure that the uid is included on the query
            query.addSelect(AdmAttrNames.ADM_UID, QueryConstants.ALWAYS_INCLUDE);
        }

        if ((!count) || (!isSecClassUidObj)) {
            // Every time the uid is the same as the admspec
            // make sure that the admspec is included on the query
            query.addSelect(AdmAttrNames.ADM_SPEC, QueryConstants.ALWAYS_INCLUDE);
        }

        // fix for PVCS_EC_6871 - only use the isLatest column for main item displays
        // ie for folder view (admObj==DimDirectory)
        // for in-box (admObj==User)
        // for catalog (admObj==WorkSet)
        // for part view (admObj==Part)
        boolean useIsLatest = false;
        if ((admObj instanceof WorkSet || admObj instanceof DimDirectory || admObj instanceof User || admObj instanceof Part)
                && (admSecClass.equals(Item.class) || admSecClass.equals(ItemFile.class))) {
            useIsLatest = true;
        }

        int localFlags = CmdUtils.processFilter(query, filter, count, relationships, useIsLatest, false);

        if (recursive) {
            localFlags = localFlags | QueryConstants.DEEP;
        }

        localFlags |= relFlag;

        // check derived explicitly here to free up QueryConstant.DERIVED bit flag.
        if (filter != null) {
            if (filter.hasAttr(CmdArguments.FILTER_DERIVED)) {
                query.addRel(admObj, localFlags, QueryConstants.DERIVED);
            } else if (filter.hasAttr(Constants.RELTYPE_ID_BASED_ON)) {
                query.addRel(admObj, localFlags, Constants.RELTYPE_ID_BASED_ON);
            } else if (filter.hasAttr(Constants.RELTYPE_ID_TOPIC)) {
                query.addRel(admObj, localFlags, Constants.RELTYPE_ID_TOPIC);
            } else if (filter.hasAttr(CmdArguments.FILTER_CONTRIBUTER)) {
                query.addRel(admObj, localFlags, Constants.RELTYPE_ID_CONTRIBUTER);
            } else {
                query.addRel(admObj, localFlags);
            }
        } else {
            query.addRel(admObj, localFlags);
        }

        // add extra out args
        if (isSecClassUidObj && relationships) {
            query.addOutputLong();
            query.addOutputString();
        }
        // Lockheed SecurityZone - only return objects from products that
        // the user has a role assignment on.
        if (!applySecurityZone(admSecClass, query)) {
            // we should not return anything if applySecurityZone
            // returns false.
            return;
        }

        if (filter != null) {
            filter.setMaximumFound(-1);
        }
        query.readStart();
        if (count) {
            while (query.read()) {
                retBaseIds.add(Boolean.TRUE);
            }
        } else {
            AdmBaseId newBaseId = null;
            AdmBaseId newRelBaseId = null;
            if (filter != null && filter.getMaximumNeeded()) {
                filter.setMaximumFound(query.getMaxRows());
            }
            while (query.read()) {
                if (!isSecClassUidObj) {
                    newRelBaseId = null;
                    newBaseId = AdmHelperCmd.newAdmBaseId(query.getString(1), admSecClass);
                } else if (!relationships) {
                    newRelBaseId = null;
                    newBaseId = AdmHelperCmd.newAdmBaseId(query.getLong(1), admSecClass, baseId,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), admSecClass, null, null));
                } else {
                    newBaseId = AdmHelperCmd.newAdmBaseId(query.getLong(1), admSecClass, baseId,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), admSecClass, null, null));
                    newRelBaseId = AdmHelperCmd.newAdmBaseId(query.getLong(3), RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(4), RelationshipType.class, null, null));
                }

                if ((relFlag & QueryConstants.CHILD) == 0) {
                    if (newRelBaseId != null) {
                        addRelation(retBaseIds, relationships, admObj.getAdmBaseId(), newBaseId, newRelBaseId);
                    } else {
                        addRelation(retBaseIds, relationships, admObj.getAdmBaseId(), newBaseId);
                    }
                } else {
                    // Need to swap the inputs to addRelation as the queried object is the parent
                    if (newRelBaseId != null) {
                        addRelation(retBaseIds, relationships, newBaseId, admObj.getAdmBaseId(), newRelBaseId);
                    } else {
                        addRelation(retBaseIds, relationships, newBaseId, admObj.getAdmBaseId());
                    }
                }
            }
        }
    }

    /**
     * Method to recursively query items in a directory structure. The method "staticExecute" could cause
     * problems as it generates a query that may work with DB2 or SQL Server.
     */
    protected static void staticExecuteRecursiveItemsForDir(List retBaseIds, AdmObject admObj, Class admSecClass, AdmBaseId baseId)
            throws DBIOException, DimBaseException, AdmException {
        Class scopeType = null;
        AdmBaseId scope = admObj.getAdmBaseId().getScope();
        if (scope != null) {
            scopeType = scope.getObjType();
        }
        AdmBaseId admBaseId = null;
        DRSClientQueryRelsRecursiveItems drsClientQueryRelsRecursiveItems = new DRSClientQueryRelsRecursiveItems(
                DRSUtils.getLCNetClntObject());
        drsClientQueryRelsRecursiveItems.setWsetUid(((AdmUidObject) AdmHelperCmd.getObject(baseId)).getAdmUid().getUid());
        drsClientQueryRelsRecursiveItems.setDirUid(((AdmUidObject) admObj).getAdmUid().getUid());
        if (scopeType != null && scopeType.equals(Baseline.class)) {
            drsClientQueryRelsRecursiveItems.setIsBaseline(1);
        } else {
            drsClientQueryRelsRecursiveItems.setIsBaseline(0);
        }

        DRSQuery drsQuery = new DRSQuery(drsClientQueryRelsRecursiveItems);
        DRSOutputDataExtractor drsOutputDataExtractor = drsQuery.execute();

        if (drsOutputDataExtractor.hasRPCExecutionFailed()) {
            throw new DRSException("Error during call of DRS function " + DRSClientQueryRelsRecursiveItems.dataRequestId
                    + " via RPC(" + RPC.RPC_DATA_REQUEST + ")");
        } else if (!drsOutputDataExtractor.isResultEmpty()) {
            int[] itemUids = drsOutputDataExtractor.getIntValues(DRSParams.OBJ_UIDS);
            for (int i = 0; i < itemUids.length; i++) {
                admBaseId = AdmHelperCmd.newAdmBaseId(itemUids[i], admSecClass, baseId);
                retBaseIds.add(admBaseId);
            }
        }
    }

    /**
     * Override to manually provide query for relationships rather than using SuperQuery.
     * <p>
     * Note: super.internalExecute(...) should NOT be called as overrides are only needed to replace SuperQuery, not to add to it.
     * @param admObj
     *            Source object for the query
     * @param admSecClass
     *            Dimensions secondary object class
     * @param queryChildren
     *            Indicates direction of relationship query
     * @param filter
     *            Filter of Attr's containing filter information
     * @param relationships
     *            If true, command returns Relationship's rather than AdmBaseId's
     * @param isDefault
     *            If true, returns default object preferences
     * @param count
     *            Not for general use, if true only returns the number of relationships
     * @param isSecClassUidObj
     *            If true, admSecClass represents an AdmUidObject class
     * @return A List implementation containing AdmBaseId's or Relationship's
     */
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new ArrayList();
        staticExecute(ret, admObj, admSecClass, getBaseUid(), queryChildren, false, filter, relationships, isDefault, count,
                isSecClassUidObj);

        return ret;
    }

    private AdmUid m_baseUid = null;

    protected static AdmUid staticBaseUid(AdmObject admObj, Class admSecClass, WorkSet workSet) throws DBIOException,
            DimBaseException, AdmException {
        // OK some hard coded rules...
        // First the times where we return null...
        if (admObj instanceof BaseDatabase) {
            return null;
        } else if ((admObj instanceof ChangeDocument) || (admObj instanceof Item)) {
            if ((!admSecClass.equals(Attachment.class)) && (!admSecClass.equals(Item.class))
                    && (!admSecClass.equals(ItemFile.class))) {
                return null;
            }
        } else if (admObj instanceof NetConfig) {
            return null;
        } else if (admObj instanceof Part) {
            if ((admSecClass.equals(Baseline.class)) || (admSecClass.equals(ChangeDocument.class))) {
                return null;
            }
        } else if (admObj instanceof User) {
            if ((!admSecClass.equals(Item.class)) && (!admSecClass.equals(ItemFile.class))) {
                return null;
            }
        }

        // Now where we return admObj.getAdmBaseId()...
        if (admObj instanceof Baseline) {
            return ((AdmUidObject) AdmHelperCmd.getObject(admObj.getAdmBaseId())).getAdmUid();
        } else if ((admObj instanceof ChangeDocument) || (admObj instanceof Item)) {
            if (admSecClass.equals(Attachment.class)) {
                return ((AdmUidObject) AdmHelperCmd.getObject(admObj.getAdmBaseId())).getAdmUid();
            }
        } else if (admObj instanceof WorkSet) {
            if ((admSecClass.equals(Item.class)) || (admSecClass.equals(ItemFile.class))) {
                return ((AdmUidObject) AdmHelperCmd.getObject(admObj.getAdmBaseId())).getAdmUid();
            }
        }

        // Finally do the original set of scoping rules...
        if (workSet != null) {
            return workSet.getAdmUid();
        }

        AdmUid baseUid = null;
        if (admObj.getAdmBaseId().getScope() != null) {
            baseUid = ((AdmUidObject) AdmHelperCmd.getObject(admObj.getAdmBaseId().getScope())).getAdmUid();
        } else {
            baseUid = ((WorkSet) DimSystem.getSystem().getSessionBean().getCurRootObj(WorkSet.class)).getAdmUid();
        }

        if (baseUid == null) {
            baseUid = (AdmUid) AdmHelperCmd.newAdmBaseId(Constants.GLOBAL_WSET_UID, WorkSet.class);
        }

        return baseUid;
    }

    /** @todo Remove hard coded rules by using a more generic algorithm */
    protected AdmUid getBaseUid() throws DBIOException, DimBaseException, AdmException {
        if (m_baseUid != null) {
            return m_baseUid;
        }

        init();
        m_baseUid = staticBaseUid(_admObj, _admSecClass, (WorkSet) getAttrValue(CmdArguments.WORKSET));
        return m_baseUid;
    }

    protected static AdmObject addRelation(List retBaseIds, boolean relationships, AdmBaseId parent, AdmBaseId child)
            throws DBIOException, DimBaseException, AdmException {
        return addRelation(retBaseIds, relationships, parent, child, (AdmObject) null);
    }

    protected static AdmObject addRelation(List retBaseIds, boolean relationships, AdmBaseId parent, AdmBaseId child,
            AdmBaseId relTypeId) throws DBIOException, DimBaseException, AdmException {
        Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECT, RelationshipType.class);
        cmd.setAttrValue(CmdArguments.ADM_BASE_ID, relTypeId);
        return addRelation(retBaseIds, relationships, parent, child, (AdmObject) cmd.execute());
    }

    protected static AdmObject addRelation(List retBaseIds, boolean relationships, AdmBaseId parent, AdmBaseId child,
            AdmObject relType) throws AdmException {
        AdmObject rel = null;
        if (relationships) {
            rel = new Relationship(parent, child);
            if (relType != null) {
                rel.setAttrValue(AdmAttrNames.REL_TYPE, relType);
            }

            retBaseIds.add(rel);
        } else {
            retBaseIds.add(child);
        }

        return rel;
    }

    private static boolean isClassRestrictedBySecurityZone(Class admSecClass) {
        return (admSecClass != null && (admSecClass.equals(ChangeDocument.class) || admSecClass.equals(Item.class)
                || admSecClass.equals(ItemFile.class) || admSecClass.equals(Baseline.class) || admSecClass.equals(WorkSet.class)
                || admSecClass.equals(Part.class) || admSecClass.equals(Release.class) || admSecClass.equals(Product.class)));
    }

    private static boolean isClassGenericAddedToSecurityZone(Class admSecClass) {
        return (admSecClass != null && (admSecClass.equals(WorkSet.class) || admSecClass.equals(Part.class) || admSecClass.equals(Product.class)));
    }

    /**
     * Modify the SuperQuery object so that it is restricted to just those
     * products in the current user's security zone
     * @return true if the SuperQuery was modified OK or it did not need to be
     *         modified; or false if the user's security zone is empty so the
     *         query should fail anyway.
     */
    private static boolean applySecurityZone(Class admSecClass, SuperQuery query) throws AdmException {
        boolean ret = true;
        if (isClassRestrictedBySecurityZone(admSecClass)) {
            SecurityZone sz = (SecurityZone) AdmCmd.getOrInitDefRootObj(SecurityZone.class);
            if (sz != null && sz.isEffective()) {
                boolean addGeneric = isClassGenericAddedToSecurityZone(admSecClass);
                if (sz.isEmpty() && !addGeneric) {
                    ret = false;
                } else {
                    List products = sz.getProducts();
                    if (addGeneric && !products.contains("$GENERIC")) {
                        products = new ArrayList(products);
                        products.add("$GENERIC");
                    }
                    query.addWhere(AdmAttrNames.PRODUCT_NAME, products, QueryConstants.EQUALS);
                }
            }
        }
        return ret;
    }

    // ** part of fix for DEF107131: This method is a substitute for the latest rev filter
    // ** for the item-folder display of Baselines. It checks for duplicate specs (minus revision)
    // ** and includes the one with the largest uid number. Not perfect I know, but a significant
    // ** performance improvement over the old code.
    private static List kludgeBaselineItemDisplay(List baseIds) {
        List tempList = new ArrayList(baseIds);
        Iterator iter = tempList.iterator();
        Map map = new HashMap();
        while (iter.hasNext()) {
            AdmUidTwin baseId = (AdmUidTwin) iter.next();
            String shortSpec = ((AdmSpec) baseId.getTwin()).getSpec();
            shortSpec = shortSpec.substring(0, shortSpec.lastIndexOf(';'));
            AdmUidTwin baseId2 = (AdmUidTwin) map.get(shortSpec);
            if (baseId2 != null) {
                long uid = baseId.getUid();
                long uid2 = baseId2.getUid();
                if (uid > uid2) {
                    map.put(shortSpec, baseId);
                    baseIds.remove(baseId2);
                } else {
                    baseIds.remove(baseId);
                }
            } else {
                map.put(shortSpec, baseId);
            }
        }
        return baseIds;
    }
}

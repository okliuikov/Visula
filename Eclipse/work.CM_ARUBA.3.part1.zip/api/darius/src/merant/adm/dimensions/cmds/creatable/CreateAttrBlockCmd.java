/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeBlock;
import merant.adm.dimensions.server.core.SpecialCharacters;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions AttributeBlock.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>TYPE{AdmObject}<dt><dd>Dimensions Type object for which the attribute block is to be created</dd>
 *  <dt>ID {String}<dt><dd>Identifier of the new attribute block</dd>
 *  <dt>ATTRBLOCK_PROMPT{String}<dt><dd>User prompt</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ATTRBLOCK_APPEND_ONLY{Boolean}<dt><dd>Whether the attribute block rows can only be appended or also updated, deleted, inserted. Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateAttrBlockCmd extends RPCExecCmd {
    public CreateAttrBlockCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE, true, Type.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRBLOCK_PROMPT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRBLOCK_APPEND_ONLY, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {
        validateAllAttrs();

        final String blockName = ValidationHelper.validateAttrBlockId((String) getAttrValue(AdmAttrNames.ID));
        final String prompt = ValidationHelper.validateAttrPrompt((String) getAttrValue(AdmAttrNames.ATTRBLOCK_PROMPT));

        final boolean isAppendOnly = ((Boolean) getAttrValue(AdmAttrNames.ATTRBLOCK_APPEND_ONLY)).booleanValue();

        AdmObject typeObj = (AdmObject) getAttrValue(AdmAttrNames.TYPE);

        List attrs = AdmHelperCmd.getAttributeValues(typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        final String productName = (String) attrs.get(0);
        final String typeName = (String) attrs.get(1);
        Class typeClass = (Class) attrs.get(2);
        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        if (!DoesExistHelper.typeExists(productName, typeName, typeFlag)) {
            throw new DimAlreadyExistsException("Error: Dimensions " + TypeUtils.getClassName(typeClass) + "Type " + productName
                    + ":" + typeName + " does not exist");
        }

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + blockName);

        if (StringUtils.containsSpecialChars(blockName, SpecialCharacters.INVALID_ATTR_BLOCK_CHARS)) {
            throw new DimInvalidAttributeException(
                    "Error: The block name must not contain one or more of the following disallowed characters: "
                            + SpecialCharacters.INVALID_ATTR_BLOCK_CHARS + " or a space character");
        }

        if (DoesExistHelper.attributeBlockExists(productName, blockName)) {
            throw new DimAlreadyExistsException("Error: block " + blockName + " already exists in product " + productName);
        }

        // Construct OBJATTR command to create multi field block attribute, for example:
        // OBJATTR /ASSIGN /TYPE=MM "MMATTRIBUTE" /OBJ_CLASS=REQUEST /PRODUCT="QLARIUS" /OBJ_TYPE="CR" /PROMPT="Multi Field"/NOAPPENDONLY
        {
            StringBuffer cmdBuf = new StringBuffer("OBJATTR /ASSIGN /TYPE=MM ");
            cmdBuf.append(Encoding.escapeDMCLI(blockName));
            cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(typeClass));
            cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));
            cmdBuf.append(" /OBJ_TYPE=").append(Encoding.escapeDMCLI(typeName));

            if (prompt != null && prompt.length() != 0)
                cmdBuf.append(" /PROMPT=").append(Encoding.escapeDMCLI(prompt));

            cmdBuf.append(isAppendOnly ? "/APPENDONLY" : "/NOAPPENDONLY");

            _cmdStr = cmdBuf.toString();
            AdmResult retResult = new AdmResult(executeRpc());
            AdmCmd.populateBaseIdFromAdmResult(this, retResult, AttributeBlock.class);
            return retResult;
        }
    }
}

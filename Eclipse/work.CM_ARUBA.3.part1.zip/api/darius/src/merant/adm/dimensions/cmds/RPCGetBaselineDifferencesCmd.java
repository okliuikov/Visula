/*
 * Copyright (C), 2012, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command return difference between two baselines. <b>Mandatory
 * Arguments:</b> <code><dl>
 *  <dt>BASELINE<dt><dd>Array of two baselines to compare</dd>
 * </dl></code> <b>Optional Arguments:</b> <code><dl>
 *  <dt>BASELINE_DIFF_SCOPE</dt><dd>Scope for baseline compare</dd>
 * </dl></code> <b>Returns:</b><code><dl>
 *  <dt>array Object[4] of arrays, that contain differences: file name,
 *  change type, item uid, design part</dd>
 * </dl></code>
 */
public class RPCGetBaselineDifferencesCmd extends RPCCmd {

    /**
     * Constructor defines the command definition and arguments.
     * 
     * @throws AttrException
     */
    public RPCGetBaselineDifferencesCmd() throws AttrException {
        super();
        setAlias("GetBaselineDifferences");
        AddArgument("cmd", "GetBaselineDifferences");
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, true, String[].class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE_DIFF_SCOPE, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.BASELINE)) {
            String[] baselines = (String[]) attrValue;
            if (baselines == null) {
                throw new AttrException("Error: Array of baselines is null", attrDef, attrValue);
            }
            if (baselines.length != 2) {
                throw new AttrException("Error: Array of baselines must have exactly two baselines", attrDef, attrValue);
            }
            for (int i = 0; i < baselines.length; i++) {
                if ((baselines[i] == null) || (baselines[i].length() == 0)) {
                    throw new AttrException("Error: Baseline spec empty or null", attrDef, attrValue);
                }
            }
        }
    }

    @Override
    public Object execute() throws AdmException {
        validateAllAttrs();
        try {
            String[] baselines = (String[]) getAttrValue(CmdArguments.BASELINE);
            String scope = (String) getAttrValue(CmdArguments.BASELINE_DIFF_SCOPE);
            Object[] differences = getSession().getConnection().rpcGetBaselineDifferences(baselines[0], baselines[1],
                    (scope != null ? scope : ""));
            return differences;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Group;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will assign or deassign users from a group.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * 	<dt>ID {String}<dt><dd>Identifier of the group.</dd>
 *  <dt>GROUP_USERS {List}<dt><dd>Users to assign or deassign from group.</dd>
 *  <dt>GROUP_ASSIGN_USERS {Boolean}<dt><dd>Flag to determine whether to
 *                                 assign or deassign users from a group.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>n/a<dt><dd>None.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 * 	<dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author Paul Smith
 */
public class AssignUsersToGroupCmd extends RPCExecCmd {

    public AssignUsersToGroupCmd() throws AttrException {
        super();
        setAlias(Assignable.ASSIGN_USERS_TO_GROUP);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.GROUP_USERS, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.GROUP_ASSIGN_USERS, true, Boolean.class));
    }

    /**
     * Overridden to validate that <code>ADM_OBJECT</code> is an instance of <code>Group</code>.
     * 
     * @param name
     *            the name of the attribute to validate.
     * @param attrDef
     *            the attribute definition to validate against.
     * @param attrValue
     *            the attribute value which needs to be validated.
     * @throws AttrException
     *             if the attribute cannot be validated.
     */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Group)) {
                throw new AttrException("AssignUsersToGroupCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    /**
     * Executes the AUGRP command-line.
     * 
     * @return <code>AdmResult</code> instance containing Dimensions server
     *         message and result code.
     */
    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject group = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List groupUsersList = (List) getAttrValue(AdmAttrNames.GROUP_USERS);
        Boolean assignUsers = (Boolean) getAttrValue(AdmAttrNames.GROUP_ASSIGN_USERS);

        StringBuffer sb = new StringBuffer();
        sb.append("AUGRP ");
        sb.append(Encoding.escapeSpec(group.getAdmSpec().getSpec()));
        sb.append(" /USERS=");

        if (groupUsersList != null && groupUsersList.size() > 0) {
            sb.append("(");
            String userName = "";
            for (int i = 0; i < groupUsersList.size(); i++) {
                userName = (String) groupUsersList.get(i);
                if (i > 0) {
                    sb.append(",");
                }
                sb.append(Encoding.escapeSpec(userName));
            }
            sb.append(")");
        } else {
            // Assign nobody to the group
            sb.append(Encoding.escapeSpec(""));
        }

        if (assignUsers.booleanValue()) {
            // We are assigning users
            sb.append(" /ADD");
        } else {
            // We are deassigning users
            sb.append(" /REMOVE");
        }
        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Group.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.StringTokenizer;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Get the role section names via Message Server
 */
public class RPCPcmsEvaluateAttrRules extends RPCCmd {
    public RPCPcmsEvaluateAttrRules() throws AdmObjectException, AttrException {
        super();
        setAlias("RPC EvaluateAttrRules");
        AddArgument("cmd", "PcmsEvaluateAttrRules");
        setAttrDef(new CmdArgDef("uidObject", false, AdmUidObject.class));
        setAttrDef(new CmdArgDef("typeObject", true, AdmUidObject.class));
        setAttrDef(new CmdArgDef("prodname", true, "", "", ""));
        setAttrDef(new CmdArgDef("typename", true, "", "", ""));
        setAttrDef(new CmdArgDef("admclass", true, "", "", ""));
        setAttrDef(new CmdArgDef("status", true, "", "", ""));
        setAttrDef(new CmdArgDef("nextstatus", true, "", "", ""));
        setAttrDef(new CmdArgDef("attrnums", true, "", "", ""));
        setAttrDef(new CmdArgDef("partuids", true, "", "", ""));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            AdmUidObject uidObject = (AdmUidObject) getAttrValue("uidObject");
            long uidObjectUid = uidObject == null ? 0 : uidObject.getAdmUid().getUid();

            String sattrnums = (String) getAttrValue("attrnums");

            StringTokenizer st = new StringTokenizer(sattrnums, " ");

            int attrnums[] = new int[st.countTokens()];
            for (int i = 0; st.hasMoreTokens(); i++) {
                attrnums[i] = Integer.parseInt(st.nextToken());
            }

            boolean attrRules[][] = getSession().getConnection().rpcPcmsEvaluateAttrRules(uidObjectUid,
                    ((AdmUidObject) getAttrValue("typeObject")).getAdmUid().getUid(), (String) getAttrValue("prodname"),
                    (String) getAttrValue("typename"), (String) getAttrValue("admclass"), (String) getAttrValue("status"),
                    (String) getAttrValue("nextstatus"), attrnums);

            String ret;

            if (attrRules != null) {
                ret = Constants.SERVER_OK;
                for (int i = 0; i < attrRules.length; i++) {
                    if (attrRules[i][0]) {
                        ret += "Y";
                    } else {
                        ret += "N";
                    }
                    if (attrRules[i][1]) {
                        ret += "Y";
                    } else {
                        ret += "N";
                    }
                    ret += "\007";
                }
            } else {
                ret = Constants.SERVER_ERROR;
            }

            return ret;

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

    }

}

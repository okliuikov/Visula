/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Check In for a Dimensions object.
 * <p>
 * Uses RPCExecCmd to check-in file via the message server.<br>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename of the object</dd>
 *  <dt>COMMENT {String}<dt><dd>User comment of the object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILENAME {String}<dt><dd>Specifies the name of the workset filename</dd>
 *  <dt>WORKSET {WorkSet}<dt><dd>Specifies the workset containing the object</dd>
 *  <dt>KEEP {Boolean}<dt><dd>Should a copy of this file be kept</dd>
 *  <dt>FORCE_UPDATE {Boolean}<dt><dd>Should file be checked-in even if content is unchanged</dd>
 *  <dt>CANCEL_UNCHANGED {Boolean}<dt><dd>performs a CIU (Cancel Item Update) command if the user file does not differ from the base revision and Dimensions is configured to allow updates only if a real change is made.</dd>
 *  <dt>STATUS {String}<dt><dd>A valid changed status</dd>
 *  <dt>CODE_PAGE {String}<dt><dd>Defines the method of encoding characters</dd>
 *  <dt>CONTENT_ENCODING {String}</dt><dd>Content encoding to be used when creating new revision</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class CheckInCmd extends RPCExecCmd {
    public CheckInCmd() throws AttrException {
        super();
        setAlias(Versionable.CHECK_IN);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILENAME, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FORCE_UPDATE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CANCEL_UNCHANGED, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.STATUS, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CODE_PAGE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CONTENT_ENCODING, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PERMS, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Item)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }


    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String userFilename = (String) getAttrValue(CmdArguments.USER_FILE);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        String filename = (String) getAttrValue(CmdArguments.FILENAME);
        WorkSet workset = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        boolean keep = ((Boolean) getAttrValue(CmdArguments.KEEP)).booleanValue();
        boolean force = ((Boolean) getAttrValue(CmdArguments.FORCE_UPDATE)).booleanValue();
        boolean cancel_unchanged = ((Boolean) getAttrValue(CmdArguments.CANCEL_UNCHANGED)).booleanValue();
        String status = (String) getAttrValue(CmdArguments.STATUS);
        String codepage = (String) getAttrValue(CmdArguments.CODE_PAGE);
        String encoding = (String) getAttrValue(CmdArguments.CONTENT_ENCODING);
        String perms = (String) getAttrValue(CmdArguments.PERMS);

        if (admObj instanceof Item) {
            _cmdStr = "RI ";
        }

        _cmdStr += Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        _cmdStr += " /USER_FILENAME=" + Encoding.escapeSpec(userFilename);
        _cmdStr += " /COMMENT=" + Encoding.escapeSpec(comment);

        String id = (String) admObj.getAttrValue(AdmAttrNames.ID);
        if (((id == null) || (id.length() == 0)) && (filename != null) && (filename.length() > 0)) {
            _cmdStr += " /FILENAME=" + Encoding.escapeSpec(filename);
        }

        if (workset != null) {
            _cmdStr += " /WORKSET=" + Encoding.escapeSpec(workset.getAdmSpec().getSpec());
        }

        _cmdStr += (keep) ? " /KEEP" : " /NOKEEP";
        _cmdStr += (force) ? " /FORCE" : "";
        _cmdStr += (cancel_unchanged) ? " /CANCEL_UNCHANGED" : " /NOCANCEL_UNCHANGED";
        _cmdStr += " /STATUS=" + Encoding.escapeSpec(status);

        if (codepage != null && codepage.length() > 0) {
            _cmdStr += " /CODEPAGE=" + Encoding.escapeSpec(codepage);
        }

        if (encoding != null && encoding.length() > 0) {
            _cmdStr += " /CONTENT_ENCODING=" + Encoding.escapeSpec(encoding);
        }

        if (admObj instanceof AdmUidObject) {
            _cmdStr += " " + AttributeDefinition.getAttrsCmdStringFromCmd(this);
        }

        if (perms != null && perms.length() > 0) {
            _cmdStr += " /PERMS=" + Encoding.escapeDMCLI(perms);
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        String ret = executeRpc();
        AdmResult retResult = new AdmResult(ret);
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Item.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ReleaseTemplateRule;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions ReleaseTemplateRule object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class DeleteReleaseTemplateRuleCmd extends DBIOCmd {
    public DeleteReleaseTemplateRuleCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReleaseTemplateRule)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String templateId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TEMPLATE_ID);
        String id = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
        String variant = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.VARIANT);
        String typeName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TYPE_NAME);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        if (DoesExistHelper.releaseTemplateIsInUse(templateId)) {
            throw new DimInUseException("Error: Release Template " + templateId
                    + " has been used to create releases - it cannot be deleted.");
        }

        DBIO query = new DBIO(wcm_sql.DELETE_RELEASETR);
        query.bindInput(templateId);
        query.bindInput(id);
        query.bindInput(variant);
        query.bindInput(typeName);
        query.write();
        query.commit();

        return "Operation Completed";
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ReleaseTemplate;
import merant.adm.dimensions.objects.ReleaseTemplateRule;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Release Template Rules's related to the ReleaseTemplate object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Floz
 */
public class QCRelTemplateToRelTRCmd extends QueryRelsCmd {
    public QCRelTemplateToRelTRCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReleaseTemplate)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(ReleaseTemplateRule.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new ArrayList();

        String templateId = admObj.getId();
        DBIO query = null;
        if (filter != null) {
            filter = (FilterImpl) filter.clone();
            query = getDBIO(templateId, filter);
        } else {
            query = new DBIO(wcm_sql.RELEASE_TEMPLATES_LIST_RULES);
            query.bindInput(templateId);
        }

        query.readStart();
        StringBuffer buf = new StringBuffer();
        while (query.read()) {
            buf.append(templateId);
            buf.append(':');
            buf.append(query.getString(1)); // partId
            buf.append('.');
            buf.append(query.getString(2)); // variant
            buf.append(';');
            buf.append(query.getString(3)); // item type/group name
            String spec = buf.toString();
            addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(spec, admSecClass));
            buf.setLength(0);
        }

        return ret;
    }

    private DBIO getDBIO(String templateId, FilterImpl filter) throws AdmException {
        String partId = "";
        String variant = "";
        String itemTypeGroup = "";

        StringBuffer sb = new StringBuffer();

        sb.append("SELECT part_id, variant, item_type FROM release_template ");
        sb.append("WHERE template_id=:I1 ");

        boolean addAnd = true;
        for (Iterator it = filter.criteria().iterator(); it.hasNext();) {
            FilterCriterion crit = (FilterCriterion) it.next();
            if (crit.getValue() == null) {
                continue;
            }

            if (crit.getAttrName().equals(AdmAttrNames.ID)) {
                if (addAnd) {
                    sb.append(" AND ");
                }

                addAnd = true;
                sb.append(" part_id = :I2");
                partId = (String) crit.getValue();
            }
            if (crit.getAttrName().equals(AdmAttrNames.VARIANT)) {
                if (addAnd) {
                    sb.append(" AND ");
                }

                addAnd = true;
                sb.append(" variant = :I3");
                variant = (String) crit.getValue();
            }

            if (crit.getAttrName().equals(AdmAttrNames.TYPE_NAME)) {
                if (addAnd) {
                    sb.append(" AND ");
                }

                addAnd = true;
                sb.append(" item_type = :I4");
                itemTypeGroup = (String) crit.getValue();
            }
        }

        String queryStr = sb.toString();
        DBIO query = new DBIO(queryStr);
        query.bindInput(templateId);
        query.bindInput(partId);
        query.bindInput(variant);
        query.bindInput(itemTypeGroup);

        return query;
    }

}

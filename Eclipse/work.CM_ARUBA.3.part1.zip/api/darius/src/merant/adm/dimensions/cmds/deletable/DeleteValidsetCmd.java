/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.dao.ValidsetDAO;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Validset;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions validset object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteValidsetCmd extends DBIOCmd {
    public DeleteValidsetCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Validset)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        String productName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
        String validsetName = admObj.getId();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_VALIDSETMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_VALIDSETMAN", productName);
        }

        if (!DoesExistHelper.validsetExists(productName, validsetName)) {
            throw new DimAlreadyExistsException("Error: validset " + productName + ":" + validsetName + " does not exists.");
        }

        final long vsUid = ((AdmUidObject) admObj).getAdmUid().getUid();

        int count = countAssigneUserAttrs(vsUid);
        if (count > 0) {
            throw new DimInUseException("Error: Cannot delete validset " + productName + ":" + validsetName
                    + " as it is currently assigned to " + count + " user-defined attributes.");
        }

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {

                ValidsetDAO dao = new ValidsetDAO(dbCtx);
                dao.delete(vsUid); // and validset values as well!
            }
        });

        return "Operation Completed";
    }

    private int countAssigneUserAttrs(long vsUid) throws DimBaseException, AttrException, AdmException {
        DBIO query = new DBIO(wcm_sql.CPL_COUNT_ATTRS_USING_VS_80);
        query.addInput(vsUid);

        query.readStart();
        int count = 0;
        if (query.read()) {
            count = query.getInt(1);
        }
        return count;
    }
}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.auditable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries the calculated next revision ID for a Dimensions object.
 * If the object is an Item or ItemFile, then it will be the next
 * revision. If the object is a Type (for an Item) or a Workset
 * then it will be the first revision.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>BRANCH {AdmObject}<dt><dd>Branch</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>The revision ID (as "branch#revison" or just "revision")</dd>
 * </dl></code>
 * @author Floz
 */
public class QueryNewRevCmd extends RPCExecCmd {
    public QueryNewRevCmd() throws AttrException {
        super();
        setAlias(Auditable.QUERY_NEW_REV);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCH, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ITEM_TYPE, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Item)) && (!(attrValue instanceof Type)) && (!(attrValue instanceof WorkSet))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String branch = (String) getAttrValue(CmdArguments.BRANCH);

        if (admObj instanceof Item) {

            String product = (String) getAttrValue(CmdArguments.PRODUCT);
            String itemTypeName = (String) getAttrValue(CmdArguments.ITEM_TYPE);
            StringBuffer sb;

            if (product == null && itemTypeName == null) {
                sb = new StringBuffer("DATA \"" + ((Item) admObj).getAdmUid().getUid() + " ITEM NEXTREVISION\"");
                if (branch != null) {
                    // This seems to be a hack on the server whereby specifying a '#'
                    // gives you the next revision on an unamed branch
                    if (branch.equals("")) {
                        branch = "#";
                    }
                    sb.append(" \"" + branch + "\"");
                }
            } else {
                sb = new StringBuffer("XDATA NEWITEMREVISION ");
                sb.append("/PARAMETER=(ITEM_TYPE=" + product + ":" + itemTypeName);
                if (branch != null && branch.length() > 0) {
                    sb.append(",BRANCH=" + branch);
                }
                sb.append(")");
            }

            _cmdStr = sb.toString();
            String str = executeRpc();

            if (str.startsWith(Constants.SERVER_OK)) {
                int n = str.indexOf('\n', Constants.SERVER_OK.length());
                if (n > Constants.SERVER_OK.length()) {
                    str = str.substring(Constants.SERVER_OK.length(), n);
                } else {
                    str = str.substring(Constants.SERVER_OK.length());
                }
            } else {
                str = "";
            }

            return str;
        } else if (admObj instanceof Type || admObj instanceof WorkSet) {
            AdmObject wsObj = null;

            // Query current workset object
            if (admObj instanceof Type) {
                wsObj = AdmCmd.getCurRootObj(WorkSet.class);
            } else {
                wsObj = admObj;
            }

            // Find default branch id if branch has not been passed in
            if (branch == null) {
                Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, wsObj);
                cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Branch.class);
                cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT, Boolean.TRUE);
                AdmBaseId brId = (AdmBaseId) cmd.execute();

                // convert to branch object (cheap for non-UID object):
                AdmObject brObj = AdmHelperCmd.getObject(brId);
                if (brObj != null) {
                    branch = brObj.getId();
                }
            }

            if (branch != null && branch.length() > 0) {
                return branch + "#1";
            } else {
                return "1";
            }
        } else {
            // validation shouldn't allow us to reach here.
            return null;
        }
    }
}

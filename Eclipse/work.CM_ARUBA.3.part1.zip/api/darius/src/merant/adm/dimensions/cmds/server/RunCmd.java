/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will allow you to run an arbitrary PCMS command line.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>COMMAND {String}<dt><dd>The command-line to execute</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * 
 * @author David Conneely
 */
public class RunCmd extends RPCExecCmd {
    public RunCmd() throws AttrException {
        super();
        setAlias(Server.RUN);
        setAttrDef(new CmdArgDef(CmdArguments.COMMAND, true, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        String cmdStr = (String) getAttrValue(CmdArguments.COMMAND);

        _cmdStr = cmdStr;

        return executeRpc();
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyRelatedException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimReservedWordException;
import merant.adm.dimensions.objects.BaselineCode;
import merant.adm.dimensions.objects.BaselineTemplateRule;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This internal command will replace the BaselineCode related to a BaselineTemplateRule.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {BaselineTemplateRule}</dt><dd>Dimensions LocalAttributeDefinition object</dd>
 *  <dt>ADM_PARENT_OBJECT {BaselineCode}</dt><dd>Parent Dimensions AttributeBlock object class</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class _internal_relate_blnt_to_blnc extends DBIOCmd {
    public _internal_relate_blnt_to_blnc() throws AttrException {
        super();
        setAlias("_internal_relate_blnt_to_blnc");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof BaselineTemplateRule)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof BaselineCode)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        String templateId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TEMPLATE_ID);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        if (DoesExistHelper.baselineTemplateIsInUse(templateId)) {
            throw new DimInUseException("Error: Baseline Template " + templateId
                    + " has been used to create baselines - it cannot be modified.");
        }

        if (templateId.equals(Constants.BLINET_ID_MERGED) || templateId.equals(Constants.BLINET_ID_REVISED)) {
            throw new DimReservedWordException("Error: Baseline Template " + templateId + " is a reserved template name.");
        }

        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_PARENT, admObj);
        cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, BaselineCode.class);
        AdmObject parentBaselineCode = AdmHelperCmd.getObject((AdmBaseId) cmd.execute());
        if (parentBaselineCode.getAdmSpec().getSpec().equals(admParentObj.getAdmSpec().getSpec())) {
            throw new DimAlreadyRelatedException("Error: Baseline template rule is already related to the specified baseline Code.");
        }

        DBIO query = new DBIO(wcm_sql.RELATE_BLNTR_TO_BLNC);
        query.bindInput(AdmHelperCmd.getAttributeValue(admParentObj, AdmAttrNames.BLINECODE_FLAG));
        query.bindInput(templateId);
        query.bindInput(admObj.getId());
        query.write();
        query.commit();

        return new AdmResult("Operation completed");
    }
}

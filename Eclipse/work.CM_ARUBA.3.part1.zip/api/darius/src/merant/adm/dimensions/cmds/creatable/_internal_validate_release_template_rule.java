/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.text.MessageFormat;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimInvalidRuleException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to validate a release template rule.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>TEMPLATE_ID {String}</dt><dd>Release Template name of the parent for the new rule</dd>
 *  <dt>ID {String}</dt><dd>Name identifier of the new release template</dd>
 *  <dt>VARIANT {String}</dt><dd>Variant of the new release template</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b>
 * <dt>RELTR_ITEMTYPE {String}</dt>
 * <dd>Item type name of the new release template rule. This parameter is mutually exclusive with RELTR_ITEMTYPEGRP</dd>
 * <dt>RELTR_ITEMTYPEGRP {String}</dt>
 * <dd>Item type group name of the new release template rule. This parameter is mutually exclusive with RELTR_ITEMTYPE</dd>
 * <dt>PRODUCT_NAME {String}</dt>
 * <dd>Product name used for part scoping</dd>
 * <dt>RELTR_SUBDIR {String}</dt>
 * <dd>Sub-directory of the new release template</dd>
 * <dt>UPDATE {Boolean}</dt>
 * <dd>Whether to validate for creation or update</dd>
 * <code><dl>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */

public class _internal_validate_release_template_rule extends DBIOCmd {
    public _internal_validate_release_template_rule() throws AttrException {
        super();
        setAlias("_internal_validate_release_template_rule");
        setAttrDef(new CmdArgDef(AdmAttrNames.TEMPLATE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VARIANT, true, String.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.RELTR_ITEMTYPE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTR_ITEMTYPEGRP, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTR_SUBDIR, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        String productId = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String templateId = (String) getAttrValue(AdmAttrNames.TEMPLATE_ID);
        String partId = (String) getAttrValue(AdmAttrNames.ID);
        String variant = (String) getAttrValue(AdmAttrNames.VARIANT);
        String itemTypeId = (String) getAttrValue(AdmAttrNames.RELTR_ITEMTYPE);
        String itemTypeGrp = (String) getAttrValue(AdmAttrNames.RELTR_ITEMTYPEGRP);
        String relSubDir = (String) getAttrValue(AdmAttrNames.RELTR_SUBDIR);

        if (DoesExistHelper.releaseTemplateIsInUse(templateId)) {
            throw new DimInUseException("Error: Release Template " + templateId
                    + " has been used to create releases - it cannot be modified.");
        }

        if (!DoesExistHelper.releaseTemplateExists(templateId)) {
            throw new DimNotExistsException("Error: Release Template " + templateId + " has not been defined.");
        }

        validateRule(templateId, partId, variant, itemTypeId, itemTypeGrp);

        return "Operation Completed";
    }

    private void validateRule(String templateId, String partId, String variant, String itemTypeId, String itemTypeGroup)
            throws AdmException {
        boolean updatingRule = ((Boolean) getAttrValue(CmdArguments.UPDATE)).booleanValue();

        // validate item type
        if (!isValidPartId(partId)) {
            throw new DimNotExistsException("Error: A valid part Id must be specified.");
        }

        if (!isValidPartVariant(variant)) {
            throw new DimNotExistsException("Error: A valid part variant must be specified.");
        }

        if (itemTypeId != null && itemTypeId.length() == 0) {
            itemTypeId = null;
        }

        if (itemTypeGroup != null && itemTypeGroup.length() == 0) {
            itemTypeGroup = null;
        }

        if (itemTypeId == null && itemTypeGroup == null) {
            throw new DimInvalidRuleException("Error: You must specify a valid item type or item type group.");
        }

        if (itemTypeId != null && itemTypeGroup != null) {
            throw new DimInvalidRuleException("Error: You can only specify an item type or an item type group, not both.");
        }

        if (itemTypeId != null && !isValidItemTypeId(itemTypeId)) {
            throw new DimInvalidRuleException("Error: You must specify a valid item type.");
        }
        if (itemTypeGroup != null && !isValidItemTypeGroup(itemTypeGroup)) {
            throw new DimInvalidRuleException("Error: You must specify a valid item group.");
        }

        String typeName = (itemTypeId != null ? itemTypeId : itemTypeGroup);

        boolean ruleExists = templateRuleExists(templateId, partId, variant, typeName);

        if (ruleExists && !updatingRule) {
            Object[] args = { templateId, partId, variant, typeName };
            String msgStr = MessageFormat.format(
                    "Error: a rule using part Id {1}, variant {2}, item type/group {3} has already been defined for the release template {0}.",
                    args);

            throw new DimAlreadyExistsException(msgStr);
        }

        if (!ruleExists && updatingRule) {
            Object[] args = { templateId, partId, variant, typeName };
            String msgStr = MessageFormat.format(
                    "Error: a rule using part Id {1}, variant {2}, item type/group {3} has not been defined for the release template {0}.",
                    args);

            throw new DimNotExistsException(msgStr);
        }
    }

    private boolean templateRuleExists(String templateId, String partId, String variant, String itemTypeGroup) throws AdmException {

        DBIO query = new DBIO(wcm_sql.RELEASETR_EXISTS);
        query.bindInput(templateId);
        query.bindInput(partId);
        query.bindInput(variant);
        query.bindInput(itemTypeGroup);
        query.readStart();

        boolean ruleExists = query.read();

        query.close();

        return ruleExists;

    }

    private boolean isValidPartId(String partId) throws AdmException {
        DBIO query = new DBIO(wcm_sql.RELEASETR_VALIDATE_PI);
        query.bindInput(partId);
        query.readStart();

        boolean isValid = query.read();

        query.close();

        return isValid;
    }

    private boolean isValidPartVariant(String variant) throws AdmException {
        DBIO query = new DBIO(wcm_sql.RELEASETR_VALIDATE_VX);
        query.bindInput(variant);
        query.readStart();

        boolean isValid = query.read();

        query.close();

        return isValid;
    }

    private boolean isValidItemTypeId(String itemTypeId) throws AdmException {
        DBIO query = new DBIO(wcm_sql.RELEASETR_VALIDATE_IT_WITHSTARANDMINUS);
        query.bindInput(itemTypeId);
        query.readStart();

        boolean isValid = query.read();

        query.close();

        return isValid;
    }

    private boolean isValidItemTypeGroup(String itemTypeGroup) throws AdmException {
        DBIO query = new DBIO(wcm_sql.RELEASETR_VALIDATE_ITG);
        query.bindInput(itemTypeGroup);
        query.readStart();

        boolean isValid = query.read();

        query.close();

        return isValid;
    }
}

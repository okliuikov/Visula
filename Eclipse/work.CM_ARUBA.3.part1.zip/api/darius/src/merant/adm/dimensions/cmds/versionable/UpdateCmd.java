package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a new Design Part revision. For creating new Item
 * revisions, please use WithBody.Update
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>REVISION {String}<dt><dd>New revision (PCS) of the existing part</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}</dt><dd>Description of the new revision</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Dunc
 */
public class UpdateCmd extends RPCExecCmd {
    public UpdateCmd() throws AttrException {
        super();
        setAlias(Versionable.UPDATE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REVISION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Part)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    public void buildCmd(AdmObject admObj, String newPCS, String description) throws AdmObjectException {
        _cmdStr = "UP";
        _cmdStr += " " + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        _cmdStr += " /NEW_PCS=\"" + newPCS + "\"";
        if (description != null) {
            _cmdStr += " /DESCRIPTION=\"" + description + "\"";
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String newPCS = (String) getAttrValue(AdmAttrNames.REVISION);
        String description = (String) getAttrValue(AdmAttrNames.DESCRIPTION);

        if (newPCS == null) {
            throw new DimMandatoryAttributeException("Error: new revision (PCS) of the design part must be specified.");
        }
        buildCmd(admObj, newPCS, description);

        return executeRpc();
    }
}
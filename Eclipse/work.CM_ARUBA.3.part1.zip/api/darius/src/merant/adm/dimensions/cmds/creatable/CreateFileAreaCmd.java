/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Work Area.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Identifier for the new area</dd>
 *  <dt>AREA_NETNODE_NAME {String}</dt><dd>File containing the area body</dd>
 *  <dt>AREA_DIRECTORY {String}</dt><dd>The ChangeDocument to attach to for scope</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>TYPE_NAME {String}</dt><dd>The type for the new area</dd>
 *  <dt>STAGE_ID {String}</dt><dd>The stage id for the new area</dd>
 *  <dt>DESCRIPTION {String}</dt><dd>The description for the new area</dd>
 *  <dt>AREA_USERNAME {String}</dt><dd>The user name for the new area</dd>
 *  <dt>AREA_PASSWORD {String}</dt><dd>The user password for the new area</dd>
 *  <dt>TRANSFER_SCRIPTS {String}</dt><dd>The transfer scripts for the new area</dd>
 *  <dt>OWNER {String}</dt><dd>The owner for the new area</dd>
 *  <dt>USER_LIST {String}</dt><dd>The list of users & groups granted access to the new area</dd>
 *  <dt>STATUS {String}</dt><dd>The status of the new area</dd>
 *  <dt>TEMPLATE_ID {String}</dt><dd>The template (filter) for the new area</dd>
 *  <dt>LIBRARY_CACHE_AREA {String}</dt><dd>The library cache area for the new area</dd>
 *  <dt>SCRIPT_PARAMETERS {Map}</dt><dd>Script parameters for the defined transfer scripts</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Peter Bate
 */
public class CreateFileAreaCmd extends RPCExecCmd {

    public CreateFileAreaCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_NETNODE_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_DIRECTORY, true, String.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_USERNAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_PASSWORD, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_FETCH_EXPANDED, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_OWNER, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STATUS, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TEMPLATE_ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_LIST, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_TRANSFER_PRE_SCRIPT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_TRANSFER_POST_SCRIPT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_TRANSFER_FAIL_SCRIPT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_LIBRARY_CACHE_AREA, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_SCRIPT_PARAMETERS, false, Map.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String description = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String networkNode = (String) getAttrValue(AdmAttrNames.AREA_NETNODE_NAME);
        String directory = (String) getAttrValue(AdmAttrNames.AREA_DIRECTORY);
        String type = (String) getAttrValue(AdmAttrNames.TYPE_NAME);
        String stage = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        String user = (String) getAttrValue(AdmAttrNames.AREA_USERNAME);
        String password = (String) getAttrValue(AdmAttrNames.AREA_PASSWORD);
        Boolean isFetchExpanded = (Boolean) getAttrValue(AdmAttrNames.AREA_FETCH_EXPANDED);

        String transfer_pre = (String) getAttrValue(AdmAttrNames.AREA_TRANSFER_PRE_SCRIPT);
        String transfer_post = (String) getAttrValue(AdmAttrNames.AREA_TRANSFER_POST_SCRIPT);
        String transfer_fail = (String) getAttrValue(AdmAttrNames.AREA_TRANSFER_FAIL_SCRIPT);

        String library_cache_area = (String) getAttrValue(AdmAttrNames.AREA_LIBRARY_CACHE_AREA);

        @SuppressWarnings("unchecked")
        Map<String, List<String>> script_parameters = (Map<String, List<String>>) getAttrValue(AdmAttrNames.AREA_SCRIPT_PARAMETERS);
        String owner = (String) getAttrValue(AdmAttrNames.AREA_OWNER);
        Boolean status = (Boolean) getAttrValue(AdmAttrNames.STATUS);
        String template = (String) getAttrValue(AdmAttrNames.TEMPLATE_ID);
        @SuppressWarnings("rawtypes")
        List userList = (List) getAttrValue(CmdArguments.USER_LIST);

        StringBuffer sb = null;
        if (type != null && (type.length() > 0) && type.equals("LIBRARY CACHE")) {
            sb = new StringBuffer("CLCA ");
            sb.append(Encoding.escapeDMCLI(id));
        } else {
            sb = new StringBuffer("CA ");
            sb.append(Encoding.escapeDMCLI(id));
            sb.append(" /TYPE=");
            sb.append(Encoding.escapeDMCLI(type));
            if ((stage != null) && (stage.length() > 0)) {
                sb.append(" /STAGE=");
                sb.append(Encoding.escapeDMCLI(stage));
            }
        }

        sb.append(" /NETWORK_NODE=");
        sb.append(Encoding.escapeDMCLI(networkNode));
        sb.append(" /DIRECTORY=");
        sb.append(Encoding.escapeDMCLI(directory));

        if ((user != null) && (user.length() > 0)) {
            sb.append(" /USER=");
            sb.append(Encoding.escapeDMCLI(user));
            if (!(user.charAt(0) == '<' && user.charAt(user.length() - 1) == '>')) {// Do not pass the password qualifier if the
                                                                                    // user name is credential
                sb.append(" /PASSWORD=");
                if ((password == null) || (password.length() == 0)) {
                    password = "";
                }
                sb.append(Encoding.escapeDMCLI(password));
            }
        }

        if (isFetchExpanded != null) {
            if (isFetchExpanded) {
                sb.append(" /FETCH_EXPANDED");
            } else {
                sb.append(" /NOFETCH_EXPANDED");
            }
        }

        if (((transfer_pre != null) && (transfer_pre.length() > 0)) || ((transfer_post != null) && (transfer_post.length() > 0))
                || ((transfer_fail != null) && (transfer_fail.length() > 0))) {
            sb.append(" /TRANSFER_SCRIPTS=(");
            if ((transfer_pre != null) && (transfer_pre.length() > 0)) {
                sb.append(Encoding.escapeDMCLI(transfer_pre));
            } else {
                sb.append("$NONE");
            }
            sb.append(",");
            if ((transfer_post != null) && (transfer_post.length() > 0)) {
                sb.append(Encoding.escapeDMCLI(transfer_post));
            } else {
                sb.append("$NONE");
            }
            sb.append(",");
            if ((transfer_fail != null) && (transfer_fail.length() > 0)) {
                sb.append(Encoding.escapeDMCLI(transfer_fail));
            } else {
                sb.append("$NONE");
            }
            sb.append(")");
        }

        if (library_cache_area != null && (library_cache_area.length() > 0)) {
            sb.append(" /LIBRARY_CACHE_AREA=");
            sb.append(Encoding.escapeDMCLI(library_cache_area));
        }

        if (script_parameters != null && !script_parameters.isEmpty()) {
            sb.append(" /SCRIPT_PARAMETERS=(");
            Iterator<Entry<String, List<String>>> entryIter = script_parameters.entrySet().iterator();
            while (entryIter.hasNext()) {
                Entry<String, List<String>> entry = entryIter.next();
                sb.append(Encoding.escapeDMCLI(entry.getKey()));
                sb.append("=");
                if (entry.getValue().size() == 1) {
                    sb.append(Encoding.escapeDMCLI(entry.getValue().get(0)));
                } else if (entry.getValue().size() > 1) {
                    sb.append("[");
                    ListIterator<String> values = entry.getValue().listIterator();
                    while (values.hasNext()) {
                        sb.append(Encoding.escapeDMCLI(values.next()));
                        if (values.hasNext()) {
                            sb.append(",");
                        }
                    }
                    sb.append("]");
                }
                if (entryIter.hasNext()) {
                    sb.append(",");
                }
            }
            sb.append(")");
        }

        if ((owner != null) && (owner.length() > 0)) {
            sb.append(" /OWNER=");
            sb.append(Encoding.escapeDMCLI(owner));
        }

        if ((description != null) && (description.length() > 0)) {
            sb.append(" /DESCRIPTION=");
            sb.append(Encoding.escapeDMCLI(description));
        }

        if (status != null) {
            sb.append(" /STATUS=");
            if (status.booleanValue()) {
                sb.append("ONLINE");
            } else {
                sb.append("OFFLINE");
            }
        }

        if ((template != null) && (template.length() > 0) && !template.equals("<none>")) {
            sb.append(" /FILTER=");
            sb.append(Encoding.escapeDMCLI(template));
        }

        if ((userList != null) && (userList.size() != 0)) {
            sb.append(" /USER_LIST=(");
            for (int i = 0; i < userList.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(Encoding.escapeDMCLI(((String) userList.get(i))));
            }
            sb.append(")");
        }

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc(), new AdmSpec(id, FileArea.class));
        return retResult;
    }
}
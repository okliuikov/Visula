/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION %PID% Description: %PD% %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.BuildTarget;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.session.Session;

/**
 * Queries all BuildTargets's related to a WorkSet object.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code><br>
 * <b>Optional Arguments: </b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * 
 * @author Vadym Krevs
 */
public class QCWorkSetToBuildTargetsCmd extends QueryRelsCmd {

    public QCWorkSetToBuildTargetsCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(BuildTarget.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {

        if (filter == null) {
            throw new IllegalArgumentException("Error: list of items to be built must be specified.");
        }

        List itemsList = (List) filter.get(CmdArguments.ADM_OBJECT_LIST);
        if (itemsList == null || itemsList.size() == 0) {
            throw new IllegalArgumentException("Error: list of items to be built must be specified.");
        }

        int worksetUid = new Long(((AdmUidObject) admObj).getUid()).intValue();

        // return the selected targets to the caller
        List ret = new ArrayList();

        int[] targetUids = null;

        try {
            Session session = (Session) DimSystem.getSystem().getSession();

            targetUids = session.getConnection().rpcGetTargets(worksetUid, -1, -1, CmdUtils.getUidArray(itemsList));

            if (targetUids == null) {
                throw new DimBaseCmdException("Error: failed to query buildable targets.");
            }

        } catch (DimBaseCmdException dbce) {
            // exceptions are rethrown, so as to translate error messages into
            // meaningful exceptions
            DimSystem.getSystem().getExceptionHandler().throwException(dbce.toString());
        } catch (Exception e) {
            Debug.error(e);
            DimSystem.getSystem().getExceptionHandler().throwException(e.toString());
        }

        for (int i = 0; i < targetUids.length; i++) {
            AdmBaseId baseId = AdmHelperCmd.newAdmBaseId(targetUids[i], BuildTarget.class);
            addRelation(ret, relationships, admObj.getAdmBaseId(), baseId);
        }

        return ret;
    }
}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;

/**
 * Obtains the serial number from a Dimensions server license.
 * 
 * @author Peter Raymond
 */
public class RPCGetVersionCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCGetVersionCmd() throws AdmObjectException {
        super();
        setAlias("RPCGetVersion");
        AddArgument("cmd", "QueryVersion");
    }

    @Override
    public Object execute() throws AdmException {
        try {
            return getSession().getConnection().rpcPcmsGetVersion(1);
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

    }

}

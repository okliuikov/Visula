/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimReservedWordException;
import merant.adm.dimensions.objects.BaselineTemplateRule;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Template;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions BaselineTemplateRule object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class DeleteBaselineTemplateRuleCmd extends DBIOCmd {
    public DeleteBaselineTemplateRuleCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof BaselineTemplateRule)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String templateId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TEMPLATE_ID);

        AdmObject admTemplateObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(templateId, Template.class));
        Object scopeClass = AdmHelperCmd.getAttributeValue(admTemplateObj, AdmAttrNames.PARENT_CLASS);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        if (DoesExistHelper.baselineTemplateIsInUse(templateId)) {
            throw new DimInUseException("Error: Baseline Template " + templateId
                    + " has been used to create baselines - it cannot be deleted.");
        }

        if (templateId.equals(Constants.BLINET_ID_MERGED) || templateId.equals(Constants.BLINET_ID_REVISED)) {
            throw new DimReservedWordException("Error: Baseline Template " + templateId + " is a reserved template name.");
        }

        DBIO query = null;
        if (Item.class.equals(scopeClass)) {
            query = new DBIO(wcm_sql.DELETE_ITEM_BLINETR);
        } else {
            query = new DBIO(wcm_sql.DELETE_CHDOC_BLINETR);
        }
        query.bindInput(templateId);
        query.bindInput(admObj.getId());
        query.write();
        query.commit();

        return "Operation Completed";
    }
}

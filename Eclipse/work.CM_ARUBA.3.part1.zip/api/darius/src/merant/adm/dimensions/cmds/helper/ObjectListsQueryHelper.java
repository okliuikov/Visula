package merant.adm.dimensions.cmds.helper;

import java.util.List;

import com.serena.dmnet.drs.DRSClientQueryObjectLists;
import com.serena.dmnet.drs.DRSClientQueryObjectLists.ObjectListsQueryContext;

import merant.adm.dimensions.cmds.creatable.GetObjectsCmd;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmUidTwin;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;

public class ObjectListsQueryHelper {

    // Filter list common: list flags
    public static final int FLC_FAVORITE = 0x00000001;
    public static final int FLC_RECENT = 0x00000002;
    public static final int FLC_OTHER = 0x00000004;
    public static final int FLC_PRODUCT = 0x00000008;

    // Filter for worksets: objFlags
    public static final int FWS_PROJECT = 0x00000001;
    public static final int FWS_STREAM = 0x00000002;
    public static final int FWS_EXCLUDE_GENERIC = 0x00000004;
    public static final int FWS_EXCLUDE_UNUPGRADED = 0x00000008;

    // Output container list type: types
    private static final int LT_FAVORITE = 0x00000001;
    private static final int LT_RECENT = 0x00000002;
    private static final int LT_OTHER = 0x00000004;

    public interface ListsQueryHandler {

        void handleFavourite(AdmObject admObject) throws AdmException;

        void handleRecent(AdmObject admObject) throws AdmException;

        void handleOther(AdmObject admObject) throws AdmException;

    }

    public static void query(int objClass, int listFlags, int objFlags, String productId, int recentMaxCount,
            ListsQueryHandler handler) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.GetLists);
        query.setObjClass(objClass);
        query.setListFlags(listFlags);
        query.setObjFlags(objFlags);
        query.setProductId(productId);
        query.setRecentMaxCount(recentMaxCount);

        DRSUtils.execute(query);

        if (query.hasData()) {

            int[] outUids = query.getOutUids();
            String[] specs = query.getSpecs();
            int[] objClasses = query.getObjClasses();
            int[] types = query.getTypes();

            if (outUids == null || specs == null || objClasses == null || types == null) {
                throw new DRSException("Incorrect output after execution of " + DRSClientQueryObjectLists.class);
            }

            if ((outUids.length != specs.length) || (specs.length != objClasses.length) || (objClasses.length != types.length)) {
                throw new DRSException("Incorrect output after execution of " + DRSClientQueryObjectLists.class);
            }

            for (int i = 0; i < outUids.length; i++) {
                int outUid = outUids[i];
                int outObjClass = objClasses[i];
                int outType = types[i];
                String outSpec = specs[i];

                AdmObject admObject = null;

                if (outObjClass == Constants.WORKSET_CLASS || outObjClass == Constants.STREAM_CLASS) {

                    admObject = createObject(outUid, outSpec, WorkSet.class);

                    if (outObjClass == Constants.WORKSET_CLASS) {
                        admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, false);
                    } else if (outObjClass == Constants.STREAM_CLASS) {
                        admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, true);
                    }
                } else if (outObjClass == Constants.BASELINE_CLASS) {
                    admObject = createObject(outUid, outSpec, Baseline.class);
                } else if (outObjClass == Constants.CHDOC_CLASS) {
                    admObject = createObject(outUid, outSpec, ChangeDocument.class);
                }

                if ((outType & LT_FAVORITE) == LT_FAVORITE) {
                    handler.handleFavourite(admObject);
                } else if ((outType & LT_RECENT) == LT_RECENT) {
                    handler.handleRecent(admObject);
                } else if ((outType & LT_OTHER) == LT_OTHER) {
                    handler.handleOther(admObject);
                }
            }
        }
    }

    public static void setFavoriteSpec(int objClass, String objSpec, boolean favourite) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetFavoriteSpec);
        query.setObjClass(objClass);
        query.setSpec(objSpec);
        query.setValue(favourite);

        DRSUtils.execute(query);
    }

    public static void setFavoriteUid(int objClass, long objUid, boolean favourite) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetFavoriteUid);
        query.setObjClass(objClass);
        query.setInUid(objUid);
        query.setValue(favourite);

        DRSUtils.execute(query);
    }

    public static void setRecentSpec(int objClass, String objSpec) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetRecentSpec);
        query.setObjClass(objClass);
        query.setSpec(objSpec);

        DRSUtils.execute(query);
    }

    public static void setRecentUid(int objClass, long objUid) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetRecentUid);
        query.setObjClass(objClass);
        query.setInUid(objUid);

        DRSUtils.execute(query);
    }

    public static void setFavoriteSpecs(int objClass, List<String> objSpecs, boolean favourite) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetFavoriteSpecList);
        query.setObjClass(objClass);
        query.setSpecs(objSpecs.toArray(new String[objSpecs.size()]));
        query.setValue(favourite);

        DRSUtils.execute(query);
    }

    public static void setFavoriteUids(int objClass, List<Long> objUids, boolean favourite) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetFavoriteUidList);
        query.setObjClass(objClass);
        query.setInUids(objUids.toArray(new Long[objUids.size()]));
        query.setValue(favourite);

        DRSUtils.execute(query);
    }

    public static void setRecentSpecs(int objClass, List<String> objSpecs) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetRecentSpecList);
        query.setObjClass(objClass);
        query.setSpecs(objSpecs.toArray(new String[objSpecs.size()]));

        DRSUtils.execute(query);
    }

    public static void setRecentUids(int objClass, List<Long> objUids) throws AdmException {
        if (objClass != Constants.WORKSET_CLASS) {
            throw new UnsupportedOperationException("Not Implemented yet.");
        }

        DRSClientQueryObjectLists query = new DRSClientQueryObjectLists(ObjectListsQueryContext.SetRecentUidList);
        query.setObjClass(objClass);
        query.setInUids(objUids.toArray(new Long[objUids.size()]));

        DRSUtils.execute(query);
    }

    private static AdmObject createObject(int outUid, String outSpec, Class<?> clazz) throws AdmException {
        AdmUidTwin baseId = new AdmUidTwin(outUid, clazz);
        AdmSpec spec = new AdmSpec(outSpec, clazz);
        baseId.setTwin(spec);
        return GetObjectsCmd.buildNewObject(baseId);
    }

}

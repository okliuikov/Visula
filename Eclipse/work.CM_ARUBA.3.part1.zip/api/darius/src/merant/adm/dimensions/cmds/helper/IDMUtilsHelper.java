/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005-2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.helper;

import java.util.*;
import java.util.regex.Pattern;

import com.serena.dmfile.utility.ArrayUtils;
import com.serena.dmnet.drs.DRSClientIdmUtils;
import com.serena.dmnet.drs.DRSClientIdmUtils.IdmUtilsQueryContext;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.IDMReport;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.system.ExtReqPickerProps;
import merant.adm.dimensions.system.OauthRequestTokenInfo;
import merant.adm.dimensions.util.DateUtils;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.session.Session;

public class IDMUtilsHelper {

    public static final long INVALID_PROVIDER_TOOL_UID = -2;
    public static final String PASS_FIELD = "********";

    public static class IdmRequestPage {
        public IdmRequestPage() {

        }

        private List<IdmRequestWithAttrs> result = new ArrayList<IdmRequestWithAttrs>();

        public void setRequestList(final List<IdmRequestWithAttrs> requests) {
            result = requests;
        }

        public List<IdmRequestWithAttrs> getRequestList() {
            return result;
        }

        private int totalRequests;

        public void setTotalRequests(final int totalRequests) {
            this.totalRequests = totalRequests;
        }

        public int getTotalRequests() {
            return totalRequests;
        }
    }

    public static class ExternalRequestPage {
        public ExternalRequestPage() {

        }

        private int totalRequests;

        private List<ExternalRequest> result = new ArrayList<ExternalRequest>();

        public void setRequestList(final List<ExternalRequest> requests) {
            result = requests;
        }

        public List<ExternalRequest> getRequestList() {
            return result;
        }

        public void setTotalRequests(final int totalRequests) {
            this.totalRequests = totalRequests;
        }

        public int getTotalRequests() {
            return totalRequests;
        }
    }

    public static class IdmRequestWithAttrs {
        private final long toolUid;
        private final long uid;
        private final String id;
        private final List<String> attrValues;
        private final List<String> customAttrNames;
        private final List<String> customAttrValues;
        private final List<Integer> customAttrTypes;

        public IdmRequestWithAttrs(final long toolUid, final long uid, final String id, final List<String> attrValues,
                final List<String> customAttrNames, final List<String> customAttrValues, final List<Integer> customAttrTypes) {
            this.toolUid = toolUid;
            this.uid = uid;
            this.id = id;
            this.attrValues = attrValues;
            this.customAttrNames = customAttrNames;
            this.customAttrValues = customAttrValues;
            this.customAttrTypes = customAttrTypes;
        }

        public long getToolUid() {
            return toolUid;
        }

        public long getUid() {
            return uid;
        }

        public String getId() {
            return id;
        }

        public List<String> getAttrValues() {
            return attrValues;
        }

        public List<String> getCustomAttrNames() {
            return customAttrNames;
        }

        public List<String> getCustomAttrValues() {
            return customAttrValues;
        }

        public List<Integer> getCustomAttrTypes() {
            return customAttrTypes;
        }
    }

    public enum SearchMode {
        INBOX, ALL, WORKING_LIST
    }

    public static boolean verifySingleRequests(final String internalId, final long productUid, final long toolUid)
            throws AdmException {

        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetVerifiedRequests);

        final String[] internalIds = new String[1];
        internalIds[0] = internalId;

        drs.setWsetUid(Constants.INVALID_UID);
        drs.setProductUid(productUid);
        drs.setToolUid(toolUid);
        drs.setFilterAttr(0);
        drs.setFilterValue("");
        drs.setFilterFlags(0);
        drs.setSortAttr(0);
        drs.setSortOrder(1);
        drs.setInUids(new Long[0]);
        drs.setInIds(internalIds);

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            return drs.getUids() != null && drs.getUids().length != 0 && drs.getUids()[0] != Constants.INVALID_UID;
        }

        return false;
    }

    public static long processRequest(final String internalId, final long productUid, final long toolUid) throws AdmException {

        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.ProcessRequestEx);

        drs.setWsetUid(Constants.INVALID_UID);
        drs.setProductUid(productUid);
        drs.setToolUid(toolUid);
        drs.setId(internalId);

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            return drs.getUid();
        }

        return Constants.INVALID_UID;
    }

    public static IdmRequestPage searchRequestsWithAttrs(final SearchMode searchMode, final long productUid, final long toolUid,
            final List<Long> filterAttrs, final List<String> filterValues, final int filterFlags, final int sortAttr,
            final int sortOrder, final List<Long> attrs, final List<Long> paginationInfo, final List<String> entities,
            final List<String> customAttrNames, final String userName) throws AdmException {
        final DRSClientIdmUtils drs;
        if (searchMode == SearchMode.INBOX) {
            drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetInboxRequestsWithAttrs);
        } else if (searchMode == SearchMode.ALL) {
            drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetRequestsWithAttrs);
        }
        else if (searchMode == SearchMode.WORKING_LIST) {
            drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetWorkingListRequests);
            drs.setUserName(userName);
        }else {
            throw new IllegalArgumentException("Unsupported search mode: " + searchMode);
        }

        drs.setAttrs(attrs.toArray(new Long[attrs.size()]));
        drs.setCustomAttrs(customAttrNames.toArray(new String[customAttrNames.size()]));
        drs.setWsetUid(Constants.INVALID_UID);
        drs.setProductUid(productUid);
        drs.setToolUid(toolUid);
        drs.setFilterFlags(filterFlags);
        drs.setSortAttr(sortAttr);
        drs.setSortOrder(sortOrder);

        if (filterAttrs != null && !filterAttrs.isEmpty()) {
            drs.setFilterAttrs(filterAttrs.toArray(new Long[filterAttrs.size()]));
        } else {
            drs.setFilterAttrs(new Long[] {});
        }

        if (filterValues != null && !filterValues.isEmpty()) {
            drs.setFilterValues(filterValues.toArray(new String[filterValues.size()]));
        } else {
            drs.setFilterValues(new String[] {});
        }

        if (paginationInfo != null && !paginationInfo.isEmpty()) {
            drs.setPaginationInfo(paginationInfo.toArray(new Long[paginationInfo.size()]));
        } else {
            drs.setPaginationInfo(new Long[] {});
        }

        if (entities != null && !entities.isEmpty()) {
            drs.setFilteredEntities(entities.toArray(new String[entities.size()]));
        } else {
            drs.setFilteredEntities(new String[] {});
        }

        DRSUtils.execute(drs);

        final IdmRequestPage page = new IdmRequestPage();
        if (drs.hasData()) {
            page.setTotalRequests(drs.getTotalRequests());
            if (drs.getAttrVals() == null) {
                return page;
            }
            final int[] outUids = drs.getUids();
            final String[] outIds = drs.getIds();
            final List<String> allAttrVals = drs.getAttrVals() != null ? Arrays.asList(drs.getAttrVals()) : new ArrayList<String>();
            final List<String> allCustomAttrVals = drs.getCustomAttrVals() != null ? Arrays.asList(drs.getCustomAttrVals())
                    : new ArrayList<String>();
            final List<Integer> allCustomAttrTypes = drs.getCustomAttrTypes() != null ? ArrayUtils.toList(drs.getCustomAttrTypes())
                    : new ArrayList<Integer>();
            if (outUids.length != outIds.length) {
                throw new AdmException("The returned lists of external request uids and ids have different sizes");
            }
            if (allAttrVals.size() != outIds.length * attrs.size()) {
                throw new AdmException("The returned list of external request system attribute values has unexpected size");
            }
            if (allCustomAttrVals.size() != outIds.length * customAttrNames.size()) {
                throw new AdmException("The returned list of external request custom attribute values has unexpected size");
            }
            if (allCustomAttrTypes.size() != outIds.length * customAttrNames.size()) {
                throw new AdmException("The returned list of external request custom attribute types has unexpected size");
            }
            int attrsStart = 0;
            int attrsEnd = attrs.size();
            int customAttrsStart = 0;
            int customAttrsEnd = customAttrNames.size();
            for (int i = 0; i < outUids.length; i++) {
                final List<String> attrsVals = allAttrVals.subList(attrsStart, attrsEnd);
                attrsStart = attrsEnd;
                attrsEnd += attrsVals.size();
                final List<String> customAttrsVals = allCustomAttrVals.subList(customAttrsStart, customAttrsEnd);
                final List<Integer> customAttrsTypes = allCustomAttrTypes.subList(customAttrsStart, customAttrsEnd);
                customAttrsStart = customAttrsEnd;
                customAttrsEnd += customAttrsVals.size();
                page.getRequestList().add(new IdmRequestWithAttrs(toolUid, outUids[i], outIds[i], attrsVals, customAttrNames,
                        customAttrsVals, customAttrsTypes));
            }
        }
        return page;
    }

    public static IdmRequestPage getRequestsAttrsPagination(final long wsetUid, final long productUid,
        final Collection<Long> uids, final Collection<String> ids,
        final List<Long> filterAttrs, final List<String> filterValues, final int filterFlags,
        final int sortAttr, final int sortOrder,
        final List<Long> attrs, final List<Long> paginationInfo) throws AdmException {

        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetRequestsAttrsPagination);

        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);

        if (uids != null && !uids.isEmpty()) {
            drs.setInUids(uids.toArray(new Long[uids.size()]));
        } else {
            drs.setInUids(new Long[] {});
        }

        if (ids != null && !ids.isEmpty()) {
            drs.setInIds(ids.toArray(new String[ids.size()]));
        } else {
            drs.setInIds(new String[] {});
        }

        if (attrs != null && !attrs.isEmpty()) {
            drs.setAttrs(attrs.toArray(new Long[attrs.size()]));
        } else {
            drs.setAttrs(new Long[] {});
        }

        if (filterAttrs != null && !filterAttrs.isEmpty()) {
            drs.setFilterAttrs(filterAttrs.toArray(new Long[filterAttrs.size()]));
        } else {
            drs.setFilterAttrs(new Long[] {});
        }

        if (filterValues != null && !filterValues.isEmpty()) {
            drs.setFilterValues(filterValues.toArray(new String[filterValues.size()]));
        } else {
            drs.setFilterValues(new String[] {});
        }

        drs.setFilterFlags(filterFlags);

        drs.setSortAttr(sortAttr);
        drs.setSortOrder(sortOrder);

        if (paginationInfo != null && !paginationInfo.isEmpty()) {
            drs.setPaginationInfo(paginationInfo.toArray(new Long[paginationInfo.size()]));
        } else {
            drs.setPaginationInfo(new Long[] {});
        }

        DRSUtils.execute(drs);

        final IdmRequestPage page = new IdmRequestPage();
        if (drs.hasData()) {
            page.setTotalRequests(drs.getTotalRequests());

            final int[] outUids = drs.getUids();
            final String[] outIds = drs.getIds();

            if (outUids == null || outIds == null) {
                return page;
            }

            final List<String> allAttrVals = (drs.getAttrVals() != null) ? Arrays.asList(drs.getAttrVals()) : new ArrayList<String>();

            if (outUids.length != outIds.length) {
                throw new AdmException("The returned lists of external request uids and ids have different sizes");
            }

            if (allAttrVals.size() != outIds.length * attrs.size()) {
                throw new AdmException("The returned list of external request system attribute values has unexpected size");
            }

            int attrsStart = 0;
            int attrsEnd = attrs.size();

            // Empty custom attributes
            final List<String> customAttrNames = new ArrayList<String>();
            final List<String> customAttrValues = new ArrayList<String>();
            final List<Integer> customAttrTypes = new ArrayList<Integer>();

            for (int i = 0; i < outUids.length; i++) {
                final List<String> attrsVals = allAttrVals.subList(attrsStart, attrsEnd);
                attrsStart = attrsEnd;
                attrsEnd += attrsVals.size();

                page.getRequestList().add(new IdmRequestWithAttrs(Constants.INVALID_UID, outUids[i], outIds[i], attrsVals,
                    customAttrNames, customAttrValues, customAttrTypes));
            }
        }

        return page;
    }

    public static List<IdmRequestWithAttrs> queryIdmRequestsAttributesByIds(final Collection<Long> toolUids,
            final Collection<String> ids, final List<Long> attrs, final List<String> customAttrs) throws AdmException {
        return queryIdmRequestsAttributes(toolUids, new ArrayList<Long>(), ids, attrs, customAttrs);
    }

    public static List<IdmRequestWithAttrs> queryIdmRequestsAttributes(final Collection<Long> toolUids, final Collection<Long> uids,
            final Collection<String> ids, final List<Long> attrs, final List<String> customAttrNames) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetRequestsAttrsEx);

        if (toolUids.size() != uids.size() + ids.size()) {
            throw new AdmException("Input lists of external request ids and tool uids have different sizes");
        }

        drs.setInToolUids(toolUids.toArray(new Long[toolUids.size()]));
        drs.setInUids(uids.toArray(new Long[uids.size()]));
        drs.setInIds(ids.toArray(new String[ids.size()]));
        drs.setAttrs(attrs.toArray(new Long[attrs.size()]));
        drs.setCustomAttrs(customAttrNames.toArray(new String[customAttrNames.size()]));
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            final List<IdmRequestWithAttrs> result = new ArrayList<IdmRequestWithAttrs>();

            final long[] outToolUids = drs.getToolUids();
            final int[] outUids = drs.getUids();
            final String[] outIds = drs.getIds();
            final List<String> allAttrVals = drs.getAttrVals() != null ? Arrays.asList(drs.getAttrVals()) : new ArrayList<String>();
            final List<String> allCustomAttrVals = drs.getCustomAttrVals() != null ? Arrays.asList(drs.getCustomAttrVals())
                    : new ArrayList<String>();
            final List<Integer> allCustomAttrTypes = drs.getCustomAttrTypes() != null ? ArrayUtils.toList(drs.getCustomAttrTypes())
                    : new ArrayList<Integer>();
            if (outToolUids.length != outIds.length) {
                throw new AdmException("The returned lists of external request ids and tool uids have different sizes");
            }
            if (outUids.length != outIds.length) {
                throw new AdmException("The returned lists of external request uids and ids have different sizes");
            }
            if (allAttrVals.size() != outIds.length * attrs.size()) {
                throw new AdmException("The returned list of external request system attribute values has unexpected size");
            }
            if (allCustomAttrVals.size() != outIds.length * customAttrNames.size()) {
                throw new AdmException("The returned list of external request custom attribute values has unexpected size");
            }
            if (allCustomAttrTypes.size() != outIds.length * customAttrNames.size()) {
                throw new AdmException("The returned list of external request custom attribute types has unexpected size");
            }
            int attrsStart = 0;
            int attrsEnd = attrs.size();
            int customAttrsStart = 0;
            int customAttrsEnd = customAttrNames.size();
            for (int i = 0; i < outToolUids.length; i++) {
                final List<String> attrsVals = allAttrVals.subList(attrsStart, attrsEnd);
                attrsStart = attrsEnd;
                attrsEnd += attrsVals.size();
                final List<String> customAttrsVals = allCustomAttrVals.subList(customAttrsStart, customAttrsEnd);
                final List<Integer> customAttrsTypes = allCustomAttrTypes.subList(customAttrsStart, customAttrsEnd);
                customAttrsStart = customAttrsEnd;
                customAttrsEnd += customAttrsVals.size();
                result.add(new IdmRequestWithAttrs(outToolUids[i], outUids[i], outIds[i], attrsVals, customAttrNames,
                        customAttrsVals, customAttrsTypes));
            }
            return result;
        }
        return new ArrayList<IdmRequestWithAttrs>();
    }

    public static List<IdmRequestWithAttrs> queryRelatedIDMRequestsIds(final long parentUid, final int parentObjClass,
            final long relTypeUid, final int options) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetRelatedRequests);

        drs.setParentUid(parentUid);
        drs.setParentObjClass(parentObjClass);
        drs.setRelTypeUid(relTypeUid);

        DRSUtils.execute(drs);

        final List<IdmRequestWithAttrs> result = new ArrayList<IdmRequestWithAttrs>();
        if (drs.hasData()) {
            final long[] outToolUids = drs.getToolUids();
            final int[] outUids = drs.getUids();
            final String[] outIds = drs.getIds();
            if (outToolUids.length != outIds.length) {
                throw new AdmException("The returned lists of external request ids and tool uids have different sizes");
            }
            if (outToolUids.length != outUids.length) {
                throw new AdmException("The returned lists of external request uids and tool uids have different sizes");
            }
            for (int i = 0; i < outToolUids.length; ++i) {
                result.add(new IdmRequestWithAttrs(outToolUids[i], (long) outUids[i], outIds[i], null, null, null, null));
            }
        }
        return result;
    }

    public static long getToolUidBySpecId(final String spec_id) throws AdmException {
        if (spec_id == null || spec_id.isEmpty()) {
            return Constants.INVALID_UID;
        }

        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetToolUidBySpecId);
        drs.setSpecId(spec_id);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            return drs.getToolUid();
        }

        return Constants.INVALID_UID;
    }

    public static RequestProvider getRequestProvider(long toolUid, long prodUid, long wsetUid) {
        try {
            if (toolUid == Constants.INVALID_UID) {         // Find out provider UID
                long uid = Constants.INVALID_UID;
                long typeUid = Constants.BASEDB_CLASS;      // Default provider case

                if (wsetUid != Constants.INVALID_UID) {
                    typeUid = Constants.WORKSET_CLASS;      // Workset-related request provider
                    uid = wsetUid;
                } else if (prodUid != Constants.INVALID_UID) {
                    typeUid = Constants.PRODUCT_CLASS;      // Product-related request provider
                    uid = prodUid;
                }

                Object[] details = ((Session) DimSystem.getSystem().getSession()).getConnection().rpcGetRequestProviders(typeUid, uid);
                if (details == null) {
                    return null;
                }

                toolUid = (Integer) details[0];
            }

            return (RequestProvider) AdmCmd.getObject(AdmCmd.newAdmBaseId(toolUid, RequestProvider.class));

        } catch (Exception e) {
            Debug.error(e);
        }
        return null;
    }

    public static String GetToolGlobalAuthUser(final String spec_id) throws AdmException {
        if (spec_id == null || spec_id.isEmpty()) {
            return "";
        }

        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetToolGlobalAuthUser);
        drs.setSpecId(spec_id);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            return drs.getUserName();
        }

        return "";
    }

    public static long getDefaultIdmToolUid() throws AdmException {

        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetDefaultIdmToolUid);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            return drs.getToolUid();
        }

        return Constants.INVALID_UID;
    }

    public static void setDefaultIdmToolUid(final Long toolUid) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.SetDefaultIdmToolUid);
        drs.setToolUid(toolUid);
        DRSUtils.execute(drs);
    }

    public static void deleteTool(final Long toolUid) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.DeleteTool);
        drs.setToolUid(toolUid);
        DRSUtils.execute(drs);
    }

    public static void setProviderProducts(final Long toolUid, final Collection<Long> assignUids,
            final Collection<Long> deassignUids) throws AdmException {

        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.SetProviderProducts);
        drs.setToolUid(toolUid);
        drs.setInAssignUids(assignUids.toArray(new Long[assignUids.size()]));
        drs.setInDeassignUids(deassignUids.toArray(new Long[deassignUids.size()]));

        DRSUtils.execute(drs);
    }

    public static void updateIDMRequest(final Long toolUid, final String id, final String status, final List<String> customAttrs,
            final List<String> customAttrVals) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.UpdateIDMRequest);
        drs.setInToolUid(toolUid);
        drs.setInUid(-1L);
        drs.setInId(id);
        drs.setCustomAttrs(customAttrs.toArray(new String[customAttrs.size()]));
        drs.setCustomAttrVals(customAttrVals.toArray(new String[customAttrVals.size()]));
        if (status != null) {
            drs.setNewStatus(status);
        } else {
            drs.setNewStatus("");
        }
        DRSUtils.execute(drs);
    }

    public static void DeleteWorkingLists(final Long toolUid) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.DeleteWorkingLists);
        drs.setInToolUid(toolUid);

        DRSUtils.execute(drs);
    }

    private static final Pattern pattern = Pattern.compile("[A-Za-z0-9_]+");// double check alphabet + num + '_' in specId

    public static boolean validateSpecId(final String specId) {
        if (specId == null || specId.isEmpty()) {
            return false;
        }
        return pattern.matcher(specId).matches();
    }

    public static String getPublicKey(String toolId, long toolUid, long wsetUid, long productUid) throws AdmException {
        String pubKey = null;
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetPublicKey);
        drs.setToolId(toolId);
        drs.setToolUid(toolUid);
        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            pubKey = drs.getPublicKey();
        }
        return pubKey;
    }

    public static OauthRequestTokenInfo getRequestToken(long toolUid, long wsetUid, long productUid, String callbackUri) throws AdmException {
        OauthRequestTokenInfo requestTokenInfo = null;
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetRequestToken);
        drs.setToolUid(toolUid);
        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);
        drs.setCallbackUri(callbackUri);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            requestTokenInfo = new OauthRequestTokenInfo(drs.getRequestToken(), drs.getRequestTokenSecret(), drs.getAuthorizationLink());
        }
        return requestTokenInfo;
    }

    /*
    DRS Exception in this case means authorization was failed and AccessToken was not provided
     */
    public static boolean getAccessToken(long toolUid, long wsetUid, long productUid, String requestToken, String requestTokenSecret, String verifierSecret) {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetAccessToken);
        drs.setToolUid(toolUid);
        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);
        drs.setRequestToken(requestToken);
        drs.setRequestTokenSecret(requestTokenSecret);
        drs.setRequestToken(requestToken);
        drs.setVerifierSecret(verifierSecret);
        try {
            DRSUtils.execute(drs);
        } catch (AdmException e) {
            return false;
        }
        return true;
    }

    public static ExtReqPickerProps getExtReqPickerProps(long toolUid, long wsetUid, long productUid) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetExtReqPickerProps);
        drs.setToolUid(toolUid);
        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            return new ExtReqPickerProps(drs.getHomeNameAndUrl(), drs.getNewRequestUrl(), drs.getPulseUrl(), drs.getFilters(), drs.getReportsInfo());
        }
        return null;
    }
    
    public static String[] GetJiraAuthInfo(final long toolUid, final long productUid) throws AdmException {

        int flags = DRSClientIdmUtils.GET_AUTH_FLAG_URL | DRSClientIdmUtils.GET_AUTH_FLAG_CREDS_DATE;
        return GetJiraAuthInfo(toolUid, productUid, flags);
    }
    
    public static String GetJiraAuthCredentialsDate(final long toolUid, final long productUid) throws AdmException {

        String[] result = GetJiraAuthInfo(toolUid, productUid, DRSClientIdmUtils.GET_AUTH_FLAG_CREDS_DATE);
        if (result != null && result.length > 0) {
            return result[0];
        }
        return "";
    }
    
    private static String[] GetJiraAuthInfo(final long toolUid, final long productUid, final int flags)
            throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(DRSClientIdmUtils.IdmUtilsQueryContext.GetJiraAuthInfo);

        drs.setWsetUid(Constants.INVALID_UID);
        drs.setProductUid(productUid);
        drs.setToolUid(toolUid);
        drs.setJiraAuthFlags(flags);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            return drs.getJiraAuthInfo();
        }
        return null;
    }

    public static void testConnection(long toolUid, long wsetUid, long productUid) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.TestConnection);
        drs.setToolUid(toolUid);
        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);
        DRSUtils.execute(drs);
    }

    public static void persistFavoriteReports(long toolUid, long wsetUid, long productUid, List<IDMReport> idmReports, String userName, String activeUUID) throws AdmException {
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.SetFavoriteReports);
        drs.setToolUid(toolUid);
        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);
        drs.setUserName(userName);
        if(idmReports != null && !idmReports.isEmpty()) {
            String[] uuids = new String[idmReports.size()];
            String[] names = new String[idmReports.size()];
            String[] urls = new String[idmReports.size()];
            String[] authors = new String[idmReports.size()];
            String[] createDates = new String[idmReports.size()];
            for(int i = 0; i < idmReports.size(); i++) {
                IDMReport currentReport = idmReports.get(i);
                uuids[i] = currentReport.getId();
                names[i] = currentReport.getDisplayId();
                Object url = currentReport.getAttrValue(AdmAttrNames.IDM_URL);
                if(url instanceof String) {
                    urls[i] = (String) url;
                } else {
                    urls[i] = "";
                }
                Object author = currentReport.getAttrValue(AdmAttrNames.ORIGINATOR);
                if(author instanceof String) {
                    authors[i] = (String) author;
                } else {
                    authors[i] = "";
                }
                Object createDate = currentReport.getAttrValue(AdmAttrNames.CREATE_DATE);
                if(createDate instanceof String) {
                    createDates[i] = (String) createDate;
                } else {
                    createDates[i] = "";
                }
            }
            drs.setUuids(uuids);
            drs.setNames(names);
            drs.setUrls(urls);
            drs.setAuthors(authors);
            drs.setCreateDates(createDates);
            if(activeUUID == null || activeUUID.isEmpty()) {
                drs.setUuid(uuids[0]);
            } else {
                drs.setUuid(activeUUID);
            }
        } else {
            drs.setUuids(new String[] {});
            drs.setNames(new String[] {});
            drs.setUrls(new String[] {});
            drs.setAuthors(new String[] {});
            drs.setCreateDates(new String[] {});
            drs.setUuid(Integer.toString(Constants.INVALID_UID));
        }
        DRSUtils.execute(drs);
    }

    public static List<IDMReport> getFavoriteReports(long toolUid, long wsetUid, long productUid, String userName) throws AdmException {
        List<IDMReport> reportList = new ArrayList<>();
        final DRSClientIdmUtils drs = new DRSClientIdmUtils(IdmUtilsQueryContext.GetFavoriteReports);
        drs.setToolUid(toolUid);
        drs.setWsetUid(wsetUid);
        drs.setProductUid(productUid);
        drs.setUserName(userName);
        DRSUtils.execute(drs);
        if (drs.hasData()) {
            String[] uuids = drs.getUuids();
            String[] names = drs.getNames();
            String[] urls = drs.getUrls();
            String[] authors = drs.getAuthors();
            String[] createDates = drs.getCreateDates();
            int[] flags = drs.getFlags();
            if (uuids == null || names == null || urls == null
                    || authors == null || createDates == null
                    || flags == null || uuids.length == 0) {
                reportList = new ArrayList<IDMReport>();
            } else if (uuids.length == names.length
                    && uuids.length == urls.length
                    && uuids.length == authors.length
                    && uuids.length == createDates.length
                    && uuids.length == flags.length) {
                reportList = new ArrayList<IDMReport>(uuids.length);
                for (int i = 0; i < uuids.length; i++) {
                    IDMReport report = new IDMReport(uuids[i]);
                    report.setAttrValue(AdmAttrNames.IDM_NAME, names[i]);
                    report.setAttrValue(AdmAttrNames.IDM_URL, urls[i]);
                    report.setAttrValue(AdmAttrNames.ORIGINATOR, authors[i]);
                    report.setAttrValue(AdmAttrNames.CREATE_DATE, createDates[i]);
                    report.setAttrValue(AdmAttrNames.IDM_FLAG, flags[i]);
                    reportList.add(report);
                }
            } else {
                throw new AdmException("The returned lists of ExternalRequestReports have different sizes");
            }
        }
        return reportList;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ChdocRelationshipName;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Chdoc Relationship Name.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME{String}<dt><dd>Product name identifier</dd>
 *  <dt>ID {String}<dt><dd>Identifier of the new chdoc relationship name</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>RELNAME_CLASS{Integer}<dt><dd>Chdoc relationship class. Default - INFO_REL_CLASS</dd>
 *  <dt>DESCRIPTION{String}<dt><dd>Chdoc relationship description</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateChdocRelNameCmd extends DBIOCmd {
    public CreateChdocRelNameCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELNAME_CLASS, false, new Integer(Constants.INFO_REL_CLASS), Integer.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        final String productName = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.PRODUCT_NAME));
        final String relName = ValidationHelper.validateChdocRelName((String) getAttrValue(AdmAttrNames.ID));
        final String description = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));
        final Integer relClass = ValidationHelper.validateChdocRelClass((Integer) getAttrValue(AdmAttrNames.RELNAME_CLASS));

        if (!DoesExistHelper.productExists(productName)) {
            throw new DimAlreadyExistsException("Error: product " + productName + " does not exist.");
        }

        if (Constants.RELTYPE_ID_INFO.equalsIgnoreCase(relName) || Constants.RELTYPE_ID_DEPENDENT.equalsIgnoreCase(relName)) {
            throw new AttrException("Error: Relationship name " + relName + " is system defined.");
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + relName);

        if (DoesExistHelper.chdocRelationshipNametExists(productName, relName)) {
            throw new DimAlreadyExistsException("Error: relationship type name " + relName + " is already defined in product "
                    + productName);
        }

        final String userName = AdmCmd.getCurRootObj(User.class).getId();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {

                long relUid = getNewUid(dbCtx);

                // insert relationship object definition
                dbCtx.resetMessage(wcm_sql.CHDOC_RELNAME_INSERT_CPL);
                dbCtx.bindInput(relUid);
                dbCtx.bindInput(relName);
                dbCtx.bindInput(productName);
                dbCtx.bindInput(userName);
                dbCtx.bindInput(description != null ? description : "");
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

                // insert actual relationship
                dbCtx.resetMessage(wcm_sql.CHDOC_RELNAME_INSERT_CA);
                dbCtx.bindInput(relUid);
                dbCtx.bindInput(relName);
                dbCtx.bindInput(relClass.intValue());
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ChdocRelationshipName.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import com.serena.dmnet.drs.DRSClientIsLCStateChangePermitted;
import com.serena.dmnet.drs.DRSClientResetFilesLC;
import com.serena.dmnet.drs.DRSClientUpdateFilesLC;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimLockedException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.LifeCycleState;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate a Stage to a LifeCycleState.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {Stage}<dt><dd>Dimensions Stage object</dd>
 *  <dt>ADM_PARENT_OBJECT {LifeCycleState}<dt><dd>Parent Dimensions LifeCycleState object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadymk
 */
public class RelateStageToLifeCycleStateCmd extends DBIOCmd {
    public RelateStageToLifeCycleStateCmd() throws AttrException {
        super();
        setAlias("RelateStageToLifeCycleStateCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, Stage.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, LifeCycleState.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Stage)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof LifeCycleState)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_BUILDMAN")) {
            throw new DimNoPrivilegeException("ADMIN_BUILDMAN");
        }

        validateAllAttrs();

        // Dimensions stage
        final AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        // Dimensions lifecycle state
        final AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        final boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        final String status = admParentObj.getId();
        final String lifecycleId = ((AdmSpec) admParentObj.getAdmBaseId().getScope()).getSpec();

        // ensure that lifecycle state is already defined
        if (!DoesExistHelper.lifecycleStateExists(lifecycleId, status)) {
            throw new DimNotExistsException("Error: lifecycle status " + status + " is not a valid state for lifecycle "
                    + lifecycleId);
        }

        final String stageId = admObj.getId();
        // sanity checks
        if (!bDeassign) {
            // ensure that stage exists when assigning
            if (!DoesExistHelper.stageExists(stageId)) {
                throw new DimNotExistsException("Error: stage " + stageId + " does not exist.");
            }
        }

        final long stageUid = ((AdmUidObject) admObj).getUid();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {
                if (!isStageChangePermitted(lifecycleId, status, stageUid)) {
                    if (bDeassign) {
                        throw new DimLockedException("Error: stage " + stageId + " cannot be de-assigned from lifecycle state "
                                + status + " as there are buildable items at that state");
                    }
                    throw new DimLockedException("Error: stage " + stageId + " cannot be assigned to lifecycle state " + status
                            + " as there are buildable items at that state");
                }

                if (!bDeassign) {
                    deAssignStageIfAlreadyAssigned(dbCtx, lifecycleId, status);

                    dbCtx.resetMessage(wcm_sql.BUILD_ASSIGN_STAGE_TO_LC_STATE);
                    dbCtx.bindInput(lifecycleId);
                    dbCtx.bindInput(status);
                    dbCtx.bindInput(stageUid);
                    int affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);

                    if (affected == 0) {
                        // this can only happen if some other stage is already assigned to the lifecycle state
                        dbCtx.resetMessage(wcm_sql.BUILD_UPDATE_STAGE_LC_STATE);
                        dbCtx.bindInput(lifecycleId);
                        dbCtx.bindInput(status);
                        dbCtx.bindInput(stageUid);
                        affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                        dbCtx.close(DBIO.DB_DONT_RELEASE);
                        if (affected != 1) {
                            throw new DBIOException("Error: failed to assign stage " + stageId + " to lifecycle state " + status);
                        }
                    }

                    updateItemCatalogue(dbCtx, lifecycleId, status, stageId);
                    updateWorksetFiles(stageId);

                    admParentObj.setAttrValue(AdmAttrNames.STAGE_OBJ, admObj);
                } else {
                    SqlUtils.buildDeassignStageFromLcState(dbCtx, lifecycleId, status, stageUid);
                    int affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);
                    if (affected != 1) {
                        throw new DBIOException("Error: stage " + stageId + " has not been assigned to lifecycle state " + status);
                    }

                    updateItemCatalogue(dbCtx, lifecycleId, status, null);
                    resetWorksetFiles(lifecycleId, status);

                    admParentObj.setAttrValue(AdmAttrNames.STAGE_OBJ, null);
                }
            }

        });

        return new AdmResult("Operation completed");
    }

    private boolean isStageChangePermitted(String lifecycleId, String status, long stageUid) throws Exception {
        DRSClientIsLCStateChangePermitted drs = new DRSClientIsLCStateChangePermitted(DRSUtils.getLCNetClntObject());
        drs.setLifecycleId(lifecycleId);
        drs.setStatus(status);
        drs.setStageUid(stageUid);
        DRSOutputDataExtractor output = new DRSQuery(drs).execute();
        int[] changePermitted = output.getIntValues(DRSParams.PERMITTED);
        if (changePermitted[0] != Constants.PCMS_OK) {
            return true;
        } else {
            return false;
        }
    }

    private void deAssignStageIfAlreadyAssigned(DBIO dbCtx, String lifecycleId, String status) throws Exception {
        dbCtx.resetSQL("SELECT stage_uid FROM stage_lifecycles where lifecycle_id=:I1 and status=:I2");
        dbCtx.bindInput(lifecycleId);
        dbCtx.bindInput(status);
        dbCtx.readStart();
        int assignedStageUid = Constants.INVALID_UID;
        if (dbCtx.read(DBIO.DB_DONT_CLOSE)) {
            assignedStageUid = dbCtx.getInt(1);
        }
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        // De-assign stage if already assigned
        if (assignedStageUid != Constants.INVALID_UID) {
            SqlUtils.buildDeassignStageFromLcState(dbCtx, lifecycleId, status, assignedStageUid);
            dbCtx.write(DBIO.DB_DONT_COMMIT);
            dbCtx.close(DBIO.DB_DONT_RELEASE);

            updateItemCatalogue(dbCtx, lifecycleId, status, null);
            resetWorksetFiles(lifecycleId, status);
        }
    }

    private void updateItemCatalogue(DBIO dbCtx, String lifecycleId, String status, String stageId) throws Exception {
        dbCtx.resetMessage(wcm_sql.UPDATE_IC_LC_STATE_BUILD_STAGE_CHANGE);
        dbCtx.bindInput(stageId, String.class);
        dbCtx.bindInput(lifecycleId);
        dbCtx.bindInput(status);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private void updateWorksetFiles(String stageId) throws AdmException {
        DRSClientUpdateFilesLC drs = new DRSClientUpdateFilesLC(DRSUtils.getLCNetClntObject());
        drs.setStageId(stageId);
        new DRSQuery(drs).execute();
    }

    private void resetWorksetFiles(String lifecycleId, String status) throws AdmException {
        DRSClientResetFilesLC drs = new DRSClientResetFilesLC(DRSUtils.getLCNetClntObject());
        drs.setLifecycleId(lifecycleId);
        drs.setStatus(status);
        new DRSQuery(drs).execute();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ProjectStage;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Project Stage Rels object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author P Smith
 */
public class DeleteProjectStageCmd extends DBIOCmd {
    public DeleteProjectStageCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {

        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ProjectStage)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_BUILDMAN")) {
            throw new DimNoPrivilegeException("ADMIN_BUILDMAN");
        }

        validateAllAttrs();

        final AdmObject projStageObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final long projStageUid = ((AdmUidObject) projStageObj).getUid();

        boolean doCommit = true;
        DBIO query = null;
        try {
            // See whether a stage ref area exists - cannot delete refs if so.
            query = new DBIO(false);
            query.resetMessage(wcm_sql.STAGEREFAREA_EXISTS_BY_UID);
            query.bindInput(projStageUid);
            query.readStart();

            if (query.read()) {
                query.commit();
                throw new AdmException("Error: Cannot delete project stage relationships because an associated build area exists");
            }
            query.commit();

            // Now do the delete
            query = new DBIO(false);
            query.resetMessage(wcm_sql.PROJECT_STAGE_REL_DELETE);
            query.bindInput(projStageUid);

            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return "Operation Completed";
    }
}

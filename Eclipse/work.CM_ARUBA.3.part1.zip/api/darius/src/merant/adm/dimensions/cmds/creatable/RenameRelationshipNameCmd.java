/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.ArrayList;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidLcStateException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.RelationshipName;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will rename a Dimensions RelationshipName object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions RelationshipName object to be renamed</dd>
 *  <dt>ID {String}<dt><dd>New RelationshipName identifier.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class RenameRelationshipNameCmd extends DBIOCmd {
    public RenameRelationshipNameCmd() throws AttrException {
        super();
        setAlias(Creatable.RENAME);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof RelationshipName))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_ITEMRELSMAN")) {
            throw new DimNoPrivilegeException("ADMIN_ITEMRELSMAN");
        }

        validateAllAttrs();
        AdmUidObject admUidObj = (AdmUidObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final String id = ValidationHelper.validateRelName((String) getAttrValue(AdmAttrNames.ID));

        if (id.equals(admUidObj.getId())) {
            throw new DimInvalidLcStateException("Error: The new id name must be different from the old one");
        }

        if (otherRelationshipNameExists(admUidObj.getAdmUid().getUid(), id)) {
            throw new DimAlreadyExistsException("Error: there is another relationship with name " + id);
        }

        final long uid = admUidObj.getUid();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {
                renameRelationshipName(dbCtx, uid, id);
            }
        });

        return "Operation Completed";
    }

    private void renameRelationshipName(DBIO query, long uid, String id) throws DimBaseException, AttrException, Exception {

        SqlUtils.updateRelationship(query, uid, id, null, null);
        query.write(DBIO.DB_DONT_COMMIT);

        SqlUtils.updateCplAttr(query, uid, id);
        query.write(DBIO.DB_DONT_COMMIT);
    }

    private boolean otherRelationshipNameExists(long relUid, String newRelName) throws DBIOException, DimBaseException,
            AdmException {
        ArrayList inputs = new ArrayList();
        inputs.add(new Long(relUid));
        inputs.add(newRelName);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.RELNAME_OTHER_RELNAME_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }
}

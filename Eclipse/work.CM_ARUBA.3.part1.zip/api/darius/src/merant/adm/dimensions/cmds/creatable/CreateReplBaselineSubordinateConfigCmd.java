/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimLockedException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplBlnMasterConfig;
import merant.adm.dimensions.objects.ReplBlnSubordinateConfig;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions subordinate baseline replication configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.REPL_CONFIG_OBJ {ReplBaselineMasterConfig}<dt>
 *      <dd>The master baseline replication configuration object.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.REPL_BASEDB_OBJ {NetBaseDatabase}<dt>
 *  <dd>
 *      A NetBaseDatabase object representing the subordinate site. Any Dimensions site is uniquely identified by
 *      a network node name, database service name, and base database name. This argument must only be set
 *      when defining subordinate sites remote to master configuration. When defining subordinate sites local
 *     to master configuration, this argument will be set automatically to the NetBaseDatabase object representing
 *     the local site.
 *  </dd>
 *  <dt>AdmAttrNames.REPL_IS_ENABLED {Boolean}<dt>
 *  <dd>Whether the replication configuration is to be enabled. Default - Boolean.TRUE</dd>
 *  <dt>AdmAttrNames.REPL_IS_OFFLINE{Boolean}<dt>
 *  <dd>Whether the replication subordinate is offline. Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateReplBaselineSubordinateConfigCmd extends DBIOCmd {

    public CreateReplBaselineSubordinateConfigCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_CONFIG_OBJ, true, ReplBlnMasterConfig.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_BASEDB_OBJ, false, AdmCmd.getCurRootObj(NetBaseDatabase.class),
                NetBaseDatabase.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_ENABLED, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_OFFLINE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_PRODUCT, false, String.class));
        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // extract and validate command arguments
        final AdmObject masterConfigObj = (AdmObject) getAttrValue(AdmAttrNames.REPL_CONFIG_OBJ);
        final AdmObject subordinateSiteObj = (AdmObject) getAttrValue(AdmAttrNames.REPL_BASEDB_OBJ);
        final boolean isEnabled = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_ENABLED)).booleanValue();
        final boolean isOffline = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_OFFLINE)).booleanValue();
        final boolean isReplicatesBack = false;
        final boolean isTransfered = true;

        if (masterConfigObj == null) {
            throw new DimMandatoryAttributeException("Error: master replication configuration must be specified.");
        }
        if (subordinateSiteObj == null) {
            throw new DimMandatoryAttributeException("Error: subordinate site must be specified.");
        }

        // check if master replication configuration exists
        final String configId = masterConfigObj.getId();
        long masterConfigUid = getMasterConfigUid(configId, Constants.REPL_BASELINE_CLASS);
        if (masterConfigUid == -1) {
            throw new DimNotExistsException("Error: master baseline replication configuration " + configId + " does not exist.");
        }

        // check if this master replication configuration is local to the base database we are currently logged on to.
        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        long thisSiteUid = 0;
        if (thisSite != null) {
            thisSiteUid = ((AdmUidObject) thisSite).getUid();
        }

        if (!isLocalReplConfig(null, masterConfigUid, Constants.REPL_BASELINE_CLASS, thisSiteUid)) {
            throw new DimLockedException("Error: remote master baseline replication configuration " + configId
                    + " is not updatable.");
        }

        // check if subordinate site definition exists
        try {
            // this is done to check if the site exists
            long uid = ((AdmUidObject) subordinateSiteObj).getUid();
        } catch (AdmException ae) {
            Debug.error(ae);
            throw new DimNotExistsException("Error: subordinate base database "
                    + subordinateSiteObj.getAttrValue(AdmAttrNames.SENDER_ID) + " does not exist.");
        }

        final String subordinateSiteId = (String) AdmHelperCmd.getAttributeValue(subordinateSiteObj, AdmAttrNames.SENDER_ID);
        final String product = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.REPL_PRODUCT), true);

        // check whether subordinate workset is remote to this base database
        final long subordinateSiteUid = ((AdmUidObject) subordinateSiteObj).getUid();
        final boolean isLocalSubordinate = (subordinateSiteUid == thisSiteUid);

        // do the work
        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws AdmException {

                String revision = getNextConfigRevision(dbCtx, configId, Constants.REPL_BASELINE_CLASS);
                setAttrValue(CmdArguments.INT_SPEC, configId + ";" + revision);

                validateConfigData(dbCtx, configId, revision, subordinateSiteUid, isLocalSubordinate);

                long configUid = getNewUid(dbCtx);
                insertConfigData(dbCtx, configUid, configId, revision, subordinateSiteUid, subordinateSiteId, isEnabled,
                        isTransfered, isReplicatesBack, isOffline, product);

            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ReplBlnSubordinateConfig.class);
        return retResult;
    }

    private void validateConfigData(DBIO dbCtx, String configId, String revision, long subordinateSiteUid,
            boolean isLocalSubordinate) throws AdmException {

        if (replConfigExists(dbCtx, configId, Constants.REPL_BASELINE_CLASS, revision)) {
            throw new DimAlreadyExistsException("Error: configuration name " + configId + " has already been specified.");
        }

        if (isRemoteSubordinateAlreadyDefined(dbCtx, configId, Constants.REPL_BASELINE_CLASS, subordinateSiteUid)) {
            throw new DimAlreadyExistsException("Error: these subordinate site details have already been specified.");
        }
    }

    private boolean isRemoteSubordinateAlreadyDefined(DBIO dbCtx, String configId, int repClass, long baseDbUid)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_SUBORD_CONFIG_IS_ALREADY_DEFINED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(baseDbUid);
        dbCtx.readStart();
        boolean defined = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return defined;
    }

    private boolean replConfigExists(DBIO dbCtx, String configId, int replClass, String revision) throws DBIOException,
            DimBaseException, AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_IS_CONFIG_ALREADY_DEFINED);

        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.bindInput(revision);

        dbCtx.readStart();
        boolean exists = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return exists;
    }

    private String getNextConfigRevision(DBIO dbCtx, String configId, int replClass) throws AdmException {

        String revision = getMaxConfigRevision(dbCtx, configId, replClass);

        if (revision == null) {
            revision = "0";
        } else {
            try {
                int rev = Integer.parseInt(revision);
                revision = new Integer(++rev).toString();
            } catch (NumberFormatException nfe) {
                Debug.error(nfe);
                revision = "0";
            }
        }
        return revision;
    }

    private String getMaxConfigRevision(DBIO dbCtx, String configId, int replClass) throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_GET_MAX_REVISION);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        String lastRevision = (dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getString(1) : null);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return lastRevision;
    }

    private void insertConfigData(DBIO dbCtx, long configUid, String configId, String revision, long subordinateSiteUid,
            String subordinateSiteId, boolean isEnabled, boolean isTransfered, boolean isReplicatesBack, boolean isOffline, String product)
            throws AdmException {

        SqlUtils.replInsertConfig(dbCtx, configUid, configId, Constants.REPL_BASELINE_CLASS, revision, null);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.replInsertConfigDetails(dbCtx, configUid, subordinateSiteUid, product, null, isEnabled, isTransfered, isReplicatesBack,
        		                         subordinateSiteId, null, isOffline);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private long getMasterConfigUid(String configId, int repClass) throws AdmException {

        DBIO dbCtx = new DBIO(wcm_sql.REPL_MASTER_CONFIG_QUERY_UID);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.readStart();
        long configUid = dbCtx.read() ? dbCtx.getLong(1) : -1;
        dbCtx.close();
        return configUid;
    }

    private boolean isLocalReplConfig(DBIO dbCtx, long configUid, int replClass, long siteUid) throws AdmException {

        boolean isOwned = false;
        if (dbCtx != null) {
            dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(replClass);
            dbCtx.bindInput(siteUid);
            dbCtx.readStart();
            isOwned = dbCtx.read(DBIO.DB_DONT_CLOSE);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
        } else {
            dbCtx = new DBIO(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(replClass);
            dbCtx.bindInput(siteUid);
            dbCtx.readStart();
            isOwned = dbCtx.read();
            dbCtx.close();
        }
        return isOwned;
    }

}
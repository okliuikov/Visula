/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will set the current root object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * <br>
 * <b>Returns:</b>
 * <code><dl>
 *  <dt>{void}</dt>
 * </dl></code>
 * @author Floz
 */
public class SetCurRootObjCmd extends AdmCmd {
    public SetCurRootObjCmd() throws AttrException {
        super();
        setAlias(Server.SET_CUR_ROOT_OBJ);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        DimSystem.getSystem().getSessionBean().setCurRootObj((AdmObject) getAttrValue(CmdArguments.ADM_OBJECT));
        return null;
    }
}

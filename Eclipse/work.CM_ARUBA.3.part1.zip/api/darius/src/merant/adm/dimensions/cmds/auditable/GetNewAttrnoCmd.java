/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.auditable;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * A Cmd to get a new valid attribute number
 * @author Vadym Krevs
 */
public class GetNewAttrnoCmd extends DBIOCmd {
    public GetNewAttrnoCmd() throws AttrException {
        super();
        setAlias(Auditable.GET_NEW_ATTRNO);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, false, DBIO.class));
    }

    /**
     * @return number of rows updated.
     */
    @Override
    public Object execute() throws AdmException {
        validateAllAttrs();

        Class typeClass = (Class) getAttrValue(CmdArguments.ADM_OBJECT_CLASS);
        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);

        String typeFlag = TypeUtils.getTypeFlag(typeClass);
        int attrNo = findUnsedAttrNo(query, typeFlag);

        return new Integer(attrNo);
    }

    private int findUnsedAttrNo(DBIO query, String typeFlag) throws DBIOException, AdmObjectException, DimBaseException {

        int attrNo = 0;
        if (query == null) {
            query = new DBIO(wcm_sql.ATTRDEF_FIND_UNUSED_ATTRNO);
            query.bindInput(typeFlag);
            query.readStart(DBIO.DB_IGNORE_REST);
            if (query.read()) {
                attrNo = query.getInt(1);
            }
            query.close();
        } else {
            query.resetMessage(wcm_sql.ATTRDEF_FIND_UNUSED_ATTRNO);
            query.bindInput(typeFlag);
            query.readStart(DBIO.DB_IGNORE_REST);
            if (query.read(DBIO.DB_DONT_CLOSE)) {
                attrNo = query.getInt(1);
            }
            query.close(DBIO.DB_DONT_RELEASE);
        }

        return attrNo;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetNode;
import merant.adm.dimensions.objects.NetNodeConnection;
import merant.adm.dimensions.objects.NetObject;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions NetNodeConnection object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>NETCLIENTNODE {String}</dt><dd>Specification of the client NetNode</dd>
 *  <dt>NETSERVERNODE {String}</dt><dd>Specification of the server NetNode</dd>
 *  <dt>NETWORKOBJECT {String}</dt><dd>Specification of the scoped NetObject</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>NETCODESET {String}</dt><dd>Specification of the optional NetCodeSet</dd>
 *  <dt>NETFILESYSTEM {String}</dt><dd>Specification of the optional NetFileSys</dd>
 *  <dt>NETNODECONNECTION_DIRECT_FILE_COPY {Boolean}</dt><dd>direct file copy between nodes</dd>
 *  <dt>NETNODECONNECTION_FILE_COMPRESSION {Boolean}</dt><dd>file compression in file transfer between nodes</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateNetNodeConnectionCmd extends RPCExecCmd {
    public CreateNetNodeConnectionCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(CmdArguments.NETCLIENTNODE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.NETSERVERNODE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.NETWORKOBJECT, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.NETCODESET, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.NETFILESYSTEM, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODECONNECTION_DIRECT_FILE_COPY, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETNODECONNECTION_FILE_COMPRESSION, false, Boolean.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String netClientNodeSpec = (String) getAttrValue(CmdArguments.NETCLIENTNODE);
        String netServerNodeSpec = (String) getAttrValue(CmdArguments.NETSERVERNODE);
        String netObjectSpec = (String) getAttrValue(CmdArguments.NETWORKOBJECT);
        String netCodeSetSpec = (String) getAttrValue(CmdArguments.NETCODESET);
        String netFileSysSpec = (String) getAttrValue(CmdArguments.NETFILESYSTEM);
        Boolean directFileCopy = (Boolean) getAttrValue(AdmAttrNames.NETNODECONNECTION_DIRECT_FILE_COPY);
        Boolean fileCompression = (Boolean) getAttrValue(AdmAttrNames.NETNODECONNECTION_FILE_COMPRESSION);

        // Construct the new NetNodeConnection object with
        // Server Node, Client Node & Network Object as scopes
        // and a combination of the aforementioned uids-as-strings
        // for the spec. Complex? Yup-sorry, but dimensions is...
        AdmUidObject netServerNode = (AdmUidObject) AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(netServerNodeSpec,
                NetNode.class));
        AdmUidObject netClientNode = (AdmUidObject) AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(netClientNodeSpec,
                NetNode.class));
        AdmUidObject netObject = (AdmUidObject) AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(netObjectSpec, NetObject.class));
        String netServerNodeUid = String.valueOf(netServerNode.getAdmUid().getUid());
        String netClientNodeUid = String.valueOf(netClientNode.getAdmUid().getUid());
        String netObjectUid = String.valueOf(netObject.getAdmUid().getUid());
        String spec = netServerNodeUid + " " + netClientNodeUid + " " + netObjectUid;
        AdmBaseId admBaseId = AdmHelperCmd.newAdmBaseId(spec, NetNodeConnection.class);
        admBaseId.add(netServerNode.getAdmBaseId());
        admBaseId.add(netClientNode.getAdmBaseId());
        admBaseId.add(netObject.getAdmBaseId());

        _cmdStr = "CNC ";
        _cmdStr += " /CLIENT_NAME=\"" + netClientNodeSpec + "\"";
        _cmdStr += " /SERVER_NAME=\"" + netServerNodeSpec + "\"";
        _cmdStr += " /NWO_NAME=\"" + netObjectSpec + "\"";
        if (netCodeSetSpec != null && netCodeSetSpec.length() > 0) {
            _cmdStr += " /CDST_NUMBER=\"" + netCodeSetSpec + "\"";
        }
        if (netFileSysSpec != null && netFileSysSpec.length() > 0) {
            _cmdStr += " /FS_NAME=\"" + netFileSysSpec + "\"";
        }

        _cmdStr += (directFileCopy != null && directFileCopy.booleanValue()) ? " /DIRECT_FILE_COPY" : " /NODIRECT_FILE_COPY";

        _cmdStr += (fileCompression != null && fileCompression.booleanValue()) ? " /FILE_COMPRESSION" : " /NOFILE_COMPRESSION";

        return new AdmResult(executeRpc(), admBaseId);
    }
}

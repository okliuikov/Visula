/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for creatable commands.
 * <p>
 * This applies to any dimensions object that can be created into the system.
 * @author Floz
 */
public interface Creatable {
    public static final String CREATE = "Creatable.Create";
    public static final String GET_OBJECT = "Creatable.GetObject";
    public static final String GET_OBJECTS = "Creatable.GetObjects";
    public static final String PRIME = "Creatable.Prime";
    public static final String QUERY_DEFAULTS = "Creatable.QueryDefaults";
    public static final String RENAME = "Creatable.Rename";
    public static final String MOVE_PATH = "Creatable.MovePath";
    public static final String MOVE_ITEM_TYPE = "Creatable.MoveItemType";
    public static final String SET_WORKSET_FILENAME = "Creatable.SetWorksetFilename";
    public static final String CREATE_SCHEDULED_JOB = "Creatable.CreateScheduledJob";
}

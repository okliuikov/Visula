/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Customer.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name of the new customer</dd>
 *  <dt>CUSTOMER_LOCATION {String}</dt><dd>Location of the new customer</dd>
 *  <dt>CUSTOMER_PROJECT {String}</dt><dd>Project of the new customer</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>COMMENT {String}</dt><dd>Comment of the new customer</dd>
 *  <dt>CUSTOMER_CONTACT {String}</dt><dd>Contact of the new customer</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateCustomerCmd extends RPCExecCmd {
    public CreateCustomerCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CUSTOMER_LOCATION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CUSTOMER_PROJECT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CUSTOMER_CONTACT, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String location = (String) getAttrValue(AdmAttrNames.CUSTOMER_LOCATION);
        String project = (String) getAttrValue(AdmAttrNames.CUSTOMER_PROJECT);
        String comment = (String) getAttrValue(AdmAttrNames.COMMENT);
        String contact = (String) getAttrValue(AdmAttrNames.CUSTOMER_CONTACT);

        setAttrValue(CmdArguments.INT_SPEC, "\"" + id + "\", \"" + location + "\", \"" + project + "\"");
        _cmdStr = "CCU " + Encoding.escapeDMCLI(id);
        _cmdStr += " /LOCATION=" + Encoding.escapeDMCLI(location);
        _cmdStr += " /PROJECT=" + Encoding.escapeDMCLI(project);
        _cmdStr += (comment != null && comment.length() > 0) ? (" /COMMENT=" + Encoding.escapeDMCLI(comment)) : "";
        _cmdStr += (contact != null && contact.length() > 0) ? (" /CONTACT=" + Encoding.escapeDMCLI(contact)) : "";

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Customer.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.assignable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Group;
import merant.adm.dimensions.objects.ProfileAssignment;
import merant.adm.dimensions.objects.ProfileDefinition;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will assign or deassign groups from a user.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * <dt>ADM_OBJECT {AdmObject}<dt><dd>User to assign groups to</dd>
 * <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Groups to assign or deassign from user</dd>
 * <dt>REMOVE {Boolean}<dt><dd>Flag to determine whether to assign or deassign groups from a user</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt><dt><dd></dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Peter Bate
 */
public class AssignProfileDefinitionCmd extends DBIOCmd {

    public AssignProfileDefinitionCmd() throws AttrException {
        super();
        setAlias(Assignable.ASSIGN_PROFILE_DEFINITION);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ProfileDefinition)) {
                throw new AttrException("AssignProfileDefinitionCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof User) && !(attrValue instanceof Group)) {
                throw new AttrException("AssignProfileDefinitionCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UI_PROFILES")) {
            throw new DimNoPrivilegeException("ADMIN_UI_PROFILES");
        }
        validateAllAttrs();

        AdmObject profileDef = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject userGroup = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        Boolean remove = (Boolean) getAttrValue(CmdArguments.REMOVE);

        String profileId = profileDef.getId();
        String userGroupId = userGroup.getId();
        long profileUid = Constants.INVALID_UID;
        long userGroupUid = Constants.INVALID_UID;
        long assignType = Constants.INVALID_UID;

        String queryStr = "select obj_uid from profile_catalogue where obj_id=:I1";
        DBIO query = new DBIO(queryStr);
        query.bindInput(profileId);
        query.readStart();
        if (query.read()) {
            profileUid = query.getLong(1);
        }

        if (userGroup instanceof User) {
            queryStr = "select user_uid from users_profile where user_name=:I1";
            assignType = Constants.USER_CLASS;
        } else {
            queryStr = "select group_uid from group_catalogue where group_name=:I1";
            assignType = Constants.GROUP_CLASS;
        }
        query.resetSQL(queryStr);
        query.bindInput(userGroupId);
        query.readStart();
        if (query.read()) {
            userGroupUid = query.getLong(1);
        }

        if (remove.booleanValue()) {
            query.resetMessage(wcm_sql.DEASSIGN_PROFILE);
            query.bindInput(profileUid);
            query.bindInput(userGroupUid);
        } else {
            // Start DEF95839 : 12th June 2006 Dinesh
            // Check whether the profile is already assigned to the user/group or not.
            queryStr = "SELECT 'X' FROM profile_assignments WHERE profile_uid = :I1 AND assign_uid = :I2 AND assign_type = :I3";
            query.resetSQL(queryStr);
            query.bindInput(profileUid);
            query.bindInput(userGroupUid);
            query.bindInput(assignType);
            query.readStart();
            if (query.read()) {
                // profile is already allocated to the user/group
                throw new DimAlreadyExistsException("\'" + userGroupId + "\' has already been assigned the profile \'" + profileId
                        + "\'");
            }
            // End DEF95839 :

            query.resetMessage(wcm_sql.ASSIGN_PROFILE);
            query.bindInput(profileUid);
            query.bindInput(userGroupUid);
            query.bindInput(assignType);
        }

        query.write();
        query.commit();

        AdmResult retResult = new AdmResult("Operation Completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ProfileAssignment.class);
        return retResult;
    }
}

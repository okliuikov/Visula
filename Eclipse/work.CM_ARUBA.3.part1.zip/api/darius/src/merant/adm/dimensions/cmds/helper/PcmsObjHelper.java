package merant.adm.dimensions.cmds.helper;

import com.serena.dmnet.drs.DRSClientInitUid;

import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.PcmsObj;
import merant.adm.exception.AdmException;

public class PcmsObjHelper {

    public static String querySpecByUid(long uid, int objType, long wsetUid) throws AdmException {

        DRSClientInitUid drs = new DRSClientInitUid();
        drs.setObjUid(uid);
        drs.setObjType(objType);
        drs.setWsetUid(wsetUid);

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            StringBuffer spec = new StringBuffer();
            spec.append(drs.getObjectProductId());
            spec.append(":");
            spec.append(drs.getObjectId());
            if (drs.getObjectVariant() != null && drs.getObjectVariant().length() > 0) {
                spec.append(".");
                spec.append(drs.getObjectVariant());
            }
            if (drs.getObjectTypeName() != null && drs.getObjectTypeName().length() > 0) {
                spec.append("-");
                spec.append(drs.getObjectTypeName());
            }
            if (drs.getObjectRevision() != null && drs.getObjectRevision().length() > 0) {
                spec.append(";");
                spec.append(drs.getObjectRevision());
            }
            return spec.toString();
        }
        return null;
    }

    public static PcmsObj queryByUid(long uid, int objType, long wsetUid) throws AdmException {
        DRSClientInitUid drs = new DRSClientInitUid();
        drs.setObjUid(uid);
        drs.setObjType(objType);
        drs.setWsetUid(wsetUid);

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            PcmsObj ret = new PcmsObj();
            ret.setObjUid(drs.getObjectUid());
            ret.setObjSpecUid(drs.getObjectSpecUid());
            ret.setObjType(drs.getObjectType());
            ret.setTypeUid(drs.getObjectTypeUid());
            ret.setProductId(drs.getObjectProductId());
            ret.setObjId(drs.getObjectId());
            ret.setVariant(drs.getObjectVariant());
            ret.setTypeName(drs.getObjectTypeName());
            ret.setRevision(drs.getObjectRevision());
            ret.setDescription(drs.getObjectDescription());
            ret.setUserName(drs.getObjectUserName());
            ret.setStatus(drs.getObjectStatus());
            ret.setDateTime(drs.getObjectDateTime());
            // Is Extracted is an int representing a character Y or N
            char c = (char) drs.getObjectIsExtracted();
            if (c == 'Y') {
                ret.setIsExtracted(true);
            } else {
                ret.setIsExtracted(false);
            }

            return ret;
        }
        return null;
    }

}

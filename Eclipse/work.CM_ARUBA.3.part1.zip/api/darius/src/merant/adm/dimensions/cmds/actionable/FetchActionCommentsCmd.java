/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.IOException;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.TempFileInputStream;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will fetch the current set of Dimensions object action comments.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ROLE_CHECK {Boolean}<dt><dd>Determines whether a role check should be performed
 * before retrieving the aciton description.</dd>
 *  <dt>LAST_ACTION_COMMENT {Boolean}<dt><dd>Determines whether the last action description or the committed ation description should be queried.
 * Default value: TRUE
 *   * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>USER_FILE {String}<dt><dd>User filename.  If not provided, returned as a String</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Tim Payne
 */
public class FetchActionCommentsCmd extends RPCExecCmd {
    public FetchActionCommentsCmd() throws AttrException {
        super();
        setAlias(Actionable.FETCH_COMMENTS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ROLE_CHECK, true, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.LAST_ACTION_COMMENT, false, Boolean.TRUE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument)) {
                throw new AttrException("Error: FetchActionCommentsCmd Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        Object result = null;
        String tmpResult = null;

        try {
            validateAllAttrs();
            AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
            Boolean roleCheck = (Boolean) getAttrValue(CmdArguments.ROLE_CHECK);
            String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
            Boolean last = (Boolean) getAttrValue(CmdArguments.LAST_ACTION_COMMENT);

            StringBuffer buff = null;
            String tmpfile = null;

            if (admObj instanceof ChangeDocument) {
                // * XDATA has replaced the old DATA command
                buff = new StringBuffer("XDATA \"FETCH_DBFILE\" /PARAMETER=(");
                buff.append("CLASS=CHDOC, ");
                if (last.booleanValue()) {
                    buff.append("ATTR=10001, ");
                } else {
                    buff.append("ATTR=10002, ");
                }
                buff.append("UID=" + ((AdmUidObject) admObj).getAdmUid() + ", ");
                if ((userFile != null) && (userFile.length() > 0)) {
                    buff.append("USER_FILENAME=" + Encoding.escapeDMCLI(userFile));
                } else {
                    tmpfile = TempFileInputStream.getTempFileName();
                    buff.append("USER_FILENAME=" + Encoding.escapeDMCLI(tmpfile));
                }

                if (roleCheck.booleanValue()) {
                    buff.append(", ROLE_CHECK=Y");
                } else {
                    buff.append(", ROLE_CHECK=N");
                }

                buff.append(")");

                _cmdStr = new String(buff);

                tmpResult = executeRpc();

                if (tmpfile != null) {
                    result = TempFileInputStream.readAsString(tmpfile);
                }
            }
        } catch (DimBaseCmdException dbce) {
            // Exceptions are rethrown to translate error messages into
            // meaningful exceptions
            DimSystem.getSystem().getExceptionHandler().throwException(dbce.toString());
        } catch (IOException ioException) {
            throw new AdmException(ioException);
        }
        return result;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.Library;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

import java.util.List;

/**
 * This command will create a Dimensions library.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Product Id for the library</dd>
 *  <dt>ID {String}<dt><dd>Item type for the library</dd>
 *  <dt>LIBRARY_PATH {String}<dt><dd>Location of the library</dd>
 *  <dt>LIBRARY_NODE_NAME {String}<dt><dd>To which computer and file system the library is applicable</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>LIBRARY_IS_DELTA {Boolean}<dt><dd>Whether the library will hold delta archives</dd>
 *  <dt>LIB_PROTECTION {String}<dt><dd>Protection code for the items library directory</dd>
 *  <dt>UPDATE {Boolean}<dt><dd>Whether the library definition is being altered</dd>
 *  <dt>REMOVE {Booelan}<dt><dd>Whether the library definition is being removed</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Stephen Sitton, Vadym Krevs
 */
public class CreateLibraryCmd extends RPCExecCmd {

    public static final String NO_CREDENTIAL_SET = ".";

    public CreateLibraryCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIBRARY_PATH, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIBRARY_IS_DELTA, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIBRARY_NODE_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIB_PROTECTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
        // Internal arguments
        setAttrDef(new CmdArgDef(AdmAttrNames.LIBRARY_IS_DEFAULT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIBRARY_CREDSET_ID, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        String productId = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.PRODUCT_NAME));
        String itemType = ValidationHelper.validateItemTypeId((String) getAttrValue(AdmAttrNames.ID));
        String library = ValidationHelper.validateLibraryPath((String) getAttrValue(AdmAttrNames.LIBRARY_PATH));
        String networkNode = ValidationHelper.validateNetworkNode((String) getAttrValue(AdmAttrNames.LIBRARY_NODE_NAME));
        String protection = ValidationHelper.validateLibraryProtection((String) getAttrValue(AdmAttrNames.LIB_PROTECTION));
        String credentialSet = (String) getAttrValue(AdmAttrNames.LIBRARY_CREDSET_ID);

        boolean delta = ((Boolean) getAttrValue(AdmAttrNames.LIBRARY_IS_DELTA)).booleanValue();
        boolean update = ((Boolean) getAttrValue(CmdArguments.UPDATE)).booleanValue();
        boolean remove = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();
        boolean isDefault = ((Boolean) getAttrValue(AdmAttrNames.LIBRARY_IS_DEFAULT)).booleanValue();

        if (update && remove) {
            throw new DimInvalidAttributeException("Error: cannot specify both UPDATE and REMOVE arguments");
        }

        setAttrValue(CmdArguments.INT_SPEC, productId + ':' + itemType);
        if (isDefault && !"*".equals(itemType)) {
            itemType = "*";
        }

        StringBuffer cmdBuf = new StringBuffer("DPL ");
        cmdBuf.append(Encoding.escapeDMCLI(productId));
        cmdBuf.append(" /ITEM_TYPE=").append(Encoding.escapeDMCLI(itemType));
        cmdBuf.append(" /LIBRARY=").append(Encoding.escapeDMCLI(library));
        cmdBuf.append(" /NETWORK_NODE=").append(Encoding.escapeDMCLI(networkNode));
        if (protection != null && protection.length() > 0) {
            cmdBuf.append(" /PROTECTION=").append(Encoding.escapeDMCLI(protection));
        }
        if (delta) {
            cmdBuf.append(" /DELTA");
        }
        if (update) {
            cmdBuf.append(" /UPDATE");
        }
        if (remove) {
            cmdBuf.append(" /DELETE");
        }
        if (credentialSet != null && !credentialSet.isEmpty()) {
            cmdBuf.append(" /CREDENTIAL_SET=").append(Encoding.escapeDMCLI(credentialSet));
        }

        _cmdStr = cmdBuf.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Library.class);
        return retResult;
    }
}

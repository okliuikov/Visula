/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2002 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.versionable;

import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimDirItemNotSupportedException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Performs a merge on a set of Items (allowing full control).
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object - the primary revision in the merge</dd>
 *  <dt>REVISION_LIST {List}</dt><dd>List of other revision IDs (Strings) in the merge</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename of the object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>COMMENT {String}<dt><dd>User comment of the object</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>Specifies change documents to relate</dd>
 *  <dt>REVISION {String}<dt><dd>The new revision to check out</dd>
 *  <dt>KEEP {Boolean}<dt><dd>Should a copy of this file be kept</dd>
 *  <dt>PROJECT {String}<dt><dd>Specification of he project where the merge should take place. If not set, the default project is used.</dd>
 *  <dt>CONTENT_ENCODING {String}</dt><dd>Content encoding to be used when creating new revision</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>The result</dd>
 * </dl></code>
 * @author David Conneely
 */
public class MergeItemCmd extends RPCExecCmd {
    public MergeItemCmd() throws AttrException {
        super();
        setAlias(Versionable.MERGE_ITEM);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REVISION_LIST, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REVISION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CONTENT_ENCODING, false, String.class));

        // merge into existing revision if target value is true.
        setAttrDef(new CmdArgDef(CmdArguments.SELF, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.REVISION_LIST)) {
            List revs = (List) attrValue;
            if (revs == null || revs.size() == 0) {
                throw new AttrException("Error: No revisions have been specified to be merged.", attrDef, attrValue);
            }
        }
    }

    private boolean isMergeIntoSelfRevision;
    private AdmObject admObj;

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();

        admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        if (admObj instanceof ItemFile) // check for directory items
        {
            String path = ((ItemFile) admObj).getFileName();
            if (path != null && CmdUtils.isDirPath(path)) {
                throw new DimDirItemNotSupportedException();
            }
        } else if (!(admObj instanceof Item)) {
            throw new IllegalArgumentException("Merge Item only supports Items");
        }

        String userFilename = (String) getAttrValue(CmdArguments.USER_FILE);
        List revList = (List) getAttrValue(CmdArguments.REVISION_LIST);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        String revision = (String) getAttrValue(CmdArguments.REVISION);
        boolean keep = ((Boolean) getAttrValue(CmdArguments.KEEP)).booleanValue();
        isMergeIntoSelfRevision = false;
        Object selfObj = getAttrValue(CmdArguments.SELF);
        if (selfObj != null && selfObj instanceof Boolean) {
            isMergeIntoSelfRevision = ((Boolean) selfObj).booleanValue();
        }

        String project = (String) getAttrValue(AdmAttrNames.PROJECT);
        String encoding = (String) getAttrValue(CmdArguments.CONTENT_ENCODING);

        _cmdStr = "MI ";
        _cmdStr += Encoding.escapeSpec(admObj.getAdmSpec().getSpec());

        if (!isMergeIntoSelfRevision) {
            _cmdStr += " /USER_FILENAME=" + Encoding.escapeSpec(userFilename);
        }

        _cmdStr += makeRevisionList(revList);

        if (comment != null) {
            _cmdStr += " /COMMENT=" + Encoding.escapeSpec(comment);
        }

        if ((revision != null) && (revision.length() > 0)) {
            _cmdStr += " /REVISION=" + Encoding.escapeSpec(revision);
        }

        if ((chdocs != null) && (chdocs.length() > 0)) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
        }

        _cmdStr += (keep) ? " /KEEP" : "";

        if (project != null && project.length() > 0) {
            _cmdStr += " /WORKSET=" + Encoding.escapeSpec(project);
        }

        if (encoding != null && encoding.length() > 0) {
            _cmdStr += " /CONTENT_ENCODING=" + Encoding.escapeSpec(encoding);
        }

        _cmdStr += " " + AttributeDefinition.getAttrsCmdStringFromCmd(this);

        if (isMergeIntoSelfRevision) {
            _cmdStr += " /SELF";
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        // Get the base identifier for the new revision
        AdmResult ret = new AdmResult(executeRpc());
        if (!isMergeIntoSelfRevision) {
            AdmCmd.populateBaseIdFromAdmResult(this, ret, admObj.getClass());
            if (ret.getUserData() == null) {
                Debug.println("Floz: MergeItemCmd.execute()");
                Debug.println("      Unable to obtain new item revision base identifier");
            }
        }
        return ret;
    }

    /**
     * Converts a list of String revision IDs into the correct Dimensions qualifier.
     */
    private String makeRevisionList(List revList) {
        StringBuffer sb = new StringBuffer(" /REVISION_LIST=(");
        boolean needComma = false;
        for (Iterator it = revList.iterator(); it.hasNext();) {
            if (needComma) {
                sb.append(',');
            }
            String rev = (String) it.next();
            sb.append(Encoding.escapeSpec(rev));
            needComma = true;
        }
        sb.append(')');
        return sb.toString();
    }
}

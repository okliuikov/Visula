package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.exception.AdmException;
import merant.adm.framework.Cmd;

public class UserPrefsHelper {

    public static void setUserPrefs(User user, Integer userPrefsType, Map<String, String> prefs) throws AdmException {
        user.setAttrValue(AdmAttrNames.USER_PREFS, prefs);
        List<String> attrNames = new ArrayList<String>();
        attrNames.add(AdmAttrNames.USER_PREFS);

        Cmd cmd = AdmCmd.getCmd(WithAttrs.UPDATE, user);
        cmd.setAttrValue(CmdArguments.USER_PREF_TYPE, userPrefsType);
        cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        cmd.execute();
    }

    public static Map<String, String> getUserPrefs(User user, Integer userPrefsType) throws AdmException {
        List<String> attrNames = new ArrayList<String>();
        attrNames.add(AdmAttrNames.USER_PREFS);

        Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, user);
        cmd.setAttrValue(CmdArguments.USER_PREF_TYPE, userPrefsType);
        cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrNames);
        return (Map<String, String>) cmd.execute();
    }
}

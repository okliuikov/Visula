/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.PrivilegeRule;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will assign or deassign users/groups/roles to or from a privilege rule.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Privilege Rule object</dd>
 * <dt>PRIVILEGE_RULE_ASSIGN {Boolean}<dt><dd>Flag to determine whether to assign or deassign from a privilege rule</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 * <dt>PRIVILEGE_RULE_PRODUCT (String)<dt>The uid of a product level privilege<dd></dd>
 * <dt>PRIVILEGE_RULE_ASSIGN_LIST (List)<dt>List of users/groups/roles to assign or deassign from the privilege rule<dd></dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code> Created 2005-08-12.
 * @author Paul Smith
 */
public class AssignPrivilegeRuleCmd extends RPCExecCmd {

    public AssignPrivilegeRuleCmd() throws AttrException {
        super();
        setAlias(Assignable.ASSIGN_PRIVILEGE_RULE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_RULE_ASSIGN, true, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_RULE_PRODUCT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_RULE_ASSIGN_LIST, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_ID, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof PrivilegeRule)) {
                throw new AttrException("AssignPrivilegeRuleCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject privilegeRule = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        String privId = (String) AdmHelperCmd.getAttributeValue(privilegeRule, AdmAttrNames.PRIVILEGE_ID);
        String ruleId = (String) AdmHelperCmd.getAttributeValue(privilegeRule, AdmAttrNames.ID);
        String product = (String) getAttrValue(AdmAttrNames.PRIVILEGE_RULE_PRODUCT);
        String assignModeStr = (String) AdmHelperCmd.getAttributeValue(privilegeRule, AdmAttrNames.PRIVILEGE_RULE_RELATED_TYPE);
        long assignMode = (new Long(assignModeStr)).longValue();

        Boolean assign = (Boolean) getAttrValue(AdmAttrNames.PRIVILEGE_RULE_ASSIGN);
        List assignList = (List) getAttrValue(AdmAttrNames.PRIVILEGE_RULE_ASSIGN_LIST);

        String project = (String) getAttrValue(AdmAttrNames.PROJECT_NAME);
        String stage = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        String area = (String) getAttrValue(AdmAttrNames.AREA_ID);

        StringBuffer sb = new StringBuffer();

        sb.append("PRIV ");
        sb.append(Encoding.escapeSpec(privId));
        sb.append(" /RULE=" + Encoding.escapeSpec(ruleId));

        if (product != null && !product.equals("")) {
            sb.append(" /PRODUCT=");
            sb.append(Encoding.escapeSpec(product));
        }

        if (assignList != null && assignList.size() > 0) {
            // Users or groups
            if (assignMode == (Constants.USER_CLASS | Constants.GROUP_CLASS)) {
                sb.append(" /USERS=");
            }
            // Roles
            else if (assignMode == Constants.ROLE_CLASS) {
                sb.append(" /ROLES=");
            }
            sb.append("(");
            String assignName = "";

            for (int i = 0; i < assignList.size(); i++) {
                assignName = (String) assignList.get(i);
                if (i > 0) {
                    sb.append(",");
                }
                sb.append(Encoding.escapeSpec(assignName));
            }
            sb.append(")");
        }

        if (assign.booleanValue()) {
            sb.append(" /ADD");
        } else {
            sb.append(" /DELETE");
        }

        if (project != null) {
            sb.append(" /WORKSET=");
            sb.append(Encoding.escapeSpec(project));
        }

        if (stage != null) {
            sb.append(" /STAGE=");
            sb.append(Encoding.escapeSpec(stage));
        }

        if (area != null) {
            sb.append(" /AREA=");
            sb.append(Encoding.escapeSpec(area));
        }

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, PrivilegeRule.class);
        return retResult;
    }
}

/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import com.serena.dmnet.RFScanResult;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Return the specified attributes of directory entries in the specified remote directory.
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>areaPath {String}</dt>
 *      <dd>
 *          Remote directory to be read. The specification of this remote directory can
 *          take one of the following forms:
 *          <pre>AREA_NAME::area_relative_path</pre> or
 *          <pre>NETWORK_NODE::absolute_path</pre>.
 *          For example, the following are examples of valid paths:
 *          stal-dev-lx1::/tmp/ws_dev_unix, stal-dev-vk2::E:\Dimensions\,
 *          DM10-LINUX-DEV::build, DM10-WINDOWS-UT::java_build\darius
 *      </dd>
 *  <dt>flags {int}</dt>
 *      <dd>
 *          bit mask of RFScan.RF_SCAN_AREA_FLAGS
 *          values controlling execution of this RPC
 *      </dd>
 *  <dt>attrNos {int[]}</dt>
 *      <dd>
 *          array of attribute numbers whose values are to be returned
 *          for each directory entry
 *      </dd>
 * </dl></code> <b>Optional Arguments:</b> <code><dl>
 *  <dt>inclusionPatterns {String[]}</dt>
 *      <dd>
 *          array of inclusion patterns. Only such paths that match
 *          at least one inclusion patterns will be considered.
 *      </dd>
 *  <dt>exclusionPatterns {String[]}</dt>
 *      <dd>
 *          array of exclusion patterns. Only such paths that match none
 *          of the exclusion patterns will be considered.
 *      </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{RFScanResult}<dt>
 *  <dd>
 *      an object containing status, error codes and an array of arrays of attribute values
 *      for each processed directory entry. That is, for N processed directory entries, the
 *      returned array will be of length N, and each element of this array will be an array
 *      of attrNos.length attribute values for the corresponding processed directory entry.
 *      The order of attribute values for each directory entry follows the order of attribute
 *      numbers in the attrNos array.
 *  </dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class RPCScanAreaCmd extends RPCCmd {

    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCScanAreaCmd() throws AttrException {
        super();
        setAlias("RPCScanAreaCmd");
        AddArgument("cmd", "RPCScanAreaCmd");
        setAttrDef(new CmdArgDef("areapath", true, "", "", ""));
        setAttrDef(new CmdArgDef("flags", true, "", "", ""));
        setAttrDef(new CmdArgDef("attrnos", true, "", "", ""));
        setAttrDef(new CmdArgDef("inclusionpatterns", false, "", "", ""));
        setAttrDef(new CmdArgDef("exclusionpatters", false, "", "", ""));
    }

    @Override
    public Object execute() throws DimConnectionException {

        try {
            Object inclusion = getAttrValue("inclusionpatterns");
            Object exclusion = getAttrValue("exclusionpatters");
            RFScanResult result = getSession().getConnection().rpcRFScanArea((String) getAttrValue("areapath"),
                    ((Integer) getAttrValue("flags")).intValue(), (int[]) getAttrValue("attrnos"),
                    (((inclusion != null) && (inclusion instanceof String[])) ? (String[]) inclusion : null),
                    (((exclusion != null) && (exclusion instanceof String[])) ? (String[]) exclusion : null));

            return result;
        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}
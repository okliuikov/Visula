/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Collection;
import java.util.List;
import java.util.Vector;

import com.serena.dmnet.drs.DRSClientUploadProjectQueries;
import com.serena.dmnet.drs.DRSClientUploadProjectQueries.UploadProjectQueryContext;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.exception.DimDatabaseConnectException;
import merant.adm.dimensions.exception.DimInvalidPropertyException;
import merant.adm.dimensions.exception.MessageFileNotFoundException;
import merant.adm.dimensions.exception.MessageNotFoundException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.UploadEnvironment;
import merant.adm.dimensions.objects.UploadProject;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all UploadProject's related to the UploadEnvironment object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Floz
 */
public class QCUplEnvToUplProjCmd extends QueryRelsCmd {
    public QCUplEnvToUplProjCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(AdmAttrNames.GET_ALL_UPLOAD_RULE_SETS, false, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UploadEnvironment)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(UploadProject.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();
        String extension = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.EXTENSION);

        // Add the default project
        String filterId = null;
        String filterSpec = null;
        boolean hasFilter = false;
        if (filter != null) {
            Collection criteria = filter.criteria();
            if (!criteria.isEmpty()) {
                Object[] objs = criteria.toArray();
                FilterCriterion filterCrit = (FilterCriterion) objs[0];

                if (filterCrit.getAttrName().equals(AdmAttrNames.ID)) {
                    filterId = (String) filterCrit.getValue();
                    hasFilter = true;
                } else if (filterCrit.getAttrName().equals(AdmAttrNames.ADM_SPEC)) {
                    filterSpec = (String) filterCrit.getValue();
                    hasFilter = true;
                }
            }
        }

        if (extension != null && filterSpec != null && filterSpec.indexOf(";" + extension) == -1) {
            // filter spec contains different extension
            return null;
        }

        final String globalWsetSpec = Constants.GLOBAL_WSET_SPEC + ";" + extension;
        if (!hasFilter || Constants.GLOBAL_ID.equals(filterId) || globalWsetSpec.equals(filterSpec)) {
            addRelation(ret, relationships, admObj.getAdmBaseId(),
                    AdmHelperCmd.newAdmBaseId(Constants.GLOBAL_WSET_SPEC + ";" + extension, admSecClass, admObj.getAdmBaseId()));
        }

        // Get a list of products and add them as UploadProjects...
        // this assumes they exist
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurRootObj(BaseDatabase.class));
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Product.class);
        // cmd.setAttrValue(CmdArguments.FILTER, filter);
        List prodObjs = AdmHelperCmd.getObjects((List) cmd.execute());

        String filterProductId = null;
        if (filterId != null) {
            filterProductId = filterId;
        } else if (filterSpec != null) {
            // YC: e.g. $GENERIC:QLARIUS;mrg-4213926
            filterProductId = filterSpec.substring(filterSpec.indexOf(":") + 1);
            filterProductId = filterProductId.substring(0, filterProductId.lastIndexOf(";"));
        }

        for (int i = 0; i < prodObjs.size(); ++i) {
            AdmObject prodObj = (AdmObject) prodObjs.get(i);
            String productId = prodObj.getId();
            if (!productId.equals(Constants.GLOBAL_PRODUCT)) { // "$GENERIC:$GLOBAL;mrg" has been added above,
                if (!hasFilter || productId.equals(filterProductId)) {
                    long uid = ((AdmUidObject) prodObj).getAdmUid().getUid();
                    String identifier = extension + "-" + uid;
                    if (doesProdDefaultExist("$$" + identifier)) {
                        addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(Constants.GLOBAL_PRODUCT
                                + ":" + productId + ";" + identifier, admSecClass));
                    }
                }
            }
        }

        boolean getAllRuleSets = true;

        if (getAttrValue(AdmAttrNames.GET_ALL_UPLOAD_RULE_SETS) != null) {
            getAllRuleSets = (Boolean) getAttrValue(AdmAttrNames.GET_ALL_UPLOAD_RULE_SETS);
        }

        String filterProjectId = filterId;

        DRSClientUploadProjectQueries drs = new DRSClientUploadProjectQueries(DRSUtils.getLCNetClntObject(),
                UploadProjectQueryContext.QueryUploadProjectSpec);
        drs.setExtension(extension);
        drs.setId(filterProjectId);
        drs.setFilterSpec(filterSpec);
        drs.setGetAllRuleSets(getAllRuleSets);

        DRSOutputDataExtractor output = new DRSQuery(drs).execute();

        if (!output.isResultEmpty()) {
            String[] uplProjSpecs = output.getStringValues(DRSParams.UPLOAD_PROJ_SPEC);
            for (int i = 0; i < uplProjSpecs.length; i++) {
                addRelation(ret, relationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(uplProjSpecs[i], admSecClass));
            }
        }

        return ret;
    }

    private boolean doesProdDefaultExist(String identifier) throws MessageFileNotFoundException, MessageNotFoundException,
            DimDatabaseConnectException, DimInvalidPropertyException, DBIOException, AdmObjectException, DimConnectionException {
        DBIO query = new DBIO(wcm_sql.DOES_PROD_RULE_EXIST);
        query.bindInput(identifier);
        query.readStart(DBIO.DB_IGNORE_REST);
        if (query.read(DBIO.DB_IGNORE_REST)) {
            return true;
        }
        return false;

    }

}

/*
 * Copyright (C) 2006 Serena Software Europe, Ltd. All rights reserved.
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidRuleException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.FileAreaFilter;
import merant.adm.dimensions.objects.FileAreaFilterRule;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions FileAreaFilterRule.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new file area filter</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author Floz
 */
public class CreateFileAreaFilterRuleCmd extends DBIOCmd {

    public CreateFileAreaFilterRuleCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);

        // rename attribute:
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_FILTER_OBJ, true, FileAreaFilter.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_FILTER_RULE_SEQ, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RULE_TYPE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.FILE_PATTERN, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE, false, Type.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.FORMAT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_FILTER_RULE_PART, false, Part.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_FILTER_RULE_RECURSE_PART, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // rename attribute:
        FileAreaFilter faf = (FileAreaFilter) getAttrValue(AdmAttrNames.AREA_FILTER_OBJ);
        Integer seq = (Integer) getAttrValue(AdmAttrNames.AREA_FILTER_RULE_SEQ);
        String ruleType = (String) getAttrValue(AdmAttrNames.RULE_TYPE);
        String filePattern = (String) getAttrValue(AdmAttrNames.FILE_PATTERN);
        Type type = (Type) getAttrValue(AdmAttrNames.TYPE);
        Part part = (Part) getAttrValue(AdmAttrNames.AREA_FILTER_RULE_PART);
        Long typeUid = null;
        if (type != null) {
            typeUid = new Long(type.getAdmUid().getUid());
        }
        String format = (String) getAttrValue(AdmAttrNames.FORMAT);
        Boolean recurse = (Boolean) getAttrValue(AdmAttrNames.AREA_FILTER_RULE_RECURSE_PART);
        Long partUid = null;
        if (part != null) {
            partUid = new Long(part.getAdmUid().getUid());
        }

        if ((null == filePattern || 0 == filePattern.length()) && (null == format || 0 == format.length()) && null == type
                && null == part) {
            throw new DimInvalidRuleException(
                    "file path pattern, data format, design part and item type cannot be all empty.  At least one of the attributes must be set");
        }

        if (ruleType == null) {
            ruleType = "I";
        } else if (!ruleType.equals("I") && !ruleType.equals("E")) {
            throw new DimInvalidRuleException(
                    "Error: area filter rules must be of RULE_TYPE 'I' or 'E' for inclusions or exclusions.");
        }
        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        DBIO query;
        // may need updating:
        if (seq == null) {
            query = new DBIO(wcm_sql.FILEAREAFILTERRULE_MAXSEQ);
            query.bindInput(faf.getAdmUid().getUid());
            query.readStart();
            if (query.read()) {
                seq = new Integer(query.getInt(1) + 1);
            } else {
                seq = new Integer(1);
            }
        }
        query = new DBIO(wcm_sql.FILEAREAFILTERRULE_CREATE);
        query.bindInput(faf.getAdmUid().getUid());
        query.bindInput(ruleType);
        query.bindInput(seq.intValue());
        query.bindInput(typeUid, Long.class);
        query.bindInput(format, String.class);
        query.bindInput(filePattern, String.class);
        query.bindInput(partUid, Long.class);
        query.bindInput(((recurse != null && recurse.booleanValue()) ? "Y" : "N"), String.class);
        query.write();
        query.commit();

        setAttrValue(CmdArguments.INT_SPEC, filePattern);
        AdmResult retResult = new AdmResult("Operation completed.");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, FileAreaFilterRule.class);
        return retResult;
    }
}
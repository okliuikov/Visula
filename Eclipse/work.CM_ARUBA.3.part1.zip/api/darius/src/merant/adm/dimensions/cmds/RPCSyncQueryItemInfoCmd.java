/*
 * -----------------------------------------------------------------------------
 * Copyright (c) 2008 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import com.serena.dmfile.ItemMetadata;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class RPCSyncQueryItemInfoCmd extends RPCCmd {
    public RPCSyncQueryItemInfoCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("SyncQueryItemInfo");
        // AddArgument("cmd","SyncQueryItemInfo");
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, true, WorkSet.class));
        setAttrDef(new CmdArgDef("localMetadatas", false, ItemMetadata[].class));
        setAttrDef(new CmdArgDef("remoteMetadatas", false, ItemMetadata[].class));
    }

    @Override
    public Object execute() throws AdmException {
        ItemMetadata[] result = null;
        try {
            WorkSet ws = (WorkSet) getAttrValue(CmdArguments.WORKSET);
            result = getSession().getConnection().rpcSyncQueryItemInfo((int) ws.getUid(),
                    (ItemMetadata[]) getAttrValue("localMetadatas"), (ItemMetadata[]) getAttrValue("remoteMetadatas"));

        } catch (AttrException e) {
            return Constants.SERVER_FAIL;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return result;
    }

}

package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;

public class CountActiveUsersInDBCmd extends DBIOCmd {
    public CountActiveUsersInDBCmd() throws AttrException {
        super();
        setAlias("CountActiveUsersInDBCmd");
    }

    // @Override
    @Override
    public Object execute() throws DBIOException, AdmException {
        long count = 0;
        DBIO query = new DBIO(wcm_sql.COUNT_ACTIVE_USERS_IN_DB);
        query.readStart();
        while (query.read()) {
            count = query.getLong(1);
        }
        return Long.valueOf(count);
    }
}

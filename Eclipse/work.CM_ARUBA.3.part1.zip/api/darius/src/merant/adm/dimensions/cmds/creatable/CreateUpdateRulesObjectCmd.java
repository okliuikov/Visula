/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.UpdateRulesObject;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * THIS COMMAND IS FOR INTERNAL USE ONLY!
 * This command will create a Dimensions UpdateRulesObject for a Dimensions object type.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>TYPE{AdmObject}<dt><dd>Dimensions Type object for which the update rules object is to be created</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateUpdateRulesObjectCmd extends DBIOCmd {
    public CreateUpdateRulesObjectCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE, true, Type.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject typeObj = (AdmObject) getAttrValue(AdmAttrNames.TYPE);
        long typeUid = ((AdmUidObject) typeObj).getAdmUid().getUid();
        List attrs = AdmHelperCmd.getAttributeValues(typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        String productName = (String) attrs.get(0);
        String typeName = (String) attrs.get(1);
        Class typeClass = (Class) attrs.get(2);
        String typeFlag = TypeUtils.getTypeFlag(typeClass);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

        if (!DoesExistHelper.typeExists(productName, typeName, typeFlag)) {
            throw new DimAlreadyExistsException("Error: Dimensions " + TypeUtils.getClassName(typeClass) + "Type " + productName
                    + ":" + typeName + " does not exist");
        }

        setAttrValue(CmdArguments.INT_SPEC, productName + ":CM_AUR_" + typeName);

        if (DoesExistHelper.updateRuleObjectExists(typeUid, typeFlag)) {
            throw new DimAlreadyExistsException("Error: attribute update rule object already exists for " + "Dimensions "
                    + TypeUtils.getClassName(typeClass) + "Type " + productName + ":" + typeName);
        }

        long ruleUid = getNewUid();

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);
            createAttribRulesObject(query, ruleUid, productName, typeFlag, typeName, typeUid);
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, UpdateRulesObject.class);
        return retResult;
    }

    private long createAttribRulesObject(DBIO query, long ruleUid, String productName, String typeFlag, String typeName,
            long typeUid) throws AdmObjectException, DBIOException, DimBaseException {

        int objClass = 1;
        char scope = typeFlag.charAt(0);

        if (scope == 'C') {
            objClass = 1;
        } else if (scope == 'I') {
            objClass = 50;
        } else if (scope == 'P') {
            objClass = 51;
        } else if (scope == 'B') {
            objClass = 53;
        } else if (scope == 'U') {
            objClass = 54;
        } else if (scope == 'W') {
            objClass = 61;
        }

        String userId = ((User) AdmCmd.getCurRootObj(User.class)).getId();
        query.resetMessage(wcm_sql.ATTRRULE_INSERT);
        query.bindInput(ruleUid);
        query.bindInput("CM_AUR_" + typeName);
        query.bindInput(objClass);
        query.bindInput(productName);
        query.bindInput(userId);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.attrruleRelateToType(query, typeUid, ruleUid, objClass);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        return ruleUid;

    }
}

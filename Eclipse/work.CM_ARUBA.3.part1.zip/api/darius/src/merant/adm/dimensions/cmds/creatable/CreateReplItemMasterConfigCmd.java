/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.drs.DRSClientSysObjAttrUtils;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplItemMasterConfig;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions master item replication configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.ID {String}<dt><dd>Identifier of the new master item replication configuration</dd>
 *  <dt>AdmAttrNames.REPL_WORKSET_ID{String}<dt><dd>The specification of the project from which item branches are to be replicated to the subordinates</dd>
 *  <dt>CmdArguments.BRANCHES{List}<dt><dd>The list of Branch objects on the above project that are to be replicated</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.DESCRIPTION{String}<dt><dd>Description</dd>
 *  <dt>AdmAttrNames.REPL_IS_ENABLED{Boolean}<dt><dd>Whether the replication configuration is to be enabled. Default - Boolean.TRUE</dd>
 *  <dt>AdmAttrNames.REPL_IS_OFFLINE{Boolean}<dt><dd>Whether the replication configuration is offline. Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateReplItemMasterConfigCmd extends DBIOCmd {
    public CreateReplItemMasterConfigCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_WORKSET_ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_ENABLED, true, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_OFFLINE, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // extract and validate command arguments
        // extract command parameters

        final String configId = ValidationHelper.validateReplConfigId((String) getAttrValue(AdmAttrNames.ID));
        final String description = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));

        final List branchList = (List) getAttrValue(CmdArguments.BRANCHES);
        final boolean isEnabled = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_ENABLED)).booleanValue();
        final boolean isOffline = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_OFFLINE)).booleanValue();
        final boolean isTransfered = true;
        final boolean isReplicatesBack = false;

        String tempSpec = ValidationHelper.validateWorksetSpec((String) getAttrValue(AdmAttrNames.REPL_WORKSET_ID));
        AdmObject projectObj = getProjectObj(tempSpec);
        if (projectObj == null) {
            throw new DimNotExistsException("Error: project " + tempSpec + " does not exist.");
        }

        final String projectSpec = projectObj.getAdmSpec().getSpec();

        if (branchList != null && branchList.size() > 0) {
            for (Iterator it = branchList.iterator(); it.hasNext();) {
                AdmObject branch = (AdmObject) it.next();
                if (branch == null || !(branch instanceof Branch)) {
                    throw new DimMandatoryAttributeException("Error: list of branches to be replicated must be specified.");
                }
            }
        }

        setAttrValue(CmdArguments.INT_SPEC, configId + ";0");
        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        final long thisSiteUid = (thisSite != null) ? ((AdmUidObject) thisSite).getUid() : 0;
        final String thisSiteId = (thisSite != null) ? (String) AdmHelperCmd.getAttributeValue(thisSite, AdmAttrNames.SENDER_ID) : "";
        // do the work
        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws AdmException {
                validateConfigData(dbCtx, configId, projectSpec, thisSiteUid);
                long configUid = getNewUid(dbCtx);
                insertConfigData(dbCtx, configUid, configId, description, projectSpec, isEnabled, isTransfered, isReplicatesBack,
                        isOffline, thisSiteUid, thisSiteId);

                if (branchList != null && branchList.size() > 0) {
                    validateBranchData(dbCtx, configId, branchList);
                    insertBranchData(dbCtx, configUid, branchList);
                }
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ReplItemMasterConfig.class);
        return retResult;
    }

    private AdmObject getProjectObj(String projectSpec) throws AdmException {

        if (projectSpec == null) {
            return null;
        }

        AdmObject projectObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(projectSpec, WorkSet.class));
        boolean projectExists = true;
        try {
            long projectUid = ((AdmUidObject) projectObj).getUid();
            if (projectUid <= 0) {
                projectExists = false;
            }
        } catch (AdmException e) {
            Debug.error(e);
            projectExists = false;
        }
        return (projectExists ? projectObj : null);
    }

    private void validateConfigData(DBIO dbCtx, String configId, String projectSpec, long thisSiteUid) throws AdmException {

        if (masterReplConfigExists(dbCtx, configId, Constants.REPL_ITEM_CLASS)) {
            throw new DimAlreadyExistsException("Error: the replication configuration " + configId + " has already been defined.");
        }

        String revision = getMaxConfigRevision(dbCtx, configId, Constants.REPL_ITEM_CLASS);
        if (revision != null) {
            throw new DimAlreadyExistsException("Error: the replication configuration " + configId + " has already been defined.");
        }

        if (isAlreadyDefined(dbCtx, configId, Constants.REPL_ITEM_CLASS, thisSiteUid, projectSpec)) {
            throw new DimAlreadyExistsException("Error: these replication details have already been specified.");
        }
    }

    private boolean isAlreadyDefined(DBIO dbCtx, String configId, int repClass, long baseDbUid, String projectId)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_ALREADY_DEFINED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(baseDbUid);
        dbCtx.bindInput(projectId);
        dbCtx.readStart();
        boolean defined = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return defined;
    }

    private boolean masterReplConfigExists(DBIO dbCtx, String configId, int replClass) throws DBIOException, DimBaseException,
            AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_MASTER_CONFIG_DOES_EXIST);

        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        boolean exists = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return exists;
    }

    private String getMaxConfigRevision(DBIO dbCtx, String configId, int replClass) throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_GET_MAX_REVISION);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        String lastRevision = (dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getString(1) : null);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return lastRevision;
    }

    private void insertConfigData(DBIO dbCtx, long configUid, String configId, String description, String projectSpec,
            boolean isEnabled, boolean isTransfered, boolean isReplicatesBack, boolean isOffline, long baseDbUid, String siteId)
            throws AdmException {

        if (baseDbUid == -1) {
            throw new DimInvalidAttributeException("Error: base database name " + siteId + " is not valid for replication.");
        }

        SqlUtils.replInsertConfig(dbCtx, configUid, configId, Constants.REPL_ITEM_CLASS, "0", description);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.replInsertConfigDetails(dbCtx, configUid, baseDbUid, null, projectSpec, isEnabled, isTransfered, isReplicatesBack, siteId, null, isOffline);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private boolean isSpecialBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_IS_SPECIAL_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private boolean isBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_IS_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private void validateBranchData(DBIO dbCtx, String configId, List branchList) throws AdmException {

        validateBranchList(dbCtx, branchList);

        for (Iterator it = branchList.iterator(); it.hasNext();) {
            AdmObject branchObj = (AdmObject) it.next();
            String branchName = branchObj.getId();

            // check if this branch has already been defined for this replication config
            boolean isAssigned = false;
            if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)) {
                isAssigned = isSpecialBranchAssigned(dbCtx, Constants.REPL_ALL_LOCAL_BRANCHES_UID, configId, "0",
                        Constants.REPL_ITEM_CLASS);
            } else if (branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
                isAssigned = isSpecialBranchAssigned(dbCtx, Constants.REPL_ALL_NAMED_BRANCHES_UID, configId, "0",
                        Constants.REPL_ITEM_CLASS);
            } else {
                long branchUid = getBranchUid(dbCtx, branchName);
                isAssigned = isBranchAssigned(dbCtx, branchUid, configId, "0", Constants.REPL_ITEM_CLASS);
            }

            if (isAssigned) {
                throw new DimAlreadyExistsException("Error: the branch name " + branchName
                        + "is already defined for configuration " + configId + ".");
            }

        }
    }

    private void insertBranchData(DBIO dbCtx, long configUid, List branchList) throws AdmException {

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        for (Iterator it = branchList.iterator(); it.hasNext();) {
            AdmObject branchObj = (AdmObject) it.next();
            String branchName = branchObj.getId();

            long relUid = getNewUid(dbCtx);
            long branchUid = getBranchUid(dbCtx, branchName);
            if (branchUid == -1) {
                throw new DimNotExistsException("Error: branch " + branchName + " does not exist.");
            }

            SqlUtils.replAssignBranchToConfig(dbCtx, relUid, configUid, branchUid, userName);
            dbCtx.write(DBIO.DB_DONT_COMMIT);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
        }
    }

    private void validateBranchList(DBIO dbCtx, List branchList) throws AdmException {
        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        long thisSiteUid = 0;
        if (thisSite != null) {
            thisSiteUid = ((AdmUidObject) thisSite).getUid();
        } 

        if (thisSiteUid <= 0) {
            Debug.println("CreateReplItemMasterConfigCmd.validateBranchList: thisSiteUid = " + thisSiteUid);
        }
        Cmd cmd = AdmCmd.getCmd("_internal_validate_branch_list");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, dbCtx);
        cmd.setAttrValue(CmdArguments.BRANCHES, branchList);
        cmd.execute();
    }

    private long getBranchUid(DBIO dbCtx, String branchName) throws AdmException {
        long branchUid = -1;
        if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_LOCAL_BRANCHES_UID;
        } else if (branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_NAMED_BRANCHES_UID;
        } else {
            DRSClientSysObjAttrUtils drs = new DRSClientSysObjAttrUtils(DRSClientSysObjAttrUtils.SysObjAttrUtilsQueryContext.GetAdmUids);
            drs.setObjClass(DRSClientSysObjAttrUtils.SYSOBJ_NAMED_BRANCH);
            drs.setAdmId(branchName);
            DRSUtils.execute(drs);

            if (drs.hasData() && (drs.getAdmUids() != null) && (drs.getAdmUids().length > 0)) {
            	branchUid = drs.getAdmUids()[0];
            }
        }

        return branchUid;
    }
}

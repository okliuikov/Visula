/*
 * -----------------------------------------------------------------------------
 * Copyright (c) 2008 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class RPCCmRulesCmd extends RPCCmd {
    public RPCCmRulesCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("RPC CmRules");
        AddArgument("cmd", "PcmsCmRulesCommand");
        setAttrDef(new CmdArgDef("wsUid", true, Long.class));
        setAttrDef(new CmdArgDef("itemUids", true, int[].class));
        setAttrDef(new CmdArgDef("itemSpecUids", false, null, int[].class));
        setAttrDef(new CmdArgDef("specs", false, null, String[].class));
        setAttrDef(new CmdArgDef("operationCode", true, int[].class));
        setAttrDef(new CmdArgDef("states", false, null, String[].class));
        setAttrDef(new CmdArgDef("numRequests", false, null, int[].class));
        setAttrDef(new CmdArgDef("requests", false, null, String[].class));
        setAttrDef(new CmdArgDef("reasons", false, null, int[].class));
    }

    @Override
    public Object execute() throws AdmException {

        int[] requestReqd = null;
        try {

            requestReqd = getSession().getConnection().rpcCmRules(((Long) getAttrValue("wsUid")).intValue(),
                    (int[]) getAttrValue("itemUids"), (int[]) getAttrValue("itemSpecUids"), (String[]) getAttrValue("specs"),
                    (int[]) getAttrValue("operationCode"), (String[]) getAttrValue("states"), (int[]) getAttrValue("numRequests"),
                    (String[]) getAttrValue("requests"), (int[]) getAttrValue("reasons"));

        } catch (AttrException e) {
            return Constants.SERVER_FAIL;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return requestReqd;
    }

}

package merant.adm.dimensions.cmds.helper;

import merant.adm.dimensions.server.drs.objects.FileVersion;
import merant.adm.dimensions.server.drs.objects.FileVersionHandler;

class SingleFileVersionHandler implements FileVersionHandler {

    private FileVersion singleFileVersion;

    @Override
    public void handleFileVersion(FileVersion version) {
        this.singleFileVersion = version;
    }

    public FileVersion getSingleFileVersion() {
        return singleFileVersion;
    }
}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014 Serena. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.serena.dmnet.LCNetClnt;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.exception.DimInvalidEmailDetailsException;
import merant.adm.dimensions.server.objects.EmailMessage;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will allow you to send emails using standard Dimensions facilities.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>COMMAND {String}<dt><dd>The command-line to execute</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * 
 * @author David Conneely
 */
public class RPCSendEmailCmd extends RPCExecCmd {
    public RPCSendEmailCmd() throws AttrException {
        super();
        setAlias("RPCSendEmailCmd");
        AddArgument("cmd", "RPCSendEmailCmd");
        setAttrDef(new CmdArgDef(CmdArguments.EMAIL_MESSAGES, true, List.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.EMAIL_MESSAGES)) {
            @SuppressWarnings("unchecked")
            List<EmailMessage> emailMessages = (List<EmailMessage>) attrValue;
            if (emailMessages == null) {
                throw new AttrException("Error: email message list is null", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        try {
            @SuppressWarnings("unchecked")
            List<EmailMessage> emailMessages = (List<EmailMessage>) getAttrValue(CmdArguments.EMAIL_MESSAGES);
            String[] toRecipientLists = new String[emailMessages.size()];
            String[] ccRecipientLists = new String[emailMessages.size()];
            String[] bccRecipientLists = new String[emailMessages.size()];
            String[] subjects = new String[emailMessages.size()];
            String[] contentTypes = new String[emailMessages.size()];
            List<byte[]> messageBodies = new ArrayList<byte[]>();

            int i = 0;
            for (EmailMessage em : emailMessages) {

                List<String> toRecipients = em.getToRecipients();
                List<String> ccRecipients = em.getCcRecipients();
                List<String> bccRecipients = em.getBccRecipients();
                String recipientList = formatRecipients(toRecipients);
                String ccrecipientList = formatRecipients(ccRecipients);
                String bccrecipientList = formatRecipients(bccRecipients);

                if ((recipientList == null || recipientList.isEmpty()) && (ccrecipientList == null || ccrecipientList.isEmpty())
                        && (bccrecipientList == null || bccrecipientList.isEmpty())) {
                    throw new DimInvalidEmailDetailsException("Email recipient list is missing.");
                }

                if (em.getSubject() == null || em.getSubject().isEmpty()) {
                    throw new DimInvalidEmailDetailsException("Email subject is missing.");
                }

                byte[] messageData = em.getMessageData();
                if (messageData == null || messageData.length == 0) {
                    throw new DimInvalidEmailDetailsException("Email body is missing.");
                }

                if (em.getContentType() == null || em.getContentType().isEmpty()) {
                    throw new DimInvalidEmailDetailsException("Email content type is missing.");
                }

                toRecipientLists[i] = recipientList;
                ccRecipientLists[i] = ccrecipientList;
                bccRecipientLists[i] = bccrecipientList;
                subjects[i] = em.getSubject();
                contentTypes[i] = em.getContentType();
                messageBodies.add(messageData);
                ++i;
            }

            LCNetClnt con = getSession().getConnection();
            con.rpcSendEmail(toRecipientLists, ccRecipientLists, bccRecipientLists, subjects, messageBodies, contentTypes);
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return null;
    }

    private static String formatRecipients(List<String> toRecipients) {
        if (toRecipients == null || toRecipients.isEmpty()) {
            return "";
        }

        StringBuffer buf = null;
        for (String s : toRecipients) {
            if (buf != null) {
                buf.append(',');
            }
            if (buf == null) {
                buf = new StringBuffer();
            }
            buf.append(s);
        }
        return buf == null ? "" : buf.toString();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.serena.dmnet.RPC;
import com.serena.dmnet.drs.DRSClientExpandRevisions;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Returns all item revisions for a list of given item revisions
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT_LIST {AdmObject}<dt><dd>List of Item objects</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Restricts the result to item revisions that are part of this workset</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>List of AdmBaseIds for all Item objects</dd>
 * </dl></code>
 * @author abollmann
 */
public class ExpandRevisionsCmd extends DBIOCmd {

    public ExpandRevisionsCmd() throws AttrException {
        super();
        setAlias(Versionable.CHECK_IN);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        Set result = new LinkedHashSet(); // ensure uniqueness on output
        List uids = new ArrayList();

        List itemList = (List) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        WorkSet workset = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        for (int i = 0; i < itemList.size(); i++) {
            AdmObject item = (AdmObject) itemList.get(i);
            AdmBaseId baseId = item.getAdmBaseId();
            Long uid = new Long(baseId.toString());
            uids.add(uid);
        }

        // Prepare DRS query
        DRSClientExpandRevisions drsClientExpandRevisions = new DRSClientExpandRevisions(DRSUtils.getLCNetClntObject());
        long wsetUid = Constants.INVALID_UID;
        drsClientExpandRevisions.setUidList(convertObjectArrayTolongArray(uids.toArray()));
        if (workset != null) {
            wsetUid = workset.getUid();
        } else {
            wsetUid = 1;
        }
        drsClientExpandRevisions.setWorksetUid(wsetUid);
        DRSQuery drsQuery = new DRSQuery(drsClientExpandRevisions);
        DRSOutputDataExtractor drsOutputDataExtractor = drsQuery.execute();

        if (drsOutputDataExtractor.hasRPCExecutionFailed()) {
            throw new DRSException("Error during call of DRS function " + DRSClientExpandRevisions.dataRequestId + " via RPC("
                    + RPC.RPC_DATA_REQUEST + ")");
        } else if (!drsOutputDataExtractor.isResultEmpty()) {
            // get the uid as well
            int[] itemUid = drsOutputDataExtractor.getIntValues(DRSParams.OBJ_UIDS);
            String[] itemSpec = drsOutputDataExtractor.getStringValues(DRSParams.ITEM_SPECS);
            for (int i = 0; i < itemUid.length; i++) {
                AdmBaseId baseId = AdmHelperCmd.newAdmBaseId(itemSpec[i], ItemFile.class, null,
                        AdmHelperCmd.newAdmBaseId(itemUid[i], ItemFile.class, null, null));
                result.add(baseId);
            }
        }
        // convert the result set to a list
        List retList = new ArrayList(result.size());
        for (Iterator resit = result.iterator(); resit.hasNext();) {
            retList.add(resit.next());
        }
        return retList;
    }

    private long[] convertObjectArrayTolongArray(Object[] objArray) {
        long[] longArr = new long[objArray.length];
        for (int i = 0; i < objArray.length; i++) {
            longArr[i] = ((Long) objArray[i]).longValue();
        }
        return longArr;
    }

}

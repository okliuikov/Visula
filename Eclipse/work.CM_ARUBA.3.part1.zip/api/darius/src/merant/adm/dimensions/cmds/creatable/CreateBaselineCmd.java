/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2001 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.creatable;

import java.util.List;

import com.serena.dmfile.VersionedProperties;
import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.withbody.BodyCmdUtils;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Baseline.
 * <p>
 * Updated in March 2003 to represent both the CBL and CRB command lines.<br>
 * The deterministic factor that decides whether a CBL or a CRB occurs is the inclusion of the BASELINE argument. If this is null,
 * CBL is used, if this is not null then CRB is assumed. If CBL is used and the OWNING_PART argument has been included, it is
 * assumed that a Design Part Baseline is being created. If the OWNING_PART argument is ommitted for a CBL, it is assumed that a
 * Project Baseline is being created, so if the WORKSET argument is also ommitted an exception will be thrown. <b>Mandatory
 * Arguments (Create Design Part Baseline):</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Identifier of the new baseline</dd>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of container for the new baseline</dd>
 *  <dt>OWNING_PART {AdmObject(Part)}</dt><dd>The owning part to relate the baseline to</dd>
 * </dl></code> <br>
 * <b>Optional Arguments (Create Design Part Baseline):</b> <code><dl>
 *  <dt>CANCEL_TRAVERSE {Boolean}</dt><dd>If true, indicates that traversal of tree structures is not to be performed</dd>
 *  <dt>INCLUDE_CLOSED {Boolean}</dt><dd>If true, indicates that relationships to closed change documents are included when CBL from a change document</dd>
 *  <dt>INCLUDE_INFO {Boolean}</dt><dd>If true, indicates that Info relationships to items are included when CBL from a change document</dd>
 *  <dt>LEVEL {String}</dt><dd>The part level that applies to this baseline</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of change documents to be related</dd>
 *  <dt>TEMPLATE {String}</dt><dd>User template</dd>
 *  <dt>TYPE_NAME {String}</dt><dd>Type name for the new baseline</dd>
 *  <dt>WORKSET {AdmObject(WorkSet)}</dt><dd>Project that this baseline is created from</dd>
 * </dl></code> <br>
 * <b>Mandatory Arguments (Create Project Baseline):</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Identifier of the new baseline</dd>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of container for the new baseline</dd>
 *  <dt>WORKSET {AdmObject(WorkSet)}</dt><dd>Project that this baseline is created from</dd>
 * </dl></code> <br>
 * <b>Optional Arguments (Create Project Baseline):</b> <code><dl>
 *  <dt>CANCEL_TRAVERSE {Boolean}</dt><dd>If true, indicates that traversal of tree structures is not to be performed</dd>
 *  <dt>INCLUDE_CLOSED {Boolean}</dt><dd>If true, indicates that relationships to closed change documents are included when CBL from a change document</dd>
 *  <dt>INCLUDE_INFO {Boolean}</dt><dd>If true, indicates that Info relationships to items are included when CBL from a change document</dd>
 *  <dt>LEVEL {String}</dt><dd>The part level that applies to this baseline</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of change documents to be related</dd>
 *  <dt>RELATED_REQUIREMENTS {String}<dt><dd>List of requirements to be related</dd>
 *  <dt>TEMPLATE {String}</dt><dd>User template</dd>
 *  <dt>TYPE_NAME {String}</dt><dd>Type name for the new baseline</dd>
 * </dl></code> <br>
 * <b>Mandatory Arguments (Create Revised Baseline):</b> <code><dl>
 *  <dt>BASELINE {AdmObject(Baseline)}</dt><dd>Existing Baseline to revise</dd>
 *  <dt>ID {String}</dt><dd>Identifier of the new baseline</dd>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of container for the new baseline</dd>
 * </dl></code> <br>
 * <b>Optional Arguments (Create Revised Baseline):</b> <code><dl>
 *  <dt>CANCEL_TRAVERSE {Boolean}</dt><dd>If true, indicates that traversal of tree structures is not to be performed</dd>
 *  <dt>REMOVE_CHDOCS {List(ChangeDocument)}</dt><dd>Identifies ChangeDocument traversal to locate Items related as Affected</dd>
 *  <dt>TYPE_NAME {String}</dt><dd>Type name for the new baseline</dd>
 *  <dt>UPDATE_CHDOCS {List(ChangeDocument)}</dt><dd>Identifies ChangeDocument traversal to locate Items related in-Response-to</dd>
 *  <dt>WORKSET {AdmObject(WorkSet)}</dt><dd>Project that this baseline is created with respect to</dd>
 *  <dt>REMOVE_REQUIREMENTS {List(Requirement)}</dt><dd>Identifies Requirement
 *      traversal to locate Items related as Affected</dd>
 *  <dt>UPDATE_REQUIREMENTSS {List(Requirement)}</dt><dd>Identifies Requirement
 *      traversal to locate Items related in-Response-to</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateBaselineCmd extends RPCExecCmd {
    public CreateBaselineCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REVISION_PROPERTIES, false, VersionedProperties.class));
        setAttrDef(new CmdArgDef(CmdArguments.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET_VERSION, false, Integer.class));
        setAttrDef(new CmdArgDef(CmdArguments.CANCEL_TRAVERSE, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.INCLUDE_CLOSED, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.INCLUDE_INFO, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.LEVEL, false, "0", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.OWNING_PART, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE_CHDOCS, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.TEMPLATE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE_CHDOCS, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_REQUIREMENTS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE_REQUIREMENT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE_REQUIREMENT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.STARTING_BASELINE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILTER, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILE_LIST, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.BASELINE)) {
            if ((attrValue != null) && (!(attrValue instanceof Baseline))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.OWNING_PART)) {
            if ((attrValue != null) && (!(attrValue instanceof Part))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.WORKSET)) {
            if ((attrValue != null) && (!(attrValue instanceof WorkSet))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        VersionedProperties properties = (VersionedProperties) getAttrValue(CmdArguments.REVISION_PROPERTIES);
        Integer worksetVersion = (Integer) getAttrValue(CmdArguments.WORKSET_VERSION);
        AdmObject baseline = (AdmObject) getAttrValue(CmdArguments.BASELINE);
        Boolean cancelTraverse = (Boolean) getAttrValue(CmdArguments.CANCEL_TRAVERSE);
        Boolean includeClosed = (Boolean) getAttrValue(CmdArguments.INCLUDE_CLOSED);
        Boolean includeInfo = (Boolean) getAttrValue(CmdArguments.INCLUDE_INFO);
        String level = (String) getAttrValue(CmdArguments.LEVEL);
        AdmObject owningPart = (AdmObject) getAttrValue(CmdArguments.OWNING_PART);
        List removeChdocs = (List) getAttrValue(CmdArguments.REMOVE_CHDOCS);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        String template = (String) getAttrValue(CmdArguments.TEMPLATE);
        String description = (String) getAttrValue(CmdArguments.DESCRIPTION);
        String typeName = (String) getAttrValue(AdmAttrNames.TYPE_NAME);
        List updateChdocs = (List) getAttrValue(CmdArguments.UPDATE_CHDOCS);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        String startingBaseline = (String) getAttrValue(CmdArguments.STARTING_BASELINE);

        String requirements = (String) getAttrValue(CmdArguments.RELATED_REQUIREMENTS);
        String updateRequirements = (String) getAttrValue(CmdArguments.UPDATE_REQUIREMENT);
        String removeRequirements = (String) getAttrValue(CmdArguments.REMOVE_REQUIREMENT);

        String fileList = (String) getAttrValue(CmdArguments.FILE_LIST);
        String userFilter = (String) getAttrValue(CmdArguments.USER_FILTER);
        String filter = (String) getAttrValue(CmdArguments.FILTER);

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id);

        StringBuffer cmd = new StringBuffer();

        if (baseline == null) {
            cmd.append("CBL ").append(Encoding.escapeSpec(productName + ":" + id));
            if (owningPart != null && (fileList == null || fileList.length() == 0)) {
                cmd.append(" /PART=").append(Encoding.escapeDMCLI(owningPart.getAdmSpec().getSpec()));
                cmd.append(" /SCOPE=PART"); // default anyway so this can be removed if causes problems
            } else if (project != null) {
                cmd.append(" /SCOPE=WORKSET");
                if (startingBaseline != null && startingBaseline.length() != 0) {
                    cmd.append(" /BASELINE=").append(Encoding.escapeDMCLI(startingBaseline));
                }
            } else {
                throw new IllegalArgumentException("Must specify either owning part or based on project");
            }
            if (fileList != null && fileList.length() != 0) {
                cmd.append(" /USER_FILE=").append(Encoding.escapeDMCLI(fileList));
                if (owningPart != null) {
                    cmd.append(" /PART=").append(Encoding.escapeDMCLI(owningPart.getAdmSpec().getSpec()));
                }
            } else if (userFilter != null && userFilter.length() != 0) {
                cmd.append(" /USER_FILTER=").append(Encoding.escapeDMCLI(userFilter));
            } else if (filter != null && filter.length() != 0) {
                cmd.append(" /FILTER=").append(Encoding.escapeDMCLI(filter));
            }
            if (level != null && level.length() != 0) {
                cmd.append(" /LEVEL=").append(Encoding.escapeDMCLI(level));
            }
            if (chdocs != null && chdocs.length() != 0) {
                cmd.append(" /CHANGE_DOC_IDS=(").append(chdocs).append(")");
            }
            if (requirements != null && requirements.length() != 0) {
                cmd.append(" /REQUIREMENT_IDS=(").append(requirements).append(")");
            }
            if (template != null && template.length() != 0) {
                cmd.append(" /TEMPLATE_ID=").append(Encoding.escapeDMCLI(template));
            }
            if (description != null && description.length() != 0) {
                cmd.append(" /DESCRIPTION=").append(Encoding.escapeDMCLI(description));
            }
            if (cancelTraverse != null && cancelTraverse.booleanValue()) {
                cmd.append(" /CANCEL_TRAVERSE");
            }
            if (includeClosed != null && includeClosed.booleanValue()) {
                cmd.append(" /INCLUDE_CLOSED");
            }
            if (includeInfo != null && includeInfo.booleanValue()) {
                cmd.append(" /INCLUDE_INFO");
            }
            if (properties != null) {
                BodyCmdUtils.addPropertiesToCmdLine(cmd, properties);
            }
        } else {
            cmd.append("CRB ").append(Encoding.escapeDMCLI(productName + ":" + id));
            cmd.append(" /BASELINE1=").append(Encoding.escapeDMCLI(baseline.getAdmSpec().getSpec()));
            cmd.append(" ").append(createParam("CANCEL_TRAVERSE", cancelTraverse));
            cmd.append(" ").append(createParam("REMOVE_CHANGE_DOC_IDS", removeChdocs));
            cmd.append(" ").append(createParam("UPDATE_CHANGE_DOC_IDS", updateChdocs));
            if (removeRequirements != null && removeRequirements.length() > 0) {
                cmd.append(" /REMOVE_REQUIREMENT_IDS=(").append(removeRequirements).append(")");
            }
            if (updateRequirements != null && updateRequirements.length() > 0) {
                cmd.append(" /UPDATE_REQUIREMENT_IDS=(").append(updateRequirements).append(")");
            }

        }
        cmd.append(" ").append(createParam("TYPE", typeName));
        if (project != null) {
            String projectSpec = project.getAdmSpec().getSpec();

            if (worksetVersion != null) {
                projectSpec += ";" + worksetVersion;
            }

            cmd.append(" /WORKSET=").append(Encoding.escapeDMCLI(projectSpec));
        }
        cmd.append(" ").append(AttributeDefinition.getAttrsCmdStringFromCmd(this));
        _cmdStr = cmd.toString();
        AdmResult retResult = new AdmResult((String) executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Baseline.class);
        return retResult;
    }

    // TODO: The following createParam methods should be moved into a
    // CmdLineBuilder class similar to ProcessBuilder.

    /**
     * Create a parameter string for a Dimensions command from a list
     * of values. <br>
     * The returned string will have the following form: <br>
     * <code>/<i>paramName</i>=(<i>value[0]</i>, <i>value[1]</i>, ...)</code>
     *
     * @param paramName
     *            The name to use for this parameter
     * @param values
     *            The values to place in the command list. The values must
     *            be of type <code>AdmObject</code>.
     *
     * @return A string with the constructed command line.
     *
     * @throws AdmObjectException
     */
    String createParam(String paramName, List values) throws AdmObjectException {
        String str = "";
        if (values != null && values.size() != 0) {
            str += "/" + paramName + "=(";
            for (int i = 0; i < values.size(); i++) {
                if (i > 0) {
                    str += ", ";
                }
                str += Encoding.escapeDMCLI(((AdmObject) values.get(i)).getAdmSpec().getSpec());
            }
            str += ")";
        }
        return str;
    }

    /**
     * Create a parameter string for a Dimensions command from a string value. <br>
     * The returned string will have the following form: <br>
     * <code>/<i>paramName</i>=<i>value</i></code>
     *
     * @param paramName
     *            The name to use for this parameter
     * @param value
     *            The value for the command.
     *
     * @return A string with the constructed command line.
     */
    String createParam(String paramName, String value) {
        String str = "";
        if (value != null && value.length() > 0) {
            str += "/" + paramName + "=" + Encoding.escapeDMCLI(value);
        }
        return str;
    }

    /**
     * Create a parameter string for a Dimensions command from a boolean value. <br>
     * The returned string will have the following form if the boolean value is
     * true: <br>
     * <code>/<i>paramName</i></code> or <code>/NO<i>paramName</i></code>
     *
     * @param paramName
     *            The name to use for this parameter
     * @param value
     *            A boolean value.
     *
     * @return A string with the constructed command line.
     */
    String createParam(String paramName, Boolean value) {
        String str = "";
        if (value != null) {
            if (value.booleanValue()) {
                str += "/" + paramName;
            } else {
                str += "/NO" + paramName;
            }
        }
        return str;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.UploadExclusion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Upload Exclusion object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new upload exclusion</dd>
 *  <dt>EXTENSION {String}</dt><dd>Extension for the new upload exclusion</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}</dt><dd>Optional parent upload project</dd>
 * </dl></code> <br>
 * <b>Required Role:</b> <code><dl>
 *  <dt>($)PRODUCT-MANAGER/TOOL-MANAGER</dt>
 *  <dd>
 *      TOOL-MANAGER if creating a default exclusion rule, otherwise
 *      the product of the parent project as scope
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateUploadExclusionCmd extends RPCExecCmd {
    public CreateUploadExclusionCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EXTENSION, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, false, AdmObject.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);
        AdmObject uploadProject = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        String projectId = (String) AdmHelperCmd.getAttributeValue(uploadProject, AdmAttrNames.ID);

        String uploadProjId = "0";
        if (uploadProject != null) {
            uploadProjId = ((Long) AdmHelperCmd.getAttributeValue(uploadProject, AdmAttrNames.SPEC_UID)).toString();
        }

        DBIO query = null;

        // P Smith 12 March 2003 TDR 13889
        // Check to see whether a row for the file extension exists already in the database
        query = new DBIO(wcm_sql.QUERY_UPLOAD_EXCLUSION_FILE_EXT);
        // user name
        query.bindInput("$$" + extension);
        // session id
        query.bindInput(uploadProjId);
        // file extension
        query.bindInput(id);
        query.readStart();
        // We have found something
        if (query.read()) {
            query.close();
            throw new DimAlreadyExistsException("An upload exclusion already exists with this file extension: '" + id + "'");
        }

        query.close();
        // End PS

        if (uploadProjId.equals("0") || extension.startsWith("$")) {
            // Start DEF173973
            if (uploadProjId.equals("0") && extension.startsWith("mrg-")) {// For all product specific Dimensions Clients upload
                                                                           // projects.
                if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", projectId)) {
                    throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", projectId);
                }// End DEF173973
            } else {
                // Ensure that we have the privilege to do this
                if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UPLOADMAN")) {
                    throw new DimNoPrivilegeException("ADMIN_UPLOADMAN");
                }
            }
        } else {
            AdmObject product = null;
            query = new DBIO(wcm_sql.QUERY_UPLPROJ_PRODUCT);
            query.bindInput(Long.valueOf(uploadProjId).longValue());
            query.readStart();
            if (query.read()) {
                product = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getString(1), Product.class));
            }

            query.close();
            if (product == null) {
                throw new DimBaseCmdException("Unable to resolve product - for role check!");
            }

            String productName = (String) AdmHelperCmd.getAttributeValue(product, AdmAttrNames.ID);
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", productName)) {
                throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", productName);
            }
        }

        setAttrValue(CmdArguments.INT_SPEC, uploadProjId + ":" + id + ";" + extension);

        query = new DBIO(wcm_sql.CREATE_UPLOAD_EXCLUSION);
        query.bindInput(id);
        query.bindInput("$$" + extension);
        query.bindInput(uploadProjId);
        query.write();

        AdmResult retResult = new AdmResult("Created upload exclusion \"" + id + "\" successfully");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, UploadExclusion.class);
        return retResult;
    }
}

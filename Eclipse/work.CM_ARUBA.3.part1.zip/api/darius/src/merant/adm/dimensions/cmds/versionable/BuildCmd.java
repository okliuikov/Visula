/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2003 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.versionable;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.Options;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Perform a build.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions Project object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>BUILD_AREA {String}</dt><dd>Build area ID</dd>
 *  <dt>BUILD_AREA_TYPE {String}</dt><dd>Build area type (deployment or work)</dd>
 *  <dt>STAGE {String}</dt><dd>Stage for which the targets are to be built.</dd>
 *  <dt>AUDIT {Boolean}</dt><dd>Signifies an audit if true</dd>
 *  <dt>BATCH {Boolean}</dt><dd>Signifies a batch job if true</dd>
 *  <dt>BUILD_CONFIG {String}</dt><dd>Build config ID</dd>
 *  <dt>BUILD_OPTIONS {String}</dt><dd>Build options</dd>
 *  <dt>BUILDTARGET_LIST {List(AdmObject)}</dt><dd>Optional List of BuildTarget objects</dd>
 *  <dt>SRC_ITEMS {List(AdmObject)}</dt><dd>Optional List of source items</dd>
 *  <dt>SRC_FILES {List(String)}</dt><dd>Optional List of source files</dd>
 *  <dt>SRC_CHANGE_DOCS {List(AdmObject)}</dt><dd>Optional List of source requests</dd>
 *  <dt>CAPTURE_BUILD_OUTPUTS {Boolean}</dt><dd>Signifies whether to capture outputs</dd>
 *  <dt>RELATED_CHDOCS {String}</dt><dd>Change Documents</dd>
 *  <dt>POPULATE {Boolean}</dt><dd>Download files to work area before each build</dd>
 *  <dt>TOUCH {Boolean}</dt><dd>Apply system date/time to downloaded files</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {Boolean}</dt><dd>Traverse child source requests</dd>
 *  <dt>CLEAN {Boolean}</dt><dd>Clean the area before each build</dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Pauls
 */
public class BuildCmd extends RPCExecCmd {
    public final static String AREA_TYPE_WORK = "work";
    public final static String AREA_TYPE_DEPLOY = "deploy";

    private File tempSrcFile = null;
    private File tempTgtFile = null;

    public BuildCmd() throws AttrException {
        super();
        setAlias(Versionable.BUILD);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_AREA, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_AREA_TYPE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.AUDIT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.BATCH, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_CONFIG_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_OPTIONS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BUILDTARGET_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.SRC_ITEMS, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.SRC_FILES, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.SRC_CHANGE_DOCS, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CAPTURE_BUILD_OUTPUTS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CAPTURE_BUILD_PROJECT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.POPULATE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.POPULATE_SCOPE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.TOUCH, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLEAN, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.LOCK, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_PASSWORD, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: BuildCmd Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(AdmAttrNames.BUILD_CONFIG_ID)) {
            if (!(attrValue instanceof String)) {
                throw new AttrException("Error: BuildCmd Object type is not supported!", attrDef, attrValue);
            }
            if (attrValue == null) {
                throw new AttrException("Error: BuildCmd attribute is not specified!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        try {
            return executeRpc(null, null, true).getStructuredResult();
        } finally {
            if (tempSrcFile != null && tempSrcFile.exists()) {
                if (!tempSrcFile.delete()) {
                    tempSrcFile.deleteOnExit();
                }
            }
            if (tempTgtFile != null && tempTgtFile.exists()) {
                if (!tempTgtFile.delete()) {
                    tempTgtFile.deleteOnExit();
                }
            }
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String buildAreaID = (String) getAttrValue(AdmAttrNames.BUILD_AREA);
        String buildAreaType = (String) getAttrValue(AdmAttrNames.BUILD_AREA_TYPE);
        String stage = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        boolean audit = ((Boolean) getAttrValue(CmdArguments.AUDIT)).booleanValue();
        boolean batch = ((Boolean) getAttrValue(CmdArguments.BATCH)).booleanValue();
        String buildConfigID = (String) getAttrValue(AdmAttrNames.BUILD_CONFIG_ID);
        String buildOptions = (String) getAttrValue(AdmAttrNames.BUILD_OPTIONS);
        List buildTargets = (List) getAttrValue(CmdArguments.BUILDTARGET_LIST);
        List srcItems = (List) getAttrValue(CmdArguments.SRC_ITEMS);
        List srcFiles = (List) getAttrValue(CmdArguments.SRC_FILES);
        List srcRequests = (List) getAttrValue(CmdArguments.SRC_CHANGE_DOCS);
        boolean traverseRequests = ((Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS)).booleanValue();
        String changeDocuments = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        boolean capture = ((Boolean) getAttrValue(CmdArguments.CAPTURE_BUILD_OUTPUTS)).booleanValue();
        String captureProject = (String) getAttrValue(CmdArguments.CAPTURE_BUILD_PROJECT);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        boolean populate = ((Boolean) getAttrValue(CmdArguments.POPULATE)).booleanValue();
        String populate_scope = (String) getAttrValue(CmdArguments.POPULATE_SCOPE);
        boolean touch = ((Boolean) getAttrValue(CmdArguments.TOUCH)).booleanValue();
        boolean clean = ((Boolean) getAttrValue(CmdArguments.CLEAN)).booleanValue();
        boolean lock = ((Boolean) getAttrValue(CmdArguments.LOCK)).booleanValue();
        String user_name = (String) getAttrValue(CmdArguments.USER_NAME);
        String user_pwd = (String) getAttrValue(CmdArguments.USER_PASSWORD);

        StringBuffer sb = new StringBuffer();
        sb.append("BLD " + Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));

        // When "<All areas>" is selected, buildAreaID is set to "*" in RunBuildCommandPage.java
        // The BLD command line doesn't need the /AREA attribute if all areas are selected.
        if (buildAreaID != null) {
            if (!buildAreaID.equals("*")) {
                sb.append(" /AREA=" + Encoding.escapeDMCLI(buildAreaID));
            } else if (buildAreaType != null || stage != null) {
                if (AREA_TYPE_WORK.equals(buildAreaType)) {
                    sb.append(" /TYPE=\"WORK\"");
                } else if (AREA_TYPE_DEPLOY.equals(buildAreaType)) {
                    sb.append(" /TYPE=\"DEPLOYMENT\"");
                }
                if (stage != null) {
                    sb.append(" /STAGE=" + Encoding.escapeDMCLI(stage));
                }
            }
            // either AREA (/AREA) or AREA_TYPE (/TYPE) or /STAGE or both /AREA_TYPE & /STAGE
            // should have been set on the command.
        } else { // Possible combination of /TYPE & /STAGE when area is null
            if (buildAreaType != null) {
                if (AREA_TYPE_WORK.equals(buildAreaType)) {
                    sb.append(" /TYPE=\"WORK\"");
                } else if (AREA_TYPE_DEPLOY.equals(buildAreaType)) {
                    sb.append(" /TYPE=\"DEPLOYMENT\"");
                }
            }
            if (stage != null) {
                sb.append(" /STAGE=" + Encoding.escapeDMCLI(stage));
            }
        }

        sb.append(audit ? " /AUDIT" : " /NOAUDIT");
        sb.append(batch ? " /WAIT" : " /NOWAIT");

        if (buildOptions != null && !buildOptions.equals("")) {
            sb.append(" /BUILD_OPTIONS=" + buildOptions);
        }

        if (buildConfigID != null && !buildConfigID.equals("")) {
            sb.append(" /BUILD_CONFIG=" + Encoding.escapeDMCLI(buildConfigID));
        }

        if (capture) {
            sb.append(" /CAPTURE");
            // Only add chg docs if we are capturing outputs
            if (changeDocuments != null && changeDocuments.trim().length() > 0) {
                if (changeDocuments.startsWith("\"") && changeDocuments.endsWith("\"")) {
                    sb.append(" /CHANGE_DOC_IDS=(" + changeDocuments + ")");
                } else {
                    sb.append(" /CHANGE_DOC_IDS=(" + Encoding.escapeDMCLI(changeDocuments) + ")");
                }
            }
            if (captureProject != null && captureProject.trim().length() > 0) {
                sb.append(" /TARGET_PROJECT=" + Encoding.escapeDMCLI(captureProject));
            }
        } else {
            sb.append(" /NOCAPTURE");
        }

        if (buildTargets != null && buildTargets.size() > 0) {
            if (buildTargets.size() > Options.getLimitNumberItemsToUseFiles()) {
                String targetFileName = "";
                if (preview) {
                    targetFileName = "selected-targets.listingfile";
                } else {
                    tempTgtFile = getTempFile(buildTargets);
                    if (tempTgtFile != null) {
                        targetFileName = tempTgtFile.getAbsolutePath();
                    }
                }
                sb.append(" /TARGETS_LIST=" + Encoding.escapeDMCLI(targetFileName));
            } else {
                sb.append(" /TARGETS=(");
                for (int i = 0; i < buildTargets.size(); i++) {
                    if (i > 0) {
                        sb.append(", ");
                    }
                    sb.append(Encoding.escapeDMCLI((String) buildTargets.get(i)));
                }
                sb.append(")");
            }
        }

        if (srcItems != null && srcItems.size() > 0) {
            if (srcItems.size() > Options.getLimitNumberItemsToUseFiles()) {
                String srcFileName = "";
                if (preview) {
                    srcFileName = "selected-objects.listingfile";
                } else {
                    List list = new ArrayList();
                    for (int i = 0; i < srcItems.size(); i++) {
                        list.add(((AdmObject) srcItems.get(i)).getAdmSpec().getSpec());
                    }
                    tempSrcFile = getTempFile(list);
                    if (tempSrcFile != null) {
                        srcFileName = tempSrcFile.getAbsolutePath();
                    }
                }
                sb.append(" /SRC_ITEMLIST=" + Encoding.escapeDMCLI(srcFileName));
            } else {
                sb.append(" /SRC_ITEMS=(");
                for (int i = 0; i < srcItems.size(); i++) {
                    if (i > 0) {
                        sb.append(", ");
                    }
                    sb.append(Encoding.escapeDMCLI(((AdmObject) srcItems.get(i)).getAdmSpec().getSpec()));
                }
                sb.append(")");
            }
        } else if (srcFiles != null && srcFiles.size() > 0) {
            if (srcFiles.size() > Options.getLimitNumberItemsToUseFiles()) {
                String srcFileName = "";
                if (preview) {
                    srcFileName = "selected-objects.listingfile";
                } else {
                    tempSrcFile = getTempFile(srcFiles);
                    if (tempSrcFile != null) {
                        srcFileName = tempSrcFile.getAbsolutePath();
                    }
                }
                sb.append(" /SRC_FILELIST=" + Encoding.escapeDMCLI(srcFileName));
            } else {
                sb.append(" /SRC_FILES=(");
                for (int i = 0; i < srcFiles.size(); i++) {
                    if (i > 0) {
                        sb.append(", ");
                    }
                    sb.append(Encoding.escapeDMCLI((String) srcFiles.get(i)));
                }
                sb.append(")");
            }
        } else if (srcRequests != null && srcRequests.size() > 0) {
            sb.append(" /SRC_CHANGE_DOC_IDS=(");
            for (int i = 0; i < srcRequests.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(Encoding.escapeDMCLI(((AdmObject) srcRequests.get(i)).getAdmSpec().getSpec()));
            }
            sb.append(")");
            if (traverseRequests) {
                sb.append(" /NOCANCEL_TRAVERSE");
            } else {
                sb.append(" /CANCEL_TRAVERSE");
            }
        }

        if (AREA_TYPE_WORK.equals(buildAreaType)) {
            if (populate_scope != null && populate_scope.trim().length() > 0) {
                sb.append(" /POPULATE_SCOPE=");
                sb.append(populate_scope);// NONE ALL REQUESTED
                sb.append(touch ? " /TOUCH" : "");// /[NO]TOUCH
            } else {
                sb.append(populate ? " /POPULATE" : "");// /[NO]POPULATE
                sb.append((touch && populate) ? " /TOUCH" : "");// /[NO]TOUCH
            }
        }

        if (user_name != null && user_name.trim().length() > 0) {
            sb.append(" /USER=" + Encoding.escapeDMCLI(user_name));
        }

        if (user_pwd != null && user_pwd.trim().length() > 0) {
            if (preview) {
                user_pwd = "*****";
            }
            sb.append(" /PASSWORD=" + Encoding.escapeDMCLI(user_pwd));
        }

        if (userFile != null && !userFile.equals("")) {
            sb.append(" /USER_FILENAME=" + Encoding.escapeDMCLI(userFile));
            if (!userFile.endsWith(".htm") && !userFile.endsWith(".html")) {
                sb.append(" /HTML_FRAGMENT");
            }
        }

        sb.append(clean ? " /BUILD_CLEAN" : " /NOBUILD_CLEAN");
        sb.append(lock ? " /LOCK_SEARCH_PATH" : "");

        _cmdStr = sb.toString();
    }

    static File getTempFile(List list) throws AdmException {
        if (list != null && list.size() > 0) {
            try {
                File file = File.createTempFile("safe_to_delete", ".tmp");
                Writer writer = null;
                PrintWriter printWriter = null;
                OutputStream os = null;
                try {
                    // Always write in UTF8
                    os = new FileOutputStream(file);
                    writer = StringUtils.createUTF8EncodingWriter(os);
                    printWriter = new PrintWriter(writer);
                    for (int i = 0; i < list.size(); i++) {
                        printWriter.println(list.get(i));
                    }
                } finally {
                    if (printWriter != null) {
                        printWriter.close();
                    }
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e) {
                            Debug.debug(e);
                        }
                    }
                    if (os != null) {
                        try {
                            os.close();
                        } catch (IOException e) {
                            Debug.debug(e);
                        }
                    }
                }
                return file;
            } catch (IOException e) {
                throw new AdmException(e);
            }
        }
        return null;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will query the child count of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_CHILD_CLASS {Class}<dt><dd>Child Dimensions object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions work set container for objects</dd>
 *  <dt>RECURSIVE {Boolean}<dt>
 *  <dd>
 *      If true, returns all child objects recursively
 *      throughout the child hierarchy.<br>
 *      Note: if parent and child classes match, or required
 *      children are hierarchical by nature, then returns
 *      Relationship's rather than AdmBaseId's.
 *  </dd>
 *  <dt>RECURSIVE_VIA_PARENT_HIER {Boolean}<dt>
 *  <dd>
 *      If true, returns all child objects recursively
 *      throughout the parent hierarchy.<br>
 *      Note: if parent and child classes match, or required
 *      children are hierarchical by nature, then returns
 *      Relationship's rather than AdmBaseId's.
 *  </dd>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}<dt><dd>If true, returns default object preferences</dd>
 *  <dt>RELTYPE_IS_PEDIGREE {Boolean}<dt><dd>If true, returns pedigree object relationship count</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Long}<dt><dd>Long containing the child count</dd>
 * </dl></code>
 * @author Floz
 */
public class QueryChildCountCmd extends DBIOCmd {
    public QueryChildCountCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_CHILD_COUNT);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_CHILD_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.RECURSIVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RECURSIVE_VIA_PARENT_HIER, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_DEFAULT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_PEDIGREE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admObj);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, getAttrValue(CmdArguments.ADM_CHILD_CLASS));
        cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
        cmd.setAttrValue(CmdArguments.RECURSIVE, getAttrValue(CmdArguments.RECURSIVE));
        cmd.setAttrValue(CmdArguments.RECURSIVE_VIA_PARENT_HIER, getAttrValue(CmdArguments.RECURSIVE_VIA_PARENT_HIER));
        cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
        cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT, getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT));
        cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE));
        cmd.setAttrValue("COUNT", Boolean.TRUE);
        return new Long(((List) cmd.execute()).size());
    }
}

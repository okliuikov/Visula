/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2012 Serena Software Europe Ltd. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.UploadProduct;
import merant.adm.dimensions.objects.UploadProject;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all UploadProject's related to the UploadEnvironment object for Product.
 * <p>
 */
public class QueryUplProdToUplProj extends DBIOCmd {
    public QueryUplProdToUplProj() throws AttrException {
        super();
        setAlias(Relatable.QUERY_PRODUCTS_CHILD_UPLOAD_PROJECTS);
        setAttrDef(new CmdArgDef(AdmAttrNames.EXTENSION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UploadProject)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(UploadProduct.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, AdmException {

        List ret = new ArrayList();
        String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);
        String productId = (String) getAttrValue(AdmAttrNames.ID);
        if (extension.startsWith("$") && !extension.startsWith("$$")) {
            extension = extension.substring(0, extension.indexOf("-"));
            // These are from the WS_IDE_INFO table.
            DBIO query = new DBIO(wcm_sql.GET_IDE_INFO_PROJECTS_WITH_PRODUCTS);
            query.bindInput(extension);
            query.bindInput(productId);
            query.bindInput("$$" + extension + "-");
            query.readStart();
            String projID;
            while (query.read()) {
                projID = query.getString(1);
                String product_id = query.getString(3);
                if (product_id == null || product_id.length() == 0) {
                    product_id = Constants.GLOBAL_PRODUCT;
                }
                String uProjSpec = product_id + ":" + projID + ";" + extension;
                ret.add(AdmHelperCmd.newAdmBaseId(uProjSpec, UploadProject.class));
            }
        } else {
            extension = extension.substring(0, extension.indexOf("-"));
            Cmd cmd = AdmCmd.getCmd("GetUploadProjectsWithProductsDRS");
            cmd.setAttrValue(CmdArguments.PRODUCT, productId);
            cmd.setAttrValue(CmdArguments.EXTENSION, "$$" + extension);
            String[] projSpecs = (String[]) cmd.execute();
            if (projSpecs.length > 0) {
                for (int i = 0; i < projSpecs.length; i++) {
                    // Yuck - as the extension is not stored in a separate field
                    // then we have to query ALL upload projects and
                    // programmatically select the ones with the correct extension
                    // (and then select the one with the correct upload project ID
                    // if there is a filter).
                    String uProjSpec = projSpecs[i] + ";" + extension;
                    if (projSpecs[i].endsWith("." + extension)) {
                        ret.add(AdmHelperCmd.newAdmBaseId(uProjSpec, UploadProject.class));
                    } else {
                        int index = projSpecs[i].indexOf(Constants.ROOT_MARKER);
                        if (index != -1 && extension.startsWith("$$")) {
                            try {
                                Integer.parseInt(projSpecs[i].substring(index + Constants.ROOT_MARKER.length()));
                                ret.add(AdmHelperCmd.newAdmBaseId(uProjSpec, UploadProject.class));
                            } catch (NumberFormatException e) {
                                // if not a number then just continue
                            }
                        }
                    }
                }
            }
        }
        return ret;
    }
}

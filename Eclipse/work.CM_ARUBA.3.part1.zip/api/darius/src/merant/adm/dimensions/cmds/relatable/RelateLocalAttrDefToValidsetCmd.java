/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.Validset;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will assign a LocalAttributeDefinition to a Validset.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {LocalAttributeDefinition}<dt><dd>Dimensions LocalAttributeDefinition object</dd>
 *  <dt>ADM_PARENT_OBJECT {Validset}<dt><dd>Parent Dimensions Validset object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, deassigns the attribute definition from the valid set
 *  </dd>
 *  <dt>ATTRDEF_VALIDATION_GROUP_NAME {String}<dt>
 *  <dd>
 *      validation group name. If REMOVE is not specified, then this argument is required.
 *  </dd>
 *  <dt>ATTRDEF_LOVCOLUMN {Integer}<dt>
 *  <dd>
 *      valid set column number. If REMOVE is not specified, then this argument is required.
 *  </dd>
 *  <dt>ATTRDEF_IS_AUTOPOPULATED {Boolean}<dt>
 *  <dd>
 *      Whether to automatically populate the attribute if a single match against the valid set if found. Default - Y
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class RelateLocalAttrDefToValidsetCmd extends RPCExecCmd {
    public RelateLocalAttrDefToValidsetCmd() throws AttrException {
        super();
        setAlias("RelateLocalAttrDefToValidsetCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, LocalAttributeDefinition.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, Validset.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_VALIDATION_GROUP_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_LOVCOLUMN, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ATTRDEF_IS_AUTOPOPULATED, false, Boolean.TRUE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LocalAttributeDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof Validset)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {

        validateAllAttrs();

        // Dimensions local attribute definition
        AdmObject attrObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // Dimensions valid set
        AdmObject validsetObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);

        boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        String validationGroupName = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ATTRDEF_VALIDATION_GROUP_NAME),
                AdmDmLengths.DM_L_ATTR_VAL_GROUP_NAME);

        Integer validsetColumnNo = (Integer) getAttrValue(AdmAttrNames.ATTRDEF_LOVCOLUMN);
        boolean autoPopulated = ((Boolean) getAttrValue(AdmAttrNames.ATTRDEF_IS_AUTOPOPULATED)).booleanValue();

        // get relevant validset attributes
        List attrValues = AdmHelperCmd.getAttributeValues(validsetObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.VALIDSET_NUM_COLS, AdmAttrNames.ID }));
        String vsProductName = (String) attrValues.get(0);
        int validsetNumCols = ((Integer) attrValues.get(1)).intValue();
        String validsetName = (String) attrValues.get(2);

        // get relevant attribute definition attributes
        attrValues = AdmHelperCmd.getAttributeValues(
                attrObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ATTRDEF_TYPE_NAME, AdmAttrNames.PARENT_CLASS,
                        AdmAttrNames.ID, AdmAttrNames.ATTRDEF_ATTRTYPE }));
        String attrProductName = (String) attrValues.get(0);
        String typeName = (String) attrValues.get(1);
        Class scopeClass = (Class) attrValues.get(2);
        String attrName = (String) attrValues.get(3);
        int attrType = ((Integer) attrValues.get(4)).intValue();

        if (!attrProductName.equals(vsProductName)) {
            throw new DimInvalidAttributeException("Error: valid set and attribute must be defined in the same product");
        }

        if (attrName == null) {
            throw new DimInvalidAttributeException("Error: Attribute name must be specified.");
        }

        String attrTypeName = "";
        if (attrType == Constants.ATTR_TYPE_SFSV)
            attrTypeName = "SS";
        else if (attrType == Constants.ATTR_TYPE_SFMV)
            attrTypeName = "SM";
        else if (attrType == Constants.ATTR_TYPE_MFMV)
            attrTypeName = "MM";
        else
            throw new DimInvalidAttributeException("Error: Wrong attribute type specified.");

        if (!bDeassign && validsetNumCols > 1) {
            if (validsetColumnNo == null) {
                throw new DimInvalidAttributeException(
                        "Error: valid set column number to which the attribute is to be assigned must be specified");
            }

            if (validationGroupName == null || validationGroupName.length() == 0) {
                throw new DimInvalidAttributeException(
                        "Error: valid set group name must be specified when assigning an attribute to a multi-column valid set");
            }

            if (validsetColumnNo.intValue() < 1 || validsetColumnNo.intValue() > validsetNumCols
                    || validsetColumnNo.intValue() > 8) {
                throw new DimInvalidAttributeException("Error: the specified valid set column number should be between 1 and "
                        + validsetNumCols);
            }
        }

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJATTR /UPDATE ");
        cmdBuf.append(Encoding.escapeDMCLI(attrName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(attrProductName));
        cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(scopeClass));

        if (User.class.equals(scopeClass)) {
            if (!Constants.GLOBAL_PRODUCT.equals(vsProductName)) {
                throw new DimInvalidAttributeException("Error: user object type attribute can only be assigned "
                        + "to a valid set defined in " + Constants.GLOBAL_PRODUCT + " product");
            }
            if (validsetNumCols != 1) {
                throw new DimInvalidAttributeException(
                        "Error: user object type attribute can only be assigned to a single-column valid set");
            }
        }

        cmdBuf.append(" /OBJ_TYPE=").append(Encoding.escapeDMCLI(typeName));
        cmdBuf.append(" /TYPE=").append(Encoding.escapeDMCLI(attrTypeName));

        if (bDeassign)
            cmdBuf.append(" /VALID_SET_NAME=\"\"");
        else if (validsetName != null && validsetName.length() > 0) {
            cmdBuf.append(" /VALID_SET_NAME=").append(Encoding.escapeDMCLI(validsetName));

            if (validsetColumnNo != null && validsetColumnNo.intValue() >= 0)
                cmdBuf.append(" /VALID_SET_COLUMN=").append(validsetColumnNo.intValue());

            if (validationGroupName != null && validationGroupName.length() > 0)
                cmdBuf.append(" /VALID_SET_GROUP=").append(Encoding.escapeDMCLI(validationGroupName));

            cmdBuf.append(autoPopulated ? " /VALID_SET_AUTOPOPULATE" : " /NOVALID_SET_AUTOPOPULATE");
        }
        else {
            throw new DimInvalidAttributeException("Error: valid set is not specified.");
        }

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will determine whether an image file representing the lifecycle
 * exists for the specified Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Boolean}<dt><dd>A value of true if a lifecycle image exists</dd>
 * </dl></code>
 * @author Floz
 */
public class HasLifecycleImageCmd extends DBIOCmd {
    public HasLifecycleImageCmd() throws AttrException {
        super();
        setAlias(Actionable.HAS_LC_IMAGE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument) && !(attrValue instanceof Item) && !(attrValue instanceof Baseline)
                    && !(attrValue instanceof Part) && !(attrValue instanceof ItemFile) && !(attrValue instanceof LifeCycle)
                    && !(attrValue instanceof WorkSet)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        Boolean bHasImage = Boolean.FALSE;
        if (admObj instanceof LifeCycle) {
            bHasImage = (Boolean) admObj.getAttrValue(AdmAttrNames.LIFECYCLE_HAS_IMAGE);
            if (bHasImage == null) {
                Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObj);
                cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, AdmAttrNames.LIFECYCLE_HAS_IMAGE);
                cmd.execute();
                bHasImage = (Boolean) admObj.getAttrValue(AdmAttrNames.LIFECYCLE_HAS_IMAGE);
            }
        } else {
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_PARENT, admObj);
            cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, LifeCycle.class);
            AdmObject lifeCycle = AdmHelperCmd.getObject((AdmBaseId) cmd.execute());
            bHasImage = (Boolean) AdmHelperCmd.getAttributeValue(lifeCycle, AdmAttrNames.LIFECYCLE_HAS_IMAGE);
        }
        return bHasImage;
    }
}

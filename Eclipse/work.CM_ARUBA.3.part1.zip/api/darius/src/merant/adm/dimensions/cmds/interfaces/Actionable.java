/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for actionable commands.
 * <p>
 * This applies to any dimensions object that can be actioned through a lifecycle and optionally commented at each transition.
 * @author Floz
 */
public interface Actionable {
    public static final String ACTION = "Actionable.Action";
    public static final String ADD_COMMENT = "Actionable.AddComment";
    public static final String BROWSE_COMMENTS = "Actionable.BrowseComments";
    public static final String COPY_ATTRIBUTES = "Actionable.CopyAttributes";
    public static final String COPY_ATTRIBUTE_RULES = "Actionable.CopyAttributeRules";
    public static final String COPY_UPLOAD_RULES = "Actionable.CopyUploadRules";
    public static final String COPY_BASELINE_TEMPLATE_RULES = "Actionable.CopyBaselineTemplateRules";
    public static final String COPY_RELEASE_TEMPLATE_RULES = "Actionable.CopyReleaseTemplateRules";
    public static final String PROMOTE_TO_STAGE = "Actionable.PromoteToStage";
    public static final String DEMOTE_TO_STAGE = "Actionable.DemoteToStage";
    public static final String FETCH_COMMENTS = "Actionable.FetchComments";
    public static final String FETCH_LC_IMAGE = "Actionable.FetchLifecycleImage";
    public static final String FETCH_BROWSE_TEMPLATE = "Actionable.FetchBrowseTemplate";
    public static final String FETCH_REPORT_FILE = "Actionable.FetchReportFile";
    public static final String HAS_LC_IMAGE = "Actionable.HasLifecycleImage";
    public static final String EDIT_COMMENTS = "Actionable.EditComments";
    public static final String UPDATE_COMMENTS = "Actionable.UpdateComments";
    public static final String UPDATE_LC_IMAGE = "Actionable.UpdateLifecycleImage";
    public static final String UPDATE_BROWSE_TEMPLATE = "Actionable.UpdateBrowseTemplate";
    public static final String UPDATE_REMOTE_JOB_STATUS = "Actionable.UpdateRemoteJobStatus";
    public static final String UPDATE_REPORT_FILE = "Actionable.UpdateReportFile";
    public static final String SUSPEND = "Actionable.Suspend";
    public static final String EDIT_SCHEDULED_JOB = "Actionable.EditScheduledJob";
    public static final String FETCH_DEPLOYABLE_AREAS = "Actionable.FetchDeployableAreas";
    public static final String DEPLOY_TO_AREAS = "Actionable.DeployToAreas";
    public static final String ROLLBACK_FROM_AREAS = "Actionable.RollbackFromAreas";
    public static final String ROLLBACK_DEPLOYMENT_CHANGE_SET = "Actionable.RollbackDeploymentChangeSet";
    public static final String ROLLBACK_AREA_VERSION = "Actionable.RollbackAreaVersion";
    public static final String FETCH_PROMOTABLE_STAGES = "Actionable.FetchPromotabeStages";
}

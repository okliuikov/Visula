/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.AuthPointInfoRequiredException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.system.PasswordAuthPointInfo;
import merant.adm.dimensions.system.PasswordAuthPointParam;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command requests that the server issues an authorization point.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>{none}</dt>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>AUTH_POINT_INFO {PasswordAuthPointInfo}<dt><dd>The password of the operating system user</dd>
 *  <dt>AUTH_POINT_PARAM {AuthPointParam}<dt><dd>Details of the /PARAMETER argument</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz, Stephen Sitton
 */
public class AutoPointInfoRequiredCmd extends RPCExecCmd {
    public AutoPointInfoRequiredCmd() throws AttrException {
        super();
        setAlias(Server.AUTH_POINT_INFO_REQUESTED);
        setAttrDef(new CmdArgDef(CmdArguments.AUTH_POINT_INFO, false, null, PasswordAuthPointInfo.class));
        setAttrDef(new CmdArgDef(CmdArguments.AUTH_POINT_PARAM, false, null, PasswordAuthPointParam.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        PasswordAuthPointParam paramObj = (PasswordAuthPointParam) getAttrValue(CmdArguments.AUTH_POINT_PARAM);

        if (((PasswordAuthPointInfo) getAttrValue(CmdArguments.AUTH_POINT_INFO)) == null) {
            // We need to get the password
            throw new AuthPointInfoRequiredException();
        }

        _cmdStr = "XDATA \"AUTHPOINT\"";

        if (paramObj != null) {
            _cmdStr += " /PARAMETER=(OPERATION=\"" + paramObj.getOperation() + "\"";

            if (paramObj.getLifecycleId() != null) {
                _cmdStr += ", LIFECYCLE=\"" + paramObj.getLifecycleId() + "\"";
                if (paramObj.getStatus() != null) {
                    _cmdStr += ", STATUS=\"" + paramObj.getStatus() + "\"";
                }
                if (paramObj.getOperation().equals(PasswordAuthPointParam.RENAME) && paramObj.getNewStatus() != null) {
                    _cmdStr += ", NAME=\"" + paramObj.getNewStatus() + "\"";
                }
            } else if (paramObj.getTypeUid() > -1) {
                _cmdStr += ", UID=\"" + paramObj.getTypeUid() + "\"";
                if (paramObj.getAttrNo() > -1) {
                    _cmdStr += ", ATTR=\"" + paramObj.getAttrNo() + "\"";
                }
            }

            if (paramObj.getSensitive() != null) {
                _cmdStr += ", SENSITIVE=" + (paramObj.getSensitive() == Boolean.TRUE ? "\"Y\"" : "\"N\"");
            }

            _cmdStr += ")";
        }

        return executeRpc();
    }
}

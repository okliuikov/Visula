/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.CmdBuilder;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This merge command will rebase a topic stream from source project version.
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd> </dl></code>
 */

// This class will perform MERGE /REBASE
public class RebaseCmd extends RPCExecCmd {
    private static CmdArgDef[] cmdDefs = {
    		new CmdArgDef(CmdArguments.WORKSET, false, String.class),
            new CmdArgDef(CmdArguments.TARGET_WORKSET, false, String.class),
            new CmdArgDef(CmdArguments.WORKSET_VERSION, false, Integer.class),
    };

    public RebaseCmd() throws AttrException {
        super();
        setAlias(Versionable.REBASE);
        for (CmdArgDef arg : cmdDefs) {
            setAttrDef(arg);
        }
    }

    @Override
	public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
		validateAllAttrs();

		String workset = (String) getAttrValue(CmdArguments.WORKSET);
		String targetWorkset = (String) getAttrValue(CmdArguments.TARGET_WORKSET);
		CmdBuilder b = CmdBuilder.create("MERGE").addParameter("/REBASE");

		if (workset != null && workset.length() > 0) {
			b.addParameter("/WORKSET", workset);
		}
		Integer worksetVersion = (Integer) getAttrValue(CmdArguments.WORKSET_VERSION);
		if (worksetVersion != null) {
			targetWorkset += ";" + worksetVersion;
		}
		b.addParameter("/TARGET", targetWorkset);
		b.addParameter("/COMMENT", "Rebasing from " + targetWorkset);

		_cmdStr = b.build();
		String result = (String) executeRpc();
		return result;
	}
}

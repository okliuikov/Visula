package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.query.DariusClassMapper;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * 
 * @author kberezovchuk, pbate
 * 
 *         This command is used to get Request Provider information from Dimensions.
 *         <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>OBJECT {AdmUidObject}<dt><dd>Object to get provider for.</dd>
 * </dl></code> <br>
 *         <b>Returns:</b> <code><dl>
 *  <dt>java.lang.Object[]</dd>
 * </dl></code>
 */
public class RPCGetRequestProvidersCmd extends RPCCmd {

    public RPCGetRequestProvidersCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("GetRequestProviders");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmUidObject.class));
    }

    /**
     * Returns Request Provider information: name/short name and valid attributes/values map
     * 
     * @return <code>java.lang.Object[]</code> with 3 elements where:
     *         [0] Integer - request provider tool instance uid
     *         [1] String - provider name
     *         [2] String - provider short name
     *         [3] HashMap - map of provider attributes/values, or empty map if no such pairs
     * 
     */
    @Override
    public Object execute() throws DimConnectionException, AdmException {
        Object[] ret;
        try {
            AdmUidObject uidObject = (AdmUidObject) getAttrValue(CmdArguments.ADM_OBJECT);
            Class objClass = uidObject.getClass();
            long typeUid = DariusClassMapper.mapClassToConstant(objClass.getName());

            long objUid = 0;
            try {
                objUid = uidObject.getAdmUid().getUid();
            } catch (AdmObjectException aoe) {
                // will be the BaseDatabase - do nothing
            }

            ret = getSession().getConnection().rpcGetRequestProviders(typeUid, objUid);
            uidObject.setAttrValue(AdmAttrNames.REQUEST_PROVIDER, ret);
        } catch (AttrException e) {
            ret = null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return ret;
    }
}

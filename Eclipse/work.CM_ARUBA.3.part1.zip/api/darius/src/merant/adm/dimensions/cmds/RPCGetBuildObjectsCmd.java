/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.List;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command determines whether a user has the specified privilege for the object and product
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>WORKSET {AdmObject}<dt><dd>Dimensions scope object for the build project</dd>
 *  <dt>RPC_MODE {Integer}<dt><dd>The mode for the RPC ie what data is being requested:<br/>
 * 1 = get build configurations for a workset (with optional list of item(s)/request )
 * 2 = get build configurations for a baseline
 * 3 = get stages, targets and build options for a build configuration (with optional list of item(s)/request )
 * 4 = get deployment areas for a build stage and build configuration
 * 5 = get work areas for a build configuration<br/>
 * </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>BASELINE {AdmObject}<dt><dd>Baseline to build </dd>
 *  <dt>BUILD_CONFIG_ID {String}<dt><dd>The build configuration id</dd>
 *  <dt>STAGE_ID {String}<dt><dd>The build stage id</dd>
 *  <dt>BUILD_SELECTION_LIST {String}<dt><dd>A list of items to calculate the correct targets and configurations for</dd>
 *  <dt>BUILD_REQUEST_OBJ {String}<dt><dd>A request to calculate the correct targets and configurations for</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {String}<dt><dd>Whether to include the related child requests in the calulation of the targets and configurations for the request</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>List<dt><dd>Contains at least one String[] for build projects/build configs/build areas and optionally a second String[] for build targets</dd>
 * </dl></code> Created 03/03/2006.
 * @author Paul Smith
 */
public class RPCGetBuildObjectsCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCGetBuildObjectsCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("GetBuildObjects");
        AddArgument("cmd", "GetBuildObjects");

        setAttrDef(new CmdArgDef(CmdArguments.RPC_MODE, true, Integer.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_CONFIG_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_SELECTION_LIST, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_REQUEST_OBJ, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.WORKSET)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("RPCGetBuildObjectsCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException {

        try {
            long projectUid = ((AdmUidObject) getAttrValue(CmdArguments.WORKSET)).getAdmUid().getUid();

            AdmUidObject baseline = (AdmUidObject) getAttrValue(CmdArguments.BASELINE);
            long baselineUid = (baseline != null ? baseline.getAdmUid().getUid() : 0);

            String buildConfig = (String) getAttrValue(AdmAttrNames.BUILD_CONFIG_ID);
            String buildStageID = (String) getAttrValue(AdmAttrNames.STAGE_ID);
            boolean includeChildRequests = ((Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS)).booleanValue();

            AdmUidObject buildRequestObj = (AdmUidObject) getAttrValue(AdmAttrNames.BUILD_REQUEST_OBJ);
            long buildRequestUid = 0;
            if (buildRequestObj != null) {
                buildRequestUid = buildRequestObj.getAdmUid().getUid();
            }

            List buildItemsSelectionList = (List) getAttrValue(AdmAttrNames.BUILD_SELECTION_LIST);
            int[] buildItemsSelectionArray = new int[0];
            if (buildItemsSelectionList != null && buildItemsSelectionList.size() > 0) {
                buildItemsSelectionArray = new int[buildItemsSelectionList.size()];
                AdmUidObject admUidObj = null;
                int admUidObjUid = 0;
                for (int i = 0; i < buildItemsSelectionList.size(); i++) {
                    admUidObj = (AdmUidObject) buildItemsSelectionList.get(i);
                    admUidObjUid = (int) admUidObj.getAdmUid().getUid();
                    buildItemsSelectionArray[i] = admUidObjUid;
                }
            }

            List<String[]> buildObjects = getSession().getConnection().rpcPcmsGetBuildObjects(
                    ((Integer) getAttrValue(CmdArguments.RPC_MODE)).intValue(), projectUid, baselineUid,
                    buildConfig != null ? buildConfig : "null", buildStageID != null ? buildStageID : "null", buildRequestUid,
                    includeChildRequests, buildItemsSelectionArray);
            return buildObjects;

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

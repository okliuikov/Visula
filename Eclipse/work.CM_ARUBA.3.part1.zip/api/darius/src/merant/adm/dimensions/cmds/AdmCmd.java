/*
 * Copyright 2001-2003, 2006 Serena Software, Inc.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.factory.AdmCmdKey;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.AdmObjectList;
import merant.adm.dimensions.objects.collections.AdmObjectListImpl;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.system.AuthPointInfo;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.system.SessionBean;
import merant.adm.dimensions.util.Cache;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Options;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AbstractCmd;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Use AdmHelperCmd for static methods in preference to this.
 * @author Laurence Martin
 */
public abstract class AdmCmd extends AbstractCmd {

    public AdmCmd() {
        try {
            // Add internal optional AuthPointInfo argument - inherited by every command
            setAttrDef(new CmdArgDef(CmdArguments.AUTH_POINT_INFO, false, AuthPointInfo.class));
        } catch (AttrException e) {
            Debug.error(e);
        }
    }

    /**
     * Determines if the command nativly supports
     * multiple operations.
     * @return boolean True the command supports multiple operations.
     */
    public boolean supportsMultiple() throws AttrException {
        if (getAttrDef(CmdArguments.ADM_OBJECT_LIST) != null) {
            return true;
        }

        if (getAttrDef(CmdArguments.ADM_OBJECT_CLASS_LIST) != null) {
            return true;
        }

        return false;
    }

    private static Cmd checkForDebugCmd(Cmd nestedCmd) throws AdmObjectException, AttrException {
        Cmd cmd = nestedCmd;
        if (Options.isLogCmds() && (cmd != null)) {
            List exclusions = Options.getLogCmdExclusions();
            List inclusions = Options.getLogCmdInclusions();

            boolean wrap = true;
            if ((inclusions != null) && (inclusions.size() > 0)) {
                wrap = false;
                for (int i = 0; ((i < inclusions.size()) && (!wrap)); i++) {
                    if (inclusions.get(i).equals(cmd.getAlias())) {
                        wrap = true;
                    }
                }
            } else if ((exclusions != null) && (exclusions.size() > 0)) {
                for (int i = 0; ((i < exclusions.size()) && wrap); i++) {
                    if (exclusions.get(i).equals(cmd.getAlias())) {
                        wrap = false;
                    }
                }
            }

            if (wrap) {
                cmd = new AdmDebugCmd(cmd);
            }
        }

        return cmd;
    }

    // Static methods for AdmCmd instances retrieval
    public static Cmd getCmd(String alias) throws DimBaseException, AdmObjectException, AttrException {
        Cmd cmd = DimSystem.getSystem().getAdmCmdFactory().getCmd(new AdmCmdKey(alias));
        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        cmd = checkForDebugCmd(cmd);

        Debug.println("AdmCmd.getCmd(" + alias + ")");
        Debug.println("   Found Command [" + cmd.getClass().getName() + "]");
        return cmd;
    }

    public static Cmd getCmd(String alias, Class objClass) throws DimBaseException, AdmObjectException, AttrException {
        Cmd cmd = DimSystem.getSystem().getAdmCmdFactory().getCmd(new AdmCmdKey(alias, objClass));
        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        cmd = checkForDebugCmd(cmd);

        if (objClass != null) {
            Debug.println("AdmCmd.getCmd(" + alias + ", " + objClass.getName() + ")");
        } else {
            Debug.println("AdmCmd.getCmd(" + alias + ", null)");
        }

        Debug.println("   Found Command [" + cmd.getClass().getName() + "]");
        return cmd;
    }

    public static Cmd getCmd(String alias, Class objClass, Class secObjClass) throws DimBaseException, AdmObjectException,
            AttrException {
        Cmd cmd = DimSystem.getSystem().getAdmCmdFactory().getCmd(new AdmCmdKey(alias, objClass, secObjClass));
        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        cmd = checkForDebugCmd(cmd);

        if (secObjClass != null) {
            Debug.println("AdmCmd.getCmd(" + alias + ", " + objClass.getName() + ", " + secObjClass.getName() + ")");
        } else if (objClass != null) {
            Debug.println("AdmCmd.getCmd(" + alias + ", " + objClass.getName() + ")");
        } else {
            Debug.println("AdmCmd.getCmd(" + alias + ", null)");
        }

        Debug.println("  Found Command [" + cmd.getClass().getName() + "]");
        return cmd;
    }

    public static Cmd getCmd(String alias, Object admObj) throws DimBaseException, AdmObjectException, AttrException {
        Cmd cmd = null;
        if (admObj == null) {
            cmd = getCmd(alias);
        } else {
            cmd = getCmd(alias, admObj.getClass());
        }

        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        if (admObj != null) {
            cmd.setAttrValue(CmdArguments.ADM_OBJECT, admObj);
        }

        return cmd;
    }

    /** @deprecated Please use getCmd(String alias, List objs) */
    @Deprecated
    public static Cmd getCmd(String alias, AdmObject[] admObjs) throws DimBaseException, AdmObjectException, AttrException {
        Cmd cmd = null;
        if (admObjs == null) {
            cmd = getCmd(alias);
        } else {
            List admObjsList = new Vector(admObjs.length);
            for (int i = 0; i < admObjs.length; i++) {
                admObjsList.set(i, admObjs[i]);
            }

            cmd = getCmd(alias, admObjsList);
        }

        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        return cmd;
    }

    public static Cmd getCmd(String alias, List objs) throws DimBaseException, AdmObjectException, AttrException {
        Cmd cmd = null;
        if ((objs == null) || (objs.size() == 0) || (objs.get(0) == null)) {
            cmd = getCmd(alias);
        } else {
            cmd = getCmd(alias, objs.get(0).getClass());
        }

        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        if ((!(cmd instanceof AdmCmd)) || (!((AdmCmd) cmd).supportsMultiple())) {
            cmd = new AdmIterativeCmd(cmd);
        }

        AdmObjectList admObjs = null;
        if ((objs != null) && (objs instanceof AdmObjectList)) {
            admObjs = (AdmObjectList) objs;
        } else {
            admObjs = new AdmObjectListImpl(objs);
        }

        cmd.setAttrValue(CmdArguments.ADM_OBJECT_LIST, admObjs);
        return cmd;
    }

    public static Cmd getCmd(String alias, Object admObj, Class secObjClass) throws DimBaseException, AdmObjectException,
            AttrException {
        Cmd cmd = null;
        if (secObjClass != null) {
            cmd = getCmd(alias, admObj.getClass(), secObjClass);
        } else if (admObj != null) {
            cmd = getCmd(alias, admObj.getClass());
        } else {
            cmd = getCmd(alias);
        }

        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        if (admObj != null) {
            cmd.setAttrValue(CmdArguments.ADM_OBJECT, admObj);
        }

        if (secObjClass != null) {
            cmd.setAttrValue(CmdArguments.ADM_SEC_CLASS, secObjClass);
        }

        return cmd;
    }

    public static Cmd getCmd(String alias, List objs, Class secObjClass) throws DimBaseException, AdmObjectException, AttrException {
        Cmd cmd = null;
        if (secObjClass != null) {
            cmd = getCmd(alias, objs.get(0).getClass(), secObjClass);
        } else if ((objs != null) && (objs.size() > 0) && (objs.get(0) != null)) {
            cmd = getCmd(alias, objs.get(0).getClass());
        } else {
            cmd = getCmd(alias);
        }

        if (cmd == null) {
            throw new DimBaseCmdException("Cannot obtain command: " + alias);
        }

        if ((!(cmd instanceof AdmCmd)) || (!((AdmCmd) cmd).supportsMultiple())) {
            cmd = new AdmIterativeCmd(cmd);
        }

        AdmObjectList admObjs = null;
        if ((objs != null) && (objs instanceof AdmObjectList)) {
            admObjs = (AdmObjectList) objs;
        } else {
            admObjs = new AdmObjectListImpl(objs);
        }

        cmd.setAttrValue(CmdArguments.ADM_OBJECT_LIST, admObjs);
        if (secObjClass != null) {
            cmd.setAttrValue(CmdArguments.ADM_SEC_CLASS, secObjClass);
        }

        return cmd;
    }

    // Static methods for Root AdmObject instances retrieval
    public static AdmObject getDefRootObj(Class objClass) {
        if (DimSystem.getSystem().getSessionBean() != null) {
            return DimSystem.getSystem().getSessionBean().getDefRootObj(objClass);
        }
        throw new RuntimeException("No session is registered for the thread");
    }

    public static AdmObject getOrInitDefRootObj(Class objClass) throws AdmException {
        final SessionBean sessionBean = DimSystem.getSystem().getSessionBean();
        if (sessionBean != null) {
            if (sessionBean.getDefRootObj(objClass) == null) {
                sessionBean.refreshRootObj(objClass);
            }
            return sessionBean.getDefRootObj(objClass);
        }
        throw new RuntimeException("No session is registered for the thread");
    }

    public static AdmObject getCurRootObj(Class objClass) {
        if (DimSystem.getSystem().getSessionBean() != null) {
            return DimSystem.getSystem().getSessionBean().getCurRootObj(objClass);
        }
        throw new RuntimeException("No session is registered for the thread");
    }

    public static void setCurRootObj(AdmObject curObject) {
        if (DimSystem.getSystem().getSessionBean() != null) {
            DimSystem.getSystem().getSessionBean().setCurRootObj(curObject);
        }
        throw new RuntimeException("No session is registered for the thread");
    }

    public static Cache getCache() {
        if (DimSystem.getSystem().getSessionBean() != null) {
            return DimSystem.getSystem().getSessionBean().getCache();
        }
        throw new RuntimeException("No session is registered for the thread");
    }

    // Static methods for AdmObject instances retrieval
    public static AdmObject getObject(AdmBaseId baseId) throws DimBaseException, AdmObjectException, AttrException, AdmException {
        return AdmHelperCmd.getObject(baseId);
    }

    public static AdmObject getObject(AdmBaseId baseId, Object attrNames) throws DimBaseException, AdmObjectException,
            AttrException, AdmException {
        return AdmHelperCmd.getObject(baseId, attrNames);
    }

    public static List getObjects(List baseIds) throws DimBaseException, AdmObjectException, AttrException, AdmException {
        return AdmHelperCmd.getObjects(baseIds);
    }

    public static List getObjects(List baseIds, Object attrNames) throws DimBaseException, AdmObjectException, AttrException,
            AdmException {
        return AdmHelperCmd.getObjects(baseIds, attrNames);
    }

    // Static methods for AdmBaseId instances retrieval
    public static AdmBaseId newAdmBaseId(long uid, Class objType) {
        return AdmHelperCmd.newAdmBaseId(uid, objType);
    }

    public static AdmBaseId newAdmBaseId(long uid, Class objType, Object scope) {
        return AdmHelperCmd.newAdmBaseId(uid, objType, scope);
    }

    public static AdmBaseId newAdmBaseId(long uid, Class objType, Object scope, AdmBaseId twin) {
        return AdmHelperCmd.newAdmBaseId(uid, objType, scope, twin);
    }

    public static AdmBaseId newAdmBaseId(String spec, Class objType) {
        return AdmHelperCmd.newAdmBaseId(spec, objType);
    }

    public static AdmBaseId newAdmBaseId(String spec, Class objType, Object scope) {
        return AdmHelperCmd.newAdmBaseId(spec, objType, scope);
    }

    public static AdmBaseId newAdmBaseId(String spec, Class objType, Object scope, AdmBaseId twin) {
        return AdmHelperCmd.newAdmBaseId(spec, objType, scope, twin);
    }

    public static AdmBaseId newAdmBaseId(List specComponents, Class objType) {
        return AdmHelperCmd.newAdmBaseId(specComponents, objType);
    }

    public static AdmBaseId newAdmBaseId(List specComponents, Class objType, Object scope) {
        return AdmHelperCmd.newAdmBaseId(specComponents, objType, scope);
    }

    public static AdmBaseId newAdmBaseId(List specComponents, Class objType, Object scope, AdmBaseId twin) {
        return AdmHelperCmd.newAdmBaseId(specComponents, objType, scope, twin);
    }

    /**
     * Static method for retrieving an attribute value from an single AdmObject.
     * Use this method in preference to <code>merant.adm.dimensions.objects.core.AdmObject.getAttrValue(java.lang.String)</code>
     * when the objects' attribute values may not have been queried.
     * Anything that appears inside a loop over a set of objects should <em>NOT</em> use this, but should instead query all of the
     * objects'
     * attributes upfront before entering the loop since this method may
     * cause an SQL query to get executed.
     */
    public static Object getAttributeValue(AdmObject admObj, String attrName) throws DBIOException, DimBaseException, AdmException {
        return AdmHelperCmd.getAttributeValue(admObj, attrName);
    }

    /**
     * Static method for retrieving an attribute value from an single AdmObject.
     * Use this method in preference to <code>merant.adm.dimensions.objects.core.AdmObject.getAttrValue(java.lang.String)</code>
     * when the objects' attribute values may not have been queried.
     * Anything that appears inside a loop over a set of objects should <em>NOT</em> use this, but should instead query all of the
     * objects'
     * attributes upfront before entering the loop since this method may
     * cause an SQL query to get executed.
     */
    public static Object getAttributeValue(AdmObject admObj, String attrName, boolean forceQuery) throws AdmException {
        return AdmHelperCmd.getAttributeValue(admObj, attrName, forceQuery);
    }

    /**
     * Static method for retrieving multiple attribute values from a single AdmObject.
     * @see AdmHelperCmd#getAttributeValues(AdmObject, List, boolean)
     */
    public static List getAttributeValues(AdmObject admObj, List attrNames) throws DBIOException, DimBaseException, AdmException {
        return AdmHelperCmd.getAttributeValues(admObj, attrNames);
    }

    public static void queryAttributes(AdmObject admObj, List<String> attrNames, boolean forceQuery) throws DBIOException, DimBaseException, AdmException {
        AdmHelperCmd.queryAttributes(admObj, attrNames, forceQuery);
    }

    public static void queryAttribute(AdmObject admObj, String attrName, boolean forceQuery) throws DBIOException, DimBaseException, AdmException {
        AdmHelperCmd.queryAttribute(admObj, attrName, forceQuery);
    }

    public static void queryAttributes(AdmObject admObj, List<String> attrNames) throws DBIOException, DimBaseException, AdmException {
        AdmHelperCmd.queryAttributes(admObj, attrNames);
    }

    public static void queryAttribute(AdmObject admObj, String attrName) throws DBIOException, DimBaseException, AdmException {
        AdmHelperCmd.queryAttribute(admObj, attrName);
    }

    /**
     * Static method for retrieving multiple attribute values from a single AdmObject.
     * @see AdmHelperCmd#getAttributeValues(AdmObject, List, boolean)
     */
    public static List getAttributeValues(AdmObject admObj, List attrNames, boolean forceQuery) throws DBIOException,
            DimBaseException, AdmException {
        return AdmHelperCmd.getAttributeValues(admObj, attrNames, forceQuery);
    }

    /**
     * Static method for retrieving an attribute value from multiple AdmObjects.
     * @see AdmHelperCmd#getAttributeValues(AdmObject, List, boolean)
     */
    public static List getAttributesValue(List admObjs, String attrName) throws DBIOException, DimBaseException, AdmException {
        return AdmHelperCmd.getAttributesValue(admObjs, attrName);
    }

    /**
     * Static method for retrieving an attribute value from multiple AdmObjects.
     * @see AdmHelperCmd#getAttributeValues(AdmObject, List, boolean)
     */
    public static List getAttributesValue(List admObjs, String attrName, boolean forceQuery) throws DBIOException,
            DimBaseException, AdmException {
        return AdmHelperCmd.getAttributesValue(admObjs, attrName, forceQuery);
    }

    /**
     * Static method for retrieving multiple attribute values from multiple AdmObjects.
     * @see AdmHelperCmd#getAttributeValues(AdmObject, List, boolean)
     */
    public static List getAttributesValues(List admObjs, List attrNames) throws DBIOException, DimBaseException, AdmException {
        return AdmHelperCmd.getAttributesValues(admObjs, attrNames);
    }

    /**
     * Static method for retrieving multiple attribute values from multiple AdmObjects.
     * @see AdmHelperCmd#getAttributeValues(AdmObject, List, boolean)
     */
    public static List getAttributesValues(List admObjs, List attrNames, boolean forceQuery) throws DBIOException,
            DimBaseException, AdmException {
        return AdmHelperCmd.getAttributesValues(admObjs, attrNames, forceQuery);
    }

    /**
     * Helper method to build up a set of attributes which will be processed by the command
     * while simultaneously removing these attributes from the <tt>attrNames</tt> list.
     * @param attrSet
     *            set of attributes to be processed
     * @param attrNames
     *            list of all attributes to be updated
     * @param attrName
     *            attribute to add to the set
     * @return the updated attribute set
     */
    protected Set updateAttrSet(Set attrSet, List attrNames, String attrName) {
        if (attrNames.remove(attrName)) {
            if (attrSet == null) {
                attrSet = new HashSet();
            }

            attrSet.add(attrName);
        }

        return attrSet;
    }

    /**
     * Helper method to return the value of the object's attribute only if that attribute's name
     * is in the specified attribute name set. Otherwise, null is returned.
     * @param admObj
     *            object whose attribute value is to be returned
     * @param attrName
     *            name of the attribute to return
     * @param attrSet
     *            attribute name set
     * @return attribute value of null, if attribute name is not in the attribute set
     */
    protected Object getAttrValue(AdmObject admObj, String attrName, Set attrSet) throws AdmObjectException {
        if (attrSet == null) {
            return null;
        }

        return (attrSet.contains(attrName) ? admObj.getAttrValue(attrName) : null);
    }

    /**
     * Used to find the String that occurs in a given String between the two specified
     * Strings. This is used to parse Dimensions command messages.
     */
    private static String stringBetween(String str, String start, String end) {
        String ret = null;
        int pos = 0;

        while (true) {
            int i = str.indexOf(start, pos);

            if (i == -1) {
                break;
            }

            int p = str.indexOf(end, i);

            if (p == -1) {
                pos = i + start.length();
                continue;
            }

            ret = str.substring(i + start.length(), p);

            break;
        }

        return ret;
    }

    /**
     * Populates an AdmBaseId given the output from the Dimensions command.
     * This is very tightly tied to the format of the return messages and
     * so is likely to break in future. This is also not I18N safe.
     * Unfortunately, it is necessary for at least the EI command, since
     * we need to get the new item revision's full spec in order to "patch"
     * the checked-out location.
     */
    public static void populateBaseIdFromAdmResult(Cmd origCmd, AdmResult admResult, Class admObjClass) throws AdmException {
        if (origCmd == null || admResult == null || admObjClass == null) {
            return;
        }
        String newSpec = null;
        String res = admResult.getResultMsg();

        // The new item revision's spec MUST be returned correctly when the Cmd
        // is Versionable.CHECK_OUT because this is used by web client to
        // "patch" the item revision's checked-out location to be the browser-
        // based user file location.
        //
        // Returning a good AdmBaseId for the Create Item and Create Request
        // Cmds may not be needed.

        if (origCmd.getAlias().equals("CreateItemCmd")) {
            // The CI message is actually:
            // "Item PD:ID.VT-TP;1 has been forwarded to USERID"
            newSpec = stringBetween(res, "Item ", " has been forwarded to");
        } else if (origCmd.getAlias().equals(Versionable.CHECK_OUT)) {
            // Check for possible EI messages:
            // "Checked out Item PD-ID.VT-TP;2" is DM10.1 turnover 11,
            // "Extracted Item PD-ID.VT-TP;2" is DM10.1 turnover 10 or earlier,
            // "Checked Out Item ..." or "Checked out item ..." are plausible
            // variations for future versions of Dimensions (to make this less
            // fragile).
            newSpec = stringBetween(res, "Checked out Item ", "\n");
            if (newSpec == null) {
                newSpec = stringBetween(res, "Extracted Item ", "\n");
                if (newSpec == null) {
                    newSpec = stringBetween(res, "Checked Out Item ", "\n");
                    if (newSpec == null) {
                        newSpec = stringBetween(res, "Checked out item ", "\n");
                    }
                }
            }
        } else if (origCmd.getAlias().equals(Versionable.CHECK_IN)) {
            // Check for following messages:
            // SUCCESS: Item QLARIUS:TEST.A-SRC;1.1 has been forwarded to DMSYS
            // Returned Item QLARIUS:TEST.A-SRC;1.1
            newSpec = stringBetween(res, "Item ", " has been forwarded to");
            if (newSpec == null) {
                newSpec = stringBetween(res, "Returned Item ", "\n");
            }
        } else if (origCmd.getAlias().equals("CreateChangeDocumentCmd")
                || (origCmd.getAlias().equals(Creatable.CREATE) && admObjClass.equals(ChangeDocument.class))) {
            // First try and find the normal Create Request message:
            // "The request PD_TP_1 has been forwarded to USERID"
            // But if that fails then look for a held request message:
            // "The request will be PD_HELD_1"
            // But if that fails then look for a forwarded to no user message:
            // "The request PD_TP_1 has not been forwarded to any user"
            newSpec = stringBetween(res, "The request ", " has been forwarded to");
            if (newSpec == null) {
                newSpec = stringBetween(res, "The request will be ", "\n");
            }
            if (newSpec == null) {
                newSpec = stringBetween(res, "The request ", " has not been forwarded to any user");
            }
        } else if (origCmd.getAlias().equals("Creatable.CreateScheduledJob")) {
            newSpec = (String) origCmd.getAttrValue(AdmAttrNames.ID);
        } else {
            // All other objects just return "Operation completed"
            // so we have to trust that the command created the object we asked it to create!
            newSpec = (String) origCmd.getAttrValue(CmdArguments.INT_SPEC);
        }

        if (newSpec != null) {
            Debug.println("AdmCmd.populateBaseIdFromAdmResult(...) newSpec = " + newSpec);
            Object scope = origCmd.getAttrValue(CmdArguments.INT_SCOPE);
            if (!(scope instanceof AdmBaseId)) {
                admResult.setUserData(new AdmSpec(newSpec, admObjClass));
            } else {
                admResult.setUserData(AdmHelperCmd.newAdmBaseId(newSpec, admObjClass, scope));
            }
        }
    }

    // As importing merant.adm.dimensions.objects creates a circular
    // dependency - for the sake of these convenience methods - we
    // will cheat and construct the classes at runtime
    private static Class _productClass = null;

    private static Class getProductClass() {
        if (_productClass != null) {
            return _productClass;
        }

        try {
            _productClass = Class.forName("merant.adm.dimensions.objects.Product");
        } catch (ClassNotFoundException e) {
            Debug.error(e);
        }

        return _productClass;
    }

    private static Class _roleDefClass = null;

    private static Class getRoleDefClass() {
        if (_roleDefClass != null) {
            return _roleDefClass;
        }

        try {
            _roleDefClass = Class.forName("merant.adm.dimensions.objects.RoleDefinition");
        } catch (ClassNotFoundException e) {
            Debug.error(e);
        }

        return _roleDefClass;
    }

    private static Class _profileDefClass = null;

    private static Class getProfileDefClass() {
        if (_profileDefClass != null) {
            return _profileDefClass;
        }

        try {
            _profileDefClass = Class.forName("merant.adm.dimensions.objects.ProfileDefinition");
        } catch (ClassNotFoundException e) {
            Debug.error(e);
        }

        return _profileDefClass;
    }

    /**
     * Determines whether the currently logged in user is has PCMS$CONSULTANT role
     */
    protected static boolean hasPcmsConsultantRole(String productName) throws AdmException {
        return hasRole(Constants.ROLE_PCMS_CONSULTANT, productName);
    }

    /**
     * Determines if the currently logged in user is in the specified role within the product
     */
    private static boolean hasRole(String roleName, String productName) throws AdmException {
        AdmObject admProdObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(productName, getProductClass()));

        if (admProdObj == null) {
            throw new DimBaseCmdException("Unable to resolve product - for role check!");
        }

        AdmObject admObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(roleName, getRoleDefClass()));

        if (admObj == null) {
            throw new DimBaseCmdException("Unable to resolve role - for role check!");
        }

        return hasRole(admObj, admProdObj);
    }

    /**
     * Determines if the currently logged in user is in role represented by the role object within the specified scope
     */
    private static boolean hasRole(AdmObject roleObj, AdmObject scope) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Auditable.HAS_ROLE, roleObj);
        if (scope != null) {
            cmd.setAttrValue(CmdArguments.ADM_SCOPE_OBJECT, scope);
        }

        Boolean hasRole = (Boolean) cmd.execute();

        if ((hasRole == null) || (!hasRole.booleanValue())) {
            return false;
        }
        return true;
    }

    /**
     * Determines if the currently logged in user is in the specified profile
     */
    protected static boolean hasProfile(String profileName) throws AdmException {
        AdmObject admObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(profileName, getProfileDefClass()));

        if (admObj == null) {
            throw new DimBaseCmdException("Unable to resolve profile - for profile check!");
        }

        return hasProfile(admObj);
    }

    /**
     * Determines if the currently logged in user is in profile represented by the profile object
     */
    protected static boolean hasProfile(AdmObject profileObj) throws AdmException {
        return hasProfile(profileObj, null);
    }

    /**
     * Determines if the currently logged in user is in profile represented by the profile object within the specified scope
     */
    protected static boolean hasProfile(AdmObject profileObj, AdmObject scope) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Auditable.HAS_PROFILE, profileObj);
        if (scope != null) {
            cmd.setAttrValue(CmdArguments.ADM_SCOPE_OBJECT, scope);
        }

        Boolean hasProfile = (Boolean) cmd.execute();

        if ((hasProfile == null) || (!hasProfile.booleanValue())) {
            return false;
        }
        return true;
    }

    /**
     * Internal convenience method for executing and
     * returning Auditable.GET_NEW_UID as a long.
     * <p>
     */
    protected static long getNewUid() throws AdmException {
        return getNewUid(null);
    }

    /**
     * Internal convenience method for executing and
     * returning Auditable.GET_NEW_UID as a long.
     * <p>
     * Commands were executing GET_NEW_UID directly, however, many were casting as a String which DB2 cannot cope with. Therefore
     * this is provided as a common mechanism to return as a correctly casted uid for insertion into the Dimensions DB.
     */
    protected static long getNewUid(Object query) throws AdmException {
        Cmd cmd = getCmd(Auditable.GET_NEW_UID);
        if (query != null) {
            cmd.setAttrValue(CmdArguments.DBIO_QUERY, query);
        }

        return ((Integer) cmd.execute()).longValue();
    }

    /**
     * Gets all children of the specified parent. The children are identified by an optional filter.
     * @param admParentObj
     *            parent object
     * @param admChildClass
     *            child object class
     * @param filt
     *            child filter
     * @param attrNames
     *            list of attributes to populate the children with
     * @return null, if no chilren matching the specified criteria exist, or list of child objects
     *         pre-populated with the specified attributes
     */
    protected static List queryChildren(AdmObject admParentObj, Class admChildClass, Filter filt, List attrNames)
            throws AdmException {
        // get command to query relationship
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admParentObj, admChildClass);

        // set filter
        if (filt != null) {
            cmd.setAttrValue(CmdArguments.FILTER, filt);
        }

        // get base identifiers of children
        List baseIds = (List) cmd.execute();
        if ((baseIds == null) || (baseIds.size() == 0)) {
            return null;
        }

        // convert base identifiers to objects
        List admChildrenList = AdmHelperCmd.getObjects(baseIds, attrNames);
        return admChildrenList;
    }

    /**
     * Get one child of the specified parent. The child is identified by an optional filter.
     * @param admParentObj
     *            parent object
     * @param admChildClass
     *            child object class
     * @param filter
     *            child filter
     * @param attrNames
     *            list of attributes to populate the child with
     * @return null, if no chilren matching the specified criteria exist, or the first child object
     *         pre-populated with the specified attributes
     */
    protected static AdmObject queryChild(AdmObject admParentObj, Class admChildClass, Filter filter, List attrNames)
            throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, admParentObj, admChildClass);

        if (filter != null) {
            cmd.setAttrValue(CmdArguments.FILTER, filter);
        }

        AdmBaseId baseId = (AdmBaseId) cmd.execute();
        if (baseId == null) {
            return null;
        }

        AdmObject admChildObj = AdmHelperCmd.getObject(baseId, attrNames);

        return admChildObj;
    }

    /**
     * Returns the logged-in base database object as a BaseDatabase object
     * instance.
     * @return The current base database
     */
    public static BaseDatabase getCurBaseDatabase() {
        return (BaseDatabase) AdmCmd.getCurRootObj(BaseDatabase.class);
    }

    /**
     * Returns the current project as a WorkSet object instance.
     * <p>
     * @return The current project
     */
    public static WorkSet getCurWorkSet() {
        return (WorkSet) AdmCmd.getCurRootObj(WorkSet.class);
    }

}

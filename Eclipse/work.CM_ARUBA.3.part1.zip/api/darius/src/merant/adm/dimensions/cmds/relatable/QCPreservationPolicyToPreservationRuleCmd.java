/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.PreservationPolicy;
import merant.adm.dimensions.objects.PreservationRule;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all PreservationRules's related to a PreservationPolicy object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Pauls
 */
public class QCPreservationPolicyToPreservationRuleCmd extends QueryRelsCmd {
    public QCPreservationPolicyToPreservationRuleCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof PreservationPolicy)) {
                throw new AttrException("QCPreservationPolicyToPreservationRuleCmd Error: Adm Object type is not supported!",
                        attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(PreservationRule.class))) {
                throw new AttrException("QCPreservationPolicyToPreservationRuleCmd Error: Child object type is not supported!",
                        attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();
        DBIO query = null;

        /* Llew 30-jan-2006 Added filter support */
        if (filter != null && filter.hasAttr(AdmAttrNames.TYPE_NAME)) {
            String typeName = (String) filter.get(AdmAttrNames.TYPE_NAME);
            query = new DBIO(wcm_sql.GET_PRESERVATIONPOLICY_PRESERVATIONRULE2);
            query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
            query.bindInput(typeName, String.class);
        } else {
            query = new DBIO(wcm_sql.GET_PRESERVATIONPOLICY_PRESERVATIONRULE);
            query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
        }

        query.readStart();
        while (query.read()) {
            addRelation(
                    ret,
                    relationships,
                    admObj.getAdmBaseId(),
                    AdmHelperCmd.newAdmBaseId(query.getLong(1), admSecClass, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(2), admSecClass, null, null)));
        }

        return ret;
    }
}

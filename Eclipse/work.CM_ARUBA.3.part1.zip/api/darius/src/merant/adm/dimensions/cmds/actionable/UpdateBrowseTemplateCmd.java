/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * PVCS:UBTC JAVA.A-SRC;main_80#1
 * Description:
 * Item UBTC JAVA.A
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.BrowseTemplate;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will add/import a browse template.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>USER_FILE{String}<dt><dd>User filename of the browse template.</dd>
 * </dl></code> <br>
 * <b>Option Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT{AdmObject}<dt>
 *  <dd>
 *      Dimensions Browse Template. If this argument is specified, then the template will be imported from the USER_FILE.
 *      If this argument is not specified, then the following arguments will specify the details of a new BrowseTemplate.
 * </dd>
 *  <dt>PRODUCT_NAME{String}<dt><dd>Dimensions Product name. </dd>
 *  <dt>PARENT_CLASS{CLASS}<dt><dd>Dimensions Type Class. Only Item.class and ChangeDocument.class are supported</dd>
 *  <dt>ID{String}<dt><dd>template name</dd>
 *  <dt>REVISION {String}<dt><dd>template revision</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class UpdateBrowseTemplateCmd extends RPCExecCmd {
    public UpdateBrowseTemplateCmd() throws AttrException {
        super();
        setAlias(Actionable.UPDATE_BROWSE_TEMPLATE);
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_CLASS, false, Class.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REVISION, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((attrValue != null) && !(attrValue instanceof BrowseTemplate)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        String fileName = (String) getAttrValue(CmdArguments.USER_FILE);

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        String productName = null;
        Class scope = null;
        String templateName = null;
        String revision = null;
        boolean bImport = false;

        if (admObj != null) {
            bImport = true;
            List attrs = AdmHelperCmd.getAttributeValues(
                    admObj,
                    Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.PARENT_CLASS, AdmAttrNames.ID,
                            AdmAttrNames.REVISION }));

            productName = (String) attrs.get(0);
            scope = (Class) attrs.get(1);
            templateName = (String) attrs.get(2);
            revision = (String) attrs.get(3);
        } else {
            revision = (String) getAttrValue(AdmAttrNames.REVISION);
            templateName = (String) getAttrValue(AdmAttrNames.ID);
            scope = (Class) getAttrValue(AdmAttrNames.PARENT_CLASS);
            productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        }

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJTMPL ");

        if (templateName == null || templateName.length() == 0) {
            throw new DimInvalidAttributeException("Error: template name is not specified.");
        } else {
            templateName = templateName.trim().toUpperCase();
        if (templateName.length() > 25) {
            templateName = templateName.substring(0, 25);
        }

            cmdBuf.append(Encoding.escapeDMCLI(templateName));
        }

            if (!bImport) {
                // add new template revision
            cmdBuf.append(" /ADD");
            } else {
                // import new file into an existing template revisision
            cmdBuf.append(" /IMPORT");
            }

        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));

        if (Item.class.equals(scope)) {
            cmdBuf.append(" /OBJ_CLASS=ITEM");
        } else if (ChangeDocument.class.equals(scope)){
            cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else {
            throw new DimInvalidAttributeException("Error: unsupported object class");
    }

        if (fileName == null || fileName.length() == 0) {
            throw new DimInvalidAttributeException("Error: the filename the template is to be imported from must be specified.");
        } else {
            fileName = fileName.trim();
            cmdBuf.append(" /FILENAME=").append(Encoding.escapeDMCLI(fileName));
    }

        if (revision == null || revision.length() == 0) {
            throw new DimInvalidAttributeException("Error: template revision number is not specified.");
        } else {
            revision = revision.trim().toUpperCase();
            if (revision.length() > 25) {
                revision = revision.substring(0, 25);
        }

            cmdBuf.append(" /REVISION=").append(Encoding.escapeDMCLI(revision));
    }

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
        }
}

// FUNCTION WRITE_DBFILE (operation_mode varchar2,
// fileUid integer, objClass integer,
// attrNo integer, binaryMode boolean, userFilename varchar2) RETURN boolean IS
// command varchar2 (1024);
// status boolean := FALSE;
// username varchar2 (40);
// status_ret pls_integer;
// conId pls_integer;
// x pls_integer;
// y pls_integer;
// z pls_integer;
// update_flag pls_integer;
// filename varchar2 (2000) := userFilename;
// errMsg varchar2 (2000);
// tempInt pls_integer;
//
// BEGIN
// if name_in ('global.operating_system') = 'WINDOWS' then
// set_application_property (cursor_style, 'BUSY');
// conId := TO_NUMBER (name_in ('global.conId'));
//
// if binaryMode then
// PcmsClnt.PcmsClntModeBinary (conId);
// else
// PcmsClnt.PcmsClntModeText (conId);
// end if;
//
// x := fileUid;
// y := objClass;
// z := attrNo;
// if operation_mode = 'UPDATE' then
// update_flag := 1;
// else
// update_flag := 0;
// end if;
// status_ret := PcmsClnt.PcmsClntPutAttrFile (conId,x, y, z, update_flag, filename);
// tempInt := PcmsClnt.PcmsClntGetLastError (conId, errMsg, 2000);
// if status_ret = 1 then
// status := TRUE;
// else
// fatal_alert (errMsg);
// end if;
// set_application_property (cursor_style, 'DEFAULT');
// else
// command := 'DATA ';
// command := command || '"' || to_char (fileUid) || ' ' || to_char (objClass);
// command := command || ' update_dbfile';
// command := command || '" ';
// command := command || '"' || to_char (attrNo) || ' ' || filename || ' ';
// if operation_mode = 'UPDATE' then
// command := command || '1 1"';
// else
// command := command || '0 1"';
// end if;
// -- info_alert(command);
// status := exec_pcms_command ('pcms', command, FALSE, NULL);
// end if;
//
// set_application_property (cursor_style, 'DEFAULT');
// return (status);
// END;

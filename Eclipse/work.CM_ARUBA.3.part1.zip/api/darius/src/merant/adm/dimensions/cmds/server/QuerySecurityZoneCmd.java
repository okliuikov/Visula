/*
 * Copyright (C) 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DmCfgConstants;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.exception.DimDatabaseConnectException;
import merant.adm.dimensions.exception.DimInvalidPropertyException;
import merant.adm.dimensions.objects.SecurityZone;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.AttrExceptionArray;
import merant.adm.framework.CmdArgDef;
import merant.adm.session.Session;

/**
 * This command will get info about the security zone for a user, where a
 * security zone is the set of products that the user is allowed to see.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>None</dt> * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>None</dt>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{SecurityZone}</dt><dd> the security zone object.</dd>
 * </dl></code>
 */
public class QuerySecurityZoneCmd extends AdmCmd {
    public QuerySecurityZoneCmd() throws AttrException {
        super();
        setAlias(Server.QUERY_SECURITY_ZONE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public Object execute() throws AttrException, AttrExceptionArray {
        validateAllAttrs();
        String effective = null;
        try {
            effective = ((Session) DimSystem.getSystem().getSession()).getConnection().rpcPcmsGetSymbol(
                    DmCfgConstants.DM_PRODUCT_USER);
        } catch (IOException e) {
            /* Do nothing, restrict will be null. */
        }
        List products = null;
        if (effective != null && effective.trim().length() != 0) {
            try {
                products = getProducts();
            } catch (AdmException ae) {
                /* Do nothing, products will be null. */
            }
        }
        return new SecurityZone(products != null, products);
    }

    private List getProducts() throws DimInvalidPropertyException, DimDatabaseConnectException, DBIOException, AdmObjectException,
            AttrException, DimConnectionException {
        /* Which user to check? */
        AdmObject user = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        if (user == null || !(user instanceof User)) {
            user = AdmCmd.getCurRootObj(User.class);
        }
        /* Query the products that the user has a role on. */
        List ret = new ArrayList();
        DBIO query = new DBIO("SELECT DISTINCT psc.product_id" + " FROM part_spec_catalogue psc, rm_users ru"
                + " WHERE psc.obj_id=psc.product_id" + " AND ru.user_name=:I1" + " AND ru.product_id=psc.product_id");
        try {
            query.bindInput(user.getId());
            query.readStart();
            while (query.read()) {
                ret.add(query.getString(1));
            }
        } finally {
            query.close();
        }
        return ret;
    }
}

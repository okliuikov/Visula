/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  (Micro Focus) are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for system commands.
 * <p>
 * This applies to global server system commands.
 * @author Floz
 */
public interface Server {
    public static final String AUTH = "Server.Auth";
    public static final String AUTH_POINT_INFO_REQUESTED = "Server.AuthPointInfoRequested";
    public static final String GET_CUR_ROOT_OBJ = "Server.GetCurRootObj";
    public static final String GET_CWS = "Server.GetCws";
    public static final String GET_DEF_ROOT_OBJ = "Server.GetDefRootObj";
    public static final String LOGIN = "Server.Login";
    public static final String LOGOUT = "Server.Logout";
    public static final String QUERY_KEYINFO = "Server.QueryKeyInfo";
    public static final String QUERY_VERSION = "Server.QueryVersion";
    public static final String REFRESH_ATTR_CACHE = "Server.RefreshAttrCache";
    public static final String RUN = "Server.Run";
    public static final String SET_CUR_ROOT_OBJ = "Server.SetCurRootObj";
    public static final String USER_PREF = "Server.UserPref";
    public static final String QUERY_SECURITY_ZONE = "Server.QuerySecurityZone";
    public static final String QUERY_DEFAULT_IDM_TOOL = "Server.QueryDefaultIDMTool";
    public static final String UPDATE_DEFAULT_IDM_TOOL = "Server.UpdateDefaultIDMTool";
    public static final String QUERY_IS_AREA_ON_MVS_NODE = "Server.QueryIsAreaOnMVSNode";
    public static final String EXTERNAL_REQUEST_PROVIDER_BASIC_AUTH = "Server.ExternalRequestProviderBasicAuth";
}

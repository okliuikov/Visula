/*
 * %HEADER%
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.auditable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.DimHistory;
import merant.adm.dimensions.objects.DimLastAttrUpdate;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Returns a set of history objects for a list of dimensions objectd.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT_LIST {AdmObject}<dt><dd>List of dimensions objects</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>List<dt><dd>List of adm history objects</dd>
 * </dl></code>
 * @author PBate
 */
public class GetLastAttrUpdateCmd extends DBIOCmd {
    public GetLastAttrUpdateCmd() throws AttrException {
        super();
        setAlias(Auditable.GET_LASTATTR_UPDATE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, List.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT_LIST)) {
            if (!(attrValue instanceof List)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        List admObjList = (List) getAttrValue(CmdArguments.ADM_OBJECT_LIST);

        List histObjs = null;
        DBIO query = null;
        if (admObjList == null) {
            return null;
        }
        AdmObject admObj = (AdmObject) admObjList.get(0);

        if (admObj instanceof Item) {
            query = new DBIO(wcm_sql.QUERY_LASTEDITATTR_ITEM);
        } else if (admObj instanceof ChangeDocument) {
            query = new DBIO(wcm_sql.QUERY_LASTEDITATTR_REQUEST);
        } else if (admObj instanceof Baseline) {
            query = new DBIO(wcm_sql.QUERY_LASTEDITATTR_BLINE);
        } else if (admObj instanceof WorkSet) {
            query = new DBIO(wcm_sql.QUERY_LASTEDITATTR_PROJECT);
        } else {
            // the admobject isn't anything we can query for
            return null;
        }

        if (admObjList.size() == 1) {
            query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
        } else if (admObjList.size() > 1) {
            query.bindInput(CmdUtils.getUidList(admObjList));
        }

        query.readStart();
        histObjs = new ArrayList();
        DimHistory histRec = null;

        // Start to read results...
        //
        while (query.read()) {
            histRec = new DimLastAttrUpdate();

            histRec.setAttrValue(AdmAttrNames.USER_NAME, query.getString(1));
            histRec.setAttrValue(AdmAttrNames.UPDATE_DATE, query.getString(2));
            if (admObjList.size() > 1) {
                histRec.setAttrValue(CmdArguments.ADM_OBJECT,
                        AdmCmd.getObject(AdmCmd.newAdmBaseId(query.getLong(3), admObj.getClass())));
            } else {
                histRec.setAttrValue(CmdArguments.ADM_OBJECT, admObj);
            }

            histObjs.add(histRec);
        }

        return (histObjs);
    }
}

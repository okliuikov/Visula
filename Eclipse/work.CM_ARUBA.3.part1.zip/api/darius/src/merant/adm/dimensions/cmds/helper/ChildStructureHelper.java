package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;
import java.util.List;

import com.serena.dmnet.drs.DRSClientQueryStructure;
import com.serena.dmnet.drs.DRSClientQueryStructure.Context;
import com.serena.dmnet.drs.DRSClientQueryStructure.WorksetNode;

import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.FolderInfo;
import merant.adm.exception.AdmException;

/**
 * 
 * @author kberezovchuk
 * 
 */
public class ChildStructureHelper {

    public static List<FolderInfo> queryWorksetVersionChildFoldersInfo(long wsetUid, long wsetVersion) throws AdmException {
        DRSClientQueryStructure drs = new DRSClientQueryStructure(Context.GetWorksetVersionFolders);
        drs.setWorksetUid(wsetUid);
        drs.setWorksetVersion(wsetVersion);

        return internalQueryStreamStructure(drs);
    }

    public static List<FolderInfo> queryWorksetChildFoldersInfo(long wsetUid) throws AdmException {
        DRSClientQueryStructure drs = new DRSClientQueryStructure(Context.GetWorksetFolders);
        drs.setWorksetUid(wsetUid);

        return internalQueryStreamStructure(drs);
    }

    public static List<FolderInfo> queryBaselineChildFoldersInfo(long scopeUid) throws AdmException {
        DRSClientQueryStructure drs = new DRSClientQueryStructure(Context.GetBaselineFolders);
        drs.setWorksetUid(scopeUid);

        return internalQueryStreamStructure(drs);
    }

    private static List<FolderInfo> internalQueryStreamStructure(DRSClientQueryStructure drs) throws AdmException {
        List<FolderInfo> result = new ArrayList<FolderInfo>();

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            traverseNodeStructure(drs.getRootNode(), result);
        }
        return result;
    }

    private static void traverseNodeStructure(WorksetNode parentNode, List<FolderInfo> resultList) {
        for (WorksetNode node : parentNode.getChildren()) {
            resultList.add(new FolderInfo(node.getFullPath(), node.getUid()));
            traverseNodeStructure(node, resultList);
        }
    }

}

package merant.adm.dimensions.cmds;

import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.session.Session;

/**
 * This command calls the Dimensions RPC to test whether the connection is still alive.
 * <p>
 * This command has no arguments.<br>
 * <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>Integer<dt>Constants.PCMS_OK<dt>Constants.PCMS_FAIL</dd>
 * </dl></code>
 *
 * @author Dharris
 *
 */
public class RPCPingServer extends RPCCmd {

    /**
     * Constructs a new RPCPingServer object
     *
     */
    public RPCPingServer() {
        super();
    }

    @Override
    public Object execute() throws AdmException {
        int type = -1;
        try {
            type = ((Session) DimSystem.getSystem().getSession()).getConnection().pingServer();
        } catch (Exception ex) {
            Debug.error(ex);
        }
        return Integer.valueOf(type);
    }
}

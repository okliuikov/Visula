/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.PrototypeObject;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Prototype Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * 	<dt>ID {String}<dt><dd>Identifier of the new object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION{String}<dt><dd>Description string</dd>
 *  <dt>TYPE_NAME{String}<dt><dd>Type of object</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 * 	<dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author
 */
public class CreatePrototypeObjectCmd extends RPCExecCmd {

    public CreatePrototypeObjectCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        String id = (String) getAttrValue(AdmAttrNames.ID);
        String description = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String type = (String) getAttrValue(AdmAttrNames.TYPE_NAME);

        StringBuffer sb = new StringBuffer();

        sb.append("ADD THE CORRECT CMDLINE HERE ");
        sb.append(Encoding.escapeSpec(id));

        if (description != null && description.length() > 0) {
            sb.append(" /DESCRIPTION=");
            sb.append(Encoding.escapeDMCLI(description));
        }
        if (type != null && type.length() > 0) {
            sb.append(" /TYPE=");
            sb.append(Encoding.escapeDMCLI(type));
        }

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, PrototypeObject.class);
        return retResult;
    }
}

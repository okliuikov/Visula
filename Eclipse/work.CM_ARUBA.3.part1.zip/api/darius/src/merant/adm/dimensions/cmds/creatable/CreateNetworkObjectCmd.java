/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetObject;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a NetObject object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new network object</dd>
 *  <dt>DESCRIPTION {String}</dt><dd>.</dd>
 *  <dt>NETOBJ_PROCESS {String}</dt><dd>.</dd>
 *  <dt>NETOBJ_PROTOCOL_SPEC {String}</dt><dd>.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateNetworkObjectCmd extends RPCExecCmd {
    public CreateNetworkObjectCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETOBJ_PROCESS, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.NETOBJ_PROTOCOL_SPEC, true, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String netProcess = (String) getAttrValue(AdmAttrNames.NETOBJ_PROCESS);
        String netProtocol = (String) getAttrValue(AdmAttrNames.NETOBJ_PROTOCOL_SPEC);

        setAttrValue(CmdArguments.INT_SPEC, id);

        _cmdStr = "CNWO ";
        _cmdStr += " /NWO_NAME=" + Encoding.escapeSpec(id);
        _cmdStr += " /DESCRIPTION=\"" + desc + "\"";
        _cmdStr += " /PROCESS=\"" + netProcess + "\"";
        _cmdStr += " /PROTOCOL=\"" + netProtocol + "\"";

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, NetObject.class);
        return retResult;
    }
}

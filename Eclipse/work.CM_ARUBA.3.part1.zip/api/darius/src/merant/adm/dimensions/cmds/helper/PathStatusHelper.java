/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import com.serena.dmnet.drs.DRSClientQueryPathStatus;

import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.PathStatus;
import merant.adm.dimensions.server.drs.objects.PathStatusHandler;
import merant.adm.exception.AdmException;

public class PathStatusHelper {

    public static void queryPaths(long treeUid, String[] paths, PathStatusHandler handler, int options) throws AdmException {

        DRSClientQueryPathStatus drs = new DRSClientQueryPathStatus();
        drs.setTreeUid(treeUid);
        drs.setPaths(paths);
        drs.setOptions(options);

        DRSUtils.execute(drs);

        if (drs.hasData() && drs.getCount() != 0) {
            int[] statuses = drs.getPathStatuses();
            int[] dirOrSpecUids = drs.getDirOrSpecUids();
            int[] itemUids = drs.getItemUids();

            for (int i = 0; i < statuses.length; i++) {
                PathStatus ps = new PathStatus(paths[i], statuses[i], dirOrSpecUids[i], itemUids[i]);
                handler.handlePathStatus(ps);
            }
        }
    }
}

/*
 * Copyright (C), 2005-2006, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.AdmUidObjectImpl;
import merant.adm.dimensions.objects.Requirement;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will query the children of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId or Relationship instances</dd>
 * </dl></code>
 * 
 * 
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
public class QCReqColToReqCmd extends QueryRelsCmd {
    public QCReqColToReqCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_CHILDREN);
        // * I don't think we need this.
        // x setAttrDef(new CmdArgDef(CmdArguments.ADM_CHILD_CLASS, true,
        // x Class.class));
        // x setAttrDef(new CmdArgDef(CmdArguments.MULTIPLE, false, Boolean.FALSE,
        // x Boolean.class));

        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTE_NAMES, true));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ATTRIBUTE_NAMES)) {
            if ((attrValue != null) && !(attrValue instanceof List)) {
                throw new AttrException("Error: Attribute name should be a List of String's", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean relationships = ((Boolean) getAttrValue(CmdArguments.RELATIONSHIPS)).booleanValue();
        FilterImpl filter = (FilterImpl) getAttrValue((CmdArguments.FILTER));

        // If Attributes are required then objects should be returned instead of Ids
        List attrNames = null;
        if (getAttrValue(CmdArguments.ATTRIBUTE_NAMES) != null) {
            attrNames = new Vector((List) getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
        }
        boolean isRequirementsShouldBeReturned = (attrNames != null && attrNames.size() > 0);

        List ret = new Vector();
        ArrayList containerDetails = new ArrayList();
        try {
            SuperQuery sq = new SuperQuery();

            sq.setObjectType(Requirement.class);
            sq.setScope(new AdmBaseId(WorkSet.class));

            // Specify the attributes we want back
            if (!isRequirementsShouldBeReturned) {
                sq.addSelect(AdmAttrNames.CLASS_UID); // class id
                sq.addSelect(AdmAttrNames.RTM_ID); // object id
                sq.addSelect(AdmAttrNames.ADM_UID); // Dimensions requirement object id
                sq.addSelect(AdmAttrNames.ADM_SPEC); //
                sq.addSelect(AdmAttrNames.RTM_COL_TYPE); // type of container(ie, collection or baseline)
                sq.addSelect(AdmAttrNames.RTM_COL_SPEC); // name of container
            } else {
                // Force Requirements to be returned instead of Ids
                sq.addSelect(AdmAttrNames.CLASS_UID); // class id
                sq.addSelect(AdmAttrNames.RTM_ID); // object id
                sq.addSelect(AdmAttrNames.ADM_SPEC); // spec
                sq.addSelect(AdmAttrNames.STATUS); // status
                sq.addSelect(AdmAttrNames.ORIGINATOR); // created by
                sq.addSelect(AdmAttrNames.USER_NAME); // modified by
                sq.addSelect(AdmAttrNames.CREATE_DATE); // time created
                sq.addSelect(AdmAttrNames.UPDATE_DATE); // time modified
                sq.addSelect(AdmAttrNames.CLASS_SPEC); // class name
                sq.addSelect(AdmAttrNames.DESCRIPTION); // 'first available text attribute'
                sq.addSelect(AdmAttrNames.RTM_TITLE); // title
                sq.addSelect(AdmAttrNames.RTM_COL_TYPE); // type of container(ie, collection or baseline)
                sq.addSelect(AdmAttrNames.RTM_COL_SPEC); // name of container
                sq.addSelect(AdmAttrNames.ID); // puid
                sq.addSelect(AdmAttrNames.RTM_PROJ_NAME); // name of RM project
                sq.addSelect(AdmAttrNames.RTM_PROJ_DBNAME); // db name of RM project
                sq.addSelect(AdmAttrNames.RTM_PROJ_URL); // url of RM project
                sq.addSelect(AdmAttrNames.RTM_PROJ_ID); // id of RM project
                sq.addSelect(AdmAttrNames.ADM_UID); // Dimensions requirement object id
            }

            sq.addRel(admObj);

            // Prepare "WHERE" & "ORDER BY" criteria
            if (filter != null)
            {
                Collection c = filter.criteria();
                if (c != null)
                {
                    for (Iterator it = c.iterator(); it.hasNext();)
                    {
                        FilterCriterion fc = (FilterCriterion) it.next();
                        //* Only add filters that are not
                        if (fc != null && fc.getValue() != null && ((String) fc.getValue()).length() > 0)
                        {
                            //* We don't care about flags in the ALM integration
                            sq.addWhere(fc.getAttrName(), (String) fc.getValue());
                        }
                    }
                }

                Collection orders = filter.orders();
                if (orders != null)
                {
                    for (Iterator it = orders.iterator(); it.hasNext();)
                    {
                        FilterOrder fc = (FilterOrder) it.next();
                        sq.addOrder(fc.getAttrName(), (fc.getFlags() & FilterOrder.DESCENDING) == FilterOrder.DESCENDING ? true : false);
                    }
                }
            }

            sq.addDefaultOrder();

            sq.readStart();

            while (sq.read()) {
                if (!isRequirementsShouldBeReturned) {
                    // Store the container details of requirements to use when querying requirement attributes
                    containerDetails.add(new String[] { sq.getString(5), sq.getString(6) });

                    addRelation(
                            ret,
                            relationships,
                            admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(sq.getLong(3), Requirement.class, admObj.getAdmBaseId(),
                                    AdmHelperCmd.newAdmBaseId(sq.getString(4), Requirement.class, admObj.getAdmBaseId(), null)));
                } else {

                    AdmBaseId reqBaseId = AdmHelperCmd.newAdmBaseId(sq.getLong(19), Requirement.class, admObj.getAdmBaseId());
                    Requirement req = new Requirement(reqBaseId);

                    if (attrNames.contains(AdmAttrNames.CLASS_UID)) {
                        req.setAttrValue(AdmAttrNames.CLASS_UID, new Long(sq.getLong(1)));
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_ID)) {
                        req.setAttrValue(AdmAttrNames.RTM_ID, new Long(sq.getLong(2)));
                    }
                    if (attrNames.contains(AdmAttrNames.ADM_SPEC)) {
                        String spec2 = sq.getString(3);
                        spec2 = trimChar(spec2, '\"');
                        ((AdmUidObjectImpl) req).setAdmSpec(new AdmSpec(spec2, Requirement.class));
                    }
                    if (attrNames.contains(AdmAttrNames.STATUS)) {
                        req.setAttrValue(AdmAttrNames.STATUS, sq.getString(4));
                    }
                    if (attrNames.contains(AdmAttrNames.ORIGINATOR)) {
                        req.setAttrValue(AdmAttrNames.ORIGINATOR, sq.getString(5));
                    }
                    if (attrNames.contains(AdmAttrNames.USER_NAME)) {
                        req.setAttrValue(AdmAttrNames.USER_NAME, sq.getString(6));
                    }
                    if (attrNames.contains(AdmAttrNames.CREATE_DATE)) {
                        req.setAttrValue(AdmAttrNames.CREATE_DATE, sq.getString(7));
                    }
                    if (attrNames.contains(AdmAttrNames.UPDATE_DATE)) {
                        req.setAttrValue(AdmAttrNames.UPDATE_DATE, sq.getString(8));
                    }
                    if (attrNames.contains(AdmAttrNames.CLASS_SPEC)) {
                        req.setAttrValue(AdmAttrNames.CLASS_SPEC, sq.getString(9));
                    }
                    if (attrNames.contains(AdmAttrNames.DESCRIPTION)) {
                        req.setAttrValue(AdmAttrNames.DESCRIPTION, sq.getString(10));
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_TITLE)) {
                        req.setAttrValue(AdmAttrNames.RTM_TITLE, sq.getString(11));
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_COL_TYPE)) {
                        String colType = sq.getString(12);
                        if (colType != null && colType.length() > 0) {
                            colType = colType.equals("0") ? "Collection" : "Baseline";
                        }
                        req.setAttrValue(AdmAttrNames.RTM_COL_TYPE, colType); // RTM_COL_TYPE is not available in the query result
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_COL_SPEC)) {
                        String colSpec = sq.getString(13);
                        req.setAttrValue(AdmAttrNames.RTM_COL_SPEC, colSpec); // RTM_COL_SPEC is not available in the query result
                    }
                    if (attrNames.contains(AdmAttrNames.ID)) {
                        req.setAttrValue(AdmAttrNames.ID, sq.getString(14));
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_PROJ_NAME)) {
                        req.setAttrValue(AdmAttrNames.RTM_PROJ_NAME, sq.getString(15));
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_PROJ_DBNAME)) {
                        req.setAttrValue(AdmAttrNames.RTM_PROJ_DBNAME, sq.getString(16));
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_PROJ_URL)) {
                        req.setAttrValue(AdmAttrNames.RTM_PROJ_URL, sq.getString(17));
                    }
                    if (attrNames.contains(AdmAttrNames.RTM_PROJ_ID)) {
                        req.setAttrValue(AdmAttrNames.RTM_PROJ_ID, sq.getString(18));
                    }

                    ret.add(req);

                } // if (!isRequirementsShouldBeReturned) {..} else {
            } // while (sq.read()) {

            if (!isRequirementsShouldBeReturned) {
                setAttrDef(new CmdArgDef(CmdArguments.CONTAINER_DETAILS, false, List.class));
                setAttrValue(CmdArguments.CONTAINER_DETAILS, containerDetails);// Set the container details of requirements in the
                                                                               // command so that it can be retrieved later to
                                                                               // supply to the command which retrieves the
                                                                               // requirement attributes
            }
        } catch (DimConnectionException e) {
            // * XXX - chrisp - temporary code to catch exception that is thrown
            // * when trying to close the connection in rpcDBclose().
            // * The underlying problem needs to be found, but this will
            // * temporarily fix the issue.
        }

        return ret;
    }

    private String trimChar(String s, char c) {
        String temp = s;
        int pos = temp.indexOf(c);
        if (pos == 0) {
            temp = temp.substring(1);
        }
        pos = temp.lastIndexOf(c);
        if (pos > 0) {
            temp = temp.substring(0, pos);
        }

        return temp;
    }

}

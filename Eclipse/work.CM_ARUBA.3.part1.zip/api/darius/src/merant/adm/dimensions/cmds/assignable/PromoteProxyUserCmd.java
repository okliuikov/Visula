/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import java.util.ArrayList;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidRoleException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will promote a proxy Dimensions user into a normal user.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions proxy user object to be promoted into a normal user</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author David Conneely
 */
public class PromoteProxyUserCmd extends RPCExecCmd {
    public PromoteProxyUserCmd() throws AttrException {
        super();
        setAlias(Assignable.PROMOTE_PROXY_USER);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof User))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_USERMAN")) {
            throw new DimNoPrivilegeException("ADMIN_USERMAN");
        }

        validateAllAttrs();

        User admObj = (User) getAttrValue(CmdArguments.ADM_OBJECT);
        String userName = admObj.getId();
        if (!isExistingUser(userName)) {
            throw new DimAlreadyExistsException("Error: user " + userName + " does not exist.");
        }
        if (userName.equals("*")) {
            throw new DimInvalidRoleException("Error: user '*' may not be promoted.");
        }
        if (!isProxyUser(userName)) {
            throw new DimInvalidRoleException("Error: user " + userName + " is not a proxy user.");
        }

        // Construct UREG command to promote auto registered user, for example:
        // UREG /NOPROXY "AUTOREGISTERED1"

        StringBuffer cmdBuf = new StringBuffer("UREG /NOPROXY ");
        cmdBuf.append(Encoding.escapeDMCLI(userName));

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }

    private boolean isExistingUser(String userName) throws DBIOException, DimBaseException, AdmException {
        ArrayList inputs = new ArrayList(1);
        inputs.add(userName);
        String queryStr = "SELECT user_uid FROM users_profile WHERE user_name=:I1 AND privilege_level>=0";
        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, queryStr);
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    private boolean isProxyUser(String userName) throws DBIOException, DimBaseException, AdmException {
        String queryStr = "SELECT user_uid FROM users_profile WHERE user_name=:I1 AND privilege_level=1";
        DBIO query = new DBIO(queryStr);
        query.bindInput(userName);
        query.readStart();
        return query.read();
    }
}

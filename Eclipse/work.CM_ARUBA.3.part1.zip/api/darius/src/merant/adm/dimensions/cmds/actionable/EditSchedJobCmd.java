/**
 */
package merant.adm.dimensions.cmds.actionable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Locale;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.creatable.CreateSchedJobCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ScheduledJob;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * The command to edit named scheduled job.
 * 
 * <b>Mandatory Arguments:</b> <code>
 * <dl>
 * <dt>ID {String}</dt><dd>Scheduled Job ID name</dd>
 * <dt>START_TIME {String}</dt><dd>Scheduled Job start time</dd>
 * </dl>
 * </code> <br>
 * <b>Optional Arguments:</b> <code>
 * <dl>
 * <dt>REPEAT {String}</dt><dd>Scheduled Job repeat period</dd>
 * <dt>DESCRIPTION {String}</dt><dd>Scheduled Job description</dd>
 * <dt>JOB_STATUS {String}</dt><dd>Scheduled Job status {ACTIVE | INACTIVE | FINISHED}</dd>
 * </dl>
 * </code> <br>
 * <b>Returns:</b> <code>
 * <dl>
 * <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl>
 * </code>
 * 
 * @author kberezovchuk
 * 
 */
public class EditSchedJobCmd extends RPCExecCmd {

    protected static final SimpleDateFormat formatter_local = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.US);
    protected static final SimpleDateFormat formatter_iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ENGLISH);

    public EditSchedJobCmd() throws AttrException {
        super();
        setAlias(Actionable.EDIT_SCHEDULED_JOB);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.START_TIME, false, String.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.REPEAT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STATUS, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(AdmAttrNames.START_TIME)) {
            checkStartTime(attrDef, attrValue);
        } else if (name.equals(AdmAttrNames.REPEAT)) {
            checkRepeatScope(attrDef, attrValue);
        } else if (name.equals(AdmAttrNames.STATUS)) {
            checkStatusScope(attrDef, attrValue);
        } else if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue instanceof ScheduledJob) {
                ScheduledJob sjob = (ScheduledJob) attrValue;
                try {
                    checkStartTime(attrDef, sjob.getAttrValue(AdmAttrNames.START_TIME));
                    checkRepeatScope(attrDef, sjob.getAttrValue(AdmAttrNames.REPEAT));
                    checkStatusScope(attrDef, sjob.getAttrValue(AdmAttrNames.DESCRIPTION));
                } catch (AdmObjectException e) {
                    throw new AttrException("Error: EditSchedJobCmd - wrong attribute!(" + e.getMessage() + ")");
                }
            } else {
                throw new AttrException("Error: EditSchedJobCmd - wrong object type!", attrDef, attrValue);
            }
        }
    }

    private void checkStartTime(AttrDef attrDef, Object attrValue) throws AttrException {
        if (attrValue == null || ((String) attrValue).length() == 0) {
            return;
        }
        try {
            formatter_iso.parse((String) attrValue);
        } catch (ParseException e1) {
            try {
                formatter_local.parse((String) attrValue);
            } catch (ParseException e2) {
                throw new AttrException("Error: EditSchedJobCmd - wrong start time parameter!", attrDef, attrValue);
            }
        }
    }

    private void checkRepeatScope(AttrDef attrDef, Object attrValue) throws AttrException {
        if (attrValue == null || ((String) attrValue).length() == 0) {
            return;
        }
        String repeatStr = (String) attrValue;

        int timePart = -1;
        int[] validTimeParts = null;

        int index = -1;
        if ((index = repeatStr.indexOf("MINUTES")) > 1) { // time part should not start from 1 index, even if indexOf() is OK
            try {
                timePart = Integer.parseInt(repeatStr.substring(0, index).trim());
                validTimeParts = CreateSchedJobCmd.VALID_MINUTES_ARRAY;
            } catch (NumberFormatException e) {
            }
        } else if ((index = repeatStr.indexOf("HOURS")) > 1) {
            try {
                timePart = Integer.parseInt(repeatStr.substring(0, index).trim());
                validTimeParts = CreateSchedJobCmd.VALID_HOURS_ARRAY;
            } catch (NumberFormatException e) {
            }
        } else if ((index = repeatStr.indexOf("DAYS")) > 1) {
            try {
                timePart = Integer.parseInt(repeatStr.substring(0, index).trim());
                validTimeParts = CreateSchedJobCmd.VALID_DAYS_ARRAY;
            } catch (NumberFormatException e) {
            }
        } else {
            throw new AttrException("Error: EditSchedJobCmd - wrong repeat parameter!", attrDef, attrValue);
        }

        if (Arrays.binarySearch(validTimeParts, timePart) < 0) {
            throw new AttrException("Error: EditSchedJobCmd - wrong repeat parameter!", attrDef, attrValue);
        }
    }

    private void checkStatusScope(AttrDef attrDef, Object attrValue) throws AttrException {
        if (attrValue == null || ((String) attrValue).length() == 0) {
            return;
        }
        String status = (String) attrValue;
        if (!CreateSchedJobCmd.ACTIVE.equals(status) && !CreateSchedJobCmd.INACTIVE.equals(status)
                && !CreateSchedJobCmd.FINISHED.equals(status)) {
            throw new AttrException("Error: EditSchedJobCmd - wrong status parameter!", attrDef, attrValue);
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        String jobID = (String) getAttrValue(AdmAttrNames.ID);
        String startTime = (String) getAttrValue(AdmAttrNames.START_TIME);
        String repeat = (String) getAttrValue(AdmAttrNames.REPEAT);
        String description = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String status = (String) getAttrValue(AdmAttrNames.STATUS);

        if (jobID == null || jobID.trim().length() == 0) {
            AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
            if (admObj instanceof ScheduledJob) {
                jobID = admObj.getAdmSpec().getSpec();
                if (startTime == null || startTime.length() == 0) {
                    startTime = (String) admObj.getAttrValue(AdmAttrNames.START_TIME);
                }
                if (repeat == null || repeat.length() == 0) {
                    repeat = (String) admObj.getAttrValue(AdmAttrNames.REPEAT);
                }
                if (description == null || description.length() == 0) {
                    description = (String) admObj.getAttrValue(AdmAttrNames.DESCRIPTION);
                }
                if (status == null || status.length() == 0) {
                    status = (String) admObj.getAttrValue(AdmAttrNames.STATUS);
                }
            }
        }
        if (jobID == null || jobID.trim().length() == 0) {
            throw new AttrException("Scheduled Job is not specified");
        }

        StringBuffer sb = new StringBuffer("ESJ ");
        sb.append(Encoding.escapeDMCLI(jobID));

        if (startTime != null && startTime.length() > 0) {
            sb.append(" /START_TIME=").append(Encoding.escapeDMCLI(startTime));
        }
        if (repeat != null && repeat.length() > 0) {
            sb.append(" /REPEAT=").append(Encoding.escapeDMCLI(repeat));
        }
        if (description != null && description.length() > 0) {
            sb.append(" /JOB_DESC=").append(Encoding.escapeDMCLI(description));
        }
        if (status != null && status.length() > 0) {
            sb.append(" /JOB_STATUS=").append(Encoding.escapeDMCLI(status));
        }

        _cmdStr = sb.toString();
        return executeRpc();
    }
}

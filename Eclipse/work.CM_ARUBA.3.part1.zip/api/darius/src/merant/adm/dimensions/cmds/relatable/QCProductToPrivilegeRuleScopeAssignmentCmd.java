/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.PrivilegeRuleScopeAssignment;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Privilege Rule Scope Assignments for a PrivilegeRule for either User/Group/Role or by Privilege
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object: Product</dd>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class: PrivilegeRuleScopeAssignment</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 * </dl></code> <br>
 * <code><dl>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing privilege rule scope assignement AdmBaseIds</dd>
 * </dl></code>
 * @author Pauls
 *         Created 2005-15-12.
 */
public class QCProductToPrivilegeRuleScopeAssignmentCmd extends QueryRelsCmd {
    public QCProductToPrivilegeRuleScopeAssignmentCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Product)) {
                throw new AttrException("QCProductToPrivilegeRuleScopeAssignmentCmd Error: Adm Object type is not supported!",
                        attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(PrivilegeRuleScopeAssignment.class))) {
                throw new AttrException("QCProductToPrivilegeRuleScopeAssignmentCmd Error: Child object type is not supported!",
                        attrDef, attrValue);
            }
        }
    }

    final String MATCH_ALL = "%";

    // initialize filter
    String relatedUid = MATCH_ALL;
    String relatedTypeId = MATCH_ALL;
    String privObjType = MATCH_ALL;
    String privId = MATCH_ALL;

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();

        // Query for the current product
        Product product = (Product) AdmCmd.getCurRootObj(Product.class);
        long productUid = product.getAdmUid().getUid();

        if (filter != null) {
            processFilter(filter);
        }

        DBIO query = null;

        // Privilege
        if (relatedTypeId.equals(MATCH_ALL)) {
            query = new DBIO(wcm_sql.GET_PRODUCT_PRIVILEGERULE_SCOPEASSIGNMENT_BYPRIV);

            query.bindInput(productUid);
            query.bindInput(privObjType);
            query.bindInput(privId);
        }
        // User, group or role
        else {
            query = new DBIO(wcm_sql.GET_PRODUCT_PRIVILEGERULE_SCOPEASSIGNMENT);

            query.bindInput(productUid);
            // User, group or role
            query.bindInput(relatedTypeId);
            // specific user, group or role if requested
            query.bindInput(relatedUid);
        }

        query.readStart();
        while (query.read()) {
            addRelation(
                    ret,
                    relationships,
                    admObj.getAdmBaseId(),
                    AdmHelperCmd.newAdmBaseId(query.getString(1), admSecClass, null,
                            AdmHelperCmd.newAdmBaseId(query.getString(1), admSecClass, null, null)));
        }

        return ret;
    }

    private void processFilter(FilterImpl f) {
        if (f == null) {
            return;
        }

        Collection crits = f.criteria();

        if (crits != null && !crits.isEmpty()) {
            Iterator it = crits.iterator();

            while (it.hasNext()) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit == null) {
                    continue;
                }
                String attrName = crit.getAttrName();

                // SCOPE ASSIGNMENT ONLY FILTERS
                // filter by related uid: user, group, role or privilege
                if (AdmAttrNames.PRIVILEGERULE_SCOPE_RELATED_UID.equals(attrName) && crit.getValue() != null) {
                    relatedUid = crit.getValue().toString();
                }
                // Filter by related type: user, group or role
                if (AdmAttrNames.PRIVILEGERULE_SCOPE_RELATED_TYPE.equals(attrName) && crit.getValue() != null) {
                    relatedTypeId = crit.getValue().toString();
                }
                // PRIVILEGE ONLY FILTERS
                // Filter by privilege uid
                if (AdmAttrNames.PRIVILEGE_ID.equals(attrName) && crit.getValue() != null) {
                    privId = crit.getValue().toString();
                }
                // Filter by type of privilege: chg doc, item etc
                if (AdmAttrNames.PRIVILEGE_OBJ_TYPE.equals(attrName) && crit.getValue() != null) {
                    privObjType = crit.getValue().toString();
                }
            }
        }
    }

}

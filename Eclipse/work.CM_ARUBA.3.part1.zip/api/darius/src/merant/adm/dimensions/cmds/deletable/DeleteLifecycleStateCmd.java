/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.GlobalStageLifecycleHelper;
import merant.adm.dimensions.cmds.helper.SensitivityHelper;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimCMRulesException;
import merant.adm.dimensions.exception.DimFirstNormalStateNotAtInitialBuildStageException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimInvalidLcStateException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.LifeCycleState;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.system.PasswordAuthPointParam;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions LifeCycleState object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteLifecycleStateCmd extends DBIOCmd {
    public DeleteLifecycleStateCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LifeCycleState) && !(attrValue instanceof Stage)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_LIFECYCLEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_LIFECYCLEMAN");
        }

        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final String state = admObj.getId();
        String lifecycleIdInit = null;
        if (admObj instanceof Stage) {
            AdmObject gsl = AdmCmd.getObject(GlobalStageLifecycleHelper.getGlobalStageLifecycle());
            if (gsl != null) {
                lifecycleIdInit = gsl.getId();
            }
        } else {
            lifecycleIdInit = ((AdmSpec) admObj.getAdmBaseId().getScope()).getSpec();
        }
        final String lifecycleId = lifecycleIdInit;

        if (state == null || state.trim().length() == 0) {
            throw new DimInvalidAttributeException("Error: STATE_NAME not specified");
        }

        if (lifecycleId == null || lifecycleId.trim().length() == 0) {
            throw new DimInvalidAttributeException("Error: LIFECYCLE_ID not specified");
        }

        if (!stateExists(lifecycleId, state)) {
            throw new DimAlreadyExistsException("Error: The state " + state + " doesn't exist in lifecycle " + lifecycleId);
        }

        // If lifecycle state is sensitive then get authentication
        if (SensitivityHelper.isLifecycleStateSensitive(lifecycleId, state)) {
            PasswordAuthPointParam paramObj = new PasswordAuthPointParam(PasswordAuthPointParam.DELETE);
            paramObj.setLifecycleId(lifecycleId);
            paramObj.setStatus(state);
            SensitivityHelper.getAuthentication(this, paramObj);
        }

        if (!isNormalState(lifecycleId, state)) {
            throw new DimInvalidLcStateException("Error: The state " + state + " is not a normal state");
        }

        validateCMRulesViolated(lifecycleId, state);

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws AdmException {

                boolean wasAtInitialBuildStage = isFirstNormalStateAtInitialBuildStage(dbCtx, lifecycleId);

                // delete lifecycle state transition
                deleteState(dbCtx, lifecycleId, state);

                // regenerate normal lifecycle path
                generateNormalLifecycle(dbCtx, lifecycleId, false);

                // deleting a state may cause there to be an off-normal transition and normal transition
                // on the same states (DEF198242) - the off-normal transitions need to be removed
                removeExtraOffNormalTransitions(dbCtx, lifecycleId);

                if (GlobalStageLifecycleHelper.isLifecycleGSL(lifecycleId)) {
                    GlobalStageLifecycleHelper.deleteGSLStage(dbCtx, state);
                } else if (wasAtInitialBuildStage) {
                    boolean isStillAtInitialBuildStage = isFirstNormalStateAtInitialBuildStage(dbCtx, lifecycleId);
                    if (!isStillAtInitialBuildStage) {
                        throw new DimFirstNormalStateNotAtInitialBuildStageException(
                                "Error: the first normal lifecycle state is no longer at the initial build stage.");
                    }
                }
            }

        });
        return "Operation Completed";
    }

    private boolean isFirstNormalStateAtInitialBuildStage(DBIO dbCtx, String lifecycleId) throws AdmException {

        dbCtx.resetSQL("SELECT 'X' " + "FROM   norm_lifecycle nl, " + "       stage_lifecycles sl, " + "       stage_catalogue sc "
                + "WHERE  nl.lifecycle_id=:I1 and " + "       nl.state_seq_no=1 and " + "       nl.status=sl.status and "
                + "       sl.lifecycle_id=:I1 and " + "       sl.stage_uid=sc.stage_uid and " + "       sc.stage_seq=1");
        dbCtx.bindInput(lifecycleId);
        dbCtx.readStart();
        boolean isAtDevStage = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAtDevStage;
    }

    private void deleteState(DBIO query, String lifecycleId, String state) throws DimBaseException, AttrException, AdmException {
        // do deletion

        // figure out state's position in the normal path
        long seqNo = getStateSequenceNumber(query, lifecycleId, state);
        long lastSeqNo = getLastStateSequenceNumber(query, lifecycleId);

        if (seqNo > 1 && seqNo < lastSeqNo) {
            // the state is neither the first nor the last state in the normal path
            String nextState = getState(query, lifecycleId, seqNo + 1);

            // Delete normal and off-normal transitions from the state
            query.resetMessage(wcm_sql.DELETE_LIFE_CYCLE_BY_DOC_STATUS);
            query.bindInput(lifecycleId);
            query.bindInput(state);
            query.write(DBIO.DB_DONT_COMMIT);

            // Delete off-normal transitions to the state
            query.resetMessage(wcm_sql.DELETE_LIFE_CYCLE_BY_NEXT_DOC_STATUS);
            query.bindInput(lifecycleId);
            query.bindInput(state);
            query.write(DBIO.DB_DONT_COMMIT);

            // Join the previous state to the next state
            SqlUtils.renameLifecycleNextdocStatus(query, lifecycleId, state, nextState);
            query.write(DBIO.DB_DONT_COMMIT);
        } else {
            // the state is either the first or last state in the normal path
            query.resetMessage(wcm_sql.DELETE_LIFE_CYCLE_BY_DOC_OR_NEXT_DOC_STATUS);
            query.bindInput(lifecycleId);
            query.bindInput(state);

            query.write(DBIO.DB_DONT_COMMIT);
        }

        query.resetMessage(wcm_sql.DELETE_STAGE_LIFE_CYCLE_BY_STATUS);
        query.bindInput(lifecycleId);
        query.bindInput(state);
        query.write(DBIO.DB_DONT_COMMIT);

        SqlUtils.deleteLcStateByStatus(query, lifecycleId, state);
        query.write(DBIO.DB_DONT_COMMIT);
    }

    /**
     * Validates the normal lifecycles path by detecting CM Phase rule violations
     */
    private void validateCMRulesViolated(String lifecycleId, String state) throws DBIOException, DimBaseException, AdmException {
        String queryStr = "SELECT NULL FROM obj_types " + "WHERE lifecycle_id = :I1 AND cntrl = 'Y' " + "AND " + "( " + "("
                + "type_flag = 'C' AND " + "(relate_state = :I2 OR extract_state = :I2 OR freeze_state = :I2 OR close_state = :I2)"
                + ") OR " + "(" + "type_flag = 'I' AND "
                + "(relate_state = :I2 OR extract_state = :I2 OR freeze_state = :I2 OR close_state = :I2)" + ")" + ")";

        DBIO query = new DBIO(queryStr);

        query.bindInput(lifecycleId);
        query.bindInput(state);
        query.readStart();

        if (query.read()) {
            throw new DimCMRulesException("Error: Cannot delete normal state " + state
                    + " because it is used in a change management rule definition.");
        }
    }

    /**
     * Regenerates and validates normal lifecycle path after an alteration of the lifecycle
     */
    private void generateNormalLifecycle(DBIO query, String lifecycleId, boolean addingTransition) throws DBIOException,
            DimBaseException, AdmException {
        Cmd cmd = AdmCmd.getCmd("_internal_generate_normal_lifecycle");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, query);
        cmd.setAttrValue(AdmAttrNames.LIFECYCLE_ID, lifecycleId);
        cmd.setAttrValue(CmdArguments.ADDING_TRANSITION, Boolean.valueOf(addingTransition));
        cmd.execute();
    }

    /**
     * Checks if a lifecycle state already exists in the specified lifecycle
     */
    private boolean stateExists(String lifecycleId, String state) throws DBIOException, DimBaseException, AdmException {
        Vector inputs = new Vector();
        inputs.add(lifecycleId);
        inputs.add(state);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, "SELECT lifecycle_id FROM life_cycles " + "WHERE lifecycle_id = :I1 AND "
                + "(doc_status = :I2 OR next_doc_status = :I2) AND ROWNUM=1");
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Checks if the specified lifecycle state is normal
     */
    private boolean isNormalState(String lifecycleId, String state) throws DBIOException, DimBaseException, AdmException {
        Vector inputs = new Vector();
        inputs.add(lifecycleId);
        inputs.add(state);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_STR, "SELECT lifecycle_id FROM life_cycles " + "WHERE lifecycle_id = :I1 AND "
                + "NVL(norm_lc, 'N') = 'Y' AND " + "(doc_status = :I2 OR next_doc_status = :I2) AND ROWNUM=1");
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }

    /**
     * Returns state sequence number in the normal path
     */
    private long getStateSequenceNumber(DBIO query, String lifecycleId, String state) throws DBIOException, DimBaseException,
            AdmException {
        query.resetSQL("SELECT state_seq_no FROM norm_lifecycle " + "WHERE lifecycle_id=:I1 AND status=:I2");
        query.bindInput(lifecycleId);
        query.bindInput(state);

        query.readStart();

        long seq = 0;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            seq = query.getLong(1);
        }

        return seq;
    }

    /**
     * Returns last state sequence number in the normal path
     */
    private long getLastStateSequenceNumber(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        query.resetSQL("SELECT MAX(state_seq_no) FROM norm_lifecycle " + "WHERE lifecycle_id=:I1");
        query.bindInput(lifecycleId);

        query.readStart();

        long seq = 0;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            seq = query.getLong(1);
        }

        return seq;
    }

    /**
     * Returns normal state by it's position in the normal path
     */
    private String getState(DBIO query, String lifecycleId, long seqNo) throws DBIOException, DimBaseException, AdmException {
        query.resetSQL("SELECT status FROM norm_lifecycle " + "WHERE lifecycle_id = :I1 AND state_seq_no = :I2");
        query.bindInput(lifecycleId);
        query.bindInput(seqNo);

        query.readStart();

        String prevState = null;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            prevState = query.getString(1);
        }
        return prevState;
    }

    /**
     * If there is an off-normal transition between the same two states as a normal transition
     * this will cause problems so the off-normal transition should be deleted.
     */
    private void removeExtraOffNormalTransitions(DBIO query, String lifecycleId) throws DBIOException, DimBaseException,
            AdmException {

        query.resetMessage(wcm_sql.DELETE_LIFE_CYCLE_OFFNORMAL);
        query.bindInput(lifecycleId);
        query.write(DBIO.DB_DONT_COMMIT);
    }

}
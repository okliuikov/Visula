/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidRoleException;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to deassign a list of roles authrorized to perform the transition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>DBIO_QUERY {DBIO}</dt>
 *  <dd>
 *      Dimensions DBIO query object to be used. This object defines the transactional scope of the operation.
 *      Any exceptions raised by this command must be handled by the caller.
 *  </dd>
 *  <dt>LIFECYCLE_ID {String}</dt><dd>Dimensions lifecycle ID</dd>
 *  <dt>LCSTATETRANS_FROM_STATE {String}</dt><dd>From state</dd>
 *  <dt>LCSTATETRANS_TO_STATE {String}</dt><dd>To state</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>LCSTATETRANS_AUTH_ROLES {List}</dt>
 *  <dd>
 *       List of Dimensions RoleDefinition objects to be deassigned to the transition.
 *       If NULL, then all roles shall be deassigned from the transition
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */

public class _internal_deassign_transition_roles extends DBIOCmd {
    public _internal_deassign_transition_roles() throws AttrException {
        super();
        setAlias("_internal_deassign_transition_roles");
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, true, DBIO.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIFECYCLE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_FROM_STATE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_TO_STATE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_AUTH_ROLES, false, List.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.DBIO_QUERY)) {
            if (!(attrValue instanceof DBIO)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        String lifecycleId = (String) getAttrValue(AdmAttrNames.LIFECYCLE_ID);
        String fromState = (String) getAttrValue(AdmAttrNames.LCSTATETRANS_FROM_STATE);
        String toState = (String) getAttrValue(AdmAttrNames.LCSTATETRANS_TO_STATE);
        List authRoles = (List) getAttrValue(AdmAttrNames.LCSTATETRANS_AUTH_ROLES);

        doDeassignTransitionRoles(query, lifecycleId, fromState, toState, authRoles);

        return "Operation Completed";
    }

    /**
     * Assignes a set of roles authorised to perform a transition
     */
    private void doDeassignTransitionRoles(DBIO query, String lifecycleId, String fromState, String toState, List authRoles)
            throws DBIOException, DimBaseException, AdmException {

        if (authRoles != null && authRoles.size() > 0) {
            query.resetMessage(wcm_sql.LCTR_DEASSIGN_ROLE);
            boolean deassigned = false;

            for (Iterator it = authRoles.iterator(); it.hasNext();) {
                RoleDefinition roleObj = (RoleDefinition) it.next();

                String roleName = StringUtils.adjustValue(roleObj.getId(), AdmDmLengths.DM_L_ROLE);
                if (roleName == null) {
                    roleName = "";
                }

                // validate role name
                if (roleName.length() == 0) {
                    throw new DimInvalidRoleException("Error: Role name must not be null.");
                }

                query.bindInput(lifecycleId);
                query.bindInput(fromState);
                query.bindInput(toState);
                query.bindInput(roleName);
                query.write(DBIO.DB_DONT_COMMIT);

                deassigned = true;

            } // for (Iterator it = authRoles.iterator(); it.hasNext(); )
            if (deassigned) {
                query.close(DBIO.DB_DONT_RELEASE);
            }
        } else {
            query.resetMessage(wcm_sql.LCTR_DEASSIGN_ALL_ROLES);

            query.bindInput(lifecycleId);
            query.bindInput(fromState);
            query.bindInput(toState);

            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

        } // if (authRoles != null && authRoles.size()>0)
    }
}

/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.auditable;

import java.util.List;
import java.util.Vector;

import com.serena.dmnet.drs.DRSClientQueryWorksetDimRevisionHistory;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.UserDisplayFormatter;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.*;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Returns a set of history objects for a dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_SCOPE_OBJECT {Class}<dt><dd>Provides history scope</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing additional information</dd>
 *  <dt>ALL {Boolean}<dt><dd>Return all revision history.  False by default</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>List<dt><dd>List of adm history objects</dd>
 * </dl></code>
 * @author Floz
 */
public class GetHistoryCmd extends DBIOCmd {
    public GetHistoryCmd() throws AttrException {
        super();
        setAlias(Auditable.GET_HISTORY);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_SCOPE_OBJECT, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class)); // Currently unused
        setAttrDef(new CmdArgDef(CmdArguments.ALL, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Item)) && (!(attrValue instanceof ExternalRequest))
                    && (!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof Baseline))
                    && (!(attrValue instanceof WorkSet))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_SCOPE_OBJECT)) {
            if ((!(attrValue == DimActionHistory.class)) && (!(attrValue == DimRevisionHistory.class))
                    && (!(attrValue == ChangeDocumentHistory.class)) && (!(attrValue == BaselineActionHistory.class))
                    && (!(attrValue == WorksetActionHistory.class))) {
                throw new AttrException("Error: History type " + attrValue + " is not supported!", attrDef, attrValue);
            }
        }

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Class hist = (Class) getAttrValue(CmdArguments.ADM_SCOPE_OBJECT);
        boolean all = ((Boolean) getAttrValue(CmdArguments.ALL)).booleanValue();

        // 2003-05-26 vadymk: MS SQL Server is similar to IBM UDB
        boolean isDB2_or_MSSQL = false;
        long chUid;
        List histObjs = null;
        DBIO query = null;

        // Get the query I need...
        //
        if (admObj instanceof Item) {
            if (hist == DimActionHistory.class) {
                query = new DBIO(wcm_sql.ITEM_ACTION_HISTORY);
            } else if (hist == DimRevisionHistory.class) {
                if (all) {
                    query = new DBIO(wcm_sql.ITEM_REVISION_HISTORY_ALL);
                } else {
                    query = new DBIO(wcm_sql.ITEM_REVISION_HISTORY);
                }
            }
        } else if (admObj instanceof ChangeDocument) {
            if (hist == ChangeDocumentHistory.class) {
                query = new DBIO(false);
                isDB2_or_MSSQL = false;
                int queryNo = wcm_sql.CHDOC_HISTORY;

                query.resetMessage(queryNo);
            }
        } else if (admObj instanceof Baseline) {
            if (hist == BaselineActionHistory.class) {
                query = new DBIO(false);
                isDB2_or_MSSQL = false;
                int queryNo = wcm_sql.BLN_ACTION_HISTORY;

                query.resetMessage(queryNo);
            } else if (hist == DimRevisionHistory.class) {
                query = new DBIO(false);
                isDB2_or_MSSQL = false;
                int queryNo = wcm_sql.BLN_REVISION_HISTORY;
                query.resetMessage(queryNo);
            }
        } else if (admObj instanceof WorkSet) {
            if (hist == WorksetActionHistory.class) {
                query = new DBIO(false);
                isDB2_or_MSSQL = false;
                int queryNo = wcm_sql.WS_ACTION_HISTORY;

                query.resetMessage(queryNo);
            } else if (hist == DimRevisionHistory.class) {
                return fetchHistObjs(admObj, hist, query, all);
            }
        }

        chUid = getUid(admObj, hist, query, all);

        query.bindInput(chUid);
        query.readStart();
        histObjs = new Vector();
        DimHistory histRec = null;

        // Start to read results...
        //
        while (query.read()) {

            if (admObj instanceof Item) {
                if (hist == DimActionHistory.class) {
                    histRec = new DimActionHistory();
                } else {
                    histRec = new DimRevisionHistory();
                }
            } else if (admObj instanceof ChangeDocument) {
                histRec = new ChangeDocumentHistory();
            } else if (admObj instanceof Baseline) {
                if (hist == BaselineActionHistory.class) {
                    histRec = new BaselineActionHistory();
                } else {
                    histRec = new DimRevisionHistory();
                }
            } else if (admObj instanceof WorkSet) {
                if (hist == WorksetActionHistory.class) {
                    histRec = new WorksetActionHistory();
                } else {
                    histRec = new DimRevisionHistory();
                }
            }

            if (histRec instanceof DimActionHistory) {
                histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_OLD_STATUS, query.getString(1));
                histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_NEW_STATUS, query.getString(2));
                histRec.setAttrValue(AdmAttrNames.HISTORY_USER_NAME, query.getString(3));
                histRec.setAttrValue(AdmAttrNames.USER_FULL_NAME, query.getString(4));
                histRec.setAttrValue(AdmAttrNames.HISTORY_ACTION_NUM, new Integer(query.getInt(5)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_DATE_TIME, query.getString(6));
                histRec.setAttrValue(AdmAttrNames.HISTORY_COMMENT, query.getString(7));
            } else if (histRec instanceof ChangeDocumentHistory) {
                histRec.setAttrValue(AdmAttrNames.HISTORY_ACTION_NUM, new Integer(query.getInt(1)));
                histRec.setAttrValue(AdmAttrNames.CHDOC_HISTORY_CM_PHASE, new Integer(query.getInt(2)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_DATE_TIME, query.getString(3));
                histRec.setAttrValue(AdmAttrNames.HISTORY_STATUS, query.getString(4));
                histRec.setAttrValue(AdmAttrNames.HISTORY_USER_NAME, query.getString(5));
                histRec.setAttrValue(AdmAttrNames.USER_FULL_NAME, query.getString(6));
                histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_TYPE, query.getString(7));
                histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_UID, new Long(query.getLong(8)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_COMMENT, query.getString(9));
                // histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_DESCRIPTIONS, query.getString(10));
            } else if (histRec instanceof BaselineActionHistory) {
                histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_OLD_STATUS, query.getString(1));
                histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_NEW_STATUS, query.getString(2));
                histRec.setAttrValue(AdmAttrNames.HISTORY_USER_NAME, query.getString(3));
                histRec.setAttrValue(AdmAttrNames.USER_FULL_NAME, query.getString(4));
                histRec.setAttrValue(AdmAttrNames.HISTORY_ACTION_NUM, new Integer(query.getInt(5)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_DATE_TIME, query.getString(6));
                histRec.setAttrValue(AdmAttrNames.HISTORY_COMMENT, query.getString(7));
            } else if (histRec instanceof WorksetActionHistory) {
                histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_OLD_STATUS, query.getString(1));
                histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_NEW_STATUS, query.getString(2));
                histRec.setAttrValue(AdmAttrNames.HISTORY_USER_NAME, query.getString(3));
                histRec.setAttrValue(AdmAttrNames.USER_FULL_NAME, query.getString(4));
                histRec.setAttrValue(AdmAttrNames.HISTORY_ACTION_NUM, new Integer(query.getInt(5)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_DATE_TIME, query.getString(6));
                histRec.setAttrValue(AdmAttrNames.HISTORY_COMMENT, query.getString(7));
            } else if (histRec instanceof DimRevisionHistory) {

                histRec.setAttrValue(AdmAttrNames.HISTORY_UID, new Long(query.getLong(1)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_SPEC_UID, new Long(query.getLong(2)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_PREV_UID, new Long(query.getLong(3)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_ACTION_NUM, new Integer(query.getInt(4)));
                histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_UID, new Long(query.getLong(5)));
                histRec.setAttrValue(AdmAttrNames.HISTORY_STATUS, query.getString(6));
                histRec.setAttrValue(AdmAttrNames.HISTORY_USER_NAME, query.getString(7));
                histRec.setAttrValue(AdmAttrNames.USER_FULL_NAME, query.getString(8));
                histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_REVISION, query.getString(9));
                if (admObj instanceof Item) {
                    histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_PREV_REV, query.getString(10));
                } else {
                    histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_PREV_OBJ_CLASS, new Integer(query.getInt(10)));
                }
                histRec.setAttrValue(AdmAttrNames.HISTORY_DATE_TIME, query.getString(11));
                histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_TYPE, query.getString(12));
                histRec.setAttrValue(AdmAttrNames.HISTORY_COMMENT, query.getString(13));
            }
            histObjs.add(histRec);
        }

        // Read the ACTION_HISTORY_DESCRIPTIONS separately
        // due to a Dimensions 8.0 db2 parser bug
        if ((admObj instanceof ChangeDocument) && isDB2_or_MSSQL) {
            for (int i = 0; i < histObjs.size(); i++) {
                histRec = (DimHistory) histObjs.get(i);
                query.resetMessage(wcm_sql.CHDOC_HISTORY_UDB_OR_MSSQL);
                query.bindInput(chUid);
                query.bindInput(((Integer) histRec.getAttrValue(AdmAttrNames.HISTORY_ACTION_NUM)).longValue());
                if (query.read()) {
                    histRec.setAttrValue(AdmAttrNames.ACTION_HISTORY_DESCRIPTIONS, query.getString(1));
                }

                query.close();
            }
        }

        return (histObjs);
    }

    private long getUid(AdmObject admObj, Class hist, DBIO query, boolean all) throws AdmException {
        long chUid;
        if (all) {
            Cmd cmd = AdmCmd.getCmd(WithAttrs.GET, admObj);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, AdmAttrNames.SPEC_UID);
            List attrs = (List) cmd.execute();
            Object res = attrs.get(0);
            if (res instanceof Long) {
                chUid = ((Long) res).longValue();
            } else {
                // get at least one record instead of nullpointer exception
                chUid = ((AdmUidObject) admObj).getAdmUid().getUid();
                if (admObj instanceof Item && hist == DimRevisionHistory.class) {
                    query.resetMessage(wcm_sql.ITEM_REVISION_HISTORY);
                }
            }
        } else {
            chUid = ((AdmUidObject) admObj).getAdmUid().getUid();
        }
        return chUid;
    }

    private Vector fetchHistObjs(AdmObject admObj, Class hist, DBIO query, boolean all) throws AdmException {
        long chUid = getUid(admObj, hist, query, all);
        Vector histObjs = new Vector();
        DimHistory histRec = null;

        DRSClientQueryWorksetDimRevisionHistory drs = new DRSClientQueryWorksetDimRevisionHistory(DRSUtils.getLCNetClntObject());
        drs.setUid(chUid);
        DRSOutputDataExtractor output = new DRSQuery(drs).execute();

        int[] uids = output.getIntValues(DRSParams.HISTORY_UID);
        if (uids == null) {
            return histObjs;
        }
        int[] specs = output.getIntValues(DRSParams.HISTORY_SPEC_UID);
        int[] prevUids = output.getIntValues(DRSParams.HISTORY_PREV_UID);

        int[] hacs = output.getIntValues(DRSParams.HISTORY_ACTION_NUM);
        int[] rhus = output.getIntValues(DRSParams.REVISION_HISTORY_UID);
        String[] hs = output.getStringValues(DRSParams.HISTORY_STATUS);

        String[] huns = output.getStringValues(DRSParams.HISTORY_USER_NAME);
        String[] rhrs = output.getStringValues(DRSParams.REVISION_HISTORY_REVISION);
        int[] rhpocs = output.getIntValues(DRSParams.REVISION_HISTORY_PREV_OBJ_CLASS);

        String[] hdts = output.getStringValues(DRSParams.HISTORY_DATE_TIME);
        String[] rhts = output.getStringValues(DRSParams.REVISION_HISTORY_TYPE);
        String[] hcs = output.getStringValues(DRSParams.HISTORY_COMMENT);

        for (int i = 0; i < uids.length; i++) {
            histRec = new DimRevisionHistory();

            histRec.setAttrValue(AdmAttrNames.HISTORY_UID, uids[i]);
            histRec.setAttrValue(AdmAttrNames.HISTORY_SPEC_UID, specs[i]);
            histRec.setAttrValue(AdmAttrNames.HISTORY_PREV_UID, prevUids[i]);

            histRec.setAttrValue(AdmAttrNames.HISTORY_ACTION_NUM, hacs[i]);
            histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_UID, rhus[i]);
            histRec.setAttrValue(AdmAttrNames.HISTORY_STATUS, hs[i]);

            histRec.setAttrValue(AdmAttrNames.HISTORY_USER_NAME, huns[i]);
            histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_REVISION, rhrs[i]);
            histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_PREV_OBJ_CLASS, rhpocs[i]);

            histRec.setAttrValue(AdmAttrNames.HISTORY_DATE_TIME, hdts[i]);
            histRec.setAttrValue(AdmAttrNames.REVISION_HISTORY_TYPE, rhts[i]);
            histRec.setAttrValue(AdmAttrNames.HISTORY_COMMENT, hcs[i]);

            histObjs.add(histRec);
        }
        return histObjs;
    }
}

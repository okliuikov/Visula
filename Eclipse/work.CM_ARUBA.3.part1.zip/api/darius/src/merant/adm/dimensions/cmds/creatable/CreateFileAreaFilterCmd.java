/*
 * Copyright (C) 2006 Serena Software Europe, Ltd. All rights reserved.
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.FileAreaFilter;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions FileAreaFilter.
 * <p>
 * <b>Mandatory Arguments: </b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new file area filter</dd>
 * </dl></code><br>
 * <b>Returns: </b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * 
 * @author Floz
 */
public class CreateFileAreaFilterCmd extends DBIOCmd {

    public CreateFileAreaFilterCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASED_ON, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        String basedOnId = (String) getAttrValue(CmdArguments.BASED_ON);
        String newId = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.ID), AdmDmLengths.DM_L_TEMPLATE);

        String description = StringUtils.adjustValue((String) getAttrValue(AdmAttrNames.DESCRIPTION),
                AdmDmLengths.DM_L_DESCRIPTION, false);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        if (DoesExistHelper.fileAreaFilterExists(newId)) {
            throw new DimAlreadyExistsException("Error: area filter " + newId + " has already been defined.");
        }
        if (basedOnId != null && !DoesExistHelper.fileAreaFilterExists(basedOnId)) {
            throw new DimNotExistsException("Error: area filter " + basedOnId + " does not exist.");
        }

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        DBIO query = new DBIO(wcm_sql.FILEAREAFILTER_CREATE);
        query.bindInput(newId);
        query.bindInput(description);
        query.bindInput(userName);
        query.write();
        query.commit();

        if (basedOnId != null) {
            long basedOnUid = getFilterUid(basedOnId);
            long newUid = getFilterUid(newId);
            if (description == null) {
                query = new DBIO(wcm_sql.FILEAREAFILTER_COPYDESC);
                query.bindInput(basedOnUid);
                query.bindInput(newUid);
                query.write();
                query.commit();
            }
            query = new DBIO(wcm_sql.FILEAREAFILTER_COPYRULES);
            query.bindInput(basedOnUid);
            query.bindInput(newUid);
            query.write();
            query.commit();
        }

        setAttrValue(CmdArguments.INT_SPEC, newId);
        AdmResult retResult = new AdmResult("Operation completed.");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, FileAreaFilter.class);
        return retResult;
    }

    private long getFilterUid(String id) throws AdmException {
        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.ID, id));
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurRootObj(BaseDatabase.class), FileAreaFilter.class);
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        List retVals = (List) cmd.execute();
        long retVal = 0L;
        if (retVals != null && retVals.size() == 1) {
            AdmUid uid = (AdmUid) retVals.get(0);
            if (uid != null) {
                retVal = uid.getUid();
            }
        }
        return retVal;
    }
}
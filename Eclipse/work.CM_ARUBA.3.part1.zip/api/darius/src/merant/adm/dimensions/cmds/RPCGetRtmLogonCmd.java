/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.exception.AdmException;

/**
 * This command returns the RTM username and password for the given user <br>
 * <b>Returns:</b>
 * a <code>java.util.List</code> with the username and password as elements,
 * or an empty list if they cannot be obtained.
 */

public class RPCGetRtmLogonCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCGetRtmLogonCmd() {
        super();
        setAlias("GetRtmLogon");
    }

    /**
     * Returns a <code>java.utils.List</code> object with 2 values - the
     * username and password.
     * 
     * @return Returns a <code>java.utils.List</code> object with 2 values -
     *         the username and password.
     */
    @Override
    public Object execute() throws DimConnectionException, AdmException {
        List retval = new ArrayList();

        try {
            if (getSession().getConnection().rpcHasRTM(null)) {
                retval = getSession().getConnection().rpcGetRtmLogin();
            } else {
                throw new AdmException("Dimensions RM is not installed.");
            }
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

        return retval;
    }
}

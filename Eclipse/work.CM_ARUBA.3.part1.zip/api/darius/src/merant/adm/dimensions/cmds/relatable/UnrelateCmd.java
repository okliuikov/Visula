/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.AdmObjectList;
import merant.adm.dimensions.objects.collections.AdmObjectListImpl;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will unrelate two Dimensions objects.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Parent Dimensions object</dd>
 *  <dt>ADM_REL_TYPE {RelationshipType}<dt><dd>Relationship type object</dd>
 * </dl></code> <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_REL_TYPE {RelationshipType}<dt><dd>Relationship type object</dd>
 *  <dt>PENDING {Boolean}<dt><dd>For (un)relating Parts and Change Documents, this indicates the pending list should be recalculated</dd>
 *  <dt>ALL {Boolean}<dt><dd>For removing items from workset, this indicates whether all item revisions of the
 *                           given item should be removed or just the selected one>/dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions Project or Stream context for unrelate</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class UnrelateCmd extends RPCExecCmd {
    public UnrelateCmd() throws AttrException {
        super();
        setAlias(Relatable.UNRELATE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, AdmObjectListImpl.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_REL_TYPE, false, RelationshipType.class));
        setAttrDef(new CmdArgDef(CmdArguments.PENDING, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.ALL, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObjectList admObjList = (AdmObjectList) getAttrValue(CmdArguments.ADM_OBJECT_LIST);

        if ((admObj == null) && (admObjList == null)) {
            throw new DimBaseCmdException("Must specify an object or a list of objects!");
        }

        if ((admObj != null) && (admObjList != null)) {
            throw new DimBaseCmdException("Cannot specify an object and a list of objects!");
        }

        Cmd cmd = null;
        if (admObjList != null) {
            cmd = AdmCmd.getCmd(Relatable.RELATE, admObjList);
        } else {
            cmd = AdmCmd.getCmd(Relatable.RELATE, admObj);
        }
        cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, getAttrValue(CmdArguments.ADM_PARENT_OBJECT));
        cmd.setAttrValue(CmdArguments.ADM_REL_TYPE, getAttrValue(CmdArguments.ADM_REL_TYPE));
        cmd.setAttrValue(CmdArguments.PENDING, getAttrValue(CmdArguments.PENDING));
        cmd.setAttrValue(CmdArguments.REMOVE, Boolean.TRUE);
        cmd.setAttrValue(CmdArguments.ALL, getAttrValue(CmdArguments.ALL));
        cmd.setAttrValue(CmdArguments.RELATED_CHDOCS, getAttrValue(CmdArguments.RELATED_CHDOCS));

        WorkSet workSet = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        if (workSet != null) {
            // Most of the commands pass a project/stream around as a WorkSet object
            // via the CmdArguments.WORKSET parameter. Sadly, RelateCmd doesn't and
            // relies instead on the string based AdmAttrNames.PROJECT.
            cmd.setAttrValue(AdmAttrNames.PROJECT, workSet.getAdmSpec().getSpec());
        }

        return cmd.execute();
    }
}

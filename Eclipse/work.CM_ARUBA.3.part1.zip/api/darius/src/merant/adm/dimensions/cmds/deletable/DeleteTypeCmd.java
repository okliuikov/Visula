/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Type object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteTypeCmd extends RPCExecCmd {
    public DeleteTypeCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }

            AdmObject typeObj = (AdmObject) attrValue;
            try {
                // an object type is uniquely identified by it's uid or product:type_name-type_class
                if (typeObj.getAttrValue(AdmAttrNames.ADM_UID) == null) {
                    // if uid is missing, require that the rest is present
                    if (typeObj.getAttrValue(AdmAttrNames.PARENT_CLASS) == null) {
                        throw new AttrException("Error: parent class not specified");
                    }
                    if (typeObj.getAttrValue(AdmAttrNames.PRODUCT_NAME) == null) {
                        throw new AttrException("Error: product not specified");
                    }
                    if (typeObj.getAttrValue(AdmAttrNames.ID) == null) {
                        throw new AttrException("Error: type name not specified");
                    }
                }
            } catch (AdmObjectException e) {
                throw new AttrException(e.getMessage());
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // long typeUid = ((AdmUidObject) admObj).getAdmUid().getUid();
        List attrs = AdmHelperCmd.getAttributeValues(admObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS, AdmAttrNames.TYPE_TEMPLATE2 }));
        String productName = (String) attrs.get(0);
        String typeName = (String) attrs.get(1);
        Class typeClass = (Class) attrs.get(2);

        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /DELETE ");
        cmdBuf.append(Encoding.escapeDMCLI(typeName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));

        if (typeClass.equals(Item.class)) {
        	cmdBuf.append(" /OBJ_CLASS=ITEM");
        } else if (typeClass.equals(ChangeDocument.class)) {
        	cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else if (typeClass.equals(Baseline.class)) {
        	cmdBuf.append(" /OBJ_CLASS=BASELINE");
        } else if (typeClass.equals(Part.class)) {
        	cmdBuf.append(" /OBJ_CLASS=PART");
        } else if (typeClass.equals(WorkSet.class)) {
        	cmdBuf.append(" /OBJ_CLASS=PROJECT");
        }

        _cmdStr = cmdBuf.toString();        
        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }
}
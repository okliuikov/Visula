/*
 * Copyright 2001, 2009 Serena Software.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.server;

import java.io.IOException;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;
import merant.adm.session.Session;

/**
 * This command will get version info about the Dimensions server.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>None</dt> * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>None</dt>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List of 3 Strings, (Schema Version, Schema Revision, Server Version)</dd>
 * </dl></code>
 */
public class QueryVersionCmd extends AdmCmd {
    public QueryVersionCmd() throws AttrException {
        super();
        setAlias(Server.QUERY_VERSION);
        setAttrDef(new CmdArgDef(CmdArguments.TYPE_OF_SERVER_VERSION, false, new Integer(0), Integer.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        Integer formatVer = (Integer) getAttrValue(CmdArguments.TYPE_OF_SERVER_VERSION);
        List lst = new Vector();
        try {
            lst.add(((Session) DimSystem.getSystem().getSession()).getSchemaVersion());
            lst.add(((Session) DimSystem.getSystem().getSession()).getSchemaRevision());
            lst.add(((Session) DimSystem.getSystem().getSession()).getConnection().rpcPcmsGetVersion(formatVer.intValue()));
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return lst;
    }
}

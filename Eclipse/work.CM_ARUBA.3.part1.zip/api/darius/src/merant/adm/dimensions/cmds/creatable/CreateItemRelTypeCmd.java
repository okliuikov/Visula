/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemRelationshipType;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Item to Item Relationship Type .
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>RELTYPE_TYPE_OBJ{AdmObject}<dt><dd>Parent item type</dd>
 *  <dt>RELTYPE_SUB_TYPE_OBJ{AdmObject}<dt><dd>Child item type</dd>
 *  <dt>RELNAME_OBJ{AdmObject}<dt><dd>Item type relationship name</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_CHILD_INHERIT{Boolean}<dt>
 *  <dd>Whether to inherit relationships to children when creating a new revision of parent. Default - FALSE</dd>
 *  <dt>RELTYPE_IS_PARENT_INHERIT{Boolean}<dt>
 *  <dd>Whether to inherit relationshipd to parents when creating children. Default - FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateItemRelTypeCmd extends RPCExecCmd {
    public CreateItemRelTypeCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_TYPE_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_SUB_TYPE_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELNAME_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_PARENT_INHERIT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_CHILD_INHERIT, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject parentTypeObj = (AdmObject) getAttrValue(AdmAttrNames.RELTYPE_TYPE_OBJ);
        AdmObject childTypeObj = (AdmObject) getAttrValue(AdmAttrNames.RELTYPE_SUB_TYPE_OBJ);
        AdmObject relNameObj = (AdmObject) getAttrValue(AdmAttrNames.RELNAME_OBJ);

        Boolean inheritParentRels = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_PARENT_INHERIT));
        Boolean inheritChildRels = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_CHILD_INHERIT));

        List attrNames = Arrays.asList(new String[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS });
        List attrs1 = AdmHelperCmd.getAttributeValues(parentTypeObj, attrNames);
        List attrs2 = AdmHelperCmd.getAttributeValues(childTypeObj, attrNames);

        if (attrs1 == null || attrs1.size() != 3) {
            throw new DimBaseCmdException("Error: failed to query attributes of parent item type.");
        }
        if (attrs2 == null || attrs2.size() != 3) {
            throw new DimBaseCmdException("Error: failed to query attributes of child item type.");
        }

        String parentProductId = ((String) attrs1.get(0)).trim().toUpperCase();
        String parentTypeId = ((String) attrs1.get(1)).trim().toUpperCase();
        Class parentTypeClass = (Class) attrs1.get(2);

        String childProductId = ((String) attrs2.get(0)).trim().toUpperCase();
        String childTypeId = ((String) attrs2.get(1)).trim().toUpperCase();
        Class childTypeClass = (Class) attrs2.get(2);

        if (!Item.class.equals(parentTypeClass)) {
            throw new DimInvalidAttributeException("Error: type " + parentProductId + ":" + parentTypeId + " is not an item type.");
        }

        if (!Item.class.equals(childTypeClass)) {
            throw new DimInvalidAttributeException("Error: type " + childProductId + ":" + childTypeId + " is not an item type.");
        }

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /ADD_RELATIONSHIP ");
        cmdBuf.append(Encoding.escapeDMCLI(parentTypeId));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(parentProductId));

        if (parentTypeClass.equals(Item.class)) {
            cmdBuf.append(" /OBJ_CLASS=ITEM");
        } else {
            throw new DimInvalidAttributeException("Error: type " + parentProductId + ":" + parentTypeId + " is not an item type.");
        }

        cmdBuf.append(" /REL_PRODUCT=").append(Encoding.escapeDMCLI(childProductId));
        cmdBuf.append(" /REL_TYPE_NAME=").append(Encoding.escapeDMCLI(childTypeId));

        if (childTypeClass.equals(Item.class)) {
            cmdBuf.append(" /REL_OBJ_CLASS=ITEM");
        } else {
            throw new DimInvalidAttributeException("Error: type " + childProductId + ":" + childTypeId + " is not an item type.");
        }

        if (inheritParentRels != null) {
            if (inheritParentRels.booleanValue() == true)
                cmdBuf.append(" /INHERIT_PARENT");
            else
                cmdBuf.append(" /NOINHERIT_PARENT");
        }

        if (inheritChildRels != null) {
            if (inheritChildRels.booleanValue() == true)
                cmdBuf.append(" /INHERIT_CHILD");
            else
                cmdBuf.append(" /NOINHERIT_CHILD");
        }

        String relName = relNameObj.getId().trim().toUpperCase();
        cmdBuf.append(" /REL_NAME=").append(Encoding.escapeDMCLI(relName));

        _cmdStr = cmdBuf.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ItemRelationshipType.class);
        return retResult;
    }

}

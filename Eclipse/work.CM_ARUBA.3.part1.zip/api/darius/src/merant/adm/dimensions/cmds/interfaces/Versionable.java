/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for versionable commands.
 * <p>
 * This applies to any dimensions object that can be versioned.
 * @author Floz
 */
public interface Versionable {
    public static final String AUDIT = "Versionable.Audit";
    public static final String BUILD = "Versionable.Build";
    public static final String BUILD_BASELINE = "Versionable.BuildBaseline";
    public static final String CANCEL = "Versionable.Cancel";
    public static final String CHECK_OUT = "Versionable.CheckOut";
    public static final String CHECK_IN = "Versionable.CheckIn";
    public static final String COMPARE = "Versionable.Compare";
    public static final String IS_BUILD_AVAILABLE = "Versionable.IsBuildAvailable";
    public static final String MERGE = "Versionable.Merge";
    public static final String MERGE_ITEM = "Versionable.MergeItem";
    public static final String UPDATE = "Versionable.Update";
    public static final String EXPAND_REVISIONS = "Versionable.ExpandRevisions";
    public static final String UPDATE_EXTRACTED_ITEM = "Versionable.UpdateExtractedItem";
    public static final String UNDO_DELIVER = "Versionable.UndoDeliver";
    public static final String REBASE = "Versionable.Rebase";
}

package merant.adm.dimensions.cmds.helper;

import java.io.IOException;
import java.util.ArrayList;

import com.serena.dmnet.LCNetClnt;
import com.serena.dmnet.ProjectContext;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.session.Session;

public final class SubProjectHelper {

    /*
     * YCai found: if parent and child projects are not adjacent, this method return null.
     * //public static final String getSubProjectOffset(WorkSet parent, WorkSet child) {
     * // String ret = null;
     * // try {
     * // DBIO dbio = new DBIO(
     * // "SELECT DISTINCT wc.obj_uid,"
     * // + " wsc.product_id||':'||wsc.obj_id, wra.attr_1"
     * // + " FROM ws_catalogue wc, ws_rels wr, wsrel_attributes wra,"
     * // + " ws_spec_catalogue wsc WHERE wr.rel_class=3 AND"
     * // + " wr.reltype_uid=2 AND wr.obj_uid=:I1 AND"
     * // + " wr.related_uid=wc.obj_uid AND wra.rel_uid(+)=wr.rel_uid"
     * // + " AND wc.obj_spec_uid=wsc.obj_spec_uid ORDER BY 2 ASC");
     * // dbio.bindInput(parent.getUid());
     * // try {
     * // dbio.readStart();
     * // while (dbio.read()) {
     * // if (dbio.getLong(1) == child.getUid()) {
     * // ret = dbio.getString(3);
     * // break;
     * // }
     * // }
     * // } finally {
     * // dbio.close();
     * // }
     * // } catch (AdmException ae) {
     * // }
     * // return ret;
     * //}
     */

    // YCai: This method might need to be modified like the getSubProjectOffset(workset, workset) method.
    public static final String getSubProjectOffset(WorkSet parent, Baseline child) {
        String ret = null;
        try {
            DBIO dbio = new DBIO("SELECT DISTINCT bc.obj_uid," + " bsc.product_id||':'||bsc.obj_id, wra.attr_1"
                    + " FROM bln_catalogue bc, ws_rels wr, wsrel_attributes wra,"
                    + " bln_spec_catalogue bsc WHERE wr.rel_class=4 AND" + " wr.reltype_uid=2 AND wr.obj_uid=:I1 AND"
                    + " wr.related_uid=bc.obj_uid AND wra.rel_uid(+)=wr.rel_uid"
                    + " AND bc.obj_spec_uid=bsc.obj_spec_uid ORDER BY 2 ASC");
            dbio.bindInput(parent.getUid());
            try {
                dbio.readStart();
                while (dbio.read()) {
                    if (dbio.getLong(1) == child.getUid()) {
                        ret = dbio.getString(3);
                        break;
                    }
                }
            } finally {
                dbio.close();
            }
        } catch (AdmException ae) {
        }
        return ret;
    }

    /*
     * :I1 - the UID of a subproject
     * :I2 - the UID of a root of this subproject
     */
    public static final String getSubProjectOffset(WorkSet parent, WorkSet child) {
        String ret = null;
        try {
            DBIO dbio = new DBIO("SELECT wr.related_uid, "
                    + " SUBSTR(wa.attr_1, 1, DECODE(SIGN(LENGTH(wa.attr_1) - 1024), -1, LENGTH(wa.attr_1), 1024))"
                    + " FROM ws_rels wr, ws_catalogue wc, ws_spec_catalogue wsc, wsrel_attributes wa" + " WHERE "
                    + " wr.obj_uid = :I1 AND wr.rel_class = 11"
                    + " AND wc.obj_uid = wr.related_uid AND wsc.obj_spec_uid = wc.obj_spec_uid"
                    + " AND wa.rel_uid = wr.rel_uid AND wa.seq = 1 AND wr.related_uid = :I2");
            dbio.bindInput(child.getUid()); // :I1 is child's uid
            dbio.bindInput(parent.getUid()); // :I2 is parent's uid
            try {
                dbio.readStart();
                while (dbio.read()) {
                    if (dbio.getLong(1) == parent.getUid()) {
                        ret = dbio.getString(2);
                        break;
                    }
                }
            } finally {
                dbio.close();
            }
        } catch (AdmException ae) {
        }
        return ret;
    }

    public static int[] getRootProjectUids(String productId, String projectId) throws DimBaseCmdException, IOException {
        if (productId == null || projectId == null) {
            throw new NullPointerException("Cannot get root projects - productId and/or projectId are null");
        }

        ProjectContext newContext = new ProjectContext();
        newContext.setProjectProduct(productId);
        newContext.setProjectId(projectId);
        newContext.setValueMask(ProjectContext.PCV.PROJECT_SPEC);

        LCNetClnt con = ((Session) DimSystem.getSystem().getSession()).getConnection();
        ProjectContext ctx;
        ArrayList rootProjects = new ArrayList();
        ctx = con.rpcQueryProjectContext(newContext, rootProjects);
        if (ctx == null) {
            String error = con.getErrorHandler().get();
            throw new DimBaseCmdException(error);
        }
        if (rootProjects != null && rootProjects.size() > 0) {
            ProjectContext.RootProjectInfo rootInfo;
            int[] rootUids = new int[rootProjects.size()];
            for (int i = 0; i < rootProjects.size(); i++) {
                rootInfo = (ProjectContext.RootProjectInfo) rootProjects.get(i);
                rootUids[i] = rootInfo.getUid();
            }
            return rootUids;
        }
        return null;
    }

    /*
     * :I1 - the UID of a subproject :I2 - the UID of a root of this subproject
     * The query selects the immediate parent of a subproject which has the same
     * selected root project as the subproject.
     */
    public static final WorkSet getImmediateParentWorkSet(WorkSet root, WorkSet current) {
        long ret = -1;
        try {
            DBIO dbio = new DBIO("SELECT  wsr1.obj_uid" + "FROM    ws_rels wsr1" + "WHERE   wsr1.related_uid = :I1"
                    + "AND     wsr1.rel_class = 3" + "AND     EXISTS" + "(SELECT NULL FROM  ws_rels wsr3"
                    + " WHERE wsr3.obj_uid = wsr1.obj_uid" + " AND   wsr3.rel_class = 11" + " AND   wsr3.related_uid = :I2" + ")");
            dbio.bindInput(current.getUid());
            dbio.bindInput(root.getUid());
            try {
                dbio.readStart();
                while (dbio.read()) {
                    ret = dbio.getLong(1);
                    break;
                }
            } finally {
                dbio.close();
            }
        } catch (AdmException ae) {
        }
        WorkSet ws = null;
        if (ret != -1) {
            try {
                ws = (WorkSet) AdmCmd.getObject(new AdmUid(ret, WorkSet.class));
            } catch (AttrException e) {
                Debug.error(e.getMessage(), e);
            } catch (DimBaseException e) {
                Debug.error(e.getMessage(), e);
            } catch (AdmObjectException e) {
                Debug.error(e.getMessage(), e);
            } catch (AdmException e) {
                Debug.error(e.getMessage(), e);
            }
        }
        return ws;
    }
}

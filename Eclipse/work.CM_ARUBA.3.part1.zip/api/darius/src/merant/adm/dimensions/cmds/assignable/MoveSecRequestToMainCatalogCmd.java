/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2009, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.assignable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.SecChangeDocument;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will move a request from secondary catalogue to main catalogue.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * <dt>ADM_OBJECT {AdmObject}<dt><dd>Secondary Request</dd>
 * </dl></code> <br>
 * 
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd></dd>
 * </dl></code>
 * @author YCai
 */
public class MoveSecRequestToMainCatalogCmd extends RPCExecCmd {

    public MoveSecRequestToMainCatalogCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof SecChangeDocument)) {
                throw new AttrException("MoveSecRequestToMainCatalogCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject request = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        StringBuffer sb = new StringBuffer();

        sb.append("MCPC /CHANGE_DOC_IDS=(");
        sb.append(Encoding.escapeDMCLI(request.getId()));
        sb.append(")");

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }
}

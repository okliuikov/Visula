/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2014, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.helper;

import java.text.ParseException;
import java.util.Date;

import com.serena.dmnet.drs.DRSClientQueryDirectoryLocks;
import com.serena.dmnet.drs.DRSClientQueryFileDetails;

import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.DariusItemLockInfo;
import merant.adm.dimensions.server.drs.objects.DariusItemLockInfoHandler;
import merant.adm.dimensions.server.drs.objects.FileDetails;
import merant.adm.dimensions.server.drs.objects.FileDetailsHandler;
import merant.adm.dimensions.util.DateUtils;
import merant.adm.exception.AdmException;

public class FileDetailsHelper {

    public static void getFileDetails(long wsetUid, Long[] objUids, FileDetailsHandler handler) throws AdmException {

        DRSClientQueryFileDetails drs = new DRSClientQueryFileDetails();
        drs.setWsetUid(wsetUid);
        drs.setObjUids(objUids);
        DRSUtils.execute(drs);

        if (drs.hasData()) {
            int[] fileLengths = drs.getFileLengths();
            String[] checksums = drs.getChecksums();

            for (int i = 0; i < checksums.length; i++) {
                FileDetails fd = new FileDetails(objUids[i], fileLengths[i], checksums[i]);
                handler.handleFileDetails(fd);
            }
        }
    }

    public static void getFileLockDetails(long wsetUid, String path, boolean recursive, DariusItemLockInfoHandler handler) throws AdmException {

        DRSClientQueryDirectoryLocks drs = new DRSClientQueryDirectoryLocks();
        drs.setWsetUid(wsetUid);
        drs.setPath(path);
        drs.setRecursive(recursive);
        DRSUtils.execute(drs);

        if (drs.hasData()) {
            int[] objUids = drs.getObjUids();
            String[] fileNames = drs.getFileNames();
            String[] lockDates = drs.getDates();
            String[] lockUsers = drs.getUsers();

            for (int i = 0; i < objUids.length; i++) {
                Date lockDate = null;
                try {
                    lockDate = DateUtils.parseDate(lockDates[i], DateUtils.DATE_PATTERN_3);
                } catch (ParseException e) {
                }
                DariusItemLockInfo fd = new DariusItemLockInfo(objUids[i], fileNames[i], lockDate, lockUsers[i]);
                handler.handleItemLockInfo(fd);
            }
        }
    }
}

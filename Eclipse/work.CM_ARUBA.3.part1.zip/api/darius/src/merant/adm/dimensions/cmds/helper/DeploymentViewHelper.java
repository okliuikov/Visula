package merant.adm.dimensions.cmds.helper;

import java.io.IOException;

import com.serena.dmnet.Constants;

import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.session.Session;

/**
 * @author kberezovchuk
 * 
 *         Generates contents of the deployment view entry page (self-submitting form) and saves it in existing given file
 */
public class DeploymentViewHelper {

    public static boolean saveEntryPageContents(String view, String rootOrProject, String stage, String area, String projectOfArea,
            String objectSpec, String objectId, String format, String userFile) {
        try {
            int result = ((Session) DimSystem.getSystem().getSession()).getConnection().rpcDeploymentViewEntryPage(view,
                    rootOrProject, stage, area, projectOfArea, objectSpec, objectId, format, userFile);

            if (result == Constants.PCMS_OK) {
                return true;
            }
        } catch (IOException ioe) {
            Debug.error(ioe);
        }
        return false;
    }
}

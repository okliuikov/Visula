/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.ListDeploymentAreaVersionsObjectsResult;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.helper.IDeploymentViewConstants;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.AreaVersion;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.ScheduledJob;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpecTwin;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Returns list of objects for rolling back as the result of rolling back provided area versions.
 */
public class QueryAreaVersionsObjectsCmd extends RPCCmd implements IDeploymentViewConstants {
    /**
     * Constructor defines the command definition and arguements.
     */
    public QueryAreaVersionsObjectsCmd() throws AdmObjectException, AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, List.class)); // list of area version
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT_LIST)) {
            if (attrValue instanceof List) {
                List list = (List) attrValue;
                Class type = null;
                for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                    Object object = iterator.next();
                    if (object == null) {
                        throw new AttrException("Error: QueryAreaVersionsObjectsCmd - null object in the list is not supported!",
                                attrDef, attrValue);
                    }
                    if ((!(object instanceof AreaVersion))) {
                        throw new AttrException("Error: QueryAreaVersionsObjectsCmd - object type in the list is not supported!",
                                attrDef, object);
                    }
                }
            }
        }
    }

    @Override
    public Object execute() throws AdmException {

        List list = new ArrayList();
        int inputFlags = 0;
        List avList = (List) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        if (avList == null || avList.size() == 0) {
            throw new AttrException("Error: QueryAreaVersionsObjectsCmd - empty list of area version!");
        }
        int[] avFlags = new int[avList.size()];
        String[] avSpecs = new String[avList.size()];
        ;
        for (int i = 0; i < avSpecs.length; i++) {
            AreaVersion av = (AreaVersion) avList.get(i);
            avSpecs[i] = av.getAdmSpec().getSpec();
            avFlags[i] = av.getAreaVersionFlag();
        }
        try {
            ListDeploymentAreaVersionsObjectsResult listResults = getSession().getConnection().rpcGetDeploymentAreaVersionsObjects(
                    inputFlags, avFlags, avSpecs);
            long k = listResults.getResultCount();
            int[] objFlags = listResults.getObjectFlags();
            int[] objUids = listResults.getObjectUids();
            int[] objClasses = listResults.getObjectClasses();
            String[] objSpecs = listResults.getObjectSpecs();
            String[] objDetails = listResults.getObjectDetails();
            String[] toPaths = listResults.getToPaths();
            avSpecs = listResults.getAreaVersionSpecs();

            if (objUids != null && objClasses != null && objUids.length > 0 && k > 0) {
                for (int i = 0; i < objUids.length && i < objClasses.length; i++) {
                    Class objClass = getObjectClass(objClasses[i]);
                    if (objClass != null) {
                        AdmSpecTwin specTwin = null;
                        if (objSpecs != null && i < objSpecs.length && objSpecs[i] != null && objSpecs[i].trim().length() != 0) {
                            specTwin = new AdmSpecTwin(objSpecs[i], objClass);
                        }
                        AdmObject admObj = AdmCmd.getObject(AdmCmd.newAdmBaseId(objUids[i], objClass, null, specTwin));
                        // AdmObject admObj = AdmCmd.getObject(AdmCmd.newAdmBaseId(objUids[i], objClass));
                        if (objDetails != null && i < objDetails.length && objDetails[i] != null) {
                            admObj.setAttrValue(AdmAttrNames.DESCRIPTION, objDetails[i]);
                        }
                        if (avSpecs != null && i < avSpecs.length && avSpecs[i] != null) {
                            admObj.setAttrValue(AdmAttrNames.DEPLOY_AREA_VERSION, avSpecs[i]);
                        }
                        if (toPaths != null && i < toPaths.length && toPaths[i] != null) {
                            admObj.setAttrValue(AdmAttrNames.FULL_PATH_NAME, toPaths[i]);
                        }
                        list.add(admObj);
                    }
                }
            }
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return list;
    }

    private Class getObjectClass(int classID) {
        switch (classID) {
        case CLASS_ITEM:
            return ItemFile.class;
        case CLASS_REQUEST:
            return ChangeDocument.class;
        case CLASS_BASELINE:
            return Baseline.class;
        case CLASS_WORKSET:
            return WorkSet.class;
        case CLASS_SCHEDULED_JOB:
            return ScheduledJob.class;
        }
        return null;
    }

}
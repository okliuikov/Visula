/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ReleaseTemplate;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions ReleaseTemplate object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class DeleteReleaseTemplateCmd extends DBIOCmd {
    public DeleteReleaseTemplateCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReleaseTemplate)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        String templateId = admObj.getAdmSpec().getSpec();
        if (DoesExistHelper.releaseTemplateIsInUse(templateId)) {
            throw new DimInUseException("Error: Release Template " + templateId
                    + " has been used to create releases - it cannot be deleted.");
        }

        // List rules = (List)AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admObj, ReleaseTemplateRule.class).execute();
        // if ((rules != null) && (rules.size() > 0))
        // throw new DimInUseException("Error: Release Template "+templateId+" has rules defined which must be deleted first.");

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            // delete release template rules first
            query.resetMessage(wcm_sql.RELEASE_TEMPLATE_DELETE_RELEASETRS);
            query.bindInput(templateId);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

            // delete release template definition
            query.resetMessage(wcm_sql.DELETE_RELEASET);
            query.bindInput(templateId);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return "Operation Completed";
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Collection;
import java.util.Hashtable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions baseline.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Product name of container for the new item</dd>
 *  <dt>VARIANT {String}<dt><dd>Variant of the new item</dd>
 *  <dt>TYPE_NAME {String}<dt><dd>Type name for the new item</dd>
 *  <dt>REVISION {String}<dt><dd>Revision of the new item</dd>
 *  <dt>OWNING_PART {Part}<dt><dd>The owning part to relate the item to</dd>
 *  <dt>WS_FILE {String}<dt><dd>The project filename</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new item.  Generated if null</dd>
 *  <dt>FORMAT {String}<dt><dd>File format for the new item</dd>
 *  <dt>DESCRIPTION {String}<dt><dd>Description of the new item</dd>
 *  <dt>ITEM_LIB_FILE_NAME {String}<dt><dd>Library filename of the new item</dd>
 *  <dt>WORKSET {WorkSet}<dt><dd>Project that this item is created in</dd>
 *  <dt>KEEP {Boolean}<dt><dd>Keep the user file after item is created</dd>
 *  <dt>USER_FILE {String}<dt><dd>Name of the user file for the item creation</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of change documents to be related</dd>
 *  <dt>COMMENT {String}<dt><dd>Comment of the item creation operation</dd>
 *  <dt>CONTENT_ENCODING {String}</dt><dd>Content encoding to be used when creating new revision</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateItemCmd extends RPCExecCmd {
    public CreateItemCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VARIANT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REVISION, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.OWNING_PART, true, Part.class));
        setAttrDef(new CmdArgDef(CmdArguments.WS_FILE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.FORMAT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ITEM_LIB_FILE_NAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.KEEP, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CONTENT_ENCODING, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.PERMS, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    // Query the process model auto-generate id flag...
    public static boolean isAutoGenerateOn(String productName, String typeName) throws DBIOException, AdmException {
        AdmObject itemType = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(
                productName + ":" + typeName + "-" + Item.class.getName(), Type.class));
        Boolean autoGen = (Boolean) AdmHelperCmd.getAttributeValue(itemType, AdmAttrNames.ITEMTYPE_AUTOGEN);
        if (autoGen == null) {
            return false;
        }

        return autoGen.booleanValue();
    }

    private String generateId(String id, String productName, String typeName, String fname) throws DimBaseCmdException,
            AdmObjectException, AdmException {
        // If the flag is set always ask the server to generate ids...

        if (CreateItemCmd.isAutoGenerateOn(productName, typeName)) {
            return "";
        }

        // If the flag is not set and the user specified a id then use it!

        if ((id != null) && (id.length() != 0)) {
            return id;
        }

        // Process model flag is off but the user did not specify a id!
        // So generate the item id from the upload rules...

        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(CmdArguments.FILENAME, fname));
        Cmd cmd = AdmCmd.getCmd(Creatable.QUERY_DEFAULTS);
        cmd.setAttrValue(CmdArguments.ADM_OBJECT_CLASS, Item.class);
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        Hashtable[] ht = (Hashtable[]) cmd.execute();

        if ((ht == null) || (ht.length < 1) || (ht[0] == null)) {
            return id;
        }

        String value = (String) ht[0].get(AdmAttrNames.ID);

        if (value == null) {
            return id;
        }

        return value;
    }

    private String productName;
    private String id;
    private String variant;
    private String typeName;
    private String revision;


    /** todo The message server must add a function to call the pcms id generation */
    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Item.class);

        AdmBaseId newBaseId = (AdmBaseId) retResult.getUserData();
        if (newBaseId != null) {
            Debug.println("Floz: newBaseId is OK!");
        } else {
            Debug.println("Floz: newBaseId is null!");
            if ((productName != null) && (productName.length() > 0) && (id != null) && (id.length() > 0) && (typeName != null)
                    && (typeName.length() > 0)) {
                if ((variant == null) || (variant.length() < 1)) {
                    variant = "%";
                }

                if ((revision == null) || (revision.length() < 1)) {
                    revision = "%";
                }

                Filter filter = new FilterImpl();
                Collection crit = filter.criteria();
                crit.add(new FilterCriterion(AdmAttrNames.PRODUCT_NAME, productName));
                crit.add(new FilterCriterion(AdmAttrNames.ID, id));
                crit.add(new FilterCriterion(AdmAttrNames.VARIANT, variant));
                crit.add(new FilterCriterion(AdmAttrNames.TYPE_NAME, typeName));
                crit.add(new FilterCriterion(AdmAttrNames.REVISION, revision));

                Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, AdmCmd.getCurRootObj(BaseDatabase.class));
                cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Item.class);
                cmd.setAttrValue(CmdArguments.FILTER, filter);
                newBaseId = (AdmBaseId) cmd.execute();
                retResult = new AdmResult(retResult.getResultMsg(), newBaseId);
            }
        }
        return retResult;
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        this.productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        this.id = (String) getAttrValue(AdmAttrNames.ID);
        this.variant = (String) getAttrValue(AdmAttrNames.VARIANT);
        this.typeName = (String) getAttrValue(AdmAttrNames.TYPE_NAME);
        this.revision = (String) getAttrValue(AdmAttrNames.REVISION);
        Part owningPart = (Part) getAttrValue(CmdArguments.OWNING_PART);
        String wsFile = (String) getAttrValue(CmdArguments.WS_FILE);
        String format = (String) getAttrValue(AdmAttrNames.FORMAT);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        String libFile = (String) getAttrValue(AdmAttrNames.ITEM_LIB_FILE_NAME);
        WorkSet project = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        boolean keep = ((Boolean) getAttrValue(CmdArguments.KEEP)).booleanValue();
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        String encoding = (String) getAttrValue(CmdArguments.CONTENT_ENCODING);
        String perms = (String) getAttrValue(CmdArguments.PERMS);

        // Populate library filename if empty
        if ((libFile == null)) {
            libFile = "";
        }

        // Generate the id if needed

        if ((wsFile != null) && (wsFile.length() > 0)) {
            id = generateId(id, productName, typeName, wsFile);
        } else {
            id = generateId(id, productName, typeName, userFile);
        }

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id + "." + variant + "-" + typeName + ";" + revision);
        _cmdStr = "CI " + Encoding.escapeDMCLI((String) getAttrValue(CmdArguments.INT_SPEC));

        if (owningPart != null) {
            _cmdStr += " /PART=" + Encoding.escapeDMCLI(owningPart.getAdmSpec().getSpec());
        }

        if ((wsFile != null) && (wsFile.length() > 0)) {
            _cmdStr += " /WS_FILENAME=" + Encoding.escapeDMCLI(CmdUtils.relPathForCmd(wsFile));
        }

        if ((format != null) && (format.length() > 0)) {
            _cmdStr += " /FORMAT=" + Encoding.escapeDMCLI(format);
        }

        if ((desc != null) && (desc.length() > 0)) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(desc);
        }

        if ((libFile != null)) {
            _cmdStr += " /FILENAME=" + Encoding.escapeDMCLI(libFile);
        }

        if (project != null) {
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec());
        }

        _cmdStr += (keep) ? " /KEEP" : " /NOKEEP";

        if ((userFile != null) && (userFile.length() > 0)) {
            _cmdStr += " /USER_FILENAME=" + Encoding.escapeDMCLI(userFile);
        }

        if ((chdocs != null) && (chdocs.length() > 0)) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
        }

        if ((comment != null) && (comment.length() > 0)) {
            _cmdStr += " /COMMENT=" + Encoding.escapeDMCLI(comment);
        }

        if (encoding != null && encoding.length() > 0) {
            _cmdStr += " /CONTENT_ENCODING=" + Encoding.escapeSpec(encoding);
        }

        if (perms != null && perms.length() > 0) {
            _cmdStr += " /PERMS=" + Encoding.escapeDMCLI(perms);
        }

        _cmdStr += " ";
        _cmdStr += AttributeDefinition.getAttrsCmdStringFromCmd(this);
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import com.serena.dmfile.FilePlatforms;

import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Query if the area is defined on MVS node.
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Area Name</dd>
 * </dl></code>
 *
 * @author S. Korniychuk
 */
public class QueryIsAreaOnMVSNodeCmd extends RPCCmd { // extends DBIOCmd {

    // private final static String MVS_NODE_NAME = "MVS";

    public QueryIsAreaOnMVSNodeCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAlias(Server.QUERY_IS_AREA_ON_MVS_NODE);
    }

    @Override
    public Object execute() throws DBIOException, AdmException {
        validateAllAttrs();
        // Boolean ret = Boolean.FALSE;
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        return CmdUtils.getUncachedOsType(admObj.getId()) == FilePlatforms.OS390;
        // DBIO query = new DBIO(wcm_sql.GET_AREA_NODE_FILE_SYSTEM_NAME);
        // query.bindInput(admObj.getId());
        // query.readStart();
        // if (query.read()) {
        // String stype = query.getString(2);
        // if (MVS_NODE_NAME.equalsIgnoreCase(stype)) {
        // ret = Boolean.TRUE;
        // }
        // } else {
        // query.resetMessage(wcm_sql.GET_NODE_FILE_SYSTEM_NAME);
        // query.bindInput(admObj.getId());
        // query.readStart();
        // if (query.read()) {
        // String stype = query.getString(2);
        // if (MVS_NODE_NAME.equalsIgnoreCase(stype)) {
        // ret = Boolean.TRUE;
        // }
        // }
        // }
        // query.close();
        // return ret;
    }
}

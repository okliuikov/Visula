/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to merge baselines.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>BRANCHES {List}</dt><dd>List of baselines to merge</dd>
 *  <dt>ID {String}</dt><dd>Identifier of the new baseline</dd>
 *  <dt>OWNING_PART {AdmObject(Part)}</dt><dd>The owning part to relate the baseline to</dd>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of container for the new baseline</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>TYPE_NAME {String}</dt><dd>Type name for the new baseline</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class MergeBaselineCmd extends RPCExecCmd {
    public MergeBaselineCmd() throws AttrException {
        super();
        setAlias(Versionable.MERGE);
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.OWNING_PART, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.BRANCHES)) {
            List branches = (List) attrValue;
            if (branches.size() == 0) {
                throw new AttrException("Error: Nothing has been specified to compare!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.OWNING_PART)) {
            if ((attrValue != null) && (!(attrValue instanceof Part))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        List branches = (List) getAttrValue(CmdArguments.BRANCHES);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        AdmObject owningPart = (AdmObject) getAttrValue(CmdArguments.OWNING_PART);
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String typeName = (String) getAttrValue(AdmAttrNames.TYPE_NAME);

        if (branches.size() < 2) {
            throw new DimBaseCmdException("Must specify at least two baselines to merge!");
        }

        setAttrValue(CmdArguments.INT_SPEC, productName + ":" + id);
        _cmdStr = "CMB " + Encoding.escapeSpec(productName + ":" + id);
        _cmdStr += " /PART=" + Encoding.escapeSpec(owningPart.getAdmSpec().getSpec());
        _cmdStr += " /BASELINE_LIST=(";
        for (int i = 0; i < branches.size(); i++) {
            if (i > 0) {
                _cmdStr += ", ";
            }

            _cmdStr += Encoding.escapeSpec(((AdmObject) branches.get(i)).getAdmSpec().getSpec());
        }

        _cmdStr += ")";
        if ((typeName != null) && (typeName.length() > 0)) {
            _cmdStr += " /TYPE=" + Encoding.escapeSpec(typeName);
        }

        _cmdStr += " " + AttributeDefinition.getAttrsCmdStringFromCmd(this);

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Baseline.class);
        return retResult;
    }
}

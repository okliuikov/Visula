/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.assignable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will assign or deassign groups from a user.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 * <dt>ADM_OBJECT {AdmObject}<dt><dd>User to assign groups to</dd>
 * <dt>USER_GROUPS {List}<dt><dd>Groups to assign or deassign from user</dd>
 * <dt>USER_ASSIGN_GROUPS {Boolean}<dt><dd>Flag to determine whether to assign or deassign groups from a user</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt><dt><dd></dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Paul Smith
 */
public class AssignGroupsToUserCmd extends RPCExecCmd {

    public AssignGroupsToUserCmd() throws AttrException {
        super();
        setAlias(Assignable.ASSIGN_GROUPS_TO_USER);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_GROUPS, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_ASSIGN_GROUPS, true, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof User)) {
                throw new AttrException("AssignGroupsToUserCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject user = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List userGroupsList = (List) getAttrValue(AdmAttrNames.USER_GROUPS);
        Boolean assignGroups = (Boolean) getAttrValue(AdmAttrNames.USER_ASSIGN_GROUPS);

        StringBuffer sb = new StringBuffer();

        sb.append("AGRPU ");
        sb.append(Encoding.escapeSpec(user.getAdmSpec().getSpec()));

        sb.append(" /GROUPS=");

        if (userGroupsList != null && userGroupsList.size() > 0) {
            sb.append("(");
            String groupName = "";

            for (int i = 0; i < userGroupsList.size(); i++) {
                groupName = (String) userGroupsList.get(i);
                if (i > 0) {
                    sb.append(",");
                }
                sb.append(Encoding.escapeSpec(groupName));
            }
            sb.append(")");
        } else {
            sb.append(Encoding.escapeSpec(""));
        }

        // We are assigning groups
        if (assignGroups.booleanValue()) {
            sb.append(" /ADD");
        }
        // We are deassigning groups
        else {
            sb.append(" /REMOVE");
        }

        _cmdStr = sb.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, User.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.PreservationPolicy;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Preservation Rule object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {String}</dt><dd>The parent preservation policy</dd>
 *  <dt>TYPE_NAME {String}</dt><dd>Item type name (within the product that the policy is defined) in for which a preservation rule is defined</dd>
 *  <dt>RULE {String}</dt><dd>Specifies how the build targets will be preserved</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt></dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Pauls
 */
public class CreatePreservationRuleCmd extends RPCExecCmd {
    public CreatePreservationRuleCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRESERVATION_RULE, true, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            // Parent preservation policy must be defined
            if (!(attrValue instanceof PreservationPolicy)) {
                throw new AttrException("CreatePreservationRuleCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String rule = (String) getAttrValue(AdmAttrNames.PRESERVATION_RULE);
        String typeName = (String) getAttrValue(AdmAttrNames.TYPE_NAME);

        _cmdStr = "DPRP " + Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        _cmdStr += " /ITEM_TYPE=" + typeName;
        _cmdStr += " /RULE=" + rule;
        _cmdStr += " /ADD";

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, PreservationPolicy.class);
        return retResult;
    }
}

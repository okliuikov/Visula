/*
 * Copyright (C) 2001-2003, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimLockedException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplChdocMasterConfig;
import merant.adm.dimensions.objects.ReplChdocSubordinateConfig;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate a request type to a request replication configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {Type}<dt><dd>Dimensions Type object</dd>
 *  <dt>ADM_PARENT_OBJECT {ReplChdocMasterConfig}<dt><dd>Parent Dimensions request replication configuration object (only master)</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class RelateChdocTypeToChdocReplCfgCmd extends DBIOCmd {

    public RelateChdocTypeToChdocReplCfgCmd() throws AttrException {
        super();
        setAlias("RelateChdocTypeToChdocReplCfgCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, Type.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof ReplChdocMasterConfig) && !(attrValue instanceof ReplChdocSubordinateConfig)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // Dimensions request replication configuration
        final AdmObject configObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        // Dimensions request type
        final AdmObject requestType = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        // determine replication configuration attributes
        final boolean isMaster = configObj instanceof ReplChdocMasterConfig;

        List attrs = AdmHelperCmd.getAttributeValues(configObj,
                Arrays.asList(new Object[] { AdmAttrNames.ID, AdmAttrNames.REVISION }));
        final String configId = (String) attrs.get(0);
        final String revision = (String) attrs.get(1);

        // make sure that the replication configuration actually exists
        if (!DoesExistHelper.replConfigExists(configId, Constants.REPL_CHDOC_CLASS, revision)) {
            throw new DimNotExistsException("Request replication configuration " + configId + " does not exist.");
        }

        final long configUid = ((AdmUidObject) configObj).getUid();
        long replSiteUid = ((Long) AdmHelperCmd.getAttributeValue(configObj, AdmAttrNames.REPL_BASEDB_UID)).longValue();
        final String replSiteId = (String) AdmHelperCmd.getAttributeValue(configObj, AdmAttrNames.REPL_SITE_ID);

        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        long thisSiteUid = 0;
        if (thisSite != null) {
            thisSiteUid = ((AdmUidObject) thisSite).getUid();
        }

        if (!isLocalReplConfig(null, configUid, Constants.REPL_CHDOC_CLASS, thisSiteUid)) {
            throw new DimLockedException("Remote request replication configuration " + configId + " is not updatable.");
        }

        // determine request type attributes
        final String productName = (String) AdmHelperCmd.getAttributeValue(requestType, AdmAttrNames.PRODUCT_NAME);
        final String typeName = requestType.getId();

        Class typeClass = (Class) AdmHelperCmd.getAttributeValue(requestType, AdmAttrNames.PARENT_CLASS);
        if (!ChangeDocument.class.equals(typeClass)) {
            throw new DimInvalidAttributeException("Object type " + productName + ":" + typeName + " is not a request type.");
        }

        if (!DoesExistHelper.typeExists(productName, typeName, "C")) {
            throw new DimNotExistsException("Request type " + productName + ":" + typeName + " does not exist.");
        }

        if (Constants.GLOBAL_PRODUCT.equals(productName)) {
            throw new DimInvalidAttributeException("Request type " + productName + ":" + typeName
                    + " is invalid for this replication configuration.");
        }

        final long typeUid = ((AdmUidObject) requestType).getUid();

        final String whoAmI = isMaster ? "the request replication configuration " + configId + "." : "the subordinate site "
                + replSiteId + ".";

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws Exception {

                // check if this type has already been defined for this replication config
                boolean isAlreadyAssigned = isTypeAssigned(dbCtx, typeUid, configId, revision, Constants.REPL_CHDOC_CLASS);

                if (!bDeassign) {
                    if (isAlreadyAssigned) {
                        throw new DimAlreadyExistsException("Request type " + productName + ":" + typeName
                                + " has already been assigned to " + whoAmI);
                    }

                    // assign the type
                    String userName = AdmCmd.getCurRootObj(User.class).getId();
                    long relUid = getNewUid(dbCtx);
                    SqlUtils.replAssignTypeToConfig(dbCtx, relUid, configUid, typeUid, Constants.REPL_CHDOC_TYPE_REL_CLASS, userName);
                    dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);
                } else {
                    // check if type has already been assigned
                    if (!isAlreadyAssigned) {
                        throw new DimNotExistsException("Request type " + productName + ":" + typeName
                                + " has not been assigned to " + whoAmI);
                    }

                    // deassign the type from the replication configuration
                    SqlUtils.replDeassignTypeFromConfig(dbCtx, configUid, typeUid, Constants.REPL_CHDOC_TYPE_REL_CLASS);
                    dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);

                    // no need to check if any types are still assigned
                }
                // update audit trail
                SqlUtils.updateSysobj(dbCtx, configUid, AdmCmd.getCurRootObj(User.class).getId());
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

            }
        });

        return new AdmResult("Operation completed");
    }

    private boolean isTypeAssigned(DBIO dbCtx, long typeUid, String configId, String revision, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_IS_TYPE_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(typeUid);
        dbCtx.bindInput(Constants.REPL_CHDOC_TYPE_REL_CLASS);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private boolean isLocalReplConfig(DBIO dbCtx, long configUid, int replClass, long siteUid) throws AdmException {

        if (dbCtx != null) {
            dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(replClass);
            dbCtx.bindInput(siteUid);
            dbCtx.readStart();
            boolean isOwned = dbCtx.read(DBIO.DB_DONT_CLOSE);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
            return isOwned;
        }
        dbCtx = new DBIO(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
        dbCtx.bindInput(configUid);
        dbCtx.bindInput(replClass);
        dbCtx.bindInput(siteUid);
        dbCtx.readStart();
        boolean isOwned = dbCtx.read();
        dbCtx.close();
        return isOwned;
    }
}

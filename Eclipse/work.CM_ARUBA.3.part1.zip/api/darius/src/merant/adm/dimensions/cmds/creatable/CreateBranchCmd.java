/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions branch.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new branch</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}<dt><dd>Description for the new branch</dd>
 *  <dt>SENDER_ID {String}<dt><dd>Ownership of the branch</dd>
 *  <dt>BRANCH_IS_LOCKED {Boolean}<dt>
 *      <dd>Flag specifying that the branch is created locked. By default,
 *          branch is created open.
 *      </dd>
 *  <dt>UPDATE {Boolean}<dt><dd>Whether the branch is being altered</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateBranchCmd extends RPCExecCmd {
    public CreateBranchCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.SENDER_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LOCKED, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        String id = ValidationHelper.validateBranchId((String) getAttrValue(AdmAttrNames.ID));
        String desc = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));
        String owner = (String) getAttrValue(AdmAttrNames.SENDER_ID);
        Boolean locked = (Boolean) getAttrValue(AdmAttrNames.LOCKED);
        boolean update = ((Boolean) getAttrValue(CmdArguments.UPDATE)).booleanValue();

        setAttrValue(CmdArguments.INT_SPEC, id);

        if (update) {
            _cmdStr = "SVBF ";
        } else {
            _cmdStr = "DVB ";
        }
        _cmdStr += Encoding.escapeSpec(id);

        if (desc != null && desc.length() > 0) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeSpec(desc);
        } else if (!update) {
            _cmdStr += " /DESCRIPTION=\"Branch " + id + "\"";
        }

        if (locked != null && locked.booleanValue() == true) {
            _cmdStr += " /LOCK";
        } else if (update && locked != null && locked.booleanValue() == false) {
            _cmdStr += " /NOLOCK";
        }

        if (update) {
            if (owner != null && owner.length() > 0) {
                _cmdStr += " /OWNER=" + Encoding.escapeSpec(owner);
            } else if (owner != null && owner.length() == 0) {
                _cmdStr += " /OWNER=\"\"";
            }
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, Branch.class);
        return retResult;
    }
}

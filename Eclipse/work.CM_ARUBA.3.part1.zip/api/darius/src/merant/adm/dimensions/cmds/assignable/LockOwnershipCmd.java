/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2004 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will lock ownership a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>LOCK {Boolean}<dt><dd>If true, locks the specified change document</dd>
 *  <dt>CANCEL_LOCK {Boolean}<dt><dd>If true, cancels lock on the specified change document</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class LockOwnershipCmd extends RPCExecCmd {
    public LockOwnershipCmd() throws AttrException {
        super();
        setAlias(Assignable.LOCK_OWNERSHIP);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.LOCK, false, null, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.CANCEL_LOCK, false, null, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Boolean lock = (Boolean) getAttrValue(CmdArguments.LOCK);
        Boolean cancelLock = (Boolean) getAttrValue(CmdArguments.CANCEL_LOCK);

        _cmdStr = "UC ";
        _cmdStr += Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());

        if (lock != null && lock.booleanValue()) {
            _cmdStr += " /EXCLUSIVE_LOCK";
        } else if (cancelLock != null && cancelLock.booleanValue()) {
            _cmdStr += " /NOEXCLUSIVE_LOCK";
        }

        return executeRpc();
    }
}

package merant.adm.dimensions.cmds;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.serena.dmfile.dto.Pair;

import merant.adm.dimensions.util.Encoding;

public class CmdBuilder {

    public static final String SEPARATOR = " ";
    public static final String EQUALS = "=";
    public static final String OPEN_BRACKET = "(";
    public static final String CLOSE_BRACKET = ")";
    public static final String MULTI_PARAM_SEPARATOR = ",";

    private final StringBuilder sb;

    private CmdBuilder(String cmdName) {
        sb = new StringBuilder(cmdName);
    }

    public static CmdBuilder create(String cmdName) {
        return new CmdBuilder(cmdName);
    }

    public CmdBuilder addSpecification(String specification) {
        sb.append(SEPARATOR).append(Encoding.escapeSpec(specification));
        return this;
    }

    public CmdBuilder addParameter(String parameter) {
        sb.append(SEPARATOR).append(parameter);
        return this;
    }
    
    public CmdBuilder addParameter(String parameter, String value) {
        sb.append(SEPARATOR).append(parameter).append(EQUALS).append(Encoding.escapeDMCLI(value));
        return this;
    }

    public CmdBuilder addParameter(String parameter, Map<String, String> values) {
        sb.append(SEPARATOR).append(parameter).append(EQUALS).append(OPEN_BRACKET);
        int count = 0;
        for (Entry<String, String> entry : values.entrySet()) {
            count++;
            sb.append(Encoding.escapeDMCLI(entry.getKey()));
            sb.append(EQUALS);
            sb.append(Encoding.escapeDMCLI(entry.getValue()));
            if (count < values.size()) {
                sb.append(MULTI_PARAM_SEPARATOR);
            }
        }
        sb.append(CLOSE_BRACKET);
        return this;
    }

    public CmdBuilder addParameter(String parameter, Pair<String, String> values) {
        sb.append(SEPARATOR).append(parameter).append(EQUALS).append(OPEN_BRACKET);
        sb.append(Encoding.escapeDMCLI(values.getFirst()));
        sb.append(EQUALS);
        sb.append(Encoding.escapeDMCLI(values.getSecond()));
        sb.append(CLOSE_BRACKET);
        return this;
    }
    
    public CmdBuilder addParameter(String parameter, List<String> values) {
        sb.append(SEPARATOR).append(parameter).append(EQUALS).append(OPEN_BRACKET);
        for (int i = 0; i < values.size(); ++i) {
            if (i > 0) {
                sb.append(MULTI_PARAM_SEPARATOR);
            }
            sb.append(Encoding.escapeDMCLI(values.get(i)));
        }
        sb.append(CLOSE_BRACKET);
        return this;
    }

    public String build() {
        return sb.toString();
    }

    public void addRawText(String cmdPart) {
        sb.append(cmdPart);
    }

    public static String createParameter(String parameter, Map<String, String> values) {
        return CmdBuilder.create("").addParameter(parameter, values).build();
    }

    public static String createParameter(String parameter, Pair<String, String> values) {
        return CmdBuilder.create("").addParameter(parameter, values).build();
    }
    
    public static String createParameter(String parameter, List<String> values) {
        return CmdBuilder.create("").addParameter(parameter, values).build();
    }
}

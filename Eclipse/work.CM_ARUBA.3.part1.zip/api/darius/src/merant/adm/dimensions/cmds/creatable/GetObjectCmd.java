/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will obtain an AdmObject given an AdmBaseId.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_BASE_ID {AdmBaseId/Relationship}<dt>
 *  <dd>
 *      Base identifier for Dimension objects.<p>
 *      Can either be an AdmBaseId or a Relationship
 *      object containing an AdmBaseId as the child
 *      of the relationship.
 *  </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ATTRIBUTE_NAMES {String/List}<dt><dd>Attribute name or List of attribute names to query</dd>
 *  <dt>USE_SUPER_QUERY {Boolean}<dt><dd>Force the use of SuperQuery</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmObject}<dt><dd>Dimensions object for the specified base identifier</dd>
 * </dl></code>
 * @author Floz
 */
public class GetObjectCmd extends AdmCmd {
    public GetObjectCmd() throws AttrException {
        super();
        setAlias(Creatable.GET_OBJECT);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_BASE_ID, true));
        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTE_NAMES, false));
        setAttrDef(new CmdArgDef(CmdArguments.USE_SUPER_QUERY, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_BASE_ID)) {
            if ((!(attrValue instanceof AdmBaseId)) && (!(attrValue instanceof Relationship))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    /** @todo Implement using external cache */
    @Override
    public Object execute() throws DimBaseException, AdmException {
        validateAllAttrs();

        AdmBaseId baseId = null;
        Object tmpObj = getAttrValue(CmdArguments.ADM_BASE_ID);
        if (tmpObj instanceof AdmBaseId) {
            baseId = (AdmBaseId) tmpObj;
        } else if (tmpObj instanceof Relationship) {
            baseId = (AdmBaseId) ((AdmObject) tmpObj).getAttrValue(AdmAttrNames.REL_CHILD);
        }

        if (baseId == null) {
            return null;
        }

        AdmObject newObj = GetObjectsCmd.buildNewObject(baseId);
        if (getAttrValue(CmdArguments.ATTRIBUTE_NAMES) != null) {
            Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, newObj);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
            cmd.setAttrValue(CmdArguments.USE_SUPER_QUERY, getAttrValue(CmdArguments.USE_SUPER_QUERY));
            cmd.execute();
        }

        return newObj;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2019 Micro Focus | Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.IDMUtilsHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

import java.util.Arrays;

/**
 * Query the default IDM Tool instance. <b>Returns:</b> <code><dl>
 * <dt>{RequestProvider}</dt><dd>Default IDM Tool instance</dd>
 * </dl></code>
 *
 * @author S. Korniychuk
 * @since 10
 */
public class QueryDefaultIDMToolCmd extends DBIOCmd {
    public QueryDefaultIDMToolCmd() throws AttrException {
        super();
        setAlias(Server.QUERY_DEFAULT_IDM_TOOL);
    }

    @Override
    public Object execute() throws DBIOException, AdmException {
        validateAllAttrs();

        Object ret = null;
        long toolUid = IDMUtilsHelper.getDefaultIdmToolUid();
        if (toolUid != 0) {
            AdmBaseId base_id = AdmHelperCmd.newAdmBaseId(toolUid, RequestProvider.class);
            // convert the ids into objects
            Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECTS, RequestProvider.class);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, Arrays.asList(new String[] { AdmAttrNames.ID }));
            // / Get the children
            cmd.setAttrValue(CmdArguments.ADM_BASE_IDS, Arrays.asList(new AdmBaseId[] { base_id }));
            ret = cmd.execute();
        }
        return ret;
    }
}

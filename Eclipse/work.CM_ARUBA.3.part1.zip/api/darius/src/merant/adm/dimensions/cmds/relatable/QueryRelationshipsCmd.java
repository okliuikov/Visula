/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2001 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import java.util.List;
import java.util.Vector;

import com.serena.dmnet.RPC;
import com.serena.dmnet.drs.DRSClientQueryRelationships;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.Requirement;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.QueryConstants;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will return all Dimensions Relationship objects for
 * the specified object pair.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Parent Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>
 *                      List containing Relationships(that in turn contain the RelationshipType)
 *                      that represet the parent->child pairing</dd>
 * </dl></code>
 * @todo make getWorkset & getWorksetUid common, pinched from QueryChildrenCmd
 * @todo Add support for filters
 * @author Floz
 */
public class QueryRelationshipsCmd extends DBIOCmd {
    public QueryRelationshipsCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_RELATIONSHIPS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
    }

    /** @todo Find a way to validate when dependencies exist between arguments */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue != null) {
                if ((!(attrValue instanceof Baseline)) && (!(attrValue instanceof ChangeDocument))
                        && (!(attrValue instanceof DimDirectory)) && (!(attrValue instanceof Item))
                        && (!(attrValue instanceof Part)) && (!(attrValue instanceof Customer))
                        && (!(attrValue instanceof Release)) && (!(attrValue instanceof WorkSet))
                        && (!(attrValue instanceof Requirement)) && (!(attrValue instanceof ExternalRequest))) {
                    throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (attrValue != null) {
                if ((!(attrValue instanceof ChangeDocument)) && (!(attrValue instanceof DimDirectory))
                        && (!(attrValue instanceof Item)) && (!(attrValue instanceof Part)) && (!(attrValue instanceof WorkSet))
                        && (!(attrValue instanceof Baseline)) && (!(attrValue instanceof Release))
                        && (!(attrValue instanceof Requirement)) && (!(attrValue instanceof ExternalRequest))) {
                    throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
                }
            }
        }
    }

    private AdmUid m_worksetuid = null;

    private AdmUid getWorksetUid() throws DBIOException, DimBaseException, AdmException {
        if (m_worksetuid != null) {
            return m_worksetuid;
        }

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        WorkSet workSet = (WorkSet) getAttrValue(CmdArguments.WORKSET);

        if (workSet != null) {
            m_worksetuid = workSet.getAdmUid();
        } else {
            if ((admObj.getAdmBaseId().getScope() != null) && (admObj.getAdmBaseId().getScope() instanceof AdmUid)
                    && (admObj.getAdmBaseId().getScope().getObjType().equals(WorkSet.class))) {
                m_worksetuid = (AdmUid) admObj.getAdmBaseId().getScope();
            } else {
                m_worksetuid = ((AdmUidObject) DimSystem.getSystem().getSessionBean().getCurRootObj(WorkSet.class)).getAdmUid();
            }

            if (m_worksetuid == null) {
                m_worksetuid = new AdmUid(Constants.GLOBAL_WSET_UID, WorkSet.class);
            }
        }

        return m_worksetuid;
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject admParentObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);

        /** Set to true if the Spec is required in the query and the return value */
        boolean querySpec = false;

        // Values of these two int variables are set based on the entry in build\include\pcms_api.h
        int parentObject = -1;
        int childObject = -1;
        boolean nothingToQuery = false;

        if (admParentObj instanceof ChangeDocument) {
            parentObject = pcmsApiMap.get("ChangeDocument");
            if (admObj instanceof Baseline) {
                childObject = pcmsApiMap.get("Baseline");
                querySpec = true;
            } else if (admObj instanceof Requirement) {
                AdmObject rel = new Relationship(admParentObj.getAdmBaseId(), admObj.getAdmBaseId());
                rel.setAttrValue(AdmAttrNames.REL_TYPE, new RelationshipType("Breakdown"));
                List retRels = new Vector(1);
                retRels.add(rel);
                return retRels;
            } else {
                if (admObj instanceof ChangeDocument) {
                    childObject = pcmsApiMap.get("ChangeDocument");
                } else if (admObj instanceof Item) {
                    childObject = pcmsApiMap.get("Item");
                } else {
                    nothingToQuery = true;
                }
            }
        } else if (admParentObj instanceof DimDirectory) {
            parentObject = pcmsApiMap.get("DimDirectory");

            if (admObj instanceof DimDirectory) {
                childObject = pcmsApiMap.get("DimDirectory");
            } else if (admObj instanceof Item) {
                childObject = pcmsApiMap.get("Item");
            } else {
                nothingToQuery = true;
            }
        } else if (admParentObj instanceof Item) {
            parentObject = pcmsApiMap.get("Item");

            if (admObj instanceof Item) {
                childObject = pcmsApiMap.get("Item");
            }
        } else if (admParentObj instanceof Part) {
            parentObject = pcmsApiMap.get("Part");
            if (admObj instanceof ChangeDocument) {
                childObject = pcmsApiMap.get("ChangeDocument");
            } else if (admObj instanceof Item) {
                childObject = pcmsApiMap.get("Item");
            } else if (admObj instanceof Part) {
                childObject = pcmsApiMap.get("Part");
            }
        } else if (admParentObj instanceof WorkSet) {
            parentObject = pcmsApiMap.get("WorkSet");
            if (admObj instanceof Baseline || admObj instanceof WorkSet) {
                Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN);
                cmd.setAttrValue(CmdArguments.ADM_OBJECT, admParentObj);

                if (admObj instanceof Baseline) {
                    cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Baseline.class);
                } else {
                    cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, WorkSet.class);
                }

                List baseIds = (List) cmd.execute();
                if (baseIds != null && baseIds.contains(admObj.getAdmBaseId())) {
                    AdmObject reltype = new RelationshipType("Based On");
                    AdmObject rel = new Relationship(admParentObj.getAdmBaseId(), admObj.getAdmBaseId());
                    rel.setAttrValue(AdmAttrNames.REL_TYPE, reltype);
                    List retRels = new Vector(1);
                    retRels.add(rel);
                    return retRels;
                } else {
                    return null;
                }
            } else if (admObj instanceof ChangeDocument) {
                childObject = pcmsApiMap.get("ChangeDocument");
            } else if (admObj instanceof ExternalRequest) {
                childObject = pcmsApiMap.get("ExternalRequest");
            } else {

                if (admObj instanceof DimDirectory) {
                    childObject = pcmsApiMap.get("DimDirectory");
                } else if (admObj instanceof Item) {
                    childObject = pcmsApiMap.get("Item");
                } else {
                    nothingToQuery = true;
                }
            }
        } else if (admParentObj instanceof ExternalRequest) {
            parentObject = pcmsApiMap.get("ExternalRequest");
            if (admObj instanceof Item) {
                childObject = pcmsApiMap.get("Item");
            } else if (admObj instanceof Baseline) {
                childObject = pcmsApiMap.get("Baseline");
                querySpec = true;
            }
        } else// NEW
        {
            AdmObject reltype = null;
            if (admParentObj instanceof Baseline) {
                if (admObj instanceof WorkSet) {
                    reltype = new RelationshipType("Based On");
                } else if (admObj instanceof Part) {
                    reltype = new RelationshipType("Breakdown");
                } else if (admObj instanceof Release) {
                    reltype = new RelationshipType("Released");
                } else if (admObj instanceof Item) {
                    reltype = new RelationshipType("Owned");
                } else if (admObj instanceof Baseline) {
                    AdmBaseId baseId = admObj.getAdmBaseId();
                    reltype = getBaselineRelTypeSQ(baseId, admParentObj, QueryConstants.SELECT_REL);
                    if (reltype == null) {
                        reltype = getBaselineRelTypeSQ(baseId, admParentObj, QueryConstants.USAGE | QueryConstants.SELECT_REL);
                    }
                } else if (admObj instanceof Requirement) {
                    AdmBaseId baseId = admParentObj.getAdmBaseId();
                    reltype = getBaselineRelTypeSQ(baseId, admObj, QueryConstants.SELECT_REL);
                }
            } else if (admParentObj instanceof Release) {
                if (admObj instanceof Item) {
                    reltype = new RelationshipType("Owned");
                } else if (admObj instanceof Customer) {
                    reltype = new RelationshipType("Forwarded");
                }
            } else if (admParentObj instanceof Requirement) {
                if (admObj instanceof ChangeDocument) {
                    reltype = new RelationshipType("Breakdown");
                }
            }

            // if (reltype!=null) {
            AdmObject rel = new Relationship(admParentObj.getAdmBaseId(), admObj.getAdmBaseId());
            rel.setAttrValue(AdmAttrNames.REL_TYPE, reltype);
            List retRels = new Vector(1);
            retRels.add(rel);
            return retRels;
            // }
        }

        if (nothingToQuery) {
            return null;
        }
        List relTypes = new Vector();

        // Prepare DRS query
        DRSClientQueryRelationships drsClientQueryRelationships = new DRSClientQueryRelationships(DRSUtils.getLCNetClntObject());
        drsClientQueryRelationships.setParentUid(((AdmUidObject) admParentObj).getAdmUid().getUid());
        drsClientQueryRelationships.setChildUid(((AdmUidObject) admObj).getAdmUid().getUid());
        drsClientQueryRelationships.setWsetUid(getWorksetUid().getUid());
        drsClientQueryRelationships.setParentObjectType(parentObject);
        drsClientQueryRelationships.setChildObjectType(childObject);

        DRSQuery drsQuery = new DRSQuery(drsClientQueryRelationships);
        DRSOutputDataExtractor drsOutputDataExtractor = drsQuery.execute();
        if (drsOutputDataExtractor.hasRPCExecutionFailed()) {
            throw new DRSException("Error during call of DRS function " + DRSClientQueryRelationships.dataRequestId + " via RPC("
                    + RPC.RPC_DATA_REQUEST + ")");
        } else if (!drsOutputDataExtractor.isResultEmpty()) {
            int[] itemUids = drsOutputDataExtractor.getIntValues(DRSParams.REL_TYPES);
            String[] itemSpecs = null;
            for (int i = 0; i < itemUids.length; i++) {
                if (querySpec && itemSpecs != null && itemSpecs.length > 0) {
                    itemSpecs = drsOutputDataExtractor.getStringValues(DRSParams.REL_NAMES);
                    relTypes.add(AdmHelperCmd.newAdmBaseId(itemUids[i], RelationshipType.class, null,
                            AdmHelperCmd.newAdmBaseId(itemSpecs[i], RelationshipType.class, null, null)));
                } else {
                    relTypes.add(AdmHelperCmd.newAdmBaseId(itemUids[i], RelationshipType.class));
                }
            }
        }

        if (relTypes.size() < 1) {
            return null;
        }

        Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECTS, RelationshipType.class);
        cmd.setAttrValue(CmdArguments.ADM_BASE_IDS, relTypes);
        relTypes = (List) cmd.execute();

        AdmObject rel = null;
        List retRels = new Vector();
        for (int i = 0; i < relTypes.size(); i++) {
            rel = new Relationship(admParentObj.getAdmBaseId(), admObj.getAdmBaseId());
            rel.setAttrValue(AdmAttrNames.REL_TYPE, relTypes.get(i));
            retRels.add(rel);
        }

        return retRels;
    }

    private RelationshipType getBaselineRelTypeSQ(AdmBaseId baseId, AdmObject admParentObj, int flag) {
        RelationshipType ret = null;
        try {
            SuperQuery sq = new SuperQuery();
            sq.setObjectType(Baseline.class);
            sq.setScope(baseId);
            sq.addSelect(AdmAttrNames.ADM_UID);
            sq.addSelect(AdmAttrNames.ADM_SPEC);
            sq.addOutputLong();
            sq.addOutputString();
            sq.addRel(admParentObj, flag);
            sq.addWhere(AdmAttrNames.ADM_UID, new String(baseId.toString()));
            sq.readStart();
            // * We only expect one return here
            if (sq.read()) {
                // Debug.println(sq.getObject(1) + ", " + sq.getObject(2)
                // + ", " + sq.getObject(3) + ", " + sq.getObject(4));
                String reltypeName = sq.getString(4);
                if (reltypeName != null && reltypeName.length() > 0) {
                    ret = new RelationshipType(reltypeName);
                }
            }
        } catch (AdmException e) {
            // * If there is an error, then a relationship type will
            // * not be returned, which means there will be none
            // * to display.
            Debug.error(e.getMessage());
        }
        return ret;
    }

}

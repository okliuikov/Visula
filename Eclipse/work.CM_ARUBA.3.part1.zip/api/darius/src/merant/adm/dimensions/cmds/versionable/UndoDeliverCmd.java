/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2017 Serena Software Europe, Ltd. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * UNDO Dimensions stream or project version.
 * <p>
 * Uses RPCExecCmd to undo changeset via the message server.<br>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>WORKSET_VERSION {Integer}<dt><dd>The version of stream or project to undo</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {String}<dt><dd>Specifies the name of the stream or project</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>Specifies requests to relate</dd>
 *  <dt>COMMENT {String}<dt><dd>A comment to describe the purpose of the undo operation.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 */
public class UndoDeliverCmd extends RPCExecCmd {
    public UndoDeliverCmd() throws AttrException {
        super();
        setAlias(Versionable.UNDO_DELIVER);
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET_VERSION, true, Integer.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, String.class)); 
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));

    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();

        Integer worksetVersion = (Integer) getAttrValue(CmdArguments.WORKSET_VERSION);
        String worksetSpec = (String) getAttrValue(CmdArguments.WORKSET);  // workset.getAdmSpec().getSpec()
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);

        _cmdStr = "UNDO ";

        if (worksetVersion != null) {
            _cmdStr += Encoding.escapeDMCLI(String.valueOf(worksetVersion));  // Encoding.escapeDMCLI("" + worksetVersion);
        }

        if ((worksetSpec != null) && (worksetSpec.length() > 0)) {
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(worksetSpec);
        }

        if ((chdocs != null) && (chdocs.length() > 0)) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
        }

        if ((comment != null) && (comment.length() > 0)) {
            _cmdStr += " /COMMENT=" + Encoding.escapeDMCLI(comment);
        }
    }

    @Override
    public Object execute() throws AdmException {
        AdmResult ret = new AdmResult(executeRpc());

        return ret;
    }

}

/*
 * Copyright (C), 2005-2017, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.serena.dmfile.BuildSourceInfo;
import com.serena.dmfile.BuildTargetInfo;
import com.serena.dmfile.BuildTargetsResult;
import com.serena.dmfile.PreserveBuilderTargetResult;
import com.serena.dmnet.LCNetClnt;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command passes the builder BOM data to the Dimensions core for processing.
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>buildAreaRoot{String}<dt><dd>The root directory of the build area.</dd>
 *  <dt>buildProject {Boolean}<dt><dd>Is this a project build?</dd>
 *  <dt>buildStage {String}<dt><dd>The stage of the build</dd>
 *  <dt>buildBOMFileName {String}<dt><dd>Absolute filename to the BOM data file.</dd>
 *  <dt>buildChdocs {Long}<dt><dd>Comma seperated list of change document specifications.</dd>
 *  <dt>buildWsetUidObj {Long}<dt><dd>Workset uid into whch we preserve the targets.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>true/false boolean</dd>
 * </dl></code> Created 09/02/2006.
 * @author Llew Thomas
 */

public class RPCPreserveBuilderTargets extends RPCCmd {
    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCPreserveBuilderTargets() throws AdmObjectException, AttrException {
        super();
        setAlias("PreserveBuilderTargets");
        AddArgument("cmd", "PreserveBuilderTargets");

        setAttrDef(new CmdArgDef("targetWorkset", true, "", "", ""));
        setAttrDef(new CmdArgDef("baselineSpec", true, "", "", ""));
        setAttrDef(new CmdArgDef("sourceWorkset", true, "", "", ""));
        setAttrDef(new CmdArgDef("buildAreaId", true, "", "", ""));
        setAttrDef(new CmdArgDef("buildNodePlatform", true, "", "", ""));
        setAttrDef(new CmdArgDef("stageAlias", true, "", "", ""));
        setAttrDef(new CmdArgDef("buildChdocs", true, "", "", ""));
        setAttrDef(new CmdArgDef("fPreserveOptions", true, Integer.class));
        setAttrDef(new CmdArgDef("BuildTargetInfo", true, ArrayList.class));
        setAttrDef(new CmdArgDef("BuildSourceInfo", true, ArrayList.class));
        setAttrDef(new CmdArgDef("iJobQueueUid", true, Integer.class));
        setAttrDef(new CmdArgDef("tmpWsSpec", true, "", "", ""));
        setAttrDef(new CmdArgDef("isStream", true, Integer.class));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            String targetWsSpec = (String)getAttrValue("targetWorkset");
            String baselineSpec = (String)getAttrValue("baselineSpec");
            String sourceWsSpec = (String)getAttrValue("sourceWorkset");
            String buildAreaId = (String)getAttrValue("buildAreaId");
            String buildRelPath = (String)getAttrValue("buildRelPath");
            String buildNodePlatform = (String)getAttrValue("buildNodePlatform");
            String stageAlias = (String)getAttrValue("stageAlias");
            String buildChdocs = (String)getAttrValue("buildChdocs");
            int fPreserveOptions = ((Integer)getAttrValue("fPreserveOptions")).intValue();

            List<BuildTargetInfo> ltargets = (List<BuildTargetInfo>)getAttrValue("BuildTargetInfo");
            List<BuildSourceInfo> lsources = (List<BuildSourceInfo>)getAttrValue("BuildSourceInfo");
            BuildTargetInfo[] targets = (BuildTargetInfo[])ltargets.toArray(new BuildTargetInfo[ltargets.size()]);
            BuildSourceInfo[] sources = (BuildSourceInfo[])lsources.toArray(new BuildSourceInfo[lsources.size()]);

            int iJobQueueUid = ((Integer)getAttrValue("iJobQueueUid")).intValue();
            String tmpWsSpec = (String)getAttrValue("tmpWsSpec");
            int isStream = ((Integer)getAttrValue("isStream")).intValue();

            LCNetClnt conn = getSession().getConnection();
            BuildTargetsResult result = conn.rpcPreserveBuilderTargetsV2(targetWsSpec,
                                                                         baselineSpec,
                                                                         sourceWsSpec,
                                                                         buildAreaId,
                                                                         buildRelPath,
                                                                         buildNodePlatform,
                                                                         stageAlias,
                                                                         buildChdocs,
                                                                         fPreserveOptions,
                                                                         targets,
                                                                         sources,
                                                                         iJobQueueUid,
                                                                         tmpWsSpec,
                                                                         isStream);
            return result;
        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

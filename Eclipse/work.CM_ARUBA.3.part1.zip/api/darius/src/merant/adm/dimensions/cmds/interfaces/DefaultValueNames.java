/*
 * Copyright (C) 2000, 2010 Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.interfaces;

import merant.adm.dimensions.server.core.Constants;

/**
 * This class contains the constants used for default values,
 * whenever one is not available elsewhere.
 * 
 * @author Floz, Pbate
 */
public class DefaultValueNames {
    public static final String OWNING_PART_VARIANT = Constants.NON_USER_DEF_ATTR_CHAR + "DefaultValueNames.owning_part_variant";
    public static final String OWNING_PART_ID = Constants.NON_USER_DEF_ATTR_CHAR + "DefaultValueNames.owning_part_id";
    public static final String OWNING_PART_PCS = Constants.NON_USER_DEF_ATTR_CHAR + "DefaultValueNames.owning_part_pcs";
}

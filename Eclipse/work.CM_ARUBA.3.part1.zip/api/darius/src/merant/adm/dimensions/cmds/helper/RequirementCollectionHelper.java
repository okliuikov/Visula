/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.objects.RMProject;
import merant.adm.dimensions.objects.RequirementCollection;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.session.Session;

/**
 * @author pbate
 *         Quick method to get the user objects for a list of user ids instead of using AdmCmd.getObjects()
 *         which is running one query per user id passed in.
 */
public class RequirementCollectionHelper {

    public static List getRequirementCollectionObjects(RMProject rm_project) throws AdmException, IOException {
        List ret = new ArrayList();
        if (((Session) DimSystem.getSystem().getSession()).getConnection().rpcHasRTM(null)) {
            SuperQuery sq = new SuperQuery();

            sq.setObjectType(RequirementCollection.class);
            sq.setScope(new AdmBaseId(rm_project != null ? RMProject.class : WorkSet.class));

            // specify the attributes we want back
            sq.addSelect(AdmAttrNames.ADM_UID); // collection id
            sq.addSelect(AdmAttrNames.ADM_SPEC); // collection name
            sq.addSelect(AdmAttrNames.TYPE_FLAG); // baseline or
                                                  // collection
            // * Look in the current workset.
            sq.addRel(rm_project != null ? rm_project : AdmCmd.getCurRootObj(WorkSet.class));
            sq.addDefaultOrder();

            sq.readStart();
            while (sq.read()) {
                long id = sq.getLong(1);
                String spec = sq.getString(2);
                long baselineFlag = sq.getLong(3);
                AdmObject obj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(id, RequirementCollection.class));
                obj.setAttrValue(AdmAttrNames.ADM_SPEC, spec);
                obj.setAttrValue(AdmAttrNames.TYPE_FLAG, new Long(baselineFlag));
                ret.add(obj);
            }
        }
        return ret;
    }
}

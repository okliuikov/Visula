/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Obtains the value of a symbol from the Dimensions server.
 * 
 * @author Peter Raymond
 */
public class RPCGetSymbolCmd extends RPCCmd {
    
    public static final String ALIAS = "GetSymbol";
    
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCGetSymbolCmd() throws AdmObjectException, AttrException {
        super();
        setAlias(ALIAS);
        setAttrDef(new CmdArgDef(CmdArguments.SYMBOL, true, "The name of the symbol to get"));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            return getSession().getConnection().rpcPcmsGetSymbol((String) getAttrValue("symbol"));
        } catch (AttrException e) {
            return null;
        } catch (IOException ioe) {
            throw new DimConnectionException(ioe);
        }

    }

}

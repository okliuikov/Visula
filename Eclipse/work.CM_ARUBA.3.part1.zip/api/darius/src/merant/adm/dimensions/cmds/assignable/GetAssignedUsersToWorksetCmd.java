package merant.adm.dimensions.cmds.assignable;

import merant.adm.dimensions.cmds.CmdBuilder;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class GetAssignedUsersToWorksetCmd extends RPCExecCmd {
    public GetAssignedUsersToWorksetCmd() throws AttrException {
        super();
        setAlias(Assignable.GET_ASSIGNED_USERS_TO_WORKSET);
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, true, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        final String workset = (String) getAttrValue(AdmAttrNames.PROJECT);
        _cmdStr = CmdBuilder.create("UWP").addSpecification(workset).build();
        return executeRpc();
    }
}


/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.PersistentQuery;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.userattrs._internal_pquery;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions persistent query.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Identifier of the new query</dd>
 *  <dt>PARENT_CLASS {Class}</dt><dd>The class of AdmObject which the results of this query will be</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>CLIENT_DATA_TYPE {String}</dt><dd>Type of the new query</dd>
 *  <dt>PRSTQRY_FILTER {Filter}</dt><dd>The Filter object to persist</dd>
 *  <dt>PRSTQRY_ATTRIBUTE_NAMES {List}</dt><dd>List of attributes interested in (columns)</dd>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}</dt><dd>The parent AdmObject for this query
 *      (assumes BaseDatabase if omitted)</dd>
 *  <dt>PRSTQRY_IS_PUBLIC {Boolean}</dt><dd>If true, query is public, otherwise (and default) private</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreatePersistentQueryCmd extends DBIOCmd {
    public CreatePersistentQueryCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PARENT_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CLIENT_DATA_TYPE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRSTQRY_FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRSTQRY_ATTRIBUTE_NAMES, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRSTQRY_IS_PUBLIC, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RPT_CHART_TYPE, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RPT_DATESPAN, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RPT_GROUP_BY_ATTRS, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RPT_GROUP_BY_DIRECTIONS, false, List.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        Class resClass = (Class) getAttrValue(AdmAttrNames.PARENT_CLASS);
        String type = (String) getAttrValue(AdmAttrNames.CLIENT_DATA_TYPE);
        Filter filter = (Filter) getAttrValue(AdmAttrNames.PRSTQRY_FILTER);
        List attrs = (List) getAttrValue(AdmAttrNames.PRSTQRY_ATTRIBUTE_NAMES);
        boolean isPublic = ((Boolean) getAttrValue(AdmAttrNames.PRSTQRY_IS_PUBLIC)).booleanValue();

        Integer chartType = (Integer) getAttrValue(AdmAttrNames.RPT_CHART_TYPE);
        Integer dateSpan = (Integer) getAttrValue(AdmAttrNames.RPT_DATESPAN);
        List groupByAttrs = (List) getAttrValue(AdmAttrNames.RPT_GROUP_BY_ATTRS);
        List groupByDirs = (List) getAttrValue(AdmAttrNames.RPT_GROUP_BY_DIRECTIONS);

        String revision = AdmCmd.getCurRootObj(User.class).getAdmSpec().getSpec();
        if (isPublic) {
            revision = Constants.GLOBAL_ID;
        }

        long uid = Constants.INVALID_UID;
        if (Constants.CLIENT_DATA_CUSTOM_FILTER.equals(type)) {
            uid = _internal_pquery.putCustom(type, id, resClass, AdmCmd.getCurRootObj(User.class).getAdmSpec().getSpec(), filter,
                    attrs, isPublic);
        } else {
            uid = _internal_pquery.put(null, id, resClass, AdmCmd.getCurRootObj(User.class).getAdmSpec().getSpec(), filter, attrs,
                    isPublic, chartType.intValue(), groupByAttrs, groupByDirs, dateSpan.intValue());
        }

        AdmResult retResult = new AdmResult("Saved search \"" + id + "\" successfully", AdmHelperCmd.newAdmBaseId(uid,
                PersistentQuery.class));

        return retResult;
    }
}

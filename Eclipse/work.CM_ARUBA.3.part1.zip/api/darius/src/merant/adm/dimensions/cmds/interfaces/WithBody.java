/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for corporealable commands.
 * <p>
 * This applies to any dimensions object that can be contain a body. This interface was called, Corporealable, but this was
 * considered a bit of a mouthful. In general, this applies to any object that can be browsed.
 * @author Floz
 */
public interface WithBody {
    public static final String BROWSE = "WithBody.Browse";
    public static final String FETCH = "WithBody.Fetch";
    public static final String ANNOTATE = "WithBody.Annotate";
    public static final String EDIT = "WithBody.Edit";
    public static final String UPDATE = "WithBody.Update";
    public static final String GET_CONTENT_TYPE = "WithBody.GetContentType";
    public static final String UPLOAD = "WithBody.Upload";
    public static final String DOWNLOAD = "WithBody.Download";
    public static final String DELIVER = "WithBody.Deliver";
    public static final String UPDATELOCAL = "WithBody.UpdateLocal";
    public static final String MERGE = "WithBody.Merge";
    public static final String SHELVE = "WithBody.Shelve";
}

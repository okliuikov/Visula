/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for deletable commands.
 * <p>
 * This applies to any dimensions object that can be removed from the system.
 * @author Floz
 */
public interface Deletable {
    public static final String DELETE = "Deletable.Delete";
    public static final String UI_DELETE = "Deletable.UiDelete";
    public static final String DELETE_SCHEDULED_JOB = "Deletable.DeleteScheduledJob";
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.auditable;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.ProfileDefinition;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Determines if the specified User has been assigned the specified Profile.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>ProfileDefinition Dimensions object to search for</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>USER {User}</dt><dd>Dimensions user object for the search</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Boolean}</dt><dd>Returns true if the User has the Profile.</dd>
 * </dl></code>
 * @author Sarah Timmons
 */
public class HasProfileCmd extends DBIOCmd {
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ProfileDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    public HasProfileCmd() throws AttrException {
        super();
        setAlias(Auditable.HAS_PROFILE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER, false, AdmCmd.getCurRootObj(User.class), User.class));

        // Add CAPABILITY valid set values
        // getAttrDef(CmdArguments.CAPABILITY).addValidSetValue(Constants.CAP_SECONDARY);
        // getAttrDef(CmdArguments.CAPABILITY).addValidSetValue(Constants.CAP_LEADER);
        // getAttrDef(CmdArguments.CAPABILITY).addValidSetValue(Constants.CAP_PRIMARY);
    }

    public Object generateKey(AdmObject admObj, User user) throws DBIOException, AdmException {
        List ret = new ArrayList();
        ret.add(Constants.HAS_PROFILE_CACHE_KEY);
        ret.add(admObj.getAdmBaseId().toCloneString());
        ret.add(user.getAdmBaseId().toCloneString());
        return ret;
    }

    public Boolean putInCache(Object key, Boolean hasProfile) {
        AdmCmd.getCache().put(key, hasProfile);
        return hasProfile;
    }

    @Override
    public Object execute() throws DBIOException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        User user = (User) getAttrValue(CmdArguments.USER);

        Object key = generateKey(admObj, user);
        if (AdmCmd.getCache().contains(key)) {
            return AdmCmd.getCache().get(key);
        }

        DBIO query = new DBIO(wcm_sql.HAS_PROFILE);
        query.bindInput(user.getAdmSpec().getSpec());
        query.bindInput(AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID));

        query.readStart();
        boolean ret = query.read();
        query.close();

        return putInCache(key, Boolean.valueOf(ret));
    }

    // Given a ProfileDefinition and a scope AdmObject
    // Figures out if the user has that profile
    private boolean hasProfile(AdmObject profileDef, AdmObject admObj, AdmObject user) throws AdmException {
        // Just some inits...
        boolean ret = false;
        Boolean hasProfile = null;
        Hashtable objs = null;
        Hashtable profiles = null;
        AdmObject fromAssignedParent = null;
        AdmObject fromAssignedChild = null;

        // See if contained within user attributes...
        Hashtable userProfiles = (Hashtable) user.getAttrValue(Constants.HAS_PROFILE_CACHE_KEY);
        if (userProfiles != null) {
            objs = (Hashtable) userProfiles.get(user.getId());
            if (objs != null) {
                profiles = (Hashtable) objs.get(admObj.getAdmBaseId().toCloneString());
                if (profiles != null) {
                    hasProfile = (Boolean) profiles.get(profileDef.getId());
                    if (hasProfile != null) {
                        return hasProfile.booleanValue();
                    }
                }
            }
        }

        // Get all the assigned profiles...
        List assignedProfiles = getProfiles(admObj);

        // Return positive if user is found
        for (int i = 0; ((i < assignedProfiles.size()) && (!ret)); i++) {
            fromAssignedParent = AdmHelperCmd.getObject((AdmBaseId) AdmHelperCmd.getAttributeValue(
                    (AdmObject) assignedProfiles.get(i), AdmAttrNames.REL_PARENT));
            fromAssignedChild = AdmHelperCmd.getObject((AdmBaseId) AdmHelperCmd.getAttributeValue(
                    (AdmObject) assignedProfiles.get(i), AdmAttrNames.REL_CHILD));
            if (fromAssignedParent.getId().equals(profileDef.getId()) && fromAssignedChild.getId().equals(user.getId())) {
                ret = true;
            }
        }

        // Update the user attribute...
        if (userProfiles == null) {
            userProfiles = new Hashtable();
            user.setAttrValue(Constants.HAS_PROFILE_CACHE_KEY, userProfiles);
        }

        if (objs == null) {
            objs = new Hashtable();
            userProfiles.put(user.getId(), objs);
        }

        if (profiles == null) {
            profiles = new Hashtable();
            objs.put(admObj.getAdmBaseId().toCloneString(), profiles);
        }

        hasProfile = Boolean.valueOf(ret);
        profiles.put(profileDef.getId(), hasProfile);

        // Now finally return...
        return ret;
    }

    private boolean isReplacement(AdmObject rel, AdmObject scope) throws AdmException {
        if (!(scope instanceof AdmUidObject)) {
            return false;
        }

        long objClass = 11;
        if (scope instanceof ChangeDocument) {
            objClass = 4;
        }

        StringBuffer query = new StringBuffer();
        query.append("SELECT SUBSTR(sa.attr_4, 1, 1) FROM sysobjrel_attributes sa,");
        query.append(" sysobj_rels sr, users_profile up WHERE sr.obj_uid=:I1 AND");
        query.append(" sr.rel_class=:I2 AND sa.attr_1=:I3 AND sr.rel_uid=sa.rel_uid AND");
        query.append(" sr.related_uid=up.user_uid AND up.user_name=:I4");
        String sql = new String(query);
        query = null;

        DBIO dbio = new DBIO(sql);
        dbio.bindInput(((AdmUidObject) scope).getAdmUid().getUid());
        dbio.bindInput(objClass);
        dbio.bindInput(AdmHelperCmd.getAttributeValue(AdmHelperCmd.getObject((AdmBaseId) rel.getAttrValue(AdmAttrNames.REL_CHILD)),
                AdmAttrNames.ID));
        dbio.bindInput(AdmHelperCmd.getAttributeValue(
                AdmHelperCmd.getObject((AdmBaseId) rel.getAttrValue(AdmAttrNames.REL_PARENT)), AdmAttrNames.ID));
        dbio.readStart();

        boolean ret = false;
        if (dbio.read()) {
            ret = dbio.getString(1).equals("Y");
        }

        dbio.close();
        return ret;
    }

    // Given a scope AdmObject
    // returns the list of user profile assignments as
    // Relationship objects
    // TODO - Make this a public command for Show Users And Profiles
    private List getProfiles(AdmObject admObj) throws AdmException {
        // Get the LifeCycle of the scope object
        AdmObject lifeCycle = AdmHelperCmd.getObject(getTheLifecycle(admObj));

        // Get all the ProfileDefinition's off the LifeCycle
        List lifeCycleProfileDefs = AdmHelperCmd.getObjects(getTheProfileDefinitions(lifeCycle));

        // Getting the RELTYPE_UID_DELEGATED RelationshipType object
        AdmObject relTypeDelegated = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_DELEGATED,
                RelationshipType.class));

        // Getting the RELTYPE_UID_REAL RelationshipType object
        AdmObject relTypeReal = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_REAL, RelationshipType.class));

        // Just some inits...
        List ret = new Vector();
        List assignedUsers = null;
        boolean doneOriginator = false;
        boolean getRealAssignments = true;
        AdmObject lifeCycleProfileDef = null;

        // For each of the LifeCycle ProfileDefinition's...
        for (int i = 0; i < lifeCycleProfileDefs.size(); i++) {
            // Just some inits...
            getRealAssignments = true;
            lifeCycleProfileDef = (AdmObject) lifeCycleProfileDefs.get(i);

            // Get the delegated users off the looped ProfileDefinition
            // scoped to the original AdmObject
            assignedUsers = getTheUserAssignments(lifeCycleProfileDef, admObj, relTypeDelegated);

            // Add to the returned list
            ret.addAll(assignedUsers);

            // For each of those Users (actually Relationship's)...
            for (int j = 0; j < assignedUsers.size(); j++) {
                // If NOT a replacement then DONT carry on
                if (!isReplacement((AdmObject) assignedUsers.get(j), admObj)) {
                    getRealAssignments = false;
                }
            }

            if (!getRealAssignments) {
                continue;
            }

            // If looking for the $ORIGINATOR profile and the user
            // is the originator, then we can add a fake assignment
            // with a capability of 'P'
            if (lifeCycleProfileDef.getId().equals(Constants.ORIGINATOR)) {
                doneOriginator = true;
                ret.add(fakeOriginatorRel(admObj, relTypeReal));
                continue;
            }
        }

        if (!doneOriginator) {
            ret.add(fakeOriginatorRel(admObj, relTypeReal));
        }

        return ret;
    }

    // Getting the LifeCycle where admObj is the
    // Baseline, ChangeDocument, or Item
    private AdmBaseId getTheLifecycle(AdmObject admObj) throws AdmException {
        // Issue the command to get the parent
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_PARENT, admObj);
        cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, LifeCycle.class);
        return (AdmBaseId) cmd.execute();
    }

    // Get all the ProfileDefinition's
    private List getTheProfileDefinitions(AdmObject lifeCycle) throws AdmException {
        // Issue the command to get the children
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, lifeCycle);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, ProfileDefinition.class);
        return (List) cmd.execute();
    }

    // Get all the assigned users as relationship objects
    // whom have been delegated the specified profile against
    // the specified scope object for the specified reltype
    private List getTheUserAssignments(AdmObject profileDef, AdmObject admObj, AdmObject relType) throws AdmException {
        // Setting up the new filter
        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(CmdArguments.ADM_REL_TYPE, relType));
        filter.criteria().add(new FilterCriterion(CmdArguments.ADM_SCOPE_OBJECT, admObj));

        // Issue the command to get the children
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, profileDef);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, User.class);
        cmd.setAttrValue(CmdArguments.RELATIONSHIPS, Boolean.TRUE);
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        return (List) cmd.execute();
    }

    // Creates a fake Relationship object to represent the originator,
    // given a ProfileDefinition, scope object and RelationshipType
    private AdmObject fakeOriginatorRel(AdmObject admObj, AdmObject relType) throws AdmException {
        AdmObject rel = new Relationship(AdmHelperCmd.newAdmBaseId(Constants.ORIGINATOR, ProfileDefinition.class),
                AdmHelperCmd.newAdmBaseId((String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ORIGINATOR), User.class));
        rel.setAttrValue(AdmAttrNames.REL_TYPE, relType);
        rel.setAttrValue(AdmAttrNames.REL_CAPABILITY, "P");
        return rel;
    }
}

package merant.adm.dimensions.cmds;

import merant.adm.exception.AdmException;

/**
 * This command calls the Dimensions RPC for getting the Operating System type of the
 * Dimensions Server, rpcGetOSType().
 * <p>
 * This command has no arguments.<br>
 * <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>Integer<dt><dd>Contains an integer representing the type of the remote operating system (as defined in
 *         include\osdep.h): <br>
 *         1(OS_UNIX), 2(OS_VMS), 3(OS_WIN3), 4(OS_WIN4), 5(OS_OS2),
 *         6(OS_NT), 7(OS_MAC), 8(OS_DOS), 9(OS_OS390)</dd>
 * </dl></code>
 * 
 * @author Dharris
 * 
 */
public class RPCGetOSType extends RPCCmd {

    /**
     * Constructs a new RPCGetOSType object
     * 
     */
    public RPCGetOSType() {
        super();
    }

    @Override
    public Object execute() throws AdmException {
        return new Integer(CmdUtils.getUncachedOsType(null));
    }
}

/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimCMRulesException;
import merant.adm.dimensions.exception.DimLcLoopInNormalPathException;
import merant.adm.dimensions.exception.DimLcNoUniqueStateException;
import merant.adm.dimensions.exception.DimLcUnreachableStateException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to generate a normal lifecycle path.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>DBIO_QUERY {DBIO}</dt>
 *  <dd>
 *      Dimensions DBIO query object to be used. This object defines the transactional scope of the operation.
 *      Any exceptions raised by this command must be handled by the caller.
 *  </dd>
 *  <dt>LIFECYCLE_ID {String}</dt><dd>Dimensions lifecycle ID</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADDING_TRANSITION {Boolean}</dt>
 *  <dd>
 *      Specifies whether the normal lifecycle path is to be regenerated while adding a new transition to the lifecycle.
 *      If TRUE, a number of consistency checks can be avoided. Default value - FALSE.
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */

public class _internal_generate_normal_lifecycle extends DBIOCmd {
    public _internal_generate_normal_lifecycle() throws AttrException {
        super();
        setAlias("_internal_generate_normal_lifecycle");
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, true, DBIO.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIFECYCLE_ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADDING_TRANSITION, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.DBIO_QUERY)) {
            if (!(attrValue instanceof DBIO)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        String lifecycleId = (String) getAttrValue(AdmAttrNames.LIFECYCLE_ID);
        boolean addingTransition = ((Boolean) getAttrValue(CmdArguments.ADDING_TRANSITION)).booleanValue();

        generateNormalLifecycle(query, lifecycleId, addingTransition);

        return "Operation Completed";
    }

    /**
     * Regenerates and validates normal lifecycle path after an alteration of the lifecycle
     */
    private void generateNormalLifecycle(DBIO query, String lifecycleId, boolean adding_transition) throws DBIOException,
            DimBaseException, AdmException {

        if (!adding_transition) {
            validateLifecycleUpdate(query, lifecycleId);
        }

        // delete normal lifecycle
        SqlUtils.deleteLCNormalPath(query, lifecycleId);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        // Check CM rules
        long no_norm_states = countNormalStates(query, lifecycleId);

        if (no_norm_states == 0 && countOffNormalStates(query, lifecycleId) == 1) {
            normaliseSingleStateLifecycle(query, lifecycleId);
            no_norm_states = countNormalStates(query, lifecycleId);
        }

        if (no_norm_states == 0) {
            if (isUsedByCMRules(query, lifecycleId)) {
                throw new DimCMRulesException("Error: The new normal lifecycle path is null. "
                        + "This is not allowed since there are change management rules currently using lifecycle +" + lifecycleId);
            }
        } else {
            // number of normal states is greater than 0

            // Generate normal path
            generateNormalPath(query, lifecycleId);

            if (no_norm_states > 1) {
                validateNormalPath(query, lifecycleId);
                validateMissingNormalLinks(query, lifecycleId);
            }
        } // if (no_norm_states == 0)
        validateMissingOffnormalLinks(query, lifecycleId);

        // check CM Phase Rules
        if (!adding_transition) {
            validateCMRulesViolated(query, lifecycleId);
        }

        // Delete Attribute Update Rules and Role Sections that are no longer valid
        if (!adding_transition && isUsedByType(query, lifecycleId)) {
            query.resetMessage(wcm_sql.PM_LC_DELETE_INVALID_ATTR_UPDATE_RULES);
            query.bindInput(lifecycleId);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        }

        // update lifecycle history
        updateLifecycleHistory(query, lifecycleId);
    }

    /**
     * Checks whether a lifecycle update resulted in a consistent lifecycle
     */
    private void validateLifecycleUpdate(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {

        Cmd cmd = AdmCmd.getCmd("_internal_validate_lifecycle_update");
        cmd.setAttrValue(CmdArguments.DBIO_QUERY, query);
        cmd.setAttrValue(AdmAttrNames.LIFECYCLE_ID, lifecycleId);
        cmd.execute();
    }

    /**
     * Returns the number of normal states in a lifecycle
     */
    private long countNormalStates(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        long count = 0;

        query.resetMessage(wcm_sql.LC_COUNT_NORMAL_STATES);
        query.bindInput(lifecycleId);
        query.readStart();

        if (query.read(DBIO.DB_DONT_CLOSE)) {
            count = query.getLong(1);
        }

        query.close(DBIO.DB_DONT_RELEASE);
        return count;
    }

    /**
     * Returns the number of off-normal states in a lifecycle
     */
    private long countOffNormalStates(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        long count = 0;

        query.resetMessage(wcm_sql.LC_COUNT_OFF_NORMAL_STATES);
        query.bindInput(lifecycleId);
        query.readStart();

        if (query.read(DBIO.DB_DONT_CLOSE)) {
            count = query.getLong(1);
        }

        query.close(DBIO.DB_DONT_RELEASE);
        return count;
    }

    /**
     * Checks if the specified lifecycle is assigned to an object type with enabled CM rules
     */
    private boolean isUsedByCMRules(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LC_IS_USED_IN_CM_RULES);

        query.bindInput(lifecycleId);
        query.readStart();
        boolean isUsed = query.read(DBIO.DB_DONT_CLOSE);

        query.close(DBIO.DB_DONT_RELEASE);

        return isUsed;
    }

    /**
     * Generates normal path for a lifecycle attempting to detect loops in lifecycle transitions
     */
    private void generateNormalPath(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        String firstState = getUniqueInitialState(query, lifecycleId);

        if (firstState == null) {
            return;
        }

        int dbType = query.getDBType();
        int queryNo = -1;
        switch (dbType) {
        case DBIO.DBMS_ORACLE:
            queryNo = wcm_sql.LIFECYCLE_GENERATE_NORMAL_PATH_ORACLE;
            break;
        case DBIO.DBMS_MSSQL:
            queryNo = wcm_sql.LIFECYCLE_GENERATE_NORMAL_PATH_MSSQL;
            break;
        case DBIO.DBMS_POSTGRESQL:
            queryNo = wcm_sql.LIFECYCLE_GENERATE_NORMAL_PATH_PSQL;
            break;
        default:
            // DBIO.DBMS_DB2 corresponds to DB/2 v7 for z/OS, and
            // DBIO.DBMS_UDB corresponds to DB/2 UDB, which are unsupported.
            throw new AdmException("Error: unsupported database type " + dbType);
        }

        query.resetMessage(queryNo);
        query.bindInput(lifecycleId);
        query.bindInput(firstState);
        if (dbType != DBIO.DBMS_ORACLE && dbType != DBIO.DBMS_POSTGRESQL) {
            String schemaName = AdmCmd.getCurRootObj(BaseDatabase.class).getId();
            query.bindInput(schemaName, DBIO.DB_ARG_STRING_LITERAL);
        }
        try {
            query.write(DBIO.DB_DONT_COMMIT);
        }
        // attempt to catch ORA-01436 error: "CONNECT BY loop in user data"
        // (or UDB-70001 or MSSQL-50000 user-defined errors)
        catch (DBIOException e) {
            String errorMessage = e.getMessage();
            if (errorMessage.indexOf("ORA-01436") != -1 || errorMessage.indexOf("SQLSTATE=70001") != -1
                    || errorMessage.indexOf("SQLSTATE=50000") != -1 || errorMessage.indexOf("Msg 530, Level 16, State 1") != -1
                    || errorMessage.indexOf("maximum recursion 512 has been exhausted") != -1) {
                throw new DimLcLoopInNormalPathException("Error: The new transition results "
                        + "in a loop in the normal lifecycle path. " + "Please re-declare the transition as off-normal.");
            } else {
                throw e;
            }
        }
    }

    /**
     * Validates the normal lifecycle path by counting unique normal states to go to from each normal state
     */
    private void validateNormalPath(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {

        // first, get a list of all normal states - DBIO does't support opening two recordsets off the same connection
        List normalStates = null;

        query.resetMessage(wcm_sql.LC_QUERY_NORMAL_STATES_FOR_VALIDATION);
        query.bindInput(lifecycleId);
        query.readStart();

        while (query.read(DBIO.DB_DONT_CLOSE)) {
            if (normalStates == null) {
                normalStates = new ArrayList();
            }
            normalStates.add(query.getString(1));
        }
        query.close(DBIO.DB_DONT_RELEASE);

        if (normalStates != null) {
            // query to count unique normal states to go to from each normal state
            query.resetMessage(wcm_sql.LIFECYCLE_CHECK_UNIQUE_NEXT_NORMAL_STATES);
            long counter = 0;

            // now validate each normal state
            for (int i = 0; i < normalStates.size(); i++) {
                String normalState = (String) normalStates.get(i);
                if (normalState == null) {
                    continue;
                }

                query.bindInput(lifecycleId);
                query.bindInput(normalState);

                query.readStart();

                if (query.read(DBIO.DB_DONT_CLOSE)) {
                    counter = query.getLong(1);
                    if (counter > 1 || counter == 0) {
                        throw new DimLcNoUniqueStateException(
                                "Error: Cannot find a unique normal state to go to from the normal state " + normalState);
                    }
                }
            }
        }
    }

    /**
     * Validates the normal lifecycle path by attempting to detect missing normal transitions
     */
    private void validateMissingNormalLinks(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LC_VALIDATE_MISSING_NORMAL_LINKS);
        query.bindInput(lifecycleId);
        query.readStart();

        String badState = null;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            badState = query.getString(1);
        }
        query.close(DBIO.DB_DONT_RELEASE);

        if (badState != null) {
            throw new DimLcUnreachableStateException("Error: There is no normal transition to state " + badState);
        }

    }

    /**
     * Validates the normal lifecycle path by attempting to detect missing off-normal transitions
     */
    private void validateMissingOffnormalLinks(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LC_VALIDATE_MISSING_OFFNORMAL_LINKS);
        query.bindInput(lifecycleId);
        query.readStart();

        String badState = null;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            badState = query.getString(1);
        }
        query.close(DBIO.DB_DONT_RELEASE);

        if (badState != null) {
            throw new DimLcUnreachableStateException("Error: The off-normal state " + badState + " is not reachable");
        }
    }

    /**
     * Validates the normal lifecycles path by detecting CM Phase rule violations
     */
    private void validateCMRulesViolated(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LC_VALIDATE_VIOLATED_CM_RULES);

        query.bindInput(lifecycleId);
        query.readStart();

        boolean areRulesViloated = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        if (areRulesViloated) {
            throw new DimCMRulesException("Error: There are currently change management phase rules "
                    + "based on normal states which have been excluded from the new lifecycle.");
        }
    }

    /**
     * Checks if the specified lifecycle is used by an object type [of specified class].
     */
    private boolean isUsedByType(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LC_IS_USED_BY_ANY_TYPE);
        query.bindInput(lifecycleId);
        query.readStart();

        boolean isUsedByType = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        return isUsedByType;
    }

    private void updateLifecycleHistory(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        String userName = AdmCmd.getCurRootObj(User.class).getId();

        SqlUtils.updateLifecycleHistory(query, lifecycleId, userName);

        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);
    }

    private String getUniqueInitialState(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        String initialState = null;

        query.resetMessage(wcm_sql.LC_GET_UNIQUE_NORMAL_STATE);
        query.bindInput(lifecycleId);
        query.readStart();

        if (!query.read(DBIO.DB_DONT_CLOSE)) {
            query.close(DBIO.DB_DONT_RELEASE);
            throw new DimLcNoUniqueStateException("Error: Cannot find a unique initial state for the normal lifecycle.");
        }

        initialState = query.getString(1);

        if (query.read(DBIO.DB_DONT_CLOSE)) {
            query.close(DBIO.DB_DONT_RELEASE);
            throw new DimLcNoUniqueStateException("Error: There is no unique normal state to go to from the normal state "
                    + initialState);
        }

        return initialState;
    }

    private void normaliseSingleStateLifecycle(DBIO query, String lifecycleId) throws DBIOException, DimBaseException, AdmException {
        query.resetMessage(wcm_sql.LC_NORMALIZE_TRANSITIONS);
        query.bindInput(lifecycleId);
        query.write(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);
    }
}

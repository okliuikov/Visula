/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.serena.dmnet.PcmsShowUsers;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.ShowUsers;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.UserRole;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all UserRoles used by an Item, Chg Doc, Baseline or Part object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT  {AdmObject}</dt><dd>Dimensions primary object
 *  <dt>ADM_CHILD_CLASS  {Class}</dt><dd>Dimensions child object class (UserRole)</dd>
 * </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's</dd>
 * </dl></code>
 * @author Paul Smith
 */
public class QCObjectToPendingUserCmd extends RPCCmd {
    public QCObjectToPendingUserCmd() throws AttrException {
        super();

        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmUidObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_SEC_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_CLASS, true, Class.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ItemFile) && !(attrValue instanceof ChangeDocument) && !(attrValue instanceof Baseline)
                    && !(attrValue instanceof Part) && !(attrValue instanceof WorkSet)) {
                throw new AttrException("QCObjectToUserRoleCmd.validateAttr() Error: Object type is not supported!", attrDef,
                        attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(User.class))) {
                throw new AttrException("QCObjectToUserRoleCmd.validateAttr() Error: Child object type is not supported!", attrDef,
                        attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException {

        try {
            PcmsShowUsers pcmsShowUsers = getSession().getConnection().rpcPcmsGetShowUsers(
                    TypeUtils.getClassInt((Class) getAttrValue(CmdArguments.ADM_OBJECT_CLASS)).intValue(),
                    ((AdmUidObject) getAttrValue(CmdArguments.ADM_OBJECT)).getAdmUid().getUid());

            // List returnValues = new ArrayList();

            return new ShowUsers(pcmsShowUsers);

            /*
             * if (returnValues == null)
             * returnValues = new ArrayList();
             * return returnValues;
             */
        } catch (AttrException e) {
            return null;
        } catch (IOException e2) {
            return null;
        }
    }

    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {

        // ******************************
        // TODO: filtering (+ sorting?)
        // Filter to include pending for users tab and
        // no pending if design part
        // Need to deal with a list of objects coming through?

        List ret = new ArrayList();

        // Dummy data for now until the RPC is put in place
        AdmBaseId userRole1 = AdmHelperCmd.newAdmBaseId("4186062:S:ANALYST", UserRole.class);
        AdmBaseId userRole2 = AdmHelperCmd.newAdmBaseId("4186066:S:REVIEWER", UserRole.class);
        AdmBaseId userRole3 = AdmHelperCmd.newAdmBaseId("13888644:P:DEPLOY-MANAGER", UserRole.class);

        ret.add(userRole1);
        ret.add(userRole2);
        ret.add(userRole3);

        return ret;
    }
}

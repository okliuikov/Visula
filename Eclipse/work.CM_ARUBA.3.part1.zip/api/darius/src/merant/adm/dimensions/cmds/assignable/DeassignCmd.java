/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2004 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.assignable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Group;
import merant.adm.dimensions.objects.ProfileAssignment;
import merant.adm.dimensions.objects.ProfileDefinition;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will deassign a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ROLE {RoleDefinition}<dt><dd>Dimensions role definition object for this assignment removal</dd>
 *  <dt>CAPABILITY {String}<dt><dd>Capability for this assignment removal, S, L or P</dd>
 *  <dd>You must specify one of the following:</dd>
 *  <dt>USER {User}<dt><dd>Dimensions user object for the assignment removal if this is a single user</dd>
 *  <dt>USER_LIST {User/List}<dt><dd>List of Dimensions user objects for the assignment removal</dd>
 *  <dt>USER_LIST_IDS {String/List}<dt><dd>List of ID Strings of Dimensions users for the assignment removal</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Part Id to deassign role from.</dd>
 *  <dt>VARIANT {String}<dt><dd>Part Variant to deassign role from.</dd>
 *  <dt>REAL {Boolean}<dt><dd>If true deassigns role as Real else as Candidate</dd>
 *  <dt>WORKSET {WorkSet}<dt><dd>Deassigning a role to a particular workSet</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @see merant.adm.dimensions.cmds.assignable.AssignCmd
 * @author Floz
 */
public class DeassignCmd extends RPCExecCmd {
    public DeassignCmd() throws AttrException {
        super();
        setAlias(Assignable.DEASSIGN);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VARIANT, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ROLE, true, RoleDefinition.class));
        setAttrDef(new CmdArgDef(CmdArguments.CAPABILITY, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REAL, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_ITEMS, false, null, Boolean.class));
        // Various ways of specifying the users...
        setAttrDef(new CmdArgDef(CmdArguments.USER, false, null, User.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ROLE_ASSIGN_GROUP_UID, false, null, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_LIST, false, null, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_LIST_IDS, false, null, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        Cmd cmd = null;
        AdmObject obj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        if (obj instanceof ProfileAssignment) {
            cmd = DeassignProfileAssignment(obj);
        } else {
            cmd = DeassignRoleAssignment(obj);
        }

        return cmd.execute();
    }

    private Cmd DeassignRoleAssignment(AdmObject obj) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Assignable.ASSIGN, obj);
        cmd.setAttrValue(AdmAttrNames.ID, getAttrValue(AdmAttrNames.ID));
        cmd.setAttrValue(AdmAttrNames.VARIANT, getAttrValue(AdmAttrNames.VARIANT));
        cmd.setAttrValue(CmdArguments.ROLE, getAttrValue(CmdArguments.ROLE));
        cmd.setAttrValue(CmdArguments.CAPABILITY, getAttrValue(CmdArguments.CAPABILITY));
        cmd.setAttrValue(CmdArguments.REAL, getAttrValue(CmdArguments.REAL));
        cmd.setAttrValue(CmdArguments.RELATED_ITEMS, getAttrValue(CmdArguments.RELATED_ITEMS));
        cmd.setAttrValue(CmdArguments.REMOVE, Boolean.TRUE);
        cmd.setAttrValue(CmdArguments.USER, getAttrValue(CmdArguments.USER));
        cmd.setAttrValue(AdmAttrNames.ROLE_ASSIGN_GROUP_UID, getAttrValue(AdmAttrNames.ROLE_ASSIGN_GROUP_UID));
        cmd.setAttrValue(CmdArguments.USER_LIST, getAttrValue(CmdArguments.USER_LIST));
        cmd.setAttrValue(CmdArguments.USER_LIST_IDS, getAttrValue(CmdArguments.USER_LIST_IDS));
        cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
        return cmd;
    }

    private Cmd DeassignProfileAssignment(AdmObject obj) throws AdmException {
        String profile = (String) obj.getAttrValue(AdmAttrNames.PROFILE_ASSIGN_PROFILE);
        String user = (String) obj.getAttrValue(AdmAttrNames.PROFILE_ASSIGN_USERNAME);

        AdmObject profileObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(profile, ProfileDefinition.class));
        AdmObject userObj = null;
        int assign_type = ((Long) AdmCmd.getAttributeValue(obj, AdmAttrNames.PROFILE_ASSIGN_TYPE)).intValue();
        if (assign_type == Constants.USER_CLASS) {
            userObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(user, User.class));
        } else if (assign_type == Constants.GROUP_CLASS) {
            userObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(user, Group.class));
        } else {
            throw new AdmObjectException("Error: profile assign type(" + assign_type + ") for '" + user + "' is not supported!");
        }

        Cmd cmd = AdmCmd.getCmd(Assignable.ASSIGN_PROFILE_DEFINITION, profileObj);
        cmd.setAttrValue(CmdArguments.ADM_PARENT_OBJECT, userObj);
        cmd.setAttrValue(CmdArguments.REMOVE, Boolean.TRUE);
        return cmd;
    }
}

/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ProfileDefinition;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions profile definition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new profile</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PROFILEDEF_DESC {String}<dt><dd>Description for the new profile</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Sarah Timmons
 */
public class CreateProfileCmd extends RPCExecCmd {
    public CreateProfileCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROFILEDEF_DESC, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROFILE_VIEWS, false, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROFILE_OPERATIONS, false, List.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UI_PROFILES")) {
            throw new DimNoPrivilegeException("ADMIN_UI_PROFILES");
        }
        validateAllAttrs();

        final String id = (String) getAttrValue(AdmAttrNames.ID);
        final String desc = (String) getAttrValue(AdmAttrNames.PROFILEDEF_DESC);
        final List viewsList = (List) getAttrValue(AdmAttrNames.PROFILE_VIEWS);
        final List operationsList = (List) getAttrValue(AdmAttrNames.PROFILE_OPERATIONS);

        if (DoesExistHelper.profileExists(id)) {
            throw new DimBaseCmdException("Profile " + id + " already exists!");
        }

        setAttrValue(CmdArguments.INT_SPEC, id);

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws AdmException {

                long profileUid = getNewUid(dbCtx);

                // insert basic profile info
                dbCtx.resetMessage(wcm_sql.PROFILE_CREATE);
                dbCtx.bindInput(profileUid);
                dbCtx.bindInput(id);
                dbCtx.bindInput(desc, String.class);
                dbCtx.bindInput(AdmCmd.getCurRootObj(User.class).getId());
                dbCtx.bindInput(AdmCmd.getCurRootObj(User.class).getId());
                dbCtx.write(DBIO.DB_DONT_COMMIT);

                if (viewsList != null) {
                    Object viewObj;
                    String viewStr;
                    for (int i = 0; i < viewsList.size(); i++) {
                        viewObj = viewsList.get(i);
                        if (viewObj == null || (!(viewObj instanceof String) && !(viewObj instanceof AdmUid)) || "".equals(viewObj)) {
                            continue;
                        }
                        viewStr = viewObj.toString();
                        SqlUtils.profileViewsRelsInsert(dbCtx, profileUid, viewStr);
                        dbCtx.write(DBIO.DB_DONT_COMMIT);
                    }
                }

                if (operationsList != null) {
                    Object opObj;
                    String opStr;
                    for (int i = 0; i < operationsList.size(); i++) {
                        opObj = operationsList.get(i);
                        if (opObj == null || (!(opObj instanceof String) && !(opObj instanceof AdmUid)) || "".equals(opObj)) {
                            continue;
                        }
                        opStr = opObj.toString();
                        SqlUtils.profileOperationsRelsInsert(dbCtx, profileUid, opStr);
                        dbCtx.write(DBIO.DB_DONT_COMMIT);
                    }
                }
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ProfileDefinition.class);
        return retResult;
    }
}

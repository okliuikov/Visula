/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;

import com.serena.dmnet.PcmsPrivilegeRules;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.PrivilegeRules;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will return privilege rule and scope assignment details for a user and object
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRIVILEGE_RULE_PRODUCT {String}<dt><dd>Product name</dd>
 *  <dt>PRIVILEGE_OBJ_TYPE {Integer}<dt><dd>Type of object, change doc, item etc</dd>
 *  <dt>ADM_OBJECT {AdmUidObject}<dt><dd>The object to query privilege rules for.</dd>
 *  <dt>USER {AdmUidObject}<dt><dd>The user to query privilege rules for.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>PrivilegeRules<dt><dd>Contains privilege rule and scope assignment information</dd>
 * </dl></code> Created 02/09/2005.
 * @author Paul Smith
 */

public class RPCPcmsGetPrivilegeRulesCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguements.
     */
    public RPCPcmsGetPrivilegeRulesCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("GetPrivileges");
        AddArgument("cmd", "GetPrivileges");

        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_RULE_PRODUCT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGE_OBJ_TYPE, true, Integer.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmUidObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER, true, User.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.GETPRIVS_DISPLAY_FLAGS, true, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGERULE_SCOPE_PROJECT, false, WorkSet.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGERULE_SCOPE_STAGE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRIVILEGERULE_SCOPE_DEPLOYMENT_AREA, false, String.class));
    }

    @Override
    public Object execute() throws AdmException {

        try {
            long userUid = ((User) getAttrValue(CmdArguments.USER)).getAdmUid().getUid();
            long admObjectUid = ((AdmUidObject) getAttrValue(CmdArguments.ADM_OBJECT)).getAdmUid().getUid();

            long projectUid = -1;
            WorkSet ws = (WorkSet) getAttrValue(AdmAttrNames.PRIVILEGERULE_SCOPE_PROJECT);
            if (ws != null) {
                projectUid = ws.getAdmUid().getUid();
            }

            PcmsPrivilegeRules pcmsPrivilegeRules = getSession().getConnection().rpcPcmsGetPrivilegeRules(
                    (String) getAttrValue(AdmAttrNames.PRIVILEGE_RULE_PRODUCT), projectUid,
                    (String) getAttrValue(AdmAttrNames.PRIVILEGERULE_SCOPE_STAGE),
                    (String) getAttrValue(AdmAttrNames.PRIVILEGERULE_SCOPE_DEPLOYMENT_AREA),
                    ((Integer) getAttrValue(AdmAttrNames.PRIVILEGE_OBJ_TYPE)).intValue(), admObjectUid, userUid,
                    ((Integer) getAttrValue(AdmAttrNames.GETPRIVS_DISPLAY_FLAGS)).intValue());

            return new PrivilegeRules(pcmsPrivilegeRules);

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }

}

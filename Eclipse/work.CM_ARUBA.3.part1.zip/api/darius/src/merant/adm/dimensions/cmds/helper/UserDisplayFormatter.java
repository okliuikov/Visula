package merant.adm.dimensions.cmds.helper;

public interface UserDisplayFormatter {

    String buildUserDisplayName(String userId, String userFullName);

    boolean isUserIdFirst();
}

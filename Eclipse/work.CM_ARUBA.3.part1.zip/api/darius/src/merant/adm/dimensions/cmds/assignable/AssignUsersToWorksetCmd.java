/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015 Serena. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package merant.adm.dimensions.cmds.assignable;

import java.util.List;

import merant.adm.dimensions.cmds.CmdBuilder;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Assignable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;
import merant.adm.framework.AttrDef;

public class AssignUsersToWorksetCmd extends RPCExecCmd {
    public AssignUsersToWorksetCmd() throws AttrException {
        super();
        setAlias(Assignable.ASSIGN_USERS_TO_WORKSET);

        // users
        setAttrDef(new CmdArgDef(CmdArguments.USER_LIST, true, List.class));
        // workset
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, true, String.class));
    }

	@Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.USER_LIST)) {
			@SuppressWarnings("unchecked")
			final List<String> userList = (List<String>) attrValue;
            if (userList.isEmpty()) {
                throw new AttrException("AssignUsersToWorksetCmd Error: User list is empty!", attrDef, attrValue);
            }
        }
    }
	
    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

		@SuppressWarnings("unchecked")
		final List<String> users = (List<String>)getAttrValue(CmdArguments.USER_LIST);
		final String workset = (String)getAttrValue(AdmAttrNames.PROJECT);
		
		_cmdStr = CmdBuilder.create("UWP").addSpecification(workset).addParameter(getFlag()).addParameter("/USERS", users).build();
        return executeRpc();
    }

    protected String getFlag() {
        return "/ADD";
    }
}

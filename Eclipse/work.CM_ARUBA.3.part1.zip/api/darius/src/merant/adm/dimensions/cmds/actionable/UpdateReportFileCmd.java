/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithBody;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will add/import a user report file to the registry of report files.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>USER_FILE{String}<dt><dd>User filename of the report file.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT{AdmObject}<dt>
 *  <dd>
 *      Dimensions User Report File. If this argument is specified, then the reprit file will be imported from the USER_FILE.
 *      If this argument is not specified, then the following arguments will specify the details of a new UserReportFile.
 * </dd>
 *  <dt>ID{String}<dt><dd>File Id</dd>
 *  <dt>REVISION {String}<dt><dd>Report revision</dd>
 *  <dt>URF_EXPORT_FILENAME {String}<dt><dd>Export filename</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class UpdateReportFileCmd extends RPCExecCmd {
    public UpdateReportFileCmd() throws AttrException {
        super();
        setAlias(Actionable.UPDATE_REPORT_FILE);
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REVISION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URF_EXPORT_FILENAME, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((attrValue != null) && !(attrValue instanceof UserReportFile)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPORTMAN")) {
            throw new DimNoPrivilegeException("ADMIN_REPORTMAN");
        }

        validateAllAttrs();

        String fileName = (String) getAttrValue(CmdArguments.USER_FILE);

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        String reportFileId = null;
        String revision = null;
        String exportFilename = null;
        boolean bImport = false;

        if (admObj != null) {
            bImport = true;
            List attrs = AdmHelperCmd.getAttributeValues(admObj,
                    Arrays.asList(new Object[] { AdmAttrNames.ID, AdmAttrNames.REVISION, AdmAttrNames.URF_EXPORT_FILENAME }));

            reportFileId = (String) attrs.get(0);
            revision = (String) attrs.get(1);
            exportFilename = (String) attrs.get(2);
        } else {
            revision = (String) getAttrValue(AdmAttrNames.REVISION);
            reportFileId = (String) getAttrValue(AdmAttrNames.ID);
            exportFilename = (String) getAttrValue(AdmAttrNames.URF_EXPORT_FILENAME);

            // only validate these arguments when creating a new report file revision
            revision = StringUtils.adjustValue(revision, AdmDmLengths.DM_L_REVISION);
            if (revision == null || revision.length() == 0) {
                throw new DimInvalidAttributeException("Error: revision number is not specified.");
            }

            reportFileId = StringUtils.adjustValue(reportFileId, AdmDmLengths.DM_L_REPORT_FILE_ID);
            if (reportFileId == null || reportFileId.length() == 0) {
                throw new DimInvalidAttributeException("Error: file id is not specified.");
            }

            exportFilename = StringUtils.adjustValue(exportFilename, AdmDmLengths.DM_L_FILENAME, false);
            if (exportFilename == null || exportFilename.length() == 0) {
                throw new DimInvalidAttributeException("Error: the export report filename must be specified.");
            }
        }

        // validate arguments
        fileName = StringUtils.adjustValue(fileName, 2000, false);
        if (fileName == null || fileName.length() == 0) {
            throw new DimInvalidAttributeException("Error: the filename the report is to be imported from must be specified.");
        }

        if (!canReadFile(fileName)) {
            throw new DimBaseCmdException("Error: cannot read file " + fileName);
        }

        int objClass = 42;
        int attrNo = 10005;

        DBIO query = null;
        boolean doCommit = true;
        try {
            Object ret = null;
            query = new DBIO(false);
            if (!bImport) {
                // add new report file revision
                ret = doAddNewReportRevision(query, exportFilename, reportFileId, revision, fileName, attrNo, objClass);

            } else {
                // import new file into an existing report revision
                ret = doImportReportRevision(query, reportFileId, revision, fileName, attrNo, objClass);
            }

            return ret;
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }
    }

    private Object doAddNewReportRevision(DBIO query, String exportFilename, String reportFileId, String revision, String fileName,
            int attrNo, int objClass) throws Exception {
        if (reportFileRevisionExists(query, reportFileId, objClass, revision)) {
            throw new DimAlreadyExistsException("Error: Report file " + reportFileId + ";" + revision + " already exists.");
        }

        long fileUid = getNewUid(query);

        Object ret = write_dbfile(false, fileUid, objClass, attrNo, fileName);

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        query.resetMessage(wcm_sql.URF_INSERT);
        query.bindInput(fileUid);
        query.bindInput(reportFileId);
        query.bindInput(objClass);
        query.bindInput(userName);
        query.bindInput(revision);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        query.resetMessage(wcm_sql.URF_INSERT2);
        query.bindInput(fileUid);
        query.bindInput(exportFilename);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        return ret;
    }

    private boolean reportFileRevisionExists(DBIO query, String reportFileId, int objClass, String revision) throws Exception {
        long uid = getReportFileUid(query, reportFileId, objClass, revision);
        return (uid != 0);
    }

    private long getReportFileUid(DBIO query, String reportFileId, int objClass, String revision) throws Exception {
        query.resetMessage(wcm_sql.URF_QUERY_UID);
        query.bindInput(reportFileId);
        query.bindInput(objClass);
        query.bindInput(revision);
        query.readStart();

        long uid = 0;
        if (query.read(DBIO.DB_DONT_CLOSE)) {
            uid = query.getLong(1);
        }
        query.close(DBIO.DB_DONT_RELEASE);
        return uid;
    }

    private Object doImportReportRevision(DBIO query, String templateName, String revision, String fileName, int attrNo,
            int objClass) throws Exception {
        long fileUid = getReportFileUid(query, templateName, objClass, revision);

        if (fileUid == 0) {
            throw new DimAlreadyExistsException("Error: Report file " + templateName + ";" + revision + " does not exist.");
        }

        Object ret = write_dbfile(true, fileUid, objClass, attrNo, fileName);

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        query.resetMessage(wcm_sql.URF_UPDATE_HISTORY);
        query.bindInput(userName);
        query.bindInput(fileUid);
        query.write(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        return ret;
    }

    private boolean isBinary(String filename) throws Exception {
        boolean isText = true;
        try {
            Cmd cmd = AdmCmd.getCmd(WithBody.GET_CONTENT_TYPE);
            cmd.setAttrValue(CmdArguments.FILENAME, filename);
            Boolean ret = (Boolean) cmd.execute();
            if (ret != null) {
                isText = ret.booleanValue();
            }
        } catch (Exception e) {
            Debug.error(e);
        }

        return !isText;
    }

    private Object write_dbfile(boolean update, long fileUid, int objClass, int attrNo,
    // boolean binaryMode,
            String userFilename) throws Exception {

        String oldVer = "0";
        if (update) {
            oldVer = "1";
        }

        // * XDATA has replaced the old DATA command
        StringBuffer buff = new StringBuffer("XDATA \"UPDATE_DBFILE\" /PARAMETER=(");
        buff.append("CLASS=" + objClass + ", ");
        buff.append("ATTR=" + attrNo + ", ");
        buff.append("UID=" + fileUid + ", ");
        buff.append("USER_FILENAME=" + Encoding.escapeDMCLI(userFilename) + ", ");
        buff.append("OLD_FILE_VERSION=" + oldVer + ", ");
        buff.append("NEW_FILE_VERSION=1)");
        _cmdStr = new String(buff);

        return executeRpc();
    }

    private boolean canReadFile(String filename) {
        boolean can = false;
        try {
            File f = new File(filename);
            can = f.canRead();
        } catch (Exception e) {
            Debug.error(e);
        }
        return can;
    }
}
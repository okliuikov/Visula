/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimAttrRuleCopyException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.UpdateRulesObject;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will copy attribute rules of an existing Dimensions object type to
 * the list of attribute rules currently defined for another existing Dimensions object type.
 * <p>
 * Only those rules involving attributes and lifecycle states relevant to the target Dimensions object type will be copied. Any
 * update rules currently defined for the above object type will be deleted before the copy operation is performed. This command is
 * not supported for User object types. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}<dt><dd>Dimensions object type the attribute rules are to be copied from</dd>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object type the attribute rules are to be copied to</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CopyAttributeRulesCmd extends DBIOCmd {

    public CopyAttributeRulesCmd() throws AttrException {
        super();
        setAlias(Actionable.COPY_ATTRIBUTE_RULES);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Type))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if ((!(attrValue instanceof Type))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject toTypeObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        long toTypeUid = ((AdmUidObject) toTypeObj).getAdmUid().getUid();

        List attrs = AdmHelperCmd.getAttributeValues(
                toTypeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS,
                        AdmAttrNames.LIFECYCLE_ID }));

        String toProductName = (String) attrs.get(0);
        String toTypeName = (String) attrs.get(1);
        Class toTypeClass = (Class) attrs.get(2);
        String toLifecycleId = (String) attrs.get(3);
        String toTypeFlag = TypeUtils.getTypeFlag(toTypeClass);

        if (User.class.equals(toTypeClass)) {
            throw new DimInvalidAttributeException("Error: copying attribute rules is not supported for user object types");
        }

        if (!DoesExistHelper.typeExists(toProductName, toTypeName, toTypeFlag)) {
            throw new DimAlreadyExistsException("Error: Dimensions " + TypeUtils.getClassName(toTypeClass) + "Type "
                    + toProductName + ":" + toTypeName + " does not exist");
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", toProductName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", toProductName);
        }

        if (toLifecycleId == null || toLifecycleId.trim().length() == 0) {
            throw new DimInvalidAttributeException("Error: " + TypeUtils.getClassName(toTypeClass) + " Type " + toProductName + ":"
                    + toTypeName
                    + " does not have a lifecycle. Attribute rules are defined in relation to lifecycle roles and states.");
        }

        AdmObject fromTypeObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        long fromTypeUid = ((AdmUidObject) fromTypeObj).getAdmUid().getUid();

        attrs = AdmHelperCmd.getAttributeValues(
                fromTypeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS,
                        AdmAttrNames.LIFECYCLE_ID }));

        String fromProductName = (String) attrs.get(0);
        String fromTypeName = (String) attrs.get(1);
        Class fromTypeClass = (Class) attrs.get(2);
        String fromLifecycleId = (String) attrs.get(3);
        String fromTypeFlag = TypeUtils.getTypeFlag(fromTypeClass);

        if (!DoesExistHelper.typeExists(fromProductName, fromTypeName, fromTypeFlag)) {
            throw new DimAlreadyExistsException("Error: Dimensions " + TypeUtils.getClassName(fromTypeClass) + "Type "
                    + fromProductName + ":" + fromTypeName + " does not exist");
        }

        if (!toTypeClass.equals(fromTypeClass)) {
            throw new DimInvalidAttributeException("Error: Dimensions object types " + fromProductName + ":" + fromTypeName
                    + " and " + toProductName + ":" + toTypeName + " must have the same object class");
        }

        if ((toTypeUid == fromTypeUid) || (toProductName.equalsIgnoreCase(fromProductName) && toTypeName.equals(fromTypeName))) {
            throw new DimInvalidAttributeException("Error: cannot copy attribute rules from Dimensions "
                    + TypeUtils.getClassName(fromTypeClass) + " Type " + fromProductName + ":" + fromTypeName + " to itself");
        }

        if (fromLifecycleId == null || fromLifecycleId.trim().length() == 0) {
            throw new DimInvalidAttributeException("Error: " + TypeUtils.getClassName(fromTypeClass) + " Type " + fromProductName
                    + ":" + fromTypeName
                    + " does not have a lifecycle. Attribute rules are defined in relation to lifecycle roles and states");
        }

        long toRulesObjectUid = getRuleObjectUid(toTypeObj);

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            doCopyAttributeRules(query, toRulesObjectUid, toTypeFlag, toTypeClass, fromTypeUid, fromProductName, fromTypeName,
                    toLifecycleId, toTypeUid);

        }
        // let's be a bit paranoid
        catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return new AdmResult("Operation completed");
    }

    private void doCopyAttributeRules(DBIO query, long toRulesObjectUid, String typeFlag, Class typeClass, long fromTypeUid,
            String fromProductName, String fromTypeName, String toLifecycleId, long toTypeUid) throws Exception {
        query.resetMessage(wcm_sql.ATTRRULE_CHECK_TYPE_HAS_RULES);
        query.bindInput(fromTypeUid);
        query.bindInput(typeFlag);
        query.readStart();
        boolean hasRules = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);
        if (!hasRules) {
            throw new DimAlreadyExistsException("Warning: " + TypeUtils.getClassName(typeClass) + " type " + fromProductName + ":"
                    + fromTypeName + " does not have any attribute rules defined for it.");
        }

        copyObjectAttributeRules(query, typeFlag, fromTypeUid, toLifecycleId, toTypeUid, toRulesObjectUid);
    }

    private long getRuleObjectUid(AdmObject typeObj) throws AdmException {
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, typeObj);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, UpdateRulesObject.class);
        AdmBaseId ruleBaseId = (AdmBaseId) cmd.execute();

        if (ruleBaseId == null) {
            // create rules object
            cmd = AdmCmd.getCmd(Creatable.CREATE, UpdateRulesObject.class);
            cmd.setAttrValue(AdmAttrNames.TYPE, typeObj);
            AdmResult cmdResult = (AdmResult) cmd.execute();
            ruleBaseId = (AdmBaseId) cmdResult.getUserData();
            if (ruleBaseId == null) {
                throw new DBIOException("Error: failed to create attribute update rules object");
            }
        }

        AdmObject rulesObj = AdmHelperCmd.getObject(ruleBaseId, AdmAttrNames.ADM_UID);
        long rulesObjectUid = ((AdmUidObject) rulesObj).getAdmUid().getUid();
        return rulesObjectUid;
    }

    private void copyObjectAttributeRules(DBIO query, String typeFlag, long fromTypeUid, String toLifecycleId, long toTypeUid,
            long toRulesObjectUid) throws Exception {
        String userId = ((User) AdmCmd.getCurRootObj(User.class)).getId();

        SqlUtils.attrruleDeleteRuleDetails(query, toRulesObjectUid);
        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.copyTypeAttrRules(query, typeFlag, fromTypeUid, toLifecycleId, toTypeUid, toRulesObjectUid);
        int rowsAffected = query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);

        if (rowsAffected == 0) {
            throw new DimAttrRuleCopyException(
                    "Warning: no attribute rules relevant to the target object type's attributes and lifecycle states were found in the source object type.");
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will deploy a Dimensions objects to specified area at specified date and time.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_LIST {AdmObject}<dt><dd>List of Dimensions objects</dd>
 *  <dt>WORKSET {String}<dt><dd>Workset name.  If not provided, current workset is taken</dd>
 *  <dt>COMMENT {String}<dt><dd>Comment</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {Boolean}<dt><dd>Whether child requests should be deployed as well</dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author skorneychuk
 */
public class DeployToAreasCmd extends RPCExecCmd {
    private File userFile = null;

    public DeployToAreasCmd() throws AttrException {
        super();
        setAlias(Actionable.DEPLOY_TO_AREAS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));// object to deploy - Item, ChangeDocument or
                                                                                   // Baseline
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, List.class)); // list of objects to deploy - Item,
                                                                                    // ChangeDocument or Baseline
        setAttrDef(new CmdArgDef(CmdArguments.DEPLOY_AREAS, true, List.class)); // list of file area objects
        setAttrDef(new CmdArgDef(CmdArguments.SCHEDULE_DATETIME, false, String.class)); // ISO8601 format in the UTC timezone -
                                                                                        // 'YYYY'-'MM'-'DD'T'HH24':'MI':'SS'.'sss'Z'
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, AdmObject.class)); // workset scope
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class)); // reason for deployment
        // Only used when deploying requests
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue != null && (!(attrValue instanceof Item)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof Baseline))) {
                throw new AttrException("Error: DeployToAreasCmd - object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_OBJECT_LIST)) {
            if (attrValue instanceof List) {
                List list = (List) attrValue;
                Class type = null;
                for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                    Object object = iterator.next();
                    if (object == null) {
                        throw new AttrException("Error: DeployToAreasCmd - null object in the list is not supported!", attrDef,
                                attrValue);
                    }
                    if ((!(object instanceof Item)) && (!(object instanceof ChangeDocument)) && (!(object instanceof Baseline))) {
                        throw new AttrException("Error: DeployToAreasCmd - object type in the list is not supported!", attrDef,
                                object);
                    }
                }
            }
        }

        if (name.equals(CmdArguments.DEPLOY_AREAS)) {
            if (attrValue instanceof List) {
                List list = (List) attrValue;
                if (list.size() == 0) {
                    throw new AttrException("Error: DeployToAreasCmd - empty list of areas to deploy!", attrDef, attrValue);
                }
            } else {
                throw new AttrException("Error: DeployToAreasCmd - no areas specified!", attrDef, attrValue);
            }
        }
    }
    
    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        String obj = executeRpc();
        try {
            if (userFile != null && userFile.exists()) {
                userFile.delete();
            }
        } catch (Exception e) {
            Debug.error(e);
            throw new AdmException(e);
        }

        return obj;
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List<AdmObject> admObjects = (List<AdmObject>) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        List<AdmObject> areas = (List<AdmObject>) getAttrValue(CmdArguments.DEPLOY_AREAS);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        List<String> objectListAsString = new ArrayList<String>();
        Boolean traverseChildRequests = (Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS);
        StringBuffer sb = new StringBuffer();
        boolean useUserFileNameQualifier = false;
        AdmObject tempAdmObj = null;
        if (admObj == null && (admObjects == null || admObjects.size() == 0)) {
            throw new DimMandatoryAttributeException("Error: Object or list of objects must be specified.");
        }
        // We will allow either admObject or list of admObject. Not both.
        if (admObj != null && (admObjects != null && admObjects.size() > 0)) {
            throw new DimMandatoryAttributeException("Error: Please provide either object or list of objects. Not both.");
        }

        if (admObjects != null && admObjects.size() > 1) {
            useUserFileNameQualifier = true;
        }

        if (admObj != null) {
            tempAdmObj = admObj;
        } else {
            tempAdmObj = admObjects.get(0);
        }
        try {
            if (useUserFileNameQualifier) {
                if (admObjects.get(0) instanceof Item || admObjects.get(0) instanceof Baseline
                        || admObjects.get(0) instanceof ChangeDocument) {
                    for (int i = 0; i < admObjects.size(); i++) {
                        objectListAsString.add(admObjects.get(i).getAdmSpec().getSpec());
                    }
                } else {
                    throw new UnsupportedOperationException("The objects selected cannot be deployed. ");
                }
                userFile = preview ? null : PromoteToStageCmd.getUserFile(objectListAsString);
            }

            if (tempAdmObj instanceof Item) {
                sb.append("SDPI ");
            } else if (tempAdmObj instanceof ChangeDocument) {
                sb.append("SDPRQ ");
            } else if (tempAdmObj instanceof Baseline) {
                sb.append("SDPBL ");
            } else {
                throw new UnsupportedOperationException("The object selected cannot be deployed. ");
            }

            if (!useUserFileNameQualifier) {
                sb.append(Encoding.escapeDMCLI(tempAdmObj.getAdmSpec().getSpec()));
            }
            if (areas != null && areas.size() > 0) {
                sb.append(" /AREA_LIST=(");
                String area = "";

                for (int i = 0; i < areas.size(); i++) {
                    area = areas.get(i).getId();
                    if (i > 0) {
                        sb.append(",");
                    }
                    sb.append(Encoding.escapeDMCLI(area));
                }
                sb.append(")");
            }
            if (project != null) {
                sb.append(" /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec()));
            }
            if (comment != null && comment.length() > 0) {
                sb.append(" /COMMENT=" + Encoding.escapeDMCLI(comment));
            }
            if (traverseChildRequests != null) {
                if (traverseChildRequests.booleanValue()) {
                    sb.append(" /NOCANCEL_TRAVERSE");
                } else {
                    sb.append(" /CANCEL_TRAVERSE");
                }
            }

            String scheduled_date = (String) getAttrValue(CmdArguments.SCHEDULE_DATETIME);
            if (scheduled_date != null) {
                sb.append(" /DEPLOY_START_TIME=\"");
                sb.append(scheduled_date);
                sb.append("\"");
            }

            if (useUserFileNameQualifier) {
                sb.append(" /USER_FILENAME="
                        + Encoding.escapeDMCLI(preview ? "selected-objects.listingfile" : userFile.getAbsolutePath()));
            }

            _cmdStr = sb.toString();
        } catch (IOException ioe) {
            throw new AdmException(ioe);
        }
    }

}

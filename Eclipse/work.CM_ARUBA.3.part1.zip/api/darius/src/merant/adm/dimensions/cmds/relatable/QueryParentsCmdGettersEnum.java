/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.serena.dmnet.drs.DRSClientGetParents;
import com.serena.dmnet.drs.DRSClientGetParents.GetParentQueryContext;
import com.serena.dmnet.drs.DRSClientGetParents.GetParentQueryContext.QueryRelTypesFilterMask;
import com.serena.dmnet.drs.DRSClientQueryWorkSetParent;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Archive;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.BaselineCode;
import merant.adm.dimensions.objects.BaselineTemplateRule;
import merant.adm.dimensions.objects.BuildProject;
import merant.adm.dimensions.objects.BuildTarget;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.Group;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Library;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.NetCodeSet;
import merant.adm.dimensions.objects.NetContact;
import merant.adm.dimensions.objects.NetFileSys;
import merant.adm.dimensions.objects.NetInstance;
import merant.adm.dimensions.objects.NetNode;
import merant.adm.dimensions.objects.NetNodeConnection;
import merant.adm.dimensions.objects.NetObject;
import merant.adm.dimensions.objects.NetOpSys;
import merant.adm.dimensions.objects.NetProtocol;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.PrivilegeRule;
import merant.adm.dimensions.objects.PrivilegeRuleScopeAssignment;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.ReplItemMasterConfig;
import merant.adm.dimensions.objects.ReplItemSubordinateConfig;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.RequestProviderDefinition;
import merant.adm.dimensions.objects.SecChangeDocument;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.UploadExclusion;
import merant.adm.dimensions.objects.UploadInclusion;
import merant.adm.dimensions.objects.UploadProject;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.UserReportDefinition;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.QueryConstants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

/**
 * Methods for parent querying mapped by class name and type constant
 */
enum QueryParentsCmdGettersEnum {
    ReplItemSubordinateConfigAdmObject(ReplItemSubordinateConfig.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(ReplItemMasterConfig.class)) {
                String masterReplSpec = admObj.getId() + ";0";
                AdmBaseId baseId = AdmCmd.newAdmBaseId(masterReplSpec, admParentClass);
                qpCmd.addRelation(retBaseIds, false, null, baseId, null);
            }
            return null;
        }

    },
    NetNodeAdmObject(NetNode.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if ((admParentClass.equals(NetContact.class)) || (admParentClass.equals(NetNode.class))
                    || (admParentClass.equals(NetOpSys.class))) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            }
            return null;
        }

    },
    NetObjectAdmObject(NetObject.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if ((admParentClass.equals(NetNode.class)) || (admParentClass.equals(NetProtocol.class))) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            }
            return null;
        }

    },
    CustomerAdmObject(Customer.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(Release.class)) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            }
            return null;
        }

    },
    ReleaseAdmObject(Release.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(Baseline.class)) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            }
            return null;
        }

    },
    ArchiveAdmObject(Archive.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(Baseline.class)) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            }
            return null;
        }

    },
    UserAdmObject(User.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(Group.class)) {
                query = new DBIO(wcm_sql.GET_GROUPS_FROM_USER);
                query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
                query.readStart();
                while (query.read()) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getString(1), admParentClass));
                }
            }
            return null;
        }

    },
    TypeAdmObject(Type.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(Library.class)) {
                Class<?> parentClass = (Class<?>) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
                if (parentClass.equals(Item.class) || parentClass.equals(ItemFile.class)) {
                    String spec = AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME).toString();
                    spec += ":" + AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID).toString();
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(spec, Library.class));
                }
            }
            return null;
        }

    },
    PrivilegeRuleScopeAssignmentAdmObject(PrivilegeRuleScopeAssignment.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(PrivilegeRule.class)) {
                query = new DBIO(wcm_sql.GET_PRIVILEGERULE_FROM_PRIVILEGERULESCOPEASSIGNMENT);
                query.bindInput(AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRIVILEGERULE_SCOPE_UID));
                query.readStart();
                while (query.read()) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getString(1), admParentClass));
                }
            }
            return null;
        }

    },
    PartAdmObject(Part.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(Baseline.class)) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            } else if (admParentClass.equals(Part.class)) {
                DRSClientGetParents pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(),
                        GetParentQueryContext.QueryPartParentPart);
                pg.getValues().setValue(DRSParams.PART_UID, ((AdmUidObject) admObj).getAdmUid().getUid());
                pg.getValues().setValue(DRSParams.QUERY_FILTER_MASK, getPartRelationFilterMask(filter));
                pg.getValues().setValue(DRSParams.STATUS, getStatusFromFilter(filter));

                DRSOutputDataExtractor output = new DRSQuery(pg).execute();
                if (!output.isResultEmpty()) {
                    int[] partUids = output.getIntValues(DRSParams.PART_UIDS);
                    int[] relTypeUids = output.getIntValues(DRSParams.RELTYPE_UIDS);
                    String[] partSpecs = output.getStringValues(DRSParams.PART_SPECS);
                    String[] relTypes = output.getStringValues(DRSParams.RELTYPES_STR);

                    for (int i = 0; i < partUids.length; i++) {
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(
                                partUids[i], admParentClass, null,
                                AdmHelperCmd.newAdmBaseId(partSpecs[i], admParentClass, null, null)),
                                AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(relTypeUids[i], RelationshipType.class, null,
                                        AdmHelperCmd.newAdmBaseId(relTypes[i], RelationshipType.class, null, null))));
                    }
                }
            }
            return null;
        }

    },
    UserReportFileAdmObject(UserReportFile.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(UserReportDefinition.class)) {
                query = new DBIO(wcm_sql.GET_USERREPORTDEFS_FROM_USERREPORTFILE);
                query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
                query.readStart();
                while (query.read()) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getString(1), admParentClass));
                }
            }
            return null;
        }

    },
    NetNodeConnectionAdmObject(NetNodeConnection.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if ((admParentClass.equals(NetCodeSet.class)) || (admParentClass.equals(NetFileSys.class))) {
                List<?> scopeObjects = AdmHelperCmd.getObjects(admObj.getAdmBaseId().getScopeObjects());
                query = new DBIO(getNetNodeConnectionParentSQL(admObj, admParentClass));
                query.bindInput(((AdmUidObject) scopeObjects.get(0)).getAdmUid().getUid());
                query.bindInput(((AdmUidObject) scopeObjects.get(1)).getAdmUid().getUid());
                query.bindInput(((AdmUidObject) scopeObjects.get(2)).getAdmUid().getUid());
                query.readStart();
                while (query.read()) {
                    qpCmd.addRelation(
                            retBaseIds,
                            useRelationships,
                            admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass, null,
                                    AdmHelperCmd.newAdmBaseId(query.getString(2), admParentClass, null, null)));
                }
            }
            return null;
        }

    },
    NetInstanceAdmObject(NetInstance.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(NetNode.class)) {
                query = new DBIO(wcm_sql.GET_NETINSTANCE_NETNODES);
                query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
                query.readStart();
                while (query.read()) {
                    qpCmd.addRelation(
                            retBaseIds,
                            useRelationships,
                            admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass, null,
                                    AdmHelperCmd.newAdmBaseId(query.getString(2), admParentClass, null, null)));
                }
            }
            return null;
        }

    },
    NetBaseDatabaseAdmObject(NetBaseDatabase.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(NetInstance.class)) {
                query = new DBIO(wcm_sql.GET_NETBASEDATABASE_NETINSTANCE);
                query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
                query.readStart();
                while (query.read()) {
                    qpCmd.addRelation(
                            retBaseIds,
                            useRelationships,
                            admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass, null,
                                    AdmHelperCmd.newAdmBaseId(query.getString(2), admParentClass, null, null)));
                }
            }
            return null;
        }

    },
    DimDirectoryAdmObject(DimDirectory.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(DimDirectory.class)) {
                executeGetParentDirDRSInternal(qpCmd, admObj, admParentClass, useRelationships, wset, retBaseIds,
                        GetParentQueryContext.QueryDirParentDir);
            }
            return null;
        }

    },
    BaselineTemplateRuleAdmObject(BaselineTemplateRule.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(BaselineCode.class)) {
                String minStatus = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.BLINETR_MINSTATUS);
                // if min status is one of "*.." special statuses, then baseline code attribute is not applicable
                if (!isValidStatusRule(minStatus)) {
                    query = new DBIO(wcm_sql.GET_BLINETR_PARENT_BLINE_CODE);
                    query.bindInput(AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TEMPLATE_ID));
                    query.bindInput(AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID));
                    query.readStart();
                    while (query.read()) {
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                                AdmHelperCmd.newAdmBaseId(query.getString(2), admParentClass));
                    }
                }
            }
            return null;
        }

    },
    RequestProviderAdmObject(RequestProvider.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(RequestProviderDefinition.class)) {
                query = new DBIO(getRequestProviderParentSQL());
                query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
                query.readStart();
                while (query.read()) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass));
                }
            }
            return null;
        }

    },
    SecChangeDocumentAdmObject(SecChangeDocument.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            return executeGetChangeDocParentInternal(qpCmd, admObj, admParentClass, useRelationships, isPedigree, filter, wset,
                    retBaseIds);
        }

    },
    ChangeDocumentAdmObject(ChangeDocument.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            return executeGetChangeDocParentInternal(qpCmd, admObj, admParentClass, useRelationships, isPedigree, filter, wset,
                    retBaseIds);
        }

    },
    ExternalRequestAdmObject(ExternalRequest.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AdmException {
            return executeGetExternalRequestParentInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
        }

    },
    BaselineAdmObject(Baseline.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if (admParentClass.equals(ChangeDocument.class)
                    || admParentClass.equals(BuildProject.class)
                    || admParentClass.equals(ExternalRequest.class)) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            } else if (admParentClass.equals(Part.class)) {
                AdmUidObject relType = getRelType(filter);
                if ((relType != null) && (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_ANCESTOR)) {
                    // Usually Baselines are considered parents of Parts, however for the purposes of finding a
                    // RELTYPE_UID_ANCESTOR used for attribute displays, we are going to flip this relationship
                    // and return the top part off the Baselines Product, which gives us the additional bonus of
                    // having common code across Baseline, Chdoc and Item objects.
                    Cmd cmd = AdmCmd.getCmd(
                            Relatable.QUERY_CHILD,
                            AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(
                                    (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME), Product.class)));
                    cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Part.class);
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(), (AdmBaseId) cmd.execute());
                }
            } else if (admParentClass.equals(WorkSet.class) || admParentClass.equals(Baseline.class)) {
                DRSClientGetParents pg;
                if (admParentClass.equals(WorkSet.class)) {
                    pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(), GetParentQueryContext.QueryBaselineParentWorkset);
                } else {
                    pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(), GetParentQueryContext.QueryBaselineParentBaseline);
                }
                pg.getValues().setValue(DRSParams.BASELINE_UID, ((AdmUidObject) admObj).getAdmUid().getUid());
                pg.getValues().setValue(DRSParams.QUERY_FILTER_MASK, getBaselineRelationFilterMask(filter));

                DRSOutputDataExtractor output = new DRSQuery(pg).execute();
                if (!output.isResultEmpty()) {
                    int[] parentUids = output.getIntValues(DRSParams.PARENT_UIDS);
                    int[] reltypesInt = output.getIntValues(DRSParams.RELTYPES_INT);
                    String[] reltypesStr = output.getStringValues(DRSParams.RELTYPES_STR);

                    for (int i = 0; i < parentUids.length; i++) {
                        AdmBaseId relTypeId = AdmHelperCmd.newAdmBaseId(reltypesInt[i], RelationshipType.class, null,
                                AdmHelperCmd.newAdmBaseId(reltypesStr[i], RelationshipType.class, null, null));
                        Cmd getObjCmd = AdmCmd.getCmd(Creatable.GET_OBJECT, RelationshipType.class);
                        getObjCmd.setAttrValue(CmdArguments.ADM_BASE_ID, relTypeId);
                        AdmObject relTypeObject = (AdmObject) getObjCmd.execute();

                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                                AdmHelperCmd.newAdmBaseId(parentUids[i], admParentClass), relTypeObject);
                    }
                }

            }
            return null;
        }

    },
    ItemFileAdmObject(ItemFile.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            return executeGetItemParentsInternal(qpCmd, admObj, admParentClass, useRelationships, isPedigree, filter, wset,
                    retBaseIds);
        }

    },
    ItemAdmObject(Item.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            return executeGetItemParentsInternal(qpCmd, admObj, admParentClass, useRelationships, isPedigree, filter, wset,
                    retBaseIds);
        }

    },
    WorkSetAdmObject(WorkSet.class.getSimpleName() + CmdArguments.ADM_OBJECT) {

        private void addRelations(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                Vector<?> retBaseIds) throws AdmException {
            DRSClientQueryWorkSetParent drs = new DRSClientQueryWorkSetParent(DRSUtils.getLCNetClntObject());
            drs.setUid(((AdmUidObject) admObj).getAdmUid().getUid());
            drs.setParentClass(TypeUtils.getClassInt(admParentClass));
            DRSOutputDataExtractor output = new DRSQuery(drs).execute();

            int[] uids = output.getIntValues(DRSParams.PREV_OBJ_UID);
            int[] htypes = output.getIntValues(DRSParams.HISTORY_TYPE);
            String[] hstrtypes = output.getStringValues(DRSParams.HISTORY_TYPE_STR);

            if (uids == null) {
                return;
            }

            for (int i = 0; i < uids.length; i++) {
                AdmBaseId relTypeId = AdmHelperCmd.newAdmBaseId(htypes[i], RelationshipType.class, null,
                        AdmHelperCmd.newAdmBaseId(hstrtypes[i], RelationshipType.class, null, null));
                Cmd getObjCmd = AdmCmd.getCmd(Creatable.GET_OBJECT, RelationshipType.class);
                getObjCmd.setAttrValue(CmdArguments.ADM_BASE_ID, relTypeId);
                AdmObject relTypeObject = (AdmObject) getObjCmd.execute();
                qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(uids[i], admParentClass), relTypeObject);
            }
        }

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            DBIO query;
            if (admParentClass.equals(BuildProject.class)) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            } else if (admParentClass.equals(Baseline.class)) {
                if (filter == null || filter.criteria().isEmpty() || filter.hasAttr(CmdArguments.FILTER_DERIVED)) {
                    addRelations(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
                }
            } else if (admParentClass.equals(WorkSet.class)) {
                if (filter == null || filter.criteria().isEmpty() || filter.hasAttr(CmdArguments.FILTER_DERIVED)) {
                    addRelations(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
                }

                // usage and info the multiple checking for filter == null and whether the filter contains INFO or USAGE allows
                // us to only run one query for all INFO and USAGE related objects and just filtering out the ones
                // we don't want. not very nice logic, but fewer queries
                if (filter == null || filter.criteria().isEmpty() || filter.hasAttr(CmdArguments.FILTER_INFO)
                        || filter.hasAttr(CmdArguments.FILTER_USAGE)) {
                    query = new DBIO(getWorkSetParentWorkSetUsage_InfoSQL());
                    query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
                    query.readStart();
                    while (query.read()) {
                        long relUid = query.getLong(2);
                        if (filter == null || filter.criteria().isEmpty()
                                || (relUid == Constants.RELTYPE_UID_INFO & filter.hasAttr(CmdArguments.FILTER_INFO))
                                || (relUid == Constants.RELTYPE_UID_USAGE & filter.hasAttr(CmdArguments.FILTER_USAGE))) {
                            AdmBaseId relTypeId = AdmHelperCmd.newAdmBaseId(relUid, RelationshipType.class, null,
                                    AdmHelperCmd.newAdmBaseId(query.getString(3), RelationshipType.class, null, null));
                            Cmd getObjCmd = AdmCmd.getCmd(Creatable.GET_OBJECT, RelationshipType.class);
                            getObjCmd.setAttrValue(CmdArguments.ADM_BASE_ID, relTypeId);
                            AdmObject relTypeObject = (AdmObject) getObjCmd.execute();

                            qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                                    AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass), relTypeObject);
                        }
                    }
                }
            }
            return null;
        }

    },
    UserAdmParentClass(User.class.getSimpleName() + CmdArguments.ADM_PARENT_CLASS) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if ((admObj instanceof Baseline) || (admObj instanceof ChangeDocument) || (admObj instanceof Item)) {
                executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
            }
            return null;
        }

    },
    UploadProjectAdmParentClass(UploadProject.class.getSimpleName() + CmdArguments.ADM_PARENT_CLASS) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            if ((admObj instanceof UploadExclusion) || (admObj instanceof UploadInclusion)) {
                String uploadProjId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PRODUCT_NAME);
                String extension = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.EXTENSION);

                if (uploadProjId.equals("0")) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(Constants.GLOBAL_WSET_SPEC + ";" + extension, admParentClass));
                } else {
                    DRSClientGetParents pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(),
                            GetParentQueryContext.QueryUploadProjectFromRule);
                    pg.getValues().setValue(DRSParams.SPEC_UID, Long.valueOf(uploadProjId).longValue());

                    DRSOutputDataExtractor output = new DRSQuery(pg).execute();
                    String[] uploadProjects = null;
                    if (!output.isResultEmpty() && output.isOutputParameterPresent(DRSParams.UPLOAD_PROJECTS_FROM_RULE)) {
                        uploadProjects = output.getStringValues(DRSParams.UPLOAD_PROJECTS_FROM_RULE);
                    }

                    if (uploadProjects != null && uploadProjects.length > 0) {
                        for (int i = 0; i < uploadProjects.length; i++) {
                            qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                                    AdmHelperCmd.newAdmBaseId(uploadProjects[i] + ";" + extension, admParentClass));
                        }
                    }
                }
            }
            return null;
        }

    },
    LifeCycleAdmParentClass(LifeCycle.class.getSimpleName() + CmdArguments.ADM_PARENT_CLASS) {

        @Override
        public Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
                boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
                DimBaseException, AdmObjectException, AdmException {
            String lifeCycleId = null;
            DRSClientGetParents pg = null;
            if (admObj instanceof ChangeDocument) {
                pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(), GetParentQueryContext.GetChDocParentLC);
                pg.getValues().setValue(DRSParams.CHDOC_UID, ((AdmUidObject) admObj).getAdmUid().getUid());
            } else {
                Type type = null;
                if (admObj instanceof Type) {
                    type = (Type) admObj;
                } else {
                    type = (Type) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TYPE);
                }

                String productName = (String) AdmHelperCmd.getAttributeValue(type, AdmAttrNames.PRODUCT_NAME);
                String typeName = (String) AdmHelperCmd.getAttributeValue(type, AdmAttrNames.ID);
                String scope = getScope(admObj);

                pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(), GetParentQueryContext.GetParentLC);
                pg.getValues().setValue(DRSParams.PRODUCT_NAME, productName);
                pg.getValues().setValue(DRSParams.TYPE_NAME, typeName);
                pg.getValues().setValue(DRSParams.SCOPE, scope);
            }

            DRSOutputDataExtractor output = new DRSQuery(pg).execute();
            if (!output.isResultEmpty() && output.isOutputParameterPresent(DRSParams.LC_ID)) {
                lifeCycleId = output.getStringValues(DRSParams.LC_ID)[0];
            }

            if ((lifeCycleId == null) || (lifeCycleId.length() < 1)) {
                throw new AdmException("Unable to find lifecycle.");
            }

            qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                    AdmHelperCmd.newAdmBaseId(lifeCycleId, admParentClass));
            return null;
        }

    };

    private final String abbreviation;
    private static final Map<String, QueryParentsCmdGettersEnum> lookup = new HashMap<String, QueryParentsCmdGettersEnum>();
    static {
        for (QueryParentsCmdGettersEnum getter : QueryParentsCmdGettersEnum.values()) {
            lookup.put(getter.getAbbreviation(), getter);
        }
    }

    private QueryParentsCmdGettersEnum(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public static QueryParentsCmdGettersEnum get(String abbreviation) {
        return lookup.get(abbreviation);
    }

    /**
     * Get parent object
     * @param qpCmd
     * @param admObj
     * @param admParentClass
     * @param useRelationships
     * @param isPedigree
     * @param filter
     * @param wset
     * @param retBaseIds
     * @return null by default in all current cases except query based on ItemFile
     * @throws AttrException
     * @throws DBIOException
     * @throws DimBaseException
     * @throws AdmObjectException
     * @throws AdmException
     */
    public abstract Object getParent(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass, boolean useRelationships,
            boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException, DBIOException,
            DimBaseException, AdmObjectException, AdmException;

    /**
     * Get a mask from filter that is based on presence of special attributes. Applicable for baselines
     * @param filter
     * @return mask
     */
    private static int getBaselineRelationFilterMask(Filter filter) {
        int filterMask = QueryRelTypesFilterMask.NULL_EMPTY.value();
        if (filter != null && !filter.criteria().isEmpty()) {
            for (Iterator<?> iterator = filter.criteria().iterator(); iterator.hasNext();) {
                FilterCriterion criterion = (FilterCriterion) iterator.next();
                if (criterion.getAttrName().equals(CmdArguments.FILTER_DERIVED)) {
                    filterMask |= QueryRelTypesFilterMask.DERIVED.value();
                } else if (criterion.getAttrName().equals(CmdArguments.FILTER_INFO)) {
                    filterMask |= QueryRelTypesFilterMask.INFO.value();
                } else if (criterion.getAttrName().equals(CmdArguments.FILTER_USAGE)) {
                    filterMask |= QueryRelTypesFilterMask.USAGE.value();
                }
            }
        }
        return filterMask;
    }

    /**
     * Get a mask from filter that is based on presence of special attributes. Applicable for parts
     * @param filter
     * @return mask
     * @throws AdmException
     */
    private static int getPartRelationFilterMask(Filter filter) throws AdmException {
        boolean[] relTypes = extractRelTypes(filter, getRelType(filter), true, true);
        int filterMask = QueryRelTypesFilterMask.NULL_EMPTY.value();
        for (int i = 0; i < relTypes.length; i++) {
            if (relTypes[i] && i == 0) {
                filterMask |= QueryRelTypesFilterMask.BREAKDOWN.value();
            } else if (relTypes[i] && i == 1) {
                filterMask |= QueryRelTypesFilterMask.USAGE.value();
            } else if (relTypes[i] && i == 2) {
                filterMask |= QueryRelTypesFilterMask.BREAKDOWN_CLOSED.value();
            } else if (relTypes[i] && i == 3) {
                filterMask |= QueryRelTypesFilterMask.USAGE_CLOSED.value();
            }
        }
        return filterMask;
    }

    /**
     * Get a scope from object or type object
     * @param admObj
     * @return scope
     * @throws DBIOException
     * @throws DimBaseException
     * @throws AdmException
     */
    private static String getScope(AdmObject admObj) throws DBIOException, DimBaseException, AdmException {
        String scope = null;
        if (admObj instanceof Baseline) {
            scope = "B";
        } else if (admObj instanceof ChangeDocument) {
            scope = "C";
        } else if (admObj instanceof Item) {
            scope = "I";
        } else if (admObj instanceof Part) {
            scope = "P";
        } else if (admObj instanceof WorkSet) {
            scope = "W";
        } else if (admObj instanceof Type) {
            Class<?> typeParentClass = (Class<?>) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
            if (typeParentClass.equals(Baseline.class)) {
                scope = "B";
            } else if (typeParentClass.equals(ChangeDocument.class)) {
                scope = "C";
            } else if (typeParentClass.equals(Item.class) || typeParentClass.equals(ItemFile.class)) {
                scope = "I";
            } else if (typeParentClass.equals(Part.class)) {
                scope = "P";
            } else if (typeParentClass.equals(WorkSet.class)) {
                scope = "W";
            } else {
                throw new DBIOException("Invalid type parent class when querying default role section.");
            }
        } else {
            throw new DBIOException("Invalid object type when querying default role section.");
        }
        return scope;
    }

    /**
     * Get relation type from created filter object
     * @param filter
     * @return AdmUidObject as a relation type
     */
    private static AdmUidObject getRelType(Filter filter) {
        AdmUidObject relType = null;
        if (filter != null) {
            Iterator it = filter.criteria().iterator();
            while (it.hasNext()) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (CmdArguments.ADM_REL_TYPE.equals(crit.getAttrName())) {
                    relType = (AdmUidObject) crit.getValue();
                    break;
                }
            }
        }
        return relType;
    }

    /**
     * Get a workset uid
     * @param admObj
     * @param workSet
     * @return AdmUid
     * @throws AdmObjectException
     */
    private static AdmUid getWorksetAdmUid(AdmObject admObj, WorkSet workSet) throws AdmObjectException {
        AdmUid wsetAdmUid = null;
        if (workSet != null) {
            wsetAdmUid = workSet.getAdmUid();
        } else if ((admObj.getAdmBaseId().getScope() != null) && (admObj.getAdmBaseId().getScope() instanceof AdmUid)
                && (admObj.getAdmBaseId().getScope().getObjType().equals(WorkSet.class))) {
            wsetAdmUid = (AdmUid) admObj.getAdmBaseId().getScope();
        } else {
            wsetAdmUid = ((AdmUidObject) DimSystem.getSystem().getSessionBean().getCurRootObj(WorkSet.class)).getAdmUid();
        }

        if (wsetAdmUid == null) {
            wsetAdmUid = (AdmUid) AdmHelperCmd.newAdmBaseId(Constants.GLOBAL_WSET_UID, WorkSet.class);
        }
        return wsetAdmUid;
    }

    /**
     * Get parent for all chdoc types
     * @param qpCmd
     * @param admObj
     * @param admParentClass
     * @param useRelationships
     * @param isPedigree
     * @param filter
     * @param wset
     * @param retBaseIds
     * @return always null
     * @throws AttrException
     * @throws DimBaseException
     * @throws AdmException
     */
    protected Object executeGetChangeDocParentInternal(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass,
            boolean useRelationships, boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AttrException,
            DimBaseException, AdmException {
        DBIO query;
        if (admParentClass.equals(ChangeDocument.class)) {
            // Fix for DEF208103: Use SuperQuery to query for parent's so filter is supported.
            QueryRelsCmd.queryRelations(QueryConstants.CHILD, retBaseIds, admObj, admParentClass,
                    QueryRelsCmd.staticBaseUid(admObj, admParentClass, (WorkSet) qpCmd.getAttrValue(CmdArguments.WORKSET)), false,
                    false, (FilterImpl) qpCmd.getAttrValue(CmdArguments.FILTER), useRelationships, false, false, true);
        } else if (admParentClass.equals(Part.class)) {
            AdmUidObject relType = getRelType(filter);
            if ((relType != null) && (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_ANCESTOR)) {
                DRSClientGetParents drs = new DRSClientGetParents(DRSUtils.getLCNetClntObject(),
                        GetParentQueryContext.QueryParentPathesForParts);
                drs.getValues().setValue(DRSParams.REQUEST_UID, ((AdmUidObject) admObj).getAdmUid().getUid());
                DRSOutputDataExtractor output = new DRSQuery(drs).execute();
                if (!output.isResultEmpty()) {
                    int parentUid = output.getIntValues(DRSParams.PARENT_UID)[0];
                    if (parentUid != Constants.INVALID_UID) {
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(), new AdmUid(parentUid, Part.class),
                                relType);
                    } else {
                        throw new DRSException("Unable to find common part related to the request!");
                    }
                }
            } else {
                query = new DBIO(getChangeDocumentParentPartsSQL());
                query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
                query.readStart();
                while (query.read()) {
                    if (!useRelationships) {
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                                AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass));
                    } else {
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                                AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass),
                                AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getLong(2), RelationshipType.class)));
                    }
                }

            }
        } else if (admParentClass.equals(WorkSet.class)) {
            query = new DBIO(wcm_sql.QUERY_PARENT_WORKSETS);
            query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
            query.readStart();
            while (query.read()) {
                if (!useRelationships) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass));
                } else {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass),
                            AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getLong(2), RelationshipType.class)));
                }
            }
        }
        return null;
    }

    /**
     * Get parent for externalrequest type, currently supports Workset parent only
     * @param qpCmd
     * @param admObj
     * @param admParentClass
     * @param useRelationships
     * @param retBaseIds
     * @return always null
     * @throws AttrException
     * @throws DimBaseException
     * @throws AdmException
     */
    protected Object executeGetExternalRequestParentInternal(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass,
                                                       boolean useRelationships, Vector<?> retBaseIds) throws AttrException,
            DimBaseException, AdmException {
        DBIO query;
        if (admParentClass.equals(WorkSet.class)) {
            query = new DBIO(wcm_sql.QUERY_PARENT_WORKSETS_EXT);
            query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
            query.readStart();
            while (query.read()) {
                if (!useRelationships) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass));
                } else {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass),
                            AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getLong(2), RelationshipType.class)));
                }
            }
        }
        return null;
    }

    /**
     * Get parent both for Item and ItemFile
     * @param qpCmd
     * @param admObj
     * @param admParentClass
     * @param useRelationships
     * @param isPedigree
     * @param filter
     * @param wset
     * @param retBaseIds
     * @return null or parents if that is isPedigree query only
     * @throws AdmException
     */
    protected Object executeGetItemParentsInternal(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass,
            boolean useRelationships, boolean isPedigree, Filter filter, WorkSet wset, Vector<?> retBaseIds) throws AdmException {
        DBIO query;
        if (admParentClass.equals(Archive.class) || admParentClass.equals(BuildTarget.class)
                || admParentClass.equals(ChangeDocument.class) || admParentClass.equals(ExternalRequest.class)
                || admParentClass.equals(Stage.class) || admParentClass.equals(Baseline.class)
                || admParentClass.equals(Release.class) || admParentClass.equals(WorkSet.class)) {
            executeQueryChildrenCmdInternal(qpCmd, admObj, admParentClass, useRelationships, retBaseIds);
        } else if (admParentClass.equals(DimDirectory.class)) {
            executeGetParentDirDRSInternal(qpCmd, admObj, admParentClass, useRelationships, wset, retBaseIds,
                    GetParentQueryContext.QueryItemParentDir);
        } else if (admParentClass.equals(Item.class) || admParentClass.equals(ItemFile.class)) {
            if (isPedigree) {
                Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_RELS, admObj);
                cmd.setAttrValue(CmdArguments.ADM_PARENT_CLASS, admParentClass);
                cmd.setAttrValue(CmdArguments.FILTER, qpCmd.getAttrValue(CmdArguments.FILTER));
                cmd.setAttrValue(CmdArguments.RELATIONSHIPS, qpCmd.getAttrValue(CmdArguments.RELATIONSHIPS));
                cmd.setAttrValue(CmdArguments.WORKSET, qpCmd.getAttrValue(CmdArguments.WORKSET));
                cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, Boolean.TRUE);
                return cmd.execute();
            }
            query = new DBIO(getItemParentItemSQL());
            query.bindInput(((AdmUidObject) admObj).getAdmUid().getUid());
            query.readStart();
            while (query.read()) {
                if (!useRelationships) {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass));
                } else {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(query.getLong(1), admParentClass),
                            new RelationshipType(AdmHelperCmd.newAdmBaseId(query.getLong(2), RelationshipType.class)));
                }
            }
        } else if (admParentClass.equals(Part.class)) {
            DRSClientGetParents pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(),
                    GetParentQueryContext.QueryItemParentPart);
            pg.getValues().setValue(DRSParams.ITEM_UID, ((AdmUidObject) admObj).getAdmUid().getUid());
            pg.getValues().setValue(DRSParams.QUERY_FILTER_MASK, getPartRelationFilterMask(filter));

            DRSOutputDataExtractor output = new DRSQuery(pg).execute();
            if (!output.isResultEmpty()) {
                int[] partUids = output.getIntValues(DRSParams.PART_UIDS);
                int[] relTypes = output.getIntValues(DRSParams.RELTYPES_INT);
                String[] partSpecs = output.getStringValues(DRSParams.PART_SPECS);
                for (int i = 0; i < partUids.length; i++) {
                    if (!useRelationships) {
                        qpCmd.addRelation(
                                retBaseIds,
                                useRelationships,
                                admObj.getAdmBaseId(),
                                AdmHelperCmd.newAdmBaseId(partUids[i], admParentClass, null,
                                        AdmHelperCmd.newAdmBaseId(partSpecs[i], admParentClass, null, null)));
                    } else {
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(), AdmHelperCmd.newAdmBaseId(
                                partUids[i], admParentClass, null,
                                AdmHelperCmd.newAdmBaseId(partSpecs[i], admParentClass, null, null)), new RelationshipType(
                                AdmHelperCmd.newAdmBaseId(relTypes[i], RelationshipType.class)));
                    }
                }
            }
        }
        return null;
    }

    /**
     * Getter of parent dirs for items and dirs objects
     * @param qpCmd
     * @param admObj
     * @param admParentClass
     * @param useRelationships
     * @param wset
     * @param retBaseIds
     * @param queryBuilder
     * @throws AdmObjectException
     * @throws AdmException
     */
    private static void executeGetParentDirDRSInternal(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass,
            boolean useRelationships, WorkSet wset, Vector<?> retBaseIds, GetParentQueryContext queryBuilder)
            throws AdmObjectException, AdmException {
        AdmUid wsetAdmUid = getWorksetAdmUid(admObj, wset);
        DRSClientGetParents pg = new DRSClientGetParents(DRSUtils.getLCNetClntObject(), queryBuilder);
        pg.getValues().setValue(DRSParams.UID, ((AdmUidObject) admObj).getAdmUid().getUid());
        pg.getValues().setValue(DRSParams.WSET_UID, wsetAdmUid.getUid());

        DRSOutputDataExtractor output = new DRSQuery(pg).execute();
        if (!output.isResultEmpty()) {
            int[] dirUids = output.getIntValues(DRSParams.DIR_UIDS);
            String[] dirPaths = output.getStringValues(DRSParams.DIR_PATHES);
            for (int i = 0; i < dirPaths.length; i++) {
                String dirname = dirPaths[i];
                if (dirname == null || dirname.length() < 1 || dirname.charAt(0) == ' ') {
                    dirname = new Character(Constants.DIRPATH_SEP).toString();
                }
                qpCmd.addRelation(
                        retBaseIds,
                        useRelationships,
                        admObj.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(dirUids[i], admParentClass, wsetAdmUid,
                                AdmHelperCmd.newAdmBaseId(dirname, admParentClass, null, null)));
            }
        }
    }

    /**
     * Query based on QUERY_CHILDREN cmd
     * 
     * @param qpCmd
     * @param admObj
     * @param admParentClass
     * @param useRelationships
     * @param retBaseIds
     * @throws AdmException
     */
    private static void executeQueryChildrenCmdInternal(QueryParentsCmd qpCmd, AdmObject admObj, Class<?> admParentClass,
            boolean useRelationships, Vector<?> retBaseIds) throws AdmException {
        Cmd cmd;
        if (admObj instanceof Item && admParentClass.equals(BuildTarget.class)) {
            cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, AdmCmd.getCurRootObj(WorkSet.class), admParentClass);
            Filter customFilter = new FilterImpl(new FilterCriterion(CmdArguments.ADM_OBJECT_LIST, Arrays.asList(admObj)));
            cmd.setAttrValue(CmdArguments.FILTER, customFilter);
        } else {
            cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admObj);
            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, admParentClass);
            cmd.setAttrValue(CmdArguments.FILTER, qpCmd.getAttrValue(CmdArguments.FILTER));
        }

        if (!(admObj instanceof NetObject) && !(admObj instanceof NetNode) && !(admObj instanceof Archive)) {
            if (admObj instanceof Item && qpCmd.getAttrValue(CmdArguments.WORKSET) == null) {
                cmd.setAttrValue(CmdArguments.WORKSET, AdmCmd.getCurRootObj(WorkSet.class));
            } else {
                cmd.setAttrValue(CmdArguments.WORKSET, qpCmd.getAttrValue(CmdArguments.WORKSET));
            }
            cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, qpCmd.getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE));
        }

        if (admObj instanceof Part || admObj instanceof Baseline || admObj instanceof Item) {
            cmd.setAttrValue(CmdArguments.RELATIONSHIPS, qpCmd.getAttrValue(CmdArguments.RELATIONSHIPS));
        }

        List<?> baseIds = (List<?>) cmd.execute();
        if (baseIds != null) {
            for (int i = 0; i < baseIds.size(); i++) {
                if (admObj instanceof Part || admObj instanceof Baseline || admObj instanceof Item) {
                    if (!useRelationships) {
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(), (AdmBaseId) baseIds.get(i));
                    } else {
                        AdmObject relType = (AdmObject) (((Relationship) baseIds.get(i)).getAttrValue(AdmAttrNames.REL_TYPE));
                        AdmBaseId relBaseId = null;
                        if (admObj instanceof Part) {
                            relBaseId = (AdmBaseId) ((Relationship) baseIds.get(i)).getAttrValue(AdmAttrNames.REL_PARENT);
                        } else if (admObj instanceof Baseline || admObj instanceof Item) {
                            relBaseId = (AdmBaseId) ((Relationship) baseIds.get(i)).getAttrValue(AdmAttrNames.REL_CHILD);
                        }
                        qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(), relBaseId, relType);
                    }
                } else {
                    qpCmd.addRelation(retBaseIds, useRelationships, admObj.getAdmBaseId(), (AdmBaseId) baseIds.get(i));
                }
            }
        }
    }

    private static String getChangeDocumentParentPartsSQL() {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT affect_uid, reltype_uid FROM cm_impacts");
        sql.append(" WHERE ch_uid = :I1 AND impact_type = 'P'");
        String query = sql.toString();
        sql = null;
        return query;
    }

    private static String getItemParentItemSQL() {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT distinct sysobj_rels.obj_uid, cpl_attributes.obj_uid, cpl_attributes.attr_1 FROM sysobj_rels, sysobjrel_attributes, cpl_attributes WHERE rel_class = 9 AND related_uid = :I1 and sysobj_rels.rel_uid = sysobjrel_attributes.rel_uid and to_char(cpl_attributes.obj_uid) = sysobjrel_attributes.attr_2");
        String query = sql.toString();
        sql = null;
        return query;
    }

    // Returns four boolean's...
    // [0]==IsBreakdown, [1]==IsUsage
    // [2]==IsBreakdownClosed, [3]==IsUsageClosed
    private static boolean[] extractRelTypes(Filter filter, AdmUidObject relType, boolean default_breakdown, boolean default_usage)
            throws AdmException {
        boolean breakdown = default_breakdown;
        boolean usage = default_usage;
        boolean breakdownClosed = true;
        boolean usageClosed = true;

        if (filter != null) {
            // Should only be used for the legacy Item->Part
            Iterator it = filter.criteria().iterator();
            while (it.hasNext()) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (AdmAttrNames.RELTYPE_IS_BREAKDOWN.equals(crit.getAttrName())) {
                    breakdown = ((Boolean) crit.getValue()).booleanValue();
                } else if (AdmAttrNames.RELTYPE_IS_USAGE.equals(crit.getAttrName())) {
                    usage = ((Boolean) crit.getValue()).booleanValue();
                }
            }

            if ((!default_breakdown) || (!default_usage)) {
                if (usage && breakdown) {
                    breakdown = false;
                }
            }
        }

        if (relType != null) {
            breakdown = false;
            usage = false;
            breakdownClosed = false;
            usageClosed = false;

            if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_ANCESTOR) {
                breakdown = true;
            } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_OWNED) {
                breakdown = true;
            } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_USAGE) {
                usage = true;
            } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_OWNED_CLOSED) {
                breakdownClosed = true;
            } else if (relType.getAdmUid().getUid() == Constants.RELTYPE_UID_USAGE_CLOSED) {
                usageClosed = true;
            }
        }

        boolean[] ret = new boolean[4];
        ret[0] = breakdown;
        ret[1] = usage;
        ret[2] = breakdownClosed;
        ret[3] = usageClosed;
        return ret;
    }

    private static String getStatusFromFilter(Filter filter) {
        String status = "";
        if (filter != null) {
            Iterator it = filter.criteria().iterator();
            while (it.hasNext()) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (AdmAttrNames.STATUS.equals(crit.getAttrName())) {
                    status = (String) crit.getValue();
                    break;
                }
            }
        }
        return status;
    }

    private static String getNetNodeConnectionParentSQL(AdmObject admObj, Class admParentClass) {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT p.");
        if (admParentClass.equals(NetCodeSet.class)) {
            sql.append("i_codeset_uid, TO_CHAR(p.i_codeset_number)");
        } else if (admParentClass.equals(NetFileSys.class)) {
            sql.append("i_filesystem_uid, p.s_name");
        }

        sql.append(" FROM pcms_sys.");
        if (admParentClass.equals(NetCodeSet.class)) {
            sql.append("admsys_codesets");
        } else if (admParentClass.equals(NetFileSys.class)) {
            sql.append("admsys_filesystems");
        }

        sql.append(" p, pcms_sys.admsys_nodeconnections c WHERE");
        sql.append(" c.i_server_networknode_uid=:I1 AND");
        sql.append(" c.i_client_networknode_uid=:I2 AND");
        sql.append(" c.i_networkobject_uid=:I3 AND p.");
        if (admParentClass.equals(NetCodeSet.class)) {
            sql.append("i_codeset_uid = c.i_codeset_uid");
        } else if (admParentClass.equals(NetFileSys.class)) {
            sql.append("i_filesystem_uid = c.i_filesystem_uid");
        }

        String query = sql.toString();
        sql = null;
        return query;
    }

    public static boolean isValidStatusRule(String status) {
        if (Constants.BLINETR_MINSTATUS_ALL.equals(status) || Constants.BLINETR_MINSTATUS_BUILT.equals(status)
                || Constants.BLINETR_MINSTATUS_FINAL.equals(status) || Constants.BLINETR_MINSTATUS_HIGHEST.equals(status)
                || Constants.BLINETR_MINSTATUS_LATEST.equals(status) || Constants.BLINETR_MINSTATUS_MADE_OF.equals(status)) {
            return true;
        }
        return false;
    }

    private static String getWorkSetParentWorkSetUsage_InfoSQL() {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT obj_uid, reltype_uid, DECODE(reltype_uid, 2,'Usage',64,'Info','Unknown') FROM ws_rels");
        sql.append(" WHERE related_uid = :I1 AND rel_class=3");
        String query = sql.toString();
        sql = null;
        return query;
    }

    private static String getRequestProviderParentSQL() {
        StringBuffer sql = new StringBuffer();
        sql.append("select t1.TOOL_SPEC_UID from  EXT_TOOL_SPEC_CATALOGUE t1, EXT_TOOL_CATALOGUE t2 ");
        sql.append("where t1.TOOL_SPEC_UID = t2.TOOL_SPEC_UID and t2.tool_uid = :I1");
        return sql.toString();
    }

}
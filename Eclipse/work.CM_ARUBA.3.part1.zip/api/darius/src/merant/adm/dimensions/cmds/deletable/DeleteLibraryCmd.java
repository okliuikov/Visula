/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Library;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Library object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteLibraryCmd extends RPCExecCmd {
    public DeleteLibraryCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Library)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // take precautions not to overwrite "*" - if we wanted to delete the default library
        String typeName = (String) admObj.getAttrValue(AdmAttrNames.ID);
        if (typeName == null) {
            typeName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ID);
        }

        List attrs = AdmHelperCmd.getAttributeValues(
                admObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.LIBRARY_IS_DEFAULT,
                        AdmAttrNames.LIBRARY_IS_DELTA }));

        String productName = (String) attrs.get(0);
        Boolean isDefault = (Boolean) attrs.get(1);
        Boolean isDelta = (Boolean) attrs.get(2);

        Cmd cmd = AdmCmd.getCmd(Creatable.CREATE, Library.class);
        cmd.setAttrValue(AdmAttrNames.PRODUCT_NAME, productName);
        cmd.setAttrValue(AdmAttrNames.ID, typeName);
        cmd.setAttrValue(AdmAttrNames.LIBRARY_IS_DEFAULT, isDefault);
        cmd.setAttrValue(AdmAttrNames.LIBRARY_IS_DELTA, isDelta);

        cmd.setAttrValue(AdmAttrNames.LIBRARY_PATH, AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.LIBRARY_PATH));
        cmd.setAttrValue(AdmAttrNames.LIBRARY_NODE_NAME, AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.LIBRARY_NODE_NAME));

        cmd.setAttrValue(CmdArguments.REMOVE, Boolean.TRUE);

        cmd.execute();

        return "Operation completed";
    }
}

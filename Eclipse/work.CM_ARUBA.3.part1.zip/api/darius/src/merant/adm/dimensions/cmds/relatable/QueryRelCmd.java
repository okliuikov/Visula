/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries a single object related to the primary object.
 * <p>
 * Where the natural direction of the relationship is clear, then CmdArguments.ADM_SEC_CLASS can be used. Otherwise use
 * ADM_CHILD_CLASS and ADM_PARENT_CLASS for direction. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PARENT_RELATIVE {Boolean}</dt><dd>If true, enforces the return of parent relations</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>MULTIPLE {Boolean}</dt><dd>Used for multiple edit attribute operations</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns a Relationship rather than an AdmBaseId</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 *  <dt>RELTYPE_IS_PEDIGREE {Boolean}<dt><dd>If true, returns pedigree object relationship</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmBaseId/Relationship}</dt><dd>AdmBaseId or Relationship representing the secondary object</dd>
 * </dl></code>
 * @author Floz
 */
public class QueryRelCmd extends AdmCmd {
    public QueryRelCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_REL);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_SEC_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARENT_RELATIVE, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(CmdArguments.MULTIPLE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATIONSHIPS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_DEFAULT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_PEDIGREE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_RELS, getAttrValue(CmdArguments.ADM_OBJECT));
        cmd.setAttrValue(CmdArguments.ADM_SEC_CLASS, getAttrValue(CmdArguments.ADM_SEC_CLASS));
        cmd.setAttrValue(CmdArguments.PARENT_RELATIVE, getAttrValue(CmdArguments.PARENT_RELATIVE));
        cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
        cmd.setAttrValue(CmdArguments.MULTIPLE, getAttrValue(CmdArguments.MULTIPLE));
        cmd.setAttrValue(CmdArguments.RELATIONSHIPS, getAttrValue(CmdArguments.RELATIONSHIPS));
        cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
        cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT, getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT));
        cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE));

        List rels = (List) cmd.execute();
        if ((rels == null) || (rels.size() == 0)) {
            return null;
        }

        return rels.get(0);
    }
}

/*
 * Copyright (C) 2001-2004, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkingCMList;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate/unrelate requests to/from a CM activated request list.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_PARENT_OBJECT {CMActivatedList}<dt><dd>CMActivatedList object</dd>
 *  <dt>ADM_OBJECT_LIST {ChangeDocument/List}<dt><dd>List of Dimensions ChangeDocument objects for the assignment</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class RelateChangeDocumentToWorkingCMListCmd extends DBIOCmd {
    public RelateChangeDocumentToWorkingCMListCmd() throws AttrException {
        super();
        setAlias("RelateChangeDocumentToWorkingCMListCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, WorkingCMList.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof WorkingCMList)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        validateAllAttrs();

        // Dimensions request list
        final AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        // Dimensions requests
        final List requests = (List) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        final boolean bUnrelate = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        List attrs = AdmHelperCmd.getAttributeValues(admObj,
                Arrays.asList(new Object[] { AdmAttrNames.USER_NAME, AdmAttrNames.ID }));

        final String userName = (String) attrs.get(0);
        final String id = (String) attrs.get(1);

        AdmObject curUserObj = AdmCmd.getCurRootObj(User.class);
        if (curUserObj != null) {
            String curUserId = curUserObj.getAdmSpec().getSpec();
            if (!curUserId.equals(userName)) {
                // Ensure that we have the privilege to do this
                if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_CHANGEMAN")) {
                    throw new DimNoPrivilegeException("ADMIN_CHANGEMAN");
                }
            }
        }

        StringBuffer warnings = new StringBuffer();
        final long userListUid = ((AdmUidObject) admObj).getUid();
        for (int i = 0; i < requests.size(); i++) {
            AdmObject request = (AdmObject) requests.get(i);
            if (request != null && request instanceof ChangeDocument) {
                try {
                    final String requestId = request.getId();

                    // Check the request exists...
                    if (!DoesExistHelper.changeDocumentExists(requestId)) {
                        throw new DimNotExistsException("\nWarning: Request \"" + requestId + "\" does not exist.");
                    }

                    final long requestUid = ((AdmUidObject) request).getUid();
                    if (bUnrelate) // Check the request is in the request list...
                    {
                        if (!DoesExistHelper.userListContainChangeDocumentExists(userListUid, requestUid)) {
                            throw new DimNotExistsException("Request \"" + requestId + "\" does not exist in request list \""
                                    + admObj.getAdmSpec().getSpec() + "\".");
                        }
                    } else {
                        // Check if the request exists in the request list...
                        if (DoesExistHelper.userListContainChangeDocumentExists(userListUid, requestUid)) {
                            throw new DimAlreadyExistsException("\nWarning: Request \"" + requestId
                                    + "\" already exists in request list \"" + admObj.getAdmSpec().getSpec() + "\".");
                        }
                    }

                    new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
                        @Override
                        public void execute(DBIO dbCtx) throws Exception {

                            if (!bUnrelate) {

                                dbCtx.resetMessage(wcm_sql.ADD_TO_WORKING_CM_LIST);
                                dbCtx.bindInput(userListUid);
                                dbCtx.bindInput(requestUid);
                                dbCtx.bindInput(userName);
                                int affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                                dbCtx.close(DBIO.DB_DONT_RELEASE);

                                if (affected != 1) {
                                    throw new DBIOException("Failed to add request \"" + requestId + "\" to request list \""
                                            + userName + ":" + id + "\".");
                                }
                            } else {
                                dbCtx.resetMessage(wcm_sql.REMOVE_FROM_WORKING_CM_LIST);
                                dbCtx.bindInput(id);
                                dbCtx.bindInput(userName);
                                dbCtx.bindInput(requestUid);
                                int affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                                dbCtx.close(DBIO.DB_DONT_RELEASE);

                                if (affected != 1) {
                                    throw new DBIOException("Failed to remove request \"" + requestId + "\" from request list \""
                                            + userName + ":" + id + "\".");
                                }
                            }
                        }
                    });
                } catch (DimNotExistsException e) {
                    warnings.append(e.getMessage());
                } catch (DimAlreadyExistsException e) {
                    warnings.append(e.getMessage());
                }
            }
        }
        warnings.insert(0, "Operation completed ");
        return new AdmResult(warnings.toString());
    }
}

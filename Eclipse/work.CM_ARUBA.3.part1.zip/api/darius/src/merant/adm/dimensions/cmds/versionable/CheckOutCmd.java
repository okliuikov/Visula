/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.serena.dmfile.FilePath;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Check Out for a Dimensions object.
 * <p>
 * Uses RPCExecCmd to check-out file via the message server.<br>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename of the object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILENAME {String}<dt><dd>Specifies the name of the workset or baseline filename</dd>
 *  <dt>BASELINE {Baseline}<dt><dd>Specifies the baseline containing the object</dd>
 *  <dt>WORKSET {WorkSet}<dt><dd>Specifies the workset containing the object</dd>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>Specifies change documents to relate</dd>
 *  <dt>REVISION {String}<dt><dd>The new revision to check out</dd>
 *  <dt>OVERWRITE {Boolean}<dt><dd>Should the Check Out overwrite a writeable file on disk</dd>
 *  <dt>CHECKOUT_FULL_PATH {String}<dt><dd>If not specified, USER_FILE is used by default</dd>
 *  <dt>CODE_PAGE {String}<dt><dd>Defines the method of encoding characters</dd>
 *  <dt>WRITE_METADATA {Boolean}<dt><dd>if false don't write metadata</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class CheckOutCmd extends RPCExecCmd {
    public CheckOutCmd() throws AttrException {
        super();
        setAlias(Versionable.CHECK_OUT);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILENAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, false, Baseline.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REVISION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.OVERWRITE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.TOUCH, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CHECKOUT_FULL_PATH, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CODE_PAGE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WRITE_METADATA, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.EXPAND, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue != null && !(attrValue instanceof Item)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    private AdmObject admObj;
    private AdmUid wsetUid;
    private String checkOutFullPath;

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        boolean isDirectoryItem = false;
        admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String userFilename = (String) getAttrValue(CmdArguments.USER_FILE);
        if (admObj instanceof ItemFile) // check for directory items
        {
            // Only allow directory items with a remote node...
            String path = ((ItemFile) admObj).getFileName();
            if (path != null && CmdUtils.isDirItemPath(path)) {
                isDirectoryItem = true;
            }
        }
        String filename = (String) getAttrValue(CmdArguments.FILENAME);
        Baseline baseline = (Baseline) getAttrValue(CmdArguments.BASELINE);
        WorkSet workset = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);
        String revision = (String) getAttrValue(CmdArguments.REVISION);
        boolean overwrite = ((Boolean) getAttrValue(CmdArguments.OVERWRITE)).booleanValue();
        boolean touch = ((Boolean) getAttrValue(CmdArguments.TOUCH)).booleanValue();
        checkOutFullPath = (String) getAttrValue(AdmAttrNames.CHECKOUT_FULL_PATH);
        String codepage = (String) getAttrValue(CmdArguments.CODE_PAGE);
        boolean metaData = ((Boolean) getAttrValue(CmdArguments.WRITE_METADATA)).booleanValue();
        boolean expand = ((Boolean) getAttrValue(CmdArguments.EXPAND)).booleanValue();
        if (checkOutFullPath == null) {
            checkOutFullPath = userFilename;
        }

        if (isDirectoryItem && !FilePath.hasNodeName(userFilename)
                && !userFilename.endsWith((new Character(File.separatorChar)).toString())) {
            userFilename += File.separatorChar;
        }

        if (workset != null) {
            wsetUid = workset.getAdmUid();
        } else if ((admObj.getAttrValue(AdmAttrNames.ADM_UID) != null) && (admObj.getAdmBaseId().getScope() != null)
                && (admObj.getAdmBaseId().getScope() instanceof AdmUid)
                && (admObj.getAdmBaseId().getScope().getObjType().equals(WorkSet.class))) {
            wsetUid = (AdmUid) admObj.getAdmBaseId().getScope();
        } else {
            wsetUid = (AdmUid) DimSystem.getSystem().getSessionBean().getCurRootObj(WorkSet.class).getAdmBaseId();
        }

        if (admObj instanceof Item) {
            _cmdStr = "EI ";
        }

        _cmdStr += Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec());
        _cmdStr += " /USER_FILENAME=" + Encoding.escapeDMCLI(userFilename);

        if ((filename != null) && (filename.length() > 0)) {
            _cmdStr += " /FILENAME=" + Encoding.escapeDMCLI(filename);
        }

        _cmdStr += (overwrite) ? " /OVERWRITE" : "";
        _cmdStr += (touch) ? " /TOUCH" : "";

        if (baseline != null) {
            _cmdStr += " /BASELINE=" + Encoding.escapeDMCLI(baseline.getAdmSpec().getSpec());
        }

        if (workset != null) {
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(workset.getAdmSpec().getSpec());
        }

        if ((chdocs != null) && (chdocs.length() > 0)) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
        }

        if ((revision != null) && (revision.length() > 0)) {
            _cmdStr += " /REVISION=" + Encoding.escapeDMCLI(revision);
        }

        if ((codepage != null) && (codepage.length() > 0)) {
            _cmdStr += " /CODEPAGE=" + Encoding.escapeDMCLI(codepage);
        }

        _cmdStr += (metaData ? "" : " /NOMETADATA"); // default true

        _cmdStr += expand ? " /EXPAND" : " /NOEXPAND"; // default NOEXPAND

        if (admObj instanceof AdmUidObject) {
            _cmdStr += " " + AttributeDefinition.getAttrsCmdStringFromCmd(this);
        }
    }
    
    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        // Get the base identifier for the new revision
        AdmResult ret = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, ret, admObj.getClass());
        if (ret.getUserData() == null) {
            Debug.println("Floz: CheckOutCmd.execute()");
            Debug.println("      Unable to obtain new item revision base identifier!");
        } else {
            // Now update the checkout path
            ((AdmBaseId) ret.getUserData()).setScope(wsetUid);
            List attrNames = new ArrayList();
            attrNames.add(AdmAttrNames.ADM_UID);
            AdmObject newItem = AdmCmd.getObject((AdmBaseId) ret.getUserData(), attrNames);
            // the workset has to be set on the item, otherwise it will think the file to update is in the current workset
            newItem.getAdmBaseId().setScope(wsetUid);

            newItem.setAttrValue(AdmAttrNames.CHECKOUT_FULL_PATH, checkOutFullPath);
            Cmd cmd = AdmCmd.getCmd(WithAttrs.UPDATE, newItem);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, AdmAttrNames.CHECKOUT_FULL_PATH);
            cmd.execute();
        }

        return ret;
    }

}

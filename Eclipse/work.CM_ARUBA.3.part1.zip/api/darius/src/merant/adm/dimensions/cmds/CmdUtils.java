/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import com.serena.dmfile.FilePath;
import com.serena.dmfile.FilePlatforms;
import com.serena.dmnet.drs.DRSClientQueryGlobalAttrsParams;

import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimDatabaseConnectException;
import merant.adm.dimensions.exception.DimInvalidPropertyException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.DimConnection;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.SecChangeDocument;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.Attribute;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.QueryConstants;
import merant.adm.dimensions.server.core.QueryExConstants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.server.query.AttributeMapEntry;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.PVCSPath;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.session.Session;

/**
 * This class contains utilities used by the commands.
 *
 * @author Peter Raymond, David Conneely
 */
public class CmdUtils {

    /** Table holds a cache of logical node name to OS type mappings */
    private static Map m_osTable = new HashMap();

    /** Clears the cache of logical node name to OS type mappings. */
    public static void clearOsTypeCache() {
        synchronized (m_osTable) {
            m_osTable.clear();
        }
    }

    /**
     * Retrieve the OS type for a given logical node name.
     *
     * @param node
     *            A logical node name.
     * @return -1 if the nodes OS cannot be determined, otherwise it returns the
     *         PVCSPath OS type of the specified node name.
     */
    public static int getOsType(String node) {
        if (node == null || m_osTable == null) {
            return -1;
        }

        synchronized (m_osTable) {
            // first, try and find this node in the cache
            Integer type = (Integer) m_osTable.get(node);

            if (type == null) {
                // otherwise, execute a command to query the node's OS type
                try {
                    type = new Integer(((Session) DimSystem.getSystem().getSession()).getConnection().rpcPcmsGetOSType(node));
                } catch (Exception ex) {
                    Debug.error(ex);
                    return -1;
                }

                // and add it to the cache
                m_osTable.put(node, type);
            }
            return type.intValue();
        }
    }

    /**
     * Retrieve the OS type for a given logical node name without consulting the cache.
     *
     * @param node
     *            A logical node name.
     * @return -1 if the nodes OS cannot be determined, otherwise it returns the
     *         PVCSPath OS type of the specified node name.
     */
    public static int getUncachedOsType(String node) {
        Integer type = null;
        // execute a command to query the node's OS type
        try {
            type = new Integer(((Session) DimSystem.getSystem().getSession()).getConnection().rpcPcmsGetOSType(node));
        } catch (Exception ex) {
            Debug.error(ex);
        }
        return type == null ? -1 : type.intValue();
    }

    /**
     * Retrieve the last component (filename) from a full path.
     */
    public static String getFileNameFromPath(String fileLocation) {
        int clientOs = -1;
        if (FilePath.hasNodeName(fileLocation)) {
            clientOs = CmdUtils.getOsType(PVCSPath.getNode(fileLocation, 0));
        }
        if (clientOs == -1) {
            clientOs = DimSystem.getSystem().getSessionBean().getClientOs();
        }
        PVCSPath path = new PVCSPath(fileLocation, clientOs);
        return path.getFile();
    }

    /**
     * Convert a file/directory path from the repository format (relative, '/')
     * to one suitable to pass to Dimensions command line (relative, server OS
     * in 7.x; or relative, client OS in 8.x).
     *
     * @param path
     *            The repository file/directory path to be translated.
     * @return The translated file/directory path.
     */
    public static String relPathForCmd(String path) {
        // Dimensions 8.0 server commands expect client format workset paths
        // (N.B. client means Dimensions Network client, not browser client),
        // but will accept '/' because I-Net only runs on UNIX and Windows
        // and currently 7.1.1 or later servers treat '/' as an alternative
        // Windows directory separator.
        // Dimensions 7.2 or earlier expect server (N.B. server means
        // Dimensions Network server, not Tomcat server) format workset
        // paths.

        // The path.replace call is just paranoia, as path should be
        // in repository format already (same for chopping leading '/'):
        String t = path.replace('\\', '/');
        if (t.length() > 0 && t.charAt(0) == '/') {
            t = t.substring(1, t.length());
        }
        return t;
    }

    /**
     * Check that a file/directory path in the repository format (relative, '/')
     * is a directory path (ends with a '/').
     *
     * @param path
     *            The repository file/directory path to be checked.
     * @return true if it is a directory.
     */
    public static boolean isDirPath(String path) {
        if (path == null) {
            return false;
        } else if (path.length() < 1) {
            return false; // or should this be true???
        } else {
            return (path.charAt(path.length() - 1) == FilePath.PVCS_DIR_SEP);
        }
    }

    /**
     * Check that a file/directory path in the repository format (relative, '/')
     * has a directory item's path (ends with a '/' or '\'). Directory items
     * have a workset filename that looks like a directory - in client filename
     * format (MVS and VMS clients do not support directory items, so only check
     * UNIX and Windows).
     *
     * @param path
     *            The repository file/directory path to be checked.
     * @return true if it is a directory.
     */
    public static boolean isDirItemPath(String path) {
        if (path == null) {
            return false;
        } else if (path.length() < 2) {
            return false; // must be something before directory char
        } else {
            char c = path.charAt(path.length() - 1);
            return (c == '/' /* UNIX client */
            || c == '\\' /* Windows client */
            );
        }
    }

    /**
     * Convert a file/directory path from the repository format (relative, '/')
     * to one suitable to be inserted into the Dimensions database (relative,
     * '/').
     *
     * @param path
     *            The repository file/directory path to be translated.
     * @return The translated file/directory path.
     */
    public static String relPathForDBIO(String path) {
        PVCSPath p = new PVCSPath(path, FilePlatforms.REPOSITORY);
        return p.toString();
    }

    /**
     * Convert a file/directory path from the repository format (relative, '/')
     * to the client's OS format.
     *
     * @param path
     *            The repository file/directory path to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The (relative) translated file/directory path.
     */
    public static String relPathForGUI(String path, String root) {
        int clientOs = getClientOS(root);

        PVCSPath p = new PVCSPath(path, FilePlatforms.REPOSITORY);
        // Convert from UniDir to the client OS
        return p.toOS(clientOs);
    }

    /**
     * Convert a directory path from the repository format (relative, '/') to
     * the client's OS format.
     *
     * @param path
     *            The repository directory path to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The (relative) translated directory path.
     */
    public static String relDirPathForGUI(String path, String root) {
        if (path == null || path.length() == 0) {
            path = "" + FilePath.PVCS_DIR_SEP;
        } else if (path.lastIndexOf(FilePath.PVCS_DIR_SEP) != path.length() - 1) {
            path += FilePath.PVCS_DIR_SEP;
        }
        return relPathForGUI(path, root);
    }

    /**
     * Take the workset root directory and append a path to it. The workset root
     * can have node:: syntax in which case we expect the path to also be in the
     * path syntax of that remote node.
     *
     * @param path
     *            The repository file/directory path to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The (absolute) translated file/directory path.
     */
    public static String fullPathForGUI(String path, String root) {
        if (path == null || path.length() == 0) {
            return (root != null) ? root : "";
        }

        // for DEF104989:
        if (root == null && path.equals("/")) {
            return "";
        }

        // for DEF105390:
        if (root != null && root.endsWith("::") && path.equals("/")) {
            return root;
        }

        int clientOs = getClientOS(root);

        PVCSPath p = new PVCSPath(path, FilePlatforms.REPOSITORY);
        if (root == null || root.length() == 0) {
            return p.toOS(clientOs);
        }

        PVCSPath p1 = new PVCSPath(root, clientOs);
        p1.append(p, FilePath.PVCS_MAKE_INPLACE);
        return p1.toOS(clientOs);
    }

    /**
     * Convert a directory path from the repository format (relative, '/') to
     * the client's OS format, appended to the workset root directory.
     *
     * @param path
     *            The repository directory path to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The (relative) translated directory path.
     */
    public static String fullDirPathForGUI(String path, String root) {
        if (path == null || path.length() == 0) {
            path = "" + FilePath.PVCS_DIR_SEP;
        } else if (path.lastIndexOf(FilePath.PVCS_DIR_SEP) != path.length() - 1) {
            path += FilePath.PVCS_DIR_SEP;
        }
        return fullPathForGUI(path, root);
    }

    /**
     * Convert a relative file/directory path from the client OS format to the
     * repository format (relative).
     *
     * @param path
     *            The client file/directory path (relative) to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The translated repository file/directory path (relative).
     */
    public static String relPathFromGUI(String path, String root) {
        int clientOs = getClientOS(root);

        PVCSPath p = new PVCSPath(path, clientOs);
        // Convert from client OS to UniDir
        return p.toString();
    }

    /**
     * Convert a relative directory path from the client OS format to the
     * repository format (relative).
     *
     * @param path
     *            The client directory path (relative) to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The translated repository directory path (relative).
     */
    public static String relDirPathFromGUI(String path, String root) {
        String s = relPathFromGUI(path, root);

        if (s == null || s.length() == 0) {
            s = ""; // N.B. empty represents top
        } else if (s.charAt(0) == FilePath.PVCS_DIR_SEP) {
            s = s.substring(1); // remove
        }
        // leading
        // '/'
        // if the string doesn't end in '/' add one:
        if (s.length() > 0 && !s.equals("*") && !s.equals("%") && s.lastIndexOf(FilePath.PVCS_DIR_SEP) != s.length() - 1) {
            s += FilePath.PVCS_DIR_SEP;
        }

        return s;
    }

    /**
     * Convert an absolute file/directory path from the client OS format to the
     * repository format (relative). If the path passed in is not under the
     * root, then the return is null.
     *
     * @param path
     *            The client file/directory path (absolute) to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The translated repository file/directory path (relative) or null
     *         if the path given is not below the root.
     */
    public static String fullPathFromGUI(String path, String root) {
        int clientOs = getClientOS(root);

        PVCSPath p1 = new PVCSPath(root, clientOs);

        // If path has a nodename then use that operating system...

        clientOs = getClientOS(path);

        PVCSPath p = new PVCSPath(path, clientOs);

        if (root == null || root.length() == 0) {
            return p.toString();
        }

        return PVCSPath.subPath(p1, p);
    }

    /**
     * Convert an absolute directory path from the client OS format to the
     * repository format (relative).
     *
     * @param path
     *            The client directory path (relative) to be translated.
     * @param root
     *            The workset root directory (if this is a node::path, then it
     *            will override the filename format set on the SessionBean).
     * @return The translated repository directory path (relative).
     */
    public static String fullDirPathFromGUI(String path, String root) {
        String s = fullPathFromGUI(path, root);

        if (s == null || s.length() == 0) {
            s = ""; // N.B. empty represents top
        } else if (s.charAt(0) == FilePath.PVCS_DIR_SEP) {
            s = s.substring(1); // remove
        }
        // leading
        // '/'
        // if the string doesn't end in '/' add one:
        if (s.length() > 0 && !s.equals("*") && !s.equals("%") && s.lastIndexOf(FilePath.PVCS_DIR_SEP) != s.length() - 1) {
            s += FilePath.PVCS_DIR_SEP;
        }

        return s;
    }

    public static int getClientOS(String root) {
        int clientOs = -1;

        if (root != null && FilePath.hasNodeName(root)) {
            clientOs = getOsType(PVCSPath.getNode(root, 0));
        }
        if (clientOs == -1) {
            clientOs = DimSystem.getSystem().getSessionBean().getClientOs();
        }

        return clientOs;
    }

    /**
     * This utility builds a List of Strings representing the SPECs of the
     * AdmObjects passed in.
     */
    public static List getSpecList(List objs) throws AdmObjectException, DimBaseException, AttrException, AdmException {
        List v2 = new ArrayList();

        if (objs.size() > 0) {
            for (int i = 0; i < objs.size(); i++) {
                if (objs.get(i) == null) {
                    continue;
                }

                if (objs.get(i) instanceof AdmObject) {
                    AdmObject o = (AdmObject) objs.get(i);
                    String so = o.getAdmSpec().getSpec();
                    v2.add(so);
                } else if (objs.get(i) instanceof AdmBaseId) {
                    Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECT);
                    AdmBaseId admBaseId = (AdmBaseId) objs.get(i);
                    cmd.setAttrValue(CmdArguments.ADM_BASE_ID, admBaseId);
                    AdmObject o = (AdmObject) cmd.execute();
                    String so = o.getAdmSpec().getSpec();
                    v2.add(so);
                } else {
                    throw new AdmObjectException("Invalid object in binding vector");
                }
            }
        } else {
            throw new AdmObjectException("Empty binding vector");
        }

        return v2;
    }

    /**
     * This utility builds an array of ints representing the UIDs of the
     * AdmObjects passed in.
     */
    public static int[] getUidArray(List objs) throws AdmObjectException, DimBaseException, AttrException, AdmException {
        if (objs.size() > 0) {
            int[] v2 = new int[objs.size()];
            for (int i = 0; i < objs.size(); i++) {
                if (objs.get(i) == null) {
                    v2[i] = Constants.INVALID_UID;
                    continue;
                }

                if (objs.get(i) instanceof AdmObject) {
                    AdmObject o = (AdmObject) objs.get(i);
                    Long lo = new Long(((AdmUidObject) o).getUid());
                    v2[i] = lo.intValue();
                } else if (objs.get(i) instanceof AdmBaseId) {
                    Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECT);
                    AdmBaseId admBaseId = (AdmBaseId) objs.get(i);
                    cmd.setAttrValue(CmdArguments.ADM_BASE_ID, admBaseId);
                    AdmObject o = (AdmObject) cmd.execute();
                    Long lo = new Long(((AdmUidObject) o).getUid());
                    v2[i] = lo.intValue();
                } else {
                    throw new AdmObjectException("Invalid object in binding vector");
                }
            }
            return v2;
        }

        throw new AdmObjectException("Empty binding vector");
    }

    /**
     * This utility builds a List of Longs representing the UIDs of the
     * AdmObjects passed in.
     */
    public static List getUidList(List objs) throws AdmObjectException, DimBaseException, AttrException, AdmException {
        List v2 = new ArrayList();

        if (objs.size() > 0) {
            for (int i = 0; i < objs.size(); i++) {
                if (objs.get(i) == null) {
                    continue;
                }

                if (objs.get(i) instanceof AdmObject) {
                    AdmObject o = (AdmObject) objs.get(i);
                    Long lo = new Long(((AdmUidObject) o).getAdmUid().getUid());
                    v2.add(lo);
                } else if (objs.get(i) instanceof AdmBaseId) {
                    Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECT);
                    AdmBaseId admBaseId = (AdmBaseId) objs.get(i);
                    cmd.setAttrValue(CmdArguments.ADM_BASE_ID, admBaseId);
                    AdmObject o = (AdmObject) cmd.execute();
                    Long lo = new Long(((AdmUidObject) o).getAdmUid().getUid());
                    v2.add(lo);
                } else {
                    throw new AdmObjectException("Invalid object in binding vector");
                }
            }
        } else {
            throw new AdmObjectException("Empty binding vector");
        }

        return v2;
    }

    /**
     * Find a AdmObject in a list given it's spec.
     */
    public static AdmObject getObjectFromList(String spec, List objs) throws AdmObjectException, DimBaseException, AttrException,
            AdmException {
        if (objs == null) {
            return null;
        }

        for (int i = 0; i < objs.size(); i++) {
            if (objs.get(i) == null) {
                continue;
            }

            if (objs.get(i) instanceof AdmObject) {
                String so = ((AdmObject) objs.get(i)).getAdmSpec().getSpec();
                if (so.equals(spec)) {
                    return (AdmObject) objs.get(i);
                }
            } else if (objs.get(i) instanceof AdmBaseId) {
                Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECT);
                AdmBaseId admBaseId = (AdmBaseId) objs.get(i);
                cmd.setAttrValue(CmdArguments.ADM_BASE_ID, admBaseId);
                AdmObject o = (AdmObject) cmd.execute();
                String so = o.getAdmSpec().getSpec();
                if (so.equals(spec)) {
                    return o;
                }
            } else {
                throw new AdmObjectException("Invalid object in binding vector");
            }
        }

        return null;
    }

    /**
     * Find a AdmObject in a list given it's uid.
     */
    public static AdmObject getObjectFromList(Long uid, List objs) throws AdmObjectException, DimBaseException, AttrException,
            AdmException {
        if (objs == null) {
            return null;
        }

        for (int i = 0; i < objs.size(); i++) {
            if (objs.get(i) == null) {
                continue;
            }

            if (objs.get(i) instanceof AdmObject) {
                Long lo = new Long(((AdmUidObject) objs.get(i)).getAdmUid().getUid());
                if (lo.equals(uid)) {
                    return (AdmObject) objs.get(i);
                }
            } else if (objs.get(i) instanceof AdmBaseId) {
                Cmd cmd = AdmCmd.getCmd(Creatable.GET_OBJECT);
                AdmBaseId admBaseId = (AdmBaseId) objs.get(i);
                cmd.setAttrValue(CmdArguments.ADM_BASE_ID, admBaseId);
                AdmObject o = (AdmObject) cmd.execute();

                Long lo = new Long(((AdmUidObject) o).getAdmUid().getUid());
                if (lo.equals(uid)) {
                    return o;
                }
            } else {
                throw new AdmObjectException("Invalid object in binding vector");
            }
        }

        return null;
    }

    /* Returns any usage or info flags that were present on the filter and removes them from the filter */
    public static int[] processFilterRelationships(FilterImpl filter) {
        int[] relFlags = null;
        List relInts = new ArrayList();

        if (filter != null) {
            if (filter.hasAttr(CmdArguments.FILTER_USAGE)) {
                relInts.add(new Integer(QueryConstants.USAGE));
                removeFromFilter(filter, CmdArguments.FILTER_USAGE);
            }

            if (filter.hasAttr(CmdArguments.FILTER_INFO)) {
                relInts.add(new Integer(QueryConstants.INFO));
                removeFromFilter(filter, CmdArguments.FILTER_INFO);
            }
        }

        relFlags = new int[relInts.size()];
        for (int i = 0; i < relInts.size(); i++) {
            relFlags[i] = ((Integer) relInts.get(i)).intValue();
        }

        return relFlags;
    }

    public static void removeFromFilter(FilterImpl filter, String attrName) {
        Iterator it = filter.criteria().iterator();
        List removals = new ArrayList();
        while (it.hasNext()) {
            FilterCriterion fc = (FilterCriterion) it.next();
            if (fc.getAttrName().equals(attrName)) {
                removals.add(fc);
            }
        }
        for (int i = 0; i < removals.size(); i++) {
            filter.criteria().remove(removals.get(i));
        }
    }

    /**
     * This looks at the FilterImpl object and adds the Where clauses to the
     * SuperQuery object. return int containing Local flags
     */
    public static int processFilter(SuperQuery query, FilterImpl filter, boolean count, boolean relationships, boolean useIsLatest,
            boolean isSavingReportFilter) throws AdmException {
        int retLocalFlags = 0;
        if (relationships) {
            retLocalFlags = QueryConstants.SELECT_REL;
        }

        int sflags = 0;
        if (count) {
            sflags = QueryConstants.DONT_ORDER;
        }

        query.setFlags(sflags);

        // SPECIAL CASE for not displaying stage projects in the UI (DEF95215)
        if (!isSavingReportFilter && query != null && query.getObjectClass().equals(WorkSet.class)) {
            if (filter == null) {
                filter = new FilterImpl();
            }
            if (!filter.getAttrs().contains(AdmAttrNames.VISIBLE)) {
                filter.criteria().add(new FilterCriterion(AdmAttrNames.VISIBLE, "N", QueryConstants.NOT | QueryConstants.EQUALS));
            }
        }

        if ((filter == null) || (query == null)) {
            return retLocalFlags;
        }

        if (filter.hasAttr(CmdArguments.FILTER_I_LATESTFV)) {
            sflags |= QueryConstants.LATEST_REVISION;
        }
        if (filter.hasAttr(CmdArguments.FILTER_I_LATEST)) {
            AdmBaseId baseId = query.getScope();
            if (useIsLatest && baseId != null && baseId instanceof AdmUid) {
                query.addWhere(AdmAttrNames.LATEST, "Y");
            } else {
                sflags |= QueryConstants.LATEST_REVISION;
            }
        }

        if (filter.hasAttr(CmdArguments.FILTER_ROOT)) {
            retLocalFlags |= QueryConstants.ROOT;
        }

        if (filter.hasAttr(CmdArguments.FILTER_BUILT)) {
            retLocalFlags |= QueryConstants.BUILT;
        }

        if (filter.hasAttr(CmdArguments.FILTER_USAGE)) {
            retLocalFlags |= QueryConstants.USAGE;
        }

        if (filter.hasAttr(CmdArguments.FILTER_INFO)) {
            retLocalFlags |= QueryConstants.INFO;
        }

        /*
         * PVCS_EC_5887: IS_TOOL_MANAGER flag is now used by IS_NULL
         * if (filter.hasAttr(CmdArguments.FILTER_U_ISTOOLMGR)) {
         * Object o = filter.get(CmdArguments.FILTER_U_ISTOOLMGR);
         * if ((o != null) && (o instanceof Boolean)) {
         * boolean isToolManager = ((Boolean) o).booleanValue();
         * if (isToolManager)
         * sflags |= QueryConstants.IS_TOOL_MANAGER;
         * else
         * sflags |= QueryConstants.IS_NOT_TOOL_MANAGER;
         * }
         * }
         */
        sflags |= QueryConstants.PRESERVE_CRITERIA_POS;
        query.setFlags(sflags);

        // set flagsEx
        int sflagsEx = 0;
        if (filter.hasAttr(CmdArguments.FILTER_IGNORE_TOPIC_FILTERING)) {
            sflagsEx |= QueryExConstants.DISABLE_TOPIC_FILTERING;
        }

        query.setFlagsEx(sflagsEx);

        // The following three methods have been left showing deprecated warnings as this
        // may require a change to the FilterImpl class.
        List names = filter.getAttrs();
        List values = filter.getValues();
        List flags = filter.getFlags();

        // Nicked from QueryRels
        List attrNames = null;
        if (filter != null && filter.getOrderBy() != null) {
            Set orderBy = filter.getOrderBy().keySet();
            if ((orderBy != null) && (orderBy.size() > 0)) {
                attrNames = new ArrayList(orderBy); // mutable list containing Set elements in order
            } else {
                attrNames = new ArrayList(); // empty mutable list
            }
            for (int i = 0; i < names.size(); i++) {
                String attrName = (String) names.get(i);
                int flag = ((Integer) flags.get(i)).intValue();
                if (attrName != null && attrName.length() > 0 && attrName.charAt(0) != Constants.NON_USER_DEF_ATTR_CHAR
                        && (flag & QueryConstants.RELATIONSHIP) == 0 && !attrNames.contains(attrName)) {
                    attrNames.add(attrName);
                }
            }
        }
        Map[] attrMaps = CmdUtils.constructAttrMaps(query.getObjectClass(), attrNames);
        // END Nicked from QueryRels

        // Construct any required Attribute objects
        for (int i = 0; i < names.size(); i++) {
            String attrName = (String) names.get(i);
            Object value = values.get(i);
            int flag = ((Integer) flags.get(i)).intValue();

            if (attrName != null && attrName.length() > 0 && attrName.charAt(0) != Constants.NON_USER_DEF_ATTR_CHAR
                    && value != null && value instanceof String && attrMaps[0] != null && attrMaps[1] != null
                    && (flag & QueryConstants.RELATIONSHIP) == 0) {
                Integer attrNum = (Integer) attrMaps[0].get(attrName);
                Long attrType = (Long) attrMaps[1].get(attrName);
                if (attrNum != null && attrType != null) {
                    String attrTypeChar = "C";
                    if (attrType.longValue() == AttributeMapEntry.DECODE_UID_DATE) {
                        attrTypeChar = "D";
                    } else if (attrType.longValue() == AttributeMapEntry.DECODE_UID_NUMBER) {
                        attrTypeChar = "N";
                    }

                    AttributeDefinition attrDef = new AttributeDefinition();
                    attrDef.setName(attrName);
                    attrDef.setAttrValue(AdmAttrNames.ATTRDEF_ATTRNO, attrNum);
                    attrDef.setAttrValue(AdmAttrNames.ATTRDEF_ATTRTYPE, attrTypeChar);
                    Attribute attr = new Attribute((String) value);
                    attr.setAttributeDefinition(attrDef);
                    values.set(i, attr);
                }
            }
        }

        query.setCriteria(names, values, flags);// sets rels as well as wheres

        if (!count) {
            processFilterOrderBy(query, filter, attrMaps[0], attrMaps[1]);
            // Range restrictions are not considered when "only counting"
            processFilterRangeRestriction(query, filter);
        }

        return retLocalFlags;
    }

    /**
     * This looks at the FilterImpl object and adds the OrderBy elements to the
     * SuperQuery object.
     */
    private static void processFilterOrderBy(SuperQuery query, FilterImpl filter, Map nameToNum, Map nameToType) {

        if ((filter == null) || (query == null)) {
            return;
        }

        Collection orders = filter.orders();
        Iterator it = orders.iterator();
        while (it.hasNext()) {
            FilterOrder order = (FilterOrder) it.next();
            String attr = order.getAttrName();
            int fl = order.getFlags();
            if ((attr != null) && (attr.length() != 0)) {
                if (attr.charAt(0) != Constants.NON_USER_DEF_ATTR_CHAR) {
                    if ((nameToNum != null) && (nameToType != null)) {
                        Integer unum = (Integer) nameToNum.get(attr);
                        Long ltype = (Long) nameToType.get(attr);
                        if (unum != null) {
                            if (fl == 0) {
                                query.addOrder(unum.intValue(), attr, QueryConstants.ASCENDING, ltype.longValue());
                            } else {
                                query.addOrder(unum.intValue(), attr, fl, ltype.longValue());
                            }
                        }
                    }
                } else {
                    if (fl == 0) {
                        query.addOrder(attr, QueryConstants.ASCENDING);
                    } else {
                        query.addOrder(attr, fl);
                    }
                }
            }
        }

        query.addDefaultOrder();
    }

    /**
     * This looks at the FilterImpl object and sets the range restriction state on the SuperQuery object.
     */
    private static void processFilterRangeRestriction(SuperQuery query, FilterImpl filter) {

        if ((filter == null) || (query == null)) {
            return;
        }

        if (filter.getRecordCount() > 0) {
            query.setStartRank(filter.getStartRank());
            query.setPageSize(filter.getRecordCount());
            query.setNeedMaxRows(filter.getMaximumNeeded());
        }
    }


    // TODO: This method is here to provide backwards compatibility of the API with a 14.3 server, it can be removed in Eagle
    public static Map[] constructAttrMapsBackwardCompat(Class objClass, List attrNames) throws DBIOException, AdmObjectException,
            DimInvalidPropertyException, DimDatabaseConnectException, AdmException {
        Map nameToNum = new HashMap();
        Map nameToType = new HashMap();
        Map[] ret = new Map[2];
        ret[0] = nameToNum;
        ret[1] = nameToType;

        if ((attrNames == null) || (objClass == null)) {
            return ret;
        }

        int pos = 0;
        String attr = null;
        String attrNums = "";
        Iterator it = attrNames.iterator();

        while (it.hasNext()) {
            attr = (String) it.next();
            if ((attr != null) && (attr.length() != 0)) {
                if (attr.charAt(0) != Constants.NON_USER_DEF_ATTR_CHAR) {
                    if (pos > 0) {
                        attrNums += ", ";
                    }

                    attrNums += "\'" + attr + "\'";
                    pos++;
                }
            }
        }

        if (pos > 0) {
            String attrNumsSQL = "SELECT attr_no, variable_name, attr_class FROM global_attributes WHERE type_flag=\'";
            if (objClass.equals(Baseline.class)) {
                attrNumsSQL += "B";
            } else if (objClass.equals(ChangeDocument.class) || objClass.equals(SecChangeDocument.class)) {
                attrNumsSQL += "C";
            } else if (objClass.equals(Item.class) || objClass.equals(ItemFile.class)) {
                attrNumsSQL += "I";
            } else if (objClass.equals(Part.class) || objClass.equals(Product.class)) {
                attrNumsSQL += "P";
            } else if (objClass.equals(User.class)) {
                attrNumsSQL += "U";
            } else if (objClass.equals(WorkSet.class)) {
                attrNumsSQL += "W";
            } else {
                throw new DBIOException("Error: Object type not supported!" + objClass.toString());
            }

            attrNumsSQL += "\' AND variable_name IN (";
            attrNumsSQL += attrNums;
            attrNumsSQL += ")";

            DBIO attrNumsQuery = new DBIO(attrNumsSQL);
            attrNumsQuery.readStart();

            String type = null;
            long ltype = AttributeMapEntry.DECODE_UID_STRING;

            while (attrNumsQuery.read()) {
                type = attrNumsQuery.getString(3);
                if (type.equals("D")) {
                    ltype = AttributeMapEntry.DECODE_UID_DATE;
                } else if (type.equals("N")) {
                    ltype = AttributeMapEntry.DECODE_UID_NUMBER;
                } else {
                    ltype = AttributeMapEntry.DECODE_UID_STRING;
                }

                nameToNum.put(attrNumsQuery.getString(2), new Integer(attrNumsQuery.getInt(1)));
                nameToType.put(attrNumsQuery.getString(2), new Long(ltype));
            }
        }

        return ret;
    }

    public static Map[] constructAttrMaps(Class objClass, List attrNames) throws DBIOException, AdmObjectException,
            DimInvalidPropertyException, DimDatabaseConnectException, AdmException {
        try {
            Map nameToNum = new HashMap();
            Map nameToType = new HashMap();
            Map[] ret = new Map[2];
            ret[0] = nameToNum;
            ret[1] = nameToType;

            if ((attrNames == null) || (objClass == null)) {
                return ret;
            }

            String attr = null;
            Iterator it = attrNames.iterator();
            List<String> vars = new ArrayList<String>();

            while (it.hasNext()) {
                attr = (String) it.next();
                if ((attr != null) && (attr.length() != 0)) {
                    if (attr.charAt(0) != Constants.NON_USER_DEF_ATTR_CHAR) {
                        vars.add(attr);
                    }
                }
            }

            if (!vars.isEmpty()) {
                DRSClientQueryGlobalAttrsParams drs = new DRSClientQueryGlobalAttrsParams();
                drs.setObjectType(TypeUtils.getClassInt(objClass));

                String[] variable = vars.toArray(new String[vars.size()]);
                drs.setVariable(variable);

                DRSUtils.execute(drs);

                if (drs.hasData() && drs.getCount() != 0) {
                    int[] attrNumber = drs.getAttrNumber();
                    String[] attrName = drs.getAttrName();
                    String[] attrClass = drs.getAttrClass();

                    for (int i = 0; i < attrNumber.length; i++) {
                        long ltype = AttributeMapEntry.DECODE_UID_STRING;

                        String type = attrClass[i];
                        if (type.equals("D")) {
                            ltype = AttributeMapEntry.DECODE_UID_DATE;
                        } else if (type.equals("N")) {
                            ltype = AttributeMapEntry.DECODE_UID_NUMBER;
                        }

                        nameToNum.put(attrName[i], new Integer(attrNumber[i]));
                        nameToType.put(attrName[i], new Long(ltype));
                    }
                }
            }

            return ret;
        } catch (AdmException e) {
            return constructAttrMapsBackwardCompat(objClass, attrNames);
        }

    }

    /**
     * Locates the top part associated with the product.
     * <p>
     * Usefully for product attribute queries as product attributes are not stored under the uid of the product - but of the uid of
     * its associated part :(
     */
    public static AdmObject getTopPartOfProduct(AdmObject product) throws AttrException, DBIOException, DimBaseException,
            AdmException {
        String id = (String) AdmHelperCmd.getAttributeValue(product, AdmAttrNames.ID);
        String variant = (String) AdmHelperCmd.getAttributeValue(product, AdmAttrNames.VARIANT);
        FilterImpl filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.PRODUCT_NAME, id));
        filter.criteria().add(new FilterCriterion(AdmAttrNames.ID, id));
        filter.criteria().add(new FilterCriterion(AdmAttrNames.VARIANT, variant));
        filter.criteria().add(new FilterCriterion(AdmAttrNames.TYPE_NAME, Constants.GLOBAL_PROD_TYPE_NAME));
        filter.criteria().add(new FilterCriterion(AdmAttrNames.STATUS, Constants.SYS_STATE_OPEN));
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, AdmCmd.getCurRootObj(BaseDatabase.class), Part.class);
        cmd.setAttrValue(CmdArguments.FILTER, filter);
        return AdmHelperCmd.getObject((AdmBaseId) cmd.execute());
    }

    private static long getRelClass(Class clazz) {
        String scopeFlag = TypeUtils.getTypeFlag(clazz);
        long relClass;
        char chRelClass = (scopeFlag.length() > 0 ? scopeFlag.charAt(0) : ' ');
        switch (chRelClass) {
        case 'C':
            relClass = 1L;
            break;
        case 'I':
            relClass = 50L;
            break;
        case 'P':
            relClass = 51L;
            break;
        case 'B':
            relClass = 53L;
            break;
        case 'U':
            relClass = 54L;
            break;
        case 'W':
            relClass = 61L;
            break;
        default:
            relClass = 1L; // request is default?
            break;
        }
        return relClass;
    }

    /**
     * Queries a User user-defined attribute to see if it is mandatory.
     */
    public static boolean queryForIsMandatory(AdmObject admObj) throws AdmException {
        long typeUid = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_TYPE_UID)).longValue();
        Class scopeClass = (Class) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
        int attrNo = ((Integer) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_ATTRNO)).intValue();

        long relClass = getRelClass(scopeClass);
        String strAttrNo = Integer.toString(attrNo);

        String sql = "SELECT ca.attr_4 FROM cpl_attributes ca, cpl_rels cr"
                + " WHERE ca.obj_uid = cr.related_uid AND cr.obj_uid = :I1" + " AND cr.rel_class = :I2"
                + " AND ca.attr_1 = :I3 AND rownum <= 1";

        boolean isMandatory = false;
        DBIO query = new DBIO(sql);
        query.bindInput(typeUid);
        query.bindInput(relClass);
        query.bindInput(strAttrNo);
        query.readStart();
        if (query.read(DBIO.DB_IGNORE_REST)) {
            isMandatory = "Y".equals(query.getString(1));
        }
        return isMandatory;
    }

    /**
     * Queries a User user-defined attribute to see if it is mandatory when
     * actioning from curState to nextState by user with specified role.
     */
    public static boolean queryForIsMandatory(AdmObject admObj, String curState, String nextState, String role) throws AdmException {
        long typeUid = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_TYPE_UID)).longValue();
        Class scopeClass = (Class) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);
        int attrNo = ((Integer) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_ATTRNO)).intValue();

        long relClass = getRelClass(scopeClass);
        String strAttrNo = Integer.toString(attrNo);

        String sql = "SELECT ca.attr_4 FROM cpl_attributes ca, cpl_rels cr"
                + " WHERE ca.obj_uid = cr.related_uid AND cr.obj_uid = :I1" + " AND ca.attr_3 = :I4 AND ca.attr_2 = :I5"
                + " AND cr.rel_class = :I2" + " AND ca.attr_1 = :I3 AND rownum <= 1";
        if (nextState != null && nextState.length() > 0) {
            sql += " AND (ca.attr_7 = :I6 OR ca.attr_7 IS NULL)";
        }

        boolean isMandatory = false;
        DBIO query = new DBIO(sql);
        query.bindInput(typeUid);
        query.bindInput(relClass);
        query.bindInput(strAttrNo);
        query.bindInput(curState);
        query.bindInput(role);
        if (nextState != null && nextState.length() > 0) {
            query.bindInput(nextState);
        }
        query.readStart();
        if (query.read(DBIO.DB_IGNORE_REST)) {
            isMandatory = "Y".equals(query.getString(1));
        }
        return isMandatory;
    }

    /**
     * Compares two version Strings. A null value is treated as a lesser value.
     * @return
     *         -1 version1 is less than version2
     *         0 version1 and version2 are the same
     *         1 version1 is greater than version2
     */
    public static int compareVersions(String version1, String version2) {

        if (version1 == null) {
            return -1;
        }
        if (version2 == null) {
            return 1;
        }

        // check the version strings, if there is a value that is not a number
        // then add zero
        List ver1List = new ArrayList();
        StringTokenizer st = new StringTokenizer(version1, ". "); // catch both '.' and ' ' (space)
        while (st.hasMoreTokens()) {
            try {
                ver1List.add(Integer.valueOf(st.nextToken()));
            } catch (NumberFormatException nfe) {
                ver1List.add(new Integer(0));
            }
        }

        List ver2List = new ArrayList();
        st = new StringTokenizer(version2, ". "); // catch both '.' and ' ' (space)
        while (st.hasMoreTokens()) {
            try {
                ver2List.add(Integer.valueOf(st.nextToken()));
            } catch (NumberFormatException nfe) {
                ver2List.add(new Integer(0));
            }
        }

        // make sure the lists are the same size by added zeros to make the sizes equal
        if (ver1List.size() != ver2List.size()) {
            while (ver1List.size() < ver2List.size()) {
                ver1List.add(new Integer(0));
            }
            while (ver2List.size() < ver1List.size()) {
                ver2List.add(new Integer(0));
            }
        }

        // compare each version value at a time
        int size = ver1List.size();
        for (int j = 0; j < size; j++) {
            if (j == ver1List.size()) {
                return -1;
            }
            if (j == ver2List.size()) {
                return 1;
            }
            if (((Integer) ver1List.get(j)).intValue() < ((Integer) ver2List.get(j)).intValue()) {
                return -1;
            }
            if (((Integer) ver1List.get(j)).intValue() > ((Integer) ver2List.get(j)).intValue()) {
                return 1;
            }
        }
        return 0;
    }

    /**
     * Returns the current Dimensions version.
     * @return String Dimensions version
     */
    public static String getDimensionsVersion() {
        String version = null;
        try {
            version = (String) AdmHelperCmd.getAttributeValue(AdmCmd.getCurRootObj(DimConnection.class), AdmAttrNames.VERSION);
        } catch (AdmException ae) {
        }
        return version;
    }

    /**
     * Returns the current database schema version.
     * @return String database schema version
     */
    public static String getSchemaVersion() {
        String version = null;
        try {
            AdmObject dimConn = AdmCmd.getCurRootObj(DimConnection.class);
            String schema = (String) AdmHelperCmd.getAttributeValue(dimConn, AdmAttrNames.DIMCONN_SCHEMA_VERSION);
            String revision = (String) AdmHelperCmd.getAttributeValue(dimConn, AdmAttrNames.DIMCONN_SCHEMA_REVISION);
            version = schema + "." + revision;
        } catch (AdmException ae) {
        }
        return version;
    }

    /**
     * Returns the administrator's published preferences as a Map.
     * @return Map administrator's published preferences
     */
    public static Map getPublishedUserPreferences() throws AdmException {
        Map prefs = new HashMap();
        long prefs_uid = Constants.INVALID_UID;
        DBIO query = new DBIO(wcm_sql.RETRIEVE_PUBLISHED_PREFS_UID);
        query.bindInput(Constants.PUBLISHED_PREFS_OBJCLASS);
        query.readStart();
        if (query.read()) {
            prefs_uid = query.getLong(1);
            query.close(DBIO.DB_DONT_RELEASE);

            query.resetMessage(wcm_sql.QUERY_USER_PREFS);
            query.bindInput(prefs_uid);
            query.readStart();
            while (query.read()) {
                String name = query.getString(1);
                String value = query.getString(2);
                prefs.put(name, value);
            }
        }
        query.close(DBIO.DB_DONT_RELEASE);
        return Collections.unmodifiableMap(prefs);
    }

    public static boolean hasCurrUserAdminPrivilege(String privilegeID) throws DimBaseException, AdmObjectException, AttrException,
            AdmException {
        AdmUidObject user = (AdmUidObject) AdmCmd.getCurRootObj(User.class);
        String userName = (String) user.getAttrValue(AdmAttrNames.ID);

        Integer privilegeUidInt = (Integer) PrivilegesCommandConstants.privilegesHashMap.get(privilegeID);

        if (privilegeUidInt == null) {
            throw new AdmException("The privilege mapping for '" + privilegeID + "' does not exist");
        }

        return hasPrivilege(userName, privilegeUidInt, "", new Integer(0), null);
    }

    public static boolean hasCurrUserApplicationPrivilege(String privilegeID, String productName) throws DimBaseException,
            AdmObjectException, AttrException, AdmException {
        AdmUidObject user = (AdmUidObject) AdmCmd.getCurRootObj(User.class);
        String userName = (String) user.getAttrValue(AdmAttrNames.ID);

        Integer privilegeUidInt = (Integer) PrivilegesCommandConstants.privilegesHashMap.get(privilegeID);
        if (privilegeUidInt == null) {
            throw new AdmException("The privilege mapping for '" + privilegeID + "' does not exist");
        }

        return hasPrivilege(userName, privilegeUidInt, productName, new Integer(0), null);
    }

    public static boolean hasPrivilege(String userName, Integer privilegeUID, String productName, Integer privilegeObjectType,
            AdmUidObject admUidObject) throws DimBaseException, AdmObjectException, AttrException, AdmException {
        Long admUid = new Long(0);
        if (admUidObject != null) {
            admUid = new Long(admUidObject.getAdmUid().getUid());
        }

        Cmd privilegeCmd = AdmCmd.getCmd("HasPrivilege");
        privilegeCmd.setAttrValue(AdmAttrNames.USER_NAME, userName);
        privilegeCmd.setAttrValue(AdmAttrNames.PRIVILEGE_UID, privilegeUID);
        privilegeCmd.setAttrValue(AdmAttrNames.PRIVILEGE_RULE_PRODUCT, productName);
        privilegeCmd.setAttrValue(AdmAttrNames.PRIVILEGE_OBJ_TYPE, privilegeObjectType);
        privilegeCmd.setAttrValue(AdmAttrNames.ADM_UID, admUid);
        Boolean hasPrivilege = (Boolean) privilegeCmd.execute();

        return hasPrivilege.booleanValue();
    }

    public static String getPrivilegeShortDesc(String privilegeID) throws AdmException {
        String privilegeShortDesc = "";

        DBIO query = new DBIO(wcm_sql.RETRIEVE_PRIVILEGE_SHORT_DESC);
        query.bindInput(privilegeID);

        query.readStart();
        if (query.read()) {
            privilegeShortDesc = query.getString(1);
        }
        query.close();

        return privilegeShortDesc;
    }

    /**
     * Return the RTM user and password
     *
     * @return Returns a <code>java.utils.List</code> object with 2 values -
     *         the username and password.
     *
     * @throws AdmException
     */
    public static List getRtmLogon() throws AdmException {
        Cmd rtmUserCmd = AdmCmd.getCmd("GetRtmLogon");
        List userpass = (List) rtmUserCmd.execute();

        return userpass;
    }

    /** Attribute default value for getting current system date */
    private static final String DEF_TODAYS_DATE = "$TODAYS_DATE";

    /** Attribute default value for getting current user name */
    private static final String DEF_USER_NAME = "$USER_NAME";

    /***
     * Verifies whether passed default value is of special form (e.g. "$TODAYS_DATE", "$USER_NAME")
     * @param defaultValue
     * @return true if default value is of special form
     */
    public static boolean isSpecialAttributeDefaultValue(String defaultValue) {
        if (defaultValue != null && (defaultValue.equals(DEF_TODAYS_DATE) || defaultValue.equals(DEF_USER_NAME))) {
            return true;
        }
        return false;
    }

    /***
     * Returns the default value or if the default value is of special form (e.g. "$TODAYS_DATE", "$USER_NAME")
     * performs corresponding server request.
     * @param defaultValue
     *            the value to interpret
     * @return the interpreted value
     */
    public static String getInterpretedAttributeDefaultValue(String defaultValue) throws AdmException {
        String interpretedValue = defaultValue;
        if (defaultValue != null) {
            if (defaultValue.equals(DEF_TODAYS_DATE)) {
                DBIO query = new DBIO(wcm_sql.DBQ_GET_TODAYS_DATE);
                query.readStart();
                if (query.read()) {
                    interpretedValue = query.getString(1);
                }
            } else if (defaultValue.equals(DEF_USER_NAME)) {
                interpretedValue = AdmCmd.getCurRootObj(User.class).getId();
            }
        }
        return interpretedValue;
    }

}

package merant.adm.dimensions.cmds.helper;

public interface IDeploymentViewConstants {

    public static final int CLASS_ITEM = 2;
    public static final int CLASS_BASELINE = 4;
    public static final int CLASS_REQUEST = 8;
    public static final int CLASS_WORKSET = 64;
    public static final int CLASS_SCHEDULED_JOB = 5066;

    // Note: following 2 constants are not used by server at this moment.
    public static final int CLASS_DEPLOYMENT_JOB = 0x20001;
    public static final int CLASS_DEPLOYMENT_HISTORY_RECORD = 0x20002;

    public static final int MODE_PENDING = 0x100000;
    public static final int MODE_ARCHIVED = 0x200000;
    public static final int MODE_AUTOMATION_QUEUE = 0x300000;
    public static final int MODE_DEPLOYMENT_QUEUE = 0x400000;
    public static final int MODE_DEPLOYMENT_HISTORY = 0x500000;
    public static final int MODE_ROLLBACK = 0x600000;
    public static final int MODE_AUTOMATION_HISTORY = 0x700000;

    public static final int LDAF_EXCLUDE_PREV_STAGE_AREAS = 0x001;
    public static final int LDAF_EXCLUDE_ALREADY_DEPLOYED_TO_AREAS = 0x002;
    public static final int LDAF_TRAVERSE_CHILD_REQUESTS = 0x004;

    // Event types
    public static final int EVENT_TYPE_INVALID = -1;
    public static final int EVENT_TYPE_DEPLOY = 0;
    public static final int EVENT_TYPE_ROLLBACK = 1;
    public static final int EVENT_TYPE_BUILD_START = 2;
    public static final int EVENT_TYPE_CLEAN = 3;
    public static final int EVENT_TYPE_AUDIT = 4;
    public static final int EVENT_TYPE_COLLECT_OUTPUTS = 5;
    public static final int EVENT_TYPE_BUILD_END = 6;
    public static final int EVENT_TYPE_TRANSACTION_START = 7;
    public static final int EVENT_TYPE_TRANSACTION_END = 8;
    public static final int EVENT_TYPE_COMMAND = 9;
    public static final int EVENT_TYPE_START_SCHEDULED_JOB = 10;
    public static final int EVENT_TYPE_AUTOMATION = 11;

    // Artificial event types, that are not actually used at deployment server, but are used sometimes as return values from server
    public static final int EVENT_TYPE_PROMOTE = 1001;
    public static final int EVENT_TYPE_DEMOTE = 1000;
    public static final int EVENT_TYPE_EXTERNAL_AUTOMATION = 1002;
    public static final int EVENT_TYPE_PROMOTE_SDA = 1003;
    public static final int EVENT_TYPE_DEMOTE_SDA = 1004;

    public static final int EVENT_RESULT_SUBMITTED = 0;
    public static final int EVENT_RESULT_EXECUTING = 1;
    public static final int EVENT_RESULT_SUCCEEDED = 2;
    public static final int EVENT_RESULT_FAILED = 3;
    public static final int EVENT_RESULT_CANCELLED = 4;
    public static final int EVENT_RESULT_PAUSED = 5;
    public static final int EVENT_RESULT_SCHEDULED = 6;
    public static final int EVENT_RESULT_SDA_EXECUTING = 7;

}

/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.relatable;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import com.serena.dmnet.drs.DRSClientQueryProductPartsRecursive;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmDebugCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.RPCPcmsGetRSAttrs;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.Format;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.RoleSection;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.QueryConstants;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will query the children of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_CHILD_CLASS {Class}<dt><dd>Child Dimensions object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions workset container for objects</dd>
 *  <dt>RELATIONSHIPS {Boolean}<dt><dd>If true, command returns Relationship rather than AdmBaseId instances</dd>
 *  <dt>RECURSIVE {Boolean}<dt>
 *  <dd>
 *      If true, returns all child objects recursively
 *      throughout the child hierarchy.<br>
 *      Note: if parent and child classes match, or required
 *      children are hierarchical by nature, then returns
 *      Relationship rather than AdmBaseId instances.
 *  </dd>
 *  <dt>RECURSIVE_VIA_PARENT_HIER {Boolean}<dt>
 *  <dd>
 *      If true, returns all child objects recursively
 *      throughout the parent hierarchy.<br>
 *      Note: if parent and child classes match, or required
 *      children are hierarchical by nature, then returns
 *      Relationship rather than AdmBaseId instances.
 *  </dd>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr instances containing filter information</dd>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}<dt><dd>If true, returns default object preferences</dd>
 *  <dt>RELTYPE_IS_PEDIGREE {Boolean}<dt><dd>If true, returns pedigree object relationships</dd>
 *  <dt>MULTIPLE {Boolean}</dt><dd>Used for multiple edit attribute operations</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId or Relationship instances</dd>
 * </dl></code>
 * 
 * @todo where there is a 'new AdmObject', replace with new Cache stuff
 * @author Floz
 *         %PCMS_HEADER_SUBSTITUTION_END%
 */
public class QueryChildrenCmd extends DBIOCmd {
    public QueryChildrenCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_CHILDREN);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_CHILD_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATIONSHIPS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RECURSIVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RECURSIVE_VIA_PARENT_HIER, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_DEFAULT, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_PEDIGREE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.MULTIPLE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef("COUNT", false, Boolean.FALSE, Boolean.class)); // Not for public use.
        setAttrDef(new CmdArgDef(AdmAttrNames.FILTER_OUT_STREAMS, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Class admChildClass = (Class) getAttrValue(CmdArguments.ADM_CHILD_CLASS);
        boolean relationships = ((Boolean) getAttrValue(CmdArguments.RELATIONSHIPS)).booleanValue();
        boolean recursive = ((Boolean) getAttrValue(CmdArguments.RECURSIVE)).booleanValue();
        boolean recursiveViaParentHier = ((Boolean) getAttrValue(CmdArguments.RECURSIVE_VIA_PARENT_HIER)).booleanValue();
        boolean isDefault = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT)).booleanValue();
        boolean isMultiple = ((Boolean) getAttrValue(CmdArguments.MULTIPLE)).booleanValue();

        // Save the filter we were originally supplied with, if any. Forget it if we do not need to return the maximum row
        // count for pagination.
        Filter original_filter = (Filter)getAttrValue(CmdArguments.FILTER);
        if (original_filter != null && !original_filter.getMaximumNeeded()) {
        	original_filter = null;
        }
        
        // VADYMK: 2002-08-20
        // for compatibility with old behavior list only open branches
        // if no filter is specified or if no filter by status criterion is
        // specified
        if ((admObj instanceof BaseDatabase) && admChildClass.equals(Branch.class)) {
            FilterImpl filt = (FilterImpl) getAttrValue(CmdArguments.FILTER);
            if (filt == null) {
                // filter is not specifed. caller is querying for all open
                // branches so, add filter by status criterion
                filt = new FilterImpl();
                filt.criteria().add(new FilterCriterion(AdmAttrNames.STATUS, "OPEN"));
                setAttrValue(CmdArguments.FILTER, filt);
            } else {
                // filter is specified. check if filter by status criterion is
                // present
                Collection crits = filt.criteria();
                if (crits != null && crits.size() > 0) {
                    boolean bFound = false;
                    for (Iterator it = crits.iterator(); it.hasNext();) {
                        FilterCriterion crit = (FilterCriterion) it.next();
                        if (crit == null) {
                            continue;
                        }
                        String filtName = crit.getAttrName();
                        if (filtName == null) {
                            continue;
                        }
                        if (AdmAttrNames.STATUS.equals(filtName)) {
                            bFound = true;
                        }
                    }
                    // if filter by status criterion was not found, then add it
                    if (!bFound) {
                        crits.add(new FilterCriterion(AdmAttrNames.STATUS, "OPEN"));
                    }
                }
            }
        }
        // VADYMK: 2002-07-31
        // make sure that the FilterCriterion.RELATIONSHIP flag is specified in
        // the filter criteria
        // when using ADM_SCOPE_OBJECT to list formats assigned to an item type
        if ((admObj instanceof BaseDatabase) && admChildClass.equals(Format.class)) {
            FilterImpl filt = (FilterImpl) getAttrValue(CmdArguments.FILTER);
            if (filt != null) {
                Collection crits = filt.criteria();
                if (crits != null && crits.size() > 0) {
                    for (Iterator it = crits.iterator(); it.hasNext();) {
                        FilterCriterion crit = (FilterCriterion) it.next();
                        if (crit == null) {
                            continue;
                        }
                        String filtName = crit.getAttrName();
                        if (filtName == null) {
                            continue;
                        }
                        Object filtValue = crit.getValue();
                        int filtFlags = crit.getFlags();

                        // if RELATIONSHIP flag is not specified, add it
                        if (CmdArguments.ADM_SCOPE_OBJECT.equals(filtName) && (filtValue instanceof Type)
                                && ((filtFlags & FilterCriterion.RELATIONSHIP) == 0)) {
                            it.remove();
                            FilterCriterion newCrit = new FilterCriterion(filtName, filtValue, filtFlags
                                    | FilterCriterion.RELATIONSHIP);
                            crits.add(newCrit);
                        }
                    }
                }
            }
        }

        // Check if recursive item query was requested via filter
        if ((admObj instanceof DimDirectory) && (admChildClass.equals(Item.class) || admChildClass.equals(ItemFile.class))) {
            FilterImpl filt = (FilterImpl) getAttrValue(CmdArguments.FILTER);
            if (filt != null) {
                Collection crits = filt.criteria();
                if (crits != null && crits.size() > 0) {
                    for (Iterator it = crits.iterator(); it.hasNext();) {

                        FilterCriterion crit = (FilterCriterion) it.next();
                        if (crit == null) {
                            continue;
                        }

                        String critName = crit.getAttrName();
                        if (critName == null || !CmdArguments.RECURSIVE.equals(critName)) {
                            continue;
                        }

                        Object filtValue = crit.getValue();
                        if (!(filtValue instanceof Boolean)) {
                            continue;
                        }

                        it.remove();
                        if (((Boolean) filtValue).booleanValue()) {
                            recursive = true;
                        }
                        break;
                    }
                }
            }
        }

        List retBaseIds = new Vector();
        if (recursive || recursiveViaParentHier) {
            recursiveQuery(retBaseIds, admObj, admChildClass, relationships, recursiveViaParentHier);
        } else if (admChildClass.equals(RoleSection.class)) {
            queryRoleSections(retBaseIds, relationships, admObj, isDefault, isMultiple);
        } else {
            // Now we have Primary and Secondary object classes
            // Try to find another command implementation
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admObj, admChildClass);
            if ((cmd instanceof QueryChildrenCmd)
                    || ((cmd instanceof AdmDebugCmd) && (((AdmDebugCmd) cmd).getNestedCmd() instanceof QueryChildrenCmd))) {
                // In other words - we didn't find any specific QUERY_CHILDREN
                // implementation. So defer to Relatable.QUERY_RELS
                cmd = AdmCmd.getCmd(Relatable.QUERY_RELS, admObj, admChildClass);
            }

            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, getAttrValue(CmdArguments.ADM_CHILD_CLASS));
            cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
            cmd.setAttrValue(CmdArguments.RELATIONSHIPS, getAttrValue(CmdArguments.RELATIONSHIPS));
            cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
            cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT, getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT));
            cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE));
            cmd.setAttrValue("COUNT", getAttrValue("COUNT"));
            if (getAttrValue(AdmAttrNames.FILTER_OUT_STREAMS) != null
                    && (((Boolean) getAttrValue(AdmAttrNames.FILTER_OUT_STREAMS)).booleanValue())) {
                Filter filter = new FilterImpl();
                filter.criteria().add(new FilterCriterion(AdmAttrNames.WSET_IS_STREAM, "Y", QueryConstants.NOT));
                cmd.setAttrValue(CmdArguments.FILTER, filter);
            }

            Object result = cmd.execute();

            // Transmit attributes from internal Command to self
            if (cmd instanceof QCWorksetToRequirementCmd) {
                Object containerDetails = cmd.getAttrValue(CmdArguments.CONTAINER_DETAILS);
                if (containerDetails != null) {
                    setAttrDef(new CmdArgDef(CmdArguments.CONTAINER_DETAILS, false, List.class));
                    setAttrValue(CmdArguments.CONTAINER_DETAILS, containerDetails);
                }
            }
            
            // Pass back any maximum record count if needed.
            if (original_filter != null) {
            	FilterImpl used_filter = (FilterImpl)cmd.getAttrValue(CmdArguments.FILTER);
            	if (used_filter != null) {
            		original_filter.setMaximumFound(used_filter.getMaximumFound());
            	}
            }

            return result;
        }

        return retBaseIds;
    }

    private void recursiveQuery(List retBaseIds, AdmObject admObj, Class admChildClass, boolean relationships,
            boolean recursiveViaParentHier) throws DBIOException, DimBaseException, AdmException {
        // First look for SuperQuery supported 'DEEP' queries
        if (((admObj instanceof DimDirectory) && (admChildClass.equals(Item.class) || admChildClass.equals(ItemFile.class)))
                || ((admObj instanceof Part) && (admChildClass.equals(Item.class) || admChildClass.equals(ItemFile.class)))) {
            /*
             * The tests against the filter below are used to determine which
             * query to use for the recursive item. If the filter only contains
             * a criteria of "FILTER_I_LATEST" (latest item revisions only) then
             * QueryChildren should be called.
             */
            boolean useSuperQuery = true;
            FilterImpl filter = (FilterImpl) getAttrValue(CmdArguments.FILTER);
            if (filter != null) {
                filter = (FilterImpl) filter.clone();
                if (filter.criteria().size() == 1 && filter.orders().size() == 0) {
                    Iterator it = filter.criteria().iterator();
                    FilterCriterion crit = (FilterCriterion) it.next();
                    if (CmdArguments.FILTER_I_LATEST.equals(crit.getAttrName())) {
                        useSuperQuery = false;
                    }
                }
            }

            if (useSuperQuery) {
                // This query that is used here does not work with DB2 or SQL
                // Server...
                Debug.println("Warning: Using query that may not work with DB2 or SQL Server.");
                QueryRelsCmd.staticExecute(retBaseIds, admObj, admChildClass,
                        QueryRelsCmd.staticBaseUid(admObj, admChildClass, (WorkSet) getAttrValue(CmdArguments.WORKSET)), true,
                        true, filter, relationships, ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT)).booleanValue(),
                        ((Boolean) getAttrValue("COUNT")).booleanValue(), AdmUidObject.class.isAssignableFrom(admChildClass));
            } else {
                // This is the performance query that should be used when
                // recursively quering items in a directory
                // structure.
                QueryRelsCmd.staticExecuteRecursiveItemsForDir(retBaseIds, admObj, admChildClass,
                        QueryRelsCmd.staticBaseUid(admObj, admChildClass, (WorkSet) getAttrValue(CmdArguments.WORKSET)));
            }

            return;
        }

        // P Smith 31 Mar 2004
        // Use the defined query for finding all sub dirs for a parent dir
        // recursively ie use cmds.relatable.QCDimDirToDimDirCmd
        if (admObj instanceof DimDirectory && admChildClass.equals(DimDirectory.class)) {
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admObj, admChildClass);
            cmd.setAttrValue(CmdArguments.RECURSIVE, Boolean.TRUE);
            List allDirs = (List) cmd.execute();
            retBaseIds.addAll(allDirs);
            return;
        }

        // Now look for other optimized queries...
        if (admObj instanceof Product) {
            if (admChildClass.equals(Part.class)) {
                if (!recursiveViaParentHier) {
                    DRSClientQueryProductPartsRecursive drs = new DRSClientQueryProductPartsRecursive(DRSUtils.getLCNetClntObject());
                    drs.setProductName(Encoding.escapeSQL(admObj.getAdmSpec().toString()));
                    DRSOutputDataExtractor output = new DRSQuery(drs).execute();
                    if (!output.isResultEmpty()) {
                        int[] partUids = output.getIntValues(DRSParams.PART_UIDS);
                        String[] partSpecs = output.getStringValues(DRSParams.PART_SPECS);
                        int[] parentPartUids = output.getIntValues(DRSParams.PARENT_PART_UIDS);
                        if (partUids != null && partUids.length > 0) {
                            for (int i = 0; i < partUids.length; i++) {
                                QueryRelsCmd.addRelation(
                                        retBaseIds,
                                        relationships,
                                        AdmHelperCmd.newAdmBaseId(parentPartUids[i], admChildClass),
                                        AdmHelperCmd.newAdmBaseId(partUids[i], admChildClass, null,
                                                AdmHelperCmd.newAdmBaseId(partSpecs[i], admChildClass, null, null)));

                            }
                        }
                    }
                    return;
                }
            }
        }

        // If still here then recurse progmatically
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admObj);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, getAttrValue(CmdArguments.ADM_CHILD_CLASS));
        cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
        cmd.setAttrValue(CmdArguments.RELATIONSHIPS, getAttrValue(CmdArguments.RELATIONSHIPS));
        cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
        cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT, getAttrValue(AdmAttrNames.RELTYPE_IS_DEFAULT));
        cmd.setAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE, getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE));
        List kids = (List) cmd.execute();
        retBaseIds.addAll(kids);
        if (recursiveViaParentHier) {
            cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, admObj);
            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, admObj.getClass());
            cmd.setAttrValue(CmdArguments.WORKSET, getAttrValue(CmdArguments.WORKSET));
            kids = (List) cmd.execute();
        }

        AdmBaseId childId = null;
        Object kid = null;
        for (int i = 0; i < kids.size(); i++) {
            kid = kids.get(i);
            if (kid instanceof Relationship) {
                childId = ((Relationship) kid).getAdmBaseId().get(1);
            } else {
                childId = (AdmBaseId) kid;
            }

            cmd = AdmCmd.getCmd(Creatable.GET_OBJECT, childId.getObjType());
            cmd.setAttrValue(CmdArguments.ADM_BASE_ID, childId);
            recursiveQuery(retBaseIds, (AdmObject) cmd.execute(), admChildClass, relationships, recursiveViaParentHier);
        }
    }

    private void queryRoleSections(List retBaseIds, boolean relationships, AdmObject parent, boolean isDefault, boolean isMultiple)
            throws DBIOException, DimBaseException, AdmException {
        if ((retBaseIds == null) || (parent == null)) {
            throw new DBIOException("Error, invalid parameter when querying default role section.");
        }

        if (isMultiple) {
            // Due to an inconsistency between the way we and
            // PC Client handles errors in getting the default
            // role section, we are currently going to hard
            // code returning $ALL by default if multiple.
            // Note: original references to isMultiple remain
            QueryRelsCmd.addRelation(retBaseIds, relationships, parent.getAdmBaseId(),
                    AdmHelperCmd.newAdmBaseId(Constants.ALL_ATTRS, RoleSection.class, parent.getAdmBaseId()));
            return;
        }

        AdmUidObject uidObject = null;
        AdmUidObject typeObject = null;

        if (parent instanceof Type) {
            typeObject = (AdmUidObject) parent;
        } else {
            uidObject = (AdmUidObject) parent;
            typeObject = (AdmUidObject) AdmHelperCmd.getAttributeValue(parent, AdmAttrNames.TYPE);
        }

        Cmd cmd = null;
        String status = AdmAttrNames.STATUS;
        if (!isDefault || isMultiple) {
            cmd = AdmCmd.getCmd("RPC GetRSNames");
        } else {
            cmd = AdmCmd.getCmd("RPC GetRSAttrs");
            cmd.setAttrValue("role", RPCPcmsGetRSAttrs.DEFAULT);
            cmd.setAttrValue("user", getCurRootObj(User.class).getId());
            // use next status for correct determination of default role section
            if (uidObject != null) {
                // check we have next status in the object
                if (parent.getAttrValue(AdmAttrNames.NEXT_STATUS) != null) {
                    status = AdmAttrNames.NEXT_STATUS;
                }
            }
        }

        cmd.setAttrValue("uidObject", uidObject);
        cmd.setAttrValue("typeObject", typeObject);
        cmd.setAttrValue("status", AdmHelperCmd.getAttributeValue(parent, status));

        String result = (String) cmd.execute();
        if (!result.startsWith(Constants.SERVER_OK)) {
            return;
        }

        if (isDefault) {
            if (isMultiple) {
                boolean hasAllRoleSec = false;
                StringTokenizer st = new StringTokenizer(result.substring(Constants.SERVER_OK.length()), "\007");
                while (st.hasMoreTokens() && (!hasAllRoleSec)) {
                    if (st.nextToken().equals(Constants.ALL_ROLE_ATTRS)) {
                        hasAllRoleSec = true;
                    }
                }

                if (hasAllRoleSec) {
                    QueryRelsCmd.addRelation(retBaseIds, relationships, parent.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(Constants.ALL_ROLE_ATTRS, RoleSection.class, parent.getAdmBaseId()));
                } else {
                    QueryRelsCmd.addRelation(retBaseIds, relationships, parent.getAdmBaseId(),
                            AdmHelperCmd.newAdmBaseId(Constants.ALL_ATTRS, RoleSection.class, parent.getAdmBaseId()));
                }
            } else {
                QueryRelsCmd.addRelation(
                        retBaseIds,
                        relationships,
                        parent.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(result.substring(Constants.SERVER_OK.length()), RoleSection.class,
                                parent.getAdmBaseId()));
            }
        } else {
            StringTokenizer st = new StringTokenizer(result.substring(Constants.SERVER_OK.length()), "\007");
            while (st.hasMoreTokens()) {
                QueryRelsCmd.addRelation(retBaseIds, relationships, parent.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(st.nextToken(), RoleSection.class, parent.getAdmBaseId()));
            }
        }
    }
}

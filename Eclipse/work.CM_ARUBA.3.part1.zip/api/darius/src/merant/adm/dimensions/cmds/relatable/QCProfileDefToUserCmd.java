/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ProfileDefinition;
import merant.adm.dimensions.objects.RelationshipType;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Queries all User's related to the ProfileDefinition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>CANDIDATE {Boolean}</dt>
 *      <dd>
 *          If true, returns candidate users,
 *          otherwise users that hold the specified profile
 *      </dd>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Floz
 */
public class QCProfileDefToUserCmd extends QueryRelsCmd {
    public QCProfileDefToUserCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.CANDIDATE, false, Boolean.TRUE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ProfileDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(User.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        List ret = new Vector();

        AdmUidObject relType = null;
        if ((filter != null) && filter.hasAttr(CmdArguments.ADM_REL_TYPE)) {
            relType = (AdmUidObject) filter.get(CmdArguments.ADM_REL_TYPE);
        }

        queryProfileDefinitionUsers(ret, relationships, admObj, filter, relType);

        return ret;
    }

    private void queryProfileDefinitionUsers(List ret, boolean relationships, AdmObject profileDef, FilterImpl filter,
            AdmUidObject relType) throws DBIOException, DimBaseException, AdmException {
        if ((ret == null) || (profileDef == null) || (filter == null)) {
            throw new DBIOException("Error, invalid parameter when querying assigned users.");
        }

        Cmd cmd = getCmd("PcmsGetUserProfiles");
        cmd.setAttrValue("profile", profileDef.getId());

        String result = (String) cmd.execute();
        if (result.startsWith(Constants.SERVER_OK)) {
            String curUserId = "";
            String curAssignType = "";
            String curCapability = "";
            AdmObject realRelType = null;
            AdmObject delegatedRelType = null;
            AdmObject curRelType = null;
            AdmObject newRel = null;
            StringTokenizer st = new StringTokenizer(result.substring(Constants.SERVER_OK.length()), "\007");
            while (st.hasMoreTokens()) {
                curUserId = st.nextToken();
                curAssignType = st.nextToken();
                curCapability = st.nextToken();
                if (curAssignType.equals("Y")) {
                    if (realRelType == null) {
                        realRelType = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_REAL,
                                RelationshipType.class));
                    }

                    curRelType = realRelType;
                } else if ((!curAssignType.equals("O")) && (!curAssignType.equals("P"))) {
                    if (delegatedRelType == null) {
                        delegatedRelType = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(Constants.RELTYPE_UID_DELEGATED,
                                RelationshipType.class));
                    }

                    curRelType = delegatedRelType;
                }

                newRel = addRelation(ret, relationships, profileDef.getAdmBaseId(),
                        AdmHelperCmd.newAdmBaseId(curUserId, User.class, null, null), curRelType);

                if (newRel != null) {
                    newRel.setAttrValue(AdmAttrNames.REL_CAPABILITY, curCapability);
                }
            }
        }
    }
}

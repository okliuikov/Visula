/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;

/**
 * This command will logout of a Dimensions server.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>none</dt>
 * <b>Returns:</b>
 * <code><dl>
 *  <dt>{void}</dt>
 * </dl></code>
 * @author Floz
 */
public class LogoutCmd extends AdmCmd {
    public LogoutCmd() throws AttrException {
        super();
        setAlias(Server.LOGOUT);
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        DimSystem.getSystem().getSessionBean().logout();
        return null;
    }
}

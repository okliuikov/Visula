/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010 Serena. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import merant.adm.dimensions.cmds.CmdBuilder;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will demote a Dimensions object to a lower stage in GSL.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_LIST {AdmObject}</dt><dd>List of Dimensions objects</dd>
 *  <dt>COMMENT {String}</dt><dd>Comment</dd>
 *  <dt>DEPLOY {Boolean}</dt><dd>
 *      Tri-state, Boolean which specifies deployment to all default areas when
 *      specified as Boolean.TRUE and no deployment at all when Boolean.FALSE.
 *      When not specified at all, it defaults to null.  In which case, any
 *      deployment defers to file areas specified by DEPLOY_AREAS.</dd>
 *  <dt>DEPLOY_AREAS {List}</dt><dd>
 *      List of specific file area objects to deploy on demotion.
 *      Only applies when no value has been specified for DEPLOY.</dd>
 *  <dt>SCHEDULE_DATETIME</dt><dd>ISO8601 format in the UTC timezone - 'YYYY'-'MM'-'DD'T'HH24':'MI':'SS'.'sss'Z'</dd>
 *  <dt>STAGE_ID</dt><dd>Specific stage id to demote the selected object(s) to</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {Boolean}</dt><dd>Whether child requests should be deployed as well</dd>
 *  <dt>WORKSET {String}</dt><dd>Workset name.  If not provided, current workset is taken</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author DineshB, PeterB
 */
public class DemoteToStageCmd extends RPCExecCmd {
    private File userFile = null;

    public DemoteToStageCmd() throws AttrException {
        super();
        setAlias(Actionable.DEMOTE_TO_STAGE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.COMMENT, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DEPLOY, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.ITEM, false, AdmObject.class));
        // Only used when demoting requests
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.DEPLOY_AREAS, false, List.class)); // list of file area objects
        setAttrDef(new CmdArgDef(CmdArguments.SCHEDULE_DATETIME, false, String.class)); // ISO8601 format in the UTC timezone -
                                                                                        // 'YYYY'-'MM'-'DD'T'HH24':'MI':'SS'.'sss'Z'
        // Only used when CM is integrated with SDA
        setAttrDef(new CmdArgDef(CmdArguments.SDA_PROCESS, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.SDA_COMPONENTS, false, Map.class));

    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        String obj = executeRpc();
        try {
            if (userFile != null && userFile.exists()) {
                userFile.delete();
            }
        } catch (Exception e) {
            Debug.error(e);
            throw new AdmException(e);
        }

        return obj;
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((attrValue != null) && (!(attrValue instanceof Item)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof Baseline))) {
                throw new AttrException("Error: DeployToStageCmd - object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List<AdmObject> admObjects = (List<AdmObject>) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        String stageID = (String) getAttrValue(AdmAttrNames.STAGE_ID);
        String comment = (String) getAttrValue(CmdArguments.COMMENT);
        List<String> objectListAsString = new ArrayList<String>();
        List<AdmObject> areas = (List<AdmObject>) getAttrValue(CmdArguments.DEPLOY_AREAS);
        Boolean deploy = (Boolean) getAttrValue(AdmAttrNames.DEPLOY);
        String sdaProcess = (String) getAttrValue(CmdArguments.SDA_PROCESS);
        Map<String, String> sdaComponents = (Map<String, String>) getAttrValue(CmdArguments.SDA_COMPONENTS);

        boolean useUserFileNameQualifier = false;
        if (admObj == null && (admObjects == null || admObjects.size() == 0)) {
            throw new DimMandatoryAttributeException("Error: Object or list of objects must be specified.");
        }
        // We will allow either admObject or list of admObject. Not both.
        if (admObj != null && (admObjects != null && admObjects.size() > 0)) {
            throw new DimMandatoryAttributeException("Error: Please provide either object or list of objects. Not both.");
        }

        if (admObjects != null && admObjects.size() > 1) {
            useUserFileNameQualifier = true;
        }
        AdmObject tempAdmObj = null;

        Boolean traverseChildRequests = (Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS);
        if (admObj != null) {
            tempAdmObj = admObj;
        } else {
            tempAdmObj = admObjects.get(0);
        }
        try {
            if (useUserFileNameQualifier) {
                if (admObjects.get(0) instanceof Item || admObjects.get(0) instanceof Baseline
                        || admObjects.get(0) instanceof ChangeDocument) {
                    for (int i = 0; i < admObjects.size(); i++) {
                        objectListAsString.add(admObjects.get(i).getAdmSpec().getSpec());
                    }
                } else {
                    throw new UnsupportedOperationException("The objects selected cannot be promoted. ");
                }
                userFile = preview ? null : PromoteToStageCmd.getUserFile(objectListAsString);
            }

            StringBuffer sb = new StringBuffer();
            if (tempAdmObj instanceof Item) {
                sb.append("DMI ");
            } else if (tempAdmObj instanceof ChangeDocument) {
                sb.append("DMRQ ");
            } else if (tempAdmObj instanceof Baseline) {
                sb.append("DMBL ");
            } else {
                throw new UnsupportedOperationException("The object selected cannot be demoted. ");
            }

            if (!useUserFileNameQualifier) {
                sb.append(Encoding.escapeDMCLI(tempAdmObj.getAdmSpec().getSpec()));
            }
            if (stageID != null && stageID.length() > 0) {
                sb.append(" /STAGE=" + Encoding.escapeDMCLI(stageID));
            }
            if (project != null) {
                sb.append(" /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec()));
            }
            if (comment != null && comment.length() > 0) {
                sb.append(" /COMMENT=" + Encoding.escapeDMCLI(comment));
            }
            if (traverseChildRequests != null) {
                if (traverseChildRequests.booleanValue()) {
                    sb.append(" /NOCANCEL_TRAVERSE");
                } else {
                    sb.append(" /CANCEL_TRAVERSE");
                }
            }
            String scheduled_date = (String) getAttrValue(CmdArguments.SCHEDULE_DATETIME);
            if (scheduled_date != null) {
                sb.append(" /DEPLOY_START_TIME=\"");
                sb.append(scheduled_date);
                sb.append("\"");
            }

            if (useUserFileNameQualifier) {
                sb.append(" /USER_FILENAME="
                        + Encoding.escapeDMCLI(preview ? "selected-objects.listingfile" : userFile.getAbsolutePath()));
            }

            //
            // 2012-04-25 Floz: Help for DEF210324:
            // Logic for demotion deployment as of CM 12.2.1.
            // Process DEPLOY/DEPLOY_AREAS thus:
            // 1. DEPLOY is specified and is Boolean.TRUE
            // NOTE: DEPLOY_AREAS is ignored
            // COMMAND: /DEPLOY
            // RESULT: Deployment to default areas
            // 2. DEPLOY is specified and is Boolean.FALSE
            // a) DEPLOY_AREAS is populated
            // NOTE: Contrary instruction that we leave
            // to the server to sort out
            // COMMAND: /AREA_LIST=(<areas>) /NODEPLOY
            // RESULT: Exception thrown by server
            // b) DEPLOY_AREAS is empty
            // COMMAND: /NODEPLOY
            // RESULT: No deployment occurs
            // 3. DEPLOY is not specified and is null.
            // a) DEPLOY_AREAS is populated
            // NOTE: We pass area list and rely on the
            // deployment flag as being assumed
            // by implication by the server
            // COMMAND: /AREA_LIST=(<areas>)
            // RESULT: Deployment to the specified areas
            // b) DEPLOY_AREAS is empty
            // COMMAND: /NODEPLOY
            // RESULT: No deployment occurs
            //
            if ((deploy != null) && deploy.booleanValue()) {
                sb.append(" /DEPLOY");
            } else {
                if (areas != null && areas.size() > 0) {
                    sb.append(" /AREA_LIST=(");
                    String area = "";

                    for (int i = 0; i < areas.size(); i++) {
                        area = areas.get(i).getId();
                        if (i > 0) {
                            sb.append(",");
                        }
                        sb.append(Encoding.escapeDMCLI(area));
                    }
                    sb.append(")");
                }
                if ((areas != null && areas.size() == 0) || (deploy != null && !deploy.booleanValue())) {
                    sb.append(" /NODEPLOY");
                }
            }

            if (sdaProcess != null && sdaProcess.length() > 0) {
                sb.append(" /SDA_PROCESS=").append(Encoding.escapeDMCLI(sdaProcess));
            }

            if (sdaComponents != null && sdaComponents.size() > 0) {
                sb.append(CmdBuilder.createParameter("/SDA_COMPONENTS", sdaComponents));
            }

            _cmdStr = sb.toString();
        } catch (IOException ioe) {
            throw new AdmException(ioe);
        }
    }
}

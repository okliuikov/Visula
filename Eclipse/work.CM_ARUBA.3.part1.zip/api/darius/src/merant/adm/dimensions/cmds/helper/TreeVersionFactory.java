package merant.adm.dimensions.cmds.helper;

import java.util.HashMap;

import merant.adm.dimensions.server.drs.objects.TreeVersion;

public class TreeVersionFactory {
    private HashMap<Integer, TreeVersion> cachedTreeVersions = new HashMap<Integer, TreeVersion>();

    static TreeVersion makeNewTreeVersion(final long treeUid, final int forestVersion, final int changeSetUid,
            final int treeVersion, final int treeClass, final String treeSpec) {
        TreeVersion tv = new TreeVersion();
        tv.setForestVersion(forestVersion);
        tv.setChangeSetUid(changeSetUid);
        tv.setTreeUid(treeUid);
        tv.setTreeVersion(treeVersion);
        tv.setTreeClass(treeClass);
        tv.setTreeSpec(treeSpec);
        return tv;
    }

    TreeVersion createTreeVersion(final long treeUid, final int forestVersion, final int changeSetUid, final int treeVersion,
            final int treeClass, final String treeSpec) {
        TreeVersion tv = cachedTreeVersions.get(forestVersion);
        if (tv == null) {
            tv = makeNewTreeVersion(treeUid, forestVersion, changeSetUid, treeVersion, treeClass, treeSpec);
            cachedTreeVersions.put(forestVersion, tv);
        }

        return tv;
    }
}

package merant.adm.dimensions.cmds.helper;

import com.serena.dmnet.Constants;
import com.serena.dmnet.drs.DRSClientEclipseGetProjects;
import com.serena.dmnet.drs.DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.creatable.GetObjectsCmd;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpec;
import merant.adm.dimensions.objects.core.AdmSpecTwin;
import merant.adm.dimensions.objects.core.AdmUidTwin;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;

import java.util.ArrayList;
import java.util.List;

public class EclipseGetProjectsHelper {

    public enum WorkSetType {
        FAVOURITE_WORKSET("WF"),
        RECENT_WORKSET("WR"),
        ALL_BASELINES("B"),
        PROJECT_GROUPS("G"),
        ECLIPSE_CONTAINERS("C"),
        SINGLE_PROJECT("S"),
        OTHER("O"),
        ALL_WORKSETS("W"),
        STREAM("S"),
        BASELINE("B"),
        PROJECTS("P");

		private final String name;

		private WorkSetType(String s) {
			name = s;
		}

		public String toString() {
			return this.name;
		}
	}

	public static final String EMPTY_STRING = "";

    public static List<AdmObject> getProject(WorkSetType objClasses, WorkSetType objTypes, int recentMaxCount,
            String includeClosedFilter) throws AdmException {

        DRSClientEclipseGetProjects drs = new DRSClientEclipseGetProjects(DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.ExecutePre145);

		List<AdmObject> listOfProjects = new ArrayList<AdmObject>();

		drs.setObjClasses(objClasses.name);
		drs.setFilter(EMPTY_STRING);
		drs.setProductID(EMPTY_STRING);
		drs.setObjID(EMPTY_STRING);
		drs.setObjTypes(objTypes.name);
		drs.setProjectID(EMPTY_STRING);
		drs.setRecentMaxCount(recentMaxCount);
		drs.setIncludeClosedFilter(includeClosedFilter);

		DRSUtils.execute(drs);
		if (drs.hasData()) {
			String[] containerClassess = drs.getContainerClass();
			String[] productIDs = drs.getProductId();
			String[] containerIds = drs.getContainerId();
			int[] containerUids = drs.getContainerUid();
			int[] scopeUids = drs.getScopeUid();
			String[] projectTypes = drs.getProjectType();
			int[] markerUIDs = drs.getMarkerUid();
			String[] markerFullPaths = drs.getMarkerFullPath();

			for (int i = 0; i < containerClassess.length; ++i) {
				final String containerClass = containerClassess[i];
				final String productId = productIDs[i];
				final String containerId = containerIds[i];
				final int containerUid = containerUids[i];
				final int scopeUid = scopeUids[i];
				final String projectType = projectTypes[i];
				final int markerUID = markerUIDs[i];
				final String markerFullPath = markerFullPaths[i];

				AdmObject admObject = null;

				if ((containerClass.equals(WorkSetType.PROJECTS.name) || containerClass.equals(WorkSetType.STREAM.name))
						&& markerUID == -1) {
					admObject = createObject(containerUid, productId + ":" + containerId, WorkSet.class);

					if (containerClass.equals(WorkSetType.PROJECTS.name)) {
						admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, false);
						admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, containerClass);
						admObject.setAttrValue(AdmAttrNames.DIRECTORY, scopeUid);
						admObject.setAttrValue(AdmAttrNames.TYPE, projectType);
					} else if (containerClass.equals(WorkSetType.STREAM.name)) {
						admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, true);
						admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, containerClass);
						admObject.setAttrValue(AdmAttrNames.DIRECTORY, scopeUid);
						admObject.setAttrValue(AdmAttrNames.TYPE, projectType);
					}
				} else if (containerClass.equals(WorkSetType.BASELINE.name) && markerUID == -1) {
					admObject = createObject(containerUid, productId + ":" + containerId, Baseline.class);
					admObject.setAttrValue(AdmAttrNames.FULL_PATH_NAME, markerFullPath);
					admObject.setAttrValue(AdmAttrNames.IDE_DM_UID, scopeUid);
					admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, containerClass);
				}
				if (admObject != null) {
					listOfProjects.add(admObject);
				}
			}
		}
		return listOfProjects;
	}

	public static List<AdmObject> getProject(WorkSetType objClasses, int recentMaxCount) throws AdmException {

        DRSClientEclipseGetProjects drs = new DRSClientEclipseGetProjects(DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.ExecutePre145);

		List<AdmObject> listOfProjects = new ArrayList<AdmObject>();

		drs.setObjClasses(objClasses.name);
		drs.setFilter(EMPTY_STRING);
		drs.setProductID(EMPTY_STRING);
		drs.setObjID(EMPTY_STRING);
		drs.setObjTypes(EMPTY_STRING);
		drs.setProjectID(EMPTY_STRING);
		drs.setRecentMaxCount(recentMaxCount);
		drs.setIncludeClosedFilter("");

		DRSUtils.execute(drs);
		if (drs.hasData()) {
			String[] containerClasses = drs.getContainerClass();
			String[] productIDs = drs.getProductId();
			String[] containerIds = drs.getContainerId();
			int[] containerUids = drs.getContainerUid();
			int[] scopeUids = drs.getScopeUid();
			int[] markerUids = drs.getMarkerUid();
			String[] markerFullPaths = drs.getMarkerFullPath();

			for (int i = 0; i < containerClasses.length; ++i) {
				final String containerObjClass = containerClasses[i];
				final String productId = productIDs[i];
				final String containerId = containerIds[i];
				final int containerUid = containerUids[i];
				final int scopeUid = scopeUids[i];
				final int markerUid = markerUids[i];
				final String markerFullPath = markerFullPaths[i];

				AdmObject admObject = null;

				if ((containerObjClass.equals(WorkSetType.PROJECTS.name) || containerObjClass.equals(WorkSetType.STREAM.name))
						&& markerUid == -1) {
					admObject = createObject(containerUid, productId + ":" + containerId, WorkSet.class);

					if (containerObjClass.equals(WorkSetType.PROJECTS.name)) {
						admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, false);
						admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, containerObjClass);
					} else if (containerObjClass.equals(WorkSetType.STREAM.name)) {
						admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, true);
						admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, containerObjClass);
					}
				} else if (containerObjClass.equals(WorkSetType.BASELINE.name) && markerUid == -1) {
					admObject = createObject(containerUid, productId + ":" + containerId, Baseline.class);
					admObject.setAttrValue(AdmAttrNames.FULL_PATH_NAME, markerFullPath);
					admObject.setAttrValue(AdmAttrNames.IDE_DM_UID, scopeUid);
					admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, containerObjClass);
				}
				if (admObject != null) {
					listOfProjects.add(admObject);
				}
			}
		}
		return listOfProjects;
	}

    public static List<AdmObject> getChild(WorkSetType ObjClasses, int recentMaxCount) throws AdmException {

        DRSClientEclipseGetProjects drs = new DRSClientEclipseGetProjects(DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.ExecutePre145);

        List<AdmObject> listOfProjects = new ArrayList<AdmObject>();

        drs.setObjClasses(ObjClasses.name);
        drs.setFilter(EMPTY_STRING);
        drs.setProductID(EMPTY_STRING);
        drs.setObjID(EMPTY_STRING);
        drs.setObjTypes(EMPTY_STRING);
        drs.setProjectID(EMPTY_STRING);
        drs.setRecentMaxCount(recentMaxCount);
        drs.setIncludeClosedFilter("");

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            String[] containerClassess = drs.getContainerClass();
            String[] productIDs = drs.getProductId();
            int[] containerUids = drs.getContainerUid();
            String[] projectIDs = drs.getProjectId();
            int[] markerUids = drs.getMarkerUid();
            int[] markerSpecUids = drs.getMarkerSpecUid();
            String[] markerFullPaths = drs.getMarkerFullPath();

            for (int i = 0; i < containerClassess.length; ++i) {
                final String containerClass = containerClassess[i];
                final String productId = productIDs[i];
                final int containerUid = containerUids[i];
                final String projectId = projectIDs[i];
                final int markerSpecUid = markerSpecUids[i];
                final int markerUid = markerUids[i];
                final String markerFullPath = markerFullPaths[i];

                AdmObject admObject = null;

                if (markerUid != -1) {
                    // Construct an AdmObject representing the project marker item
                    // Note that we use a fake object spec using the Eclipse Project id instead of the real spec of the item
                    admObject = createMarkerItem(markerUid, productId + ":" + projectId + ".A-PROJECT;1", containerClass, containerUid);
                    admObject.setAttrValue(AdmAttrNames.PRODUCT_NAME, productId);
                    admObject.setAttrValue(AdmAttrNames.ITEMFILE_FILENAME, projectId);
                    admObject.setAttrValue(AdmAttrNames.PARENT_DIR_NAME, markerFullPath);
                    admObject.setAttrValue(AdmAttrNames.SPEC_UID, Long.valueOf(markerSpecUid));
                }
                if (admObject != null) {
                    listOfProjects.add(admObject);
                }
            }
        }
        return listOfProjects;
    }

	private static AdmObject createObject(int outUid, String outSpec, Class<?> clazz) throws AdmException {
		AdmUidTwin baseId = new AdmUidTwin(outUid, clazz);
		AdmSpec spec = new AdmSpec(outSpec, clazz);
		baseId.setTwin(spec);
		return GetObjectsCmd.buildNewObject(baseId);
	}

	private static AdmObject createMarkerItem(final int itemUid, final String itemSpec, final String containerClass,
			final int containerUid) throws AdmException {
		AdmBaseId scope;
		if (containerClass.equals(WorkSetType.PROJECTS.name) || containerClass.equals(WorkSetType.STREAM.name)) {
		    scope = AdmHelperCmd.newAdmBaseId(containerUid, WorkSet.class);
		} else {
			scope = AdmHelperCmd.newAdmBaseId(containerUid, Baseline.class);
		}
		AdmSpecTwin specTwin = new AdmSpecTwin(itemSpec, ItemFile.class);
		AdmBaseId baseId = AdmHelperCmd.newAdmBaseId(itemUid, ItemFile.class, scope, specTwin);
		return GetObjectsCmd.buildNewObject(baseId);
	}

    public static List<AdmObject> getFavorites() throws AdmException {
        return getFavoritesOrRecents(false, 0);
    }

    public static List<AdmObject> getRecents(int recentMaxCount) throws AdmException {
        return getFavoritesOrRecents(true, recentMaxCount);
    }

    public static List<AdmObject> getSingleProjects(String filter, String productId, String objId, String projectId,
            boolean excludeClosedWs, boolean excludeClosedBl) throws AdmException {
        return getWorksets(DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.GetSingleProjects, WorkSetType.SINGLE_PROJECT.name,
                filter, productId, objId, projectId, excludeClosedWs, excludeClosedBl);
    }

    public static List<AdmObject> getProjectGroups(String filter, String productId, String objId, String projectId,
            boolean excludeClosedWs, boolean excludeClosedBl) throws AdmException {
        return getWorksets(DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.GetProjectGroups, WorkSetType.PROJECT_GROUPS.name,
                filter, productId, objId, projectId, excludeClosedWs, excludeClosedBl);
    }

    public static List<AdmObject> getProjectContainers(String filter, String productId, String objId, String projectId,
            boolean excludeClosedWs, boolean excludeClosedBl) throws AdmException {
        return getWorksets(DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.GetProjectContainers, WorkSetType.ECLIPSE_CONTAINERS.name,
                filter, productId, objId, projectId, excludeClosedWs, excludeClosedBl);
    }

    public static List<AdmObject> getEclMarkers(int workSetUid, String product, String typeOfContainer) throws AdmException {

        DRSClientEclipseGetProjects drs = new DRSClientEclipseGetProjects(DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.GetEclMarkers);

        List<AdmObject> markers = new ArrayList<AdmObject>();

        drs.setWorkSetUid(workSetUid);
        DRSUtils.execute(drs);

        if (drs.hasData()) {
            int[] uids = drs.getUids();
            int[] specUids = drs.getSpecUids();
            String[] filenames = drs.getFilenames();
            String[] dirnames = drs.getDirnames();

            for (int i = 0; i < uids.length; ++i) {

                final int uid = uids[i];
                final int specUid = specUids[i];
                final String filename = filenames[i];
                final String dirname = dirnames[i];

                String containerClass = WorkSetType.BASELINE.name;
                if (typeOfContainer.equals("PROJECT"))
                    containerClass = WorkSetType.PROJECTS.name;

                // Construct an AdmObject representing the project marker item
                // Note that we use a fake object spec using the Eclipse Project id instead of the real spec of the item
                AdmObject admObject = createMarkerItem(uid, product + ":" + filename + ".A-PROJECT;1", containerClass, workSetUid);
                admObject.setAttrValue(AdmAttrNames.PRODUCT_NAME, product);
                admObject.setAttrValue(AdmAttrNames.ITEMFILE_FILENAME, filename);
                admObject.setAttrValue(AdmAttrNames.PARENT_DIR_NAME, dirname);
                admObject.setAttrValue(AdmAttrNames.SPEC_UID, Long.valueOf(specUid));

                if (admObject != null) {
                    markers.add(admObject);
                }
            }
        }

        return markers;
    }

    private static List<AdmObject> getFavoritesOrRecents(boolean recents, int recentMaxCount) throws AdmException {
        
        EclipseGetProjectsQueryContext ctx = DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.GetFavorites;
        if (recents) {
            ctx = DRSClientEclipseGetProjects.EclipseGetProjectsQueryContext.GetRecents;
        }

        DRSClientEclipseGetProjects drs = new DRSClientEclipseGetProjects(ctx);

        if (recents) {
            drs.setRecentMaxCount(recentMaxCount);
        }

        List<AdmObject> data = new ArrayList<AdmObject>();

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] uids = drs.getUids();
            String[] specs = drs.getSpecs();
            int[] objTypes = drs.getOTypes();

            for (int i = 0; i < uids.length; ++i) {
                final int uid = uids[i];
                final String spec = specs[i];
                final int objType = objTypes[i];

                AdmObject admObject = createObject(uid, spec, WorkSet.class);
                boolean isStream = (objType == Constants.PCMS_STREAM);
                admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, isStream);
                admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, isStream ? WorkSetType.STREAM.name : WorkSetType.PROJECTS.name);

                if (admObject != null) {
                    data.add(admObject);
                }
            }
        }
        return data;
    }

    private static List<AdmObject> getWorksets(EclipseGetProjectsQueryContext ctx, String type,
            String filter, String productId, String objId, String projectId,
            boolean excludeClosedWs, boolean excludeClosedBl) throws AdmException {
        DRSClientEclipseGetProjects drs = new DRSClientEclipseGetProjects(ctx);

        drs.setFilter(filter);
        drs.setProductID(productId);
        drs.setObjID(objId);
        drs.setProjectID(projectId);

        if (excludeClosedWs) {
            drs.excludeClosedWokrsets();
        }

        if (excludeClosedBl) {
            drs.excludeClosedBaselines();
        }

        List<AdmObject> data = new ArrayList<AdmObject>();

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] uids = drs.getUids();
            int[] ideUids = drs.getIdeUids();
            String[] specs = drs.getSpecs();
            int[] objTypes = drs.getOTypes();

            for (int i = 0; i < uids.length; ++i) {
                final int uid = uids[i];
                final int ideUid = ideUids[i];
                final String spec = specs[i];
                final int objType = objTypes[i];

                AdmObject admObject = createObject(uid, spec, WorkSet.class);
                boolean isStream = (objType == Constants.PCMS_STREAM);
                admObject.setAttrValue(AdmAttrNames.WSET_IS_STREAM, isStream);
                admObject.setAttrValue(AdmAttrNames.PARENT_CLASS, isStream ? WorkSetType.STREAM.name : WorkSetType.PROJECTS.name);
                admObject.setAttrValue(AdmAttrNames.DIRECTORY, ideUid);
                admObject.setAttrValue(AdmAttrNames.TYPE, type);
                
                if (admObject != null) {
                    data.add(admObject);
                }
            }
        }
        return data;
    }

}

/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.serena.dmfile.SystemAttributeDefinition;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.Attribute;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.query.SuperQuery;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.LegacyCollections;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;

/**
 * This class contains helper methods for attribute operations. Uses optimized code for quering
 * attributes and coverts the attribute data to legacy objects that are still relied upon by
 * some code.
 */
public class AttributeHelper {

    private static final HashSet RESERVED_WORDS = new HashSet();
    private static final HashSet RESERVED_CHARS = new HashSet();

    private static List ATTRIBUTE_COLUMN_NAMES = new ArrayList();
    private static List VALIDSET_COLUMN_NAMES = new ArrayList();

    private static Map itemSysAttrMap = new HashMap();
    private static Map requestSysAttrMap = new HashMap();
    private static Map baselineSysAttrMap = new HashMap();
    private static Map projectSysAttrMap = new HashMap();
    static {
        initSysAttrsMap(itemSysAttrMap, Item.class);
        initSysAttrsMap(requestSysAttrMap, ChangeDocument.class);
        initSysAttrsMap(projectSysAttrMap, WorkSet.class);
        initSysAttrsMap(baselineSysAttrMap, Baseline.class);
    }

    // get from oracle 10g - SELECT keyword FROM v$reserved_words WHERE reserved='Y' AND length=1;
    // if the KEY_CHARS.length becomes too big in future, we need to put them in a list file.
    private static final String[] KEY_CHARS = { "+", "<", "^", ",", "/", "!", ":", "@", "=", "-", "[", "&", "|", ">", "]", ".",
            "*", ")", "(" };

    static {
        for (int i = 0; i < KEY_CHARS.length; i++) {
            RESERVED_CHARS.add(KEY_CHARS[i]);
        }

        // build up list of attribute names to query against the LocalAttributeDefinition object
        ATTRIBUTE_COLUMN_NAMES.add(AdmAttrNames.ID);
        ATTRIBUTE_COLUMN_NAMES.add(AdmAttrNames.ATTRDEF_ATTRTYPE);
        ATTRIBUTE_COLUMN_NAMES.add(AdmAttrNames.ATTRDEF_DATATYPE);
        ATTRIBUTE_COLUMN_NAMES.add(AdmAttrNames.ATTRDEF_PROMPT);
        ATTRIBUTE_COLUMN_NAMES.add(AdmAttrNames.ATTRDEF_VALIDSET_OBJ);
        ATTRIBUTE_COLUMN_NAMES.add(AdmAttrNames.ATTRDEF_LOVCOLUMN);

        // build up list of attribute names to query against any Validset objects.
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_DISPLAY_ORDER);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN1_VALUES);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN2_VALUES);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN3_VALUES);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN4_VALUES);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN5_VALUES);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN6_VALUES);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN7_VALUES);
        VALIDSET_COLUMN_NAMES.add(AdmAttrNames.VALIDSET_COLUMN8_VALUES);
    }

    // lazy initialisation of RESERVED_WORDS
    private static void init() {
        InputStream is = null;
        InputStreamReader isReader = null;
        BufferedReader reader = null;
        try {
            is = new AttributeHelper().getClass().getResourceAsStream("ReservedKeywords.list");
            isReader = new InputStreamReader(is, "UTF-8");
            reader = new BufferedReader(isReader);
            String line = reader.readLine();
            while (line != null) {
                line = line.trim();
                if (line.length() > 0 && !line.startsWith("#")) {
                    RESERVED_WORDS.add(line.toUpperCase());
                }
                line = reader.readLine();
            }
        } catch (UnsupportedEncodingException e1) {
            Debug.error(e1.getMessage());
        } catch (IOException e) {
            Debug.error("Cannot read ReservedKeywords.properties in AttributeHelp.getReservedWords()");
            Debug.error(e.getMessage());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    Debug.debug(e);
                }
            }
            if (isReader != null) {
                try {
                    isReader.close();
                } catch (IOException e) {
                    Debug.debug(e);
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    Debug.debug(e);
                }
            }
        }
    }

    /**
     * Gets an <code>Attribute</code> object from the object type and attribute number.
     * @param type
     *            AdmObject object type to query against.
     * @param attrNo
     *            int attribute number to query for.
     * @return Attribute object matching the parameters.
     */
    public static Attribute getOptimizedAttr(AdmObject type, int attrNo) throws AdmObjectException, AttrException, AdmException {

        Filter filter = new FilterImpl();
        filter.criteria().add(new FilterCriterion(AdmAttrNames.ATTRDEF_ATTRNO, Integer.valueOf(String.valueOf(attrNo))));
        Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, type);
        cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, LocalAttributeDefinition.class);
        cmd.setAttrValue(CmdArguments.FILTER, filter);

        // set attribute details that are needed from the object
        List attrNames = new ArrayList();
        attrNames.add(AdmAttrNames.ID);
        attrNames.add(AdmAttrNames.ATTRDEF_ATTRNO);
        attrNames.add(AdmAttrNames.ATTRDEF_ATTRTYPE);
        attrNames.add(AdmAttrNames.ATTRDEF_DEFAULT_VALUE);

        Attribute attr = null;
        List attrDefs = AdmHelperCmd.getObjects((List) cmd.execute(), attrNames);
        if (attrDefs != null && attrDefs.size() > 0) {
            attr = getAttributeObject((LocalAttributeDefinition) attrDefs.get(0));
        }
        return attr;
    }

    /**
     * Gets list of <code>LocalAttributeDefinition</code> objects related to a type and converts them to
     * <code>AttributeDefinition</code> objects. The attributes returned are ordered alphabetically by
     * the attributes prompt value.
     * @param type
     *            AdmObject to query for <code>LocalAttributeDefinition</code> objects against.
     * @return List of <code>Attribute</code> objects related to the type.
     */
    public static List getOptimizedAttrs(AdmObject type) {
        List vsList = new ArrayList();
        List attrs = new ArrayList();

        try {
            // query all of the user-defined attributes against the type
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, type);
            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, LocalAttributeDefinition.class);

            // order by prompt
            Filter filter = new FilterImpl();
            filter.orders().add(new FilterOrder(AdmAttrNames.ATTRDEF_PROMPT, FilterOrder.IGNORE_CASE));
            cmd.setAttrValue(CmdArguments.FILTER, filter);

            List attrDefs = AdmHelperCmd.getObjects((List) cmd.execute(), ATTRIBUTE_COLUMN_NAMES);
            for (int i = 0; (attrDefs != null) && (attrDefs.size() > i); i++) {

                // for each LocalAttributeDefinition object create an Attribute object from it
                LocalAttributeDefinition lad = (LocalAttributeDefinition) attrDefs.get(i);
                Attribute attr = getAttributeObject(lad);

                // check if a valid set exists, we check for the validset objects here so they can
                // be cached to prevent any validset object being queried for than once
                if (lad.getAttrValue(AdmAttrNames.ATTRDEF_VALIDSET_OBJ) != null) {

                    // get the valid set column associated with the attribute
                    Integer lovCol = (Integer) lad.getAttrValue(AdmAttrNames.ATTRDEF_LOVCOLUMN);
                    if (lovCol != null) {
                        AdmObject vs = (AdmObject) lad.getAttrValue(AdmAttrNames.ATTRDEF_VALIDSET_OBJ);
                        if (vs != null) {

                            // we do not want to keep re-querying the same validset objects. Query the validsets
                            // that have not been queried and store the validset object incase it is needed again.
                            if (!vsList.contains(vs)) {
                                AdmHelperCmd.getAttributeValues(vs, VALIDSET_COLUMN_NAMES);
                                vsList.add(vs);
                            } else {
                                vs = (AdmObject) vsList.get(vsList.indexOf(vs));
                            }

                            // get the validset values for the column in a list of distinct values
                            List vsColValues = LegacyCollections.asListSet((List) vs.getAttrValue((String) VALIDSET_COLUMN_NAMES.get(lovCol.intValue())));
                            attr.getAttributeDefinition().setAttrValue(AdmAttrNames.ATTRDEF_IS_LOVPRESENT, Boolean.TRUE);
                            attr.getAttributeDefinition().setAttrValue(AdmAttrNames.ATTRDEF_LOVCOLUMN, lovCol);

                            // store the validset values using this attribute which can be read from the AttributeDefintion object
                            attr.getAttributeDefinition().setAttrValue(AdmAttrNames.ATTRDEF_LOV, vsColValues);
                        }
                    }
                }
                attrs.add(attr.getAttributeDefinition());
            }
        } catch (Exception e) {
            Debug.error(e);
        }
        return attrs;
    }

    /**
     * Gets list of <code>LocalAttributeDefinition</code> objects related to a type and converts them to
     * <code>AttributeDefinition</code> objects. The attributes returned are ordered alphabetically by
     * the attributes prompt value.
     * @param type
     *            AdmObject to query for <code>LocalAttributeDefinition</code> objects against.
     * @return List of <code>Attribute</code> objects related to the type.
     */
    public static List getAttributes(AdmObject type) {
        List attrs = new ArrayList();

        try {
            // query all of the user-defined attributes against the type
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, type);
            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, LocalAttributeDefinition.class);

            // order by prompt
            Filter filter = new FilterImpl();
            filter.orders().add(new FilterOrder(AdmAttrNames.ATTRDEF_PROMPT, FilterOrder.IGNORE_CASE));
            cmd.setAttrValue(CmdArguments.FILTER, filter);

            List attrDefs = AdmHelperCmd.getObjects((List) cmd.execute(), ATTRIBUTE_COLUMN_NAMES);
            for (int i = 0; (attrDefs != null) && (attrDefs.size() > i); i++) {

                // for each LocalAttributeDefinition object create an Attribute object from it
                LocalAttributeDefinition lad = (LocalAttributeDefinition) attrDefs.get(i);
                Attribute attr = getAttributeObject(lad);
                if (lad.getAttrValue(AdmAttrNames.ATTRDEF_VALIDSET_OBJ) != null) {
                    attr.getAttributeDefinition().setAttrValue(AdmAttrNames.ATTRDEF_IS_LOVPRESENT, Boolean.TRUE);
                }
                attrs.add(attr.getAttributeDefinition());
            }
        } catch (Exception e) {
            Debug.error(e);
        }
        return attrs;
    }

    public static List getAttrValidSet(AdmObject type, String attrId) {
        List vsList = new ArrayList();
        try {
            // query all of the user-defined attributes against the type
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, type);
            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, LocalAttributeDefinition.class);

            // order by prompt
            Filter filter = new FilterImpl();
            filter.criteria().add(new FilterCriterion(AdmAttrNames.ID, attrId, FilterCriterion.EQUALS));
            cmd.setAttrValue(CmdArguments.FILTER, filter);

            List attrDefs = AdmHelperCmd.getObjects((List) cmd.execute(), ATTRIBUTE_COLUMN_NAMES);
            if (attrDefs != null && attrDefs.size() > 0) {

                // for each LocalAttributeDefinition object create an Attribute object from it
                LocalAttributeDefinition lad = (LocalAttributeDefinition) attrDefs.get(0);

                // check if a valid set exists, we check for the validset objects here so they can
                // be cached to prevent any validset object being queried for than once
                if (lad.getAttrValue(AdmAttrNames.ATTRDEF_VALIDSET_OBJ) != null) {

                    // get the valid set column associated with the attribute
                    Integer lovCol = (Integer) lad.getAttrValue(AdmAttrNames.ATTRDEF_LOVCOLUMN);
                    if (lovCol != null) {
                        AdmObject vs = (AdmObject) lad.getAttrValue(AdmAttrNames.ATTRDEF_VALIDSET_OBJ);
                        if (vs != null) {

                            // we do not want to keep re-querying the same validset objects. Query the validsets
                            // that have not been queried and store the validset object incase it is needed again.
                            if (!vsList.contains(vs)) {
                                AdmHelperCmd.getAttributeValues(vs, VALIDSET_COLUMN_NAMES);
                                vsList.add(vs);
                            } else {
                                vs = (AdmObject) vsList.get(vsList.indexOf(vs));
                            }

                            // get the validset values for the column in a list of distinct values
                            return LegacyCollections.asListSet((List) vs.getAttrValue((String) VALIDSET_COLUMN_NAMES.get(lovCol.intValue())));
                        }
                    }
                }
            }
        } catch (Exception e) {
            Debug.error(e);
        }
        return null;
    }

    /**
     * Convert a <code>LocalAttributeDefinition</code> object to a legacy <code>Attribute</code> object.
     * @param lad
     *            <code>LocalAttributeDefinition</code> object to create the <code>Attribute</code> object from.
     * @return Attribute object created from the <code>LocalAreaDefinition</code> object.
     */
    public static Attribute getAttributeObject(LocalAttributeDefinition lad) throws AdmObjectException, AttrException {

        // populate the Attribute object with details from the LocalAttributeDefinition
        Attribute attr = new Attribute();
        AttributeDefinition attrDef = new AttributeDefinition();

        // set the attribute name
        attrDef.setName(lad.getId());

        // is the attribute multi-valued?
        boolean isMultiValued = false;
        Integer attrType = (Integer) lad.getAttrValue(AdmAttrNames.ATTRDEF_ATTRTYPE);
        if ((attrType != null) && (attrType.intValue() == 2)) {
            isMultiValued = true;
        }
        attrDef.setAttrValue(AdmAttrNames.ATTRDEF_IS_MULTIVALUED, ((isMultiValued) ? Boolean.TRUE : Boolean.FALSE));

        // check attribute datatype
        Class dataTypeClass = (Class) lad.getAttrValue(AdmAttrNames.ATTRDEF_DATATYPE);
        String dataType = null;
        if (dataTypeClass != null) {
            if (Number.class.equals(dataTypeClass)) {
                dataType = "N";
            } else if (Date.class.equals(dataTypeClass)) {
                dataType = "D";
            } else if (Integer.class.equals(dataTypeClass)) {
                dataType = "I";
            } else if (String.class.equals(dataTypeClass)) {
                dataType = "C";
            }
        }
        attrDef.setAttrValue(AdmAttrNames.ATTRDEF_ATTRTYPE, dataType);

        // check default value
        if (lad.getAttrValue(AdmAttrNames.ATTRDEF_DEFAULT_VALUE) != null) {
            attrDef.setDefaultValue(lad.getAttrValue(AdmAttrNames.ATTRDEF_DEFAULT_VALUE));
        }

        // check attribute number
        if (lad.getAttrValue(AdmAttrNames.ATTRDEF_ATTRNO) != null) {
            Integer attrNo = (Integer) lad.getAttrValue(AdmAttrNames.ATTRDEF_ATTRNO);
            attrDef.setAttrNo(attrNo.intValue());
        }

        // check prompt
        if (lad.getAttrValue(AdmAttrNames.ATTRDEF_PROMPT) != null) {
            attrDef.setPrompt((String) lad.getAttrValue(AdmAttrNames.ATTRDEF_PROMPT));
        }

        attr.setAttributeDefinition(attrDef);
        return attr;
    }

    /*
     * return true if attribute name is validate
     * or return false if it is a reserved keyword
     */
    public static boolean isValidAttributeName(String name) {
        if (name == null || name.length() == 0) {
            return false;
        }

        if (RESERVED_WORDS.size() == 0) {
            init();
        }
        return !RESERVED_CHARS.contains(name) && !RESERVED_WORDS.contains(name.toUpperCase());
    }

    public static List getSysAttrDefs(Class navClass) {
        int objClass = -1;
        if (navClass != null) {
            if (navClass.equals(Item.class) || navClass.equals(ItemFile.class)) {
                objClass = Constants.ITEM_CLASS;
            } else if (navClass.equals(ChangeDocument.class)) {
                objClass = Constants.CHDOC_CLASS;
            } else if (navClass.equals(WorkSet.class)) {
                objClass = Constants.WORKSET_CLASS;
            } else if (navClass.equals(Baseline.class)) {
                objClass = Constants.BASELINE_CLASS;
            }
        }
        try {
            Cmd cmd = AdmCmd.getCmd("GetSystemAttributeDefinitions");
            cmd.setAttrValue(AdmAttrNames.PARENT_CLASS, new Integer(objClass));
            return (List) cmd.execute();
        } catch (AdmException e) {
            Debug.error(e.getMessage(), e);
        }
        return null;
    }

    public static Map getSysAttrMap(Class resClass) {
        if (Item.class.equals(resClass) || ItemFile.class.equals(resClass)) {
            return itemSysAttrMap;
        } else if (ChangeDocument.class.equals(resClass)) {
            return requestSysAttrMap;
        } else if (WorkSet.class.equals(resClass)) {
            return projectSysAttrMap;
        } else if (Baseline.class.equals(resClass)) {
            return baselineSysAttrMap;
        } else {
            return null;
        }
    }

    // some attribute name may not be used for webclient, but have the same attribute number
    // e.g. the attributes bln_template_id and template both have attr number -300. However, the rpcGetSystemAttrDef() method will
    // only return attribute 'template'.
    private static void initSysAttrsMap(Map map, Class objClass) {
        List sysAttrs = AttributeHelper.getSysAttrDefs(objClass);
        if (sysAttrs != null) {
            for (int i = 0; i < sysAttrs.size(); i++) {
                SystemAttributeDefinition attrDef = (SystemAttributeDefinition) sysAttrs.get(i);
                // String name = attrDef.getName();
                Integer number = new Integer(attrDef.getAttrNum());
                // name = Constants.NON_USER_DEF_ATTR_CHAR + "AdmAttrNames." + name.toLowerCase();
                map.put(number, attrDef);
            }
        }
    }

    public static String getSysAttrType(String name, Class objClass) {
        SystemAttributeDefinition attrDef = getSysAttrDef(name, objClass);
        if (attrDef != null) {
            return attrDef.getAttrTypeAsString();
        } else {
            return null;
        }
    }

    public static String[] getBooleanValues(String name, Class objClass) {
        SystemAttributeDefinition attrDef = getSysAttrDef(name, objClass);
        if (attrDef != null) {
            return attrDef.getBooleanAttrValues();
        } else {
            return null;
        }
    }

    private static SystemAttributeDefinition getSysAttrDef(String name, Class objClass) {
        Map sysAttrMap = getSysAttrMap(objClass);
        Map superQueryAttrMap = SuperQuery.getAttrToNumMap();
        Integer attrNum = (Integer) superQueryAttrMap.get(name);
        if (attrNum != null) {
            return (SystemAttributeDefinition) sysAttrMap.get(attrNum);
        }
        return null;
    }
}

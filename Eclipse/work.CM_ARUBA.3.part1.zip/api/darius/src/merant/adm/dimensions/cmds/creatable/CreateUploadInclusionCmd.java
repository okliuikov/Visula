/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.Product;
import merant.adm.dimensions.objects.UploadInclusion;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Upload Inclusion object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new upload inclusion</dd>
 *  <dt>UPLINC_SEQ {Long}</dt><dd>Sequence for the new upload inclusion</dd>
 *  <dt>ADM_PARENT_OBJECT {AdmObject}</dt><dd>Parent upload project</dd>
 *  <dt>UPLINC_FORMAT {AdmBaseId}</dt><dd>Upload Inclusion format criteria</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>EXTENSION {String}</dt><dd>Extension for the new upload inclusion</dd>
 *  <dt>UPLINC_PART {AdmBaseId}</dt><dd>Upload Inclusion part criteria</dd>
 *  <dt>UPLINC_TYPE {AdmBaseId}</dt><dd>Upload Inclusion type criteria</dd>
 * </dl></code> <br>
 * <b>Required Role:</b> <code><dl>
 *  <dt>($)PRODUCT-MANAGER/TOOL-MANAGER</dt>
 *  <dd>
 *      TOOL-MANAGER if creating a default inclusion rule, otherwise
 *      the product of the parent project as scope
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 * @todo Relies upon DBIO accepting bindInput(null)!
 */
public class CreateUploadInclusionCmd extends RPCExecCmd {
    public CreateUploadInclusionCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.UPLINC_SEQ, true, Long.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.UPLINC_FORMAT, true, AdmBaseId.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.EXTENSION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.UPLINC_PART, false, Object.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.UPLINC_TYPE, false, AdmBaseId.class));
        setAttrDef(new CmdArgDef(CmdArguments.CREATE_PROD_UPLOAD_RULE, false, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.UPLINC_EXCLUDE, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String extension = (String) getAttrValue(AdmAttrNames.EXTENSION);
        long seq = ((Long) getAttrValue(AdmAttrNames.UPLINC_SEQ)).longValue();
        AdmObject uploadProject = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        String exclude_patterns = (String) getAttrValue(AdmAttrNames.UPLINC_EXCLUDE);

        if (extension == null) {
            extension = (String) AdmHelperCmd.getAttributeValue(uploadProject, AdmAttrNames.EXTENSION);
        }

        String uploadProjId = "0";
        String projectProductName = (String) AdmHelperCmd.getAttributeValue(uploadProject, AdmAttrNames.PRODUCT_NAME);
        String projectId = (String) AdmHelperCmd.getAttributeValue(uploadProject, AdmAttrNames.ID);
        if ((!projectProductName.equals(Constants.GLOBAL_PRODUCT)) || (!projectId.equals(Constants.GLOBAL_ID))) {
            uploadProjId = ((Long) AdmHelperCmd.getAttributeValue(uploadProject, AdmAttrNames.SPEC_UID)).toString();
        }

        DBIO query = null;
        boolean isProdRuleCreation = getAttrValue(CmdArguments.CREATE_PROD_UPLOAD_RULE) == null
                ? false : (Boolean) getAttrValue(CmdArguments.CREATE_PROD_UPLOAD_RULE);

        // P Smith 11 March 2003
        // Check to see whether a row for the file extension exists already in the database
        query = new DBIO(wcm_sql.QUERY_UPLOAD_INCLUSION_FILE_EXT);
        // user name
        query.bindInput("$$" + extension);
        // session id
        query.bindInput(uploadProjId);
        // file extension
        query.bindInput(id);
        query.readStart();
        // We have found something
        if (query.read()) {
            query.close();
            throw new DimAlreadyExistsException("An upload inclusion already exists with this file extension: '" + id + "'");
        }
        query.close();

        if (uploadProjId.equals("0") || extension.startsWith("$")) {
            // Start DEF173973
            if (uploadProjId.equals("0") && extension.startsWith("mrg-")) {// For all product specific Dimensions Clients upload
                                                                           // projects.
                if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", projectId)) {
                    throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", projectId);
                }// End DEF173973
            } else {
                // Ensure that we have the privilege to do this
                if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_UPLOADMAN")) {
                    throw new DimNoPrivilegeException("ADMIN_UPLOADMAN");
                }
            }
        } else {
            AdmObject product = null;
            query = new DBIO(wcm_sql.QUERY_UPLPROJ_PRODUCT);
            query.bindInput(Long.valueOf(uploadProjId).longValue());
            query.readStart();
            if (query.read()) {
                product = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getString(1), Product.class));
            }

            query.close();
            if (product == null) {
                throw new DimBaseCmdException("Unable to resolve product - for role check!");
            }

            String productName = (String) AdmHelperCmd.getAttributeValue(product, AdmAttrNames.ID);
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserApplicationPrivilege("APP_PROJECTUPLOADMAN", productName)) {
                throw new DimNoPrivilegeException("APP_PROJECTUPLOADMAN", productName);
            }
        }

        AdmBaseId formatBaseId = (AdmBaseId) getAttrValue(AdmAttrNames.UPLINC_FORMAT);
        AdmBaseId typeBaseId = (AdmBaseId) getAttrValue(AdmAttrNames.UPLINC_TYPE);
        Object partObj = getAttrValue(AdmAttrNames.UPLINC_PART);
        AdmBaseId partBaseId = null;
        String partId = null;
        String partVariant = null;
        if (partObj instanceof AdmBaseId) {
            partBaseId = (AdmBaseId) partObj;
            partId = (partBaseId != null) ? (String) AdmHelperCmd.getAttributeValue(AdmHelperCmd.getObject(partBaseId),
                    AdmAttrNames.ID) : null;
            partVariant = (partBaseId != null) ? (String) AdmHelperCmd.getAttributeValue(AdmHelperCmd.getObject(partBaseId),
                    AdmAttrNames.VARIANT) : null;
        } else if (partObj instanceof String) {
            partId = (String) partObj;
        }

        setAttrValue(CmdArguments.INT_SPEC, uploadProjId + ":" + id + ";" + extension);

        String itemFormat = (formatBaseId != null) ? (String) AdmHelperCmd.getAttributeValue(AdmHelperCmd.getObject(formatBaseId),
                AdmAttrNames.ID) : null;
        String itemType = (typeBaseId != null) ? (String) AdmHelperCmd.getAttributeValue(AdmHelperCmd.getObject(typeBaseId),
                AdmAttrNames.ID) : null;
        String part_id = null;
        if (partId != null) {
            part_id = partId;
            if (partVariant != null) {
                part_id += "." + partVariant;
            }
        }

        // wcm_sql.GET_UPLOAD_INCLUSIONS guarantees us an ordering by
        // sequence but add the filter anyway - for future compatibility
        List uploadInclusions = null;
        if (!isProdRuleCreation) {
            Filter filter = new FilterImpl();
            filter.orders().add(new FilterOrder(AdmAttrNames.UPLINC_SEQ, FilterOrder.ASCENDING));
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILDREN, uploadProject, UploadInclusion.class);
            cmd.setAttrValue(CmdArguments.FILTER, filter);
            uploadInclusions = AdmHelperCmd.getObjects((List) cmd.execute(), AdmAttrNames.UPLINC_SEQ);
        }

        int startResequenceIndex = -1;
        if (!isProdRuleCreation) {
            if ((uploadInclusions == null) || (uploadInclusions.size() < 1)) {
                seq = 1;
            } else if (seq < 1) {
                seq = 1;
                startResequenceIndex = 0;
            } else if (seq > uploadInclusions.size()) {
                seq = uploadInclusions.size() + 1;
            } else {
                startResequenceIndex = (int) seq - 1;
            }
        }

        query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            if (startResequenceIndex != -1) {
                for (int i = startResequenceIndex; i < uploadInclusions.size(); i++) {

                    String ext = "$$" + extension;
                    String uploadInclusion = (String)((AdmObject)uploadInclusions.get(i)).getAttrValue(AdmAttrNames.ID);
                    long num = ((Long) ((AdmObject) uploadInclusions.get(i)).getAttrValue(AdmAttrNames.UPLINC_SEQ)).longValue() + 1;

                    SqlUtils.updateUploadInclusionSeq(query, ext, uploadProjId, uploadInclusion, num);

                    query.write(DBIO.DB_DONT_COMMIT);
                    query.close(DBIO.DB_DONT_RELEASE);
                }
            }

            query.resetMessage(wcm_sql.CREATE_UPLOAD_INCLUSION);
            query.bindInput("$$" + extension);
            query.bindInput(uploadProjId);
            query.bindInput(id);
            query.bindInput(seq);
            query.bindInput(itemFormat, String.class);
            query.bindInput(itemType, String.class);
            query.bindInput(part_id, String.class);
            query.bindInput(exclude_patterns, String.class);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }

                doCommit = false;
            }

            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if ((query != null) && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        AdmResult retResult = new AdmResult("Created upload inclusion \"" + id + "\" successfully");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, UploadInclusion.class);
        return retResult;
    }
}

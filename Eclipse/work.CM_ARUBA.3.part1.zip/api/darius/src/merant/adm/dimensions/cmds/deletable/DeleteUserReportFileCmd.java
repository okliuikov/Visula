/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions User Report File object.
 * <p>
 * This commans will fail if the report file to be deleted is used in a user report definition unless REMOVE is set to true.
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt><dd>If true, automatically deassign report file from the associated report definition.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteUserReportFileCmd extends DBIOCmd {
    public DeleteUserReportFileCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UserReportFile)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPORTMAN")) {
            throw new DimNoPrivilegeException("ADMIN_REPORTMAN");
        }

        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean force = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        long reportFileUid = ((AdmUidObject) admObj).getAdmUid().getUid();

        List attrs = AdmHelperCmd.getAttributeValues(admObj, Arrays.asList(new Object[] { AdmAttrNames.ID, AdmAttrNames.REVISION }));

        String reportFileId = (String) attrs.get(0);
        String revision = (String) attrs.get(1);

        int count = countAssignedReports(reportFileUid);
        if (count > 0 && !force) {
            throw new DimInUseException("Error: The report file " + reportFileId + ";" + revision + " is currently used by "
                    + count + " report definitions.");
        }

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            // delete records from cpl_attributes (export file name)
            query.resetMessage(wcm_sql.URF_DELETE_ATTRS);
            query.bindInput(reportFileUid);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

            // delete report file BLOB
            query.resetMessage(wcm_sql.URF_DELETE_FILE_DATA);
            query.bindInput(reportFileUid);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

            // delete repoprt file revision definition
            query.resetMessage(wcm_sql.URF_DELETE_REPORT_FILE_REVISION);
            query.bindInput(reportFileUid);
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);
        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return "Operation Completed";
    }

    private int countAssignedReports(long reportFileUid) throws DBIOException, AdmObjectException, DimBaseException {

        DBIO query = new DBIO(wcm_sql.URF_COUNT_ASSIGNED_REPORTS);
        query.bindInput(reportFileUid);
        query.readStart();
        int count = 0;
        if (query.read()) {
            count = query.getInt(1);
        }
        query.close();
        return count;
    }

}

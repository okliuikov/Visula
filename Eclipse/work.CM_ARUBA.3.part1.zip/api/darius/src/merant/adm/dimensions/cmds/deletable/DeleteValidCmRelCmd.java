/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ValidCMRelationship;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Valid CM Relationship object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteValidCmRelCmd extends RPCExecCmd {

    public DeleteValidCmRelCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ValidCMRelationship)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        String parentProductId = (String) admObj.getAttrValue(AdmAttrNames.CMREL_TYPE_PRODUCT_NAME);
        String parentTypeName = (String) admObj.getAttrValue(AdmAttrNames.CMREL_TYPE_ID);
        String childProductId = (String) admObj.getAttrValue(AdmAttrNames.CMREL_RELATED_TYPE_PRODUCT_NAME);
        String childTypeName = (String) admObj.getAttrValue(AdmAttrNames.CMREL_RELATED_TYPE_ID);
        Class childTypeClass = (Class) admObj.getAttrValue(AdmAttrNames.CMREL_RELATED_TYPE_PARENT_CLASS);

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /DELETE_RELATIONSHIP ");
        cmdBuf.append(Encoding.escapeDMCLI(parentTypeName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(parentProductId));
        cmdBuf.append(" /OBJ_CLASS=REQUEST");
        cmdBuf.append(" /REL_PRODUCT=").append(Encoding.escapeDMCLI(childProductId));
        cmdBuf.append(" /REL_TYPE_NAME=").append(Encoding.escapeDMCLI(childTypeName));

        if (childTypeClass.equals(Item.class)) {
            cmdBuf.append(" /REL_OBJ_CLASS=ITEM");
        } else if (childTypeClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /REL_OBJ_CLASS=REQUEST");
        } else {
            throw new DimInvalidAttributeException("Error: Unable to delete relationship of specified related object type.");
        }

        _cmdStr = cmdBuf.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }
}
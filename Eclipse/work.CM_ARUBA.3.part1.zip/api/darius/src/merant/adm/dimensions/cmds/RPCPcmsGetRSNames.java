/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Get the role section names via Message Server
 */
public class RPCPcmsGetRSNames extends RPCCmd {

    public static final String UID_OBJECT = "uidObject";
    public static final String TYPE_OBJECT = "typeObject";

    public RPCPcmsGetRSNames() throws AdmObjectException, AttrException {
        super();
        setAlias("RPC GetRSNames");
        AddArgument("cmd", "PcmsGetRSNames");
        /*
         * setAttrDef(new CmdArgDef("objuid", true, "", "", ""));
         * setAttrDef(new CmdArgDef("typeuid", true, "", "", ""));
         * setAttrDef(new CmdArgDef("status", true, "", "", ""));
         */
        setAttrDef(new CmdArgDef(UID_OBJECT, true, AdmUidObject.class));
        setAttrDef(new CmdArgDef(TYPE_OBJECT, true, AdmUidObject.class));
        setAttrDef(new CmdArgDef("status", true, "", "", ""));
    }

    @Override
    public Object execute() throws AdmException {

        try {

            AdmUidObject uidObject = (AdmUidObject) getAttrValue(UID_OBJECT);
            AdmUidObject typeObject = (AdmUidObject) getAttrValue(TYPE_OBJECT);

            AdmUidObject objectToUse = uidObject != null ? uidObject : typeObject;
            String[] rsNames = getSession().getConnection().rpcPcmsGetRSNames(objectToUse.getAdmUid().getUid());

            String ret;
            if (rsNames != null) {
                ret = Constants.SERVER_OK;
                for (int i = 0; i < rsNames.length; i++) {
                    ret = ret + rsNames[i] + "\007";
                }
            } else {
                ret = Constants.SERVER_ERROR;
            }
            return ret;

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Calls the Builder get-dependencies RPC.
 */
public class RPCAddFavoriteCmd extends RPCCmd {
    public RPCAddFavoriteCmd() throws AdmObjectException, AttrException {
        setAlias("AddFavorite");
        setAttrDef(new CmdArgDef(AdmAttrNames.REPORT_UID, true, Long.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.USER_UID, true, Long.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_FLAG, false, new Integer(0), Integer.class));
    }

    @Override
    public Object execute() throws AdmException {
        try {
            int reportUid = ((Long) getAttrValue(AdmAttrNames.REPORT_UID)).intValue();
            int userUid = ((Long) getAttrValue(AdmAttrNames.USER_UID)).intValue();
            int typeFlag = ((Integer) getAttrValue(AdmAttrNames.TYPE_FLAG)).intValue();
            int result = getSession().getConnection().rpcAddFavourite(reportUid, typeFlag, userUid);

            if (result == Constants.PCMS_OK) {
                return "Operation Success";
            }
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }

        return "Operation Failed";
    }
}

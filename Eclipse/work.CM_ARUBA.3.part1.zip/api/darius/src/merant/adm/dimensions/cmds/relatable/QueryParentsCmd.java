/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2001 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Archive;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.BaselineCode;
import merant.adm.dimensions.objects.BaselineTemplateRule;
import merant.adm.dimensions.objects.BuildProject;
import merant.adm.dimensions.objects.BuildTarget;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.Group;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.Library;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.NetCodeSet;
import merant.adm.dimensions.objects.NetContact;
import merant.adm.dimensions.objects.NetFileSys;
import merant.adm.dimensions.objects.NetInstance;
import merant.adm.dimensions.objects.NetNode;
import merant.adm.dimensions.objects.NetNodeConnection;
import merant.adm.dimensions.objects.NetObject;
import merant.adm.dimensions.objects.NetOpSys;
import merant.adm.dimensions.objects.NetProtocol;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.PrivilegeRule;
import merant.adm.dimensions.objects.PrivilegeRuleScopeAssignment;
import merant.adm.dimensions.objects.Relationship;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.ReplItemMasterConfig;
import merant.adm.dimensions.objects.ReplItemSubordinateConfig;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.RequestProviderDefinition;
import merant.adm.dimensions.objects.SecChangeDocument;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.UploadExclusion;
import merant.adm.dimensions.objects.UploadInclusion;
import merant.adm.dimensions.objects.UploadProject;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.UserReportDefinition;
import merant.adm.dimensions.objects.UserReportFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will query the parents of a Dimensions object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_PARENT_CLASS {Class}<dt><dd>Parent Dimensions object class</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>WORKSET {WorkSet}<dt><dd>Dimensions work set container for objects</dd>
 *  <dt>RELATIONSHIPS {Boolean}<dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELTYPE_IS_PEDIGREE {Boolean}<dt><dd>If true, returns pedigree object relationships</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * 
 * @author Floz
 */
public class QueryParentsCmd extends DBIOCmd {
    public QueryParentsCmd() throws AttrException {
        super();
        setAlias(Relatable.QUERY_PARENTS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATIONSHIPS, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTYPE_IS_PEDIGREE, false, Boolean.FALSE, Boolean.class));
    }

    /** @todo Find a way to validate when dependencies exist between arguments */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof Archive)) && (!(attrValue instanceof Baseline))
                    && (!(attrValue instanceof BaselineTemplateRule)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof SecChangeDocument)) && (!(attrValue instanceof Customer))
                    && (!(attrValue instanceof Item)) && (!(attrValue instanceof DimDirectory))
                    && (!(attrValue instanceof NetBaseDatabase)) && (!(attrValue instanceof NetInstance))
                    && (!(attrValue instanceof NetNode)) && (!(attrValue instanceof NetNodeConnection))
                    && (!(attrValue instanceof NetObject)) && (!(attrValue instanceof UserReportFile))
                    && (!(attrValue instanceof Part)) && (!(attrValue instanceof PrivilegeRuleScopeAssignment))
                    && (!(attrValue instanceof BuildProject)) && (!(attrValue instanceof Release))
                    && (!(attrValue instanceof Type)) && (!(attrValue instanceof UploadExclusion))
                    && (!(attrValue instanceof UploadInclusion)) && (!(attrValue instanceof User))
                    && (!(attrValue instanceof RequestProvider)) && (!(attrValue instanceof WorkSet))
                    && (!(attrValue instanceof ReplItemSubordinateConfig)) && (!(attrValue instanceof ExternalRequest))) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_CLASS)) {
            if ((!(attrValue.equals(Archive.class))) && (!(attrValue.equals(Baseline.class)))
                    && (!(attrValue.equals(BaselineCode.class))) && (!(attrValue.equals(BuildProject.class)))
                    && (!(attrValue.equals(BuildTarget.class))) && (!(attrValue.equals(ChangeDocument.class)))
                    && (!(attrValue.equals(ExternalRequest.class))) && (!(attrValue.equals(DimDirectory.class)))
                    && (!(attrValue.equals(Group.class))) && (!(attrValue.equals(Item.class)))
                    && (!(attrValue.equals(ItemFile.class))) && (!(attrValue.equals(Library.class)))
                    && (!(attrValue.equals(LifeCycle.class))) && (!(attrValue.equals(NetCodeSet.class)))
                    && (!(attrValue.equals(NetContact.class))) && (!(attrValue.equals(NetFileSys.class)))
                    && (!(attrValue.equals(NetInstance.class))) && (!(attrValue.equals(NetNode.class)))
                    && (!(attrValue.equals(NetOpSys.class))) && (!(attrValue.equals(UserReportDefinition.class)))
                    && (!(attrValue.equals(NetProtocol.class))) && (!(attrValue.equals(Part.class)))
                    && (!(attrValue.equals(PrivilegeRule.class))) && (!(attrValue.equals(BuildProject.class)))
                    && (!(attrValue.equals(Release.class))) && (!(attrValue.equals(Stage.class)))
                    && (!(attrValue.equals(UploadProject.class))) && (!(attrValue.equals(User.class)))
                    && (!(attrValue.equals(RequestProviderDefinition.class))) && (!(attrValue.equals(WorkSet.class)))
                    && (!(attrValue.equals(ReplItemMasterConfig.class)))) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Class<?> admParentClass = (Class<?>) getAttrValue(CmdArguments.ADM_PARENT_CLASS);
        WorkSet workSet = (WorkSet) getAttrValue(CmdArguments.WORKSET);
        boolean useRelationships = ((Boolean) getAttrValue(CmdArguments.RELATIONSHIPS)).booleanValue();
        boolean isPedigree = ((Boolean) getAttrValue(AdmAttrNames.RELTYPE_IS_PEDIGREE)).booleanValue();

        Filter filter = (Filter) getAttrValue(CmdArguments.FILTER);
        if (filter != null) {
            filter = (Filter) filter.clone();
        }

        Vector retBaseIds = new Vector();

        // first check cases if current parent class is exist in method collection
        QueryParentsCmdGettersEnum getter = QueryParentsCmdGettersEnum.get(admParentClass.getSimpleName()
                + CmdArguments.ADM_PARENT_CLASS);
        if (getter != null) {
            getter.getParent(this, admObj, admParentClass, useRelationships, isPedigree, filter, workSet, retBaseIds);
        } else {
            getter = QueryParentsCmdGettersEnum.get(admObj.getClass().getSimpleName() + CmdArguments.ADM_OBJECT);
            if (getter != null) {
                Object result = getter.getParent(this, admObj, admParentClass, useRelationships, isPedigree, filter, workSet,
                        retBaseIds);
                if (result != null) {
                    return result;
                }
            }
        }

        return retBaseIds;

    }

    // XXX - Floz: NOTE - parent and child params are reversed to those in QueryChildrenCmd.java
    AdmObject addRelation(List retBaseIds, boolean relationships, AdmBaseId child, AdmBaseId parent) throws AdmObjectException {
        return addRelation(retBaseIds, relationships, child, parent, null);
    }

    AdmObject addRelation(List retBaseIds, boolean relationships, AdmBaseId child, AdmBaseId parent, AdmObject relType)
            throws AdmObjectException {
        AdmObject rel = null;
        if (relationships) {
            rel = new Relationship(parent, child);
            if (relType != null) {
                rel.setAttrValue(AdmAttrNames.REL_TYPE, relType);
            }

            retBaseIds.add(rel);
        } else {
            retBaseIds.add(parent);
        }

        return rel;
    }

}

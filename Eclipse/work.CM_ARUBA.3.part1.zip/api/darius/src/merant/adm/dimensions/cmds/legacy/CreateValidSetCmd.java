/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.legacy;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.serena.dmfile.utility.StringUtils;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimDatabaseConnectException;
import merant.adm.dimensions.exception.DimInvalidPropertyException;
import merant.adm.dimensions.exception.MessageFileNotFoundException;
import merant.adm.dimensions.exception.MessageNotFoundException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will insert a new Valid Set.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}<dt><dd>Product to create the Valid Set</dd>
 *  <dt>ID {String}<dt><dd>The name of the Valid Set to be created</dd>
 *  <dt>NO_OF_COLUMNS {String}<dt><dd>The number of columns in the valid set</dd>
 *  <dt>COLUMN1_VALUES {List}<dt><dd>The values for column 1 of the valid set</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DISPLAY_ORDER {List}<dt><dd>Display order for the Valid Set values</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Integer}<dt><dd>Dimensions operation completion status</dd>
 * </dl></code>
 * @todo Update to new object model
 * @author Stephen Sitton
 * @author Floz
 */
public class CreateValidSetCmd extends DBIOCmd {

    public CreateValidSetCmd() throws AttrException {
        super();
        setAlias("CreateValidSetCmd");
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.NO_OF_COLUMNS, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DISPLAY_ORDER, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.COLUMN1_VALUES, true, List.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmObjectException, MessageNotFoundException,
            MessageFileNotFoundException, DimInvalidPropertyException, DimDatabaseConnectException, AdmException {

        validateAllAttrs();
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String no_of_columns = (String) getAttrValue(CmdArguments.NO_OF_COLUMNS);
        List displayOrder = (List) getAttrValue(CmdArguments.DISPLAY_ORDER);
        List col1Values = (List) getAttrValue(CmdArguments.COLUMN1_VALUES);

        // Process the command...
        Iterator iterDispOrder = null;
        boolean dispOrder = false;
        long vs_uid = validSetExists(productName, id);
        if (vs_uid == Constants.INVALID_UID) {
            try {
                vs_uid = getNewUid();

                DBIO query = SqlUtils.createValidSet(vs_uid,
                                                     productName,
                                                     id.toUpperCase(),
                                                     (StringUtils.isEmpty(no_of_columns) ? 1 : Integer.parseInt(no_of_columns)),
                                                     "",
                                                     "");

                query.write();
            } catch (DBIOException ex) {
                // Pass the exception on...
                throw new AdmException(ex);
            }
        }
        if (col1Values != null) {
            if ((displayOrder != null) && (displayOrder.size() == col1Values.size())) {
                iterDispOrder = displayOrder.iterator();
                dispOrder = true;
            }
            Iterator iterCol1 = col1Values.iterator();
            try {
                while (iterCol1.hasNext()) {
                    String dOrder = "";
                    String col1Value = iterCol1.next().toString();
                    if (dispOrder) {
                        dOrder = iterDispOrder.next().toString();
                    }
                    if (!validSetValueExists(vs_uid, col1Value)) {
                        DBIO query = new DBIO();
                        SqlUtils.insertValidSetValues(query,
                                                      vs_uid,
                                                      (StringUtils.isEmpty(dOrder) ? 1 : Integer.parseInt(dOrder)),
                                                      col1Value,
                                                      "",
                                                      "",
                                                      "",
                                                      "",
                                                      "",
                                                      "",
                                                      "");
                        query.write();
                    }
                }
            } catch (AdmException ae) {
                Debug.error(ae);
            }
        }
        return null;
    }

    private long validSetExists(String productName, String id) throws DBIOException, DimBaseException, AdmObjectException,
            MessageNotFoundException, AdmException, MessageFileNotFoundException, DimInvalidPropertyException,
            DimDatabaseConnectException {

        long uid = Constants.INVALID_UID;
        DBIO query = null;
        try {
            query = new DBIO(wcm_sql.CPL_VS_EXISTS);
            query.bindInput(productName);
            query.bindInput(id);
            query.readStart();
        } catch (DBIOException ex) {
            Debug.println("Error querying if valid set exists - " + ex);
            throw new AdmException(ex);
        }

        while (query.read()) {
            uid = query.getLong(1);
        }
        return uid;
    }

    private boolean validSetValueExists(long uid, String col1Value) throws DimBaseCmdException, AdmObjectException, AdmException {

        // This function only works for one column valid sets!!
        Vector inputs = new Vector();
        inputs.add(new Long(uid));
        inputs.add(col1Value);

        Cmd cmd = AdmCmd.getCmd(Auditable.DOES_EXIST);
        cmd.setAttrValue(CmdArguments.SQL_QUERY_NO, new Integer(wcm_sql.VALID_SET_VALUE_EXISTS));
        cmd.setAttrValue(CmdArguments.SQL_INPUTS, inputs);
        return ((Boolean) cmd.execute()).booleanValue();
    }
}
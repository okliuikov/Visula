/*
 * Copyright (C) 2001, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypePriming;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Type Priming object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>TYPE_PRIMING_TYPE_OBJ{AdmObject}<dt><dd>Dimensions request Type</dd>
 *  <dt>TYPE_PRIMING_RELATED_TYPE_OBJ {AdmObject}<dt><dd>Dimensions request Type which can be primed from TYPE_PRIMING_TYPE_OBJ</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateTypePrimingCmd extends RPCExecCmd {
    public CreateTypePrimingCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_PRIMING_TYPE_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_PRIMING_RELATED_TYPE_OBJ, true, AdmObject.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(AdmAttrNames.TYPE_PRIMING_TYPE_OBJ)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(AdmAttrNames.TYPE_PRIMING_RELATED_TYPE_OBJ)) {
            if (!(attrValue instanceof Type)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject typeObj = (AdmObject) getAttrValue(AdmAttrNames.TYPE_PRIMING_TYPE_OBJ);
        AdmObject primedTypeObj = (AdmObject) getAttrValue(AdmAttrNames.TYPE_PRIMING_RELATED_TYPE_OBJ);

        // Query data for priming type
        List attrs = AdmHelperCmd.getAttributeValues(typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        String productName = (String) attrs.get(0);
        String typeName = (String) attrs.get(1);
        Class typeClass = (Class) attrs.get(2);

        // Query data for primed type
        attrs = AdmHelperCmd.getAttributeValues(primedTypeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        String primedProductName = (String) attrs.get(0);
        String primedTypeName = (String) attrs.get(1);
        Class primedTypeClass = (Class) attrs.get(2);

        // Construct OBJTYPE /ADD_PRIME_MAPPING command
        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /ADD_PRIME_MAPPING ");
        cmdBuf.append(Encoding.escapeDMCLI(typeName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));

        if (typeClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else {
            throw new DimAlreadyExistsException("Dimensions object type " + productName + ":" + typeName
                    + " is not a request type.");
        }

        cmdBuf.append(" /PRIMED_PRODUCT=").append(Encoding.escapeDMCLI(primedProductName));
        cmdBuf.append(" /PRIMED_TYPE_NAME=").append(Encoding.escapeDMCLI(primedTypeName));

        if (primedTypeClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /PRIMED_OBJ_CLASS=REQUEST");
        } else {
            throw new DimAlreadyExistsException("Dimensions object type " + primedProductName + ":" + primedTypeName
                    + " is not a request type.");
        }

        long typeUid = ((AdmUidObject) typeObj).getAdmUid().getUid();
        long primedTypeUid = ((AdmUidObject) primedTypeObj).getAdmUid().getUid();

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        setAttrValue(CmdArguments.INT_SPEC, typeUid + ":" + primedTypeUid);
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, TypePriming.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.auditable;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Determines if the specified User has been assigned the [$]TOOL-MANAGER Role.
 * <p>
 * This command has been added as a special case to optimise for calculating against a List of many Users. For other roles, continue
 * to use HAS_ROLE. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions User object to query against</dd>
 *  <dt>ADM_OBJECT_LIST {List}</dt><dd>Dimensions AdmObject's list of Users</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PRODUCT_MANAGER {Boolean}</dt><dd>If true, calculates [$]TOOL-MANAGER OR [$]PRODUCT-MANAGER</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Boolean/List}</dt><dd>Returns true if the User is a tool manager.</dd>
 * </dl></code>
 * @author Floz
 */
public class IsToolManagerCmd extends DBIOCmd {
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof User)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    public IsToolManagerCmd() throws AttrException {
        super();
        setAlias(Auditable.IS_TOOL_MANAGER);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, getCurRootObj(User.class), AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT_MANAGER, false, Boolean.FALSE, Boolean.class));
    }

    private List getAllToolManagers(Boolean productManager) throws AdmException {
        String key = Constants.IS_TOOL_MANAGER_CACHE_KEY + "_or_prodmgr[" + productManager.toString() + "]";
        if (getCache().contains(key)) {
            return (List) AdmCmd.getCache().get(key);
        }

        List ret = new ArrayList();
        DBIO query = null;
        if (productManager.booleanValue()) {
            query = new DBIO(wcm_sql.QUERY_ALL_TOOL_OR_PROD_MANAGERS);
        } else {
            query = new DBIO(wcm_sql.QUERY_ALL_TOOL_MANAGERS);
        }

        query.readStart();
        while (query.read()) {
            ret.add(query.getString(1));
        }

        getCache().put(key, ret);
        return ret;
    }

    @Override
    public Object execute() throws DBIOException, AdmException {
        validateAllAttrs();

        AdmObject user = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List users = (List) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        Boolean productManager = (Boolean) getAttrValue(CmdArguments.PRODUCT_MANAGER);

        List allToolManagers = getAllToolManagers(productManager);
        if (users != null) {
            List ret = new ArrayList();
            boolean isToolMan;
            for (int i = 0; i < users.size(); i++) {
                isToolMan = allToolManagers.contains(((AdmObject) users.get(i)).getAdmSpec().getSpec());
                ret.add(isToolMan ? Boolean.TRUE : Boolean.FALSE);
            }

            return ret;
        }

        boolean isToolMan = allToolManagers.contains(user.getAdmSpec().getSpec());
        return (isToolMan ? Boolean.TRUE : Boolean.FALSE);
    }
}

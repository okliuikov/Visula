package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class CountBaselinesInProductCmd extends DBIOCmd {
    public CountBaselinesInProductCmd() throws AttrException {
        super();
        setAlias("CountBaselinesInProductCmd");
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
    }

    // @Override
    @Override
    public Object execute() throws DBIOException, AdmException {
        long count = 0;
        DBIO query = new DBIO(wcm_sql.COUNT_BASELINES_IN_PRODUCT);
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        query.bindInput(productName);
        query.readStart();
        while (query.read()) {
            count = query.getLong(1);
        }
        return new Long(count);
    }
}

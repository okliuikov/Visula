/*
 * Copyright (C) 2003, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplBlnMasterConfig;
import merant.adm.dimensions.objects.ReplChdocMasterConfig;
import merant.adm.dimensions.objects.ReplItemMasterConfig;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Master Replication Configuration object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>Whether to automatically delete the replication configuration definition that is currently in use without raising a warning exception. Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteReplConfigCmd extends DBIOCmd {

    public DeleteReplConfigCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReplItemMasterConfig) && !(attrValue instanceof ReplBlnMasterConfig)
                    && !(attrValue instanceof ReplChdocMasterConfig)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        final AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final boolean force = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        final String configId = admObj.getId();
        final Class parentClass = (Class) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.PARENT_CLASS);

        final int repClass = (Item.class.equals(parentClass) ? Constants.REPL_ITEM_CLASS : (Baseline.class.equals(parentClass)
                ? Constants.REPL_BASELINE_CLASS : Constants.REPL_CHDOC_CLASS));

        final int repRelClass = ((Item.class.equals(parentClass) || Baseline.class.equals(parentClass))
                ? Constants.REPL_ITEM_TYPE_REL_CLASS : Constants.REPL_CHDOC_TYPE_REL_CLASS);

        if (!DoesExistHelper.masterReplConfigExists(configId, repClass)) {
            throw new DimNotExistsException("The "
                    + (repClass == Constants.REPL_ITEM_CLASS ? "item" : (repClass == Constants.REPL_BASELINE_CLASS
                            ? "baseline" : "request")) + " replication configuration " + configId + " does not exist.");
        }

        final long configUid = ((AdmUidObject) admObj).getUid();

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {
                if (isReplicationInUse(dbCtx, configId, repClass)) {
                    if (!force) {
                        if (isRemoteMaster(dbCtx, configUid)) {
                            throw new DimInUseException("This site is a subordinate for the replication configuration " + configId
                                    + " that is currently in use.");
                        }
                        throw new DimInUseException("The master replication configuration " + configId + " is currently in use.");
                    }
                    deleteAllReplData(dbCtx, configUid, configId, repClass, repRelClass);
                }
                deleteReplConfig(dbCtx, configUid, configId, repClass);
            }
        });

        return "Operation Completed";
    }

    private boolean isReplicationInUse(DBIO dbCtx, String configId, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_IN_USE);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.readStart();
        boolean inUse = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return inUse;

    }

    private boolean isRemoteMaster(DBIO dbCtx, long configUid) throws Exception {

        AdmObject baseDb = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        long baseDbUid = 0;
        if (baseDb != null) {
            baseDbUid = ((AdmUidObject) baseDb).getAdmUid().getUid();
        }

        // check if the replication configuration to be deleted is a master configuration in this base database
        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_EXISTS_IN_BASEDB);
        dbCtx.bindInput(configUid);
        dbCtx.bindInput("0");
        dbCtx.bindInput(baseDbUid);
        dbCtx.readStart();
        boolean isMasterInThisBaseDb = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        if (isMasterInThisBaseDb) {
            return false;
        }

        // check if the replication configuration to be deleted is a master configuration in another base database
        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_EXISTS_IN_OTHER_BASEDB);
        dbCtx.bindInput(configUid);
        dbCtx.bindInput("0");
        dbCtx.bindInput(baseDbUid);
        dbCtx.readStart();
        boolean isMasterInOtherBaseDb = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        if (isMasterInOtherBaseDb) {
            return true;
        }

        // check if this replication config has a subordinate in this database
        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_HAS_SUBORDINATE_IN_THIS_BASEDB);
        dbCtx.bindInput(configUid);
        dbCtx.bindInput(baseDbUid);
        dbCtx.readStart();
        boolean hasSubordinateInThisDb = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        if (hasSubordinateInThisDb) {
            return true;
        }

        return false;
    }

    private void deleteReplConfig(DBIO dbCtx, long configUid, String configId, int repClass) throws Exception {

        if (isMasterConfigInUse(dbCtx, configUid)) {
            throw new DimInUseException("The master configuration " + configId + " cannot be deleted as it is currently in use.");
        }

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_BRANCH_OR_TYPE_ASSIGNMENTS);
        dbCtx.bindInput(configUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_CONFIG_DETAILS);
        dbCtx.bindInput(configUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_SUBORDINATES);
        dbCtx.bindInput(configUid);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_CONFIG);
        dbCtx.bindInput(configUid);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private void deleteAllReplData(DBIO dbCtx, long configUid, String configId, int repClass, int repRelClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_BRANCH_ASSIGNMENTS1);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_TYPE_ASSIGNMENTS1);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(repRelClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_CONFIG_DETAILS1);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_RECEIVE_LOGS_DETAILS);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_TRANSFER_LOGS_DETAILS);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_RECEIVE_LOGS_DETAILS1);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_TRANSFER_LOGS_DETAILS1);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_RECEIVE_LOGS_DETAILS2);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_TRANSFER_LOGS_DETAILS2);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_RECEIVE_ITEMS);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_TRANSFER_ITEMS);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_RECEIVE_ITEMS1);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        dbCtx.resetMessage(wcm_sql.REPL_DELETE_TRANSFER_ITEMS1);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private boolean isMasterConfigInUse(DBIO dbCtx, long configUid) throws Exception {

        // check if the replication configuration to be deleted is a master configuration currently being used
        dbCtx.resetMessage(wcm_sql.REPL_IS_MASTER_IN_USE1);
        dbCtx.bindInput(configUid);
        dbCtx.readStart();
        boolean isMasterInUse = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        if (isMasterInUse) {
            return true;
        }

        // check if the replication configuration to be deleted is a master configuration currently being used
        dbCtx.resetMessage(wcm_sql.REPL_IS_MASTER_IN_USE2);
        dbCtx.bindInput(configUid);
        dbCtx.readStart();
        isMasterInUse = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        if (isMasterInUse) {
            return true;
        }

        return false;
    }
}

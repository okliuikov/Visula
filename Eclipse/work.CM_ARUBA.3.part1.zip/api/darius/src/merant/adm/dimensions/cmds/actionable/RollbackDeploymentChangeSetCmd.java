/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.util.List;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.DeploymentChangeSet;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will rollback Dimensions objects from specified area at specified date and time.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_LIST {AdmObject}<dt><dd>List of Dimensions objects</dd>
 *  <dt>WORKSET {String}<dt><dd>Workset name.  If not provided, current workset is taken</dd>
 *  <dt>COMMENT {String}<dt><dd>Comment</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {Boolean}<dt><dd>Whether child requests should be deployed as well</dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author skorneychuk
 */
public class RollbackDeploymentChangeSetCmd extends RPCExecCmd {

    public RollbackDeploymentChangeSetCmd() throws AttrException {
        super();
        setAlias(Actionable.ROLLBACK_DEPLOYMENT_CHANGE_SET);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));// object to rollback - Deployment Change Set
        setAttrDef(new CmdArgDef(CmdArguments.DEPLOY_AREAS, true, List.class)); // list of file area objects
        setAttrDef(new CmdArgDef(CmdArguments.SCHEDULE_DATETIME, false, String.class)); // ISO8601 format in the UTC timezone -
                                                                                        // 'YYYY'-'MM'-'DD'T'HH24':'MI':'SS'.'sss'Z'
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (attrValue != null && (!(attrValue instanceof DeploymentChangeSet))) {
                throw new AttrException("Error: RollbackDeploymentChangeSetCmd - object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.DEPLOY_AREAS)) {
            if (attrValue instanceof List) {
                List list = (List) attrValue;
                if (list.size() == 0) {
                    throw new AttrException("Error: RollbackDeploymentChangeSetCmd - empty list of areas to rollback!", attrDef,
                            attrValue);
                }
            } else {
                throw new AttrException("Error: RollbackDeploymentChangeSetCmd - no areas specified!", attrDef, attrValue);
            }
        }
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List<AdmObject> areas = (List<AdmObject>) getAttrValue(CmdArguments.DEPLOY_AREAS);
        StringBuffer sb = new StringBuffer();
        if (admObj == null) {
            throw new DimMandatoryAttributeException("Error: Deployment Change Set must be specified.");
        }
        sb.append("XDATA ROLLBACK /PARAMETER=(DCS_UID=");
        sb.append(admObj.getAdmSpec().getSpec());
        String scheduled_date = (String) getAttrValue(CmdArguments.SCHEDULE_DATETIME);
        if (scheduled_date != null) {
            sb.append(",DEPLOY_START_TIME=\"");
            sb.append(scheduled_date);
            sb.append("\"");
        }
        if (areas != null && areas.size() > 0) {
            sb.append(",");
            StringBuffer area_specs = new StringBuffer();
            for (int i = 0; i < areas.size(); i++) {
                if (i != 0) {
                    area_specs.append(",");
                }
                area_specs.append(areas.get(i).getId());
            }
            sb.append("AREA_LIST=" + Encoding.escapeDMCLI(area_specs.toString()));
        }
        sb.append(")");
        _cmdStr = sb.toString();
    }
    
    @Override
    public Object execute() throws AdmException {
        return executeRpc();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2010 Serena Software. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.ListDeploymentAreaVersionsResult;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.helper.IDeploymentViewConstants;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.AreaVersion;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmSpecTwin;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Returns list of area versions for ( Requests , Baselines or Items )
 */
public class QueryAreaVersionsCmd extends RPCCmd implements IDeploymentViewConstants {
    /**
     * Constructor defines the command definition and arguements.
     */
    public QueryAreaVersionsCmd() throws AdmObjectException, AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, List.class)); // list of objects to rollback - Item,
                                                                                   // ChangeDocument or Baseline
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, WorkSet.class)); // project
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT_LIST)) {
            if (attrValue instanceof List) {
                List list = (List) attrValue;
                Class type = null;
                for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                    Object object = iterator.next();
                    if (object == null) {
                        throw new AttrException("Error: QueryAreaVersionsCmd - null object in the list is not supported!", attrDef,
                                attrValue);
                    }
                    if ((!(object instanceof Item)) && (!(object instanceof ChangeDocument)) && (!(object instanceof Baseline))) {
                        throw new AttrException("Error: QueryAreaVersionsCmd - object type in the list is not supported!", attrDef,
                                object);
                    }
                }
            }
        }
    }

    @Override
    public Object execute() throws AdmException {

        List list = new ArrayList();
        int inputFlags = 0;
        List objList = (List) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        if (objList == null || objList.size() == 0) {
            throw new AttrException("Error: QueryAreaVersionsObjectsCmd - empty list of area version!");
        }
        Object obj = getAttrValue(CmdArguments.WORKSET);
        int projUID = -1;
        if (obj instanceof WorkSet) {
            projUID = getAdmUID((WorkSet) obj);
        }

        int[] objFlags = new int[objList.size()];
        int[] objUids = new int[objList.size()];
        int[] objClasses = new int[objList.size()];
        for (int i = 0; i < objUids.length; i++) {
            AdmObject admObj = (AdmObject) objList.get(i);
            objFlags[i] = 0;// not in use for now
            objUids[i] = getAdmUID(admObj);
            objClasses[i] = getClassID(admObj.getClass());
        }
        try {
            ListDeploymentAreaVersionsResult listResults = getSession().getConnection().rpcGetDeploymentAreaVersions(inputFlags,
                    projUID, objFlags, objUids, objClasses);
            long k = listResults.getResultCount();
            int[] flags = listResults.getAreaVersionFlags();
            String[] specs = listResults.getAreaVersionSpecs();
            int[] projUids = listResults.getProjectUids();
            String[] projSpecs = listResults.getProjectSpecs();

            if (specs != null && specs.length > 0 && flags != null && k > 0) {
                for (int i = 0; i < specs.length && i < flags.length; i++) {
                    AdmObject admObj = AdmCmd.getObject(AdmCmd.newAdmBaseId(specs[i], AreaVersion.class));
                    admObj.setAttrValue(AdmAttrNames.DEPLOY_AREA_VERSION_FLAG, Integer.valueOf(flags[i]));
                    if (projUids != null && i < projUids.length && projUids[i] > 0) {
                        AdmSpecTwin specTwin = null;
                        if (projSpecs != null && i < projSpecs.length && projSpecs[i] != null) {
                            specTwin = new AdmSpecTwin(projSpecs[i], WorkSet.class);
                        }
                        AdmObject wsObj = AdmCmd.getObject(AdmCmd.newAdmBaseId(projUids[i], WorkSet.class, null, specTwin));
                        admObj.setAttrValue(AdmAttrNames.PROJECT, wsObj);
                    }
                    list.add(admObj);
                }
            }
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
        return list;
    }

    private int getAdmUID(AdmObject admObj) throws AdmException {
        if (admObj != null) {
            AdmUid uid = (AdmUid) AdmCmd.getAttributeValue(admObj, AdmAttrNames.ADM_UID);
            if (uid != null) {
                return (int) uid.getUid();
            }
        }
        return -1;
    }

    private int getClassID(Class childClass) {
        if (ChangeDocument.class.equals(childClass)) {
            return CLASS_REQUEST;
        } else if (Baseline.class.equals(childClass)) {
            return CLASS_BASELINE;
        } else if (ItemFile.class.equals(childClass)) {
            return CLASS_ITEM;
        }
        return -1;
    }

}
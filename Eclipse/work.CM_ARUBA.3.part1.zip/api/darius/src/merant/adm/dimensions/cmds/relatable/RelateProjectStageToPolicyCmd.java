/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.PreservationPolicy;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions ProjectStage via SPSP command line
 * 
 * @author Yudong Cai
 * @version 23 March 2006
 */
public class RelateProjectStageToPolicyCmd extends RPCExecCmd {

    public RelateProjectStageToPolicyCmd() throws AttrException {

        super();
        setAlias(Relatable.RELATE_PROJECTSTAGE_TO_POLICY);
        setAttrDef(new CmdArgDef(CmdArguments.STAGE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {

        validateAllAttrs();

        AdmObject policyObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        String policyName = (String) policyObj.getAttrValue(AdmAttrNames.ID);

        String projectName = (String) getAttrValue(CmdArguments.WORKSET);

        String stageName = (String) getAttrValue(CmdArguments.STAGE);

        if (policyName != null && projectName != null && stageName != null) {
            _cmdStr = "SPSP";
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(projectName);
            _cmdStr += " /STAGE=" + Encoding.escapeDMCLI(stageName);

            if (policyName.indexOf(":") == -1) { // policy name don't have product id appended
                int index = projectName.indexOf(":");
                if (index != -1) {
                    String productId = projectName.substring(0, index);
                    policyName = productId + ":" + policyName;
                }
            }

            _cmdStr += " /POLICY=" + Encoding.escapeDMCLI(policyName);

            AdmResult retResult = new AdmResult(executeRpc());
            AdmCmd.populateBaseIdFromAdmResult(this, retResult, PreservationPolicy.class);
            return retResult;
        }
        return null;
    }
}

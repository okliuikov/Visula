/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ReplInwardTransfer;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Baselines that were successfully or unsuccessfully transferred by the Replication Inward Transfer object.
 * <p>
 * In order to obtain the corresponding baseline Id (ala Replication Log in Replicator Administration Tool), simply convert the
 * returned AdmBaseId's to full objects and query their ADM_SPEC. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions work set container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class QCReplInwardTransferToBaselineCmd extends QueryRelsCmd {
    public QCReplInwardTransferToBaselineCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReplInwardTransfer)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(Baseline.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    // initialize filter
    String filterSuccess = "SUCCESS";

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {

        String typeName = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TYPE_NAME);
        if (!"BR".equals(typeName)) {
            throw new DimNotExistsException("Error: baselines are not replicated by item replication.");
        }

        if (filter != null) {
            processFilter(filter);
        }

        List ret = new ArrayList();

        long relUid = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.REPL_REL_UID)).longValue();

        DBIO query = new DBIO(wcm_sql.REPL_QUERY_INWARD_TRANSFER_BASELINES);

        query.bindInput(relUid);
        query.bindInput(filterSuccess);
        query.readStart();

        while (query.read()) {

            long baselineUid = query.getLong(1);
            if (baselineUid > 0) {

                long replObjUid = query.getLong(2);
                AdmBaseId uidBaseId = AdmHelperCmd.newAdmBaseId(baselineUid, Baseline.class, null, null);
                addRelation(ret, relationships, admObj.getAdmBaseId(), uidBaseId);
            }
        }

        return ret;
    }

    private void processFilter(FilterImpl f) {

        if (f == null) {
            return;
        }

        Collection crits = f.criteria();

        if (crits != null && !crits.isEmpty()) {
            for (Iterator it = crits.iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit == null) {
                    continue;
                }
                String attrName = crit.getAttrName();

                // filter by whether baseline was transfered successfully or unsuccessfully?
                if (AdmAttrNames.REPL_IS_SUCCESS.equals(attrName) && crit.getValue() != null) {
                    if (Boolean.TRUE.equals(crit.getValue())) {
                        filterSuccess = "SUCCESS";
                    } else if (Boolean.FALSE.equals(crit.getValue())) {
                        filterSuccess = "FAILURE";
                    }
                }
            }
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2000 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.interfaces;

/**
 * This class contains the constants used for command events.
 * <p>
 * The static int's within this class are used as the status numbers within an Execution Event for AdmCmd's.
 * @todo Support single AdmCmd operations as well as AdmIterativeCmd.
 * @author Floz
 */
public class AdmCmdEvents {
    /**
     * Fired when execute throws an exception.
     * <p>
     * User Data(Throwable), exception thrown by execute.
     */
    public static final int ERROR = -1;

    /**
     * Fired when in heavy processing blocks to
     * indicate life within the command.
     * <p>
     * User Data(null by default).
     * @todo This event is not yet supported.
     */
    public static final int PING = 0;

    /**
     * Fired after argument validation but before
     * the business logic of the execute method.
     * <p>
     * User Data(null by default).
     */
    public static final int PRE = 1;

    /**
     * Fired at the end of a successful execute.
     * <p>
     * User Data, contains result object specific to command.
     */
    public static final int POST = 2;

    /**
     * Fired (mainly by AdmIterativeCmd),
     * immediately after a PRE event to inform the
     * listeners of the size of the work to do.
     * <p>
     * User Data(Long), Contains maximum iterative size.
     */
    public static final int PROGRESS_SIZE = 3;

    /**
     * Fired (mainly by AdmIterativeCmd),
     * immediately after a POST event to inform the
     * listeners of the completion of an iteration loop.
     * User Data(Long), Contains index of iteration just completed.
     */
    public static final int PROGRESS = 4;
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimDirItemNotSupportedException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Performs a merge on a set of Items (allowing full control).
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object - the checked out revision in the UEI command</dd>
 *  <dt>REVISION {String}</dt><dd>New revision id</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename of the object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>PROJECT {String}<dt><dd>Dimensions project (Specification)</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>The result</dd>
 * </dl></code>
 * @author Annette Bollmann
 */
public class UpdateExtractedItemCmd extends RPCExecCmd {
    public UpdateExtractedItemCmd() throws AttrException {
        super();
        setAlias(Versionable.MERGE_ITEM);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.REVISION, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PROJECT, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String project = (String) getAttrValue(AdmAttrNames.PROJECT);
        if (admObj instanceof ItemFile) // check for directory items
        {
            String path = ((ItemFile) admObj).getFileName();
            if (path != null && CmdUtils.isDirPath(path)) {
                throw new DimDirItemNotSupportedException();
            }
        } else if (!(admObj instanceof Item)) {
            throw new IllegalArgumentException("Update Extracted Item only supports Items");
        }

        String userFilename = (String) getAttrValue(CmdArguments.USER_FILE);
        String revision = (String) getAttrValue(CmdArguments.REVISION);

        _cmdStr = "UEI ";
        _cmdStr += Encoding.escapeSpec(admObj.getAdmSpec().getSpec());
        _cmdStr += " /USER_FILENAME=" + Encoding.escapeSpec(userFilename);

        if ((revision != null) && (revision.length() > 0)) {
            _cmdStr += " /REVISION=" + Encoding.escapeSpec(revision);
        }

        if (project != null && project.length() > 0) {
            _cmdStr += " /WORKSET=" + Encoding.escapeSpec(project);
        }
        AdmResult ret = new AdmResult(executeRpc());
        return ret;
    }

}

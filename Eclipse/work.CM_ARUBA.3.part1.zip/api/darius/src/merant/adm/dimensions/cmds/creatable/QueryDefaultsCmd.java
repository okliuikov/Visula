/*
 * Copyright (C) 2000-2004, 2010 Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCDuRulesCmd;
import merant.adm.dimensions.cmds.RPCDuRulesCmd2;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.DefaultValueNames;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.dimensions.util.Options;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will get the default values as per
 * upload rules.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT_CLASS {Class}<dt><dd>Object class that identifies type of defaults to return</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing filter information</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{Hashtable[]}<dt><dd>Contains default values keyed by attribute name.</dd>
 * </dl></code>
 * @author Vijay Bhovan
 * @author Floz
 * @author PBate
 */
public class QueryDefaultsCmd extends AdmCmd {
    public QueryDefaultsCmd() throws AttrException {
        super();
        setAlias(Creatable.QUERY_DEFAULTS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_CLASS, true, Class.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VERSION, false, new Integer(1), Integer.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT_CLASS)) {
            if (!(attrValue.equals(Item.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseException, AdmException {
        Class admObjClass = (Class) getAttrValue(CmdArguments.ADM_OBJECT_CLASS);
        FilterImpl filter = (FilterImpl) getAttrValue(CmdArguments.FILTER);
        int version = ((Integer) getAttrValue(AdmAttrNames.VERSION)).intValue();

        Hashtable[] ret = null;
        if (admObjClass.equals(Item.class)) {
            String filename = "";
            String[] filenames = null;
            if (!(filter.hasAttr(CmdArguments.FILENAME))) {
                if (!(filter.hasAttr(CmdArguments.FILE_LIST))) {
                    throw new DimInvalidAttributeException("Error, filename(s) not specified!");
                } else {
                    List fileList = (List) filter.get(CmdArguments.FILE_LIST);
                    if (fileList != null) {
                        filenames = (String[]) fileList.toArray();
                    }
                }
            } else {
                filename = (String) filter.get(CmdArguments.FILENAME);
                if (filename == null) {
                    filename = "";
                }
                filenames = new String[1];
                filenames[0] = filename;
            }

            // If filename is a directory with a trailing slash remove the slash
            // to overcome msgserver crash...
            if (CmdUtils.isDirItemPath(filename)) {
                filename = filename.substring(0, filename.length() - 1);
            }

            String productName = null;
            if (filter.hasAttr(AdmAttrNames.PRODUCT_NAME)) {
                productName = (String) filter.get(AdmAttrNames.PRODUCT_NAME);
            }

            String wsetSpec = AdmCmd.getCurRootObj(WorkSet.class).getAdmSpec().getSpec();
            if (filter.hasAttr(CmdArguments.WORKSET)) {
                wsetSpec = (String) filter.get(CmdArguments.WORKSET);
            }
            String wsetRoot = (String) AdmCmd.getCurRootObj(WorkSet.class).getAttrValue(AdmAttrNames.WSET_USER_DIR);
            if (filter.hasAttr(AdmAttrNames.WSET_USER_DIR)) {
                wsetRoot = (String) filter.get(AdmAttrNames.WSET_USER_DIR);
            }
            if (wsetRoot == null) {
                wsetRoot = "/";
            }
            Integer options = null;
            if (filter.hasAttr(CmdArguments.OPTIONS)) {
                options = (Integer) filter.get(CmdArguments.OPTIONS);
            }
            long productUid = 0L;
            if (productName != null && productName.length() != 0 && Options.getDimensionsUploadRuleIDProduct()) {
                productUid = getProductUid(productName);
            }

            String ruleId = Options.getDimensionsUploadRuleID(productUid);
            // DVDC: if there are no product-specific upload rules, then fall back.
            // although the 8040 libdurules does this anyway, we can't guarantee
            // that the msgserver is 8040 - if it is 8030, and we pass a rule ID
            // with no inclusions, then msgserver will go into an infinite loop!
            if (productUid != 0 && !hasProductDefaults(ruleId, "0")) {
                ruleId = Options.getDimensionsUploadRuleID(0);
            }

            if (version == 1) {

                // DVDC: should this instantiate the Cmd directly?
                Cmd cmd = new RPCDuRulesCmd();
                cmd.setAttrValue("newfilename", filename);
                if (productName != null && productName.length() != 0) {
                    cmd.setAttrValue("product", productName);
                }
                cmd.setAttrValue("ruleid", ruleId);
                cmd.setAttrValue("options", options);
                String return_s = (String) cmd.execute();

                if (!return_s.startsWith(Constants.SERVER_OK)) {
                    return null;
                }

                String defaults_s = return_s.substring(Constants.SERVER_OK.length());

                StringTokenizer st = new StringTokenizer(defaults_s, "\007");
                String namevalue;
                int ie;
                String name;
                String value;
                while (st.hasMoreTokens()) {
                    namevalue = st.nextToken();

                    if (namevalue == null) {
                        break;
                    }

                    if ((ie = namevalue.indexOf('=')) == -1) {
                        continue;
                    }

                    name = namevalue.substring(0, ie);
                    value = namevalue.substring(ie + 1);

                    if (name.equals("$FORMAT")) {
                        name = AdmAttrNames.FORMAT;
                    } else if (name.equals("$ITEM_ID")) {
                        name = AdmAttrNames.ID;
                    } else if (name.equals("$PRODUCT_ID")) {
                        name = AdmAttrNames.PRODUCT_NAME;
                    } else if (name.equals("$VARIANT")) {
                        name = AdmAttrNames.VARIANT;
                    } else if (name.equals("$DESCRIPTION")) {
                        name = AdmAttrNames.DESCRIPTION;
                    } else if (name.equals("$OWNING_PART_VARIANT")) {
                        name = DefaultValueNames.OWNING_PART_VARIANT;
                    } else if (name.equals("$COMMENT")) {
                        name = CmdArguments.COMMENT;
                    } else if (name.equals("$TYPE")) {
                        name = AdmAttrNames.TYPE_NAME;
                    } else if (name.equals("$OWNING_PART_ID")) {
                        name = DefaultValueNames.OWNING_PART_ID;
                    } else if (name.equals("$LIB_FILENAME")) {
                        name = AdmAttrNames.ITEM_LIB_FILE_NAME;
                    } else if (name.equals("$FILENAME")) {
                        name = AdmAttrNames.ITEMFILE_FILENAME;
                    }

                    if (ret == null) {
                        ret = new Hashtable[1];
                    }
                    if (ret[0] == null) {
                        ret[0] = new Hashtable();
                    }
                    ret[0].put(name, value);
                }

            } else {
                Cmd cmd = new RPCDuRulesCmd2();
                cmd.setAttrValue("ruleid", ruleId);
                cmd.setAttrValue("project", "0");
                if (productName != null && productName.length() != 0) {
                    cmd.setAttrValue("product", productName);
                }
                cmd.setAttrValue("workset", wsetSpec);
                cmd.setAttrValue("worksetRoot", wsetRoot);
                cmd.setAttrValue("contextRoot", wsetRoot);
                cmd.setAttrValue("filenames", filenames);
                if (version == 3) {
                    cmd.setAttrValue("extended", Boolean.TRUE);
                }
                Map[] cmdret = (Map[]) cmd.execute();
                if (cmdret != null) {
                    ret = new Hashtable[cmdret.length];
                    for (int m = 0; m < cmdret.length; ++m) {
                        if (cmdret[m] != null) {
                            String errcode = (String) cmdret[0].get("$UPLOAD_ERROR");
                            if (errcode == null) {
                                ret[m] = new Hashtable();
                                if (cmdret[m].containsKey("$COMMENT")) {
                                    ret[m].put(CmdArguments.COMMENT, cmdret[0].get("$COMMENT"));
                                }
                                if (cmdret[m].containsKey("$DESCRIPTION")) {
                                    ret[m].put(AdmAttrNames.DESCRIPTION, cmdret[0].get("$DESCRIPTION"));
                                }
                                if (cmdret[m].containsKey("$PRODUCT_ID")) {
                                    ret[m].put(AdmAttrNames.PRODUCT_NAME, cmdret[0].get("$PRODUCT_ID"));
                                }
                                if (cmdret[m].containsKey("$ITEM_ID")) {
                                    ret[m].put(AdmAttrNames.ID, cmdret[0].get("$ITEM_ID"));
                                }
                                if (cmdret[m].containsKey("$VARIANT")) {
                                    ret[m].put(AdmAttrNames.VARIANT, cmdret[0].get("$VARIANT"));
                                }
                                if (cmdret[m].containsKey("$TYPE")) {
                                    ret[m].put(AdmAttrNames.TYPE_NAME, cmdret[0].get("$TYPE"));
                                }
                                if (cmdret[m].containsKey("$FORMAT")) {
                                    ret[m].put(AdmAttrNames.FORMAT, cmdret[0].get("$FORMAT"));
                                }
                                if (cmdret[m].containsKey("$LIB_FILENAME")) {
                                    ret[m].put(AdmAttrNames.ITEM_LIB_FILE_NAME, cmdret[0].get("$LIB_FILENAME"));
                                }
                                if (cmdret[m].containsKey("$OWNING_PART_ID")) {
                                    ret[m].put(DefaultValueNames.OWNING_PART_ID, cmdret[0].get("$OWNING_PART_ID"));
                                }
                                if (cmdret[m].containsKey("$OWNING_PART_VARIANT")) {
                                    ret[m].put(DefaultValueNames.OWNING_PART_VARIANT, cmdret[0].get("$OWNING_PART_VARIANT"));
                                }
                                if (cmdret[m].containsKey("$FILENAME")) {
                                    ret[m].put(AdmAttrNames.ITEMFILE_FILENAME, cmdret[0].get("$FILENAME"));
                                }
                                if (cmdret[m].containsKey("$OWNING_PART_PCS")) {
                                    ret[m].put(DefaultValueNames.OWNING_PART_PCS, cmdret[0].get("$OWNING_PART_PCS"));
                                }
                                // not used so far - $WSPATH, $REVISION, $STATUS, $DIRPATH
                                break;
                            } else {
                                ret[m] = null; // for now don't pass error code back
                            }
                        }
                    }
                }

            }

        }

        return ret;
    }

    private long getProductUid(String productName) {
        long productUid = 0;
        try {
            DBIO query = new DBIO(wcm_sql.CPL_PRODUCT_EXISTS);
            try {
                query.bindInput(productName);
                query.readStart();
                if (query.read()) {
                    productUid = query.getLong(1);
                }
            } finally {
                query.close();
            }
        } catch (DimBaseException dbe) {
            Debug.error(dbe);
        } catch (AdmObjectException aoe) {
            Debug.error(aoe);
        }
        return productUid;
    }

    // note: userName is the rule ID, and sessionId is the item spec UID.
    private boolean hasProductDefaults(String userName, String sessionId) {
        boolean ret = false;
        try {
            DBIO query = new DBIO(wcm_sql.DUR_HAS_PRODUCT_DEFAULTS);
            try {
                query.bindInput(userName);
                query.bindInput(sessionId);
                query.readStart();
                ret = query.read();
            } finally {
                query.close();
            }
        } catch (DimBaseException dbe) {
            Debug.error(dbe);
        } catch (AdmObjectException aoe) {
            Debug.error(aoe);
        }
        return ret;
    }
}

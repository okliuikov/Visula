/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.ListDeployableAreasResult;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCCmd;
import merant.adm.dimensions.cmds.helper.IDeploymentViewConstants;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Stage;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.objects.core.AdmUidTwin;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will promote a Dimensions object.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ADM_OBJECT_LIST {AdmObject}<dt><dd>List of Dimensions objects</dd>
 *  <dt>WORKSET {Workset}<dt><dd>Workset object.  If not provided, current workset is taken</dd>
 *  <dt>STAGE_OBJ {Stage}<dt><dd>Stage  object.</dd>
 *  <dt>TRAVERSE_CHILD_REQUESTS {Boolean}<dt><dd>Whether child requests should be deployed as well</dd>
 *  <dt>EXCLUDE_PREV_STAGE_AREAS {Boolean}<dt><dd>???</dd>
 *  <dt>EXCLUDE_ALREADY_DEPLOYED_TO_AREAS {Boolean}<dt><dd>???</dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author skorneychuk
 */
public class FetchDeployableAreasCmd extends RPCCmd implements IDeploymentViewConstants {

    public FetchDeployableAreasCmd() throws AttrException {
        super();
        setAlias(Actionable.FETCH_DEPLOYABLE_AREAS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_OBJ, false, Stage.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.DEPLOY_RPC_FLAG, false, Integer.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.DEPLOY_RPC_FLAG)) {
            if (attrValue != null) {
                int value = -1;
                try {
                    value = ((Integer) attrValue).intValue();
                } catch (NumberFormatException nfe) {
                }
                if (!(value == Constants.DAOP_DEPLOY || value == Constants.DAOP_DEMOTE || value == Constants.DAOP_PROMOTE || value == Constants.DAOP_ROLL_BACK)) {
                    throw new AttrException("Error: FetchDeployableAreasCmd - the operation value is invalid or out of range!",
                            attrDef, attrValue);
                }
            }
        } else if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((attrValue != null) && (!(attrValue instanceof Item)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof Baseline))) {
                throw new AttrException("Error: FetchDeployableAreasCmd - object type is not supported!", attrDef, attrValue);
            }
        } else if (name.equals(CmdArguments.ADM_OBJECT_LIST)) {
            if (attrValue instanceof List) {
                List list = (List) attrValue;
                Class type = null;
                for (Iterator iterator = list.iterator(); iterator.hasNext();) {
                    Object object = iterator.next();
                    if (object == null) {
                        throw new AttrException("Error: FetchDeployableAreasCmd - null object in the list is not supported!",
                                attrDef, attrValue);
                    }
                    if (type == null) {
                        type = object.getClass();
                    }
                    if (!type.equals(object.getClass())) {
                        throw new AttrException("Error: FetchDeployableAreasCmd - all objects in the list must be the same type!",
                                attrDef, attrValue);
                    }
                }
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        List<AdmObject> admObjects = (List<AdmObject>) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        Stage stage = (Stage) getAttrValue(AdmAttrNames.STAGE_OBJ);
        Boolean traverseChildRequests = (Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS);
        if (admObj == null && (admObjects == null || admObjects.size() == 0)) {
            throw new DimMandatoryAttributeException("Error: Object or list of objects must be specified.");
        }
        if (admObjects == null) {
            admObjects = new ArrayList<AdmObject>();
        }
        if (admObj != null) {
            admObjects.add(0, admObj); // make object to be first in the list
        }

        int flags = LDAF_EXCLUDE_PREV_STAGE_AREAS;
        if (traverseChildRequests != null && traverseChildRequests) {
            flags |= LDAF_TRAVERSE_CHILD_REQUESTS;
        }

        int[] objectUids = new int[admObjects.size()];
        int objectClass = 0;

        for (int i = 0; i < objectUids.length; i++) {
            AdmObject admObject = admObjects.get(i);
            objectUids[i] = getAdmUID(admObject);
            if (objectClass == 0) {
                objectClass = TypeUtils.getClassInt(admObject.getClass());
            }
        }
        Integer mode = (Integer) getAttrValue(CmdArguments.DEPLOY_RPC_FLAG);
        int rpcOperation = Constants.DAOP_DEPLOY;
        if (mode != null) {
            rpcOperation = mode.intValue();
        }

        try {
            ListDeployableAreasResult listRes = getSession().getConnection().rpcListDeployableAreas(getAdmUID(project), objectUids,
                    objectClass, getAdmUID(stage), flags, rpcOperation);
            if (listRes != null) {
                int[] areaUids = listRes.getAreaUids();
                String[] areaNames = listRes.getAreaNames();
                int[] areaFlags = listRes.getAreaFlags();
                if (areaUids != null && areaUids.length > 0 && areaNames != null && areaNames.length > 0) {
                    List baseIds = new ArrayList();
                    for (int i = 0; i < areaUids.length && i < areaNames.length; i++) {
                        baseIds.add(AdmHelperCmd.newAdmBaseId(areaNames[i], FileArea.class, null, new AdmUidTwin(areaUids[i],
                                FileArea.class)));
                    }
                    List areas = AdmHelperCmd.getObjects(baseIds);
                    for (int i = 0; i < areas.size(); i++) {
                        for (int j = 0; j < areaUids.length; j++) {
                            if (((FileArea) areas.get(i)).getAdmUid().getUid() == areaUids[j]) {
                                ((FileArea) areas.get(i)).setAttrValue(CmdArguments.WS_AREA_DEPLOY_BY_DEFAULT, new Boolean(
                                        (areaFlags[j] & 0x01) == 1));
                                ((FileArea) areas.get(i)).setAttrValue(CmdArguments.NO_DEPLOY_PRIVILEGE_TO_AREA, new Boolean(
                                        (areaFlags[j] & 0x02) == 2));
                                break;
                            }
                        }
                    }
                    return areas;
                }
            }
        } catch (IOException ioe) {
            throw new AdmException(ioe);
        }
        return null;
    }

    private int getAdmUID(AdmObject admObj) throws AdmException {
        if (admObj != null) {
            AdmUid uid = (AdmUid) AdmCmd.getAttributeValue(admObj, AdmAttrNames.ADM_UID);
            if (uid != null) {
                return (int) uid.getUid();
            }
        }
        return -1;
    }

}

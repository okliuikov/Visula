/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.AdmUidObjectImpl;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.ArrayTree;
import merant.adm.dimensions.util.Tree;
import merant.adm.dimensions.util.TreeHandle;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

class ItemPedigreeKey extends ArrayList implements Comparable {
    private long _itemUid = 0L;

    public long getItemUid() {
        return _itemUid;
    }

    private long _specUid = 0L;

    public long getSpecUid() {
        return _specUid;
    }

    private String _spec = null;

    public String getSpec() {
        return _spec;
    }

    public ItemPedigreeKey(long itemUid, long specUid, String spec) {
        _itemUid = itemUid;
        _specUid = specUid;
        _spec = spec;
    }

    public ItemPedigreeKey(AdmObject admObj) {
        _itemUid = 0L;
        _specUid = 0L;
        _spec = null;

        try {
            AdmUidObjectImpl item = (AdmUidObjectImpl) admObj;
            if (item.getAttrValue(AdmAttrNames.SPEC_UID) != null) {
                _specUid = ((Long) item.getAttrValue(AdmAttrNames.SPEC_UID)).longValue();
            } else if (item.getAdmSpecRaw() != null) {
                String productName = (String) item.getAttrValue(AdmAttrNames.PRODUCT_NAME);
                String id = (String) item.getAttrValue(AdmAttrNames.ID);
                String variant = (String) item.getAttrValue(AdmAttrNames.VARIANT);
                String typeName = (String) item.getAttrValue(AdmAttrNames.TYPE_NAME);
                if ((productName != null) && (id != null) && (variant != null) && (typeName != null)) {
                    _spec = productName + ":" + id + "." + variant + "-" + typeName;
                } else {
                    _specUid = ((Long) AdmHelperCmd.getAttributeValue(item, AdmAttrNames.SPEC_UID)).longValue();
                }
            } else if (item.getAdmUidRaw() != null) {
                _itemUid = item.getAdmUidRaw().getUid();
            } else {
                _specUid = ((Long) AdmHelperCmd.getAttributeValue(item, AdmAttrNames.SPEC_UID)).longValue();
            }
        } catch (Exception e) {
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }

        if (!(o instanceof ItemPedigreeKey)) {
            return false;
        }

        ItemPedigreeKey pk = (ItemPedigreeKey) o;
        if (pk.getItemUid() != 0L) {
            if (getItemUid() == pk.getItemUid()) {
                return true;
            }
        } else if (pk.getSpecUid() != 0L) {
            if (getSpecUid() == pk.getSpecUid()) {
                return true;
            }
        } else if (getSpec() != null) {
            if (getSpec().equals(pk.getSpec())) {
                return true;
            }
        }

        return false;
    }

    // DON'T NEED THIS BUT Hastable Requires Comparable
    @Override
    public int compareTo(Object o) {
        if (!equals(o)) {
            return -1;
        }

        return 0;
    }
}

/**
 * Queries all pedigree related to the primary object.
 * <p>
 * Use ADM_CHILD_CLASS or ADM_PARENT_CLASS for direction. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions related object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's</dd>
 * </dl></code>
 * @author Floz
 * @todo Fix handleOf
 */
public class _internal_pedigree extends DBIOCmd {
    public void displayTree(TreeHandle treeHandle, String tabs) {
        List kids = treeHandle.getTree().getChildren(treeHandle);
        if (kids != null) {
            for (int i = 0; i < kids.size(); i++) {
                displayTree((TreeHandle) kids.get(i), tabs + "    ");
            }
        }
    }

    public void displayTree(Tree tree) {
        List kids = tree.getChildren(tree.getRoot());
        if (kids != null) {
            for (int i = 0; i < kids.size(); i++) {
                displayTree((TreeHandle) kids.get(i), "        ");
            }
        }
    }

    public _internal_pedigree() throws AttrException {
        super();
        setAlias("_internal_pedigree");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_SEC_CLASS, false, Class.class));
        setAttrDef(new CmdArgDef("QUERY_CHILDREN", false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
    }

    private TreeHandle findParent(Tree tree, TreeHandle child, AdmObject admObj) {
        List parents = tree.getParents(child);
        if (parents == null) {
            return null;
        }

        TreeHandle th = null;
        for (int i = 0; i < parents.size(); i++) {
            th = (TreeHandle) parents.get(i);
            try {
                if (((AdmObject) th.get()).getAdmBaseId().equals(admObj.getAdmBaseId())) {
                    return th;
                }
            } catch (Exception e) {
            }
        }

        return null;
    }

    private TreeHandle handleOf(Tree tree, AdmObject admObj) {
        Iterator it = tree.iterator();

        TreeHandle th = null;
        while (it.hasNext()) {
            th = (TreeHandle) it.next();
            try {
                if (((AdmUidObject) th.get()).getAdmUid().getUid() == ((AdmUidObject) admObj).getAdmUid().getUid()) {
                    return th;
                }
            } catch (Exception e) {
            }
        }

        return null;
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Class admSecClass = (Class) getAttrValue(CmdArguments.ADM_SEC_CLASS);
        boolean queryChildren = ((Boolean) getAttrValue("QUERY_CHILDREN")).booleanValue();

        Tree tree = null;
        List handles = null;
        TreeHandle th = null;
        TreeHandle child = null;
        AdmUidObject treeObj = null;
        AdmUidObject prevObj = null;
        List ret = new Vector();

        if ((admObj instanceof Item) && (admSecClass.equals(Item.class) || admSecClass.equals(ItemFile.class))) {
            ItemPedigreeKey key = new ItemPedigreeKey(admObj);
            if (AdmCmd.getCache().contains(key)) {
                tree = (Tree) AdmCmd.getCache().get(key);
            } else {
                long specUid = 0L;
                String itemSpec = null;
                long itemUid = ((AdmUidObject) admObj).getAdmUid().getUid();
                DBIO query = new DBIO(wcm_sql.GET_ITEM_ITEM_PEDIGREE);
                query.bindInput(itemUid);
                query.readStart();
                while (query.read()) {
                    specUid = query.getLong(2);
                    itemSpec = query.getString(3);
                    treeObj = (AdmUidObject) AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getLong(1), admSecClass, null,
                            AdmHelperCmd.newAdmBaseId(itemSpec + ";" + query.getString(8), admSecClass, null, null)));
                    prevObj = (AdmUidObject) AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(query.getLong(9), admSecClass, null,
                            AdmHelperCmd.newAdmBaseId(itemSpec + ";" + query.getString(10), admSecClass, null, null)));

                    if (tree == null) {
                        tree = new ArrayTree(treeObj);
                    } else {
                        th = handleOf(tree, prevObj);
                        if (th != null) {
                            child = handleOf(tree, treeObj);
                            if (child == null) {
                                tree.addChild(th, treeObj);
                            } else if (findParent(tree, child, (AdmObject) th.get()) == null) {
                                tree.addParent(th, child);
                            }
                        }
                    }
                }

                AdmCmd.getCache().put(new ItemPedigreeKey(itemUid, specUid, itemSpec), tree);
            }

            th = handleOf(tree, admObj);
            if (th == null) {
                throw new DBIOException("Error: Failed to find object within the returned pedigree!");
            }

            if (queryChildren) {
                handles = tree.getChildren(th);
            } else {
                handles = tree.getParents(th);
            }

            if (handles == null) {
                return null;
            }

            for (int i = 0; i < handles.size(); i++) {
                ret.add(((AdmObject) ((TreeHandle) handles.get(i)).get()).getAdmBaseId());
            }
        } else {
            throw new DBIOException("Error: Object types are not supported!");
        }

        return ret;
    }
}

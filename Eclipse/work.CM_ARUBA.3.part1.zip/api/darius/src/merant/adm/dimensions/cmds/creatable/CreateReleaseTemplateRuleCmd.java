/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.ReleaseTemplateRule;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions ReleaseTemplateRule.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name used exclusively for role checking</dd>
 *  <dt>TEMPLATE_ID {String}</dt><dd>Release Template name of the parent for the new rule</dd>
 *  <dt>ID {String}</dt><dd>Name identifier of the new release template</dd>
 *  <dt>VARIANT {String}</dt><dd>Variant of the new release template</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b>
 * <dt>RELTR_ITEMTYPE {String}</dt>
 * <dd>Item type name of the new release template rule. This parameter is mutually exclusive with RELTR_ITEMTYPEGRP</dd>
 * <dt>RELTR_ITEMTYPEGRP {String}</dt>
 * <dd>Item type group name of the new release template rule. This parameter is mutually exclusive with RELTR_ITEMTYPE</dd>
 * <dt>RELTR_SUBDIR {String}</dt>
 * <dd>Sub-directory of the new release template</dd>
 * <code><dl>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateReleaseTemplateRuleCmd extends DBIOCmd {
    public CreateReleaseTemplateRuleCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TEMPLATE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.VARIANT, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTR_ITEMTYPE, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTR_ITEMTYPEGRP, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RELTR_SUBDIR, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        final String productId = ValidationHelper.validateProductId((String) getAttrValue(AdmAttrNames.PRODUCT_NAME));
        final String templateId = ValidationHelper.validateReleaseTemplateId((String) getAttrValue(AdmAttrNames.TEMPLATE_ID));
        final String partId = ValidationHelper.validatePartId((String) getAttrValue(AdmAttrNames.ID));
        final String variant = ValidationHelper.validateVariant((String) getAttrValue(AdmAttrNames.VARIANT));
        String itemTypeId = ValidationHelper.validateItemTypeId((String) getAttrValue(AdmAttrNames.RELTR_ITEMTYPE), true);
        String itemTypeGroup = ValidationHelper.validateItemTypeId((String) getAttrValue(AdmAttrNames.RELTR_ITEMTYPEGRP), true);
        final String subDir = ValidationHelper.validateReleaseSubDir((String) getAttrValue(AdmAttrNames.RELTR_SUBDIR), true);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_TEMPLATEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_TEMPLATEMAN");
        }

        // validate baseline template rule details - if we get an exception, then the rule is invalid
        Cmd cmd = AdmCmd.getCmd("_internal_validate_release_template_rule");
        cmd.setAttrValue(AdmAttrNames.PRODUCT_NAME, productId);
        cmd.setAttrValue(AdmAttrNames.TEMPLATE_ID, templateId);
        cmd.setAttrValue(AdmAttrNames.ID, partId);
        cmd.setAttrValue(AdmAttrNames.VARIANT, variant);
        cmd.setAttrValue(AdmAttrNames.RELTR_ITEMTYPE, itemTypeId);
        cmd.setAttrValue(AdmAttrNames.RELTR_ITEMTYPEGRP, itemTypeGroup);
        cmd.setAttrValue(AdmAttrNames.RELTR_SUBDIR, subDir);
        cmd.setAttrValue(CmdArguments.UPDATE, Boolean.FALSE);
        cmd.execute();

        final String typeName = (itemTypeId != null ? itemTypeId : itemTypeGroup);

        final String userId = AdmCmd.getCurRootObj(User.class).getId();

        setAttrValue(CmdArguments.INT_SPEC, templateId + ":" + partId + "." + variant + ";" + typeName);

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
            @Override
            public void execute(DBIO dbCtx) throws Exception {
                // Now insert into database...
                dbCtx.resetMessage(wcm_sql.CREATE_RELEASETR);
                dbCtx.bindInput(templateId);
                dbCtx.bindInput(partId);
                dbCtx.bindInput(variant);
                dbCtx.bindInput(subDir, String.class);
                dbCtx.bindInput(typeName);
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

                SqlUtils.releaseTemplateUpdateHistory(dbCtx, userId, templateId);
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ReleaseTemplateRule.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.versionable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Versionable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Performs a comparison on a set of objects.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>BRANCHES {List}</dt><dd>List of objects to compare</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>BASE {AdmObject}</dt><dd>An ancestor to calculate differences against</dd>
 *  <dt>REPORT {Boolean}</dt><dd>Specifies that a human-readable report be returned</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{InputStream}</dt><dd>Access to the delta's calculated by the comparison</dd>
 * </dl></code>
 * @author Floz
 */
public class CompareCmd extends AdmCmd {
    public CompareCmd() throws AttrException {
        super();
        setAlias(Versionable.COMPARE);
        setAttrDef(new CmdArgDef(CmdArguments.BRANCHES, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASE, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REPORT, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        Cmd cmd = AdmCmd.getCmd(Versionable.MERGE);
        cmd.setAttrValue(CmdArguments.BRANCHES, getAttrValue(CmdArguments.BRANCHES));
        cmd.setAttrValue(CmdArguments.BASE, getAttrValue(CmdArguments.BASE));
        cmd.setAttrValue(CmdArguments.REPORT, getAttrValue(CmdArguments.REPORT));
        return cmd.execute();
    }
}

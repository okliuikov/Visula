/*
 * Copyright (C) 2005, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ValidCMRelationship;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Valid CM Relationship.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>CMREL_TYPE_OBJ{AdmObject}<dt><dd>Parent request type</dd>
 *  <dt>CMREL_RELATED_TYPE_OBJ{AdmObject}<dt><dd>Child item/request type</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>CMREL_MIN_STATUS_ATTRDEF{AdmObject}<dt>
 *  <dd>Minimum status attribute</dd>
 *  <dt>CMREL_MAX_STATUS_ATTRDEF{AdmObject}<dt>
 *  <dd>Maximum status attribute</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateValidCmRelCmd extends RPCExecCmd {
    public CreateValidCmRelCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.CMREL_TYPE_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CMREL_RELATED_TYPE_OBJ, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CMREL_MIN_STATUS_ATTRDEF, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CMREL_MAX_STATUS_ATTRDEF, false, AdmObject.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {
        validateAllAttrs();

        AdmObject parentTypeObj = (AdmObject) getAttrValue(AdmAttrNames.CMREL_TYPE_OBJ);
        AdmObject childTypeObj = (AdmObject) getAttrValue(AdmAttrNames.CMREL_RELATED_TYPE_OBJ);
        AdmObject minAttrDef = (AdmObject) getAttrValue(AdmAttrNames.CMREL_MIN_STATUS_ATTRDEF);
        AdmObject maxAttrDef = (AdmObject) getAttrValue(AdmAttrNames.CMREL_MAX_STATUS_ATTRDEF);

        List attrNames = Arrays.asList(new String[]{AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS});
        List attrs1 = AdmHelperCmd.getAttributeValues(parentTypeObj, attrNames);
        List attrs2 = AdmHelperCmd.getAttributeValues(childTypeObj, attrNames);

        if (attrs1 == null || attrs1.size() != 3) {
            throw new DimBaseCmdException("Failed to query attributes of parent request type.");
        }
        if (attrs2 == null || attrs2.size() != 3) {
            throw new DimBaseCmdException("Failed to query attributes of child object type.");
        }

        String parentProductId = ((String) attrs1.get(0)).trim().toUpperCase();
        String parentTypeId = ((String) attrs1.get(1)).trim().toUpperCase();
        Class parentTypeClass = (Class) attrs1.get(2);

        String childProductId = ((String) attrs2.get(0)).trim().toUpperCase();
        String childTypeId = ((String) attrs2.get(1)).trim().toUpperCase();
        Class childTypeClass = (Class) attrs2.get(2);

        if (!ChangeDocument.class.equals(parentTypeClass)) {
            throw new DimInvalidAttributeException("Object type " + parentProductId + ":" + parentTypeId
                    + " is not a request type.");
        }

        if (!Item.class.equals(childTypeClass) && !ChangeDocument.class.equals(childTypeClass)) {
            throw new DimInvalidAttributeException("Object type " + childProductId + ":" + childTypeId
                    + " is not an item or request type.");
        }

        // ignore these attrs unless relating to a request type
        if (!childTypeClass.equals(ChangeDocument.class)) {
            minAttrDef = null;
            maxAttrDef = null;
        }

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /ADD_RELATIONSHIP ");
        cmdBuf.append(Encoding.escapeDMCLI(parentTypeId));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(parentProductId));

        if (parentTypeClass.equals(Item.class)) {
            cmdBuf.append(" /OBJ_CLASS=ITEM");
        } else if (parentTypeClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else {
            throw new DimInvalidAttributeException("Error: Unable to add relationship to specified object type.");
        }

        cmdBuf.append(" /REL_PRODUCT=").append(Encoding.escapeDMCLI(childProductId));
        cmdBuf.append(" /REL_TYPE_NAME=").append(Encoding.escapeDMCLI(childTypeId));

        if (childTypeClass.equals(Item.class)) {
            cmdBuf.append(" /REL_OBJ_CLASS=ITEM");
        } else if (childTypeClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /REL_OBJ_CLASS=REQUEST");
        } else {
            throw new DimInvalidAttributeException("Error: Unable to add relationship of specified related object type.");
        }

        if (childTypeClass.equals(ChangeDocument.class)) {
            if (minAttrDef != null) {
                String minAttrName = (String) AdmHelperCmd.getAttributeValue(minAttrDef, AdmAttrNames.ID);
                if (minAttrName != null && minAttrName.length() > 0)
                    cmdBuf.append(" /MIN_STATE_ATTR=").append(Encoding.escapeDMCLI(minAttrName));
            }

            if (maxAttrDef != null) {
                String maxAttrName = (String) AdmHelperCmd.getAttributeValue(maxAttrDef, AdmAttrNames.ID);
                if (maxAttrName != null && maxAttrName.length() > 0)
                    cmdBuf.append(" /MAX_STATE_ATTR=").append(Encoding.escapeDMCLI(maxAttrName));
            }
        }

        _cmdStr = cmdBuf.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ValidCMRelationship.class);
        return retResult;
    }
}

package merant.adm.dimensions.cmds.assignable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class HidePromotionCmd extends RPCExecCmd {
    public HidePromotionCmd() throws AttrException {
        super();
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.AREA_ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RPC_MODE, false, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((attrValue != null) && (!(attrValue instanceof Item)) && (!(attrValue instanceof ChangeDocument))
                    && (!(attrValue instanceof Baseline))) {
                throw new AttrException("Error: QCHidePromotionCmd - object type is not supported!", attrDef, attrValue);
            }
        }
    }
    
    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        return executeRpc();
    }

    @Override
    public void prepareCommand(boolean preview) throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmObject project = (AdmObject) getAttrValue(CmdArguments.WORKSET);
        String area = (String) getAttrValue(AdmAttrNames.AREA_ID);
        Object rpcMode = getAttrValue(CmdArguments.RPC_MODE);
        boolean doHide = true;
        if (rpcMode != null && rpcMode instanceof Boolean) {
            doHide = ((Boolean) rpcMode).booleanValue();
        }

        StringBuffer sb = new StringBuffer();
        if (!doHide) {
            sb.append("X");
        }
        if (admObj instanceof Item) {
            sb.append("HDPI ");
        } else if (admObj instanceof ChangeDocument) {
            sb.append("HDPRQ ");
        } else if (admObj instanceof Baseline) {
            sb.append("HDPBL ");
        }

        sb.append(Encoding.escapeDMCLI(admObj.getAdmSpec().getSpec()));

        sb.append(" /AREA=" + Encoding.escapeDMCLI(area));

        sb.append(" /WORKSET=" + Encoding.escapeDMCLI(project.getAdmSpec().getSpec()));

        _cmdStr = sb.toString();
    }
}

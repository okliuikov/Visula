/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.SensitivityHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.LocalAttributeDefinition;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.system.PasswordAuthPointParam;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Local Attribute Definition object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>Whether to automatically delete the global attribute definition if it is not used by any object types.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteLocalAttrDefCmd extends RPCExecCmd {
    public DeleteLocalAttrDefCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LocalAttributeDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    /**
     * @return the text description of the result, for example:
     * <pre>
     * SUCCESS: Operation completed
     * Operation completed
     * </pre>
     */
    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // the next 2 attributes come from ADM_SPEC
        final int attrNo = ((Integer) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_ATTRNO)).intValue();
        final long typeUid = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.ATTRDEF_TYPE_UID)).longValue();

        List attrs = AdmHelperCmd.getAttributeValues(admObj, Arrays.asList(new Object[] {
                AdmAttrNames.PARENT_CLASS,
                AdmAttrNames.PRODUCT_NAME,
                AdmAttrNames.ATTRDEF_TYPE_NAME,
                AdmAttrNames.ATTRDEF_DATATYPE,
                AdmAttrNames.ATTRDEF_ATTRTYPE,
                AdmAttrNames.ID
                }));

        if (attrs == null || attrs.size() != 6) {
            throw new DimBaseCmdException("Error: failed to query single field attribute details (" + typeUid + ":" + attrNo + ")");
        }

        final Class scopeClass = (Class) attrs.get(0);
        final String productName = (String) attrs.get(1);
        final String typeName = (String) attrs.get(2);
        final Class attrDataType = (Class) attrs.get(3);
        final int attrType = ((Integer) attrs.get(4)).intValue();

        final String attrId = admObj.getId();

        // If attribute is sensitive then get authentication
        if (SensitivityHelper.isAttributeSensitive(attrNo, typeUid)) {
            PasswordAuthPointParam paramObj = new PasswordAuthPointParam(PasswordAuthPointParam.DELETE);
            paramObj.setTypeUid(typeUid);
            paramObj.setAttrNo(attrNo);
            SensitivityHelper.getAuthentication(this, paramObj);
        }

        if (User.class.equals(scopeClass)) {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_USERMAN")) {
                throw new DimNoPrivilegeException("ADMIN_USERMAN");
            }
        } else {
            // Ensure that we have the privilege to do this
            if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
                throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
            }
        }

        // Construct OBJATTR command to deassign attribute from object type, for example:
        // OBJATTR /DEASSIGN /TYPE=SS "SS3746836" /PRODUCT="QLARIUS" /OBJ_CLASS=ITEM /OBJ_TYPE="DAT"

        StringBuffer cmdBuf = new StringBuffer("OBJATTR /DEASSIGN ");
        cmdBuf.append(Encoding.escapeDMCLI(attrId));
        cmdBuf.append(" /TYPE=").append(getAttrType(attrType));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));
        cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(scopeClass));
        cmdBuf.append(" /OBJ_TYPE=").append(Encoding.escapeDMCLI(typeName));

        _cmdStr = cmdBuf.toString();
        String retResult = executeRpc();

        final String typeFlag = TypeUtils.getTypeFlag(scopeClass);
        int cntAssignedAttrs = countAssignedAttrs(attrNo, typeFlag);
        final boolean deleteGlobalAttr = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        if (deleteGlobalAttr && 0 == cntAssignedAttrs) {
            // Construct OBJATTR command to delete global attribute definition, for example:
            // OBJATTR /DELETE "SS3746836" /DATA_TYPE=CHAR /OBJ_CLASS=ITEM

            cmdBuf.setLength(0);
            cmdBuf.append(("OBJATTR /DELETE "));
            cmdBuf.append(Encoding.escapeDMCLI(attrId));

            if (String.class.equals(attrDataType))
                cmdBuf.append(" /DATA_TYPE=CHAR");
            else if (Number.class.equals(attrDataType))
                cmdBuf.append(" /DATA_TYPE=NUMERIC");
            else if (Integer.class.equals(attrDataType))
                cmdBuf.append(" /DATA_TYPE=NUMERIC");
            else if (Date.class.equals(attrDataType))
                cmdBuf.append(" /DATA_TYPE=DATE");

            cmdBuf.append(" /OBJ_CLASS=").append(TypeUtils.getClassQualifier(scopeClass));

            _cmdStr = cmdBuf.toString();
             retResult = executeRpc();
        }

        // Refresh the server attribute cache
        AdmCmd.getCmd(
                Server.REFRESH_ATTR_CACHE,
                AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(productName + ":" + typeName + "-" + scopeClass.getName(),
                        Type.class))).execute();

        return retResult;
    }

    /**
     * @param attrNo The ID of global attribute definition.
     * @param typeFlag The single character identifier of object class, for example: "C", "U", "I", etc.
     * @return The number of existing local attribute definitions, which use the global attribute, specified by attrNo
     * and typeFlag parameters.
     * @throws DBIOException
     * @throws AdmObjectException
     * @throws DimBaseException
     */
    private int countAssignedAttrs(int attrNo, String typeFlag) throws DBIOException, AdmObjectException,
            DimBaseException {
        DBIO query = new DBIO(wcm_sql.ATTRDEF_COUNT_ATTR_USAGE_80);
        query.bindInput(attrNo);
        query.bindInput(typeFlag);

        query.readStart();
        int count = 0;
        if (query.read()) {
            count = query.getInt(1);
        }
        query.close();
        return count;
    }

    private String getAttrType(final int attrType) throws DimInvalidAttributeException {
        if (attrType == Constants.ATTR_TYPE_SFSV)
            return "SS";
        else if (attrType == Constants.ATTR_TYPE_SFMV)
            return "SM";
        else if (attrType == Constants.ATTR_TYPE_MFMV)
            return "MM";
        else 
            throw new DimInvalidAttributeException("Error: invalid attribute type value.");
    }
}

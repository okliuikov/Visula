/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions lifecycle.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new lifecycle</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION {String}<dt><dd>Description for the new lifecycle</dd>
 *  <dt>BASED_ON {String}<dt><dd>Lifecycle name of an existing lifecycle on which the new one is to be based</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateLifecycleCmd extends RPCExecCmd {
    public CreateLifecycleCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASED_ON, false, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DimBaseCmdException, DimBaseException, AdmException {

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_LIFECYCLEMAN")) {
            throw new DimNoPrivilegeException("ADMIN_LIFECYCLEMAN");
        }

        validateAllAttrs();

        final String id = ValidationHelper.validateLifecycleId((String) getAttrValue(AdmAttrNames.ID));
        final String desc = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));
        final String basedOnLc = ValidationHelper.validateLifecycleId((String) getAttrValue(CmdArguments.BASED_ON), true);

        setAttrValue(CmdArguments.INT_SPEC, id);

        StringBuffer cmdBuf = new StringBuffer("LIFECYCLE /ADD ");
        cmdBuf.append(Encoding.escapeDMCLI(id));
        cmdBuf.append(" /DESCRIPTION=").append(Encoding.escapeDMCLI(desc));
        if (basedOnLc != null)
            cmdBuf.append(" /BASED_ON=").append(Encoding.escapeDMCLI(basedOnLc));

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, LifeCycle.class);
        return retResult;
    }

}

package merant.adm.dimensions.cmds.helper;

import java.util.ArrayList;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.DeploymentCheckpoint;
import merant.adm.dimensions.objects.JobDetails;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.session.BaseSession;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;

public class DeploymentCheckpointHelper {

    public static DeploymentCheckpoint getDeploymentCheckPoint() throws DBIOException, AdmException {

        long jobUid = Constants.INVALID_UID;
        int sessionID = Constants.INVALID_UID;
        DBIO query = new DBIO(wcm_sql.GET_DEPLOYMENT_CHECK_POINT);
        query.readStart();
        if (query.read()) {
            jobUid = query.getLong(1);
        }
        query.close();
        sessionID = ((BaseSession) DimSystem.getSystem().getSession()).getConnection().getSessionID();
        return new DeploymentCheckpoint(jobUid, sessionID);
    }

    public static List<JobDetails> getJobDetails(DeploymentCheckpoint deploymentCheckpoint) throws DBIOException, AdmException {

        ArrayList<JobDetails> jobDetailsList = new ArrayList<JobDetails>();
        DBIO query = new DBIO(wcm_sql.GET_JOB_DETAILS);
        query.bindInput(((AdmUidObject) AdmCmd.getCurRootObj(User.class)).getUid());
        query.bindInput(deploymentCheckpoint.getSessionID());
        query.bindInput(deploymentCheckpoint.getJobUid());
        query.readStart();
        while (query.read()) {
            jobDetailsList.add(new JobDetails(query.getLong(1), query.getInt(2)));
        }
        query.close();
        return jobDetailsList;
    }
}

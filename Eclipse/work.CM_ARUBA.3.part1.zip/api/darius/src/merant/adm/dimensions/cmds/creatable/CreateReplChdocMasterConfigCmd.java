/*
 * Copyright (C) 2003, 2006, Serena Software Europe, Ltd.
 * All rights reserved.
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplChdocMasterConfig;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions master request replication configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.ID {String}<dt><dd>Identifier of the new master request replication configuration</dd>
 *  <dt>CmdArguments.CHDOC_TYPES{List}<dt><dd>The list of (request) Type objects that are to be replicated. This list must not
 *  include request types defined in the $GENERIC product.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>AdmAttrNames.DESCRIPTION{String}<dt><dd>Description</dd>
 *  <dt>AdmAttrNames.REPL_IS_ENABLED{Boolean}<dt><dd>Whether the replication configuration is to be enabled. Default - Boolean.TRUE</dd>
 *  <dt>AdmAttrNames.REPL_IS_OFFLINE{Boolean}<dt><dd>Whether the replication configuration is offline. Default - Boolean.FALSE</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class CreateReplChdocMasterConfigCmd extends DBIOCmd {
    public CreateReplChdocMasterConfigCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CHDOC_TYPES, true, List.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_ENABLED, true, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.REPL_IS_OFFLINE, false, Boolean.FALSE, Boolean.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // extract and validate command arguments
        // extract command parameters

        final String configId = ValidationHelper.validateReplConfigId((String) getAttrValue(AdmAttrNames.ID));
        final String description = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));

        final List chdocTypeList = (List) getAttrValue(CmdArguments.CHDOC_TYPES);
        final boolean isEnabled = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_ENABLED)).booleanValue();
        final boolean isOffline = ((Boolean) getAttrValue(AdmAttrNames.REPL_IS_OFFLINE)).booleanValue();
        final boolean isTransfered = true;
        final boolean isReplicatesBack = false;

        if (chdocTypeList != null && chdocTypeList.size() > 0) {
            for (Iterator it = chdocTypeList.iterator(); it.hasNext();) {
                AdmObject chdocType = (AdmObject) it.next();
                if (chdocType == null || !(chdocType instanceof Type)) {
                    throw new DimMandatoryAttributeException("List of request types to be replicated must be specified.");
                }
                Class parentClass = (Class) AdmHelperCmd.getAttributeValue(chdocType, AdmAttrNames.PARENT_CLASS);
                if (!ChangeDocument.class.equals(parentClass)) {
                    throw new DimMandatoryAttributeException("List of request types to be replicated must be specified.");
                }

                String productId = (String) AdmHelperCmd.getAttributeValue(chdocType, AdmAttrNames.PRODUCT_NAME);
                if (Constants.GLOBAL_PRODUCT.equalsIgnoreCase(productId)) {
                    throw new DimInvalidAttributeException("Request type $GENERIC:" + chdocType.getId()
                            + " cannot be used to define a replication configuration.");
                }
            }
        }
        setAttrValue(CmdArguments.INT_SPEC, configId + ";0");
        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        final long thisSiteUid = (thisSite != null) ? ((AdmUidObject) thisSite).getUid() : 0;
        final String thisSiteId = (thisSite != null) ? (String) AdmHelperCmd.getAttributeValue(thisSite, AdmAttrNames.SENDER_ID) : "";
        // do the work
        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws Exception {
                validateConfigData(dbCtx, configId, thisSiteUid);
                long configUid = getNewUid(dbCtx);
                insertConfigData(dbCtx, configUid, configId, description, isEnabled, isTransfered, isReplicatesBack, isOffline,
                        thisSiteUid, thisSiteId);

                if (chdocTypeList != null && chdocTypeList.size() > 0) {
                    validateTypeData(dbCtx, chdocTypeList, configId);
                    insertTypeData(dbCtx, chdocTypeList, configUid);
                }
            }
        });

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ReplChdocMasterConfig.class);
        return retResult;
    }

    private void validateConfigData(DBIO dbCtx, String configId, long thisSiteUid) throws Exception {

        if (masterReplConfigExists(dbCtx, configId, Constants.REPL_CHDOC_CLASS)) {
            throw new DimAlreadyExistsException("The replication configuration " + configId + " has already been defined.");
        }

        String revision = getMaxConfigRevision(dbCtx, configId, Constants.REPL_CHDOC_CLASS);
        if (revision != null) {
            throw new DimAlreadyExistsException("The replication configuration " + configId + " has already been defined.");
        }

        if (isAlreadyDefined(dbCtx, configId, Constants.REPL_CHDOC_CLASS, thisSiteUid)) {
            throw new DimAlreadyExistsException("These replication details have already been specified.");
        }
    }

    private boolean isAlreadyDefined(DBIO dbCtx, String configId, int repClass, long baseDbUid) throws Exception {

        // despite the name of the SQL query, the query does apply for request replication configurations
        dbCtx.resetMessage(wcm_sql.REPL_SUBORD_CONFIG_IS_ALREADY_DEFINED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(baseDbUid);
        dbCtx.readStart();
        boolean defined = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return defined;
    }

    private boolean masterReplConfigExists(DBIO dbCtx, String configId, int replClass) throws DBIOException, DimBaseException,
            Exception {

        dbCtx.resetMessage(wcm_sql.REPL_MASTER_CONFIG_DOES_EXIST);

        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        boolean exists = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return exists;
    }

    private String getMaxConfigRevision(DBIO dbCtx, String configId, int replClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_CONFIG_GET_MAX_REVISION);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(replClass);
        dbCtx.readStart();
        String lastRevision = (dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getString(1) : null);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return lastRevision;
    }

    private void insertConfigData(DBIO dbCtx, long configUid, String configId, String description, boolean isEnabled,
            boolean isTransfered, boolean isReplicatesBack, boolean isOffline, long baseDbUid, String siteId) throws Exception {

        if (baseDbUid == -1) {
            throw new DimInvalidAttributeException("Base database name " + siteId + " is not valid for replication.");
        }

        SqlUtils.replInsertConfig(dbCtx, configUid, configId, Constants.REPL_CHDOC_CLASS, "0", description);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        SqlUtils.replInsertConfigDetails(dbCtx, configUid, baseDbUid, null, null, isEnabled, isTransfered, isReplicatesBack, siteId, null, isOffline);
        dbCtx.write(DBIO.DB_DONT_COMMIT);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
    }

    private void validateTypeData(DBIO dbCtx, List chdocTypeList, String configId) throws Exception {

        for (Iterator it = chdocTypeList.iterator(); it.hasNext();) {
            AdmObject typeObj = (AdmObject) it.next();
            String productName = (String) typeObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
            String typeName = (String) typeObj.getAttrValue(AdmAttrNames.ID);
            // check if this request type has already been defined for this replication config
            long typeUid = getChdocTypeUid(dbCtx, productName, typeName);
            boolean isAssigned = isTypeAssigned(dbCtx, typeUid, configId, "0", Constants.REPL_CHDOC_CLASS);

            if (isAssigned) {
                throw new DimAlreadyExistsException("The request type " + productName + ":" + typeName
                        + "is already defined for configuration " + configId + ".");
            }

        }
    }

    private void insertTypeData(DBIO dbCtx, List itemTypeList, long configUid) throws Exception {

        String userName = AdmCmd.getCurRootObj(User.class).getId();

        for (Iterator it = itemTypeList.iterator(); it.hasNext();) {

            AdmObject typeObj = (AdmObject) it.next();
            String productName = (String) typeObj.getAttrValue(AdmAttrNames.PRODUCT_NAME);
            String typeName = (String) typeObj.getAttrValue(AdmAttrNames.ID);
            // check if this request type has already been defined for this replication config
            long typeUid = getChdocTypeUid(dbCtx, productName, typeName);
            if (typeUid == -1) {
                throw new DimNotExistsException("Request type " + productName + ":" + typeName + " does not exist.");
            }

            long relUid = getNewUid(dbCtx);

            SqlUtils.replAssignTypeToConfig(dbCtx, relUid, configUid, typeUid, Constants.REPL_CHDOC_TYPE_REL_CLASS, userName);
            dbCtx.write(DBIO.DB_DONT_COMMIT);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
        }
    }

    private boolean isTypeAssigned(DBIO dbCtx, long typeUid, String configId, String revision, int repClass) throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_IS_TYPE_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(typeUid);
        dbCtx.bindInput(Constants.REPL_CHDOC_TYPE_REL_CLASS);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private long getChdocTypeUid(DBIO dbCtx, String productName, String typeName) throws Exception {
        dbCtx.resetSQL("SELECT type_uid FROM obj_types WHERE product_id=UPPER(:I1) AND type_name=UPPER(:I2) AND type_flag='C'");
        dbCtx.bindInput(productName);
        dbCtx.bindInput(typeName);
        dbCtx.readStart();
        long typeUid = dbCtx.read(DBIO.DB_DONT_CLOSE) ? dbCtx.getLong(1) : -1;
        dbCtx.close(DBIO.DB_DONT_RELEASE);

        return typeUid;
    }
}

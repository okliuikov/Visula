/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.TempFileOutputStream;
import merant.adm.dimensions.cmds.helper.AttributeHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.Relatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.BaseDatabase;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.Attribute;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.util.Encoding;
import merant.adm.dimensions.util.Grid;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions request.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>PRODUCT_NAME {String}</dt><dd>Product name of container for the new request</dd>
 *  <dt>TYPE_NAME {String}</dt><dd>Type name for the new request</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ATTACHMENTS_GRID {Grid}</dt><dd>3 columned Grid of attachment details(Strings): file_id, user_file, description</dd>
 *  <dt>DESCRIPTION {String}</dt><dd>The title of the request</dd>
 *  <dt>AFFECTED_PARTS {List}</dt><dd>A list of affected parts to relate the request to</dd>
 *  <dt>USER_FILE {String}</dt><dd>File containing detailed description</dd>
 *  <dt>DETAILED_DESCRIPTION {String}</dt><dd>Text of the detailed description</dd>
 *  <dt>HOLD {Boolean}</dt><dd>If true then the created document will be held</dd>
 *  <dt>RELATED_BASELINES {String}<dt><dd>List of baselines to be related</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}</dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateChangeDocumentCmd extends RPCExecCmd {
    public CreateChangeDocumentCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.TYPE_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ATTACHMENTS_GRID, false, Grid.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.AFFECTED_PARTS, false, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASED_ON, false, Object.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_REL_TYPE, false, Object.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DETAILED_DESCRIPTION, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.HOLD, false, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_BASELINES, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_REQUIREMENTS, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        String typeName = (String) getAttrValue(AdmAttrNames.TYPE_NAME);
        Grid attachmentsGrid = (Grid) getAttrValue(CmdArguments.ATTACHMENTS_GRID);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);
        List affectedParts = (List) getAttrValue(CmdArguments.AFFECTED_PARTS);
        Object basedOnObj = getAttrValue(CmdArguments.BASED_ON);
        Object basedOnRel = getAttrValue(CmdArguments.ADM_REL_TYPE);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        String detailedDesc = (String) getAttrValue(CmdArguments.DETAILED_DESCRIPTION);
        Boolean doHold = (Boolean) getAttrValue(CmdArguments.HOLD);
        String baselines = (String) getAttrValue(CmdArguments.RELATED_BASELINES);
        String wset = (String) getAttrValue(CmdArguments.WORKSET);

        if (doHold == null) {
            doHold = Boolean.FALSE;
        }

        StringBuffer partArg = new StringBuffer();
        if (affectedParts != null && affectedParts.size() != 0) {
            partArg.append('(');
            for (int i = 0; i < affectedParts.size(); ++i) {
                if (i > 0) {
                    partArg.append(", ");
                }
                partArg.append(Encoding.escapeDMCLI(((Part) affectedParts.get(i)).getAdmSpec().getSpec()));
            }
            partArg.append(')');
        }

        _cmdStr = "CC " + Encoding.escapeDMCLI(productName) + " " + Encoding.escapeDMCLI(typeName);

        if (partArg != null && partArg.length() > 0) {
            _cmdStr += " /AFFECTED_PARTS=" + partArg;
        }

        if (basedOnObj != null) {
            String prime = "";
            if (basedOnObj instanceof ChangeDocument) {
                prime = " /BASED_ON=" + Encoding.escapeDMCLI(((ChangeDocument) basedOnObj).getAdmSpec().getSpec());
            } else if (basedOnObj instanceof String) {
                prime = " /BASED_ON=" + Encoding.escapeDMCLI((String) basedOnObj);
            } else {
                basedOnRel = null;
            }
            if (basedOnRel != null) {
                String basedOnSpec = null;
                if (basedOnRel instanceof AdmUidObject) {
                    if (((AdmUidObject) basedOnRel).getAdmUid().getUid() == Constants.RELTYPE_UID_INFO) {
                        basedOnSpec = "INFO";
                    } else {
                        basedOnSpec = ((AdmObject) basedOnRel).getAdmSpec().getSpec();
                    }
                } else if (basedOnRel instanceof String) {
                    basedOnSpec = (String) basedOnRel;
                }
                prime += " /RELATIONSHIP=" + Encoding.escapeDMCLI(basedOnSpec);
            }
            _cmdStr += prime;
        }

        TempFileOutputStream ts = null;
        if ((userFile != null) && (userFile.length() > 0)) {
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(userFile);
        } else if (detailedDesc != null) {
            try {
                ts = new TempFileOutputStream();
                ts.writeString(detailedDesc);
            } catch (IOException ioException) {
                throw new AdmException(ioException);
            }
            _cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(ts.getAbsolutePath());
        }

        String titleWarning = null;
        // Add title(desc)
        if ((desc != null) && (desc.length() > 0)) {
            // Setup filter for required type
            Filter filter = new FilterImpl();
            Collection crit = filter.criteria();
            crit.add(new FilterCriterion(AdmAttrNames.PRODUCT_NAME, productName));
            crit.add(new FilterCriterion(AdmAttrNames.ID, typeName));
            crit.add(new FilterCriterion(AdmAttrNames.PARENT_CLASS, ChangeDocument.class));

            // Query Base Identifier of type
            Cmd cmd = AdmCmd.getCmd(Relatable.QUERY_CHILD, AdmCmd.getCurRootObj(BaseDatabase.class));
            cmd.setAttrValue(CmdArguments.ADM_CHILD_CLASS, Type.class);
            cmd.setAttrValue(CmdArguments.FILTER, filter);
            AdmBaseId typeId = (AdmBaseId) cmd.execute();

            // Obtain the Type object
            cmd = AdmCmd.getCmd(Creatable.GET_OBJECT, Type.class);
            cmd.setAttrValue(CmdArguments.ADM_BASE_ID, typeId);
            AdmObject type = (AdmObject) cmd.execute();

            // Get the attr that represents attr1 (title/desc) and set it on the command
            Attribute attr = AttributeHelper.getOptimizedAttr(type, 1);
            if (attr != null) {
                attr.setAttrValue(desc);
                String attrName = attr.getAttributeDefinition().getName();
                setAttrDef(attrName, attr.getAttributeDefinition());
                setAttrValue(attrName, attr);
            } else {
                // we should warn the user
                titleWarning = "WARNING: Attribute 1 is not assigned to request type " + typeName + "\n";
            }
        }

        // DEF102324 - if no attachment descriptions have been added
        // then attachmentGrid.size().x could be 2 instead of 3
        if (attachmentsGrid != null && attachmentsGrid.size().x >= 2 && attachmentsGrid.size().y > 0) {
            StringBuffer sb = new StringBuffer();
            sb.append(" /ATTACHMENTS=(");
            for (int y = 0; y < attachmentsGrid.size().y; ++y) {
                if (y > 0) {
                    sb.append(", ");
                }
                sb.append("[FILENAME=");
                sb.append(Encoding.escapeDMCLI((String) attachmentsGrid.get(0, y)));
                sb.append(", USER_FILENAME=");
                sb.append(Encoding.escapeDMCLI((String) attachmentsGrid.get(1, y)));
                if (attachmentsGrid.get(2, y) != null) {
                    sb.append(", DESCRIPTION=");
                    sb.append(Encoding.escapeDMCLI((String) attachmentsGrid.get(2, y)));
                }
                sb.append("]");
            }
            sb.append(")");
            _cmdStr += sb.toString();
        }

        if (doHold.booleanValue()) {
            _cmdStr += " /HOLD";
        }

        if ((baselines != null) && (baselines.length() > 0)) {
            _cmdStr += " /BASELINE_LIST=(" + baselines + ")";
        }

        if ((wset != null) && (wset.length() > 0)) {
            _cmdStr += " /WORKSET=" + Encoding.escapeDMCLI(wset);
        }

        String attrs = AttributeDefinition.getAttrsCmdStringFromCmd(this);
        if (attrs != null && attrs.length() > 0) {
            _cmdStr += " " + attrs;
        }

        String ret = executeRpc();

        // YC: to fix DEF51250
        if (ret != null && ret instanceof String) {
            String retMsg = ret;
            final String duCompleted = "Operation completed\nOperation completed";
            if (retMsg.endsWith(duCompleted)) {
                ret = retMsg.substring(0, retMsg.indexOf(duCompleted) + 19);
            }
        }

        try {
            if (ts != null) {
                ts.close();
            }
        } catch (IOException ioException) {
            throw new AdmException(ioException);
        }
        if (titleWarning != null) {
            ret = titleWarning + ret;
        }

        AdmResult retResult = new AdmResult(ret);
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, ChangeDocument.class);
        return retResult;
    }
}

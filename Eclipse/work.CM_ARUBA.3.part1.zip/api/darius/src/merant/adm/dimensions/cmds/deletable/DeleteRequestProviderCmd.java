/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2009 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.deletable;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.PrivilegesCommandConstants;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.IDMUtilsHelper;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInUseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Request Provider object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class DeleteRequestProviderCmd extends DBIOCmd {
    public DeleteRequestProviderCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof RequestProvider)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege(PrivilegesCommandConstants.ADMIN_IDMTOOLMAN)) {
            throw new DimNoPrivilegeException(PrivilegesCommandConstants.ADMIN_IDMTOOLMAN);
        }

        AdmBaseId tool_base = admObj.getAdmBaseId();
        AdmObject def = queryCurrentDefaultProvider();
        if (def != null && def.getAdmBaseId().equals(tool_base)) {
            throw new DimInUseException("Error: Cannot delete tool instance as it is currently the default.");
        }

        long tool_uid = 0;
        if (tool_base instanceof AdmUid) {
            tool_uid = ((AdmUid) tool_base).getUid();
        }

        if (tool_uid <= 0) {
            throw new DimInvalidAttributeException("Error: wrong parent key : " + tool_uid);
        }

        IDMUtilsHelper.deleteTool(tool_uid);
        return "Operation Completed";
    }

    private AdmObject queryCurrentDefaultProvider() {
        AdmObject ret = null;
        try {
            Cmd cmd = AdmCmd.getCmd("Server.QueryDefaultIDMTool", RequestProvider.class);
            Object resObj = cmd.execute();
            if (resObj instanceof List) {
                List resList = (List) resObj;
                if (resList.size() > 0) {
                    resObj = resList.get(0);
                    if (resObj instanceof RequestProvider) {
                        ret = (AdmObject) resObj;
                    }
                }
            }
        } catch (AdmException e) {
            Debug.error(e);
        }
        return ret;
    }
}

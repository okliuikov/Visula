/*
 * Copyright (C) 2001-2002, 2006 Serena Software Europe, Ltd.
 * All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted,
 * in any form or by any means, without the prior permission in writing
 * of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.auditable;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithBody;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.UserReportDefinition;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Uses RPCExecCmd to fetch the Object via the Dimensions message server.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>USER_FILE {String}<dt><dd>User filename for the fetch</dd>
 *  <dt>PRODUCT_NAME {String}<dt><dd>A specific product id or a string that can represent one or more product ids in the database, by using wildcards </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>URD_PROMPT2 {String}<dt>
 *  <dt>URD_PROMPT3 {String}<dt>
 *  <dt>URD_PROMPT4 {String}<dt>
 *  <dt>URD_PROMPT5 {String}<dt>
 *  <dt>URD_PROMPT6 {String}<dt>
 *  <dt>URD_PROMPT7 {String}<dt>
 *  <dt>URD_PROMPT8 {String}<dt>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Paul Smith
 */
public class UserReportCmd extends RPCExecCmd {
    public UserReportCmd() throws AttrException {
        super();
        setAlias(WithBody.FETCH);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.PRODUCT_NAME, true, String.class));
        // Optional parameters for the report
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT2, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT3, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT4, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT5, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT6, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT7, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT8, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof UserReportDefinition)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        String productName = (String) getAttrValue(AdmAttrNames.PRODUCT_NAME);
        // Parameter values specified by the user
        String userParam2 = (String) getAttrValue(AdmAttrNames.URD_PROMPT2);
        String userParam3 = (String) getAttrValue(AdmAttrNames.URD_PROMPT3);
        String userParam4 = (String) getAttrValue(AdmAttrNames.URD_PROMPT4);
        String userParam5 = (String) getAttrValue(AdmAttrNames.URD_PROMPT5);
        String userParam6 = (String) getAttrValue(AdmAttrNames.URD_PROMPT6);
        String userParam7 = (String) getAttrValue(AdmAttrNames.URD_PROMPT7);
        String userParam8 = (String) getAttrValue(AdmAttrNames.URD_PROMPT8);
        if (admObj instanceof UserReportDefinition) {
            // The parameter field values off the user report definition
            String param2 = (String) admObj.getAttrValue(AdmAttrNames.URD_PROMPT2);
            String param3 = (String) admObj.getAttrValue(AdmAttrNames.URD_PROMPT3);
            String param4 = (String) admObj.getAttrValue(AdmAttrNames.URD_PROMPT4);
            String param5 = (String) admObj.getAttrValue(AdmAttrNames.URD_PROMPT5);
            String param6 = (String) admObj.getAttrValue(AdmAttrNames.URD_PROMPT6);
            String param7 = (String) admObj.getAttrValue(AdmAttrNames.URD_PROMPT7);
            String param8 = (String) admObj.getAttrValue(AdmAttrNames.URD_PROMPT8);
            StringBuffer paramsSB = new StringBuffer();
            boolean firstSet = false;
            StringBuffer sb = new StringBuffer("RUR ");
            sb.append(Encoding.escapeDMCLI((String) admObj.getAttrValue(AdmAttrNames.ID)));
            sb.append(" /PRODUCT=");
            sb.append(Encoding.escapeDMCLI(productName));
            sb.append(" /FILENAME=");
            sb.append(Encoding.escapeDMCLI(userFile));
            // Parameter 2 specified for user report definition
            if (param2 != null && !param2.equals("")) {
                firstSet = true;
                paramsSB.append((userParam2 == null) ? " /PARAM=(\"\"" : " /PARAM=(" + Encoding.escapeDMCLI(userParam2));
            }
            if (param3 != null && !param3.equals("")) {
                paramsSB.append((!firstSet) ? " /PARAM=(" : ",");
                paramsSB.append((userParam3 == null) ? "\"\"" : Encoding.escapeDMCLI(userParam3));
                firstSet = true;
            }
            if (param4 != null && !param4.equals("")) {
                paramsSB.append((!firstSet) ? " /PARAM=(" : ",");
                paramsSB.append((userParam4 == null) ? "\"\"" : Encoding.escapeDMCLI(userParam4));
                firstSet = true;
            }
            if (param5 != null && !param5.equals("")) {
                paramsSB.append((!firstSet) ? " /PARAM=(" : ",");
                paramsSB.append((userParam5 == null) ? "\"\"" : Encoding.escapeDMCLI(userParam5));
                firstSet = true;
            }
            if (param6 != null && !param6.equals("")) {
                paramsSB.append((!firstSet) ? " /PARAM=(" : ",");
                paramsSB.append((userParam6 == null) ? "\"\"" : Encoding.escapeDMCLI(userParam6));
                firstSet = true;
            }
            if (param7 != null && !param7.equals("")) {
                paramsSB.append((!firstSet) ? " /PARAM=(" : ",");
                paramsSB.append((userParam7 == null) ? "\"\"" : Encoding.escapeDMCLI(userParam7));
                firstSet = true;
            }
            if (param8 != null && !param8.equals("")) {
                paramsSB.append((!firstSet) ? " /PARAM=(" : ",");
                paramsSB.append((userParam8 == null) ? "\"\"" : Encoding.escapeDMCLI(userParam8));
                firstSet = true;
            }
            if (firstSet) {
                paramsSB.append(")");
                sb.append(paramsSB.toString());
            }
            _cmdStr = sb.toString();
        }
        return executeRpc();
    }
}

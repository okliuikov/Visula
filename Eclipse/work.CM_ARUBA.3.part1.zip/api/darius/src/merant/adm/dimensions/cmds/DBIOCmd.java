/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.util.HashMap;

import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * This class should be used as a basis for all commands that
 * use DBIO to access the RDBMS.
 * @author Peter Raymond
 */
public abstract class DBIOCmd extends AdmCmd {
    protected HashMap<String, Integer> pcmsApiMap = new HashMap<String, Integer>();

    /** Default constructor sets the properties of the command. */
    public DBIOCmd() {
        super();
        setAlias("DBIOCmd");
        initialiseObjMap();
    }

    private HashMap<String, Integer> initialiseObjMap() {
        // The int values in the hashmap are set based on the entry in build\include\pcms_api.h
        pcmsApiMap.put("Part", 1);
        pcmsApiMap.put("Item", 2);
        pcmsApiMap.put("Baseline", 4);
        pcmsApiMap.put("ChangeDocument", 8);
        pcmsApiMap.put("WorkSet", 64);
        pcmsApiMap.put("DimDirectory", 128);
        pcmsApiMap.put("Requirement", 8192);
        pcmsApiMap.put("ExternalRequest", 131072);
        pcmsApiMap.put(AdmAttrNames.DESCRIPTION, -6);
        pcmsApiMap.put(AdmAttrNames.SPEC_UID, -15);
        pcmsApiMap.put(AdmAttrNames.UPLPRJ_ENV_OBJ, 11000);
        return pcmsApiMap;
    }

    /** Just a placeholder at the moment, should validate the arguments. */
    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
    }

    /**
     * All classes derived from the DBIOCmd class must implement execute.
     * @return An object is returned by the execute method
     */
    @Override
    abstract public Object execute() throws DBIOException, AdmException;
}

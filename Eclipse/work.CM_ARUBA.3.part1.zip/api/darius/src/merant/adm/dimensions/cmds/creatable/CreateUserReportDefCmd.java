/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.ValidationHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.UserReportDefinition;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions UserReportDefinition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}<dt><dd>Identifier of the new user report</dd>
 *  <dt>URD_OP_SYS{String}<dt><dd>Operating System</dd>
 *  <dt>URD_SCOPE{String}<dt><dd>Report scope</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DESCRIPTION{String}<dt><dd>Report description</dd>
 *  <dt>URD_PROMPT_2{String}<dt><dd>User prompt 2</dd>
 *  <dt>URD_PROMPT_3{String}<dt><dd>User prompt 2</dd>
 *  <dt>URD_PROMPT_4{String}<dt><dd>User prompt 2</dd>
 *  <dt>URD_PROMPT_5{String}<dt><dd>User prompt 2</dd>
 *  <dt>URD_PROMPT_6{String}<dt><dd>User prompt 2</dd>
 *  <dt>URD_PROMPT_7{String}<dt><dd>User prompt 2</dd>
 *  <dt>URD_PROMPT_8{String}<dt><dd>User prompt 2</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class CreateUserReportDefCmd extends DBIOCmd {
    public CreateUserReportDefCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_OP_SYS, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_SCOPE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT2, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT3, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT4, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT5, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT6, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT7, false, "", String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.URD_PROMPT8, false, "", String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));

    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPORTMAN")) {
            throw new DimNoPrivilegeException("ADMIN_REPORTMAN");
        }

        String reportId = ValidationHelper.validateReportId((String) getAttrValue(AdmAttrNames.ID));
        String opSys = ValidationHelper.validateReportOs((String) getAttrValue(AdmAttrNames.URD_OP_SYS));

        if (DoesExistHelper.userReportDefExists(reportId, opSys)) {
            throw new DimAlreadyExistsException("Error: user report definition " + reportId + ";" + opSys + " already exists.");
        }

        String reportScope = ValidationHelper.validateReportScope((String) getAttrValue(AdmAttrNames.URD_SCOPE));
        String description = ValidationHelper.validateDescription((String) getAttrValue(AdmAttrNames.DESCRIPTION));
        String userPrompt2 = ValidationHelper.validateReportPrompt((String) getAttrValue(AdmAttrNames.URD_PROMPT2));
        String userPrompt3 = ValidationHelper.validateReportPrompt((String) getAttrValue(AdmAttrNames.URD_PROMPT3));
        String userPrompt4 = ValidationHelper.validateReportPrompt((String) getAttrValue(AdmAttrNames.URD_PROMPT4));
        String userPrompt5 = ValidationHelper.validateReportPrompt((String) getAttrValue(AdmAttrNames.URD_PROMPT5));
        String userPrompt6 = ValidationHelper.validateReportPrompt((String) getAttrValue(AdmAttrNames.URD_PROMPT6));
        String userPrompt7 = ValidationHelper.validateReportPrompt((String) getAttrValue(AdmAttrNames.URD_PROMPT7));
        String userPrompt8 = ValidationHelper.validateReportPrompt((String) getAttrValue(AdmAttrNames.URD_PROMPT8));

        String[] userPrompts = { userPrompt2, userPrompt3, userPrompt4, userPrompt5, userPrompt6, userPrompt7, userPrompt8 };

        // find the last non-null user prompt
        int i = 6;
        while (i >= 0 && (userPrompts[i] == null || userPrompts[i].length() == 0)) {
            --i;
        }
        for (int j = 0; j < i; j++) {
            if (userPrompts[j] == null || userPrompts[j].length() == 0) {
                throw new DimInvalidAttributeException("Error: you have specified a prompt for parameter " + (i + 2)
                        + " but not for parameter " + (j + 2) + " which precedes it.");
            }
        }

        setAttrValue(CmdArguments.INT_SPEC, reportId + ";" + opSys);

        DBIO query = new DBIO(wcm_sql.URD_INSERT);

        query.bindInput(reportId);
        query.bindInput(opSys);
        query.bindInput(reportScope);
        query.bindInput(description, String.class);
        query.bindInput(userPrompt2, String.class);
        query.bindInput(userPrompt3, String.class);
        query.bindInput(userPrompt4, String.class);
        query.bindInput(userPrompt5, String.class);
        query.bindInput(userPrompt6, String.class);
        query.bindInput(userPrompt7, String.class);
        query.bindInput(userPrompt8, String.class);
        query.write();
        query.close();

        AdmResult retResult = new AdmResult("Operation completed");
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, UserReportDefinition.class);
        return retResult;
    }
}

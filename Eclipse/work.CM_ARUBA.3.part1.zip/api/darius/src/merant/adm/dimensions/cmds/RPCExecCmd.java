/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds;

import com.serena.dmfile.progress.CancelMonitor;
import com.serena.dmfile.progress.ProgressListener;
import com.serena.dmnet.RemoteCmdResult;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.AuthPointInfoFailedException;
import merant.adm.dimensions.exception.AuthPointInfoRequiredException;
import merant.adm.dimensions.exception.CancelMonitorIsCancelledException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.system.AuthPointInfo;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;

/**
 * Execute a Dimensions command over RPC to the DBMsg RPC Server
 */
public abstract class RPCExecCmd extends RPCCmd {
    protected String _cmdStr = null;

    protected void setCommand(String cmdStr) {
        _cmdStr = cmdStr;
    }

    public String getCommand() {
        return _cmdStr;
    }

    public RPCExecCmd() {
        setAlias("RPC Execute");
        AddArgument("cmd", "PcmsClntApiExecCommand");
    }

    public final String executeRpc() throws DimBaseCmdException, AdmException {
        return executeRpc(null, null);
    }

    public final String executeRpc(ProgressListener progress, CancelMonitor cancelMonitor) throws AdmException {
        return executeRpc(progress, cancelMonitor, false).getSuccess();
    }

    public final RemoteCmdResult executeRpc(ProgressListener progressListener, CancelMonitor cancelMonitor, boolean retrieveStructuredResult) throws DimBaseCmdException,
            AdmException {
        long t0 = System.currentTimeMillis();
        RemoteCmdResult obj = null;
        try {
            prepareCommand(false);
            AddArgument("command", _cmdStr);

            AuthPointInfo authPointInfo = (AuthPointInfo) this.getAttrValue(CmdArguments.AUTH_POINT_INFO);
            try {
                obj = getSession().execute(m_table, authPointInfo, retrieveStructuredResult, progressListener, cancelMonitor);
            } catch (AuthPointInfoRequiredException apire) {
                // want to rethrow this:
                throw apire;
            } catch (AuthPointInfoFailedException apife) {
                // want to rethrow this:
                throw apife;
            } catch (DimConnectionException dce) {
                // want to rethrow this:
                throw dce;
            } catch (CancelMonitorIsCancelledException cce) {
                // throw cancellation if message doesn't contains any other msg codes
                Debug.debug(cce); // use debug level, because it's rethrown in the next line
                DimSystem.getSystem().getExceptionHandler().throwCancellationException(cce.toString());
            } catch (DimBaseCmdException dbce) {
                // exceptions are rethrown, so as to translate error messages into meaningful exceptions
                Debug.debug(dbce); // use debug level, because it's rethrown in the next line
                DimSystem.getSystem().getExceptionHandler().throwException(dbce.toString());
            } catch (Exception e) {
                Debug.debug(e); // use debug level, because it's rethrown in the next line
                DimSystem.getSystem().getExceptionHandler().throwException(e.toString());
            }
        } finally {
            long td = System.currentTimeMillis() - t0;
            if (_cmdStr.startsWith("AUTH")) {
                Debug.println("EXEC: [AUTH ...] (" + td + " ms)");
            } else {
                Debug.println("EXEC: [" + _cmdStr + "] (" + td + " ms)");
            }
        }
        Debug.println("EXEC.return: [" + obj + "]");
        return obj;
    }
    

    public void prepareCommand(boolean preview) throws AdmException {
    }
    
}

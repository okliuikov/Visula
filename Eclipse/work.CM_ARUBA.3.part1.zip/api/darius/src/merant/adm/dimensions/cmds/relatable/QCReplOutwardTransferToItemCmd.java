/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.serena.dmnet.RPC;
import com.serena.dmnet.drs.DRSClientQCReplOutwardOrInwardTransferToItem;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.DimConnection;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.ReplOutwardTransfer;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Items that were successfully or unsuccessfully transferred by the
 * Replication Outward Transfer object.
 * <p>
 * In order to obtain the corresponding "item Id", "fileName", and "item in source workset" flag (ala Replication Log in Replicator
 * Administration Tool), simply convert the returned AdmBaseId's to full objects.
 * <dl>
 * <dt>item Id</dt>
 * <dd>query ADM_SPEC components</dd>
 * <dt>fileName</dt>
 * <dd>workset filename of the item in the source workset. If the item is not in the source workset, then the workset filename in
 * $GENERIC:$GLOBAL must be used. The "source workset" can be obtained by querying the REPL_WORKSET_ID attribute of the parent
 * ReplOutwardTransfer object.</dd>
 * <dt>"item in source workset" flag</dt>
 * <dd>true, if item in question is in the source workset; false otherwise</dd>
 * </dl>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship rather than AdmBaseId instances</dd>
 *  <dt>WORKSET {WorkSet}</dt><dd>Dimensions workset container for objects</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId or Relationship instances</dd>
 * </dl></code>
 * 
 * @author Vadym Krevs
 *         %PCMS_HEADER_SUBSTITUTION_END%
 */
public class QCReplOutwardTransferToItemCmd extends QueryRelsCmd {
    public QCReplOutwardTransferToItemCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ReplOutwardTransfer)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!attrValue.equals(Item.class) && !attrValue.equals(ItemFile.class)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    private static final String MATCH_ALL = "%";

    // initialize filter
    private String filterProductId = MATCH_ALL;
    private String filterItemId = MATCH_ALL;
    private String filterRevison = MATCH_ALL;
    private String filterVariant = MATCH_ALL;
    private String filterWorksetFilename = MATCH_ALL;
    private String filterSuccess = "SUCCESS";

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        if (filter != null) {
            processFilter(filter);
        }
        List ret = new ArrayList();
        Class childClass = (Class) getAttrValue(CmdArguments.ADM_CHILD_CLASS);
        long relUid = ((Long) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.REPL_REL_UID)).longValue();
        String sourceWorksetId = (String) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.REPL_WORKSET_ID);
        String uniDirSep = (String) AdmHelperCmd.getAttributeValue(AdmCmd.getCurRootObj(DimConnection.class),
                AdmAttrNames.DIMCONN_UNIDIR_SEP);

        // Prepare DRS query
        DRSClientQCReplOutwardOrInwardTransferToItem drsClientQCReplOutwardTransferToItem = new DRSClientQCReplOutwardOrInwardTransferToItem(
                DRSUtils.getLCNetClntObject());
        drsClientQCReplOutwardTransferToItem.setRelUid(relUid);
        drsClientQCReplOutwardTransferToItem.setRepInward(0);
        drsClientQCReplOutwardTransferToItem.setProductId(filterProductId);
        drsClientQCReplOutwardTransferToItem.setItemId(filterItemId);
        drsClientQCReplOutwardTransferToItem.setVariant(filterVariant);
        drsClientQCReplOutwardTransferToItem.setRevision(filterRevison);
        drsClientQCReplOutwardTransferToItem.setFilterSuccess(filterSuccess);
        drsClientQCReplOutwardTransferToItem.setWorksetId(sourceWorksetId);
        drsClientQCReplOutwardTransferToItem.setWorksetFileName(filterWorksetFilename);
        drsClientQCReplOutwardTransferToItem.setUniDirSep(uniDirSep);

        DRSQuery drsQuery = new DRSQuery(drsClientQCReplOutwardTransferToItem);
        DRSOutputDataExtractor drsOutputDataExtractor = drsQuery.execute();
        if (drsOutputDataExtractor.hasRPCExecutionFailed()) {
            throw new DRSException("Error during call of DRS function "
                    + DRSClientQCReplOutwardOrInwardTransferToItem.dataRequestId + " via RPC(" + RPC.RPC_DATA_REQUEST + ")");
        } else if (!drsOutputDataExtractor.isResultEmpty()) {
            int[] relUids = drsOutputDataExtractor.getIntValues(DRSParams.REL_UIDS);
            long itemUid = Constants.INVALID_UID;
            for (int i = 0; i < relUids.length; i++) {
                itemUid = relUids[i];
                if (itemUid > 0) {
                    AdmBaseId uidBaseId = null;
                    if (childClass.equals(Item.class)) {
                        uidBaseId = AdmHelperCmd.newAdmBaseId(itemUid, Item.class, null, null);
                    } else if (childClass.equals(ItemFile.class)) {
                        AdmBaseId workset = AdmHelperCmd.newAdmBaseId(sourceWorksetId, WorkSet.class);
                        uidBaseId = AdmHelperCmd.newAdmBaseId(itemUid, ItemFile.class, workset, null);
                    }
                    addRelation(ret, relationships, admObj.getAdmBaseId(), uidBaseId);
                }
            }
        }
        return ret;
    }

    private void processFilter(FilterImpl f) {
        if (f == null) {
            return;
        }
        Collection crits = f.criteria();
        if (crits != null && !crits.isEmpty()) {
            for (Iterator it = crits.iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit == null) {
                    continue;
                }
                String attrName = crit.getAttrName();
                // filter by whether item was transfered successfully or
                // unsuccessfully?
                if (AdmAttrNames.REPL_IS_SUCCESS.equals(attrName) && crit.getValue() != null) {
                    if (Boolean.TRUE.equals(crit.getValue())) {
                        filterSuccess = "SUCCESS";
                    } else if (Boolean.FALSE.equals(crit.getValue())) {
                        filterSuccess = "FAILURE";
                    }
                }
                // filter by product Id ?
                if (AdmAttrNames.PRODUCT_NAME.equals(attrName) && crit.getValue() != null) {
                    filterProductId = crit.getValue().toString();
                }
                // filter by item Id?
                if (AdmAttrNames.ID.equals(attrName) && crit.getValue() != null) {
                    filterItemId = crit.getValue().toString();
                }
                // filter by revision?
                if (AdmAttrNames.REVISION.equals(attrName) && crit.getValue() != null) {
                    filterRevison = crit.getValue().toString();
                }
                // filter by variant?
                if (AdmAttrNames.VARIANT.equals(attrName) && crit.getValue() != null) {
                    filterVariant = crit.getValue().toString();
                }
                // filter by full workset filename?
                if (AdmAttrNames.FULL_PATH_NAME.equals(attrName) && crit.getValue() != null) {
                    filterWorksetFilename = crit.getValue().toString();
                }
            }
        }
    }
}

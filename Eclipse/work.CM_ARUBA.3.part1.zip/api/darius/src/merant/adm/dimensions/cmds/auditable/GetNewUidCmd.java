/*
 * %HEADER%
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.auditable;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.Auditable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimDatabaseConnectException;
import merant.adm.dimensions.exception.DimInvalidPropertyException;
import merant.adm.dimensions.exception.MessageFileNotFoundException;
import merant.adm.dimensions.exception.MessageNotFoundException;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * A Cmd to get a new valid uid.
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>DBIO_QUERY {String}</dt><dd>Internal DBIO query that must be committed externally to this command</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <DT>{Integer}<dt><dd>Integer containing a newly defined primitive Dimensions uid</dd>
 * </dl></code>
 * @author Stephen Sitton, Floz
 * @todo Return Long not Integer to avoid confusion when using DBIO
 */
public class GetNewUidCmd extends DBIOCmd {

    public GetNewUidCmd() throws AttrException {
        super();
        setAlias(Auditable.GET_NEW_UID);
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, false, DBIO.class));
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmObjectException, MessageNotFoundException,
            MessageFileNotFoundException, DimInvalidPropertyException, DimDatabaseConnectException, AdmException {

        validateAllAttrs();
        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);

        long uid = 0;

        // Process the command...
        try {
            if (query != null) {
                query.resetMessage(wcm_sql.GET_NEW_UID);
                query.readStart();
                if (query.read(DBIO.DB_DONT_CLOSE)) {
                    uid = query.getLong(1);
                }
                query.close(DBIO.DB_DONT_RELEASE);
            } else {
                query = new DBIO(wcm_sql.GET_NEW_UID);
                query.readStart();
                if (query.read()) {
                    uid = query.getLong(1);
                }
                query.close();
            }
        } catch (DBIOException ex) {
            // Pass the exception on...
            throw new AdmException(ex);
        }
        return new Integer((int) uid);
    }
}

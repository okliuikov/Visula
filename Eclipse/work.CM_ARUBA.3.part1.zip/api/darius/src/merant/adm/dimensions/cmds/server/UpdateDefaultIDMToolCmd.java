/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2008 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.server;

import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.PrivilegesCommandConstants;
import merant.adm.dimensions.cmds.helper.IDMUtilsHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Updates the default IDM Tool instance. <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * 
 * @author S. Korniychuk
 */
public class UpdateDefaultIDMToolCmd extends AdmCmd {
    public UpdateDefaultIDMToolCmd() throws AttrException {
        super();
        setAlias(Server.UPDATE_DEFAULT_IDM_TOOL);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
    }

    @Override
    public Object execute() throws AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege(PrivilegesCommandConstants.ADMIN_IDMTOOLMAN)) {
            throw new DimNoPrivilegeException(PrivilegesCommandConstants.ADMIN_IDMTOOLMAN);
        }

        final AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Cmd cmd = AdmCmd.getCmd("Server.QueryDefaultIDMTool", RequestProvider.class);
        Object resObj = cmd.execute();
        if (resObj instanceof List) {
            List resList = (List) resObj;
            if (resList.size() > 0) {
                resObj = resList.get(0);
                if (resObj != null && admObj != null && ((AdmObject) resObj).getAdmBaseId().equals(admObj.getAdmBaseId())) {
                    return "No update was needed";
                }
            }
        }

        long toolUid = -1;
        if (admObj != null) {
            AdmBaseId tool_base = admObj.getAdmBaseId();
            if (tool_base instanceof AdmUid) {
                toolUid = ((AdmUid) tool_base).getUid();
            }
        }

        IDMUtilsHelper.setDefaultIdmToolUid(toolUid);

        return "Operation completed";
    }
}

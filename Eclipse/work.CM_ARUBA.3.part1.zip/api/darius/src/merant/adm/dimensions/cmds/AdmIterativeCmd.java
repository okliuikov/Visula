/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds;

import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.interfaces.AdmCmdEvents;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.collections.AdmObjectList;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;
import merant.adm.framework.CmdExecutionListener;
import merant.adm.framework.FrameworkBaseException;

/**
 * Base command for multiple operations.
 * <p>
 * This class should be used as a basis for Multiple Adm commands where the native command does NOT supportsMultiple(). Note: This
 * class is a rare example where it is not contained in the factory and has arguments on the constructor. This behaviour is not
 * generally advised. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT_LIST {AdmObjectList}<dt><dd>Dimensions AdmObject's list</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>List of return objects from contained command</dd>
 * </dl></code>
 * @todo Messaging in single commands to remove dummy messages from here.
 * @author Floz
 */
public class AdmIterativeCmd extends AdmCmd {
    public AdmIterativeCmd(Cmd cmd) throws AdmObjectException, AttrException {
        setAlias("AdmIterativeCmd");
        setCanCancel(true);
        if (cmd != null) {
            setNestedCmd(cmd);
            List<AttrDef> attrDefs = cmd.getAllAttrDefs();
            if (attrDefs != null) {
                AttrDef attrDef = null;
                for (int i = 0; i < attrDefs.size(); i++) {
                    attrDef = attrDefs.get(i);
                    if (attrDef != null) {
                        setAttrDef(attrDef);
                    }
                }
            }
        }

        setAttrDef(CmdArguments.ADM_OBJECT_LIST, new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, AdmObjectList.class));
    }

    @Override
    public Object execute() throws FrameworkBaseException, AdmException {
        int status = fireExecutionEvent(this, getNestedCmd(), null, AdmCmdEvents.PRE);
        if (canCancel() && ((status == CmdExecutionListener.ABORT) || (status == CmdExecutionListener.CANCEL))) {
            return null;
        }

        List retObjects = new Vector();
        try {
            if (getNestedCmd() == null) {
                Debug.println("AdmIterativeCmd.execute() - getNestedCmd() == null");
                throw new DimBaseCmdException("Error: Unspecified nested command");
            }

            List attrDefs = getNestedCmd().getAllAttrDefs();
            if (attrDefs != null) {
                AttrDef attrDef = null;
                for (int i = 0; i < attrDefs.size(); i++) {
                    attrDef = (AttrDef) attrDefs.get(i);
                    if ((attrDef != null) && (!attrDef.getName().equals(CmdArguments.ADM_OBJECT))) {
                        getNestedCmd().setAttrValue(attrDef.getName(), getAttrValue(attrDef.getName()));
                    }
                }
            }

            AdmObjectList admObjList = (AdmObjectList) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
            status = fireExecutionEvent(this, getNestedCmd(), new Long(admObjList.size()), AdmCmdEvents.PROGRESS_SIZE);

            if (canCancel() && ((status == CmdExecutionListener.ABORT) || (status == CmdExecutionListener.CANCEL))) {
                return null;
            }

            Object result = null;
            for (int i = 0; i < admObjList.size(); i++) {
                getNestedCmd().setAttrValue(CmdArguments.ADM_OBJECT, admObjList.get(i));

                // XXX - Floz: Remove once single cmd messaging is complete.
                status = fireExecutionEvent(getNestedCmd(), getNestedCmd(), null, AdmCmdEvents.PRE);

                if (canCancel() && ((status == CmdExecutionListener.ABORT) || (status == CmdExecutionListener.CANCEL))) {
                    return null;
                }

                result = getNestedCmd().execute();

                // XXX - Floz: Remove once single cmd messaging is complete.
                status = fireExecutionEvent(getNestedCmd(), getNestedCmd(), result, AdmCmdEvents.POST);

                if (canCancel() && ((status == CmdExecutionListener.ABORT) || (status == CmdExecutionListener.CANCEL))) {
                    return null;
                }

                status = fireExecutionEvent(this, getNestedCmd(), new Long(i), AdmCmdEvents.PROGRESS);

                if (canCancel() && ((status == CmdExecutionListener.ABORT) || (status == CmdExecutionListener.CANCEL))) {
                    return null;
                }

                retObjects.add(result);
            }
        } catch (Exception e) {
            fireExecutionEvent(this, getNestedCmd(), e, AdmCmdEvents.ERROR);
            throw new AdmException(e);
        }

        status = fireExecutionEvent(this, getNestedCmd(), retObjects, AdmCmdEvents.POST);
        if (canCancel() && ((status == CmdExecutionListener.ABORT) || (status == CmdExecutionListener.CANCEL))) {
            return null;
        }

        return retObjects;
    }

    private Cmd _nestedCmd = null;

    protected void setNestedCmd(Cmd nestedCmd) {
        _nestedCmd = nestedCmd;
    }

    protected Cmd getNestedCmd() {
        return _nestedCmd;
    }
}

/*
 * Copyright (C), 2012, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */
package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;
import merant.adm.session.Session;

/**
 * This command creates a Vault Object.
 * <b>Mandatory Arguments:</b> <code>
 *  NOTE: Many of the optional arguments are actually mandatory, yet mutually
 *  exclusive.  For details, please refer to the CRVO command line
 *  documentation.
 * </code> <br>
 * <b>Optional Arguments:</b> <code>
 *  <dl>
 *   <dt>CONFIG_FILE</dt><dd>Location of an unversioned configuration file</dd>
 *   <dt>CONFIG_ITEM</dt><dd>Location of a versioned configuration item</dd>
 *   <dt>WORKSET</dt><dd>Project or stream specification containing the versioned configuration file</dd>
 *   <dt>USER_DIRECTORY</dt><dd>Unversioned user directory to upload to the vault</dd>
 *   <dt>BASELINE</dt><dd>Versioned baseline specification to place within the vault</dd>
 *   <dt>LOG_FILE</dt><dd>Overrides the default location for the log file</dd>
 *   <dt>DESCRIPTION</dt><dd>Provides a description for the newly created vault object</dd>
 *   <dt>STAGE</dt><dd>Override to the stage that the vault object will be promoted</dd>
 *   <dt>CLEAN</dt><dd>Deletes (or cleans-up) temporary directories and projects</dd>
 *   <dt>DML</dt><dd>Indicates that the new vault object be within the DML</dd>
 *   <dt>DRY_RUN</dt><dd>Simply generates an XML for subsequent upload</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code>
 *  <dl>
 *   <dt>{AdmResult}</dt>
 *   <dd>The user data contains AdmBaseId(AdmSpec) of the newly created baseline</dd>
 *  </dl>
 * </code>
 * @author Floz
 */
public class RPCCreateRVObjectCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCCreateRVObjectCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("CreateRVObject");
        AddArgument("cmd", "CreateRVObject");
        setAttrDef(new CmdArgDef(CmdArguments.CONFIG_FILE, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CONFIG_ITEM, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_DIRECTORY, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.BASELINE, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.LOG_FILE, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DESCRIPTION, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.STAGE, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLEAN, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.DML, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.DRY_RUN, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public Object execute() throws AdmException {
        try {
            String configFile = ((String) getAttrValue(CmdArguments.CONFIG_FILE));
            String configItem = ((String) getAttrValue(CmdArguments.CONFIG_ITEM));
            String workSet = ((String) getAttrValue(CmdArguments.WORKSET));
            String directory = ((String) getAttrValue(CmdArguments.USER_DIRECTORY));
            String baseline = ((String) getAttrValue(CmdArguments.BASELINE));
            String logFile = ((String) getAttrValue(CmdArguments.LOG_FILE));
            String description = ((String) getAttrValue(CmdArguments.DESCRIPTION));
            String stage = ((String) getAttrValue(CmdArguments.STAGE));
            boolean cleanup = ((Boolean) getAttrValue(CmdArguments.CLEAN)).booleanValue();
            boolean dml = ((Boolean) getAttrValue(CmdArguments.DML)).booleanValue();
            boolean dryRun = ((Boolean) getAttrValue(CmdArguments.DRY_RUN)).booleanValue();

            Session session = (Session) DimSystem.getSystem().getSession();
            String[] output = session.getConnection().rpcCreateRVObject(configFile, configItem, workSet, directory, baseline,
                    logFile, description, stage, cleanup, dml, dryRun);

            String baselineSpec = output[0];
            String messages = output[1];
            AdmBaseId admBaseId = AdmCmd.newAdmBaseId(baselineSpec, Baseline.class);
            AdmResult ret = new AdmResult(messages, admBaseId);
            return ret;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

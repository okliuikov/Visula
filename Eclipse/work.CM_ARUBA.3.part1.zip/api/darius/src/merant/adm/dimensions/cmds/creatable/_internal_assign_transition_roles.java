/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimInvalidRoleException;
import merant.adm.dimensions.objects.RoleDefinition;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Internal command to add a list of roles authrorized to perform the transition.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>DBIO_QUERY {DBIO}</dt>
 *  <dd>
 *      Dimensions DBIO query object to be used. This object defines the transactional scope of the operation.
 *      Any exceptions raised by this command must be handled by the caller.
 *  </dd>
 *  <dt>LIFECYCLE_ID {String}</dt><dd>Dimensions lifecycle ID</dd>
 *  <dt>LCSTATETRANS_FROM_STATE {String}</dt><dd>From state</dd>
 *  <dt>LCSTATETRANS_TO_STATE {String}</dt><dd>To state</dd>
 *  <dt>LCSTATETRANS_IS_NORM {Boolean}</dt><dd>Whether the transition is normal.</dd>
 *  <dt>LCSTATETRANS_AUTH_ROLES {List}</dt><dd>List of Dimensions RoleDefinition objects to be assigned to the transition. </dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>UPDATE {Boolean}</dt><dd>Whether updates to the already assigned roles are allowed.</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}</dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */

public class _internal_assign_transition_roles extends DBIOCmd {
    public _internal_assign_transition_roles() throws AttrException {
        super();
        setAlias("_internal_assign_transition_roles");
        setAttrDef(new CmdArgDef(CmdArguments.DBIO_QUERY, true, DBIO.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIFECYCLE_ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_FROM_STATE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_TO_STATE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_IS_NORM, true, Boolean.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LCSTATETRANS_AUTH_ROLES, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.UPDATE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.DBIO_QUERY)) {
            if (!(attrValue instanceof DBIO)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        DBIO query = (DBIO) getAttrValue(CmdArguments.DBIO_QUERY);
        String lifecycleId = (String) getAttrValue(AdmAttrNames.LIFECYCLE_ID);
        String fromState = (String) getAttrValue(AdmAttrNames.LCSTATETRANS_FROM_STATE);
        String toState = (String) getAttrValue(AdmAttrNames.LCSTATETRANS_TO_STATE);
        List authRoles = (List) getAttrValue(AdmAttrNames.LCSTATETRANS_AUTH_ROLES);
        boolean isNormal = ((Boolean) getAttrValue(AdmAttrNames.LCSTATETRANS_IS_NORM)).booleanValue();
        boolean updateRoles = ((Boolean) getAttrValue(CmdArguments.UPDATE)).booleanValue();

        doAssignTransitionRoles(query, lifecycleId, fromState, toState, isNormal, authRoles, updateRoles);

        return "Operation Completed";
    }

    /**
     * Assignes a set of roles authorised to perform a transition
     */
    private void doAssignTransitionRoles(DBIO query, String lifecycleId, String fromState, String toState, boolean isNormal,
            List authRoles, boolean updateRoles) throws DBIOException, DimBaseException, AdmException {
        String normal_lc = (isNormal ? "Y" : "N");

        for (Iterator it = authRoles.iterator(); it.hasNext();) {
            RoleDefinition roleObj = (RoleDefinition) it.next();

            String roleName = StringUtils.adjustValue(roleObj.getId(), AdmDmLengths.DM_L_ROLE);
            if (roleName == null) {
                roleName = "";
            }

            Boolean isPending = (Boolean) roleObj.getAttrValue(AdmAttrNames.LCSTATETRANS_IS_PENDING);
            if (isPending == null) {
                isPending = Boolean.TRUE;
            }

            Boolean isOptional = (Boolean) roleObj.getAttrValue(AdmAttrNames.LCSTATETRANS_IS_OPTIONAL);
            if (isOptional == null) {
                isOptional = Boolean.FALSE;
            }

            // validate role name
            if (roleName.length() == 0) {
                throw new DimInvalidRoleException("Error: Role name must not be null.");
            }

            if (roleName.length() > 25) {
                throw new DimInvalidRoleException("Error: Role name length must not exceed 25 characters.");
            }

            if (roleName.startsWith(Constants.ROLE_PRE_TOOL_SYMBOL)
                    && !roleName.equalsIgnoreCase(Constants.ROLE_PRE_TOOL_SYMBOL + Constants.ROLE_ORIGINATOR)) {
                throw new DimInvalidRoleException(
                        "Error: Role names starting with $ are reserved roles and only role $ORIGINATOR can be used in lifecycles.");
            }

            if (!roleName.equalsIgnoreCase(Constants.ROLE_PRE_TOOL_SYMBOL + Constants.ROLE_ORIGINATOR)
                    && !DoesExistHelper.roleExists(roleName)) {
                throw new DimInvalidRoleException("Error: Role " + roleName + " is undefined.");
            }

            // check if this role has already been assigned to the transition
            boolean alreadyAssigned = isRoleAlreadyAssigned(query, lifecycleId, fromState, toState, roleName);
            if (alreadyAssigned && !updateRoles) {
                throw new DimInvalidRoleException("Error: Role " + roleName + " is already assigned to the transition " + fromState
                        + "->" + toState + ".");
            }

            String bypass_flag;
            if (!isOptional.booleanValue() && !isPending.booleanValue()) {
                bypass_flag = "A";
            } else if (isOptional.booleanValue() && !isPending.booleanValue()) {
                bypass_flag = "B";
            } else if (!isOptional.booleanValue() && isPending.booleanValue()) {
                bypass_flag = "C";
            } else {
                bypass_flag = "D";
            }

            if (updateRoles && alreadyAssigned) {
                doUpdateTransition(query, lifecycleId, fromState, toState, roleName, bypass_flag);
            } else {
                doInsertTransition(query, lifecycleId, fromState, toState, roleName, normal_lc, bypass_flag);
            }

        } // for (Iterator it = authRoles.iterator(); it.hasNext(); )
    }

    private void doInsertTransition(DBIO query, String lifecycleId, String fromState, String toState, String roleName,
            String normal_lc, String bypass_flag) throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LCTR_INSERT);

        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.bindInput(roleName);
        query.bindInput(bypass_flag);
        query.bindInput(normal_lc);

        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);
    }

    private void doUpdateTransition(DBIO query, String lifecycleId, String fromState, String toState, String roleName,
            String bypass_flag) throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LCTR_UPDATE_FLAGS);

        query.bindInput(bypass_flag);
        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.bindInput(roleName);

        query.write(DBIO.DB_DONT_COMMIT);
        query.close(DBIO.DB_DONT_RELEASE);
    }

    /**
     * Checks if the specified role has already been assigned to this transition
     */
    private boolean isRoleAlreadyAssigned(DBIO query, String lifecycleId, String fromState, String toState, String roleName)
            throws DBIOException, DimBaseException, AdmException {

        query.resetMessage(wcm_sql.LCTR_IS_ROLE_ALREADY_ASSIGNED);

        query.bindInput(lifecycleId);
        query.bindInput(fromState);
        query.bindInput(toState);
        query.bindInput(roleName);

        query.readStart();
        boolean isAssigned = query.read(DBIO.DB_DONT_CLOSE);
        query.close(DBIO.DB_DONT_RELEASE);

        return isAssigned;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.LifeCycle;
import merant.adm.dimensions.objects.LifeCycleState;
import merant.adm.dimensions.objects.LifeCycleStateTransition;
import merant.adm.dimensions.objects.collections.FilterCriterion;
import merant.adm.dimensions.objects.collections.FilterOrder;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all LIfecycle State Transitions originating and/or terminating at the given Lifecycle state
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object (LifecycleState)</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class (lifecycle state)</dd>
 *  <dt>ADM_PARENT_CLASS {Class}</dt><dd>Dimensions parent object class</dd>
 *  <dt>ADM_SEC_CLASS {Class}</dt><dd>Dimensions secondary object class</dd>
 *  <dt>FILTER {Filter}</dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>RELATIONSHIPS {Boolean}</dt><dd>If true, command returns Relationship's rather than AdmBaseId's</dd>
 * </dl></code> <br>
 * <b>User Object Optional Arguments:</b> <code><dl>
 *  <dt>RELTYPE_IS_DEFAULT {Boolean}</dt><dd>If true, returns default object preferences</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing AdmBaseId's or Relationship's</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class QCLifeCycleStateToTransitionCmd extends QueryRelsCmd {
    public QCLifeCycleStateToTransitionCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof LifeCycleState)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(LifeCycleStateTransition.class))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {
        AdmObject lifecycleObj = AdmHelperCmd.getObject(admObj.getAdmBaseId().getScope());
        if ((lifecycleObj == null) || (!(lifecycleObj instanceof LifeCycle))) {
            throw new DBIOException("Unable to find LifeCycle base identifier!");
        }

        boolean onlyOriginating = false;
        boolean onlyTerminating = false;
        if (filter != null) {
            Collection crits = filter.criteria();
            if ((crits != null) && (crits.size() > 0)) {
                boolean bFound = false;
                for (Iterator it = crits.iterator(); it.hasNext();) {
                    FilterCriterion crit = (FilterCriterion) it.next();
                    if (crit == null) {
                        continue;
                    }

                    if (AdmAttrNames.LCSTATETRANS_FROM_STATE.equals(crit.getAttrName())) {
                        onlyOriginating = true;
                        continue;
                    }

                    if (AdmAttrNames.LCSTATETRANS_TO_STATE.equals(crit.getAttrName())) {
                        onlyTerminating = true;
                        continue;
                    }
                }
            }
        }

        List ret = new ArrayList();
        String lifecycleId = lifecycleObj.getId();
        String stateName = admObj.getId();

        DBIO query = getDBIO(onlyOriginating, onlyTerminating, lifecycleId, stateName, filter);
        query.readStart();

        String spec = null;
        List specs = new ArrayList();

        AdmBaseId lcTransBaseId = null;
        while (query.read()) {
            spec = query.getString(1) + ":" + query.getString(6);
            if (!specs.contains(spec)) // Remove duplicates - sql retains duplicates for reasons of ORDER BY
            {
                specs.add(spec);
                lcTransBaseId = AdmHelperCmd.newAdmBaseId(spec, LifeCycleStateTransition.class, lifecycleObj.getAdmBaseId());
                addRelation(ret, relationships, admObj.getAdmBaseId(), lcTransBaseId);
            }
        }

        return ret;
    }

    private DBIO getDBIO(boolean onlyOriginating, boolean onlyTerminating, String lifecycleId, String stateName, FilterImpl filter)
            throws AdmException {
        String fromState = null;
        String isNorm = null;
        String isOptional = null;
        String isPending = null;
        String role = null;
        String toState = null;

        StringBuffer sb = new StringBuffer();
        sb.append("SELECT doc_status, norm_lc, DECODE(NVL(bypass_flag, 'N'), 'B', 'Y', 'D', 'Y', 'N'), ");
        sb.append("DECODE(NVL(bypass_flag, 'N'), 'C', 'Y', 'D', 'Y', 'N'), role, next_doc_status FROM life_cycles ");
        if (onlyOriginating || onlyTerminating) {
            sb.append("WHERE lifecycle_id=:I1 ");
        } else {
            sb.append("WHERE lifecycle_id=:I1 AND (doc_status=:I2 OR next_doc_status=:I2) ");
        }

        if (filter != null) {
            for (Iterator it = filter.criteria().iterator(); it.hasNext();) {
                FilterCriterion crit = (FilterCriterion) it.next();
                if (crit.getValue() == null) {
                    continue;
                }

                if (crit.getAttrName().equals(AdmAttrNames.LCSTATETRANS_FROM_STATE)) {
                    sb.append(" AND doc_status = :I3");
                    fromState = (String) crit.getValue();
                }

                if (crit.getAttrName().equals(AdmAttrNames.LCSTATETRANS_IS_NORM)) {
                    sb.append(" AND norm_lc = :I4");
                    if (((Boolean) crit.getValue()).booleanValue()) {
                        isNorm = "Y";
                    } else {
                        isNorm = "N";
                    }
                }

                if (crit.getAttrName().equals(AdmAttrNames.LCSTATETRANS_IS_OPTIONAL)) {
                    if (((Boolean) crit.getValue()).booleanValue()) {
                        sb.append(" AND ((bypass_flag = 'D') OR (bypass_flag = :I5))");
                    } else {
                        sb.append(" AND ((bypass_flag != 'D') AND (bypass_flag != :I5))");
                    }

                    isOptional = "B";
                }

                if (crit.getAttrName().equals(AdmAttrNames.LCSTATETRANS_IS_PENDING)) {
                    if (((Boolean) crit.getValue()).booleanValue()) {
                        sb.append(" AND ((bypass_flag = 'D') OR (bypass_flag = :I6))");
                    } else {
                        sb.append(" AND ((bypass_flag != 'D') AND (bypass_flag != :I6))");
                    }

                    isPending = "C";
                }

                if (crit.getAttrName().equals(AdmAttrNames.LCSTATETRANS_ROLE)) {
                    sb.append(" AND role = :I7");
                    role = (String) crit.getValue();
                }

                if (crit.getAttrName().equals(AdmAttrNames.LCSTATETRANS_TO_STATE)) {
                    sb.append(" AND next_doc_status = :I8");
                    toState = (String) crit.getValue();
                }
            }

            if (filter.orders().size() > 0) {
                sb.append(" ORDER BY ");
                boolean first = true;
                for (Iterator it = filter.orders().iterator(); it.hasNext();) {
                    if (first) {
                        first = false;
                    } else {
                        sb.append(", ");
                    }

                    FilterOrder order = (FilterOrder) it.next();
                    if (order.getAttrName().equals(AdmAttrNames.LCSTATETRANS_FROM_STATE)) {
                        sb.append("1");
                    } else if (order.getAttrName().equals(AdmAttrNames.LCSTATETRANS_IS_NORM)) {
                        sb.append("2");
                    }
                    if (order.getAttrName().equals(AdmAttrNames.LCSTATETRANS_IS_OPTIONAL)) {
                        sb.append("3");
                    } else if (order.getAttrName().equals(AdmAttrNames.LCSTATETRANS_IS_PENDING)) {
                        sb.append("4");
                    }
                    if (order.getAttrName().equals(AdmAttrNames.LCSTATETRANS_ROLE)) {
                        sb.append("5");
                    } else if (order.getAttrName().equals(AdmAttrNames.LCSTATETRANS_TO_STATE)) {
                        sb.append("6");
                    }

                    switch (order.getFlags()) {
                    case FilterOrder.ASCENDING:
                        sb.append(" ASC");
                        break;
                    case FilterOrder.DESCENDING:
                        sb.append(" DESC");
                        break;
                    default:
                        break;
                    }
                }
            }
        }

        String queryStr = sb.toString();
        DBIO query = new DBIO(queryStr);
        query.bindInput(lifecycleId);
        query.bindInput(stateName);
        if (filter != null) {
            query.bindInput(fromState);
            query.bindInput(isNorm);
            query.bindInput(isOptional);
            query.bindInput(isPending);
            query.bindInput(role);
            query.bindInput(toState);
        }

        return query;
    }
}

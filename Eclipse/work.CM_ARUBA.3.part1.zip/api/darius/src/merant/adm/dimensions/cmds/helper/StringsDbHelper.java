/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.exception.AdmException;

/**
 * This class contains helper methods for returning values from the
 * STRINGS_DB table. The 'string' and 'obj_size' columns are queried.
 * If 'obj_size'is > 60 (length of 'string' column) then the value of the
 * full_string column is returned (this is a 'long' column).
 */
public class StringsDbHelper {

    private static long STRING_COL_LENGTH = 60L;

    /**
     * Don't want an instance of this class
     */
    private StringsDbHelper() {
        super();
    }

    /**
     * Returns value from the 'string' column or 'full_string' column
     * depending on the length of the record determined by the
     * 'obj_size' column in strings_db table.
     * @param long objUID
     * @return String returnVal
     */
    public static String getStringsDbVal(long objUID) throws AdmException {
        String returnVal = "";

        DBIO stringsDBQuery = new DBIO("SELECT obj_size, string FROM strings_db WHERE obj_uid = :I1");

        stringsDBQuery.bindInput(objUID);
        stringsDBQuery.readStart();

        String stringColValue = "";
        long objSizeLong = 0;

        while (stringsDBQuery.read()) {
            objSizeLong = stringsDBQuery.getLong(1);
            stringColValue = stringsDBQuery.getString(2);
            returnVal = stringColValue;
        }
        stringsDBQuery.close();

        // If the length of the value that is stored in this table in 'obj_size'
        // exceeds the length of 'string' column then we need to return
        // the value in 'full_string' column
        /**
         * @todo: PSmith cannot currently get the value of the 'full_string'
         *        column as the DBIO layer does not support this type of column
         *        Dummy data is passed back currently.
         * 
         */
        if (objSizeLong > STRING_COL_LENGTH) {

            /**
             * @todo: PUT THIS CODE BACK IN WHEN getLong is working correcly
             */
            // stringsDBQuery = new DBIO("SELECT full_string FROM strings_db WHERE obj_uid = :I1");
            // stringsDBQuery.bindInput(objUID);
            // stringsDBQuery.readStart();

            // while (stringsDBQuery.read())
            // {
            // returnVal = stringsDBQuery.getString(1);
            // }
            // stringsDBQuery.close();

            returnVal = stringColValue + "....";
        }

        return returnVal;
    }

}

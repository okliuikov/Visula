/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.List;
import java.util.Vector;

import com.serena.dmnet.drs.DRSClientQCBaselineToState;
import com.serena.dmnet.drs.DRSOutputDataExtractor;
import com.serena.dmnet.drs.DRSParams;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.LifeCycleState;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.objects.userattrs.FilterImpl;
import merant.adm.dimensions.server.drs.DRSQuery;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;

/**
 * Queries all Lifecycle States for Items related to a Baseline object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}</dt><dd>Dimensions primary object</dd>
 *  <dt>ADM_CHILD_CLASS {Class}</dt><dd>Dimensions child object class</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}</dt><dd>A List implementation containing Lifecycle State Ids</dd>
 * </dl></code>
 * @author Peterb
 */
public class QCBaselineToStateCmd extends QueryRelsCmd {
    public QCBaselineToStateCmd() throws AttrException {
        super();
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Baseline)) {
                throw new AttrException("QCBaselineToStateCmd Error: Adm Object type is not supported!", attrDef, attrValue);
            }
        }

        if (name.equals(CmdArguments.ADM_CHILD_CLASS)) {
            if (!(attrValue.equals(LifeCycleState.class))) {
                throw new AttrException("QCBaselineToStateCmd Error: Child object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    protected List internalExecute(AdmObject admObj, Class admSecClass, boolean queryChildren, FilterImpl filter,
            boolean relationships, boolean isDefault, boolean count, boolean isSecClassUidObj) throws DBIOException,
            DimBaseException, AdmException {

        List ret = new Vector();

        DRSClientQCBaselineToState dg = new DRSClientQCBaselineToState(DRSUtils.getLCNetClntObject());

        dg.setBaselineUid(((AdmUidObject) admObj).getAdmUid().getUid());

        DRSOutputDataExtractor output = new DRSQuery(dg).execute();
        if (!output.isResultEmpty()) {
            String[] uids = output.getStringValues(DRSParams.STATES);

            if (uids != null && uids.length > 0) {
                for (int i = 0; i < uids.length; i++) {
                    ret.add(uids[i]);
                }
            }
        }

        return ret;
    }
}

/*
 * Copyright (C), 2005, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 */

package merant.adm.dimensions.cmds.helper;

import java.util.Date;

import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.exception.DimMandatoryAttributeException;
import merant.adm.dimensions.server.core.AdmDmLengths;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.SpecialCharacters;
import merant.adm.dimensions.util.StringUtils;

/**
 * @author vadymk
 *         This class contains helper methods for simple validation of command attribute values
 */
public class ValidationHelper {

    public static String validateAttrBlockId(String id) throws DimMandatoryAttributeException {
        return validateAttrBlockId(id, false);
    }

    public static String validateAttrBlockId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_ATTR_BLOCK_ID);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: attribute block ID must be specified.");
        }

        return value;
    }

    public static String validateAttrDataType(Class attrDataType) throws DimMandatoryAttributeException {
        return validateAttrDataType(attrDataType, false);
    }

    public static String validateAttrDataType(Class attrDataType, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        if (!isNullOrEmptyOk && attrDataType == null) {
            throw new DimMandatoryAttributeException("Error: attribute data type must be specified.");
        }

        String attrClass = null;
        if (attrDataType != null) {
            attrClass = "C";
            if (Number.class.equals(attrDataType)) {
                attrClass = "N";
            } else if (Date.class.equals(attrDataType)) {
                attrClass = "D";
            } else if (Integer.class.equals(attrDataType)) {
                attrClass = "I";
            }
        }
        return attrClass;
    }

    public static String validateAttrId(String id) throws DimMandatoryAttributeException, DimInvalidAttributeException {
        return validateAttrId(id, false);
    }

    public static String validateAttrId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_ATTR_VARIABLE);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: attribute ID must be specified.");
        }

        if (value != null && StringUtils.containsSpecialChars(value, SpecialCharacters.INVALID_ATTR_CHARS)) {
            throw new DimInvalidAttributeException(
                    "Error: the attribute name must not contain one or more of the following disallowed characters: "
                            + SpecialCharacters.INVALID_ATTR_CHARS + " or a space character");
        }

        return value;
    }

    public static String validateAttrPrompt(String prompt) throws DimMandatoryAttributeException {
        return validateAttrPrompt(prompt, false);
    }

    public static String validateAttrPrompt(String prompt, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(prompt, AdmDmLengths.DM_L_DESCRIPTION, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: user prompt must be specified.");
        }

        return value;
    }

    public static String validateBranchId(String id) throws DimMandatoryAttributeException {
        return validateBranchId(id, false);
    }

    public static String validateBranchId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_BRANCH_ID, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: version branch ID must be specified.");
        }
        if (value != null) {
            value = value.toLowerCase();
        }
        return value;
    }

    public static String validateBuildAreaId(String id) throws DimMandatoryAttributeException {
        return validateBuildAreaId(id, false);
    }

    public static String validateBuildAreaId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, 128);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: build area name must be specified.");
        }

        return value;
    }

    public static String validateBuildProjectId(String id) throws DimMandatoryAttributeException {
        return validateBuildProjectId(id, false);
    }

    public static String validateBuildProjectId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, 128);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: build project ID must be specified.");
        }
        return value;
    }

    public static String validateBuildStageAlias(String id) throws DimMandatoryAttributeException {
        return validateBuildStageAlias(id, false);
    }

    public static String validateBuildStageAlias(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, 3);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: build stage alias must be specified.");
        }

        return value;
    }

    public static Integer validateBuildStageDisplayOrder(Integer displayOrder) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {
        return validateBuildStageDisplayOrder(displayOrder, false);
    }

    public static Integer validateBuildStageDisplayOrder(Integer displayOrder, boolean isNullOrEmptyOk)
            throws DimMandatoryAttributeException, DimInvalidAttributeException {

        if (!isNullOrEmptyOk && displayOrder == null) {
            throw new DimMandatoryAttributeException("Error: build stage display order must be specified.");
        }

        if (displayOrder != null) {
            if (displayOrder.intValue() < 0) {
                throw new DimInvalidAttributeException("Error: build stage display order must be nonnegative.");
            }
        }
        return displayOrder;
    }

    public static String validateBuildStageId(String id) throws DimMandatoryAttributeException {
        return validateBuildStageId(id, false);
    }

    public static String validateBuildStageId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, 128);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: build stage ID must be specified.");
        }

        return value;
    }

    public static Integer validateChdocRelClass(Integer relClass) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {
        return validateChdocRelClass(relClass, false);
    }

    public static Integer validateChdocRelClass(Integer relClass, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        if (!isNullOrEmptyOk && relClass == null) {
            throw new DimMandatoryAttributeException("Error: relationship class must be specified.");
        }
        if (relClass != null) {
            if (relClass.intValue() != Constants.INFO_REL_CLASS && relClass.intValue() != Constants.DEPENDENT_REL_CLASS) {
                throw new DimInvalidAttributeException("Error: an invalid relationship class was specified (" + relClass + ")");
            }
        }
        return relClass;
    }

    public static String validateChdocRelName(String id) throws DimMandatoryAttributeException {
        return validateChdocRelName(id, false);
    }

    public static String validateChdocRelName(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_RELNAME, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: relationship name must be specified.");
        }

        return value;
    }

    public static String validateDefaultAttrValue(String defaultValue) throws DimMandatoryAttributeException {
        return validateDefaultAttrValue(defaultValue, false);
    }

    public static String validateDefaultAttrValue(String defaultValue, boolean isNullOrEmptyOk)
            throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(defaultValue, AdmDmLengths.DM_L_ATTR_DEFAULT_VAL, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: default value must be specified.");
        }

        return value;
    }

    public static String validateDescription(String description) throws DimMandatoryAttributeException {
        return validateDescription(description, true);
    }

    public static String validateDescription(String description, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(description, AdmDmLengths.DM_L_DESCRIPTION, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: description must be specified.");
        }

        return value;
    }

    public static String validateDirectory(String id) throws DimMandatoryAttributeException {
        return validateDirectory(id, false);
    }

    public static String validateDirectory(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_PATHNAME, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: directory must be specified.");
        }

        return value;
    }

    public static Integer validateDisplayHeight(Integer displayHeight) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {
        return validateDisplayHeight(displayHeight, false);
    }

    public static Integer validateDisplayHeight(Integer displayHeight, boolean isNullOrEmptyOk)
            throws DimMandatoryAttributeException, DimInvalidAttributeException {

        if (!isNullOrEmptyOk && displayHeight == null) {
            throw new DimMandatoryAttributeException("Error: display height must be specified.");
        }

        if (displayHeight != null) {
            if (displayHeight.intValue() < 1 || displayHeight.intValue() > 24) {
                throw new DimInvalidAttributeException("Error: display height must be in range 1 to 24.");
            }
        }
        return displayHeight;
    }

    public static Integer validateDisplayLength(Integer displayLength) throws DimMandatoryAttributeException,
            DimInvalidAttributeException, DimConnectionException {
        return validateDisplayLength(displayLength, false);
    }

    public static Integer validateDisplayLength(Integer displayLength, boolean isNullOrEmptyOk)
            throws DimMandatoryAttributeException, DimInvalidAttributeException, DimConnectionException {

        if (!isNullOrEmptyOk && displayLength == null) {
            throw new DimMandatoryAttributeException("Error: display length must be specified.");
        }

        if (displayLength != null) {
            int max = DBLimits.getLimits().getMaxAttrDisplayLength();
            if (displayLength.intValue() < 1 || displayLength.intValue() > max) {
                throw new DimInvalidAttributeException("Error: display length must be in range 1 to " + max + ".");
            }
        }
        return displayLength;
    }

    public static Integer validateDisplayWidth(Integer displayWidth) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {
        return validateDisplayWidth(displayWidth, false);
    }

    public static Integer validateDisplayWidth(Integer displayWidth, boolean isNullOrEmptyOk)
            throws DimMandatoryAttributeException, DimInvalidAttributeException {

        if (!isNullOrEmptyOk && displayWidth == null) {
            throw new DimMandatoryAttributeException("Error: display width must be specified.");
        }

        if (displayWidth != null) {
            if (displayWidth.intValue() < 0) {
                throw new DimInvalidAttributeException("Error: display width must be greater than 0.");
            }
        }
        return displayWidth;
    }

    public static String validateFormatId(String id) throws DimMandatoryAttributeException {
        return validateFormatId(id, false);
    }

    public static String validateFormatId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_FORMAT);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: file format ID must be specified.");
        }
        return value;
    }

    public static String validateHelpMessage(String defaultValue) throws DimMandatoryAttributeException {
        return validateHelpMessage(defaultValue, false);
    }

    public static String validateHelpMessage(String defaultValue, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(defaultValue, AdmDmLengths.DM_L_ATTR_HELP_MESS, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: help message must be specified.");
        }

        return value;
    }

    public static String validateItemTypeGroupId(String id) throws DimMandatoryAttributeException {
        return validateItemTypeGroupId(id, false);
    }

    public static String validateItemTypeGroupId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_ITEM_TYPE);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: item type group name must be specified.");
        }

        return value;
    }

    public static String validateItemTypeId(String id) throws DimMandatoryAttributeException {
        return validateItemTypeId(id, false);
    }

    public static String validateItemTypeId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_ITEM_TYPE);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: item type name must be specified.");
        }

        return value;
    }

    public static String validateLibraryPath(String id) throws DimMandatoryAttributeException {
        return validateLibraryPath(id, false);
    }

    public static String validateLibraryPath(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, 128, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: item library path must be specified.");
        }

        return value;
    }

    public static String validateLibraryProtection(String protection) throws DimMandatoryAttributeException {
        return validateLibraryProtection(protection, true);
    }

    public static String validateLibraryProtection(String protection, boolean isNullOrEmptyOk)
            throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(protection, 20, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: item library protection must be specified.");
        }

        return value;
    }

    public static String validateLifecycleId(String id) throws DimMandatoryAttributeException {
        return validateLifecycleId(id, false);
    }

    public static String validateLifecycleId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_LIFECYCLE);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: lifecycle ID must be specified.");
        }

        return value;
    }

    public static String validateLifecycleStatus(String id) throws DimMandatoryAttributeException, DimInvalidAttributeException {
        return validateLifecycleStatus(id, false);
    }

    public static String validateLifecycleStatus(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_STATUS);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: lifecycle state must be specified.");
        }

        if (value != null && StringUtils.containsSpecialChars(value, SpecialCharacters.INVALID_LIFECYCLE_STATE_CHARS)) {
            throw new DimInvalidAttributeException("Error: lifecycle state name contains invalid characters "
                    + SpecialCharacters.INVALID_LIFECYCLE_STATE_CHARS);
        }
        return value;
    }

    public static Integer validateMaxLength(Integer maxLength) throws DimMandatoryAttributeException, DimInvalidAttributeException,
            DimConnectionException {
        return validateMaxLength(maxLength, false);
    }

    public static Integer validateMaxLength(Integer maxLength, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException, DimConnectionException {

        if (!isNullOrEmptyOk && maxLength == null) {
            throw new DimMandatoryAttributeException("Error: maximum length must be specified.");
        }

        if (maxLength != null) {
            int max = DBLimits.getLimits().getMaxAttrLength();
            if (maxLength.intValue() < 1 || maxLength.intValue() > max) {
                throw new DimInvalidAttributeException("Error: maximum length must be in range 1 to " + max + ".");
            }
        }
        return maxLength;
    }

    public static String validateNetworkNode(String id) throws DimMandatoryAttributeException {
        return validateNetworkNode(id, false);
    }

    public static String validateNetworkNode(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_NODE_NAME);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: network node name must be specified.");
        }

        return value;
    }

    public static String validateOsPlatform(String id) throws DimMandatoryAttributeException {
        return validateOsPlatform(id, false);
    }

    public static String validateOsPlatform(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, 128, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: OS platform must be specified.");
        }

        return value;
    }

    public static String validatePartId(String id) throws DimMandatoryAttributeException {
        return validatePartId(id, false);
    }

    public static String validatePartId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_PART_ID);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: part ID must be specified.");
        }

        return value;
    }

    public static String validatePassword(String id) throws DimMandatoryAttributeException {
        return validatePassword(id, false);
    }

    public static String validatePassword(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_PASSWORD, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: password must be specified.");
        }

        return value;
    }

    public static String validateProductId(String id) throws DimMandatoryAttributeException {
        return validateProductId(id, false);
    }

    public static String validateProductId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_PRODUCT_ID);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: product ID must be specified.");
        }

        return value;
    }

    public static String validateProjectId(String id) throws DimMandatoryAttributeException {
        return validateProjectId(id, false);
    }

    public static String validateProjectId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, 128);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: project ID must be specified.");
        }
        return value;
    }

    public static String validateReleaseSubDir(String id) throws DimMandatoryAttributeException {
        return validateReleaseSubDir(id, true);
    }

    public static String validateReleaseSubDir(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_RELEASE_SUB_DIR, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: release subdirectory must be specified.");
        }

        return value;
    }

    public static String validateReleaseTemplateId(String id) throws DimMandatoryAttributeException {
        return validateReleaseTemplateId(id, false);
    }

    public static String validateReleaseTemplateId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_TEMPLATE);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: release template ID must be specified.");
        }

        return value;
    }

    public static String validateRelName(String id) throws DimMandatoryAttributeException {
        return validateRelName(id, false);
    }

    public static String validateRelName(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_RELNAME);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: relationship name must be specified.");
        }

        return value;
    }

    public static String validateReplConfigId(String id) throws DimMandatoryAttributeException, DimInvalidAttributeException {
        return validateReplConfigId(id, false);
    }

    public static String validateReplConfigId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_REPL_CONFIG_ID);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: replication configuration ID must be specified.");
        }

        if (value != null && StringUtils.containsSpecialChars(value, SpecialCharacters.INVALID_REPLICATION_CONFIG_CHARS)) {
            throw new DimInvalidAttributeException("Error: replication configuration name contains invalid characters "
                    + SpecialCharacters.INVALID_REPLICATION_CONFIG_CHARS);
        }

        return value;
    }

    public static String validateReportId(String id) throws DimMandatoryAttributeException {
        return validateReportId(id, false);
    }

    public static String validateReportId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_REPORT_DEF_ID);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: report ID must be specified.");
        }

        return value;
    }

    public static String validateReportOs(String opSys) throws DimMandatoryAttributeException, DimInvalidAttributeException {
        return validateReportOs(opSys, false);
    }

    public static String validateReportOs(String opSys, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        if (!isNullOrEmptyOk && opSys == null) {
            throw new DimMandatoryAttributeException("Error: OS identifier must be specified.");
        }

        if (opSys != null && !opSys.equals(Constants.OS_UNIX) && !opSys.equals(Constants.OS_VME) && !opSys.equals(Constants.OS_VMS)
                && !opSys.equals(Constants.OS_WINDOWS)) {
            throw new DimInvalidAttributeException("Error: invalid OS identifier.");
        }

        return opSys;
    }

    public static String validateReportPrompt(String prompt) throws DimMandatoryAttributeException {
        return validateReportPrompt(prompt, true);
    }

    public static String validateReportPrompt(String prompt, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(prompt, 15, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: user prompt must be specified.");
        }

        return value;
    }

    public static String validateReportScope(String reportScope) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {
        return validateReportScope(reportScope, false);
    }

    public static String validateReportScope(String reportScope, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        if (!isNullOrEmptyOk && reportScope == null) {
            throw new DimMandatoryAttributeException("Error: report scope must be specified.");
        }

        if (reportScope != null && !reportScope.equals(Constants.REPORT_SCOPE_ALL_TOOLS)
                && !reportScope.equals(Constants.REPORT_SCOPE_CHANGE) && !reportScope.equals(Constants.REPORT_SCOPE_DESIGN)
                && !reportScope.equals(Constants.REPORT_SCOPE_VERSION)) {
            throw new DimInvalidAttributeException("Error: invalid report scope.");
        }

        return reportScope;
    }

    public static String validateTypeId(String id) throws DimMandatoryAttributeException {
        return validateTypeId(id, false);
    }

    public static String validateTypeId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_TYPE_NAME);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: type name must be specified.");
        }

        return value;
    }

    public static String validateUserName(String id) throws DimMandatoryAttributeException {
        return validateUserName(id, false);
    }

    public static String validateUserName(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_USER, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: user name must be specified.");
        }

        return value;
    }

    public static String validateValidsetId(String id) throws DimMandatoryAttributeException {
        return validateValidsetId(id, false);
    }

    public static String validateValidsetId(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_VALID_SET_ID);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: valid set ID must be specified.");
        }

        return value;
    }

    public static Integer validateValidsetNumCols(Integer columns) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {
        return validateValidsetNumCols(columns, false);
    }

    public static Integer validateValidsetNumCols(Integer columns, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        if (!isNullOrEmptyOk && columns == null) {
            throw new DimMandatoryAttributeException("Error: number of valid set columns must be specified.");
        }

        if (columns != null) {
            if (columns.intValue() < 1 || columns.intValue() > 8) {
                throw new DimInvalidAttributeException("Error: number of valid set columns must be in range 1 to 8.");
            }
        }
        return columns;
    }

    public static String validateVariant(String id) throws DimMandatoryAttributeException {
        return validateVariant(id, false);
    }

    public static String validateVariant(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_VARIANT);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: variant must be specified.");
        }

        return value;
    }

    public static String validateWorksetSpec(String spec) throws DimMandatoryAttributeException, DimInvalidAttributeException {
        return validateWorksetSpec(spec, false);
    }

    public static String validateWorksetSpec(String spec, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException,
            DimInvalidAttributeException {

        // The "5" below is for four quotes and a colon as the specs can contain spaces
        // e.g. "PRODUCT 1":"WS 1"
        String value = StringUtils.adjustValue(spec, AdmDmLengths.DM_L_PRODUCT_ID + AdmDmLengths.DM_L_ID + 5);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: project specification must be specified.");
        }

        return value;
    }

    public static String validateUrl(String id) throws DimMandatoryAttributeException {
        return validateUrl(id, false);
    }

    public static String validateUrl(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_URL, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: URL must be specified.");
        }

        return value;
    }

    public static String validateTemplateName(String id) throws DimMandatoryAttributeException {
        return validateTemplateName(id, false);
    }

    public static String validateTemplateName(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_TEMPLATE_NAME);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: Template name must be specified.");
        }

        return value;
    }

    public static String validateBuildOptions(String id) throws DimMandatoryAttributeException {
        return validateBuildOptions(id, false);
    }

    public static String validateBuildOptions(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_BUILD_OPTIONS, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: Build Options name must be specified.");
        }

        return value;
    }

    public static String validateOptions(String id) throws DimMandatoryAttributeException {
        return validateOptions(id, false);
    }

    public static String validateOptions(String id, boolean isNullOrEmptyOk) throws DimMandatoryAttributeException {

        String value = StringUtils.adjustValue(id, AdmDmLengths.DM_L_OPTIONS, false);
        if (!isNullOrEmptyOk && (value == null || value.length() == 0)) {
            throw new DimMandatoryAttributeException("Error: Options name must be specified.");
        }

        return value;
    }

    /**
     *
     */
    private ValidationHelper() {
        super();
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.RemoteJob;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will change the status of a RemoteJob
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>STATUS {String}<dt><dd>Status to change the RemoteJob</dd>
 *  <dt>RESULT_CODE {Integer}<dt><dd>Result Code for the RemoteJob</dd>
 *  <dt>DESCRIPTION {String}<dt><dd>Description for the RemoteJob</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Floz
 */
public class UpdateRemoteJobStatusCmd extends RPCExecCmd {
    public UpdateRemoteJobStatusCmd() throws AttrException {
        super();
        setAlias(Actionable.UPDATE_REMOTE_JOB_STATUS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STATUS, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.RESULT_CODE, false, Integer.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.DESCRIPTION, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof RemoteJob)) {
                throw new AttrException("UpdateRemoteJobStatusCmd Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();

        AdmObject remoteJob = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String remoteJobSpec = (String) AdmHelperCmd.getAttributeValue(remoteJob, AdmAttrNames.REMOTE_JOB_SPEC);
        String status = (String) getAttrValue(AdmAttrNames.STATUS);
        Integer rc = (Integer) getAttrValue(AdmAttrNames.RESULT_CODE);
        String desc = (String) getAttrValue(AdmAttrNames.DESCRIPTION);

        this._cmdStr = "RSTAT " + remoteJobSpec;

        if (status != null) {
            this._cmdStr += " /STATUS=" + status;
        }

        if (rc != null) {
            this._cmdStr += " /RC=" + rc.toString();
        }

        if (desc != null) {
            this._cmdStr += " /DESCRIPTION=" + Encoding.escapeDMCLI(desc);
        }

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, RemoteJob.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.withattrs;

import java.util.List;
import java.util.Vector;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.collections.Filter;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.userattrs.AttributeDefinition;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * Convenience command for batch querying and retrieval of object
 * attribute definitions.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ATTRIBUTE_NAMES {String/List}<dt><dd>Attribute name or List of attribute names to query</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>FILTER {Filter}<dt><dd>Filter of Attr's containing filter information</dd>
 *  <dt>FORCE_QUERY {Boolean}<dt><dd>If true, forces query even if definition is available</dd>
 *  <dt>MULTIPLE {Boolean}</dt><dd>Used for multiple edit attribute operations</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{List}<dt><dd>List of (AttrDef) attribute definitions</dd>
 * </dl></code>
 * @author Floz
 */
public class GetAttrDefsCmd extends AdmCmd {
    public GetAttrDefsCmd() throws AttrException {
        super();
        setAlias(WithAttrs.GET_DEFS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ATTRIBUTE_NAMES, true));
        setAttrDef(new CmdArgDef(CmdArguments.FILTER, false, Filter.class));
        setAttrDef(new CmdArgDef(CmdArguments.FORCE_QUERY, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.MULTIPLE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ATTRIBUTE_NAMES)) {
            if ((!(attrValue instanceof String)) && (!(attrValue instanceof List))) {
                throw new AttrException("Error: Attribute name should be a singular String or a List of String's", attrDef,
                        attrValue);
            }
        }
    }

    private static void addMVAToMCB(List mcb, AttributeDefinition attrDef) {
        if (mcb.size() == 0) {
            mcb.add(attrDef);
            return;
        }

        boolean added = false;
        AttributeDefinition tmpAttrDef = null;
        int attrMcbCol = attrDef.getMcbColumn();
        for (int i = 0; ((i < mcb.size()) && (!added)); i++) {
            tmpAttrDef = (AttributeDefinition) mcb.get(i);
            if (tmpAttrDef.getMcbColumn() >= attrMcbCol) {
                mcb.add(i, attrDef);
                added = true;
            }
        }

        if (!added) {
            mcb.add(attrDef);
        }
    }

    /**
     * Regroups such that MVAs that are part of an MCB
     * are placed together in order of their MCB column number
     */
    private static void segregateMCB(List attrDefs) throws AdmException {
        List mcb = null;
        AttributeDefinition attrDef = null;
        AttributeDefinition tmpAttrDef = null;
        for (int i = 0; i < attrDefs.size(); i++) {
            attrDef = (AttributeDefinition) attrDefs.get(i);
            if (attrDef.getBlock() != null) {
                mcb = new Vector();
                mcb.add(attrDef);

                // Locate other attrDefs within the same MCB
                for (int j = i + 1; j < attrDefs.size(); j++) {
                    tmpAttrDef = (AttributeDefinition) attrDefs.get(j);
                    if ((tmpAttrDef.getBlock() != null)
                            && tmpAttrDef.getBlock().getAdmSpec().equals(attrDef.getBlock().getAdmSpec())) {
                        addMVAToMCB(mcb, tmpAttrDef);
                        attrDefs.remove(j);
                        j--;
                    }
                }

                attrDefs.set(i, mcb.get(mcb.size() - 1));
                for (int j = mcb.size() - 2; j >= 0; j--) {
                    attrDefs.add(i, mcb.get(j));
                }
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        boolean forceQuery = ((Boolean) getAttrValue(CmdArguments.FORCE_QUERY)).booleanValue();

        List attrNames = null;
        if (getAttrValue(CmdArguments.ATTRIBUTE_NAMES) instanceof String) {
            attrNames = new Vector();
            attrNames.add(getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
        } else {
            attrNames = new Vector((List) getAttrValue(CmdArguments.ATTRIBUTE_NAMES));
        }

        List attrsToQuery = null;
        if (forceQuery) {
            attrsToQuery = attrNames;
        } else {
            for (int i = 0; i < attrNames.size(); i++) {
                if (admObj.getAttrDef((String) attrNames.get(i)) == null) {
                    if (attrsToQuery == null) {
                        attrsToQuery = new Vector();
                    }

                    attrsToQuery.add(attrNames.get(i));
                }
            }
        }

        if ((attrsToQuery != null) && (attrsToQuery.size() > 0)) {
            Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY_DEFS, admObj);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, attrsToQuery);
            cmd.setAttrValue(CmdArguments.FILTER, getAttrValue(CmdArguments.FILTER));
            cmd.setAttrValue(CmdArguments.MULTIPLE, getAttrValue(CmdArguments.MULTIPLE));
            cmd.execute();
        }

        List ret = new Vector();
        AttrDef attrDef = null;
        AttributeDefinition tmpAttrDef = null;
        AttributeDefinition userAttrDef = null;
        String attrName = null;
        for (int i = 0; i < attrNames.size(); i++) {
            if (((String) attrNames.get(i)).equals(AdmAttrNames.USER_DEFINED_ATTRIBUTES)) {
                List attrDefs = admObj.getAllAttrDefs();
                if (attrDefs != null) {
                    for (int j = 0; j < attrDefs.size(); j++) {
                        attrDef = (AttrDef) attrDefs.get(j);
                        attrName = attrDef.getName();
                        if ((attrName != null) && (attrName.length() > 0)
                                && (attrName.charAt(0) != Constants.NON_USER_DEF_ATTR_CHAR)) {
                            userAttrDef = (AttributeDefinition) attrDef;
                            if ((ret.size() < 1) || (userAttrDef.getDisplayOrder() == 0)) {
                                ret.add(userAttrDef);
                            } else {
                                for (int k = ret.size() - 1; k >= 0; k--) {
                                    tmpAttrDef = (AttributeDefinition) ret.get(k);
                                    if (tmpAttrDef == null) {
                                        ret.add(userAttrDef);
                                        break;
                                    } else if (tmpAttrDef.getDisplayOrder() == 0) {
                                        if (k == 0) {
                                            ret.add(k, userAttrDef);
                                            break;
                                        } else {
                                            continue;
                                        }
                                    } else if (tmpAttrDef.getDisplayOrder() < userAttrDef.getDisplayOrder()) {
                                        if (k == (ret.size() - 1)) {
                                            ret.add(userAttrDef);
                                        } else {
                                            ret.add(k + 1, userAttrDef);
                                        }

                                        break;
                                    } else if (tmpAttrDef.getDisplayOrder() > userAttrDef.getDisplayOrder()) {
                                        if (k == 0) {
                                            ret.add(k, userAttrDef);
                                            break;
                                        } else {
                                            continue;
                                        }
                                    } else {
                                        ret.add(k, userAttrDef);
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    segregateMCB(ret);
                }
            } else if (!(((String) attrNames.get(i)).equals(AdmAttrNames.USER_DEFINED_ATTRIBUTE_NUMBERS))) {
                ret.add(admObj.getAttrDef((String) attrNames.get(i)));
            }
        }

        return ret;
    }
}

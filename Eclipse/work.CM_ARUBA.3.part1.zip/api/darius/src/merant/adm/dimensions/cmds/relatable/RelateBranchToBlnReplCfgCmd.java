/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.serena.dmnet.drs.DRSClientSysObjAttrUtils;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimLockedException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.Branch;
import merant.adm.dimensions.objects.NetBaseDatabase;
import merant.adm.dimensions.objects.ReplBlnMasterConfig;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate a Branch to a Baseline Replication Configuration.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {Type}<dt><dd>Dimensions Branch object</dd>
 *  <dt>ADM_PARENT_OBJECT {ItemTypeGroup}<dt><dd>Parent Dimensions Baseline Replication Configuration object (only master)</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Vadymk
 */
public class RelateBranchToBlnReplCfgCmd extends DBIOCmd {

    public RelateBranchToBlnReplCfgCmd() throws AttrException {
        super();
        setAlias("RelateBranchToBlnReplCfgCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, Branch.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof Branch)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof ReplBlnMasterConfig)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {
        validateAllAttrs();

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_REPL")) {
            throw new DimNoPrivilegeException("ADMIN_REPL");
        }

        // Dimensions baseline replication configuration
        final AdmObject configObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        // Dimensions branch
        final AdmObject branchObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        final boolean bDeassign = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();

        // determine replication configuration attributes
        List attrs = AdmHelperCmd.getAttributeValues(configObj,
                Arrays.asList(new Object[] { AdmAttrNames.ID, AdmAttrNames.REVISION }));
        final String configId = (String) attrs.get(0);
        final String revision = (String) attrs.get(1);

        // make sure that the replication configuration actually exists
        if (!DoesExistHelper.replConfigExists(configId, Constants.REPL_BASELINE_CLASS, revision)) {
            throw new DimNotExistsException("Error: baseline replication configuration " + configId + " does not exists.");
        }

        final long configUid = ((AdmUidObject) configObj).getUid();
        final long replSiteUid = ((Long) AdmHelperCmd.getAttributeValue(configObj, AdmAttrNames.REPL_BASEDB_UID)).longValue();

        AdmObject thisSite = AdmCmd.getCurRootObj(NetBaseDatabase.class);
        long thisSiteUid = 0;
        if (thisSite != null) {
            thisSiteUid = ((AdmUidObject) thisSite).getUid();
        }

        if (!isLocalReplConfig(null, configUid, Constants.REPL_BASELINE_CLASS, thisSiteUid)) {
            throw new DimLockedException("Error: remote baseline replication configuration " + configId + " is not updatable.");
        }

        if (!"0".equals(revision)) {
            throw new DimLockedException("Error: remote baseline subordinate is not updatable.");
        }

        // determine branch attributes
        final String branchName = branchObj.getId();

        if (!branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)
                && !branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {

            if (!DoesExistHelper.branchExists(branchName)) {
                throw new DimNotExistsException("Error: branch " + branchName + " does not exist.");
            }
        }

        new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {

            @Override
            public void execute(DBIO dbCtx) throws Exception {

                // form the list of branches to be validated
                List branchList = new ArrayList();
                branchList.add(branchObj);

                // validate the branch against repl config workset
                Cmd cmd = AdmCmd.getCmd("_internal_validate_branch_list");
                cmd.setAttrValue(CmdArguments.DBIO_QUERY, dbCtx);
                cmd.setAttrValue(CmdArguments.BRANCHES, branchList);
                cmd.setAttrValue(CmdArguments.REPL_BASEDB_UID, new Long(replSiteUid));
                cmd.execute();

                long branchUid = getBranchUid(dbCtx, branchName);
                if (branchUid == -1) {
                    throw new DimNotExistsException("Error: branch " + branchName + " does not exist.");
                }

                // check if this branch has already been defined for this replication config
                boolean isAlreadyAssigned = false;
                if (branchUid == Constants.REPL_ALL_LOCAL_BRANCHES_UID || branchUid == Constants.REPL_ALL_NAMED_BRANCHES_UID) {
                    isAlreadyAssigned = isSpecialBranchAssigned(dbCtx, branchUid, configId, revision, Constants.REPL_BASELINE_CLASS);
                } else {
                    isAlreadyAssigned = isBranchAssigned(dbCtx, branchUid, configId, revision, Constants.REPL_BASELINE_CLASS);
                }

                if (!bDeassign) {

                    if (isAlreadyAssigned) {
                        throw new DimAlreadyExistsException("Error: branch " + branchName
                                + " has already been assigned to the baseline replication configuration " + configId + ".");
                    }

                    // assign the branch
                    String userName = AdmCmd.getCurRootObj(User.class).getId();
                    long relUid = getNewUid(dbCtx);
                    SqlUtils.replAssignBranchToConfig(dbCtx, relUid, configUid, branchUid, userName);
                    dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);
                }

                else {
                    // check if branch has already been assigned
                    if (!isAlreadyAssigned) {
                        throw new DimNotExistsException("Error: branch " + branchName
                                + " has not been assigned to the baseline replication configuration " + configId + ".");
                    }

                    // deassign the branch from the replication configuration
                    SqlUtils.replDeassignBranchFromConfig(dbCtx, configUid, branchUid);
                    dbCtx.write(DBIO.DB_DONT_COMMIT);
                    dbCtx.close(DBIO.DB_DONT_RELEASE);

                    // // check if there still remaing at least one more branch
                    // // if not, throw an exception
                    // dbCtx.resetMessage(wcm_sql.REPL_CONFIG_HAS_BRANCHES);
                    // dbCtx.bindInput(configUid);
                    // dbCtx.readStart();
                    // boolean hasBranches = dbCtx.read(DBIO.DB_DONT_CLOSE);
                    // dbCtx.close(DBIO.DB_DONT_RELEASE);
                    // if (!hasBranches)
                    // throw new DimNotExistsException(
                    // "Error: there must be at least one assigned branch to the baseline replication configuration "
                    // + configId
                    // + ".");
                }
                // update audit trail
                SqlUtils.updateSysobj(dbCtx, configUid, AdmCmd.getCurRootObj(User.class).getId());
                dbCtx.write(DBIO.DB_DONT_COMMIT);
                dbCtx.close(DBIO.DB_DONT_RELEASE);

            }
        });

        return new AdmResult("Operation completed");
    }

    private boolean isBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass)
            throws AdmException {

        dbCtx.resetMessage(wcm_sql.REPL_IS_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private boolean isSpecialBranchAssigned(DBIO dbCtx, long branchUid, String configId, String revision, int repClass)
            throws Exception {

        dbCtx.resetMessage(wcm_sql.REPL_IS_SPECIAL_BRANCH_ASSIGNED);
        dbCtx.bindInput(configId);
        dbCtx.bindInput(revision);
        dbCtx.bindInput(repClass);
        dbCtx.bindInput(branchUid);
        dbCtx.readStart();
        boolean isAssigned = dbCtx.read(DBIO.DB_DONT_CLOSE);
        dbCtx.close(DBIO.DB_DONT_RELEASE);
        return isAssigned;
    }

    private boolean isLocalReplConfig(DBIO dbCtx, long configUid, int replClass, long siteUid) throws AdmException {

        if (dbCtx != null) {
            dbCtx.resetMessage(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
            dbCtx.bindInput(configUid);
            dbCtx.bindInput(replClass);
            dbCtx.bindInput(siteUid);
            dbCtx.readStart();
            boolean isOwned = dbCtx.read(DBIO.DB_DONT_CLOSE);
            dbCtx.close(DBIO.DB_DONT_RELEASE);
            return isOwned;
        }
        dbCtx = new DBIO(wcm_sql.REPL_CONFIG_IS_OWNED_BY_SITE);
        dbCtx.bindInput(configUid);
        dbCtx.bindInput(replClass);
        dbCtx.bindInput(siteUid);
        dbCtx.readStart();
        boolean isOwned = dbCtx.read();
        dbCtx.close();
        return isOwned;
    }

    private long getBranchUid(DBIO dbCtx, String branchName) throws AdmException {
        long branchUid = -1;
        if (branchName.equalsIgnoreCase(Constants.REPL_ALL_LOCAL_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_LOCAL_BRANCHES_UID;
        } else if (branchName.equalsIgnoreCase(Constants.REPL_ALL_NAMED_BRANCHES_ID)) {
            branchUid = Constants.REPL_ALL_NAMED_BRANCHES_UID;
        } else {
            DRSClientSysObjAttrUtils drs = new DRSClientSysObjAttrUtils(DRSClientSysObjAttrUtils.SysObjAttrUtilsQueryContext.GetAdmUids);
            drs.setObjClass(DRSClientSysObjAttrUtils.SYSOBJ_NAMED_BRANCH);
            drs.setAdmId(branchName);
            DRSUtils.execute(drs);

            if (drs.hasData() && (drs.getAdmUids() != null) && (drs.getAdmUids().length > 0)) {
            	branchUid = drs.getAdmUids()[0];
            }
        }

        return branchUid;
    }
}

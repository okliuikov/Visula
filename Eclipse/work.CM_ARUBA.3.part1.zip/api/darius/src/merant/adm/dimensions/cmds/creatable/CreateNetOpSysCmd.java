/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.NetOpSys;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will create a Dimensions Network Operating System object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ID {String}</dt><dd>Name identifier of the new operating system</dd>
 *  <dt>CASE {String}</dt><dd>Constants.CASE_LOWER/CASE_MIXED/CASE_UPPER for the os filename case convention</dd>
 *  <dt>LIB_PROTECTION {String}</dt><dd>OS library protections</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains AdmBaseId as the user data</dd>
 * </dl></code>
 * @author Floz
 */
public class CreateNetOpSysCmd extends RPCExecCmd {
    public CreateNetOpSysCmd() throws AttrException {
        super();
        setAlias(Creatable.CREATE);
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.CASE, true, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.LIB_PROTECTION, true, String.class));

        // Internal arguments
        setAttrDef(new CmdArgDef(CmdArguments.INT_SPEC, false, String.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String fnameCase = (String) getAttrValue(AdmAttrNames.CASE);
        String protection = (String) getAttrValue(AdmAttrNames.LIB_PROTECTION);

        setAttrValue(CmdArguments.INT_SPEC, id);

        _cmdStr = "COS ";
        _cmdStr += " /OS_NAME=" + Encoding.escapeSpec(id);
        _cmdStr += " /CASE=\"" + fnameCase + "\"";
        _cmdStr += " /LIB_PROTECTION=\"" + protection + "\"";

        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, NetOpSys.class);
        return retResult;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.PrimedAttributeMapping;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions PrimedAttributeMapping object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeletePrimedAttributeMappingCmd extends RPCExecCmd {
    public DeletePrimedAttributeMappingCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof PrimedAttributeMapping)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        AdmBaseId scope = admObj.getAdmBaseId().getScope();

        AdmObject primingObj = AdmHelperCmd.getObject(scope);

        AdmObject typeObj = (AdmObject) AdmHelperCmd.getAttributeValue(primingObj, AdmAttrNames.TYPE_PRIMING_TYPE_OBJ);
        AdmObject primedTypeObj = (AdmObject) AdmHelperCmd.getAttributeValue(primingObj, AdmAttrNames.TYPE_PRIMING_RELATED_TYPE_OBJ);

        AdmObject fromAttrObj = (AdmObject) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TYPE_PRIMING_FROM_ATTR_OBJ);
        AdmObject toAttrObj = (AdmObject) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.TYPE_PRIMING_TO_ATTR_OBJ);

        // Query data for priming type
        List attrs = AdmHelperCmd.getAttributeValues(typeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        String productName = (String) attrs.get(0);
        String typeName = (String) attrs.get(1);
        Class typeClass = (Class) attrs.get(2);

        // Query data for primed type
        attrs = AdmHelperCmd.getAttributeValues(primedTypeObj,
                Arrays.asList(new Object[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS }));
        String primedProductName = (String) attrs.get(0);
        String primedTypeName = (String) attrs.get(1);
        Class primedTypeClass = (Class) attrs.get(2);

        // get attr names
        String fromAttrName = fromAttrObj.getId();
        String toAttrName = toAttrObj.getId();

        // Construct OBJTYPE command
        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /DELETE_ATTR_MAPPING ");
        cmdBuf.append(Encoding.escapeDMCLI(typeName));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(productName));

        if (typeClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /OBJ_CLASS=REQUEST");
        } else {
            throw new DimAlreadyExistsException("Dimensions object type " + productName + ":" + typeName
                    + " is not a request type.");
        }

        cmdBuf.append(" /PRIMED_PRODUCT=").append(Encoding.escapeDMCLI(primedProductName));
        cmdBuf.append(" /PRIMED_TYPE_NAME=").append(Encoding.escapeDMCLI(primedTypeName));

        if (primedTypeClass.equals(ChangeDocument.class)) {
            cmdBuf.append(" /PRIMED_OBJ_CLASS=REQUEST");
        } else {
            throw new DimAlreadyExistsException("Dimensions object type " + primedProductName + ":" + primedTypeName
                    + " is not a request type.");
        }

        cmdBuf.append(" /ATTR_FROM=").append(Encoding.escapeDMCLI(fromAttrName));
        cmdBuf.append(" /ATTR_TO=").append(Encoding.escapeDMCLI(toAttrName));

        _cmdStr = cmdBuf.toString();
        AdmResult retResult = new AdmResult(executeRpc());
        AdmCmd.populateBaseIdFromAdmResult(this, retResult, PrimedAttributeMapping.class);
        return retResult.toString();
    }
}
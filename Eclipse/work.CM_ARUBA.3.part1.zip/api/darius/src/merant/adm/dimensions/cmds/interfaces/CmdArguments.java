/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.interfaces;

import merant.adm.dimensions.server.core.Constants;

/**
 * This class contains the constants used for command arguments.
 * @author Peter Raymond
 */
public class CmdArguments {
    // Objects...
    public static final String ADM_BASE_ID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmBaseId"; // AdmBaseId
    public static final String ADM_BASE_IDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmBaseIds";
    // List of AdmBaseId objects
    public static final String ADM_SEC_CLASS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.SecAdmObjectClass";
    // Secondary Class
    public static final String ADM_CHILD_CLASS = ADM_SEC_CLASS; // Class
    public static final String ADM_CMD_OBJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmCmdObject";
    // Class, AdmObject or List
    public static final String ADM_OBJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmObject"; // AdmObject object
    public static final String ADM_OBJECT_CLASS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmObjectClass"; // Class
    public static final String ADM_OBJECT_CLASS_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmObjectClassList";
    // List of Class objects
    public static final String ADM_OBJECT_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmObjectList";
    // List of AdmObject objects
    public static final String ADM_PARENT_CLASS = ADM_SEC_CLASS; // Class
    public static final String ADM_PARENT_OBJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmParentObject";
    // AdmObject object
    public static final String ADM_REL_TYPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmRelType";
    // RelationshipType object
    public static final String ADM_SCOPE_ID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmScopeId"; // AdmBaseId object
    public static final String ADM_SCOPE_OBJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AdmScopeObject";
    // AdmObject object
    public static final String BASELINE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Baseline";
    public static final String BASEDATABASE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.BaseDatabase";
    public static final String STARTING_BASELINE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.StartingBaseline";
    // BaseDatabase object
    public static final String BRANCH = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Branch";
    // AdmObject(Part of Revision) or Boolean(Opposite of Trunk)
    public static final String BUILDTARGET_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.BuildTargetList";
    // List of BuildTarget objects
    public static final String SRC_ITEMS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.SrcItems";
    public static final String SRC_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.SrcFiles";
    public static final String SRC_CHANGE_DOCS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.SrcChDocs";
    // List of source objects for BLD, Items or ChangeDocuments
    public static final String STAGE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Stage";
    public static final String STAGEREFAREA = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.StageRefArea";
    // StageReferenceArea object

    public static final String NETBASEDB = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetBaseDb";
    // String object - Used by CreateNetInstanceCmd only
    public static final String NETCLIENTNODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetClientNode";
    // String object - Used by CreateNetNodeConnectionCmd only
    public static final String NETCODESET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetCodeset";
    // String object - Used by CreateNetNodeConnectionCmd only
    public static final String NETCONTACT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetContact";
    // String object - Used by CreateBaseDatabaseCmd only
    public static final String NETFILESYSTEM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetFileSys";
    // String object - Used by CreateNetNodeConnectionCmd only
    public static final String NETINSTANCE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetInstance";
    // String object - Used by CreateBaseDatabaseCmd only
    public static final String NETNODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetNode";
    // NetNode object - Used by StageReferenceArea and BuildBaselineCmd
    public static final String NETSERVERNODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetServerNode";
    // String object - Used by CreateNetNodeConnectionCmd only
    public static final String NETWORKOBJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.NetworkObject";
    // String object - Used by CreateNetNodeConnectionCmd only

    public static final String ITEM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Item"; // Item object
    public static final String PART = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Part"; // Part object
    public static final String RELEASE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Release"; // Release object
    public static final String WORKSET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Workset";
    public static final String TARGET_WORKSET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.target_workset";
    public static final String WORKSET_VERSION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.WorksetVersion";
    public static final String IDM_TOOL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.idm_tool";

    // UIDS...
    public static final String PARENT_UID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.ParentUid"; // Long
    public static final String UID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.UID"; // Long
    public static final String USE_UIDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.UseUids"; // Boolean
    public static final String PRODUCT_UID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.ProductUid"; // Long

    // Login Parameters
    public static final String SESSION_BEAN = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.SessionBean";
    public static final String USER_DB_NAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userDbName"; // String
    public static final String USER_DB_PASSWORD = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userDbPassword"; // String
    public static final String USER_NAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userName"; // String
    public static final String USER_PASSWORD = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userPassword"; // String
    public static final String HOSTNAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userHostname"; // String
    public static final String DATASOURCE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.datasource"; // String
    public static final String CLIENTNODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.clientNode"; // String
    public static final String LICENSETYPES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.licenseTypes"; // int[]
    public static final String APPNAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.appName"; // String
    public static final String USER_NEW_PASSWORD = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userNewPassword"; // String

    // Parameters...
    public static final String ACCEPT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.accept"; // Boolean
    public static final String ACTION_CHECK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.action_check"; // Boolean
    public static final String ACTION_COMMENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.actionComment"; // String
    public static final String BRIEF = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.brief"; // Boolean
    public static final String CLOSURE_CHECK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.closure_check"; // Boolean
    public static final String LAST_ACTION_COMMENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.lastActionComment"; // Boolean
    public static final String AFFECTED_PARTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.affectedParts";
    // List of Part objects
    public static final String ALL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.all";
    /** 3 columned Grid of attachment details(Strings): file_id, user_file, description */
    public static final String ATTACHMENTS_GRID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.attachmentsGrid";
    // Grid of String objects
    public static final String ATTRIBUTE_NAMES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.attributeNames"; // List of String
                                                                                                                   // objects
    // Grid of String objects - used by SQ for optimizing query
    public static final String GET_BY_CUSTOM_ATTRIBUTE_MAP = Constants.NON_USER_DEF_ATTR_CHAR
            + "CmdArguments.getByCustomAttributeMap"; // List of String objects
    // List of String objects
    public static final String ATTRIBUTE_NUMBERS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.attributeNumbers";
    // Map of Attribute Name to Numbers
    public static final String ATTRIBUTE_TYPES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.attributeTypes";
    // Map of Attribute Name to Types
    public static final String AUDIT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.audit"; // Boolean
    public static final String BATCH = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.batch"; // Boolean
    public static final String HEADER_NAMES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.headerNames";
    // List of String objects
    public static final String PREF_NAMES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.prefNames"; // List of String objects
    public static final String PREF_VALUES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.prefValues";
    // Type of user preference - Integer object with values from Contstants.USER_PREF_TYPE_xxx
    public static final String USER_PREF_TYPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userPrefType";
    // List of String objects
    public static final String BASED_ON = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.PrimeBasedOnChangeDocument";
    // ChangeDocument object or Boolean(for Relatable.QUERY_VALID_OBJTYPES)
    public static final String BASED_ON_PRODUCT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.CreateBasedOnProduct";
    // product name for Creatable.CreateProductCmd
    public static final String BASELINE_CODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.BaselineCode";
    // BaselineCode id for Creatable.CreateBaselineTemplateRuleCmd
    public static final String CANCEL_TRAVERSE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.cancelTraverse"; // Boolean
    public static final String CHERRYPICK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.cherrypick"; // Boolean
    public static final String CANDIDATE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.candidate"; // Boolean
    public static final String CAPABILITY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.capability";
    public static final String CAPTURE_BUILD_OUTPUTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.captureBuildOutputs"; // Boolean
    public static final String CAPTURE_BUILD_PROJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.captureBuildProject"; // String
    public static final String CATEGORY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.category";
    public static final String CHANGE_MANAGER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.changeManager";
    public static final String CHECK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.check"; // Boolean
    public static final String CLEAN = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.clean"; // Boolean
    public static final String COLUMN1_VALUES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.column1Values";
    public static final String COMMENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.comment"; // String
    public static final String SCHEDULE_DATETIME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.schedDatetime"; // String
    public static final String CLIENT_TIMEZONE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.clientTimezone"; // String
    public static final String CLIENT_TIMEZONE_OFFSET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.clientTimezoneOffset"; // String
    public static final String CLIENT_TIMESTAMP_LABEL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.clientTimestampLabel"; // String
    public static final String SCHEDULED_JOB = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.scheduledJob"; // ScheduledJob
                                                                                                               // object
    public static final String COPY_IPDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.CopyIPDs";
    public static final String DESCRIPTION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.description"; // String
    public static final String DELETE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.delete";
    public static final String DETAILED_DESCRIPTION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.detailedDesc";
    public static final String DIRECTORY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.directory";
    public static final String USER_DIRECTORY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.user_directory";
    public static final String DISPLAY_ORDER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.display_order";
    public static final String EXPAND = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userFileExpand"; // Boolean
    public static final String FILENAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filename"; // String
    public static final String FILE_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.file_list";
    public static final String FILTER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filter";
    public static final String FORCE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.force";
    public static final String QUERY_RANGE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.query.range";
    public static final String USER_DISPLAY_FORMATTER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.user.display.formatter";
    public static final String FORCE_UPDATE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.forceUpdate"; // Boolean
    public static final String GETATTRS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.getAttributes";
    public static final String GLOBAL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.global";
    public static final String HOLD = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.hold";
    public static final String HOST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.host";
    public static final String INCLUDE_CLOSED = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.includeClosed"; // Boolean for CBL
    public static final String INCLUDE_GLOBAL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.includeGlobal"; // Boolean for
                                                                                                                 // Creatable.CreateProductCmd
    public static final String INCLUDE_INFO = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.includeInfo"; // Boolean for CBL
    public static final String ITEM_FILTER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.ItemFilter";
    public static final String KEEP = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.keep"; // Boolean
    public static final String LEVEL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.level";
    public static final String MSG_ARGS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.msg_args";
    public static final String MSG_NUM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.msg_num";
    public static final String MULTIPLE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.multiple"; // Boolean
    public static final String NEW_VARIANT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.newVariant"; // String
    public static final String NO_OF_COLUMNS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.noOfColumns";
    public static final String NOWSET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.nowset"; // Boolean
    public static final String OPTIONS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.options"; // String object
    public static final String OWNING_PART = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.part"; // Part object
    public static final String OVERWRITE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.overwrite"; // Boolean
    public static final String PARENT_PART = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.parentPart"; // Part object
    public static final String PARENT_VARIANT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.parentVariant"; // String
    public static final String PARTS_CONTROLLER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.partsController";
    public static final String PENDING = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.pending"; // Boolean
    public static final String PRODUCT_MANAGER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.productManager";
    public static final String PROXY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.proxy";
    public static final String REAL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.real";
    public static final String RECURSIVE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.recursive"; // Boolean
    public static final String SECURE_CHECKSUM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.secureChecksum"; // Boolean
    public static final String RECURSIVE_VIA_PARENT_HIER = Constants.NON_USER_DEF_ATTR_CHAR
            + "CmdArguments.recursive_via_parent_hier"; // Boolean
    public static final String RELATIVE_LOCATION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.relativeLocation";
    public static final String REPLACE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.replace";
    public static final String REPORT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.report"; // Boolean
    public static final String REVISE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.revise"; // Boolean
    public static final String SQL_INPUTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.sqlInputs";
    public static final String SQL_QUERY_NO = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.sqlQueryNo";
    public static final String SQL_QUERY_STR = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.sqlQueryStr";
    public static final String STATUS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.status"; // String
    public static final String COPY_STRUCTURE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.CopyStructure";
    public static final String CANCEL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Cancel";
    // Boolean for Creatable.CreateProductCmd
    public static final String TEMPLATE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.template";
    public static final String RELATED_BASELINES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.relatedBaselines";
    public static final String RELATED_CHDOCS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.relatedChdocs";
    public static final String RELATED_ITEMS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.relatedItems"; // Boolean for DLGC
    public static final String RELATIONSHIPS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.relationships";
    public static final String REMOVE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.remove";
    public static final String REMOVE_CHDOCS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.removeChdocs";
    public static final String REMOVE_ITEMS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.removeItems";
    // List of AdmObject{ChangeDocument}'s
    public static final String REMOVE_USER_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.remove_user_list";
    public static final String REMOVE_USER_LIST_IDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.remove_user_list_ids";
    public static final String REVISION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.revision"; // String
    public static final String REVISION_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.revision_list"; // List
    public static final String ROLE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.role";
    public static final String ROLE_DEF = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.roleDefinition";
    public static final String ROLE_CHECK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.roleCheck";
    public static final String ROOT_PROJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.rootProject";
    public static final String PROFILE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.profile";
    public static final String PROFILE_DEF = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.profileDefinition";
    public static final String PROFILE_CHECK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.profileCheck";
    public static final String TOUCH = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.touch"; // Boolean
    public static final String UPDATE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.update"; // Boolean
    public static final String UPDATE_CHDOCS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.updateChdocs";
    public static final String LOCK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.lock"; // Boolean
    public static final String SESSION_LOCK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.session_lock"; // Boolean
    public static final String CANCEL_LOCK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.cancel_lock"; // Boolean
    public static final String SITE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.site"; // String
    // List of AdmObject{ChangeDocument}'s
    public static final String USE_PARENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.use_parent"; // Boolean
    public static final String USE_GLOBAL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.use_global"; // Boolean
    public static final String USE_SUPER_QUERY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.use_super_query"; // Boolean
    public static final String USER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.user";
    public static final String USER_FILE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userFilename"; // String
    public static final String USER_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.user_list";
    public static final String USER_LIST_IDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.user_list_ids";
    public static final String VALID_SET_NAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.validSetName";
    public static final String WORKSET_TYPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.worksetType";
    public static final String WS_FILE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.wsFilename"; // String
    public static final String FORMAT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.blameFormat";
    public static final String USERNAMEFORMAT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.userNameFormat";

    // Merant Build and File Area Arguments...
    public static final String RESET_PROJECT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.reset_project";
    public static final String POPULATE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.populate";
    public static final String POPULATE_SCOPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.populate_scope";
    public static final String AREA_REL_LOCATION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.areaRelativeLocation";

    // Compare and Merge Arguments...
    public static final String BASE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.base";
    public static final String BRANCHES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.branches"; // List
    public static final String TARGET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.target";

    // Internal Command Arguments...
    public static final String AUTH_POINT_INFO = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.auth_point_info";
    public static final String AUTH_POINT_PARAM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.auth_point_param";
    // AuthPointInfo - don't use
    public static final String INT_SPEC = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.int_spec"; // String - don't use
    public static final String INT_SCOPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.int_scope"; // AdmBaseId - don't use

    // Filter...
    public static final String FILTER_I_LATEST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterItemLatest";
    public static final String FILTER_I_LATESTFV = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterItemLatestFv";
    public static final String FILTER_ROOT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterRoot";
    public static final String FILTER_U_ISTOOLMGR = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterUserIsToolManager";
    public static final String FILTER_BUILT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterItemIsBuilt";
    public static final String FILTER_DERIVED = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterItemIsDerived";
    public static final String FILTER_USAGE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterUsage";
    public static final String FILTER_INFO = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterInfo";
    public static final String FILTER_CONTRIBUTER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filterContributer";
    public static final String FILTER_IGNORE_TOPIC_FILTERING = Constants.NON_USER_DEF_ATTR_CHAR
            + "CmdArguments.filterIgnoreTopicFiltering";

    // Upload Arguments
    public static final String FORCE_TIP = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.forceTip";
    public static final String FILES_TO_UPLOAD = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filesToUpload";
    public static final String LOG_FILE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.logFile";
    public static final String SCRIPT_FILE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.scriptFile";
    public static final String CODE_PAGE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.codePage";
    public static final String EOL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.eol";
    public static final String VERBOSE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.verbose";

    // Download Arguments
    public static final String ITEMS_TO_DOWNLOAD = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.itemsToDownload";
    public static final String REFACTORING = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.downloadRefactoring";
    public static final String FORCE_ADD = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.forceAdd";
    public static final String FORCE_DELETE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.forceDelete";
    public static final String FORCE_FETCH = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.forceFetch";
    public static final String LEGACY_MODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.legacyMode";
    public static final String MERGE_STREAM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.mergeStream";
    public static final String MODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.mode";
    public static final String PARENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.parent";
    public static final String QUIET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.quiet";
    public static final String REEXPAND = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.reexpand";
    public static final String SORT_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.sortFiles";
    public static final String STREAM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.stream";
    public static final String REHOME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.rehome";
    // new xml inputs
    // workarea scan
    public static final String WORKAREA_SCAN_CONTAINER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.workareaScanContainer";
    public static final String WORKAREA_SCAN = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.workareaScan";
    public static final String MERGEPOINTS_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.mergePointsList";

    // user resolution
    public static final String RESOLUTION_ACTIONS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.resolutionActions";

    // new xml outputs
    // server resolutions and/or execution results
    public static final String RESOLUTION_RESULTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.resolutionResults";

    // Miscellaneous...
    public static final String COMMAND = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.command";
    public static final String EMAIL_MESSAGES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.emailMessages";
    public static final String FORCE_QUERY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.forceQuery"; // Boolean
    public static final String PARENT_RELATIVE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.parentRelative"; // Boolean
    public static final String RULE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.Rule";
    public static final String RULE_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.RuleList";
    public static final String AUTO_SPLIT_TRANSITIONS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.AutoSplitTransitions";

    public static final String DBIO_QUERY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.dbioQuery";
    public static final String ADDING_TRANSITION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.addingTransition";

    public static final String ORIGINATING_TRANSITIONS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.originatingTransitions";
    public static final String TERMINATING_TRANSITIONS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.terminatingTransitions";

    public static final String ATTRIBUTES_STRING = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.attributesString";
    public static final String REPL_IS_REMOTE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.repl_is_remote";
    public static final String REPL_BASEDB_UID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.repl_basedb_uid";
    public static final String ITEM_TYPES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.item_types"; // LIST
    public static final String ITEM_TYPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.item_type";
    public static final String CHDOC_TYPES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.chdoc_types"; // List
    public static final String DOLLAR_ROLES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.dollar_roles"; // Boolean

    public static final String INCLUDE_ROOT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.include_root"; // Boolean

    public static final String CONTENT_TYPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.content_type"; // Integer
    public static final String CONTENT_ENCODING = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.content_encoding"; // String
    public static final String TYPE_OF_SERVER_VERSION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.typeOfServerVersion";

    // new SCWS arguments
    public static final String RESET = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.reset"; // Boolean
    public static final String DEFAULT_CHDOC = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.default_chdoc"; // String
    public static final String LIBRARY_CACHE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.library_cache_area"; // String
    public static final String DEFAULT_PART = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.default_part"; // String

    // * Requirements arguments
    /** A list of requirements to remove */
    public static final String REMOVE_REQUIREMENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.removeRequirements";

    /** Collection Details of Requirements */
    public static final String CONTAINER_DETAILS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.containerDetails";

    /** A list of requirements to add */
    public static final String UPDATE_REQUIREMENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.updateRequirements";
    public static final String RELATED_REQUIREMENTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.relatedRequirements";
    /**
     * A product to query from. Used for getting the RTM connection
     * information, which is related to a product
     */
    public static final String PRODUCT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.product";
    /** Determines the mode for an RPC */
    public static final String RPC_MODE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.rpc_mode";

    /** METADATA arguments */
    public static final String WRITE_METADATA = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.writeMetadata";

    /** for MI merge into existing revision **/
    public static final String SELF = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.self";

    /** for Upload to force UI for metadataless items **/
    public static final String FORCE_CHECKIN = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.force_checkin";
    /** for Upload/Download to execute as well as generate xml **/
    public static final String EXECUTE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.execute";

    /** for Upload to use specific rules **/
    public static final String UPLOAD_RULES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.upload_rules";
    public static final String EXTENSION = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.extension";
    /** CREATE_PROD_UPLOAD_RULE: Dimensions (upload) */
    public static final String CREATE_PROD_UPLOAD_RULE = Constants.NON_USER_DEF_ATTR_CHAR + "AdmAttrNames.create_prod_upload_rule";
    /** to set progress on / off around command **/
    public static final String PROGRESS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.progress";
    /** to set cancel monitor for command **/
    public static final String CANCEL_MONITOR = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.cancel_monitor";
    /** to set restricted **/
    public static final String RESTRICTED = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.restricted";
    /** enable conflict check for upload/download commands **/
    public static final String CONFLICT_CHECK = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.conflict_check";
    /** enable getting conflicts for upload command **/
    public static final String GETCONFLICTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.getconflicts";
    /** cancel checkout of unchanged enable conflict check for upload/download commands **/
    public static final String CANCEL_UNCHANGED = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.cancel_unchanged";
    /** transfer scripts to run for download **/
    public static final String TRANSFER_SCRIPTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.transfer_scripts";
    /** permissions to set **/
    public static final String PERMS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.perms";
    /** cache files in upload/download **/
    public static final String CACHE_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.cache_files";
    /** file cache size in bytes - will be rounded to dm_file_blocksize multiple **/
    public static final String FILECACHE_SIZE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.filecache_size";
    /** ignore errors and keep going in download/upload **/
    public static final String IGNORE_ERRORS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.ignore_errors";
    /** Container name of a Requirement **/
    public static final String CONTAINER_NAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.container_name";
    /** Is the workset a Stream? **/
    public static final String WSET_IS_STREAM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.wset_is_stream";// Boolean
    public static final String WSET_IS_TOPIC_STREAM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.wset_is_topic_stream";// Boolean
    public static final String TOPIC_STREAM_USERS_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.topic_stream_visibility_users_list";
    public static final String IMPORT_ALL_REVISIONS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.import_all_revisions";// Boolean
    /** files to be delivered **/
    public static final String FILES_TO_DELIVER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.files_to_deliver";
    public static final String CONTRIBUTOR_STREAMS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.contributor_streams";
    public static final String DELETE_WORKING_LISTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.delete_working_lists";
    public static final String ENABLE_ADD_NEW_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.enable_add_new_files";
    public static final String DISABLE_ADD_NEW_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.disable_add_new_files";
    public static final String ENABLE_DELETE_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.enable_delete_files";
    public static final String DISABLE_DELETE_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.disable_delete_files";
    public static final String USER_FILTER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.user_filter";
    public static final String ENABLE_UPDATE_FILES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.enable_update_files";
    public static final String DELIVER_SHAPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.deliver_shape";
    public static final String REVISION_PROPERTIES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.revision_properties";
    public static final String DELIVER_WORKAREA_TYPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.deliver_workarea_type";

    /** Shelving */
    public static final String SHELF_NAME = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.shelf_name";
    public static final String SHELF_DESC = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.shelf_desc";
    public static final String DEFAULT_BRANCH = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.default_name";

    /** arguments for writing metadata back to the server **/
    public static final String FULL_FILEPATHS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.full_file_paths";
    public static final String FULL_FILEPATH = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.full_file_path";
    public static final String METADATA_STRINGS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.metadata_strings";
    public static final String DELETE_METADATA = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.delete_metadata";
    public static final String AREA_PATH_ONLY = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.area_path_only";
    public static final String METADATA_TYPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.metadata_type";

    /** arguments to verify updates from foreign stream */
    public static final String HOME_STREAM_UID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.home_stream_uid";
    public static final String FOREIGN_STREAM_UID = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.foreign_stream_uid";
    public static final String LOCAL_ITEM_UIDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.local_item_uids";
    public static final String LOCAL_ITEM_PATHS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.local_item_paths";
    public static final String FOREIGN_ITEM_UIDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.foreign_item_uids";
    public static final String FOREIGN_ITEM_PATHS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.foreign_item_paths";
    public static final String FOREIGN_ITEM_CHANGES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.foreign_item_changes";
    public static final String LOCAL_DIR_PATHS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.local_directory_paths";
    public static final String FOREIGN_DIR_PATHS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.foreign_directory_paths";
    public static final String FOREIGN_DIR_CHANGES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.foreign_directory_changes";

    /** Deployment **/
    /** whether to return Pending/Archive, History/Rollback data **/
    public static final String DEPLOYMENT_DATA_REQUESTED_MODE = Constants.NON_USER_DEF_ATTR_CHAR
            + "CmdArguments.deployment_data_requested_mode";

    public static final String DEPLOY_AREAS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.deploy_areas";

    public static final String DEPLOY_RPC_FLAG = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.deploy_rpc_flag";

    /** Ranged data support **/
    public static final String DATA_RANGE_INFO = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.data_range_info";

    /** Build Impacted Targets switches **/
    public static final String SHOW_TARGETS_CONFIG = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.show_targets_config";
    public static final String SHOW_TARGETS_FINAL = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.show_targets_final";
    public static final String SHOW_TARGETS_FOREIGN = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.show_targets_foreign";
    public static final String SHOW_TARGETS_SIDE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.show_targets_side";
    public static final String SHOW_TARGETS_SOFT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.show_targets_soft";

    public static final String PROJECT_UIDS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.project_uids";
    public static final String PROJECT_LIST = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.project_list";
    /** Deploy by default flag on workset area assignment */
    public static final String WS_AREA_DEPLOY_BY_DEFAULT = Constants.NON_USER_DEF_ATTR_CHAR
            + "CmdArguments.workset_area_deploy_by_default";
    /** Deploy by default flag on workset area assignment */
    public static final String NO_DEPLOY_PRIVILEGE_TO_AREA = Constants.NON_USER_DEF_ATTR_CHAR
            + "CmdArguments.no_deploy_privilege_to_area";
    public static final String COPY_BUILD_CONFIGURATION = Constants.NON_USER_DEF_ATTR_CHAR
            + "CmdArguments.copy_build_configuration";
    public static final String USE_CACHE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.use_cache";

    public static final String IS_FOREIGN_BASELINE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.is_foreign_baseline";
    public static final String BASELINE_DIFF_SCOPE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.baseline_diff_scope";;

    /** DML additional arguments **/
    public static final String CONFIG_FILE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.config_file";
    public static final String CONFIG_ITEM = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.config_item";
    public static final String FLAG_NUMBERS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.flag_numbers";
    public static final String FLAG_VALUES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.flag_values";
    public static final String DML = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.dml";
    public static final String DRY_RUN = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.dry_run";

    public static final String AUTOMERGE = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.auto_merge"; // Boolean
    public static final String UNDO = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.undo"; // Boolean

    public static final String EXPLICIT_LOG_FOLDER = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.explicit_log_folder";

    public static final String SYMBOL = "symbol";

    public static final String SDA_DEPLOY_COMPONENT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.sda_deploy_component";
    public static final String SDA_PROCESS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.sda_process";
    public static final String SDA_COMPONENTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.sda_components";
    public static final String REQUEST_NAMES = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.request_names";

    public static final String FAVORITE_REPORTS = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.favorite_reports";
    public static final String ACTIVE_FAVORITE_UUID_REPORT = Constants.NON_USER_DEF_ATTR_CHAR + "CmdArguments.active_favorite_uuid_report";
}

/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2001 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package merant.adm.dimensions.cmds.interfaces;

/**
 * Methodless interface for assignable commands.
 * <p>
 * This applies to any dimensions object that can be assigned(delegated) to a dimensions user.
 * @author Floz
 */
public interface Assignable {
    static final String ASSIGN = "Assignable.Assign";
    static final String DEASSIGN = "Assignable.Deassign";

    static final String REGISTER_TOOL_MANAGER = "Assignable.RegisterToolManager";
    static final String PROMOTE_PROXY_USER = "Assignable.PromoteProxyUser";

    static final String REQUEST_OWNERSHIP = "Assignable.RequestOwnership";
    static final String LOCK_OWNERSHIP = "Assignable.LockOwnership";

    static final String ASSIGN_USERS_TO_GROUP = "Assignable.AssignUsersToGroup";
    static final String ASSIGN_GROUPS_TO_USER = "Assignable.AssignGroupsToUser";

    static final String SUBSCRIBE_GROUPS_TO_MAILNOTIF = "Assignable.SubscribeGroupsToMailNotif";
    static final String SUBSCRIBE_USERS_TO_MAILNOTIF = "Assignable.SubscribeUsersToMailNotif";

    static final String ASSIGN_PRIVILEGE_RULE = "Assignable.AssignPrivilegeRule";

    static final String ASSIGN_PROFILE_DEFINITION = "Assignable.AssignProfileDefinition";

    static final String MOVE_SECREQUEST_TO_MAIN_CATALOG = "Assignable.MoveSecRequestToMainCatalog";
    static final String MOVE_REQUEST_TO_SEC_CATALOG = "Assignable.MoveRequestToSecCatalog";

    static final String HIDE_PROMOTION = "Assignable.HidePromotion";

    static final String DLGS = "Assignable.DLGS";

    static final String ASSIGN_USERS_TO_WORKSET = "Assignable.AssignUsersToWorkset";
    static final String GET_ASSIGNED_USERS_TO_WORKSET = "Assignable.GetAssignedUsersToWorkset";
    static final String REPLACE_ASSIGNED_USERS_TO_WORKSET = "Assignable.ReplaceAssignedUsersToWorkset";
    static final String DELETE_ASSIGNED_USERS_TO_WORKSET = "Assignable.DeleteAssignedUsersToWorkset";

    static final String ASSIGN_PRODUCTS_TO_REQUEST_PROVIDER = "Assignable.AssignProductsToRequestProvider";
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttributeException;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.ItemRelationshipType;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Item Relationship Type object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteItemRelTypeCmd extends RPCExecCmd {
    public DeleteItemRelTypeCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ItemRelationshipType)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        String relName = AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.RELNAME_NAME).toString();

        List attrs = AdmHelperCmd.getAttributeValues(admObj,
                Arrays.asList(new String[] { AdmAttrNames.RELTYPE_TYPE_OBJ, AdmAttrNames.RELTYPE_SUB_TYPE_OBJ }));

        if (attrs == null || attrs.size() == 0) {
            throw new DimBaseCmdException("Error: failed to query item types for which the relationship type is defined.");
        }

        AdmObject parentTypeObj = (AdmObject) attrs.get(0);
        AdmObject childTypeObj = (AdmObject) attrs.get(1);

        List attrNames = Arrays.asList(new String[] { AdmAttrNames.PRODUCT_NAME, AdmAttrNames.ID, AdmAttrNames.PARENT_CLASS });
        List attrs1 = AdmHelperCmd.getAttributeValues(parentTypeObj, attrNames);
        List attrs2 = AdmHelperCmd.getAttributeValues(childTypeObj, attrNames);

        if (attrs1 == null || attrs1.size() != 3) {
            throw new DimBaseCmdException("Failed to query attributes of parent request type.");
        }
        if (attrs2 == null || attrs2.size() != 3) {
            throw new DimBaseCmdException("Failed to query attributes of child object type.");
        }

        String parentProductId = (String) attrs1.get(0);
        String parentTypeId = ((String) attrs1.get(1)).trim().toUpperCase();
        Class parentTypeClass = (Class) attrs1.get(2);

        String childProductId = (String) attrs2.get(0);
        String childTypeId = ((String) attrs2.get(1)).trim().toUpperCase();
        Class childTypeClass = (Class) attrs2.get(2);

        // Construct command
        StringBuffer cmdBuf = new StringBuffer("OBJTYPE /DELETE_RELATIONSHIP ");
        cmdBuf.append(Encoding.escapeDMCLI(parentTypeId));
        cmdBuf.append(" /PRODUCT=").append(Encoding.escapeDMCLI(parentProductId));
            cmdBuf.append(" /OBJ_CLASS=ITEM");
        cmdBuf.append(" /REL_PRODUCT=").append(Encoding.escapeDMCLI(childProductId));
        cmdBuf.append(" /REL_TYPE_NAME=").append(Encoding.escapeDMCLI(childTypeId));

        if (childTypeClass.equals(Item.class)) {
            cmdBuf.append(" /REL_OBJ_CLASS=ITEM");
        } else {
            throw new DimInvalidAttributeException("Error: type " + childProductId + ":" + childTypeId + " is not an item type.");
        }

        cmdBuf.append(" /REL_NAME=").append(Encoding.escapeDMCLI(relName));

        _cmdStr = cmdBuf.toString();

        AdmResult retResult = new AdmResult(executeRpc());
        return retResult;
    }
}
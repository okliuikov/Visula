/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001-2004 Merant. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import java.io.IOException;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.system.SessionBean;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will login to the Dimensions server.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>USER_NAME {String}</dt><dd>The Operating System user name</dd>
 *  <dt>USER_PASSWORD {String}</dt><dd>The Operating System user password</dd>
 *  <dt>USER_DB_NAME {String}</dt><dd>The user database name</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>USER_DB_PASSWORD {String}</dt><dd>The password for the user database account</dd>
 *  <dt>SESSION_BEAN {SessionBean}</dt><dd>The instance of the current session</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{void}</dt>
 * </dl></code>
 * @author Floz
 */
public class LoginCmd extends AdmCmd {
    public LoginCmd() throws AttrException {
        super();
        setAlias(Server.LOGIN);
        setAttrDef(new CmdArgDef(CmdArguments.USER_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_PASSWORD, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_DB_NAME, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_DB_PASSWORD, false, "", String.class));
        setAttrDef(new CmdArgDef(CmdArguments.HOSTNAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.DATASOURCE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.CLIENTNODE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.LICENSETYPES, false, int[].class));
        setAttrDef(new CmdArgDef(CmdArguments.APPNAME, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.SESSION_BEAN, false, SessionBean.class));
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        String userID = (String) getAttrValue(CmdArguments.USER_NAME);
        String password = (String) getAttrValue(CmdArguments.USER_PASSWORD);
        String databaseName = (String) getAttrValue(CmdArguments.USER_DB_NAME);
        String hostname = (String) getAttrValue(CmdArguments.HOSTNAME);
        String datasourceAlias = (String) getAttrValue(CmdArguments.DATASOURCE);
        int[] licenseTypes = (int[]) getAttrValue(CmdArguments.LICENSETYPES);
        String clientNode = (String) getAttrValue(CmdArguments.CLIENTNODE);
        String appName = (String) getAttrValue(CmdArguments.APPNAME);

        SessionBean sessionBean = (SessionBean) getAttrValue(CmdArguments.SESSION_BEAN);
        if (sessionBean == null) {
            sessionBean = (SessionBean) DimSystem.getSystem().getSession();
        }

        try {
            sessionBean.logIn(userID, password, hostname, databaseName, datasourceAlias, clientNode, null, licenseTypes, appName);
        } catch (IOException ioException) {
            throw new AdmException(ioException);
        }

        return null;
    }
}

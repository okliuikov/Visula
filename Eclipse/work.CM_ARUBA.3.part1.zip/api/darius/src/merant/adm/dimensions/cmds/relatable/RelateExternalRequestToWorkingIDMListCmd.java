/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2001 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional
 *  warranty. Micro Focus shall not be liable for technical or editorial errors or omissions contained
 *  herein. The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information
 *  and a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 *  Computer Software Documentation, and Technical Data for Commercial Items are licensed
 *  to the U.S. Government under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package merant.adm.dimensions.cmds.relatable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.AdmResult;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.helper.DoesExistHelper;
import merant.adm.dimensions.cmds.helper.IDMUtilsHelper;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DBIOException;
import merant.adm.dimensions.exception.DimAlreadyExistsException;
import merant.adm.dimensions.exception.DimBaseException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.exception.DimNotExistsException;
import merant.adm.dimensions.objects.ExternalRequest;
import merant.adm.dimensions.objects.RequestProvider;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkingIDMList;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.dbio.DBIOTransactionManager;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This helper command will relate/unrelate requests to/from a IDM activated request list.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_PARENT_OBJECT {IDMActivatedList}<dt><dd>IDMActivatedList object</dd>
 *  <dt>ADM_OBJECT_LIST {ExternalRequest/List}<dt><dd>List of External Request objects for the assignment</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>REMOVE {Boolean}<dt>
 *  <dd>
 *      If true, unrelates the existing specified relationship<br>
 *      For convenience nested in the Unrelate command
 *  </dd>
 *  <dt>PRODUCT_UID {Long}<dt><dd>Current product UID, if not set Constants.INVALID_UID will be using</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{AdmResult}<dt><dd>Contains Relationship as the user data or null if failed</dd>
 * </dl></code>
 * @author Stephen Sitton
 */
public class RelateExternalRequestToWorkingIDMListCmd extends DBIOCmd {
    public RelateExternalRequestToWorkingIDMListCmd() throws AttrException {
        super();
        setAlias("RelateExternalRequestToWorkingIDMListCmd");
        setAttrDef(new CmdArgDef(CmdArguments.ADM_PARENT_OBJECT, true, WorkingIDMList.class));
        setAttrDef(new CmdArgDef(CmdArguments.PARENT_UID, true, Long.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_LIST, true, List.class));
        setAttrDef(new CmdArgDef(CmdArguments.REMOVE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.PRODUCT_UID, false, Long.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);

        if (name.equals(CmdArguments.ADM_PARENT_OBJECT)) {
            if (!(attrValue instanceof WorkingIDMList)) {
                throw new AttrException("Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    protected void handleExistsInList(String requestSpec, AdmObject admObj) throws DimAlreadyExistsException, AdmObjectException {
        throw new DimAlreadyExistsException("\nWarning: Request \"" + requestSpec
                    + "\" already exists in activated request list \"" + admObj.getAdmSpec().getSpec() + "\".");
    }

    @Override
    public Object execute() throws DBIOException, DimBaseException, AdmException {

        validateAllAttrs();

        // Dimensions request list
        final AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_PARENT_OBJECT);
        // Dimensions requests
        final List requests = (List) getAttrValue(CmdArguments.ADM_OBJECT_LIST);
        final boolean bUnrelate = ((Boolean) getAttrValue(CmdArguments.REMOVE)).booleanValue();
        final long toolUid = getAttrValue(CmdArguments.PARENT_UID) != null
                ? (long) getAttrValue(CmdArguments.PARENT_UID)
                : Constants.INVALID_UID;  

        long productUid;
        if(getAttrValue(CmdArguments.PRODUCT_UID) != null) {
            productUid = (long) getAttrValue(CmdArguments.PRODUCT_UID);
        } else {
            productUid = Constants.INVALID_UID;
        }

        List attrs = AdmHelperCmd.getAttributeValues(admObj,
                Arrays.asList(new Object[] { AdmAttrNames.USER_NAME, AdmAttrNames.ID }));

        final String userName = (String) attrs.get(0);
        final String id = (String) attrs.get(1);

        AdmObject curUserObj = AdmCmd.getCurRootObj(User.class);
        if (curUserObj != null) {
            String curUserId = curUserObj.getAdmSpec().getSpec();
            if (!curUserId.equals(userName)) {
                // Ensure that we have the privilege to do this
                if (!CmdUtils.hasCurrUserAdminPrivilege("ADMIN_CHANGEMAN")) {
                    throw new DimNoPrivilegeException("ADMIN_CHANGEMAN");
                }
            }
        }

        StringBuffer warnings = new StringBuffer();
        List result = new ArrayList();
        final long userListUid = ((AdmUidObject) admObj).getUid();
        for (int i = 0; i < requests.size(); i++) {
            AdmObject request = (AdmObject) requests.get(i);
            if (request != null && request instanceof ExternalRequest) {
                final String requestSpec = request.getAdmSpec().getSpec();
                final String requestInternalId = request.getId();
                final String title = (String) request.getAttrValue(AdmAttrNames.DESCRIPTION);
                final String report_uuid = (String) request.getAttrValue(AdmAttrNames.REPORT_UID);
                final String item_url = (String) request.getAttrValue(AdmAttrNames.ITEM_LOC);
                try {

                    long reqUid = Constants.INVALID_UID;
                    boolean isExists = IDMUtilsHelper.verifySingleRequests(requestSpec, productUid, toolUid);
                    if (!isExists) {
                        if (bUnrelate) {
                            throw new DimNotExistsException("Request \"" + requestSpec
                                    + "\" does not exist in database yet. Unrelate operation has been ignored.");
                        }

                        reqUid = IDMUtilsHelper.processRequest(requestSpec, productUid, toolUid);
                        if (reqUid == Constants.INVALID_UID) {
                            throw new DBIOException("Failed to add external request \"" + requestSpec + "\" ");
                        }
                    } else {
                        reqUid = ((AdmUidObject) request).getUid();
                    }

                    if (bUnrelate) // Check the request is in the request list...
                    {
                        if (!DoesExistHelper.userListContainChangeDocumentExists(userListUid, reqUid)) {
                            throw new DimNotExistsException("Request \"" + requestSpec
                                    + "\" does not exist in activated request list \"" + admObj.getAdmSpec().getSpec() + "\".");
                        }
                    } else {
                        // Check if the request exists in the request list...
                        if (DoesExistHelper.userListContainChangeDocumentExists(userListUid, reqUid)) {
                            handleExistsInList(requestSpec, admObj);
                        }
                    }

                    final long requestUid = reqUid;
                    new DBIOTransactionManager().execute(new DBIOTransactionManager.DBIOTransaction() {
                        @Override
                        public void execute(DBIO dbCtx) throws Exception {

                            if (!bUnrelate) {

                                long rel_uid = 0;
                                dbCtx.resetMessage(wcm_sql.GET_NEW_UID);
                                dbCtx.readStart();
                                if (dbCtx.read(DBIO.DB_DONT_CLOSE)) {
                                    rel_uid = dbCtx.getLong(1);
                                }
                                dbCtx.close(DBIO.DB_DONT_RELEASE);

                                dbCtx.resetMessage(wcm_sql.ADD_TO_WORKING_IDM_LIST_WEB);
                                dbCtx.bindInput(rel_uid);
                                dbCtx.bindInput(userListUid);
                                dbCtx.bindInput(requestUid);
                                dbCtx.bindInput(userName);
                                int affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                                dbCtx.close(DBIO.DB_DONT_RELEASE);

                                if (affected != 1) {
                                    throw new DBIOException("Failed to add request \"" + requestSpec + "\" to request list \""
                                            + userName + ":" + id + "\".");
                                }

                                dbCtx.resetMessage(wcm_sql.ADD_TO_WORKING_IDM_LIST_ATTRS_WEB);
                                dbCtx.bindInput(rel_uid);
                                dbCtx.bindInput(title);
                                dbCtx.bindInput(report_uuid);
                                dbCtx.bindInput(item_url);
                                affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                                dbCtx.close(DBIO.DB_DONT_RELEASE);

                                if (affected != 1) {
                                    throw new DBIOException("Failed to save attributes of request \"" + requestSpec + "\" ");
                                }

                            } else {
                                dbCtx.resetMessage(wcm_sql.REMOVE_FROM_WORKING_IDM_LIST_ATTRS);
                                dbCtx.bindInput(id);
                                dbCtx.bindInput(userName);
                                dbCtx.bindInput(requestUid);
                                dbCtx.write(DBIO.DB_DONT_COMMIT);
                                dbCtx.close(DBIO.DB_DONT_RELEASE);

                                dbCtx.resetMessage(wcm_sql.REMOVE_FROM_WORKING_IDM_LIST_WEB);
                                dbCtx.bindInput(id);
                                dbCtx.bindInput(userName);
                                dbCtx.bindInput(requestUid);
                                int affected = dbCtx.write(DBIO.DB_DONT_COMMIT);
                                dbCtx.close(DBIO.DB_DONT_RELEASE);

                                if (affected != 1) {
                                    throw new DBIOException("Failed to remove request \"" + requestSpec + "\" from request list \""
                                            + userName + ":" + id + "\".");
                                }
                            }
                        }
                    });
                } catch (DimNotExistsException e) {
                    warnings.append(e.getMessage());
                } catch (DimAlreadyExistsException e) {
                    warnings.append(e.getMessage());
                }
                result.add(requestSpec);
            }
        }
        warnings.insert(0, "Operation completed ");
        return new AdmResult(warnings.toString(), result);
    }
}

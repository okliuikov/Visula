/*
 * Copyright (C) 2010, Serena Software Europe, Ltd.
 * All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 */
package merant.adm.dimensions.cmds.deletable;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.MultiView;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.SqlUtils;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

public class DeleteMultiViewCmd extends RPCExecCmd {

    public DeleteMultiViewCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof MultiView)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        long uid = ((AdmUidObject) admObj).getAdmUid().getUid();

        // Check if user has permissions to delete a public multi-view report
        Boolean isPublic = (Boolean) AdmHelperCmd.getAttributeValue(admObj, AdmAttrNames.IS_PUBLIC);
        if (isPublic.booleanValue() && !CmdUtils.hasCurrUserAdminPrivilege("ADMIN_PUBLICQUERIES")) {
            throw new DimNoPrivilegeException("ADMIN_PUBLICQUERIES");
        }

        // delete from users_queries table
        DBIO query = new DBIO(wcm_sql.MVIEW_DELETE);
        query.bindInput(uid);
        query.write();
        query.commit();
        query.close();

        // delete any PersistentReport relationships
        query = SqlUtils.sysobjRelsDeleteParent(uid, Constants.RELCLASS_MVIEW_TO_PREPORT);

        query.write();
        query.commit();
        query.close();

        return "Operation completed successfully";
    }
}

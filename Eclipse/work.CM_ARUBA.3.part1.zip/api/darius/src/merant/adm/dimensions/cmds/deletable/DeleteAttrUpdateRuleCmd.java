/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2002 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.deletable;

import java.util.Arrays;
import java.util.List;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.DBIOCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Deletable;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.exception.DimInvalidAttrRuleException;
import merant.adm.dimensions.exception.DimNoPrivilegeException;
import merant.adm.dimensions.objects.AttributeUpdateRule;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.dbio.DBIO;
import merant.adm.dimensions.server.message.wcm_sql;
import merant.adm.dimensions.util.Debug;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will delete a Dimensions Attribute Update Rule object.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object to be deleted</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Vadym Krevs
 */
public class DeleteAttrUpdateRuleCmd extends DBIOCmd {
    public DeleteAttrUpdateRuleCmd() throws AttrException {
        super();
        setAlias(Deletable.DELETE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof AttributeUpdateRule)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);

        List attrs = AdmHelperCmd.getAttributeValues(
                admObj,
                Arrays.asList(new Object[] { AdmAttrNames.ATTRRULE_OBJECT_UID, AdmAttrNames.ATTRRULE_ROLE_NAME,
                        AdmAttrNames.ATTRRULE_ATTRNO, AdmAttrNames.ATTRRULE_CURRENT_STATUS, AdmAttrNames.ATTRRULE_NEW_STATUS,
                        AdmAttrNames.ATTRRULE_IS_DISPLAYABLE, AdmAttrNames.ATTRRULE_IS_MANDATORY,
                        AdmAttrNames.ATTRRULE_IS_UPDATABLE }));

        long ruleUid = ((Long) attrs.get(0)).longValue();
        String roleName = (String) attrs.get(1);
        int attrNo = ((Integer) attrs.get(2)).intValue();
        String curStatus = (String) attrs.get(3);
        String newStatus = (String) attrs.get(4);
        Boolean o = (Boolean) attrs.get(5);
        boolean isDisplayable = (o != null ? o.booleanValue() : false);
        o = (Boolean) attrs.get(6);
        boolean isMandatory = (o != null ? o.booleanValue() : false);
        o = (Boolean) attrs.get(7);
        boolean isUpdateable = (o != null ? o.booleanValue() : false);

        // get details of the object type related to this rule
        long typeUid = -1;
        String productName = null;
        String typeName = null;
        String typeFlag = null;
        DBIO q = new DBIO(wcm_sql.ATTRRULE_QUERY_RELATED_TYPE);
        q.bindInput(ruleUid);
        q.readStart();
        if (q.read()) {
            typeUid = q.getLong(1);
            productName = q.getString(2);
            typeName = q.getString(3);
            typeFlag = q.getString(4);
        }
        q.close();
        if (typeUid == -1 || productName == null) {
            throw new DimInvalidAttrRuleException("Error: cannot find the object type for this attribute update rule.");
        }

        // Ensure that we have the privilege to do this
        if (!CmdUtils.hasCurrUserApplicationPrivilege("PRODUCT_OBJTYPEMAN", productName)) {
            throw new DimNoPrivilegeException("PRODUCT_OBJTYPEMAN", productName);
        }

        DBIO query = null;
        boolean doCommit = true;
        try {
            query = new DBIO(false);

            // delete the rule from cpl_attributes

            query.resetMessage(wcm_sql.ATTRRULE_DELETE_ONE_RULE_DETAILS);
            query.bindInput(ruleUid);
            query.bindInput(attrNo);
            query.bindInput(roleName);
            query.bindInput(curStatus != null ? curStatus : "$$$&&&");
            query.bindInput(isMandatory ? "Y" : "N");
            query.bindInput(isUpdateable ? "Y" : "N");
            query.bindInput(isDisplayable ? "Y" : "N");
            query.bindInput(newStatus != null ? newStatus : "$$$&&&");
            query.write(DBIO.DB_DONT_COMMIT);
            query.close(DBIO.DB_DONT_RELEASE);

            if ("P".equals(typeFlag) && Constants.GLOBAL_PRODUCT.equals(productName) && "PRODUCT".equals(typeName)) {
                // a quote from Oracle Form Code :"blow them away" - how poetic
                query.resetMessage(wcm_sql.ATTRRULE_DELETE_PRODUCT_LEVEL_RULES);
                query.bindInput(attrNo);
                query.bindInput(roleName);
                query.bindInput(curStatus != null ? curStatus : "$$$&&&");
                query.bindInput(isMandatory ? "Y" : "N");
                query.bindInput(isUpdateable ? "Y" : "N");
                query.bindInput(isDisplayable ? "Y" : "N");
                query.bindInput(newStatus != null ? newStatus : "$$$&&&");
                query.write(DBIO.DB_DONT_COMMIT);
                query.close(DBIO.DB_DONT_RELEASE);
            }

        } catch (Exception e) {
            if (query != null) {
                try {
                    query.rollback();
                } catch (Exception ex) {
                    Debug.error(ex);
                }
                doCommit = false;
            }
            Debug.error(e);
            throw new AdmException(e);
        } finally {
            if (query != null && doCommit) {
                try {
                    query.commit();
                } catch (Exception ex) {
                    Debug.error(ex);
                    throw new DimBaseCmdException(ex.toString());
                }
            }
        }

        return "Operation Completed";
    }
}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.helper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.serena.dmnet.LCNetClnt;
import com.serena.dmnet.drs.DRSClientChangeSet;
import com.serena.dmnet.drs.DRSClientChangeSet.ChangeSetQueryContext;
import com.serena.dmnet.drs.DRSClientChangeStep;
import com.serena.dmnet.drs.DRSClientGetDatabaseId;
import com.serena.dmnet.drs.DRSClientQueryUsersWithRolesFromChangesets;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.ChangeSet;
import merant.adm.dimensions.server.drs.objects.ChangeSetFilterDataHolder;
import merant.adm.dimensions.server.drs.objects.ChangeSetOrbiterStatus;
import merant.adm.dimensions.server.drs.objects.ChangeStep;
import merant.adm.dimensions.server.drs.objects.DatabaseId;
import merant.adm.dimensions.server.drs.objects.TreeVersion;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.DateUtils;
import merant.adm.dimensions.util.SpecUtils;
import merant.adm.dimensions.util.StringUtils;
import merant.adm.exception.AdmException;
import merant.adm.session.Session;

public class ChangeSetsHelper {
    private static final String REPOSITORY_ID_PATTERN = "scm:dimensions:id:{0}@{1}";

	public static List<ChangeSet> queryChangeSets(long worksetUid, String worksetSpec, ChangeSetFilterDataHolder filter,
            boolean includePropertyChangeSets) throws AdmException {
		return queryChangeSets(worksetUid, worksetSpec, filter, includePropertyChangeSets, 0);
	}

    public static List<ChangeSet> queryChangeSets(long worksetUid, String worksetSpec, ChangeSetFilterDataHolder filter,
            boolean includePropertyChangeSets, int flags) throws AdmException {

        if (null == worksetSpec) {
            AdmBaseId baseId = AdmCmd.newAdmBaseId(worksetUid, WorkSet.class);
            List<String> attrs = new ArrayList<String>(1);
            attrs.add(AdmAttrNames.ADM_SPEC);
            AdmObject admObject = AdmCmd.getObject(baseId, attrs);
            worksetSpec = admObject.getAdmSpec().getSpec();
        }

        List<ChangeSet> result = new ArrayList<ChangeSet>();

        DRSClientChangeSet drs = new DRSClientChangeSet(ChangeSetQueryContext.QueryChangeSetsUids);
        drs.setWorksetUid((int) worksetUid);

        if (filter != null) {
            if (filter.isDirectoryFilterEnabled()) {
                drs.setDirName(filter.getDirName());
            }

            if (filter.isColumnFilterEnabled()) {
                drs.setFilterColumn(filter.getFilterByColumn());
                drs.setFilter(filter.getFilterByValue());
            }

            if (filter.isFromDateFilterEnabled()) {
                drs.setFromDate(filter.getFromDate());
            }

            if (filter.isToDateFilterEnabled()) {
                drs.setToDate(filter.getToDate());
            }

            if (filter.isItemSpecFilterEnabled()) {
                drs.setItemSpec(filter.getItemSpec());
            } else if (filter.isItemUidFilterEnabled()) {
                drs.setItemUid(filter.getItemUid());
            }

            if (filter.isDirUidFilterEnabled()) {
                drs.setDirUid(filter.getDirUid());
            }
        }

        drs.setIncludeProperties(includePropertyChangeSets);
		drs.setFlags(flags);

        DRSUtils.execute(drs);

        if (drs.hasData() && drs.getCount() != 0) {
            int[] uids = drs.getChangeSetUids();
            int[] treeVersions = drs.getTreeVersions();
            int[] forestVersions = drs.getForestVersions();
            int[] uidsReduced = drs.getUidsReduced();

            Set<Integer> uidsReducedSet = new HashSet<Integer>();
            if (uidsReduced != null) {
                for (int i : uidsReduced) {
                    uidsReducedSet.add(i);
                }
            }
            for (int i = 0; i < uids.length; i++) {
                TreeVersion tv = new TreeVersion();
                tv.setForestVersion(forestVersions[i]);
                tv.setChangeSetUid(uids[i]);
                tv.setTreeUid((int) worksetUid);
                tv.setTreeVersion(treeVersions[i]);
                tv.setTreeClass(Constants.WORKSET_CLASS);
                tv.setTreeSpec(worksetSpec);

                ChangeSet cs = new ChangeSet();
                cs.setUid(uids[i]);
                cs.setReduced(uidsReducedSet.contains(uids[i]));
                cs.setTreeVersion(tv);

                result.add(cs);
            }
        }

        return result;
    }

    public static List<ChangeSet> queryChangeSets(long worksetUid, String worksetSpec, ChangeSetFilterDataHolder filter)
            throws AdmException {
        return queryChangeSets(worksetUid, worksetSpec, filter, false);
    }

    public static void queryChangeSetsDetails(List<ChangeSet> csl) throws AdmException {
        DRSClientChangeSet drs = new DRSClientChangeSet(ChangeSetQueryContext.QueryChangeSetsInfo);
        LCNetClnt conn = DRSUtils.getLCNetClntObject();

        if (csl != null && csl.size() > 0) {
            int[] uids = new int[csl.size()];
            ChangeSet[] csarray = csl.toArray(new ChangeSet[csl.size()]);
            for (int i = 0; i < csarray.length; i++) {
                uids[i] = (int) csarray[i].getUid();
            }
            drs.setChangeSetUids(uids);
            drs.setWorksetUid(csarray[0].getTreeVersion().getTreeUid());
            DRSUtils.execute(drs);

            if (drs.hasData()) {
                int[] ops = drs.getOps();
                int[] sourceObjClasses = drs.getSourceObjClasses();
                String[] users = drs.getUsers();
                String[] comments = drs.getComments();
                String[] dates = drs.getDates();
                String[] requestIds = drs.getRequestIds();
                String[] toolUids = drs.getToolUids();
                String[] requestUids = drs.getRequestUids();
                String[] requestInternalIds = drs.getRequestInternalIds();
                String[] sourceWsets = drs.getSourceWsets();
                String[] scopePaths = drs.getScopePaths();
                String[] sourceRequests = drs.getSourceRequests();

                for (int i = 0; i < csarray.length; i++) {
                    if (!StringUtils.isBlank(dates[i])) {
                        try {
                            csarray[i].setDate(DateUtils.parseDate(dates[i], DateUtils.DATE_PATTERN_3));
                            csarray[i].setDateTZ(DateUtils.parseDate(dates[i], DateUtils.DATE_PATTERN_3, conn.getRemotePeerTimeZone()));
                        } catch (ParseException e) {
                            throw new AdmException(e);
                        }
                    } else {
                        // Change sets with empty date have come back for tree version [0].
                        csarray[i].setDate(null);
                    }

                    // DRS has misleading names: internal ids -> ids, ids -> specs
                    // Check for nulls, in order to use Java API 14.5.1 with Server 14.5.0
                    if (toolUids != null) {
                        csarray[i].setToolUids(parseCommaListLongs(toolUids[i]));
                    }
                    if (requestUids != null) {
                        csarray[i].setRequestUids(parseCommaListLongs(requestUids[i]));
                    }
                    if (requestInternalIds != null) {
                        csarray[i].setRequestIds(parseCommaList(requestInternalIds[i]));
                    }
                    csarray[i].setRequestSpecs(parseCommaList(requestIds[i]));

                    if (comments != null) {
                        csarray[i].setComment(comments[i]);
                    }
                    if (users != null) {
                        csarray[i].setUser(users[i]);
                    }
                    if (ops != null) {
                        csarray[i].setOperationType(ops[i]);
                    }
                    if (sourceWsets != null) {
                        csarray[i].setSourceWsets(sourceWsets[i]);
                    }
                    if (scopePaths != null) {
                        csarray[i].setScopePaths(scopePaths[i]);
                    }
                    if (sourceObjClasses != null) {
                        csarray[i].setSourceObjClass(sourceObjClasses[i]);
                    }
                    if (sourceRequests != null) {
                        csarray[i].setSourceRequests(sourceRequests[i]);
                    }
                }
            }
        }
    }

    static List<String> parseCommaList(final String commaList) {
        final List<String> parsedList = new ArrayList<String>();
        if (!StringUtils.isBlank(commaList)) {
            final String[] elements = commaList.split(",");
            for (final String element : elements) {
                parsedList.add(element.trim());
            }
        }
        return parsedList;
    }

    static List<Long> parseCommaListLongs(final String commaList) {
	    final List<Long> result = new ArrayList<Long>();
        final List<String> elements = parseCommaList(commaList);
        for (final String element : elements) {
            result.add(Long.parseLong(element));
        }
        return result;
    }

    public static void queryChangeSteps(List<ChangeSet> changeSets, ChangeSetFilterDataHolder filter,
            boolean includePropertyChangeSets, int options) throws AdmException {

    	if (changeSets == null) {
            throw new AdmException("ChangeSet list is null");
        } else if (changeSets.isEmpty()) {
        	return;
        }
    	          
        long[] uids = new long[changeSets.size()];
    	Map<Long,ChangeSet> map = new HashMap<Long, ChangeSet>();
    	int idx = 0;
    	for(ChangeSet cs: changeSets) {
    		cs.setChangeSteps(null); // clear current change set steps if any
    		map.put(cs.getUid(), cs);
    		uids[idx++] = cs.getUid();
    	}    	       

        DRSClientChangeStep drs = new DRSClientChangeStep();
        drs.setChangeSetUids(uids);

        if (filter != null) {
            if (filter.isDirectoryFilterEnabled()) {
                drs.setDirName(filter.getDirName());
            }

            if (filter.isColumnFilterEnabled()) {
                drs.setFilterColumn(filter.getFilterByColumn());
                drs.setFilter(filter.getFilterByValue());
            }

            if (filter.isFromDateFilterEnabled()) {
                drs.setFromDate(filter.getFromDate());
            }

            if (filter.isToDateFilterEnabled()) {
                drs.setToDate(filter.getToDate());
            }
        }
		
        if (options>0) {
            drs.setOptions(options);
        }

        drs.setIncludeProperties(includePropertyChangeSets);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
        	int[] changeSetUids = drs.getPerStepChangeSetUids();
            int[] types = drs.getTypes();
            int[] objUids = drs.getObjUids();

            String[] paths = drs.getPaths();
            String[] revisions = drs.getRevisions();
            String[] requestIds = drs.getRequestIds();

			if ((changeSetUids == null || changeSetUids.length == 0) && changeSets.size() == 1) {
				// DRS_QUERY_CHANGE_STEPS = 188 doesn't return changesetUids, if was invoked with one changesetUid
				// don't remove until DEF320665  is fixed
				changeSetUids = new int[objUids.length];
				Arrays.fill(changeSetUids, (int) changeSets.get(0).getUid());
			}

            for (int i = 0; i < objUids.length; i++) {
            	ChangeSet cs = map.get((long)changeSetUids[i]);
            	if (cs == null) {
            		throw new AdmException("Unexpected change set uid = " + changeSetUids[i]);
            	}
            	
                ChangeStep csp = new ChangeStep();
                csp.setType(types[i]);
                csp.setObjUid(objUids[i]);
                csp.setProjectPath(paths[i]);
                csp.setRevision(revisions[i]);

                csp.setRequestIds(new ArrayList<String>());
                if (requestIds[i].contains(",")) {
                    String[] requests = requestIds[i].split(",");

                    for (int j = 0; j < requests.length; j++) {
                        if (!StringUtils.isBlank(requests[j])) {
                            csp.getRequestIds().add(requests[j]);
                        }
                    }
                } else {
                    if (!StringUtils.isBlank(requestIds[i])) {
                        csp.setRequestIds(Arrays.asList(requestIds[i]));
                    }
                }

                csp.setChangeSet(cs);
                cs.addChangeStep(csp);
            }
        }
    }
    
    public static List<ChangeStep> queryChangeSteps(ChangeSet cs, ChangeSetFilterDataHolder filter,
            boolean includePropertyChangeSets) throws AdmException {
        if (cs == null) {
            throw new AdmException("ChangeSet object is null");
        }

        List<ChangeStep> result = new ArrayList<ChangeStep>();

        DRSClientChangeStep drs = new DRSClientChangeStep();
        drs.setChangeSetUid(cs.getUid());

        if (filter != null) {
            if (filter.isDirectoryFilterEnabled()) {
                drs.setDirName(filter.getDirName());
            }

            if (filter.isColumnFilterEnabled()) {
                drs.setFilterColumn(filter.getFilterByColumn());
                drs.setFilter(filter.getFilterByValue());
            }

            if (filter.isFromDateFilterEnabled()) {
                drs.setFromDate(filter.getFromDate());
            }

            if (filter.isToDateFilterEnabled()) {
                drs.setToDate(filter.getToDate());
            }
        }

        drs.setIncludeProperties(includePropertyChangeSets);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] types = drs.getTypes();
            int[] objUids = drs.getObjUids();

            String[] paths = drs.getPaths();
            String[] revisions = drs.getRevisions();
            String[] requestIds = drs.getRequestIds();

            for (int i = 0; i < types.length; i++) {
                ChangeStep csp = new ChangeStep();
                csp.setType(types[i]);
                csp.setObjUid(objUids[i]);
                csp.setProjectPath(paths[i]);
                csp.setRevision(revisions[i]);

                csp.setRequestIds(new ArrayList<String>());
                if (requestIds[i].contains(",")) {
                    String[] requests = requestIds[i].split(",");

                    for (int j = 0; j < requests.length; j++) {
                        if (!StringUtils.isBlank(requests[j])) {
                            csp.getRequestIds().add(requests[j]);
                        }
                    }
                } else {
                    if (!StringUtils.isBlank(requestIds[i])) {
                        csp.setRequestIds(Arrays.asList(requestIds[i]));
                    }
                }

                csp.setChangeSet(cs);
                result.add(csp);
                cs.addChangeStep(csp);
            }
        }

        return result;
    }

    public static List<ChangeStep> queryChangeSteps(ChangeSet cs, ChangeSetFilterDataHolder filter) throws AdmException {
        return queryChangeSteps(cs, filter, false);
    }

    public static String queryChangesetsStatuses(List<ChangeSet> csl) throws AdmException {
        DRSClientChangeSet drs = new DRSClientChangeSet(ChangeSetQueryContext.QueryChangeSetsStatus);

        String baseURL = "";
        if (csl != null && csl.size() > 0) {
            int[] uids = new int[csl.size()];
            ChangeSet[] csarray = csl.toArray(new ChangeSet[csl.size()]);
            for (int i = 0; i < csarray.length; i++) {
                uids[i] = (int) csarray[i].getUid();
            }
            drs.setChangeSetUids(uids);
            drs.setWorksetUid(csarray[0].getTreeVersion().getTreeUid());
            DRSUtils.execute(drs);

            if (drs.hasData()) {
                int[] reviewStatuses = drs.getReviewStatuses();
                int[] buildStatuses = drs.getBuildStatuses();

                baseURL = drs.getBaseURL();
				String[] peerReviewSuffixURLs = drs.getPeerReviewSuffixURLs();
				String[] changesetDetailsSuffixURLs = drs.getChangesetDetailsSuffixURLs();
                for (int i = 0; i < csarray.length; i++) {
                    ChangeSetOrbiterStatus st = new ChangeSetOrbiterStatus();
                    st.setReviewStatus(reviewStatuses[i]);
                    st.setBuildStatus(buildStatuses[i]);
					st.setPeerReviewSuffixUrl(peerReviewSuffixURLs[i]);
					st.setChangesetDetailsSuffixUrl(changesetDetailsSuffixURLs[i]);
                    st.setBaseUrl(baseURL);
                    csarray[i].setStatus(st);
                }
            }
        }
        return baseURL;
    }

    public static void queryUsersWithRole(long wsetUid, Long[] changeSetUids, String roleName, String assignmentType, String capability, String candidate, String noWorkset,
    		                              List<String> userNames, List<String> fullUserNames, List<String> emails) throws AdmException {
    
    	DRSClientQueryUsersWithRolesFromChangesets drs = new DRSClientQueryUsersWithRolesFromChangesets();
        drs.setWsetUid(wsetUid);
        drs.setChangesetUids(changeSetUids);
        drs.setRoles(new String[] {roleName});
        drs.setAssignmentType(assignmentType);
        drs.setCapability(capability);
        
        int options = 0;
        if ("Y".equals(candidate)) {
            options |= Constants.PCMS_OPT_DLG_CANDIDATES;
        }
        
        if ("Y".equals(noWorkset)) {
        	options |= Constants.PCMS_OPT_NOWSET;
        } else if ("*".equals(noWorkset)) {
        	options |= Constants.PCMS_OPT_NOWSET|Constants.PCMS_OPT_NATURAL_SCOPE;
        }  
        
        drs.setOptions(options);

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            String[] userArray = drs.getUsers();
            String[] fullnamesArray = drs.getFullnames();
            String[] emailArray = drs.getEmails();
            
            if (userArray != null)
            	userNames.addAll(Arrays.asList(userArray));
            if (fullnamesArray != null)
            	fullUserNames.addAll(Arrays.asList(fullnamesArray));
            if (emails != null)
            	emails.addAll(Arrays.asList(emailArray));
        }
    }

    public static DatabaseId queryDatabaseId() throws AdmException {
        DatabaseId result = new DatabaseId();
        DRSClientGetDatabaseId drs = new DRSClientGetDatabaseId();

        DRSUtils.execute(drs);

        if (drs.hasData()) {
            result.setDatabase(drs.getDatabase());
            result.setBaseDb(drs.getBasedb());
        }

        return result;
    }

    public static String getScmUri() throws AdmException {
        DatabaseId db = queryDatabaseId();

        if (null != db) {
            return MessageFormat.format(ChangeSetsHelper.REPOSITORY_ID_PATTERN, db.getBaseDb(), db.getDatabase());
        }

        return "";
    }

    public static boolean generateRedirectPulsePage(String filename, String pulseUrlSuffix, boolean embeddedMode)
            throws IOException {
        return ((Session) DimSystem.getSystem().getSession()).getConnection().rpcGetRedirectPulsePage(filename, pulseUrlSuffix,
                embeddedMode);
    }

    public static String getCreatePullRequestUrlSuffix(String projectSpec, String scmUri) throws UnsupportedEncodingException {
        return getPullRequestUrlSuffix("services/rest/redirect/createpullrequest", projectSpec, scmUri) ;
    }

    public static String getPullRequestUrlSuffix(String projectSpec, String scmUri) throws UnsupportedEncodingException {
        return getPullRequestUrlSuffix("services/rest/redirect/pullrequest", projectSpec, scmUri);
    }

    private static String getPullRequestUrlSuffix(String path, String projectSpec, String scmuri) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder(path);
        result.append("?scmuri=").append(URLEncoder.encode(scmuri, "UTF-8"));
        result.append("&dcmproduct=").append(URLEncoder.encode(SpecUtils.getProduct(projectSpec), "UTF-8"));
        result.append("&dcmstream=").append(URLEncoder.encode(projectSpec, "UTF-8"));
        return result.toString();
    }

}

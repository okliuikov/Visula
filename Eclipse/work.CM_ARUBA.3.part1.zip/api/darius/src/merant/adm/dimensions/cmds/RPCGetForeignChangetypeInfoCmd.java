/*
 * Copyright (C), 2010-2011, Serena Software Europe, Ltd.
 * All Rights Reserved. No part of this software may be reproduced, stored,
 * or transmitted, in any form or by any means, without the prior permission
 * in writing of Serena Software Europe, Ltd and Serena Software, Inc.
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 */

package merant.adm.dimensions.cmds;

import java.io.IOException;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;
import merant.adm.session.Session;

/**
 * This command verifies and returns the correct synchronize change types
 * <b>Mandatory Arguments:</b> <code>
 *  <dl>
 *   <dt>HOME_STREAM_UID<dt><dd>Uid of Stream from which Work Area contents came from</dd>
 *   <dt>FOREIGN_STREAM_UID<dt><dd>Uid of Foreign Stream being used to update the work area from</dd>
 *   <dt>LOCAL_ITEM_UIDS<dt><dd>Uids of Work Area item revisions (-1 if there is no local item which
 *       corresponds to foreignUids entry with the same index in array)</dd>
 *   <dt>LOCAL_ITEM_PATHS<dt><dd>Relative (to work area root) path of local item (forward slash style, w/o leading slash, say "build/pcwin/AboutBox.cpp").
 *       Required just when the input parameter "foreignItemChanges" contains VFIU_CH_REN.
 *       If item is moved/renamed locally - this parameter should be 'moved-from' path, i.e. path before local move/rename.</dd>
 *   <dt>FOREIGN_ITEM_UIDS<dt><dd> Uids of Foreign Stream item revisions (-1 if there is no foreign item which
 *       corresponds to localUids entry with the same index in array)</dd>
 *   <dt>FOREIGN_ITEM_PATHS<dt><dd>Relative (to Stream root) path of  item (forward slash style, w/o leading slash, say "build/pcwin/Renamed.cpp").
 *       Required just when the input parameter "foreignItemChanges" contains VFIU_CH_REN</dd>
 *   <dt>FOREIGN_ITEM_CHANGES<dt><dd>Detected change types coming from Foreign streams to be verified:<br/>
 *                               # VFIU_CH_NO =0x0000 // No changes (do not provide such items to RPC)
 *                               # VFIU_CH_MOD=0x0002 // Modification (new item Revision from Foreign Stream)
 *                               # VFIU_CH_DEL=0x0004 // Deletion (no such item into Foreign Stream)
 *                               # VFIU_CH_ADD=0x0008 // Addition (new item from Foreign Stream)
 *                               # VFIU_CH_REN=0x0010 // Rename/Move
 *                               # VFIU_CH_CON=0x0040 // Conflict (Changes from Foreign Stream are conflicting
 *                               #                    // with local)
 *                           <br/></dd>
 *   <dt>LOCAL_DIR_PATHS<dt><dd>Relative (to home stream root) path of local directory (forward slash style, w/o leading slash, say "build/pcwin").
 *       Mandatory. If item is moved/renamed locally - this parameter should be 'moved-from' path, i.e. path before local move/rename.</dd>
 *   <dt>FOREIGN_DIR_PATHS<dt><dd>Relative (to Stream root) path of directory(forward slash style, w/o leading slash, say "build/pcun").</dd>
 *   <dt>FOREIGN_DIR_CHANGES<dt><dd>Detected change types coming from Foreign streams to be verified:<br/>
 *                               # VFIU_CH_NO =0x0000 // No changes (do not provide such dirs to RPC)
 *                               # VFIU_CH_DEL=0x0004 // Deletion (no such dir into Foreign Stream)
 *                               # VFIU_CH_ADD=0x0008 // Addition (new dir from Foreign Stream)
 *                               # VFIU_CH_REN=0x0010 // Rename/Move
 *                               # VFIU_CH_CON=0x0040 // Conflict (Changes from Foreign Stream are conflicting
 *                               #                    // with local)
 *                           <br/></dd>
 *  </dl>
 * </code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt></dd>
 * 
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>List<dt><dd>@return - List of:
 *      int[] VerifiedItemChanges,
 *      int[] DiscoveredHomeItemChanges,
 *      int[] VerifiedDirChanges,
 *  </dd>
 * </dl></code> Created 13/07/2010.
 * @author Dinesh Babu
 */
public class RPCGetForeignChangetypeInfoCmd extends RPCCmd {
    /**
     * Constructor defines the command definition and arguments.
     */
    public RPCGetForeignChangetypeInfoCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("GetForeignChangetypeInfo");
        AddArgument("cmd", "GetForeignChangetypeInfo");
        setAttrDef(new CmdArgDef(CmdArguments.HOME_STREAM_UID, true, Long.class));
        setAttrDef(new CmdArgDef(CmdArguments.FOREIGN_STREAM_UID, true, Long.class));
        setAttrDef(new CmdArgDef(CmdArguments.LOCAL_ITEM_UIDS, true, int[].class));
        setAttrDef(new CmdArgDef(CmdArguments.LOCAL_ITEM_PATHS, false, String[].class));
        setAttrDef(new CmdArgDef(CmdArguments.FOREIGN_ITEM_UIDS, true, int[].class));
        setAttrDef(new CmdArgDef(CmdArguments.FOREIGN_ITEM_PATHS, false, String[].class));
        setAttrDef(new CmdArgDef(CmdArguments.FOREIGN_ITEM_CHANGES, true, int[].class));
        setAttrDef(new CmdArgDef(CmdArguments.LOCAL_DIR_PATHS, true, String[].class));
        setAttrDef(new CmdArgDef(CmdArguments.FOREIGN_DIR_PATHS, true, String[].class));
        setAttrDef(new CmdArgDef(CmdArguments.FOREIGN_DIR_CHANGES, true, int[].class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
    }

    @Override
    public Object[] execute() throws AdmException {

        try {
            long localStreamUid = ((Long) getAttrValue(CmdArguments.HOME_STREAM_UID)).longValue();
            long foreignStreamUid = ((Long) getAttrValue(CmdArguments.FOREIGN_STREAM_UID)).longValue();
            int[] localItemUids = ((int[]) getAttrValue(CmdArguments.LOCAL_ITEM_UIDS));
            String[] localItemPaths = ((String[]) getAttrValue(CmdArguments.LOCAL_ITEM_PATHS));
            int[] foreignItemUids = ((int[]) getAttrValue(CmdArguments.FOREIGN_ITEM_UIDS));
            String[] foreignItemPaths = ((String[]) getAttrValue(CmdArguments.FOREIGN_ITEM_PATHS));
            int[] foreignItemChanges = ((int[]) getAttrValue(CmdArguments.FOREIGN_ITEM_CHANGES));
            String[] localDirPaths = ((String[]) getAttrValue(CmdArguments.LOCAL_DIR_PATHS));
            String[] foreignDirPaths = ((String[]) getAttrValue(CmdArguments.FOREIGN_DIR_PATHS));
            int[] foreignDirChanges = ((int[]) getAttrValue(CmdArguments.FOREIGN_DIR_CHANGES));

            Object[] verifiedChanges = ((Session) DimSystem.getSystem().getSession()).getConnection().rpcGetForeignChangetypeInfo(
                    (int) localStreamUid, (int) foreignStreamUid, localItemUids, localItemPaths, foreignItemUids, foreignItemPaths,
                    foreignItemChanges, localDirPaths, foreignDirPaths, foreignDirChanges);

            return verifiedChanges;

        } catch (AttrException e) {
            return null;
        } catch (IOException e) {
            throw new DimConnectionException(e);
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2003 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.server;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Server;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.Baseline;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.Customer;
import merant.adm.dimensions.objects.Item;
import merant.adm.dimensions.objects.Part;
import merant.adm.dimensions.objects.Release;
import merant.adm.dimensions.objects.Type;
import merant.adm.dimensions.objects.User;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will allow you to refresh the server attribute cache
 * <p>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions Type of attributes to refresh</dd>
 *  <dt>ADM_OBJECT_CLASS {Class}<dt><dd>Dimensions class of attributes to refresh, ignored if ADM_OBJECT is specified</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * 
 * @author Floz
 */
public class RefreshAttrCacheCmd extends RPCExecCmd {
    public RefreshAttrCacheCmd() throws AttrException {
        super();
        setAlias(Server.REFRESH_ATTR_CACHE);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, false, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT_CLASS, false, Class.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((attrValue != null) && (!(attrValue instanceof Type))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    private String convertClass(Class objClass) {
        if (objClass == null) {
            return "0";
        }

        if (objClass.equals(Baseline.class)) {
            return "BASELINE";
        } else if (objClass.equals(ChangeDocument.class)) {
            return "CHDOC";
        } else if (objClass.equals(Customer.class)) {
            return "CUSTOMER";
        } else if (objClass.equals(Item.class)) {
            return "ITEM";
        } else if (objClass.equals(Part.class)) {
            return "PART";
        } else if (objClass.equals(Release.class)) {
            return "RELEASE";
        } else if (objClass.equals(User.class)) {
            return "USER";
        } else if (objClass.equals(WorkSet.class)) {
            return "WORKSET";
        }

        return "0";
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();
        AdmUidObject type = (AdmUidObject) getAttrValue(CmdArguments.ADM_OBJECT);
        Class objClass = (Class) getAttrValue(CmdArguments.ADM_OBJECT_CLASS);

        _cmdStr = "DATA \"";
        if (type != null) {
            String uidStr = String.valueOf(type.getAdmUid().getUid());
            Class parentClass = (Class) AdmHelperCmd.getAttributeValue(type, AdmAttrNames.PARENT_CLASS);
            _cmdStr += uidStr + " " + convertClass(parentClass);
        } else if (objClass != null) {
            _cmdStr += "0 " + convertClass(objClass);
        } else {
            _cmdStr += "0 0";
        }

        _cmdStr += " refresh_attrdef\"";
        return executeRpc();
    }
}

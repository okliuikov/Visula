package merant.adm.dimensions.cmds;

import java.util.ArrayList;
import java.util.List;

import com.serena.dmnet.LCNetClnt;

import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimConnectionException;
import merant.adm.dimensions.objects.BuildTarget;
import merant.adm.dimensions.objects.FileArea;
import merant.adm.dimensions.objects.WorkSet;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * Calls the Builder get-dependencies RPC.
 */
public class RPCGetDependenciesCmd extends RPCCmd {
    private static int[] EMPTY_INT_ARRAY = new int[0];

    public RPCGetDependenciesCmd() throws AdmObjectException, AttrException {
        super();
        setAlias("GetDependencies");
        setAttrDef(new CmdArgDef(CmdArguments.WORKSET, true, AdmObject.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_CONFIG_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.STAGE_ID, false, String.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_AREA, false, String.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_REQUEST_OBJ, false, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.BUILD_SELECTION_LIST, false, List.class));

        setAttrDef(new CmdArgDef(AdmAttrNames.TRAVERSE_CHILD_REQUESTS, true, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.SHOW_TARGETS_CONFIG, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.SHOW_TARGETS_FINAL, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.SHOW_TARGETS_FOREIGN, false, Boolean.TRUE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.SHOW_TARGETS_SIDE, false, Boolean.FALSE, Boolean.class));
        setAttrDef(new CmdArgDef(CmdArguments.SHOW_TARGETS_SOFT, false, Boolean.TRUE, Boolean.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {

        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.WORKSET)) {
            if (!(attrValue instanceof WorkSet)) {
                throw new AttrException("RPCGetDependenciesCmd Object type is not supporte!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws AdmException {

        try {

            int iMode = LCNetClnt.Dependencies.IMODE_CTL_PARSECFG | LCNetClnt.Dependencies.IMODE_CTL_GETCFG
                    | LCNetClnt.Dependencies.IMODE_CTL_RETTARG | LCNetClnt.Dependencies.IMODE_CTL_RETDEP
                    | LCNetClnt.Dependencies.IMODE_CTL_RELPATH;
            if (((Boolean) getAttrValue(AdmAttrNames.TRAVERSE_CHILD_REQUESTS)).booleanValue()) {
                iMode |= LCNetClnt.Dependencies.IMODE_CTL_CD_RECURSE;
            }
            if (((Boolean) getAttrValue(CmdArguments.SHOW_TARGETS_CONFIG)).booleanValue()) {
                iMode |= LCNetClnt.Dependencies.IMODE_CTL_ALLTARG;
            }
            if (((Boolean) getAttrValue(CmdArguments.SHOW_TARGETS_FINAL)).booleanValue()) {
                iMode |= LCNetClnt.Dependencies.IMODE_CTL_FINAL;
            }
            if (((Boolean) getAttrValue(CmdArguments.SHOW_TARGETS_FOREIGN)).booleanValue()) {
                iMode |= LCNetClnt.Dependencies.IMODE_CTL_FOREIGN;
            }
            if (!((Boolean) getAttrValue(CmdArguments.SHOW_TARGETS_SIDE)).booleanValue()) {
                iMode |= LCNetClnt.Dependencies.IMODE_CTL_CD_RESTRICT;
            }
            if (((Boolean) getAttrValue(CmdArguments.SHOW_TARGETS_SOFT)).booleanValue()) {
                iMode |= LCNetClnt.Dependencies.IMODE_CTL_SOFT;
            }

            long projectUid = ((AdmUidObject) getAttrValue(CmdArguments.WORKSET)).getAdmUid().getUid();
            AdmUidObject req = (AdmUidObject) getAttrValue(AdmAttrNames.BUILD_REQUEST_OBJ);
            long reqUid = 0L;
            if (req != null) {
                reqUid = req.getAdmUid().getUid();
            }
            String buildConfig = (String) getAttrValue(AdmAttrNames.BUILD_CONFIG_ID);
            String stage = (String) getAttrValue(AdmAttrNames.STAGE_ID);
            String area = (String) getAttrValue(AdmAttrNames.BUILD_AREA);
            int areaUid = -1;
            if (area != null) {
                AdmObject areaObj = AdmHelperCmd.getObject(AdmHelperCmd.newAdmBaseId(area, FileArea.class));
                areaUid = (int) ((AdmUidObject) areaObj).getAdmUid().getUid();
            }

            int[] itemUid;
            List items = (List) getAttrValue(AdmAttrNames.BUILD_SELECTION_LIST);
            if (items != null && items.size() > 0) {
                itemUid = new int[items.size()];
                AdmUidObject item;
                long uid;
                for (int i = 0; i < items.size(); ++i) {
                    item = (AdmUidObject) items.get(i);
                    uid = item.getAdmUid().getUid();
                    itemUid[i] = (int) uid;
                }
            } else {
                itemUid = EMPTY_INT_ARRAY;
            }

            if (itemUid.length > 0) {
                iMode |= LCNetClnt.Dependencies.IMODE_FCN_ITEMS;
            } else if (reqUid != 0L) {
                iMode |= LCNetClnt.Dependencies.IMODE_FCN_CHDOC;
            } else {
                iMode |= LCNetClnt.Dependencies.IMODE_FCN_WS;
            }

            LCNetClnt.Dependencies deps = getSession().getConnection().rpcGetDependencies(iMode, (int) projectUid, (int) reqUid,
                    buildConfig, itemUid, areaUid, stage);
            if (deps != null) {
                LCNetClnt.Dependencies.BuildTarget[] bt = deps.getBuildTargets();
                List retVal = new ArrayList(bt.length);
                for (int i = 0; i < bt.length; ++i) {
                    if (((bt[i].getConfigSpec()).length()) != 0) {
                        AdmBaseId uid = AdmHelperCmd.newAdmBaseId(bt[i].getUid(), BuildTarget.class);
                        // normally one does not use darius like this.
                        // DON'T COPY AND PASTE ME.
                        AdmObject obj = new BuildTarget(uid);
                        obj.setAttrValue(AdmAttrNames.ID, bt[i].getName());
                        obj.setAttrValue(AdmAttrNames.FILE_PATTERN, bt[i].getFileSpec());
                        String foundIn;
                        int rsn = bt[i].getReason();
                        obj.setAttrValue(AdmAttrNames.BUILDTARGET_REASON_CODE, new Integer(rsn));
                        if ((rsn & LCNetClnt.Dependencies.RSN_CONFIG_TARGET) != 0) {
                            if ((rsn & LCNetClnt.Dependencies.RSN_DEPENDENT) != 0) {
                                foundIn = "Build Config and BOM";
                            } else {
                                foundIn = "Build Config";
                            }
                        } else {
                            if ((rsn & LCNetClnt.Dependencies.RSN_DEPENDENT) != 0) {
                                foundIn = "BOM";
                            } else {
                                foundIn = "";
                            }
                        }
                        obj.setAttrValue(AdmAttrNames.BUILDTARGET_STATUS, foundIn);
                        obj.setAttrValue(AdmAttrNames.BUILD_CONFIG_ID, bt[i].getConfigSpec());
                        retVal.add(obj);
                    }
                }
                // new section for appending dependent items to the build target list
                LCNetClnt.Dependencies.DependentItem[] di = deps.getDependentItems();
                for (int i = 0; i < di.length; i++) {
                    int rsn = di[i].getReason();
                    if ((rsn & LCNetClnt.Dependencies.RSN_DEPENDENT) != 0 && di[i].getUid() != Constants.INVALID_UID
                            && di[i].getConfigspec().length() != 0) {
                        // sorry, but this is cut-n-pasted from the above section that
                        // explicitly states 'DON'T COPY AND PASTE ME'.
                        // in fact, this is probably worse than the code above!
                        AdmBaseId uid = AdmHelperCmd.newAdmBaseId(di[i].getUid(), BuildTarget.class);
                        AdmObject obj = new BuildTarget(uid);
                        obj.setAttrValue(AdmAttrNames.ID, di[i].getFilename());
                        obj.setAttrValue(AdmAttrNames.FILE_PATTERN, di[i].getFullpath());
                        obj.setAttrValue(AdmAttrNames.BUILDTARGET_REASON_CODE, new Integer(rsn));
                        // obj.setAttrValue(AdmAttrNames.BUILDTARGET_REASON_CODE,
                        // new Integer(LCNetClnt.Dependencies.RSN_DEPENDENT));
                        obj.setAttrValue(AdmAttrNames.BUILDTARGET_STATUS, "BOM");
                        obj.setAttrValue(AdmAttrNames.BUILD_CONFIG_ID, di[i].getConfigspec());
                        obj.setAttrValue(AdmAttrNames.BUILD_AREA, di[i].getArea());
                        retVal.add(obj);
                    }
                }
                return retVal;
            } else {
                return null;
            }
        } catch (Throwable e) {
            throw new DimConnectionException(e);
        }
    }
}

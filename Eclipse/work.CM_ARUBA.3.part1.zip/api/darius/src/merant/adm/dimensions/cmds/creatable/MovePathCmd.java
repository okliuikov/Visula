/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.creatable;

import java.util.Vector;

import com.serena.dmfile.FilePath;

import merant.adm.dimensions.cmds.AdmCmd;
import merant.adm.dimensions.cmds.CmdUtils;
import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.cmds.interfaces.Creatable;
import merant.adm.dimensions.cmds.interfaces.WithAttrs;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.DimDirectory;
import merant.adm.dimensions.objects.ItemFile;
import merant.adm.dimensions.objects.core.AdmAttrNames;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.system.DimSystem;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.exception.AdmObjectException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.Cmd;
import merant.adm.framework.CmdArgDef;

/**
 * This command will move a Dimensions object from one directory to another.
 * <p>
 * NOTE: The ID parameter should be the new workset parent directory (PARENT_DIR_NAME) not the database id as it is for other
 * commands. <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 *  <dt>ID {String}<dt><dd>New identifier for the object. In the case of DimDirectory
 *                         objects this should be the parent directory path. In the case
 *                         of ItemFile objects this should be the directory component.</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>RELATED_CHDOCS {String}<dt><dd>List of requests to be related</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Peter Raymond
 */
public class MovePathCmd extends RPCExecCmd {
    public MovePathCmd() throws AttrException {
        super();
        setAlias(Creatable.MOVE_PATH);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(AdmAttrNames.ID, true, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.RELATED_CHDOCS, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if ((!(attrValue instanceof ItemFile)) && (!(attrValue instanceof DimDirectory))) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmObjectException, AdmException {
        validateAllAttrs();

        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String id = (String) getAttrValue(AdmAttrNames.ID);
        String chdocs = (String) getAttrValue(CmdArguments.RELATED_CHDOCS);

        // attempt to check new filename for validity:
        if (id == null) {
            throw new DimBaseCmdException("New location not specified");
        }

        // Get the last path element...

        String lastElement = null;

        if (admObj instanceof ItemFile) {
            Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObj);
            Vector cmdArgs = new Vector();
            cmdArgs.add(AdmAttrNames.ITEMFILE_FILENAME);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, cmdArgs);
            cmd.execute();
            lastElement = (String) admObj.getAttrValue(AdmAttrNames.ITEMFILE_FILENAME);
        } else if (admObj instanceof DimDirectory) {
            Cmd cmd = AdmCmd.getCmd(WithAttrs.QUERY, admObj);
            Vector cmdArgs = new Vector();
            cmdArgs.add(AdmAttrNames.ID);
            cmd.setAttrValue(CmdArguments.ATTRIBUTE_NAMES, cmdArgs);
            cmd.execute();
            lastElement = (String) admObj.getAttrValue(AdmAttrNames.ID);
        }

        if (lastElement == null || lastElement.length() == 0) {
            throw new DimBaseCmdException("This object's location cannot be changed");
        }

        // combine the move path with the last element:

        String param;

        // strip off leading and trailing directory separators:
        if (id.length() > 0) {
            char chSep = FilePath.getDirSep(DimSystem.getSystem().getSessionBean().getServerOs());
            while (id.length() > 0 && (id.charAt(0) == Constants.DIRPATH_SEP || id.charAt(0) == chSep)) {
                id = id.substring(1, id.length());
            }
            while (id.length() > 0 && (id.charAt(id.length() - 1) == Constants.DIRPATH_SEP || id.charAt(id.length() - 1) == chSep)) {
                id = id.substring(0, id.length() - 1);
            }
        }
        if (id.length() > 0) {
            param = id + Constants.DIRPATH_SEP + lastElement;
        } else {
            param = lastElement;
        }

        param = CmdUtils.relPathForCmd(param);

        // admObj should always be one of these types if validation has succeeded:
        if (admObj instanceof DimDirectory) {
            String spec = CmdUtils.relPathForCmd(admObj.getAdmSpec().getSpec());
            _cmdStr = "MWSD " + Encoding.escapeSpec(spec) + " " + Encoding.escapeSpec(param);
        } else if (admObj instanceof ItemFile) {
            _cmdStr = "SWF " + Encoding.escapeSpec(admObj.getAdmSpec().getSpec()) + " /WS_FILENAME=" + Encoding.escapeSpec(param);
        }

        if ((chdocs != null) && (chdocs.length() > 0)) {
            _cmdStr += " /CHANGE_DOC_IDS=(" + chdocs + ")";
        }

        return executeRpc();
    }
}

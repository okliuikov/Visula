package merant.adm.dimensions.cmds.helper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.serena.dmfile.FileHelper;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.dto.Pair;
import com.serena.dmnet.LCNetClnt;
import com.serena.dmnet.RPCArg;
import com.serena.dmnet.drs.DRSClientQueryDirectoryVersionChildren;
import com.serena.dmnet.drs.DRSClientQueryFileVersionParent;
import com.serena.dmnet.drs.DRSClientQueryFileVersions;
import com.serena.dmnet.drs.DRSClientQueryItemPathByForestVersion;
import com.serena.dmnet.drs.DRSClientQueryTreeVersionsInRange;

import merant.adm.dimensions.cmds.AdmHelperCmd;
import merant.adm.dimensions.exception.DRSException;
import merant.adm.dimensions.objects.TypeUtils;
import merant.adm.dimensions.objects.core.AdmBaseId;
import merant.adm.dimensions.objects.core.AdmSpecTwin;
import merant.adm.dimensions.objects.core.AdmUid;
import merant.adm.dimensions.server.core.Constants;
import merant.adm.dimensions.server.core.VrsOptions;
import merant.adm.dimensions.server.drs.DRSUtils;
import merant.adm.dimensions.server.drs.objects.FileVersion;
import merant.adm.dimensions.server.drs.objects.FileVersionHandler;
import merant.adm.dimensions.server.drs.objects.TreeVersion;
import merant.adm.dimensions.server.drs.objects.TreeVersionHandler;
import merant.adm.exception.AdmException;

public class RepositoryVersionFileHelper {

    private static String createPath(final String[] uniqueNames, final int[] basenameKeys, final int[] dirnameKeys, int i) {
        final int dirnameIdx = dirnameKeys[i];
        final int basenameIdx = basenameKeys[i];
        final String dirname = uniqueNames[dirnameIdx];
        final String basename = uniqueNames[basenameIdx];

        StringBuilder sb = new StringBuilder(dirname);
        if (sb.length() > 0) {
            sb.append('/');
        }
        sb.append(basename);
        return sb.toString();
    }

    private static boolean removeRecursive(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; ++i) {
                boolean removed = removeRecursive(new File(dir, children[i]));
                if (!removed) {
                    return false;
                }
            }
        }
        return dir.delete();
    }

    public static AdmBaseId createScopeObject(int treeClass, String treeSpec, long treeUid) {
        Class<?> scopeClass = TypeUtils.getClassFromInt(treeClass);
        AdmSpecTwin specTwin = new AdmSpecTwin(treeSpec, scopeClass);
        return AdmHelperCmd.newAdmBaseId(treeUid, scopeClass, null, specTwin);
    }

    public static FileVersion getRootDirectory(long forestVersion, int treeClass, long treeUid, String treeSpec,
            AdmBaseId scopeObject) throws AdmException {
        // Query the root folder
        SingleFileVersionHandler singleHandler = new SingleFileVersionHandler();
        getFiles(forestVersion, treeClass, treeUid, treeSpec, Collections.singletonList("/"), scopeObject, singleHandler);
        return singleHandler.getSingleFileVersion();
    }

    public static void getChildren(long targetVersion, FileVersion directory, FileVersionHandler handler, boolean recursive,
            int options) throws AdmException {
        // include all if not specified
        if ((options & VrsOptions.VERSIONFILE_INCLUDE_DIRS) == 0 && (options & VrsOptions.VERSIONFILE_INCLUDE_FILES) == 0) {
            options |= VrsOptions.VERSIONFILE_INCLUDE_ALL;
        }

        if (recursive) {
            options |= VrsOptions.VERSIONFILE_RECURSIVE;
        } else {
            options &= ~VrsOptions.VERSIONFILE_RECURSIVE;
        }

        long treeUid = directory.getTreeUid();

        DRSClientQueryDirectoryVersionChildren drs = new DRSClientQueryDirectoryVersionChildren();
        drs.setForestVersion(targetVersion);
        drs.setTreeUid(treeUid);
        drs.setObjUid(directory.getUid());
        drs.setOptions(options);

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] objUids = drs.getObjUids();
            int[] objSpecUids = drs.getObjSpecUids();
            int[] forestVersions = drs.getForestVersions();
            int[] treeVersions = drs.getTreeVersions();
            int[] types = drs.getFileTypes();
            int[] changesetUids = drs.getChangesetUids();
            String[] paths = drs.getPaths();
            String[] users = drs.getUsers();
            String[] dates = drs.getDates();

            int treeClass = directory.getTreeClass();
            String treeSpec = directory.getTreeSpec();

            AdmBaseId scopeBaseId = getScopeBaseIdFromFile(directory, treeUid, treeClass, treeSpec);

            FileVersionFactory fvf = new FileVersionFactory();

            for (int i = 0; i < objUids.length; ++i) {
                final TreeVersion tv = TreeVersionFactory.makeNewTreeVersion(treeUid, forestVersions[i], changesetUids[i],
                        treeVersions[i], treeClass, treeSpec);
                final int objUid = objUids[i];
                final int type = types[i];
                final String user = users[i];
                final String date = dates[i];
                final String path = paths[i];

                int objSpecUid = -1;
                if (objSpecUids != null) {
                    objSpecUid = objSpecUids[i];
                }

                final FileVersion fv = fvf.createFileVersion(tv, objUid, objSpecUid, type, path, user, date, scopeBaseId);
                handler.handleFileVersion(fv);
            }
        }
    }

    public static void getChildren(FileVersion rootDirectory, long fromForestVersion, long toForestVersion,
            TreeVersionHandler treeVersionHandler, FileVersionHandler fileVersionHander, int options) throws AdmException {
        if (rootDirectory.getUid() != 0) {
            throw new DRSException("Invalid starting directory.");
        }

        // include all if not specified
        if ((options & VrsOptions.VERSIONFILE_INCLUDE_DIRS) == 0 && (options & VrsOptions.VERSIONFILE_INCLUDE_FILES) == 0) {
            options |= VrsOptions.VERSIONFILE_INCLUDE_ALL;
        }

        options |= VrsOptions.VERSIONFILE_RECURSIVE;
        final long treeUid = rootDirectory.getTreeUid();
        final int treeClass = rootDirectory.getTreeClass();
        final String treeSpec = rootDirectory.getTreeSpec();
        final AdmBaseId scopeBaseId = getScopeBaseIdFromFile(rootDirectory, treeUid, treeClass, treeSpec);

        DRSClientQueryTreeVersionsInRange drs = new DRSClientQueryTreeVersionsInRange();
        drs.setTreeUid(treeUid);
        drs.setFromForestVersion(fromForestVersion);
        drs.setToForestVersion(toForestVersion);
        drs.setOptions(options); // just filenames

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            LCNetClnt con = DRSUtils.getLCNetClntObject();

            final String[] uniqueNames = drs.getNames();
            final Map<Integer, Pair<String, String>> uniqueChangeSetInfo = drs.getUniqueChangeSetInfo();

            final int[] elementCounts = drs.getElementCounts();
            final int[] forestVersions = drs.getForestVersions();
            final int[] changeSetUids = drs.getChangeSetUids();
            final int[] treeVersions = drs.getTreeVersions();
            final String[] tempFilenames = drs.getTempFilenames();
            final String tempDirname = drs.getTempDir();

            TreeVersionFactory tvf = new TreeVersionFactory();
            FileVersionFactory fvf = new FileVersionFactory();

            try {
                for (int i = 0; i < forestVersions.length; ++i) {
                    final int childCount = elementCounts[i];
                    if (childCount == 0) {
                        // continue; allow creation of empty changesets to be compatible with other API parts;
                        // for example, user could query tree version using DRS which does not return files
                        // and then query for files using each tree version receiving empty files list;
                    }

                    final int forestVersion = forestVersions[i];
                    final int changeSetUid = changeSetUids[i];
                    final int treeVersion = treeVersions[i];
                    final String treeVersionData = tempFilenames[i];
                    final TreeVersion tv = tvf.createTreeVersion(treeUid, forestVersion, changeSetUid, treeVersion,
                            treeClass, treeSpec);

                    byte[] buffer = FileHelper.readFileAsBytes(treeVersionData);

                    List<RPCArg> args = new ArrayList<RPCArg>();
                    if (!con.readRPCmessage(buffer, 0, buffer.length, args)) {
                        throw new DRSException("Failed to parse tree version data in file " + treeVersionData);
                    }

                    if (args.size() != 8) {
                        throw new DRSException("Invalid tree version data in file " + treeVersionData);
                    }

                    final int[] objUids = args.get(0).asIntArray();
                    final int[] objSpecUids = args.get(1).asIntArray();
                    final int[] pathForestVersions = args.get(2).asIntArray();
                    final int[] pathTreeVersions = args.get(3).asIntArray();
                    final int[] pathChangeSetUids = args.get(4).asIntArray();
                    final int[] types = args.get(5).asIntArray();
                    final int[] basenameKeys = args.get(6).asIntArray();
                    final int[] dirnameKeys = args.get(7).asIntArray();

                    treeVersionHandler.handleTreeVersion(tv);

                    for (int j = 0; j < objUids.length; ++j) {
                        FileVersion fv = null;

                        if (i > 0) {
                            fv = fvf.getCachedFileVersion(pathForestVersions[j], objSpecUids[j],
                                    uniqueNames[dirnameKeys[j]]);
                            if (fv != null && fv.getUid() != objUids[j]) {
                                fv = null;
                            }
                        }

                        if (fv == null) {
                            final TreeVersion ftv = tvf.createTreeVersion(treeUid, pathForestVersions[j],
                                    pathChangeSetUids[j], pathTreeVersions[j], treeClass, treeSpec);
                            final String path = createPath(uniqueNames, basenameKeys, dirnameKeys, j);
                            final Pair<String, String> ci = uniqueChangeSetInfo.get(pathChangeSetUids[j]);
                            final int objUid = objUids[j];
                            final int type = types[j];

                            int objSpecUid = -1;
                            if (objSpecUids != null) {
                                objSpecUid = objSpecUids[j];
                            }

                            fv = fvf.createFileVersion(ftv, objUid, objSpecUid, type, path, ci.getFirst(), ci.getSecond(),
                                    scopeBaseId);
                        }

                        fileVersionHander.handleFileVersion(fv);
                    }
                }
            } catch (IOException e) {
                throw new DRSException(e);
            } finally {
                File tempDir = new File(tempDirname);
                removeRecursive(tempDir);
            }
        }
    }

    public static void getFiles(long version, int treeClass, long treeUid, String treeSpec, List<String> paths,
            AdmBaseId scopeBaseId, FileVersionHandler handler) throws AdmException {
        DRSClientQueryFileVersions drs = new DRSClientQueryFileVersions();
        drs.setForestVersion(version);
        drs.setTreeUid(treeUid);
        drs.setPaths(paths.toArray(new String[paths.size()]));

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int[] objUids = drs.getObjUids();
            int[] objSpecUids = drs.getObjSpecUids();
            int[] types = drs.getFileTypes();
            int[] changesetUids = drs.getChangesetUids();
            String[] users = drs.getUsers();
            String[] dates = drs.getDates();
            int[] forestVersions = drs.getForestVersions();
            int[] treeVersions = drs.getTreeVersions();

            scopeBaseId = getScopeBaseIdFromBaseId(scopeBaseId, treeClass, treeUid, treeSpec);

            FileVersionFactory fvf = new FileVersionFactory();

            for (int i = 0; i < objUids.length; ++i) {
                final TreeVersion ftv = TreeVersionFactory.makeNewTreeVersion(treeUid, forestVersions[i], changesetUids[i],
                        treeVersions[i], treeClass, treeSpec);
                final int objUid = objUids[i];
                final int type = types[i];
                final String user = users[i];
                final String date = dates[i];
                final String path = paths.get(i);

                int objSpecUid = -1;
                if (objSpecUids != null) {
                    objSpecUid = objSpecUids[i];
                }

                final FileVersion fv = fvf.createFileVersion(ftv, objUid, objSpecUid, type, path, user, date, scopeBaseId);
                handler.handleFileVersion(fv);
            }
        }
    }

    public static FileVersion getParent(FileVersion dariusFileVersion) throws AdmException {
        DRSClientQueryFileVersionParent drs = new DRSClientQueryFileVersionParent();

        long treeUid = dariusFileVersion.getTreeUid();

        drs.setTreeUid(treeUid);
        drs.setForestVersion(dariusFileVersion.getForestVersion());
        drs.setPath(dariusFileVersion.getPath());

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            int objUid = drs.getObjUid();
            int forestVersion = drs.getParentForestVersion();
            int treeVersion = drs.getParentTreeVersion();
            int changesetUid = drs.getChangesetUid();
            String path = drs.getParentPath();
            String user = drs.getUser();
            String date = drs.getDate();

            int treeClass = dariusFileVersion.getTreeClass();
            String treeSpec = dariusFileVersion.getTreeSpec();

            AdmBaseId scopeBaseId = getScopeBaseIdFromFile(dariusFileVersion, treeUid, treeClass, treeSpec);

            final TreeVersion ftv = TreeVersionFactory.makeNewTreeVersion(treeUid, forestVersion, changesetUid, treeVersion,
                    treeClass, treeSpec);
            final FileVersion fv = FileVersionFactory.makeNewFileVersion(ftv, objUid, objUid, 0, path, user, date,
                    scopeBaseId);
            return fv;
        }

        return null;
    }

    private static AdmBaseId getScopeBaseIdFromFile(FileVersion directory, long treeUid, int treeClass, String treeSpec) {
        AdmBaseId scopeBaseId = null;
        AdmBaseId directoryBaseId = directory.getAdmBaseId();
        if (directoryBaseId != null) {
            scopeBaseId = directoryBaseId.getScope();
        }

        return getScopeBaseIdFromBaseId(scopeBaseId, treeClass, treeUid, treeSpec);
    }

    private static AdmBaseId getScopeBaseIdFromBaseId(AdmBaseId baseId, int treeClass, long treeUid, String treeSpec) {
        if (!(baseId instanceof AdmUid)) {
            baseId = createScopeObject(treeClass, treeSpec, treeUid);
        } else {
            AdmUid admScopeUid = (AdmUid) baseId;
            long scopeUid = admScopeUid.getUid();
            if (scopeUid != treeUid) {
                baseId = createScopeObject(treeClass, treeSpec, treeUid);
            }
        }
        return baseId;
    }

    public static Pair<String, String> getPathByForestVersion(FileVersion dariusFileVersion, long targetVersion)
            throws AdmException {
        return getPathByForestVersion(targetVersion, dariusFileVersion.getForestVersion(), dariusFileVersion.getUid(),
                dariusFileVersion.getTreeUid(), !dariusFileVersion.isFolder());
    }

    public static Pair<String, String> getPathByForestVersion(long targetForestVersion, long itemForestVersion, long itemUid,
            long treeUid, boolean itemIsFile) throws AdmException {
        DRSClientQueryItemPathByForestVersion drs = new DRSClientQueryItemPathByForestVersion();
        drs.setItemForestVersion(itemForestVersion);
        drs.setTargetForestVersion(targetForestVersion);
        drs.setItemUid(itemUid);
        drs.setTreeUid(treeUid);
        if (itemIsFile) {
            drs.setObjectType(Constants.ITEM_CLASS);
        } else {
            drs.setObjectType(Constants.DIRECTORY_CLASS);
        }

        DRSUtils.execute(drs);
        if (drs.hasData()) {
            String projectSpec = drs.getProjectSpec();
            String path = drs.getPath();
            if (StringPath.isNullorEmpty(projectSpec) || StringPath.isNullorEmpty(path)) {
                throw new IllegalArgumentException(
                        "Incorrect result after execution of drs. Project specification and path should not be null or empty.");
            }
            return new Pair<String, String>(projectSpec, path);
        }

        return null;
    }

}

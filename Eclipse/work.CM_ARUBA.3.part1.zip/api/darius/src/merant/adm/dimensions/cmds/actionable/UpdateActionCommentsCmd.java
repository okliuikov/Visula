/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2001 MERANT. All rights reserved.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package merant.adm.dimensions.cmds.actionable;

import java.io.IOException;

import merant.adm.dimensions.cmds.RPCExecCmd;
import merant.adm.dimensions.cmds.TempFileOutputStream;
import merant.adm.dimensions.cmds.interfaces.Actionable;
import merant.adm.dimensions.cmds.interfaces.CmdArguments;
import merant.adm.dimensions.exception.DimBaseCmdException;
import merant.adm.dimensions.objects.ChangeDocument;
import merant.adm.dimensions.objects.core.AdmObject;
import merant.adm.dimensions.objects.core.AdmUidObject;
import merant.adm.dimensions.util.Encoding;
import merant.adm.exception.AdmException;
import merant.adm.framework.AttrDef;
import merant.adm.framework.AttrException;
import merant.adm.framework.CmdArgDef;

/**
 * This command will update the current set of Dimensions object action comments.
 * <p>
 * <b>Mandatory Arguments:</b> <code><dl>
 *  <dt>ADM_OBJECT {AdmObject}<dt><dd>Dimensions object</dd>
 * </dl></code> <br>
 * <b>Optional Arguments:</b> <code><dl>
 *  <dt>USER_FILE {String}<dt><dd>User filename.  If not provided, use ACTION_COMMENT</dd>
 *  <dt>ACTION_COMMENT {String}<dt><dd>String containing action comment</dd>
 * </dl></code> <br>
 * <b>Returns:</b> <code><dl>
 *  <dt>{String}<dt><dd>Dimensions operation completion statement</dd>
 * </dl></code>
 * @author Tim Payne
 */
public class UpdateActionCommentsCmd extends RPCExecCmd {
    public UpdateActionCommentsCmd() throws AttrException {
        super();
        setAlias(Actionable.UPDATE_COMMENTS);
        setAttrDef(new CmdArgDef(CmdArguments.ADM_OBJECT, true, AdmObject.class));
        setAttrDef(new CmdArgDef(CmdArguments.USER_FILE, false, String.class));
        setAttrDef(new CmdArgDef(CmdArguments.ACTION_COMMENT, false, String.class));
    }

    @Override
    public void validateAttr(String name, AttrDef attrDef, Object attrValue) throws AttrException {
        super.validateAttr(name, attrDef, attrValue);
        if (name.equals(CmdArguments.ADM_OBJECT)) {
            if (!(attrValue instanceof ChangeDocument)) {
                throw new AttrException("Error: Object type is not supported!", attrDef, attrValue);
            }
        }
    }

    @Override
    public Object execute() throws DimBaseCmdException, AdmException {
        validateAllAttrs();
        AdmObject admObj = (AdmObject) getAttrValue(CmdArguments.ADM_OBJECT);
        String userFile = (String) getAttrValue(CmdArguments.USER_FILE);
        String actionComment = (String) getAttrValue(CmdArguments.ACTION_COMMENT);

        StringBuffer buff = null;
        TempFileOutputStream ts = null;
        String ret = null;
        try {
            if (admObj instanceof ChangeDocument) {
                buff = new StringBuffer("XDATA \"UPDATE_DBFILE\" /PARAMETER=(");
                buff.append("CLASS=CHDOC, ");
                buff.append("ATTR=10001, ");
                buff.append("UID=" + ((AdmUidObject) admObj).getAdmUid() + ", ");
                if ((userFile != null) && (userFile.length() > 0)) {
                    buff.append("USER_FILENAME=" + Encoding.escapeDMCLI(userFile));
                } else {
                    ts = new TempFileOutputStream();
                    ts.writeString(actionComment);
                    buff.append("USER_FILENAME=" + Encoding.escapeDMCLI(ts.getAbsolutePath()));

                }
                buff.append(")");
            }

            this._cmdStr = new String(buff);
            ret = executeRpc();

            if (ts != null) {
                ts.close();
            }
        } catch (IOException ioException) {
            throw new AdmException(ioException);
        }

        return ret;
    }
}

/*
 * Copyright 2002 SERENA Software, Inc. All Rights Reserved.
 * This software is proprietary information of SERENA Software, Inc.
 * Use is subject to license terms.
 */
package com.serena.eclipse.core;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.internal.core.Assert;
import com.serena.eclipse.internal.core.Policy;

/**
 * Service registry keeps track of all installed services.
 *
 * @author V.Grishchenko
 */
public final class ServiceRegistry {
    private static final ServiceRegistry INSTANCE = new ServiceRegistry();

    private Map services = new HashMap();

    // no external instantiation allowed
    private ServiceRegistry() {
        super();
    }

    public static ServiceRegistry getInstance() {
        return INSTANCE;
    }

    // private and protected instance methods -----------------------------------
    private void registerExtension(IConfigurationElement config) {
        String id = config.getAttribute("id"); //$NON-NLS-1$
        String name = config.getAttribute("name"); //$NON-NLS-1$
        if (id != null && name != null) {
            IService service = new Service(id, name);
            if (getService(id) == null) {
                registerService(service);
            } else {
                Status warn = new Status(IStatus.WARNING, CorePlugin.ID, IStatus.ERROR, "Service already exists, id=" + id, null); //$NON-NLS-1$
                CorePlugin.log(warn);
            }
        } else {
            IStatus error = new Status(IStatus.ERROR, CorePlugin.ID, IStatus.ERROR,
                    "Invalid service extension, id=" + id + " name=" + name, null); //$NON-NLS-1$ //$NON-NLS-2$
            CorePlugin.log(error);
        }
    }

    private void processEpConfig(IConfigurationElement[] configElements) {
        for (int j = 0; j < configElements.length; j++) {
            IConfigurationElement config = configElements[j];
            if (config.getName().equals("service")) {
                registerExtension(config);
            }
        }
    }

    void startup() {
        IExtensionPoint ep = Platform.getExtensionRegistry().getExtensionPoint(CorePlugin.SERVICES_EXTENSION);
        if (ep != null) {
            IExtension[] extensions = ep.getExtensions();
            for (int i = 0; i < extensions.length; i++) {
                IConfigurationElement[] configElements = extensions[i].getConfigurationElements();
                processEpConfig(configElements);
            }
        }
    }

    // public instance methods --------------------------------------------------

    public void registerService(IService service) {
        Assert.isLegal(service.getId() != null);
        if (Policy.debugAddservice) {
            System.out.println("[" + CorePlugin.ID + "] adding service, id=" //$NON-NLS-1$ //$NON-NLS-2$
                    + service.getId() + ", name=" + service.getName()); //$NON-NLS-1$
        }
        services.put(service.getId(), service);
    }

    public String[] getServiceIds() {
        return (String[]) services.keySet().toArray(new String[services.size()]);
    }

    public IService[] getServices() {
        return (IService[]) services.values().toArray(new IService[services.size()]);
    }

    public IService getService(String id) {
        return (IService) services.get(id);
    }

    public IService unregisterService(String id) {
        return (IService) services.remove(id);
    }

}

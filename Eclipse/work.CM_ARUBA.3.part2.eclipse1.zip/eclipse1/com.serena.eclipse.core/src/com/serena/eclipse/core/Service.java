/*
 * Copyright 2002 SERENA Software, Inc. All Rights Reserved.
 * This software is proprietary information of SERENA Software, Inc.
 * Use is subject to license terms.
 */
package com.serena.eclipse.core;

import org.eclipse.core.runtime.PlatformObject;

/**
 * Default service implementation.
 *
 * @author V.Grishchenko
 */
public class Service extends PlatformObject implements IService, IServiceResource {

    private String id;
    private String name;

    /**
     * Constructor for Service.
     */
    public Service(String id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * @see com.serena.eclipse.core.IService#getId()
     */
    @Override
    public String getId() {
        return id;
    }

    /**
     * @see com.serena.eclipse.core.IService#getName()
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * @see com.serena.eclipse.core.IServiceResource#getServiceId()
     */
    @Override
    public String getServiceId() {
        return getId();
    }

    /**
     * @see com.serena.eclipse.core.IServiceResource#isContainer()
     */
    @Override
    public boolean isContainer() {
        return true;
    }

    /**
     * @see com.serena.eclipse.core.IService#equals(Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof IService) {
            return id.equals(((IService) obj).getId());
        }
        return false;
    }

    /**
     * @see com.serena.eclipse.core.IService#hashCode()
     */
    @Override
    public int hashCode() {
        return id.hashCode();
    }

}

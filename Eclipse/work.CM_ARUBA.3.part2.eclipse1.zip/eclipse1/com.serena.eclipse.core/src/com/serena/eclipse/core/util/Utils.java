package com.serena.eclipse.core.util;

import java.io.File;
import java.util.Arrays;

public class Utils {
    private Utils() {
    }

    @SuppressWarnings("unchecked")
    public static <T> T[] concat(T[] first, T[] second) {
        if (first == null) {
            first = (T[]) new Object[0];
        }

        if (second == null) {
            second = (T[]) new Object[0];
        }

        if (first.length == 0) {
            return second;
        } else if (second.length == 0) {
            return first;
        }

        T[] result = Arrays.copyOf(first, first.length + second.length);
        System.arraycopy(second, 0, result, first.length, second.length);
        return result;
    }

    public static int[] concat(int[] first, int[] second) {
        if (first == null) {
            first = new int[0];
        }

        if (second == null) {
            second = new int[0];
        }

        if (first.length == 0) {
            return second;
        } else if (second.length == 0) {
            return first;
        }

        int[] result = Arrays.copyOf(first, first.length + second.length);
        System.arraycopy(second, 0, result, first.length, second.length);
        return result;
    }

    private static final int DEFAULT_DELAY = 30000;

    /***
     * Deletes file after delay (30 seconds)
     * @param file
     *            file to delete
     */
    public static void deleteFileWithDelay(File file) {
        deleteFileWithDelay(file, DEFAULT_DELAY);
    }

    /***
     * Deletes file after specified delay
     * @param file
     *            file to delete
     * @param delay
     *            delay in ms
     */
    public static void deleteFileWithDelay(final File file, final int delay) {
        if (file == null || !file.exists()) {
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(delay);
                    file.delete();
                } catch (Exception e) { // Swallow it
                }
            }
        }).start();
    }

}

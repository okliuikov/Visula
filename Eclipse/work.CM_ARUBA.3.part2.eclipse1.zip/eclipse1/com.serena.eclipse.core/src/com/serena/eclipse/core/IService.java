/*
 * Copyright 2002 SERENA Software, Inc. All Rights Reserved.
 * This software is proprietary information of SERENA Software, Inc.
 * Use is subject to license terms.
 */
package com.serena.eclipse.core;

import org.eclipse.core.runtime.IAdaptable;

/**
 * Service is an abstraction of any Serena change management product. Each
 * service has a unique id and symbolic name. This interface is not intended
 * to be implemented by clients.
 *
 * @author V.Grishchenko
 */
public interface IService extends IAdaptable {
    /**
     * Gets service id.
     * @return service id
     */
    public String getId();

    /**
     * Gets service name.
     * @return String
     */
    public String getName();

    /**
     * @see java.lang.Object#equals(Object)
     */
    @Override
    public boolean equals(Object obj);

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode();

}

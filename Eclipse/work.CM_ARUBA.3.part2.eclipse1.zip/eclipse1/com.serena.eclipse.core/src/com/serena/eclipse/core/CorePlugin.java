package com.serena.eclipse.core;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Plugin;
import org.osgi.framework.BundleContext;

/**
 * The main plugin class to be used in the desktop.
 */
public class CorePlugin extends Plugin {

    // plugin id
    public static final String ID = "com.serena.eclipse.core";
    // services extension point
    public static final String SERVICES_EXTENSION = ID + ".services";
    // The shared instance.
    private static CorePlugin plugin;

    /**
     * The constructor.
     */
    public CorePlugin() {
        super();
        plugin = this;
    }

    /**
     * Returns the shared instance.
     */
    public static CorePlugin getDefault() {
        return plugin;
    }

    private void startServiceRegistry() {
        ServiceRegistry.getInstance().startup();
    }

    /**
     * Returns the workspace instance.
     */
    public static IWorkspace getWorkspace() {
        return ResourcesPlugin.getWorkspace();
    }

    /**
     * @see org.eclipse.core.runtime.Plugin#startup()
     */
    @Override
    public void start(BundleContext context) throws Exception {
        super.start(context);
        startServiceRegistry();
    }

    public static void log(IStatus status) {
        plugin.getLog().log(status);
    }

}

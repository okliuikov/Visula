/*
 * Copyright 2002 SERENA Software, Inc. All Rights Reserved.
 * This software is proprietary information of SERENA Software, Inc.
 * Use is subject to license terms.
 */
package com.serena.eclipse.core;

import org.eclipse.core.runtime.IAdaptable;

/**
 * @author V.Grishchenko
 */
public interface IServiceResource extends IAdaptable {

    String getServiceId();

    public boolean isContainer();

}

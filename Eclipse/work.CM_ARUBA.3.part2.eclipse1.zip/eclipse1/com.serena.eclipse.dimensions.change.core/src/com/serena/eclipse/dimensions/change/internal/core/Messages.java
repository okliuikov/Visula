/*
 * @Messages.java, created on May 11, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.change.internal.core;

import org.eclipse.osgi.util.NLS;

/**
 * NLS convenience methods for the plugin.
 *
 * @author V.Grishchenko
 */
public class Messages {
    private static final String BUNDLE_NAME = "com.serena.eclipse.dimensions.change.internal.core.messages"; //$NON-NLS-1$

    static {
        NLS.initializeMessages(BUNDLE_NAME, Messages.class);
    }
}
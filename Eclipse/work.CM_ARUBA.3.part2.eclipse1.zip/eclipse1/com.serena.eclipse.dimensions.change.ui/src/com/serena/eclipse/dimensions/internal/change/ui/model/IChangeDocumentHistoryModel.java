/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import java.util.List;

import com.serena.eclipse.dimensions.internal.ui.model.IHistoryModel;

/**
 * Contains structure history information for a request.
 *
 * @author V.Grishchenko
 */
public interface IChangeDocumentHistoryModel extends IHistoryModel {

    /**
     * @return a list whose elements are <code>StructureHistoryRec</code> or null
     *         if this model hasn't yet been loaded
     */
    List /* <StructureHistoryRec> */getStructureHistory();

}

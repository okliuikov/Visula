/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.DimensionsRuntimeException;
import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.model.EditableModel;

/**
 * @author V.Grishchenko
 */
public class ActionDescriptionModel extends EditableModel implements IActionDescriptionModel {

    /** MIME type <code>text/plain</code> */
    String TEXT_PLAIN = "text/plain"; //$NON-NLS-1$

    /** MIME type <code>text/html</code> */
    String TEXT_HTML = "text/html"; //$NON-NLS-1$

    /** MIME type <code>text/rtf</code> */
    String TEXT_RTF = "text/rtf"; //$NON-NLS-1$

    /** MIME type <code>application/vnd.ms-winword</code> */
    String APP_VND_MSWINWORD = "application/vnd.ms-winword"; //$NON-NLS-1$

    /** MIME type <code>application/msword</code> */
    String APP_MSWORD = "application/msword"; //$NON-NLS-1$

    private Request changeDocument;
    private String originalDescription;
    private String newDescription;
    private String mimeType;
    private DimensionsResult result;

    public ActionDescriptionModel(APIObjectAdapter object) {
        super(object);
        assert object.getAPIObject() instanceof Request;
        changeDocument = (Request) object.getAPIObject();
    }

    @Override
    protected long doSave(IProgressMonitor pm) throws DMException {
        final IProgressMonitor _pm = Utils.monitorFor(pm);
        _pm.beginTask(Messages.actionDesc_save, 100);
        final long[] tsHolder = new long[1];
        try {
            Session session = getUnderlyingObject().getConnectionDetails().openSession(Utils.subMonitorFor(_pm, 30)); // 30
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {

                    result = changeDocument.addActionDescription(newDescription);
                    _pm.worked(70); // 100
                    tsHolder[0] = getTimeStamp(); // new timestamp is already cached after reload
                }
            }, _pm);
        } catch (DMException e) {
            _pm.done();
        }
        return tsHolder[0];
    }

    @Override
    protected long doLoad(IProgressMonitor pm) throws DMException {
        pm = Utils.monitorFor(pm);
        pm.beginTask(Messages.actionDesc_load, IProgressMonitor.UNKNOWN);
        Session session = getUnderlyingObject().getConnectionDetails().openSession(Utils.subMonitorFor(pm, 10));
        try {
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    try {
                        originalDescription = changeDocument.getCommittedActionDescription(null);
                    } catch (DimensionsRuntimeException e) {
                        if (e.getMessage().indexOf(Messages.actionDesc_exceptionText) == -1) {
                            // only throw the exception if it is not the given exception
                            throw (e);
                        }
                    }
                    try {
                        originalDescription += changeDocument.getLastActionDescription(null);
                    } catch (DimensionsRuntimeException e) {
                        if (e.getMessage().indexOf(Messages.actionDesc_exceptionText) == -1) {
                            // only throw the exception if it is not the given exception
                            throw (e);
                        }
                    }
                    mimeType = changeDocument.getBrowseTemplateMimeType();
                }
            }, pm);
        } finally {
            pm.done();
        }
        return getTimeStamp();
    }

    @Override
    public String getCompleteActionDescription() {
        return originalDescription;
    }

    @Override
    public void addActionDescription(String newDescription) {
        this.newDescription = newDescription;
        if (newDescription.length() > 0) {
            setDirty(true);
        } else {
            setDirty(false);
        }
    }

    @Override
    public String getMimeType() {
        return changeDocument.getBrowseTemplateMimeType();
    }

    @Override
    public boolean isTextPlain() {
        return TEXT_PLAIN.equalsIgnoreCase(mimeType);
    }

    @Override
    public boolean isTextHtml() {
        return TEXT_HTML.equalsIgnoreCase(mimeType);
    }

    @Override
    public boolean isRTF() {
        return TEXT_RTF.equalsIgnoreCase(mimeType) || APP_MSWORD.equalsIgnoreCase(mimeType)
                || APP_VND_MSWINWORD.equalsIgnoreCase(mimeType);
    }

    @Override
    public boolean isInSyncOnSave() {
        return false; // need to refresh after save
    }
}
/*
 * @EditChangeDocumentAttributesAction.java, created on Apr 17, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.util.Iterator;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.dialogs.DelegateWizard;
import com.serena.eclipse.dimensions.internal.ui.editors.DelegatesPage;

/**
 * Opens attributes page.
 *
 * @author V.Grishchenko
 */
public class DelegateChangeDocumentAction extends DimensionsAction {

    public DelegateChangeDocumentAction() {
    }

    @Override
    public void run(IAction action) {
        IStructuredSelection ssel = getSelection();
        if (ssel.isEmpty()) {
            return;
        }

        APIObjectAdapter[] objects = new APIObjectAdapter[ssel.size()];
        if (ssel.size() > 1) {
            int i = 0;
            boolean sameProductType = true;
            for (Iterator iter = ssel.iterator(); iter.hasNext();) {
                Object object = iter.next();

                if (object instanceof APIObjectAdapter) {
                    objects[i] = (APIObjectAdapter) object;
                }
                i++;
            }
            for (i = 0; i < objects.length - 1; i++) {
                if (i == 0) {
                    // only the first time the first object has to be queried, the next time it has been queried in the previous
                    // loop already
                    objects[i].getAPIObject().queryAttribute(SystemAttributes.PRODUCT_NAME);
                    objects[i].getAPIObject().queryAttribute(SystemAttributes.TYPE_NAME);
                    objects[i + 1].getAPIObject().queryAttribute(SystemAttributes.PRODUCT_NAME);
                    objects[i + 1].getAPIObject().queryAttribute(SystemAttributes.TYPE_NAME);
                    String product1 = (String) objects[i].getAPIObject().getAttribute(SystemAttributes.PRODUCT_NAME);
                    String product2 = (String) objects[i + 1].getAPIObject().getAttribute(SystemAttributes.PRODUCT_NAME);
                    String type1 = (String) objects[i].getAPIObject().getAttribute(SystemAttributes.TYPE_NAME);
                    String type2 = (String) objects[i + 1].getAPIObject().getAttribute(SystemAttributes.TYPE_NAME);
                    if (!product1.equalsIgnoreCase(product2) || !type1.equalsIgnoreCase(type2)) {
                        sameProductType = false;
                    }

                }
            }
            if (sameProductType) {
                DelegateWizard wizard = new DelegateWizard(objects);
                WizardDialog dialog = new WizardDialog(getShell(), wizard);
                dialog.open();
            } else {
                for (i = 0; i < objects.length; i++) {
                    try {
                        IDimensionsObjectEditHandler handler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.REQUEST);
                        if (handler != null) {
                            handler.openEditor(objects[i], DelegatesPage.ID);
                        }
                    } catch (CoreException e) {
                        DMChangeUiPlugin.getDefault().handle(e);
                    }
                }
            }
        } else {
            Object object = ssel.getFirstElement();
            if (object instanceof ChangeDocumentAdapter) {
                try {
                    IDimensionsObjectEditHandler handler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.REQUEST);
                    if (handler != null) {
                        handler.openEditor((ChangeDocumentAdapter) object, DelegatesPage.ID);
                    }
                } catch (CoreException e) {
                    DMChangeUiPlugin.getDefault().handle(e);
                }
            }
        }
    }

}

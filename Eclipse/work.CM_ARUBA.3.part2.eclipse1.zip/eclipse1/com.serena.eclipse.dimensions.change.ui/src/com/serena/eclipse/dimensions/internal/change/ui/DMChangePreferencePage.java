/*
 * @DMChangePreferencePage.java, created on May 5, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;

/**
 * Issue management preference page.
 *
 * @author V.Grishchenko
 */
public class DMChangePreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {

    /**
     * @param style
     */
    public DMChangePreferencePage() {
        super(GRID);
        setDescription(Messages.preferences_change_title);
        setPreferenceStore(DMChangeUiPlugin.getDefault().getPreferenceStore());
    }

    @Override
    protected void createFieldEditors() {

        addField(new RadioGroupFieldEditor(IDMChangePreferences.CHANGE_DOC_LIST_DISPLAY, Messages.preferences_change_showIn, 1,
                new String[][] {
                        { Messages.preferences_change_showInEditor, IDMChangePreferences.CHANGE_DOC_LIST_DISPLAY_EDITOR_VAL },
                        { Messages.preferences_change_showInView, IDMChangePreferences.CHANGE_DOC_LIST_DISPLAY_VIEW_VAL } },
                getFieldEditorParent(), true));
    }

    @Override
    public void init(IWorkbench workbench) {
    }

    @Override
    public boolean performOk() {
        boolean ok = super.performOk();
        DMChangeUiPlugin.getDefault().savePluginPreferences();
        return ok;
    }
}

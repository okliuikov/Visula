/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.Part;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.StringPath;
import com.serena.dmfile.dto.Pair;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.NumberAwareStringComparator;
import com.serena.eclipse.dimensions.core.util.SpaceCommaStringSplitter;
import com.serena.eclipse.dimensions.core.util.SpaceCommaStringSplitter.ResultCase;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;

/**
 * @author abollmann
 *
 *         Attributes page in the new object wizard
 */
public class NewChangeDocumentRelatePage extends WizardPage {
    private DimensionsConnectionDetailsEx conn;
    private String selectedProduct;
    private Button partButton;
    private Button projectButton;
    private Text partListText;
    private Text projectText;
    private Request basedOnChdoc;
    // do we have a based on change document
    private Project projectToRelate = null;
    private List<Part> partsToRelate = new ArrayList<Part>();

    public NewChangeDocumentRelatePage(String pageName, String title, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx conn, Request basedOn) {
        super(pageName, title, titleImage);
        setDescription(Messages.new_relate_description);
        this.conn = conn;
        this.basedOnChdoc = basedOn;
        processBasedOn();
    }

    private void processBasedOn() {
        Runnable r = new Runnable() {

            @Override
            public void run() {
                if (basedOnChdoc != null) {
                    try {
                        final Session session = conn.openSession(new NullProgressMonitor());

                        session.run(new ISessionRunnable() {

                            @Override
                            public void run() throws Exception {
                                DimensionsObjectFactory factory = session.getObjectFactory();
                                // get related project
                                basedOnChdoc.queryAttribute(SystemAttributes.PROJECT);
                                if (!StringPath.isNullorEmpty((String) basedOnChdoc.getAttribute(SystemAttributes.PROJECT))) {
                                    projectToRelate = factory.getProject((String) basedOnChdoc.getAttribute(SystemAttributes.PROJECT));
                                }

                                // parts
                                basedOnChdoc.flushRelatedObjects(Part.class, true);
                                List<?> relatedObjects = basedOnChdoc.getChildParts(null);
                                basedOnChdoc.flushRelatedObjects(Part.class, true);
                                List<Part> primeParts = new ArrayList<Part>();
                                for (int i = 0; i < relatedObjects.size(); i++) {
                                    DimensionsRelatedObject relObject = (DimensionsRelatedObject) relatedObjects.get(i);
                                    Part part = (Part) relObject.getObject();
                                    primeParts.add(part);
                                }
                                partsToRelate = primeParts;
                            }

                        }, new NullProgressMonitor());

                    } catch (DMException e) {
                        DMChangeUiPlugin.getDefault().handle(e);
                    }
                }
            }
        };
        BusyIndicator.showWhile(Display.getDefault(), r);

        fillText();
    }

    private void fillText() {
        if (partListText != null && projectText != null) {
            StringBuilder sb = new StringBuilder();
            for (Iterator<Part> iterator = partsToRelate.iterator(); iterator.hasNext();) {
                Part part = iterator.next();
                sb.append(part.getName());
                if (iterator.hasNext()) {
                    sb.append(", "); //$NON-NLS-1$
                }
            }

            partListText.setText(sb.toString());
            projectText.setText(projectToRelate != null ? projectToRelate.getName() : "");//$NON-NLS-1$
        }
    }

    @Override
    public void createControl(Composite parent) {
        NewChangeDocumentBasicPage page = (NewChangeDocumentBasicPage) getWizard().getPage(Messages.new_basic_pageName);
        if (page != null) {
            selectedProduct = page.getChdocProduct();
        }

        if (basedOnChdoc == null) {
            // read from based on page
            NewChangeDocumentBasedOnPage bop = (NewChangeDocumentBasedOnPage) getWizard().getPage(Messages.new_baseIssueOn_pageName);
            basedOnChdoc = bop.getSelectedIssue();
            if (basedOnChdoc != null) {
                processBasedOn();
            }

        }
        Composite composite = new Composite(parent, SWT.NULL);
        composite.getBackground();
        GridLayout gridLayout = new GridLayout();
        gridLayout.numColumns = 3;
        composite.setLayout(gridLayout);
        GridData gridData = new GridData(GridData.FILL_BOTH | GridData.HORIZONTAL_ALIGN_BEGINNING);
        composite.setLayoutData(gridData);
        setControl(composite);

        Label partLabel = new Label(composite, SWT.NONE);
        partLabel.setText(Messages.new_relate_part);
        gridData = new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING);
        partLabel.setLayoutData(gridData);

        partListText = new Text(composite, SWT.SINGLE | SWT.BORDER);
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        partListText.setLayoutData(gridData);

        partButton = new Button(composite, SWT.PUSH);
        partButton.setText("Find..."); //$NON-NLS-1$
        partButton.addSelectionListener(new PartListener());

        Label projectLabel = new Label(composite, SWT.NONE);
        projectLabel.setText(Messages.new_relate_project);
        gridData = new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING);
        projectLabel.setLayoutData(gridData);

        projectText = new Text(composite, SWT.SINGLE | SWT.BORDER);
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        projectText.setLayoutData(gridData);

        projectButton = new Button(composite, SWT.PUSH);
        projectButton.setText("Find..."); //$NON-NLS-1$
        projectButton.addSelectionListener(new ProjectListener());

        setControl(composite);
        fillText();
    }

    public void updateProduct(String productId) {
        this.selectedProduct = productId;
    }

    public void updateBasedOn(Request basedOn) {
        basedOnChdoc = basedOn;
        processBasedOn();
        fillText();
    }

    List<String> getSelectedParts() {
        Collection<String> parts = null;

        if (partListText != null) { // page created
            String partList = UIUtils.safeGetText(partListText).trim().toUpperCase();
            parts = SpaceCommaStringSplitter.splitUnique(partList, ResultCase.UPPER, NumberAwareStringComparator.INSTANCE);
        } else { // page not created
            parts = new TreeSet<String>(NumberAwareStringComparator.INSTANCE);
            for (Part part : partsToRelate) {
                parts.add(part.getName());
            }
        }

        return new ArrayList<String>(parts);
    }

    String getSelectedProject() {
        if (projectText != null) { // page created
            return UIUtils.safeGetText(projectText).trim().toUpperCase();
        } else if (projectToRelate != null) { // page not created
            return projectToRelate.getName();
        }
        return "";//$NON-NLS-1$
    }

    private class PartListener implements SelectionListener {

        @Override
        public void widgetSelected(SelectionEvent e) {
            // Open Design Part Selection Wizard
            FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.PART, conn,
                    selectedProduct, false, false);
            if (dialog.open() == Window.OK) {

                partsToRelate.clear();

                List<Pair<String, ?>> pairs = dialog.getFindResult().getNameObjectPairs();

                StringBuilder sb = new StringBuilder();
                for (Iterator<Pair<String, ?>> iterator = pairs.iterator(); iterator.hasNext();) {
                    Pair<String, ?> pair = iterator.next();
                    partsToRelate.add((Part) pair.getSecond());
                    sb.append(pair.getFirst());
                    if (iterator.hasNext()) {
                        sb.append(", "); //$NON-NLS-1$
                    }
                }

                partListText.setText(sb.toString());
            }
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }
    }

    private class ProjectListener implements SelectionListener {

        @Override
        public void widgetSelected(SelectionEvent e) {
            // Open Baseline Selection Wizard
            FindObjectWizardDialog dialog = new FindObjectWizardDialog(getControl().getShell(), IDMConstants.PROJECT, conn,
                    selectedProduct, true, false, conn.isOnlyStreamsActive(), conn.isOnlyProjectsActive());
            if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {
                Pair<String, ?> pair = dialog.getFindResult().getNameObjectPairs().get(0);
                projectToRelate = (Project) pair.getSecond();
                projectText.setText(pair.getFirst());
            }
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }
    }

}

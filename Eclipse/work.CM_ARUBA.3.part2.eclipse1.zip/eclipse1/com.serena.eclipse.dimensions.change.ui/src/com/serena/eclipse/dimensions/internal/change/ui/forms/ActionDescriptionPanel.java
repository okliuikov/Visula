/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.forms;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.FormColors;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.model.IActionDescriptionModel;
import com.serena.eclipse.dimensions.internal.ui.IDMPreferences;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.forms.DimensionsFormPart;
import com.serena.eclipse.dimensions.internal.ui.forms.IEditablePart;

/**
 * @author abollmann
 *
 *         Class to create the panel for the Attachment dialog/editor
 */
public class ActionDescriptionPanel extends DimensionsFormPart implements IEditablePart, IPropertyChangeListener {
    final IActionDescriptionModel model;
    private Composite parent;
    private Control originalDescriptionCntrl;
    private Text newDescriptionText;
    private Section section;

    public ActionDescriptionPanel(IManagedForm managedForm, IActionDescriptionModel model, Composite parent) {
        super(managedForm, model);
        this.model = model;
        this.parent = parent;
        if (model.isLoaded()) {
            createControl();
        }
    }

    private void createControl() {
        // create Title Section
        section = getToolkit().createSection(parent, ExpandableComposite.TITLE_BAR | Section.DESCRIPTION);
        section.setText(Messages.actionDesc_section);
        // need to make the section occupy the rest of the available space but
        // don't want it to be too tall (when table has many rows) as it will
        // enable vertical page scrollbar when the table scrollbar needed instead.
        // Set size hints to something obviously small and let parent's grid
        // layout figure out the rest
        GridData gd = UIUtils.setGridData(section, GridData.FILL_BOTH);
        gd.widthHint = gd.heightHint = 10;

        Composite comp = getToolkit().createComposite(section, SWT.NONE);// SWT.V_SCROLL|SWT.H_SCROLL);
        UIUtils.setGridLayout(comp, 2);

        section.setClient(comp);

        Label originalDescription = getToolkit().createLabel(comp, Messages.actionDesc_origLabel);
        originalDescription.setForeground(getToolkit().getColors().getColor(FormColors.TITLE));
        gd = UIUtils.setGridData(originalDescription, GridData.VERTICAL_ALIGN_BEGINNING);

        if (model.isTextPlain()) {
            originalDescriptionCntrl = createText(comp);
        } else if (model.isTextHtml()) {
            originalDescriptionCntrl = createBrowser(comp);
        } else if (model.isRTF()) {
            originalDescriptionCntrl = createRtfComp(comp);
        } else {
            originalDescriptionCntrl = createText(comp);
        }

        gd = UIUtils.setGridData(originalDescriptionCntrl, GridData.FILL_BOTH);
        gd.heightHint = 150;

        Label newDescription = getToolkit().createLabel(comp, Messages.actionDesc_newLabel);
        newDescription.setForeground(getToolkit().getColors().getColor(FormColors.TITLE));
        gd = UIUtils.setGridData(newDescription, GridData.VERTICAL_ALIGN_BEGINNING);

        newDescriptionText = getToolkit().createText(comp, Utils.EMPTY_STRING, SWT.WRAP | SWT.V_SCROLL);
        newDescriptionText.setFont(JFaceResources.getFontRegistry().get(IDMPreferences.ACTION_DESCR_FONT));

        gd = UIUtils.setGridData(newDescriptionText, GridData.FILL_BOTH);
        gd.heightHint = 50;

        newDescriptionText.addModifyListener(new MyModifyListener());

        getToolkit().paintBordersFor(comp);
    }

    void fillDescription() {
        // empty any previously entered new description as this has been committed to the database if
        // fillDescription is called.
        newDescriptionText.setText(""); //$NON-NLS-1$
        String actionDescription = model.getCompleteActionDescription();
        if (actionDescription == null) {
            actionDescription = ""; //$NON-NLS-1$
        }
        if (model.isTextHtml()) {
            ((Browser) originalDescriptionCntrl).setText(actionDescription);
        } else if (model.isTextPlain()) {
            ((Text) originalDescriptionCntrl).setText(actionDescription);
        } else if (model.isRTF()) {
            ((Text) originalDescriptionCntrl).setText(Messages.actionDesc_rtfMessage);
        }
    }

    Text createText(Composite comp) {
        Text text = getToolkit().createText(comp, "", SWT.READ_ONLY | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL); //$NON-NLS-1$
        text.setFont(JFaceResources.getFontRegistry().get(IDMPreferences.ACTION_DESCR_FONT));
        return text;
    }

    Browser createBrowser(Composite comp) {
        Browser browser = new Browser(comp, SWT.NONE);
        browser.setData(FormToolkit.KEY_DRAW_BORDER, FormToolkit.TEXT_BORDER);
        return browser;
    }

    Text createRtfComp(Composite comp) {
        Text text = getToolkit().createText(comp, "", SWT.READ_ONLY | SWT.MULTI | SWT.WRAP); //$NON-NLS-1$
        return text;
    }

    @Override
    public void refresh() {
        if (section != null) {
            section.dispose();
        }
        createControl();
        fillDescription();
        super.refresh();
    }

    /**
     * @return Returns the panel.
     */
    public Composite getPanel() {
        return parent;
    }

    @Override
    public void fireSaveNeeded() {
    }

    @Override
    public void cancelEdit() {
    }

    @Override
    public void propertyChange(PropertyChangeEvent event) {
    }

    class MyModifyListener implements ModifyListener {

        @Override
        public void modifyText(ModifyEvent e) {
            model.addActionDescription(newDescriptionText.getText());
        }
    }

}

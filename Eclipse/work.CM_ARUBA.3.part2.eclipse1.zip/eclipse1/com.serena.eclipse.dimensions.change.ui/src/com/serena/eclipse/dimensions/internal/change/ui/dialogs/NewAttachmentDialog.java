/*
 * Created on Jun 24, 2005
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.serena.eclipse.dimensions.internal.change.ui.model.AttachmentDetails;
import com.serena.eclipse.dimensions.internal.change.ui.model.IAttachmentsModel;
import com.serena.eclipse.dimensions.internal.ui.Messages;

/**
 * @author abollmann
 *
 */
public class NewAttachmentDialog extends Dialog {
    private IAttachmentsModel model;
    private Text textFileName;
    private Text textDescription;
    private Text textId;

    public NewAttachmentDialog(Shell parentShell, IAttachmentsModel model) {
        super(parentShell);
        this.model = model;
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        GridLayout layout = new GridLayout();
        layout.numColumns = 3;
        composite.setLayout(layout);

        // Set the title
        getShell().setText(Messages.attachment_new_title);

        // browse file name
        Label labelFileName = new Label(composite, SWT.NONE | SWT.BOLD);
        labelFileName.setText(Messages.attachment_fileName);
        Font font = labelFileName.getFont();
        FontData data[] = font.getFontData();
        data[0].setStyle(SWT.BOLD);
        font = new Font(getShell().getDisplay(), data[0]);
        labelFileName.setFont(font);
        textFileName = new Text(composite, SWT.BORDER | SWT.SINGLE);
        textFileName.setText(""); //$NON-NLS-1$
        GridData gridData = new GridData();
        gridData.widthHint = 300;
        gridData.horizontalAlignment = GridData.FILL;
        gridData.grabExcessHorizontalSpace = true;
        textFileName.setLayoutData(gridData);
        Button browseButton = new Button(composite, SWT.NONE);
        browseButton.setText("..."); //$NON-NLS-1$
        browseButton.addMouseListener(new FileBrowseListener());

        // Attach as
        Label labelId = new Label(composite, SWT.NONE);
        labelId.setText(Messages.attachment_new_attachas);
        Font font2 = labelId.getFont();
        FontData data2[] = font2.getFontData();
        data2[0].setStyle(SWT.BOLD);
        font2 = new Font(getShell().getDisplay(), data2[0]);
        labelId.setFont(font2);
        textId = new Text(composite, SWT.BORDER | SWT.SINGLE);
        GridData gridData3 = new GridData();
        gridData3.widthHint = 150;
        gridData3.horizontalAlignment = GridData.FILL;
        gridData3.grabExcessHorizontalSpace = false;
        textId.setLayoutData(gridData3);
        Button emptyButton = new Button(composite, SWT.NONE);
        emptyButton.setVisible(false);

        // description
        Label labelDescription = new Label(composite, SWT.NONE);
        labelDescription.setText(Messages.attachment_description);
        textDescription = new Text(composite, SWT.BORDER | SWT.SINGLE);
        GridData gridData2 = new GridData();
        gridData2.widthHint = 150;
        gridData2.horizontalAlignment = GridData.FILL;
        gridData2.grabExcessHorizontalSpace = false;
        textDescription.setLayoutData(gridData2);
        emptyButton = new Button(composite, SWT.NONE);
        emptyButton.setVisible(false);

        return composite;
    }

    @Override
    protected void okPressed() {
        setReturnCode(OK);
        String fileName = textFileName.getText();
        if (fileName.length() == 0) {
            MessageBox message = new MessageBox(getShell(), SWT.ICON_ERROR);
            message.setText(Messages.attachment_error);
            message.setMessage(Messages.attachment_error_nofileselected);
            message.open();
            return;
        }
        String description = textDescription.getText();
        String id = textId.getText();
        AttachmentDetails details = new AttachmentDetails();
        details.setDescription(description);
        details.setFileName(fileName);
        details.setName(id);
        model.attach(details);
        close();
    }

    class FileBrowseListener implements MouseListener {
        @Override
        public void mouseDown(MouseEvent e) {
            String fileName;
            FileDialog fileDialog = new FileDialog(getShell());
            String fullFileName = fileDialog.open();
            if (fullFileName == null) {
                return;
            }

            textFileName.setText(fullFileName);
            textFileName.redraw();
            int index = fullFileName.lastIndexOf("\\"); //$NON-NLS-1$
            if (index == -1) {
                index = fullFileName.lastIndexOf("/"); //$NON-NLS-1$
            }
            if (index == -1) {
                fileName = fullFileName;
            } else {
                fileName = fullFileName.substring(index + 1);
            }
            textId.setText(fileName);
        }

        @Override
        public void mouseUp(MouseEvent e) {
        }

        @Override
        public void mouseDoubleClick(MouseEvent e) {
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ECustomChangeDocumentList;
import com.serena.eclipse.dimensions.core.RequestListList;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;

/**
 * @author abollmann
 */
public class DeleteCustomListAction extends DimensionsAction {

    public DeleteCustomListAction() {
        super(true);
    }

    @Override
    public void run(IAction action) {
        boolean jobs = false, customLists = false;
        final List selectedLists = getSelection().toList();
        int selectedNr = selectedLists.size();
        for (int i = 0; i < selectedLists.size(); i++) {
            ECustomChangeDocumentList selection = (ECustomChangeDocumentList) selectedLists.get(i);
            jobs = jobs || selection.isList(ChangeDocumentList.JOB);
            customLists = customLists || !selection.isList(ChangeDocumentList.JOB);
        }
        String title = Messages.delCustomList_title;
        String question;
        if (jobs && !customLists) {
            if (selectedNr == 1) {
                question = Messages.delJob_single_question;
            } else {
                question = Messages.delJob_multiple_question;
            }
        } else if (customLists && !jobs) {
            if (selectedNr == 1) {
                question = Messages.delCustomList_single_question;
            } else {
                question = Messages.delCustomList_multiple_question;
            }
        } else {
            question = Messages.delCustomListJob_question;
        }

        if (MessageDialog.openConfirm(getShell(), title, question)) {
            try {
                PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                    @Override
                    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                        monitor.beginTask(Messages.delCustomList_task, selectedLists.size() * 10);
                        try {
                            ArrayList errors = new ArrayList();
                            for (int i = 0; i < selectedLists.size(); i++) {
                                ECustomChangeDocumentList selection = (ECustomChangeDocumentList) selectedLists.get(i);
                                RequestListList rll = RequestListList.getList(selection.getConnectionDetails());
                                try {
                                    rll.deleteList(selection,
                                            Utils.subMonitorFor(monitor, 10, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK));
                                } catch (DMException e) {
                                    errors.add(e);
                                }
                            }
                            if (!errors.isEmpty()) {
                                DMException dme;
                                if (errors.size() == 1) {
                                    dme = (DMException) errors.get(0);
                                } else {
                                    IStatus[] stats = new IStatus[errors.size()];
                                    for (int i = 0; i < errors.size(); i++) {
                                        stats[i] = ((DMException) errors.get(i)).getStatus();
                                    }
                                    MultiStatus ms = new MultiStatus(DMChangeUiPlugin.ID, 0, stats, Messages.delCustomList_msMsg,
                                            null);
                                    dme = new DMException(ms);
                                }
                                throw new InvocationTargetException(dme);
                            }
                        } finally {
                            monitor.done();
                        }
                    }
                });
            } catch (InvocationTargetException e) {
                DMChangeUiPlugin.getDefault().handle(e, getShell(), Messages.delCustomList_errTitle, Messages.delCustomList_errMsg);
            } catch (InterruptedException ignore) {
            }
        }
    }

}

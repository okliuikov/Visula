/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.DimensionsRuntimeException;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.RequestAttachment;
import com.serena.dmclient.api.RequestAttachmentDetails;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.model.EditableModel;

/**
 * @author V.Grishchenko
 */
public class AttachmentsModel extends EditableModel implements IAttachmentsModel {

    private List apiAttachments;
    private List attachments;
    private Request changeDocument;

    private DimensionsResult attachResult;
    private DimensionsResult[] deleteResults;
    private DimensionsResult[] updateResults;
    private DimensionsResult saveResult;

    public AttachmentsModel(APIObjectAdapter object) {
        super(object);
        changeDocument = (Request) object.getAPIObject();
        initResults();
    }

    private void initResults() {
        attachResult = null;
        saveResult = null;
        deleteResults = updateResults = new DimensionsResult[0];
    }

    @Override
    public void reset() {
        apiAttachments = null;
        attachments = null;
        initResults();
        super.reset();
    }

    @Override
    protected long doSave(IProgressMonitor pm) throws DMException {
        final IProgressMonitor _pm = Utils.monitorFor(pm);
        _pm.beginTask(Messages.attachments_save, 100);
        if (attachments == null) {
            return getTimeStamp();
        }

        final long[] tsHolder = new long[1];
        try {
            Session session = getUnderlyingObject().getConnectionDetails().openSession(Utils.subMonitorFor(_pm, 20)); // 20
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    initResults();

                    DimensionsResult result;

                    int newAttachmentsNr = 0;
                    int updateAttachmentsNr = 0;
                    int newDetailsNr = 0;
                    int updateDetailsNr = 0;
                    for (int i = 0; i < attachments.size(); i++) {
                        if (((AttachmentDetails) attachments.get(i)).getModus() == AttachmentDetails.NEW) {
                            newAttachmentsNr++;
                        }
                        if (((AttachmentDetails) attachments.get(i)).getModus() == AttachmentDetails.UPDATED) {
                            updateAttachmentsNr++;
                        }
                    }

                    // delete the attachments first
                    int deleteAttachmentsNr = apiAttachments.size() - attachments.size() + newAttachmentsNr;
                    deleteResults = new DimensionsResult[deleteAttachmentsNr];

                    int deleteDetailsNr = 0;
                    for (int i = 0; i < apiAttachments.size(); i++) {
                        RequestAttachment apiAttachment = (RequestAttachment) apiAttachments.get(i);
                        int index = findAttachment(apiAttachment.getName());
                        if (index == -1) {
                            // this is an attachment that has to be deleted
                            try {
                                result = apiAttachment.delete();
                            } catch (DimensionsRuntimeException e) {
                                throw new DMException(IStatus.ERROR, 0, e.getCause().getMessage(), e);
                            }
                            deleteResults[deleteDetailsNr] = result;
                            deleteDetailsNr++;
                        }
                    }
                    _pm.worked(20); // 40

                    // attach and update
                    RequestAttachmentDetails[] allDetails = new RequestAttachmentDetails[newAttachmentsNr];
                    updateResults = new DimensionsResult[updateAttachmentsNr];
                    for (int i = 0; i < attachments.size(); i++) {
                        AttachmentDetails details = (AttachmentDetails) attachments.get(i);
                        if (details.getModus() == AttachmentDetails.NEW) {
                            RequestAttachmentDetails newDetails = new RequestAttachmentDetails();
                            newDetails.setName(details.getName());
                            newDetails.setFileName(details.getFileName());
                            newDetails.setDescription(details.getDescription());
                            allDetails[newDetailsNr] = newDetails;
                            newDetailsNr++;
                        }
                        if (details.getModus() == AttachmentDetails.UPDATED) {
                            int index = findApiAttachment(details.getName());
                            if (index != -1) {
                                RequestAttachment apiAttach = (RequestAttachment) apiAttachments.get(index);
                                try {
                                    result = apiAttach.updateDescription(details.getDescription());
                                } catch (DimensionsRuntimeException e) {
                                    throw new DMException(IStatus.ERROR, 0, e.getCause().getMessage(), e);
                                }
                                updateResults[updateDetailsNr] = result;
                                updateDetailsNr++;
                            }
                        }
                    }
                    _pm.worked(20); // 60
                    // now attach all attachments together
                    try {
                        attachResult = changeDocument.attach(allDetails);
                    } catch (DimensionsRuntimeException e) {
                        throw new DMException(IStatus.ERROR, 0, e.getCause().getMessage(), e);
                    }
                    _pm.worked(20); // 80

                    _pm.worked(20); // 100
                    tsHolder[0] = getTimeStamp();
                }
            }, _pm);
        } finally {
            _pm.done();
        }
        return tsHolder[0];
    }

    @Override
    protected long doLoad(IProgressMonitor pm) throws DMException {
        final IProgressMonitor _pm = Utils.monitorFor(pm);
        checkCanceled(_pm);
        // 100 ticks: 20 - session, 20 - timestamp, 30 - query attahments,
        // 30 - load attachment properties as it seems doing dbio
        _pm.beginTask(Messages.attachments_fetch, 100);
        try {
            Session session = getUnderlyingObject().getConnectionDetails().openSession(Utils.subMonitorFor(_pm, 20)); // 20
            checkCanceled(_pm);
            final long[] timeStamp = new long[1];
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    // fetch timestamp first as it is safer to have false
                    // "out of sync" than false "in sync"
                    checkCanceled(_pm);
                    timeStamp[0] = fetchTimeStamp();
                    _pm.worked(20);

                    // load attachments
                    checkCanceled(_pm);
                    changeDocument.queryRequestAttachments();
                    apiAttachments = changeDocument.getRequestAttachments();
                    _pm.worked(30);
                    if (apiAttachments == null) {
                        apiAttachments = Collections.EMPTY_LIST;
                    }
                    attachments = new ArrayList();
                    for (Iterator attIter = apiAttachments.iterator(); attIter.hasNext();) {
                        RequestAttachment attachment = (RequestAttachment) attIter.next();
                        AttachmentDetails newEntry = new AttachmentDetails();
                        newEntry.setName(attachment.getName());
                        newEntry.setSize(attachment.getFileLength());
                        newEntry.setModus(AttachmentDetails.UNCHANGED);
                        newEntry.setDescription(attachment.getDescription());
                        attachments.add(newEntry);
                    }
                    _pm.worked(30);
                }
            }, _pm);
            return timeStamp[0];
        } finally {
            _pm.done();
        }
    }

    @Override
    public AttachmentDetails[] getAttachments() {
        if (attachments == null) {
            return new AttachmentDetails[0];
        }
        return (AttachmentDetails[]) attachments.toArray(new AttachmentDetails[attachments.size()]);
    }

    @Override
    public void attach(AttachmentDetails details) {
        if (attachments == null) {
            attachments = new ArrayList();
        }
        details.setModus(AttachmentDetails.NEW);
        attachments.add(details);
        setDirty(true);
    }

    @Override
    public void removeAttachment(String id) {
        if (attachments == null) {
            return;
        }
        // remove the attachment from the internal list
        int found = -1;
        for (int i = 0; i < attachments.size(); i++) {
            AttachmentDetails details = (AttachmentDetails) attachments.get(i);
            if (details.getName() == id) {
                found = i;
            }
        }
        attachments.remove(found);
        setDirty(true);
    }

    @Override
    public void updateAttachment(String id, String newDescription) {
        if (attachments == null) {
            return;
        }
        for (int i = 0; i < attachments.size(); i++) {
            AttachmentDetails details = (AttachmentDetails) attachments.get(i);
            if (details.getName() == id) {
                details.setDescription(newDescription);
                if (details.getModus() != AttachmentDetails.NEW) {
                    // if the attachment was added beforehand, and then the description is updated
                    // in that case the modus should still be NEW so that
                    // it is created on save
                    details.setModus(AttachmentDetails.UPDATED);
                }
            }
        }
        setDirty(true);
    }

    @Override
    public DimensionsResult getAttachResult() {
        return attachResult;
    }

    @Override
    public DimensionsResult[] getDeleteResults() {
        return deleteResults;
    }

    @Override
    public DimensionsResult[] getUpdateResults() {
        return updateResults;
    }

    /** save to file result from last save to file **/
    @Override
    public DimensionsResult getSaveResult() {
        return saveResult;
    }

    @Override
    public void saveAttachmentToFile(final String id, final String localFileName) throws DMException {
        Session session = getUnderlyingObject().getConnectionDetails().openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {

                int index = findApiAttachment(id);
                RequestAttachment attachment = (RequestAttachment) apiAttachments.get(index);
                try {
                    saveResult = attachment.saveToFile(localFileName);
                } catch (DimensionsRuntimeException e) {
                    throw new DMException(IStatus.ERROR, 0, e.getCause().getMessage(), e);
                }

            }
        });
    }

    /*
     * finds the api attachment in the list of api attachments identified by the name
     * @returns -1 if not found
     */
    private int findApiAttachment(String id) {
        for (int i = 0; i < apiAttachments.size(); i++) {
            RequestAttachment attachment = (RequestAttachment) apiAttachments.get(i);
            if (attachment.getName().equals(id)) {
                return i;
            }
        }
        return -1;
    }

    /*
     * finds the attachment in the list of attachments identified by the name
     * @returns -1 if not found
     */
    private int findAttachment(String id) {
        for (int i = 0; i < attachments.size(); i++) {
            AttachmentDetails attachment = (AttachmentDetails) attachments.get(i);
            if (attachment.getName().equals(id)) {
                return i;
            }
        }
        return -1;
    }

    /** Returns the mime type for the attachment identified by the id */
    @Override
    public String getMimeType(String id) {
        int index = findApiAttachment(id);
        RequestAttachment attachment = (RequestAttachment) apiAttachments.get(index);
        String mimeType = attachment.getMimeType();
        return mimeType;
    }

    @Override
    public boolean isInSyncOnSave() {
        return false; // need to refresh after save
    }
}

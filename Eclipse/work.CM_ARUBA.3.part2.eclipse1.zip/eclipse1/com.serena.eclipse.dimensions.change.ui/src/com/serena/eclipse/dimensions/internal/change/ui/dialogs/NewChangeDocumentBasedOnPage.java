/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.collections.RequestRelationshipTypes;
import com.serena.dmclient.objects.Product;
import com.serena.dmclient.objects.RelationshipClass;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * @author abollmann
 *
 */
public class NewChangeDocumentBasedOnPage extends WizardPage {
    private DimensionsConnectionDetailsEx conn;
    private Button basedOnButton;
    private Combo basedOnCombo, relationCombo;
    private ChangeDocumentAdapter basedOnChdoc;
    private String basedOnChdocId;
    private IWizard wizard;
    private List pendingChdocsForProduct;

    public NewChangeDocumentBasedOnPage(String pageName, String title, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx conn, ChangeDocumentAdapter basedOnChdoc) {
        super(pageName, title, titleImage);
        setDescription(Messages.new_baseIssueOn_description);
        this.conn = conn;
        this.basedOnChdoc = basedOnChdoc;
        if (basedOnChdoc != null) {
            basedOnChdoc.getAPIObject().queryAttribute(SystemAttributes.OBJECT_ID);
            basedOnChdocId = (String) basedOnChdoc.getAPIObject().getAttribute(SystemAttributes.OBJECT_ID);
        } else {
            basedOnChdocId = ""; //$NON-NLS-1$
        }
    }

    @Override
    public void createControl(Composite parent) {
        this.wizard = getWizard();
        Composite composite = new Composite(parent, SWT.NULL);
        UIUtils.setGridLayout(composite, 2);

        basedOnButton = new Button(composite, SWT.CHECK);
        basedOnButton.setText(Messages.new_baseIssueOn_baseOn);
        basedOnButton.addSelectionListener(new CheckListener());

        basedOnCombo = new Combo(composite, SWT.NONE);
        basedOnCombo.addSelectionListener(new BasedOnListener());
        UIUtils.setGridData(basedOnCombo, GridData.FILL_HORIZONTAL).widthHint = 70;

        Label relateLabel = new Label(composite, SWT.NONE);
        relateLabel.setText(Messages.new_baseIssueOn_relate);
        UIUtils.setGridData(relateLabel, GridData.HORIZONTAL_ALIGN_END);

        relationCombo = new Combo(composite, SWT.NONE);

        fillCombos(null);
        setControl(composite);

    }

    List getPendingChdocs(final String productName) {
        final List pendingChdocs = new ArrayList();
        Runnable r = new Runnable() {

            @Override
            public void run() {
                try {
                    final Session session = conn.openSession(null);
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            Filter filter = new Filter();
                            try {
                                filter.criteria().add(
                                        new Filter.Criterion(SystemAttributes.PRODUCT_NAME, productName, Filter.Criterion.EQUALS));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            List temp = session.getObjectFactory().getCurrentUser().getPendingRequests(filter);
                            pendingChdocs.addAll(temp);
                        }
                    }, new NullProgressMonitor());
                } catch (DMException e) {
                    e.printStackTrace();
                }

            }
        };
        BusyIndicator.showWhile(Display.getDefault(), r);
        return pendingChdocs;
    }

    String[] getRelationships(final String productName) {
        final List<String> ret = new LinkedList<String>();

        Runnable r = new Runnable() {

            @Override
            public void run() {
                try {
                    final Session session = conn.openSession(null);
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            Product product = conn.getProduct(productName, null);

                            RequestRelationshipTypes infoTypes = product.getRequestRelationshipTypes(RelationshipClass.INFO);
                            RequestRelationshipTypes depTypes = product.getRequestRelationshipTypes(RelationshipClass.DEPENDENT);

                            Iterator depIterator = depTypes.iterator();
                            while (depIterator.hasNext()) {
                                String relationshipName = (String) depIterator.next();
                                ret.add(relationshipName);
                            }

                            Iterator infoIterator = infoTypes.iterator();
                            while (infoIterator.hasNext()) {
                                String relationshipName = (String) infoIterator.next();
                                ret.add(relationshipName);
                            }
                        }
                    }, new NullProgressMonitor());
                } catch (DMException e) {
                    e.printStackTrace();
                    DMUIPlugin.getDefault().handle(e);
                }
            }
        };

        BusyIndicator.showWhile(Display.getDefault(), r);

        return ret.toArray(new String[0]);
    }

    private void fillCombos(String productId) {
        if (relationCombo == null) {
            // Dialog has not been created yet
            return;
        }
        if (productId == null) {
            NewChangeDocumentBasicPage page = (NewChangeDocumentBasicPage) getWizard().getPage(Messages.new_basic_pageName);
            productId = page.getChdocProduct();
        }

        String rels[] = getRelationships(productId);
        relationCombo.setItems(rels);
        relationCombo.add(Messages.new_baseIssueOn_dependent, 0);
        relationCombo.add(Messages.new_baseIssueOn_information, 1);
        relationCombo.select(0); // select Dependendent

        basedOnCombo.removeAll();
        pendingChdocsForProduct = getPendingChdocs(productId);
        if (pendingChdocsForProduct == null) {
            return;
        }

        Runnable r = new Runnable() {

            @Override
            public void run() {
                try {
                    final Session session = conn.openSession(null);
                    session.run(new ISessionRunnable() {

                        @Override
                        public void run() throws Exception {
                            BulkOperator bo = session.getObjectFactory().getBulkOperator(pendingChdocsForProduct);
                            bo.queryAttribute(SystemAttributes.TITLE);
                        }
                    }, new NullProgressMonitor());
                } catch (DMException e) {
                    DMChangeUiPlugin.getDefault().handle(e);
                }
            }
        };
        BusyIndicator.showWhile(Display.getDefault(), r);

        for (int i = 0; i < pendingChdocsForProduct.size(); i++) {
            Request chdoc = (Request) pendingChdocsForProduct.get(i);
            String text = chdoc.getName() + "   "; //$NON-NLS-1$
            String title = (String) chdoc.getAttribute(SystemAttributes.TITLE);
            if (title != null) {
                text += title;
            }
            basedOnCombo.add(text);

            if (basedOnChdocId.equals(chdoc.getName())) {
                basedOnCombo.select(i);
                basedOnButton.setSelection(true);
            }
        }
    }

    public void updateProduct(String productId) {
        fillCombos(productId);
        setControl(null);
    }

    public Request getSelectedIssue() {
        // test to see if button enabled
        if (basedOnButton != null) {
            if (!basedOnButton.getSelection()) {
                return null;
            }
        }
        if (basedOnCombo == null) {
            if (basedOnChdoc != null) {
                return basedOnChdoc.getChangeDocument(); // Dialog has not been created yet so return the passed in based on chdoc
                                                         // if available
            } else {
                return null;
            }
        }
        if (basedOnCombo.getSelectionIndex() != -1) {
            int index = basedOnCombo.getSelectionIndex();
            if (pendingChdocsForProduct == null) {
                return null;
            }
            return (Request) pendingChdocsForProduct.get(index);
        } else {
            return null;
        }
    }

    public String getSelectedRelation() {
        if (basedOnButton != null) {
            if (!basedOnButton.getSelection()) {
                return ""; //$NON-NLS-1$
            }
        }
        if (relationCombo == null) {
            return Messages.new_baseIssueOn_dependent;
        }
        if (relationCombo.getSelectionIndex() != -1) {
            return relationCombo.getItem(relationCombo.getSelectionIndex());
        } else {
            return ""; //$NON-NLS-1$
        }
    }

    @Override
    public IWizardPage getNextPage() {
        boolean canFlip = canFlipToNextPage();
        wizard.getContainer().updateButtons();
        if (canFlip) {
            // post into RelatedObjectsPage if we have a selection to force calculation
            if (getSelectedIssue() != null) {
                NewChangeDocumentRelatePage pageRel = (NewChangeDocumentRelatePage) getWizard().getPage(
                        Messages.new_relate_pageName);
                if (pageRel != null) {
                    pageRel.updateBasedOn(getSelectedIssue());
                }
            }
            return wizard.getNextPage(this);
        } else {
            return this;
        }
    }

    @Override
    public boolean canFlipToNextPage() {
        if (basedOnButton.getSelection() && basedOnCombo.getSelectionIndex() == -1) {
            setErrorMessage(Messages.new_baseIssueOn_error);
            return false;
        } else {
            setErrorMessage(null);
            return true;
        }

    }

    class CheckListener implements SelectionListener {

        @Override
        public void widgetSelected(SelectionEvent e) {
            Button button = (Button) e.getSource();
            if (button.getSelection()) {
                basedOnCombo.setEnabled(true);
                relationCombo.setEnabled(true);
            } else {
                basedOnCombo.setEnabled(false);
                relationCombo.setEnabled(false);
                canFlipToNextPage();
                wizard.getContainer().updateButtons();
            }
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }

    }

    class BasedOnListener implements SelectionListener {

        @Override
        public void widgetSelected(SelectionEvent e) {
            canFlipToNextPage();
            wizard.getContainer().updateButtons();
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }

    }
}

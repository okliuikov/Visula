/*
 * @IChangeDocumentModel.java, created on May 19, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsLcObjectModel;

/**
 * @author V.Grishchenko
 */
public interface IChangeDocumentModel extends IDimensionsLcObjectModel {
    IAttachmentsModel getAttachmentsModel();
}

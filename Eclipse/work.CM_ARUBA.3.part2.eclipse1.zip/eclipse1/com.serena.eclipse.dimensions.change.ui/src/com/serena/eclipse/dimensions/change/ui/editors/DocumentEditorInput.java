/*
 * @DocumentEditorInput.java, created on May 16, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.change.ui.editors;

import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IEditorInput;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorInput;

/**
 * @author V.Grishchenko
 */
public class DocumentEditorInput extends DimensionsObjectEditorInput implements IEditorInput {

    public DocumentEditorInput(ChangeDocumentAdapter document, String page) {
        super(document, page);
    }

    public ChangeDocumentAdapter getChangeDocumentAdapter() {
        return (ChangeDocumentAdapter) getAPIObjectAdapter();
    }

    @Override
    protected int[] getRequiredAttributes() {
        return new int[] { SystemAttributes.OBJECT_SPEC, SystemAttributes.TITLE };
    }

    @Override
    protected String getFullToolTipText() {
        String[] params = new String[] { DMTypeScope.REQUEST.getDisplayText(),
                (String) getChangeDocumentAdapter().getChangeDocument().getAttribute(SystemAttributes.OBJECT_SPEC),
                (String) getChangeDocumentAdapter().getChangeDocument().getAttribute(SystemAttributes.TITLE) };
        return NLS.bind(Messages.docEditor_tooltip, params);
    }

}

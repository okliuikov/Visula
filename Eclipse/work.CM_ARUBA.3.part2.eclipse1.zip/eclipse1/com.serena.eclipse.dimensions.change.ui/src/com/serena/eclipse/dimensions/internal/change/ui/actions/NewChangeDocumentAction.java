/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDimensionsServiceResource;
import com.serena.eclipse.dimensions.core.sbm.ISBMConnection;
import com.serena.eclipse.dimensions.internal.change.ui.dialogs.NewChangeDocumentWizard;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.actions.NewSBMRequestAction;

/**
 * @author abollmann
 *
 *         Class for creating a new change document
 */
public class NewChangeDocumentAction extends DimensionsAction {

    public NewChangeDocumentAction() {
        super(true); // trust plugin.xml
    }

    @Override
    public void run(IAction action) {
        IStructuredSelection selection = getSelection();
        if (selection.isEmpty()) {
            return;
        }
        Object selectedElement = getSelection().getFirstElement();
        if (selectedElement instanceof IDimensionsServiceResource) {
            DimensionsConnectionDetailsEx conn = ((IDimensionsServiceResource) selectedElement).getConnectionDetails();
            if (conn.getSBMConnection() != null) {
                newSBMRequest(action, conn.getSBMConnection());
            } else {
                ChangeDocumentAdapter chdoc = null;
                if (selectedElement instanceof ChangeDocumentAdapter) {
                    chdoc = (ChangeDocumentAdapter) selectedElement;
                }
                NewChangeDocumentWizard wizard = new NewChangeDocumentWizard(conn, chdoc);
                WizardDialog dialog = new WizardDialog(getShell(), wizard);
                dialog.open();
                refreshTree(conn);
            }
        }
    }

    protected void refreshTree(DimensionsConnectionDetailsEx conn) {
        try {
            ChangeDocumentList list = ChangeDocumentList.getMyPendingList(conn);
            list.fetch(null);
            list = ChangeDocumentList.getDraftList(conn);
            list.fetch(null);
        } catch (DMException e) {
            DMChangeUiPlugin.getDefault().handle(e);
        }
    }

    void newSBMRequest(IAction action, ISBMConnection connection) {
        NewSBMRequestAction newSbmAction = new NewSBMRequestAction();
        newSbmAction.setSelection(new StructuredSelection(connection));
        newSbmAction.run(action);
    }

}

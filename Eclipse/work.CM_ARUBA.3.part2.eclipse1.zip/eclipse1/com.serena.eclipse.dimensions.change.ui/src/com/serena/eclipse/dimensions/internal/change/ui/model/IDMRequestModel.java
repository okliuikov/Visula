/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import com.serena.eclipse.dimensions.core.IDMRequestAdapter;
import com.serena.eclipse.dimensions.internal.ui.model.EditableAggregateModel;
import com.serena.eclipse.dimensions.internal.ui.model.IBaseDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDMRelatedObjectsModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDMRequestAttrModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IRelatedObjectsModel;

public class IDMRequestModel extends EditableAggregateModel {

    private IDimensionsArObjectModel sysAttrModel;
    private IRelatedObjectsModel relatedObjectsModel;

    public IDMRequestModel(IDMRequestAdapter object) {
        super(object);
        sysAttrModel = new IDMRequestAttrModel(object);
        relatedObjectsModel = new IDMRelatedObjectsModel(object);
        setMembers(new IBaseDimensionsArObjectModel[] { sysAttrModel, relatedObjectsModel });
    }

    public IDimensionsArObjectModel getSystemAttributeModel() {
        return sysAttrModel;
    }

    public IRelatedObjectsModel getRelatedObjectsModel() {
        return relatedObjectsModel;
    }

}

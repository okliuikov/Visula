/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.RequestList;
import com.serena.dmclient.api.RequestListDetails;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ECustomChangeDocumentList;
import com.serena.eclipse.dimensions.core.ERequestListDetails;
import com.serena.eclipse.dimensions.core.IDimensionsServiceResource;
import com.serena.eclipse.dimensions.core.RequestListList;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;

/**
 * @author abollmann
 *
 *         Action for creating a new custom list or new job
 */
public class NewCustomListAction extends DimensionsAction implements IInputValidator {

    @Override
    public void run(IAction action) {
        if (getSelection() == null || getSelection().isEmpty()) {
            return;
        }
        // TODO VG on Feb 6, 2006: job handling needed?
        boolean job = action.getId().equals("com.serena.eclipse.dimensions.ui.newJobAction") //$NON-NLS-1$
                || action.getId().equals("com.serena.eclipse.dimensions.ui.newJobActionPlusChangeDocument"); //$NON-NLS-1$
        String dlgTitle = job ? Messages.newJob_title : Messages.newCustomList_title;
        String dlgMessage = job ? Messages.newJob_label : Messages.newCustomList_label;
        InputDialog dialog = new InputDialog(getShell(), dlgTitle, dlgMessage, null, this) {
            @Override
            protected Control createDialogArea(Composite parent) {
                Control composite = super.createDialogArea(parent);
                getText().setTextLimit(RequestList.ID_MAX_LENGTH);
                return composite;
            }
        };
        if (dialog.open() == Window.OK) {
            final String name = job ? ECustomChangeDocumentList.jobPrefix + dialog.getValue() : dialog.getValue();
            final ArrayList requests = new ArrayList();
            final DimensionsConnectionDetailsEx[] connectionHolder = new DimensionsConnectionDetailsEx[1];
            for (Iterator iterator = getSelection().iterator(); iterator.hasNext();) {
                IDimensionsServiceResource dsr = (IDimensionsServiceResource) iterator.next();
                if (connectionHolder[0] == null) {
                    connectionHolder[0] = dsr.getConnectionDetails();
                }
                if (dsr instanceof ChangeDocumentAdapter) {
                    requests.add(((ChangeDocumentAdapter) dsr).getChangeDocument());
                }
            }
            try {
                PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                    @Override
                    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                        try {
                            createCustomRequestList(connectionHolder[0], name, requests, monitor);
                        } catch (DMException e) {
                            throw new InvocationTargetException(e);
                        }
                    }
                });
            } catch (InvocationTargetException e) {
                DMChangeUiPlugin.getDefault().handle(e, getShell(), Messages.newCustomList_errCreateTitle,
                        Messages.newCustomList_errCreateMessage);
            } catch (InterruptedException ignore) {
            }
        }
    }

    private void createCustomRequestList(DimensionsConnectionDetailsEx connection, final String name, final List requests,
            IProgressMonitor monitor) throws DMException {
        RequestListList rll = RequestListList.getList(connection);
        rll.createObject(new ERequestListDetails(new RequestListDetails(name, requests)), monitor);
    }

    @Override
    protected boolean isEnabledForSelection() {
        IStructuredSelection selection = getSelection();

        // 1. always enable for a single IDimensionsServiceResource
        if (selection.size() == 1) {
            return true;
        }

        // 2. enable for change documents from 1 connection
        DimensionsConnectionDetailsEx connection = null;
        for (Iterator iter = selection.iterator(); iter.hasNext();) {
            IDimensionsServiceResource dmResource = (IDimensionsServiceResource) iter.next();
            if (!(dmResource instanceof ChangeDocumentAdapter)) {
                return false;
            }
            if (connection == null) {
                connection = dmResource.getConnectionDetails();
            } else {
                if (!connection.equals(dmResource.getConnectionDetails())) {
                    return false;
                }
            }

        }
        return true;
    }

    @Override
    public String isValid(String newText) {
        if (newText == null || newText.trim().length() == 0) {
            return Messages.newCustomList_validateMsg;
        }
        return null;
    }

}

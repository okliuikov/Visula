/*
 * @IAttachmentsModel.java, created on May 19, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.internal.ui.model.IBaseDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IEditable;
import com.serena.eclipse.dimensions.internal.ui.model.IPropertyModel;

/**
 * @author V.Grishchenko
 */
public interface IAttachmentsModel extends IBaseDimensionsArObjectModel, IEditable, IPropertyModel {
    public AttachmentDetails[] getAttachments();

    // the following methods update an internal list only, updated to the db
    // is done on the doSave.
    void attach(AttachmentDetails details);

    void removeAttachment(String id) throws DMException;

    void updateAttachment(String id, String newDescription);

    // Writes the selected attachment to a local file
    void saveAttachmentToFile(String id, String localFileName) throws DMException;

    /** attach result from last save, or <code>null</code> if none */
    DimensionsResult getAttachResult();

    /** delete results from last save, or empty array if none */
    DimensionsResult[] getDeleteResults();

    /** update description results from last save, or empty array if none */
    DimensionsResult[] getUpdateResults();

    /** save to file result from last save to file **/
    DimensionsResult getSaveResult();

    /** Returns the mime type for the attachment identified by the id */
    String getMimeType(String id);

}

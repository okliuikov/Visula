/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ECustomChangeDocumentList;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;

/**
 * @author abollmann
 *
 */
public class RemoveFromCustomListAction extends DimensionsAction {

    @Override
    public void run(IAction action) {
        boolean ok;
        final List chdocList = new ArrayList();
        final ChangeDocumentAdapter selection = (ChangeDocumentAdapter) getSelection().getFirstElement();
        if (((ECustomChangeDocumentList) selection.getObjectList()).isList(ChangeDocumentList.JOB)) {
            ok = MessageDialog.openQuestion(getShell(), Messages.remFromJob_title, Messages.remFromJob_question);
        } else {
            ok = MessageDialog.openQuestion(getShell(), Messages.remFromCustomList_title, Messages.remFromCustomList_question);
        }
        if (ok) {
            try {
                final ChangeDocumentAdapter element = selection;
                element.getConnectionDetails().openSession(null);
                for (Iterator iterator = getSelection().iterator(); iterator.hasNext();) {
                    ChangeDocumentAdapter adapter = (ChangeDocumentAdapter) iterator.next();
                    chdocList.add(adapter);
                }
                ECustomChangeDocumentList list = (ECustomChangeDocumentList) element.getObjectList();
                list.removeChangeDocuments(chdocList);
            } catch (DMException e) {
                DMChangeUiPlugin.getDefault().handle(e);
            }
        }
    }

    /**
     * @return <code>true</code> if action should be enabled for the current
     *         selection, returns <code>false</code> otherwise
     */
    @Override
    protected boolean isEnabledForSelection() {
        DimensionsConnectionDetailsEx conn, prevConn = null;
        List changeDocs = getSelection().toList();
        for (int i = 0; i < changeDocs.size(); i++) {
            ChangeDocumentAdapter chdoc = (ChangeDocumentAdapter) changeDocs.get(i);
            conn = chdoc.getConnectionDetails();
            if (prevConn != null && !conn.equals(prevConn)) {
                return false;
            } else {
                prevConn = conn;
            }
        }
        return true;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.model.AttachmentDetails;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * @author abollmann
 *
 *         Summary page for new change document wizard
 */
public class NewChangeDocumentSummaryPage extends WizardPage {
    private Text text;
    private Button draftButton;
    private IWizard wizard;

    public NewChangeDocumentSummaryPage(String pageName, String title, ImageDescriptor titleImage) {
        super(pageName, title, titleImage);
        setDescription(Messages.new_summary_description1);

    }

    @Override
    public void createControl(Composite parent) {
        wizard = getWizard();
        Composite composite = new Composite(parent, SWT.NULL);
        UIUtils.setGridLayout(composite, 1);
        Label label2 = new Label(composite, SWT.NONE);
        label2.setText(Messages.new_summary_description2);
        text = new Text(composite, SWT.BORDER | SWT.WRAP | SWT.V_SCROLL | SWT.H_SCROLL);
        GridData gd = UIUtils.setGridData(text, GridData.FILL_BOTH);
        gd.widthHint = gd.heightHint = 100; // hint small size to ensure page is not expanded to accommodate all text
        Color normalBgrnd = text.getBackground();
        text.setEditable(false);
        text.setBackground(normalBgrnd);
        draftButton = new Button(composite, SWT.CHECK);
        draftButton.setText(Messages.new_summary_draft);

        fillSummary();
        setControl(composite);
    }

    private void fillSummary() {
        NewChangeDocumentBasicPage page = (NewChangeDocumentBasicPage) wizard.getPage(Messages.new_basic_pageName);
        String productId = page.getChdocProduct();
        String type = page.getChdocType();
        String title = page.getChdocTitle();
        String description = page.getChdocDescription();
        String descriptionFile = page.getDescriptionFileName();

        NewChangeDocumentBasedOnPage basedOnPage = (NewChangeDocumentBasedOnPage) wizard.getPage(Messages.new_baseIssueOn_pageName);
        Request primeIssue = basedOnPage.getSelectedIssue();
        String relPrimeRelation = basedOnPage.getSelectedRelation();

        NewChangeDocumentRelatePage relPage = (NewChangeDocumentRelatePage) wizard.getPage(Messages.new_relate_pageName);
        List<String> parts = relPage.getSelectedParts();
        String project = relPage.getSelectedProject();

        NewChangeDocumentAttachmentPage attachPage = (NewChangeDocumentAttachmentPage) wizard.getPage(Messages.new_attach_pageName);
        AttachmentDetails attachments[] = attachPage.getAttachments();

        NewChangeDocumentAttributesPage attrPage = (NewChangeDocumentAttributesPage) wizard.getPage(Messages.new_attr_pageName);
        String attrs = attrPage.getChangedAttributesString();

        String info[] = new String[4];
        info[0] = type;
        info[1] = productId;
        info[2] = title;
        info[3] = text.getLineDelimiter();
        String summary = NLS.bind(Messages.new_summary_text1, info);
        if (description.length() > 0) {
            summary += NLS.bind(Messages.new_summary_text2, description, text.getLineDelimiter());
        } else if (descriptionFile.length() > 0) {
            summary += NLS.bind(Messages.new_summary_text3, descriptionFile, text.getLineDelimiter());
        } else {
            summary += NLS.bind(Messages.new_summary_text4, text.getLineDelimiter());
        }
        if (primeIssue == null) {
            summary += NLS.bind(Messages.new_summary_noIssue, text.getLineDelimiter());
        } else {
            info = new String[3];
            info[0] = relPrimeRelation;
            info[1] = primeIssue.getName();
            info[2] = text.getLineDelimiter();
            summary += NLS.bind(Messages.new_summary_basedOnIssue, info);
        }

        summary += NLS.bind(Messages.new_summary_attrs, text.getLineDelimiter());
        if (attrs.length() > 0) {
            summary += "     " + attrs + text.getLineDelimiter(); //$NON-NLS-1$
        } else {
            summary += "     " + Messages.new_summary_noAttrs + text.getLineDelimiter(); //$NON-NLS-1$
        }

        summary += text.getLineDelimiter();
        summary += NLS.bind(Messages.new_summary_relate, text.getLineDelimiter());
        summary += NLS.bind(Messages.new_summary_relParts, text.getLineDelimiter());
        if (parts.size() > 0) {
            for (int i = 0; i < parts.size(); i++) {
                summary += "     " + parts.get(i) + text.getLineDelimiter(); //$NON-NLS-1$
            }
        } else {
            summary += "     " + Messages.new_summary_noRelParts + text.getLineDelimiter(); //$NON-NLS-1$
        }

        summary += text.getLineDelimiter();
        summary += NLS.bind(Messages.new_summary_relProjects, text.getLineDelimiter());
        if (project.length() > 0) {
            summary += "     " + project + text.getLineDelimiter(); //$NON-NLS-1$
        } else {
            summary += "     " + Messages.new_summary_noRelProjects + text.getLineDelimiter(); //$NON-NLS-1$
        }

        summary += text.getLineDelimiter();
        if (attachments.length == 0) {
            summary += Messages.new_summary_noAttachment;
        } else {
            summary += NLS.bind(Messages.new_summary_attachment, text.getLineDelimiter());
            for (int i = 0; i < attachments.length; i++) {
                summary += "     " + attachments[i].getName() + text.getLineDelimiter(); //$NON-NLS-1$
            }
        }
        text.setText(summary);
    }

    public boolean isHeld() {
        if (draftButton == null) {
            return false;
        }
        return draftButton.getSelection();
    }

    @Override
    public IWizardPage getPreviousPage() {
        fillSummary(); // force it to update whenever this page is left
        return super.getPreviousPage();
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;

import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.DimensionsRuntimeException;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.model.HistoryModel;

/**
 * @author V.Grishchenko
 */
public class ChangeDocumentHistoryModel extends HistoryModel implements IChangeDocumentHistoryModel {
    private List structureHistory;
    private Project requestRelatedProject;

    public ChangeDocumentHistoryModel(final ChangeDocumentAdapter object) {
        super(object);
        try {
            Session session = getUnderlyingObject().getConnectionDetails().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() {
                    getRequestRelatedProject((Request) object.getAPIObject());
                }
            }, new NullProgressMonitor());
        } catch (DMException ex) {
            throw new DimensionsRuntimeException(ex);
        }
    }

    @Override
    protected long doLoad(IProgressMonitor pm) throws DMException {
        checkCanceled(pm);
        pm = Utils.monitorFor(pm);
        pm.beginTask(Messages.ChangeDocumentHistoryModel_task, 120);
        try {
            final Session session = getUnderlyingObject().getConnectionDetails().openSession(Utils.subMonitorFor(pm, 20));
            pm.subTask(Messages.ChangeDocumentHistoryModel_structSubTask);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    structureHistory = new ArrayList();
                    Request r = ((ChangeDocumentAdapter) getUnderlyingObject()).getChangeDocument();

                    Project toQuery = session.getObjectFactory().getGlobalProject();
                    if (requestRelatedProject != null) {
                        toQuery = requestRelatedProject;
                    }

                    structureHistory = r.getStructureHistory(toQuery);
                }
            }, pm);
            pm.worked(50);
            return super.doLoad(Utils.subMonitorFor(pm, 50));
        } finally {
            pm.done();
        }
    }

    private void getRequestRelatedProject(Request req) {
        List projs = req.getParentProjects(null);
        if (projs.size() > 0) {
            requestRelatedProject = (Project) ((DimensionsRelatedObject) projs.get(0)).getObject();
        }
    }

    @Override
    public List getStructureHistory() {
        return structureHistory;
    }

}

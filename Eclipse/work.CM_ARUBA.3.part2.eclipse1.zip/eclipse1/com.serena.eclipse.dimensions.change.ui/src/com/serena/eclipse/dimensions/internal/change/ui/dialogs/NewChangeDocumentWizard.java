/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.RequestAttachmentDetails;
import com.serena.dmclient.api.RequestDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.Product;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.model.AttachmentDetails;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.atts.SFAttributeValue;
import com.serena.eclipse.dimensions.internal.ui.forms.FormWizard;

/**
 * @author abollmann
 *
 *         Wizard for creating new change documents
 */
public class NewChangeDocumentWizard extends FormWizard {
    private DimensionsConnectionDetailsEx conn;
    private ChangeDocumentAdapter basedOnChdoc;

    public NewChangeDocumentWizard(DimensionsConnectionDetailsEx conn, ChangeDocumentAdapter chdoc) {
        super();
        this.conn = conn;
        this.basedOnChdoc = chdoc;
        setNeedsProgressMonitor(true);
    }

    @Override
    public void addPages() {
        addPage(new NewChangeDocumentBasicPage(Messages.new_basic_pageName, Messages.new_basic_chdoc_title, DMUIPlugin.getDefault()
                .getImageDescriptor(IDMImages.LOGIN_WIZBAN), conn, basedOnChdoc));
        addPage(new NewChangeDocumentBasedOnPage(Messages.new_baseIssueOn_pageName, Messages.new_baseIssueOn_title,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), conn, basedOnChdoc));
        addPage(new NewChangeDocumentAttributesPage(Messages.new_attr_pageName, Messages.new_attr_title, DMUIPlugin.getDefault()
                .getImageDescriptor(IDMImages.LOGIN_WIZBAN), conn));
        NewChangeDocumentBasedOnPage page = (NewChangeDocumentBasedOnPage) getPage(Messages.new_baseIssueOn_pageName); //$NON-NLS-1
        Request basedOn = page.getSelectedIssue();
        addPage(new NewChangeDocumentRelatePage(Messages.new_relate_pageName, Messages.new_relate_title, DMUIPlugin.getDefault()
                .getImageDescriptor(IDMImages.LOGIN_WIZBAN), conn, basedOn));
        addPage(new NewChangeDocumentAttachmentPage(Messages.new_attach_pageName, Messages.new_attach_title,
                DMUIPlugin.getDefault().getImageDescriptor(IDMImages.LOGIN_WIZBAN), conn));
        addPage(new NewChangeDocumentSummaryPage(Messages.new_summary_pageName, Messages.new_summary_title, DMUIPlugin.getDefault()
                .getImageDescriptor(IDMImages.LOGIN_WIZBAN)));
    }

    @Override
    public String getWindowTitle() {
        if (getContainer().getCurrentPage().getName().equals(Messages.new_basic_pageName)) {
            return Messages.new_basic_chdoc_windowTitle;
        } else if (getContainer().getCurrentPage().getName().equals(Messages.new_baseIssueOn_pageName)) {
            return Messages.new_baseIssueOn_windowTitle;
        } else if (getContainer().getCurrentPage().getName().equals(Messages.new_attr_pageName)) {
            return Messages.new_attr_windowTitle;
        } else if (getContainer().getCurrentPage().getName().equals(Messages.new_relate_pageName)) {
            return Messages.new_relate_windowTitle;
        } else if (getContainer().getCurrentPage().getName().equals(Messages.new_attach_pageName)) {
            return Messages.new_attach_windowTitle;
        } else if (getContainer().getCurrentPage().getName().equals(Messages.new_summary_pageName)) {
            return Messages.new_summary_windowTitle;
        } else {
            return ""; //$NON-NLS-1$
        }

    }

    @Override
    public boolean performFinish() {
        final RequestDetails newChdoc = new RequestDetails();
        NewChangeDocumentBasicPage page = (NewChangeDocumentBasicPage) getPage(Messages.new_basic_pageName);
        final String productId = page.getChdocProduct();
        String typeId = page.getChdocType();
        String title = page.getChdocTitle();
        String description = page.getChdocDescription();
        String descriptionFile = page.getDescriptionFileName();

        NewChangeDocumentBasedOnPage basedOnPage = (NewChangeDocumentBasedOnPage) getPage(Messages.new_baseIssueOn_pageName);
        Request primeIssue = basedOnPage.getSelectedIssue();
        String relPrimeRelation = basedOnPage.getSelectedRelation();
        // if we came here directly from bopage
        final NewChangeDocumentRelatePage relPage = (NewChangeDocumentRelatePage) getPage(Messages.new_relate_pageName);
        if (primeIssue != null && getContainer().getCurrentPage().getName().equals(Messages.new_baseIssueOn_pageName)) {
            // post to related page to do pre selection
            relPage.updateBasedOn(primeIssue);
        }

        final List partSpecs = relPage.getSelectedParts();
        final String projectSpec = relPage.getSelectedProject();

        NewChangeDocumentAttachmentPage attachPage = (NewChangeDocumentAttachmentPage) getPage(Messages.new_attach_pageName);
        AttachmentDetails attachments[] = attachPage.getAttachments();
        RequestAttachmentDetails[] dmAttachments = new RequestAttachmentDetails[attachments.length];
        for (int i = 0; i < attachments.length; i++) {
            RequestAttachmentDetails attachDetails = new RequestAttachmentDetails();
            attachDetails.setDescription(attachments[i].getDescription());
            attachDetails.setFileName(attachments[i].getFileName());
            attachDetails.setName(attachments[i].getName());
            dmAttachments[i] = attachDetails;
        }

        NewChangeDocumentAttributesPage attrPage = (NewChangeDocumentAttributesPage) getPage(Messages.new_attr_pageName);
        List attrs = attrPage.getChangedAttributes();
        for (int i = 0; i < attrs.size(); i++) {
            SFAttributeValue attr = (SFAttributeValue) attrs.get(i);
            attr.setToObjectDetails(newChdoc);
        }

        boolean isHeld;
        NewChangeDocumentSummaryPage sumPage = (NewChangeDocumentSummaryPage) getPage(Messages.new_summary_pageName);
        if (sumPage != null) {
            isHeld = sumPage.isHeld();
        } else {
            isHeld = false;
        }

        newChdoc.setDescription(title);
        newChdoc.setProductName(productId);
        newChdoc.setTypeName(typeId);
        if (description.length() > 0) {
            newChdoc.setDetailedDescription(description);
        } else if (descriptionFile.length() > 0) {
            newChdoc.setDetailedDescriptionFileName(descriptionFile);
        }
        newChdoc.setHeld(isHeld);
        newChdoc.setAttachments(dmAttachments);

        if (primeIssue != null) {
            newChdoc.setBasedOnRequest(primeIssue.getName());
        }
        newChdoc.setBasedOnRelationship(relPrimeRelation);
        final String[] errMsgHolder = new String[1];
        try {
            getContainer().run(true, true, new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    try {
                        createRequest(newChdoc, productId, partSpecs, projectSpec, errMsgHolder, monitor);
                    } catch (OperationCanceledException e) {
                        throw new InterruptedException(e.getMessage());
                    } catch (DMException e) {
                        throw new InvocationTargetException(e);
                    } finally {
                        monitor.done();
                    }
                }
            });
        } catch (InvocationTargetException e) {
            if (Utils.isNullEmpty(errMsgHolder[0])) {
                errMsgHolder[0] = Messages.new_chdoc_createError;
            }
            DMChangeUiPlugin.getDefault().handle(e, getShell(), Messages.err_error, errMsgHolder[0]);
            return false;
        } catch (InterruptedException e) {
            return false; // cancelled
        }
        return true;
    }

    private void createRequest(final RequestDetails newChdoc, final String productId, final List partSpecs,
            final String projectSpec, final String[] errMsgHolder, final IProgressMonitor monitor) throws DMException {
        String createMsg = NLS.bind(Messages.new_chdoc_createMsg, newChdoc.getTypeName());
        monitor.beginTask(createMsg, 100);
        final Session session = conn.openSession(Utils.subMonitorFor(monitor, 10)); // 10 of 100
        session.run(new APIOperation(createMsg) {
            @Override
            public DimensionsResult doRun() throws Exception {
                Utils.checkCanceled(monitor);
                Product product = session.getObjectFactory().getBaseDatabaseAdmin().getProducts().get(productId);
                monitor.worked(10); // 20 of 100
                Utils.checkCanceled(monitor);
                if (partSpecs.size() > 0) {
                    Filter filter = new Filter();
                    filter.criteria().add(Filter.Criterion.START_OR);
                    for (int i = 0; i < partSpecs.size(); i++) {
                        String partSpec = (String) partSpecs.get(i);
                        filter.criteria()
                                .add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, partSpec, Filter.Criterion.EQUALS));
                    }
                    filter.criteria().add(Filter.Criterion.END_OR);
                    List parts = product.getParts(filter);
                    if (parts.size() != partSpecs.size()) {
                        errMsgHolder[0] = Messages.err_relatePartMsg;
                        throw new DMException(new Status(IStatus.ERROR, DMChangeUiPlugin.ID, 0, Messages.err_relatePartDesc, null));
                    }
                    newChdoc.setRelatedParts(parts);
                }
                Utils.checkCanceled(monitor);
                monitor.worked(10); // 30 of 100
                if (!Utils.isNullEmpty(projectSpec)) {
                    Filter filter = new Filter();
                    filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, projectSpec, Filter.Criterion.EQUALS));
                    List projects = product.getProjects(filter);
                    if (projects.size() != 1) {
                        errMsgHolder[0] = Messages.err_relateProjectMsg;
                        throw new DMException(new Status(IStatus.ERROR, DMChangeUiPlugin.ID, 0, Messages.err_relateProjectDesc,
                                null));
                    }
                    newChdoc.setRelatedProject(((Project) projects.get(0)).getName());
                }
                Utils.checkCanceled(monitor);
                monitor.worked(10); // 40 of 100
                return session.getObjectFactory().createRequest(newChdoc);
            }
        }, monitor);
    }
}

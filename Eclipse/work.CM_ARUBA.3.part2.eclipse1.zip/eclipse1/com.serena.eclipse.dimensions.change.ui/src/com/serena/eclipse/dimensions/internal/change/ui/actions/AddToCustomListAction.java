/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ECustomChangeDocumentList;
import com.serena.eclipse.dimensions.core.RequestListAdapter;
import com.serena.eclipse.dimensions.core.RequestListList;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;

/**
 * @author abollmann
 *         Action to add selected change document(s) to a custom change document list
 */
public class AddToCustomListAction extends DimensionsAction {

    private ECustomChangeDocumentList[] customLists;

    private class MyDialog extends ResizableDialog {
        private ECustomChangeDocumentList selectedCustomList;
        private Combo comboBox;

        /**
         * @param parent
         */
        public MyDialog(Shell parent) {
            super(parent);
        }

        @Override
        protected Control createDialogArea(Composite _parent) {
            getShell().setText(Messages.addToCustomList_title);

            Composite composite = (Composite) super.createDialogArea(_parent);
            GridLayout gridLayout = new GridLayout();
            gridLayout.numColumns = 1;
            GridData gridData = new GridData(GridData.FILL_BOTH | GridData.GRAB_HORIZONTAL);
            composite.setLayout(gridLayout);
            composite.setLayoutData(gridData);

            Label label = new Label(composite, SWT.NONE);
            label.setText(Messages.addToCustomList_label);
            comboBox = new Combo(composite, SWT.NONE);
            for (int i = 0; i < customLists.length; i++) {
                comboBox.add(customLists[i].getQualifier());
            }
            return composite;
        }

        @Override
        protected void okPressed() {
            int index = comboBox.getSelectionIndex();
            if (index >= 0) {
                selectedCustomList = customLists[index];
            }
            super.okPressed();
        }

        public ECustomChangeDocumentList getSelectedList() {
            return selectedCustomList;
        }
    }

    @Override
    public void run(IAction action) {
        if (getSelection().isEmpty()) {
            return;
        }
        final DimensionsConnectionDetailsEx con = ((ChangeDocumentAdapter) getSelection().getFirstElement()).getConnectionDetails();
        try {
            PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                @Override
                public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                    try {
                        RequestListList rll = RequestListList.getList(con);
                        rll.fetch(monitor);
                        Object[] lists = rll.getObjects();
                        customLists = new ECustomChangeDocumentList[lists.length];
                        for (int i = 0; i < lists.length; i++) {
                            customLists[i] = ((RequestListAdapter) lists[i]).getERequestList();
                        }
                    } catch (DMException e) {
                        throw new InvocationTargetException(e);
                    }
                }
            });
        } catch (InvocationTargetException e2) {
            DMChangeUiPlugin.getDefault().handle(e2, getShell());
        } catch (InterruptedException e2) {
        }

        MyDialog dialog = new MyDialog(getShell());
        int ret = dialog.open();
        if (ret == Window.OK) {
            final ECustomChangeDocumentList customList = dialog.getSelectedList();
            if (customList != null) {
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                customList.addChangeDocuments(getSelection().toList(), monitor);
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });
                } catch (InvocationTargetException e1) {
                    DMChangeUiPlugin.getDefault().handle(e1, getShell());
                } catch (InterruptedException e1) {
                }
            }
        }
    }

    /**
     * @return <code>true</code> if action should be enabled for the current
     *         selection, returns <code>false</code> otherwise
     */
    @Override
    protected boolean isEnabledForSelection() {
        DimensionsConnectionDetailsEx conn, prevConn = null;
        List changeDocs = getSelection().toList();
        for (int i = 0; i < changeDocs.size(); i++) {
            ChangeDocumentAdapter chdoc = (ChangeDocumentAdapter) changeDocs.get(i);
            conn = chdoc.getConnectionDetails();
            if (prevConn != null && !conn.equals(prevConn)) {
                return false;
            } else {
                prevConn = conn;
            }
        }
        return true;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.internal.ui.model.ChangeDocumentAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsChangeDocumentModel;
import com.serena.eclipse.dimensions.internal.ui.model.EditableAggregateModel;
import com.serena.eclipse.dimensions.internal.ui.model.IAttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.IBaseDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IHistoryModel;
import com.serena.eclipse.dimensions.internal.ui.model.IPreviewModel;
import com.serena.eclipse.dimensions.internal.ui.model.IPrivilegesModel;
import com.serena.eclipse.dimensions.internal.ui.model.IRelatedObjectsModel;
import com.serena.eclipse.dimensions.internal.ui.model.IUsersAndRolesModel;
import com.serena.eclipse.dimensions.internal.ui.model.PrivilegesModel;
import com.serena.eclipse.dimensions.internal.ui.model.RelatedObjectsModel;
import com.serena.eclipse.dimensions.internal.ui.model.UsersAndRolesModel;

/**
 * @author V.Grishchenko
 */
public class ChangeDocumentModel extends EditableAggregateModel implements IChangeDocumentModel {

    private IAttachmentsModel attachmensModel;
    private IDimensionsArObjectModel sysAttrModel;
    private IAttributeModel userAttrModel;
    private IChangeDocumentHistoryModel historyModel;
    private IUsersAndRolesModel delegateModel;
    private IUsersAndRolesModel userAndRolesModel;
    private IPreviewModel previewModel;
    private IPrivilegesModel privilegesModel;
    private IRelatedObjectsModel relatedObjectsModel;
    private IActionDescriptionModel descriptionModel;

    public ChangeDocumentModel(ChangeDocumentAdapter object) {
        super(object);
        attachmensModel = new AttachmentsModel(object);
        sysAttrModel = new DimensionsChangeDocumentModel(object);
        userAttrModel = new ChangeDocumentAttributeModel(object);
        historyModel = new ChangeDocumentHistoryModel(object);
        delegateModel = new UsersAndRolesModel(object);
        userAndRolesModel = new UsersAndRolesModel(object, false);
        previewModel = new ChangeDocumentPreviewModel(object);
        privilegesModel = new PrivilegesModel(object);
        relatedObjectsModel = new RelatedObjectsModel(object);
        descriptionModel = new ActionDescriptionModel(object);
        setMembers(new IBaseDimensionsArObjectModel[] { attachmensModel, sysAttrModel, userAttrModel, historyModel, delegateModel,
                userAndRolesModel, previewModel, privilegesModel, relatedObjectsModel, descriptionModel });
    }

    @Override
    public IAttachmentsModel getAttachmentsModel() {
        return attachmensModel;
    }

    @Override
    public IDimensionsArObjectModel getSystemAttributeModel() {
        return sysAttrModel;
    }

    @Override
    public IAttributeModel getUserAttributeModel() {
        return userAttrModel;
    }

    /**
     * @return an instance of <code>IChangeDocumentHistoryModel</code>
     * @see com.serena.eclipse.dimensions.internal.ui.model.IDimensionsLcObjectModel#getHistoryModel()
     */
    @Override
    public IHistoryModel getHistoryModel() {
        return historyModel;
    }

    @Override
    public IUsersAndRolesModel getDelegateModel() {
        return delegateModel;
    }

    @Override
    public IUsersAndRolesModel getUsersAndRolesModel() {
        return userAndRolesModel;
    }

    public IPrivilegesModel getPrivilegesModel() {
        return privilegesModel;
    }

    @Override
    public IRelatedObjectsModel getRelatedObjectsModel() {
        return relatedObjectsModel;
    }

    @Override
    public IPreviewModel getPreviewModel() {
        return previewModel;
    }

    public IActionDescriptionModel getDescriptionModel() {
        return descriptionModel;
    }

}

package com.serena.eclipse.dimensions.change.ui.editors;

import java.util.Arrays;
import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.widgets.ExpandableComposite;

import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.api.IDMRequestIdentifier;
import com.serena.dmclient.api.IDMRequestV2;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMRequestAdapter;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.forms.DocumentDetailsSection;
import com.serena.eclipse.dimensions.internal.change.ui.model.IDMRequestModel;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.editors.BrowserPage;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditor;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorPage;
import com.serena.eclipse.dimensions.internal.ui.editors.RelatedObjectsPage;
import com.serena.eclipse.dimensions.internal.ui.forms.FormEntry;
import com.serena.eclipse.dimensions.internal.ui.forms.ObjectDetailsSection;
import com.serena.eclipse.dimensions.internal.ui.model.IAggregateModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;

/**
 *
 * @author kberezovchuk
 *
 */
public class IDMRequestEditor extends DimensionsObjectEditor {
    public static final String ID = "com.serena.eclipse.dimensions.change.editors.IDMReq"; //$NON-NLS-1$

    @Override
    protected void addPages() {
        try {
            IDMRequestModel docModel = (IDMRequestModel) getModel();
            addPage(new RelatedObjectsPage(this, docModel.getRelatedObjectsModel()));
            if (docModel.getConnection().getRequestProviderType().equals(DimensionsConnectionDetailsEx.TYPE_REQUEST_PROVIDER_IDM)) {
                try {
                    final Session session = docModel.getConnection().openSession(null);
                    IDMHelper helper = session.getObjectFactory().getIDMHelper();
                    RequestProvider provider = session.getObjectFactory().getRequestProvider(null);
                    IDMRequestIdentifier identifier = new IDMRequestIdentifier(
                            provider.getUID(), docModel.getUnderlyingObject().getAPIObject().getName());
                    List<IDMRequestV2> requests = helper.getIDMRequests(Arrays.asList(identifier));
                    if (requests != null && requests.size() == 1) {
                        String link = requests.get(0).getUrl();
                        addPage(new BrowserPage(this, Messages.browserPage_title, link));
                    }
                } catch (Exception e) {
                    DMChangeUiPlugin.getDefault().getLog().log(new Status(Status.WARNING, DMUIPlugin.ID, Messages.err_genericMsg, e));
                }
            }
            activateInitialPage();
        } catch (PartInitException e) {
            DMChangeUiPlugin.getDefault().getLog().log(e.getStatus());
            IStatus svcInfo = Utils.getServiceInfo(e, DMChangeUiPlugin.getDefault().getBundle());
            UIUtils.showError(getSite().getShell(), Messages.err_error, Messages.err_addEditorPage, svcInfo);
        }
    }

    @Override
    public void init(IEditorSite site, IEditorInput input) throws PartInitException {
        if (!(input instanceof IDMRequestEditorInput)) {
            throw new PartInitException("Unexpected input: " + input.getClass().getName()); //$NON-NLS-1$
        }
        super.init(site, input);
    }

    @Override
    protected IAggregateModel createModel(APIObjectAdapter object) {
        return new IDMRequestModel((IDMRequestAdapter) object);
    }

    @Override
    public ObjectDetailsSection createDetailsSection(Composite parent, DimensionsObjectEditorPage page) {
        int style = ExpandableComposite.TITLE_BAR | ExpandableComposite.TWISTIE;
        IDimensionsArObjectModel sysModel = ((IDMRequestModel) getModel()).getSystemAttributeModel();
        DocumentDetailsSection section = new DocumentDetailsSection(page, sysModel, parent, Messages.detailsPage_text, style);
        return section;
    }

}

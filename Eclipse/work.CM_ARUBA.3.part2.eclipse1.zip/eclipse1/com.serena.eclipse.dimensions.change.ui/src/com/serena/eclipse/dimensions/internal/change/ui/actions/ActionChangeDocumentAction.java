/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.wizard.WizardDialog;

import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ActionWizard;

/**
 * @author abollmann
 *
 *         Action for actioning a change document
 */
public class ActionChangeDocumentAction extends DimensionsAction {
    public ActionChangeDocumentAction() {
    }

    @Override
    public void run(IAction action) {
        List chdocss = getSelection().toList();
        List connections = new ArrayList();
        ChangeDocumentAdapter[] chdocs = new ChangeDocumentAdapter[chdocss.size()];
        for (int i = 0; i < chdocss.size(); i++) {
            chdocs[i] = (ChangeDocumentAdapter) chdocss.get(i);
            DimensionsConnectionDetailsEx conn = chdocs[i].getConnectionDetails();
            if (!connections.contains(conn)) {
                connections.add(conn);
            }
        }
        ActionWizard wizard = new ActionWizard(chdocs);
        WizardDialog dialog = new WizardDialog(getShell(), wizard);
        dialog.open();
    }

    /**
     * @return <code>true</code> if action should be enabled for the current
     *         selection, returns <code>false</code> otherwise
     */
    @Override
    protected boolean isEnabledForSelection() {
        return isSameConnection();
    }
}

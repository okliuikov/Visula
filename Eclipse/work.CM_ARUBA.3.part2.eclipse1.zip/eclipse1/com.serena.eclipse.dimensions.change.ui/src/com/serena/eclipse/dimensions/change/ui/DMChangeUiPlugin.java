package com.serena.eclipse.dimensions.change.ui;

import java.lang.reflect.InvocationTargetException;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.plugin.AbstractUIPlugin;

import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;

/**
 * The main plugin class to be used in the desktop.
 */
public class DMChangeUiPlugin extends AbstractUIPlugin /* implements IDoubleClickListener */{
    public static final String ID = "com.serena.eclipse.dimensions.change.ui"; //$NON-NLS-1$

    static final DMTypeScope[] DOC_SCOPES = new DMTypeScope[] { DMTypeScope.REQUEST };

    // The shared instance.
    private static DMChangeUiPlugin plugin;
    // Resource bundle.
    private ResourceBundle resourceBundle;

    /**
     * The constructor.
     */
    public DMChangeUiPlugin() {
        super();
        plugin = this;
        try {
            resourceBundle = ResourceBundle.getBundle("com.serena.eclipse.dimensions.change.ui.DMChangeUiPluginResources"); //$NON-NLS-1$
        } catch (MissingResourceException x) {
            resourceBundle = null;
        }
    }

    /**
     * Returns the shared instance.
     */
    public static DMChangeUiPlugin getDefault() {
        return plugin;
    }

    /**
     * Returns the string from the plugin's resource bundle,
     * or 'key' if not found.
     */
    public static String getResourceString(String key) {
        ResourceBundle bundle = DMChangeUiPlugin.getDefault().getResourceBundle();
        try {
            return (bundle != null) ? bundle.getString(key) : key;
        } catch (MissingResourceException e) {
            return key;
        }
    }

    /**
     * Returns the plugin's resource bundle,
     */
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    public void handle(Throwable t) {
        handle(t, null, null, null);
    }

    public void handle(Throwable t, Shell shell) {
        handle(t, shell, null, null);
    }

    public void handle(Throwable t, Shell shell, String errTitle, String errMsg) {
        // unwrap invocation tarhet exception
        if (t instanceof InvocationTargetException) {
            Throwable target = ((InvocationTargetException) t).getTargetException();
            if (target instanceof Error) {
                throw (Error) target;
            }
            handle(target, shell, errTitle, errMsg);
            return;
        }
        IStatus errStat = null;
        if (t instanceof CoreException) {
            errStat = ((CoreException) t).getStatus();
        } else {
            String msg = Utils.isNullEmpty(t.getMessage()) ? Messages.msg_noDetailsAvailable : t.getMessage();
            errStat = new Status(IStatus.ERROR, ID, 0, msg, t);
        }
        handle(errStat, shell, errTitle, errMsg);
    }

    public void handle(IStatus errorStatus) {
        handle(errorStatus, null, null, null);
    }

    public void handle(IStatus errorStatus, Shell shell) {
        handle(errorStatus, shell, null, null);
    }

    public void handle(IStatus errorStatus, Shell shell, String errTitle, String errMsg) {
        if (!errorStatus.matches(IStatus.CANCEL | IStatus.OK)) {
            if (shell == null) {
                shell = UIUtils.findShell();
            }
            if (errTitle == null) {
                errTitle = Messages.err_error;
            }
            if (errMsg == null) {
                errMsg = Messages.err_genericMsg;
            }
            getLog().log(errorStatus);
            IStatus svcInfo = Utils.getServiceInfo(errorStatus, getBundle());
            UIUtils.showError(shell, errTitle, errMsg, svcInfo);
        }
    }

}

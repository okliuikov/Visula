/*
 * @EditChangeDocumentAttributesAction.java, created on Apr 17, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.util.Iterator;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.IStructuredSelection;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.editors.AttributesPage;

/**
 * Opens attributes page.
 *
 * @author V.Grishchenko
 */
public class EditChangeDocumentAttributesAction extends DimensionsAction {

    public EditChangeDocumentAttributesAction() {
    }

    @Override
    public void run(IAction action) {
        IStructuredSelection ssel = getSelection();
        if (ssel.isEmpty()) {
            return;
        }
        for (Iterator iter = ssel.iterator(); iter.hasNext();) {
            Object object = iter.next();
            if (object instanceof ChangeDocumentAdapter) {
                try {
                    IDimensionsObjectEditHandler handler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.REQUEST);
                    if (handler != null) {
                        handler.openEditor((ChangeDocumentAdapter) object, AttributesPage.ID);
                    }
                } catch (CoreException e) {
                    DMChangeUiPlugin.getDefault().handle(e);
                }
            }
        }
    }

}

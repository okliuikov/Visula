/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.change.ui;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Composite;

import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsObjectList;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.RequestListPage;
import com.serena.eclipse.dimensions.internal.ui.AttributeColumnDetails;
import com.serena.eclipse.dimensions.internal.ui.AttributeUtils;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListConfiguration;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListPage;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectListContainer;
import com.serena.eclipse.dimensions.internal.ui.TableColumnModel;

/**
 * Change document list display configuration, defined per document list
 * category (user pending, other pending, custom, jobs, draft). Multiple
 * lists of the same category from the same connection shared the same
 * configuration. Note: This class is not thread safe.
 *
 * @author V.Grishchenko
 */
public class DocumentListConfiguration extends DimensionsObjectListConfiguration {

    public static final QualifiedName GENERIC_KEY = new QualifiedName(DocumentListConfiguration.class.getName(), "generic_config"); //$NON-NLS-1$
    public static final QualifiedName MY_PENDING_KEY = new QualifiedName(DocumentListConfiguration.class.getName(),
            "my_pending_config"); //$NON-NLS-1$
    public static final QualifiedName OTHER_PENDING_KEY = new QualifiedName(DocumentListConfiguration.class.getName(),
            "other_pending_config"); //$NON-NLS-1$
    public static final QualifiedName CUSTOM_KEY = new QualifiedName(DocumentListConfiguration.class.getName(), "custom_config"); //$NON-NLS-1$
    public static final QualifiedName DRAFT_KEY = new QualifiedName(DocumentListConfiguration.class.getName(), "draft_config"); //$NON-NLS-1$
    public static final QualifiedName JOB_KEY = new QualifiedName(DocumentListConfiguration.class.getName(), "job_config"); //$NON-NLS-1$
    public static final QualifiedName ACTIVE_KEY = new QualifiedName(DocumentListConfiguration.class.getName(), "active_config"); //$NON-NLS-1$

    private AttributeColumnDetails[] defaultSortOrder;
    private AttributeColumnDetails[] defaultGroupOrder;

    /**
     * @param con
     */
    public DocumentListConfiguration(DimensionsConnectionDetailsEx con, QualifiedName cat) {
        super(DMTypeScope.REQUEST, con, cat);
        assert cat != null;
    }

    @Override
    public boolean isMultiPage() {
        return true;
    }

    @Override
    public String getPageTitle(DimensionsObjectList list) {
        if (list instanceof ChangeDocumentList) {
            switch (list.getType()) {
            case ChangeDocumentList.MY_PENDING:
                return Messages.docList_page_myPending;
            case ChangeDocumentList.OTHER_PENDING:
                return NLS.bind(Messages.docList_page_otherPending, list.getQualifier());
            case ChangeDocumentList.CUSTOM:
                return NLS.bind(Messages.docList_page_custom, list.getQualifier());
            case ChangeDocumentList.DRAFT:
                return Messages.docList_page_drafts;
            case ChangeDocumentList.JOB:
                return list.getQualifier();
            default:
                return DMTypeScope.REQUEST.getMultipleDisplayText(false);
            }
        }
        return super.getPageTitle(list);
    }

    @Override
    public ImageDescriptor getImageDescriptor(DimensionsObjectList list) {
        String imgId = IDMImages.ISSUES;
        if (list != null) {
            switch (list.getType()) {
            case ChangeDocumentList.DRAFT:
                imgId = IDMImages.DRAFTS;
                break;
            case ChangeDocumentList.CUSTOM:
            case ChangeDocumentList.JOB:
                imgId = IDMImages.REQUEST_LIST;
                break;
            }
        }
        return DMUIPlugin.getDefault().getImageDescriptor(imgId);
    }

    @Override
    protected AttributeColumnDetails[] getDefaultColumns() {
        AttributeColumnDetails[] defaults = new AttributeColumnDetails[5];
        defaults[0] = createSystem(SystemAttributes.TITLE);
        defaults[1] = createSystem(SystemAttributes.OBJECT_ID);
        defaults[2] = createSystem(SystemAttributes.STATUS);
        defaults[3] = createSystem(SystemAttributes.CM_PHASE);
        defaults[4] = createSystem(SystemAttributes.LAST_ACTIONED_DATE);
        return defaults;
    }

    @Override
    protected AttributeColumnDetails createSystem(int attNumber) {
        AttributeColumnDetails sysCol = super.createSystem(attNumber);
        if (attNumber == SystemAttributes.NUMBER) { // put more recent numbers on top
            sysCol.setDefaultSortDirection(TableColumnModel.ORDER_DESCENDING);
        }
        return sysCol;
    }

    @Override
    protected AttributeColumnDetails[] getSystemColumns() {
        int[] sysAttrs = AttributeUtils.getChangeDocumentSystemAttributes();
        ArrayList result = new ArrayList(sysAttrs.length);
        for (int i = 0; i < sysAttrs.length; i++) {
            // Exclude description as it can be long (it is stored as CLOB)
            // and there are issues with concurrent use of bulk operators
            // if description is requested
            if (sysAttrs[i] != SystemAttributes.DESCRIPTION) {
                result.add(createSystem(sysAttrs[i]));
            }
        }
        return (AttributeColumnDetails[]) result.toArray(new AttributeColumnDetails[result.size()]);
    }

    @Override
    public AttributeColumnDetails[] getSortOrderForColumn(AttributeColumnDetails col) {
        AttributeColumnDetails[] result;
        AttributeColumnDetails[] dflt = getDefaultSortOrder();
        if (col.getAttrNum() == SystemAttributes.OBJECT_ID) {
            result = dflt;
        } else if (col.getAttrNum() == SystemAttributes.PRODUCT_NAME) {
            result = dflt;
        } else if (col.getAttrNum() == SystemAttributes.TYPE_NAME) {
            result = new AttributeColumnDetails[3];
            result[0] = dflt[1]; // type
            result[1] = dflt[0]; // product
            result[2] = dflt[2]; // number
        } else if (col.getAttrNum() == SystemAttributes.NUMBER) {
            result = new AttributeColumnDetails[3];
            result[0] = dflt[2]; // number
            result[1] = dflt[0]; // product
            result[2] = dflt[1]; // type
        } else {
            result = new AttributeColumnDetails[dflt.length + 1];
            result[0] = col;
            System.arraycopy(dflt, 0, result, 1, dflt.length);
        }
        return result;
    }

    @Override
    public boolean isPartOfSortColumn(AttributeColumnDetails col) {
        if (((AttributeColumnDetails) getSortColumn()).getAttrNum() == SystemAttributes.OBJECT_ID) {
            switch (col.getAttrNum()) {
            case SystemAttributes.PRODUCT_NAME:
            case SystemAttributes.TYPE_NAME:
            case SystemAttributes.NUMBER:
                return true;
            default:
                return false;
            }
        }
        return super.isPartOfSortColumn(col);
    }

    @Override
    protected AttributeColumnDetails[] getDefaultGrouping() {
        // TODO VG on Jul 7, 2005: thread safe?
        if (defaultGroupOrder == null) {
            List defgrporder = new ArrayList();
            defgrporder.add(createSystem(SystemAttributes.PROJECT));
            AttributeColumnDetails[] _defaultGroupOrder = (AttributeColumnDetails[]) defgrporder.toArray(new AttributeColumnDetails[defgrporder.size()]);

            defaultGroupOrder = _defaultGroupOrder;
        }
        return defaultGroupOrder;
    }

    public AttributeColumnDetails[] getDefaultSortOrder() {
        // TODO VG on Jul 7, 2005: thread safe?
        if (defaultSortOrder == null) {
            AttributeColumnDetails[] _defaultSortOrder = new AttributeColumnDetails[3];
            _defaultSortOrder[0] = createSystem(SystemAttributes.PRODUCT_NAME);
            _defaultSortOrder[1] = createSystem(SystemAttributes.TYPE_NAME);
            _defaultSortOrder[2] = createSystem(SystemAttributes.NUMBER);
            defaultSortOrder = _defaultSortOrder;
        }
        return defaultSortOrder;
    }

    @Override
    public AttributeColumnDetails getDefaultSortColumn() {
        return createSystem(SystemAttributes.OBJECT_ID);
    }

    @Override
    public DimensionsObjectListPage createPage(IDimensionsObjectListContainer part, Composite parent) {
        return new RequestListPage(part, parent);
    }

}

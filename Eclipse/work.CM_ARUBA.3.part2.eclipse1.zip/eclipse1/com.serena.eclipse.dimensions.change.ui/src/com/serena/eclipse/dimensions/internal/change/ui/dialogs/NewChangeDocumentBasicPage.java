/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.collections.AttributeDefinitions;
import com.serena.dmclient.collections.PrimingRelationships;
import com.serena.dmclient.collections.Products;
import com.serena.dmclient.collections.Types;
import com.serena.dmclient.objects.AttributeDefinition;
import com.serena.dmclient.objects.AttributeMappingDetails;
import com.serena.dmclient.objects.AttributeType;
import com.serena.dmclient.objects.PrimingRelationship;
import com.serena.dmclient.objects.Product;
import com.serena.dmclient.objects.RequestType;
import com.serena.dmclient.objects.Type;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMPreferences;

/**
 * @author abollmann
 *         Basic information page for the new object wizard
 */
public class NewChangeDocumentBasicPage extends WizardPage {
    private Combo productCombo;
    private Combo typeCombo;
    private Text titleText, fromFileText, descriptionText;
    private Button fromFileButton, descriptionButton, fileButton;
    private DimensionsConnectionDetailsEx conn;
    private Map<String, Types> chdocTypes;
    private String products[];
    private String selectedProductId, selectedTypeId;
    private IWizard wizard;
    private ChangeDocumentAdapter basedOnChdoc;
    private RequestType selectedChangeDocumentType;
    private String errorMessage;
    private boolean isTitleMandatory, isDescMandatory;

    public NewChangeDocumentBasicPage(String pageName, String title, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx conn, ChangeDocumentAdapter basedOnChdoc) {
        super(pageName, title, titleImage);
        setDescription(Messages.new_basic_chdoc_description);
        this.conn = conn;
        this.basedOnChdoc = basedOnChdoc;
        chdocTypes = new HashMap<String, Types>();
        Runnable r = new Runnable() {

            @Override
            public void run() {
                try {
                    List<Product> allProducts = NewChangeDocumentBasicPage.this.conn.getProducts(new NullProgressMonitor());
                    List<String> productNames = new ArrayList<String>();
                    for (Iterator<Product> prodIter = allProducts.iterator(); prodIter.hasNext();) {
                        Product product = prodIter.next();
                        String productName = product.getName();
                        if (IDMConstants.TEMPLATE_PRODUCT.equals(productName)) {
                            continue;
                        }
                        productNames.add(productName);
                        Types types = product.getRequestTypes();
                        chdocTypes.put(productName, types);
                    }
                    products = productNames.toArray(new String[productNames.size()]);
                } catch (DMException e) {
                    DMUIPlugin.getDefault().handle(e);
                }
            }
        };

        BusyIndicator.showWhile(Display.getDefault(), r);

    }

    @Override
    public void createControl(Composite parent) {
        wizard = getWizard();
        Composite composite = new Composite(parent, SWT.NULL);
        Color background = composite.getBackground();
        GridLayout gridLayout = new GridLayout();
        gridLayout.numColumns = 1;
        composite.setLayout(gridLayout);
        GridData gridData = new GridData(GridData.FILL_BOTH);
        composite.setLayoutData(gridData);

        Composite composite1 = new Composite(composite, SWT.NULL);
        composite1.setBackground(background);
        gridLayout = new GridLayout();
        gridLayout.numColumns = 4;
        composite1.setLayout(gridLayout);
        gridData = new GridData(GridData.FILL_BOTH | GridData.GRAB_HORIZONTAL);
        composite1.setLayoutData(gridData);

        if (basedOnChdoc != null) {
            selectedProductId = (String) basedOnChdoc.getAPIObject().getAttribute(SystemAttributes.PRODUCT_NAME);
            if (Utils.isNullEmpty(selectedProductId)) {
                basedOnChdoc.getAPIObject().queryAttribute(SystemAttributes.PRODUCT_NAME);
                selectedProductId = (String) basedOnChdoc.getAPIObject().getAttribute(SystemAttributes.PRODUCT_NAME);
            }
        } else {
            selectedProductId = ""; //$NON-NLS-1$
        }
        int selectedProductIndex = -1;
        for (int i = 0; i < products.length; i++) {
            if (products[i].equals(selectedProductId)) {
                selectedProductIndex = i;
            }
        }
        Label productLabel = new Label(composite1, SWT.NULL);
        productLabel.setBackground(background);
        productLabel.setText(Messages.new_basic_chdoc_product);
        productCombo = new Combo(composite1, SWT.READ_ONLY);
        productCombo.setItems(products);
        if (selectedProductIndex != -1) {
            productCombo.select(selectedProductIndex);
        } else {
            productCombo.select(0);
        }
        productCombo.addSelectionListener(new ProductListener());

        Label typeLabel = new Label(composite1, SWT.NULL);
        typeLabel.setText(Messages.new_basic_chdoc_type);
        typeLabel.setBackground(background);

        typeCombo = new Combo(composite1, SWT.READ_ONLY);
        typeCombo.addSelectionListener(new TypeListener());

        Composite composite2 = new Composite(composite, SWT.NULL);
        gridLayout = new GridLayout();
        gridLayout.numColumns = 2;
        composite2.setLayout(gridLayout);
        gridData = new GridData(GridData.FILL_BOTH);
        composite2.setLayoutData(gridData);

        Label titleLabel = new Label(composite2, SWT.NULL);
        titleLabel.setText(Messages.new_basic_chdoc_titleLabel);
        titleText = new Text(composite2, SWT.BORDER);
        gridData = new GridData(GridData.FILL_HORIZONTAL | GridData.GRAB_HORIZONTAL);
        titleText.setLayoutData(gridData);
        titleText.addModifyListener(new TitleListener());

        Composite composite3 = new Composite(composite, SWT.NULL);
        gridLayout = new GridLayout();
        gridLayout.numColumns = 2;
        composite3.setLayout(gridLayout);
        gridData = new GridData(GridData.FILL_BOTH | GridData.GRAB_HORIZONTAL);
        composite3.setLayoutData(gridData);

        Group group = new Group(composite3, SWT.NONE);
        gridLayout = new GridLayout();
        gridLayout.numColumns = 4;
        gridData = new GridData(GridData.FILL_BOTH | GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_BEGINNING);
        group.setLayoutData(gridData);
        group.setLayout(gridLayout);
        group.setText(Messages.new_basic_description);

        fromFileButton = new Button(group, SWT.RADIO);
        fromFileButton.setText(Messages.new_basic_fromFile);
        fromFileButton.addSelectionListener(new FromFileListener());

        fromFileText = new Text(group, SWT.BORDER);
        gridData = new GridData(GridData.FILL_HORIZONTAL | GridData.GRAB_HORIZONTAL);
        gridData.horizontalSpan = 2;
        fromFileText.setLayoutData(gridData);
        fromFileText.setEnabled(false);

        fileButton = new Button(group, SWT.NONE);
        gridData = new GridData(GridData.FILL_HORIZONTAL);
        fileButton.setText("..."); //$NON-NLS-1$
        fileButton.addSelectionListener(new FileListener());
        fileButton.setEnabled(false);

        descriptionButton = new Button(group, SWT.RADIO | SWT.CENTER);
        descriptionButton.setText(Messages.new_basic_text);
        descriptionButton.setSelection(true);
        descriptionButton.addSelectionListener(new DescriptionButtonListener());
        gridData = new GridData(GridData.VERTICAL_ALIGN_BEGINNING);
        descriptionButton.setLayoutData(gridData);
        descriptionText = new Text(group, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.MULTI);
        descriptionText.setFont(JFaceResources.getFontRegistry().get(IDMPreferences.REQUEST_DESCR_FONT));

        gridData = new GridData(GridData.FILL_BOTH);
        gridData.horizontalSpan = 3;
        gridData.heightHint = 100;
        descriptionText.setLayoutData(gridData);
        descriptionText.addModifyListener(new DescriptionListener());

        fillLists();
        setControl(composite);
        // force it to process messages Windows 7 on first invocation isn't drawing correctly
        getShell().getDisplay().readAndDispatch();
    }

    void fillLists() {
        int index = productCombo.getSelectionIndex();
        if (index != -1) {
            selectedProductId = productCombo.getItem(index);
            String chdocTypesArray[] = getProductTypes(selectedProductId);
            typeCombo.setItems(chdocTypesArray);
            if (chdocTypesArray.length > 0) {
                typeCombo.select(0);
                setChangeDocumentType();
            }
        }
    }

    String[] getProductTypes(String selectedProductId) {
        final Types types = chdocTypes.get(selectedProductId);
        final List<String> chdocTypesList = new ArrayList<String>(types.size());

        Runnable r = new Runnable() {

            @Override
            public void run() {
                for (Iterator typeIter = types.iterator(); typeIter.hasNext();) {
                    String typeName = (String) typeIter.next();
                    Type type = types.get(typeName);
                    if (!type.isDisabled()) {
                        chdocTypesList.add(type.getName());
                    }
                }
            }
        };
        BusyIndicator.showWhile(Display.getDefault(), r);
        final String[] chdocTypesArray = chdocTypesList.toArray(new String[chdocTypesList.size()]);

        return chdocTypesArray;
    }

    void fillTitleAndDescriptionFromPage() {
        NewChangeDocumentBasedOnPage page = (NewChangeDocumentBasedOnPage) wizard.getPage(Messages.new_baseIssueOn_pageName);
        if (page != null) {
            final Request selectedIssue = page.getSelectedIssue();
            Runnable r = new Runnable() {

                @Override
                public void run() {
                    fillTitleAndDescription(selectedIssue);
                }
            };
            BusyIndicator.showWhile(Display.getDefault(), r);
        }
    }

    void fillTitleAndDescription(final Request fromChdoc) {
        if (fromChdoc == null) {
            // Nothing to fill in
            return;
        }

        try {
            final Session session = conn.openSession(null);
            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    final boolean[] doTitle = new boolean[] { false };
                    final boolean[] doDescription = new boolean[] { false };
                    PrimingRelationships prs = ((RequestType) fromChdoc.getType()).getPrimingRelationships();
                    for (Iterator iter = prs.iterator(); iter.hasNext();) {
                        String prName = (String) iter.next();
                        PrimingRelationship pr = prs.get(prName);
                        if (typesEqual(selectedChangeDocumentType, pr.getPrimeableType())) {
                            AttributeDefinitions sfsvDefs = fromChdoc.getType().getAttributeDefinitions(AttributeType.SFSV);
                            AttributeDefinitions sfmvDefs = fromChdoc.getType().getAttributeDefinitions(AttributeType.SFMV);
                            List mappings = pr.getAttributeMappings();

                            List attrToQueryList = new ArrayList();
                            for (Iterator mappingIter = mappings.iterator(); mappingIter.hasNext();) {
                                AttributeMappingDetails amd = (AttributeMappingDetails) mappingIter.next();
                                AttributeDefinition fromDef = sfsvDefs.get(amd.getFromAttributeName());
                                if (fromDef == null) {
                                    fromDef = sfmvDefs.get(amd.getFromAttributeName());
                                }
                                AttributeDefinition toDef = sfsvDefs.get(amd.getToAttributeName());
                                if (toDef == null) {
                                    toDef = sfmvDefs.get(amd.getToAttributeName());
                                }
                                if (fromDef != null) {
                                    fromDef.getNumber();
                                    if (toDef != null && toDef.getNumber() == 1) {
                                        // the title attribute is mapped
                                        attrToQueryList.add(new Integer(fromDef.getNumber()));
                                        doTitle[0] = true;
                                    }

                                    if (amd.getToAttributeName().equals("PCMS_CHDOC_DETAIL_DESC")) { //$NON-NLS-1$
                                        if (amd.getFromAttributeName().equals("PCMS_CHODC_DETAIL_DESC")) {
                                            attrToQueryList.add(new Integer(SystemAttributes.DESCRIPTION));
                                        } else {
                                            attrToQueryList.add(new Integer(fromDef.getNumber()));
                                        }
                                        doDescription[0] = true;
                                    }
                                }
                            }
                            final int[] attrToQuery = new int[attrToQueryList.size()];
                            for (int i = 0; i < attrToQueryList.size(); i++) {
                                attrToQuery[i] = ((Integer) attrToQueryList.get(i)).intValue();
                            }
                            fromChdoc.queryAttribute(attrToQuery);

                            Display.getDefault().asyncExec(new Runnable() {

                                @Override
                                public void run() {
                                    if (doTitle[0]) {
                                        String title = (String) fromChdoc.getAttribute(attrToQuery[0]);
                                        titleText.setText(title);
                                    }
                                    if (doDescription[0]) {
                                        String description = (String) fromChdoc.getAttribute(attrToQuery[1]);
                                        descriptionText.setText(description);
                                    }
                                }
                            });

                        }
                    }

                }

            }, new NullProgressMonitor());
        } catch (Exception e) {
            DMChangeUiPlugin.getDefault().handle(e);
        }
    }

    private boolean typesEqual(RequestType t1, RequestType t2) throws Exception {
        if (t1 == t2) {
            return true;
        }
        if (t1 != null && t2 != null) {
            return t1.getProduct().getName().equals(t2.getProduct().getName()) && t1.getName().equals(t2.getName());
        }
        return false;
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            fillTitleAndDescriptionFromPage();
        }
        super.setVisible(visible);
    }

    String getChdocProduct() {
        return selectedProductId;
    }

    String getChdocType() {
        int selectionIndex = typeCombo.getSelectionIndex();
        return selectionIndex == -1 ? Utils.EMPTY_STRING : typeCombo.getItem(selectionIndex);
    }

    RequestType getChdocTypeObject() {
        return selectedChangeDocumentType;
    }

    String getChdocTitle() {
        return titleText.getText();
    }

    String getDescriptionFileName() {
        if (fromFileText.isEnabled()) {
            return fromFileText.getText();
        } else {
            return ""; //$NON-NLS-1$
        }
    }

    String getChdocDescription() {
        if (descriptionText.isEnabled()) {
            return descriptionText.getText();
        } else {
            return ""; //$NON-NLS-1$
        }
    }

    private void setChangeDocumentType() {
        selectedProductId = productCombo.getItem(productCombo.getSelectionIndex());
        int typeIdx = typeCombo.getSelectionIndex();
        if (typeIdx == -1) {
            return;
        }
        selectedTypeId = typeCombo.getItem(typeIdx);
        Runnable r = new Runnable() {

            @Override
            public void run() {
                try {
                    final Session session = conn.openSession(null);
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            Products products = session.getObjectFactory().getBaseDatabaseAdmin().getProducts();
                            Product product = products.get(selectedProductId);
                            Types types = product.getRequestTypes();
                            selectedChangeDocumentType = (RequestType) types.get(selectedTypeId);
                            // Find out immediately if title and description are mandatory
                            List attrs = selectedChangeDocumentType.getTitleAndDescription();
                            AttributeDefinition title = (AttributeDefinition) attrs.get(0);
                            isTitleMandatory = title.getMandatory();
                            AttributeDefinition desc = (AttributeDefinition) attrs.get(1);
                            isDescMandatory = desc.getMandatory();
                        }
                    }, new NullProgressMonitor());
                    conn.getAttributeDefinitions(selectedChangeDocumentType, "$ORIGINATOR", false, new NullProgressMonitor()); //$NON-NLS-1$
                } catch (DMException dme) {
                    DMChangeUiPlugin.getDefault().handle(dme);
                }
            }
        };
        BusyIndicator.showWhile(Display.getDefault(), r);
    }

    private boolean isTitleComplete() {
        if (titleText.getText().length() == 0 && isTitleMandatory) {
            errorMessage = Messages.new_basic_title_error;
            return false;
        }
        return true;
    }

    private boolean isDescriptionComplete() {
        if (descriptionText.getText().length() == 0 && (fromFileText.getText().length() == 0 || !fromFileButton.getSelection())
                && isDescMandatory) {
            errorMessage = Messages.new_basic_description_error;
            return false;
        }
        return true;
    }

    private boolean isTypeSelected() {
        if (productCombo.getSelectionIndex() != -1 && typeCombo.getSelectionIndex() != -1) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isPageComplete() {
        return isTitleComplete() && isDescriptionComplete() && isTypeSelected();
    }

    class ProductListener implements SelectionListener {

        @Override
        public void widgetSelected(SelectionEvent e) {
            fillLists();
            selectedProductId = productCombo.getItem(productCombo.getSelectionIndex());

            int typeIdx = typeCombo.getSelectionIndex();
            if (typeIdx != -1) {
                selectedTypeId = typeCombo.getItem(typeIdx);
            }

            // Change the list of change documents in the based on dialog
            NewChangeDocumentBasedOnPage page = (NewChangeDocumentBasedOnPage) wizard.getPage(Messages.new_baseIssueOn_pageName);
            page.updateProduct(selectedProductId);
            // change the list of objects to select in the relate page
            NewChangeDocumentRelatePage relPage = (NewChangeDocumentRelatePage) wizard.getPage(Messages.new_relate_pageName);
            relPage.updateProduct(selectedProductId);
            fillTitleAndDescriptionFromPage();
            wizard.getContainer().updateButtons();
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }

    }

    class TypeListener implements SelectionListener {

        @Override
        public void widgetSelected(SelectionEvent e) {
            selectedProductId = productCombo.getItem(productCombo.getSelectionIndex());
            int selectionIndex = typeCombo.getSelectionIndex();
            if (selectionIndex != -1) {
                selectedTypeId = typeCombo.getItem(selectionIndex);
            }
            setChangeDocumentType();
            fillTitleAndDescriptionFromPage();
            wizard.getContainer().updateButtons();
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }

    }

    class FileListener implements SelectionListener {

        @Override
        public void widgetSelected(SelectionEvent e) {
            FileDialog fileDialog = new FileDialog(getShell());
            String fullFileName = fileDialog.open();
            if (fullFileName == null) {
                return;
            }

            fromFileText.setText(fullFileName);
            fromFileText.redraw();
            if (!isDescriptionComplete()) {
                setErrorMessage(errorMessage);
            } else {
                setErrorMessage(null);
            }
            wizard.getContainer().updateButtons();
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }

    }

    class FromFileListener implements SelectionListener {
        @Override
        public void widgetSelected(SelectionEvent e) {
            fromFileText.setEnabled(true);
            fileButton.setEnabled(true);
            descriptionText.setEnabled(false);
            if (!isDescriptionComplete()) {
                setErrorMessage(errorMessage);
            } else {
                setErrorMessage(null);
            }
            wizard.getContainer().updateButtons();
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }
    }

    class DescriptionButtonListener implements SelectionListener {
        @Override
        public void widgetSelected(SelectionEvent e) {
            fromFileText.setEnabled(false);
            fileButton.setEnabled(false);
            descriptionText.setEnabled(true);
        }

        @Override
        public void widgetDefaultSelected(SelectionEvent e) {
        }
    }

    class TitleListener implements ModifyListener {

        @Override
        public void modifyText(ModifyEvent e) {
            if (!isTitleComplete()) {
                setErrorMessage(errorMessage);
            } else {
                setErrorMessage(null);
            }
            wizard.getContainer().updateButtons();
        }

    }

    class DescriptionListener implements ModifyListener {

        @Override
        public void modifyText(ModifyEvent e) {
            if (!isPageComplete()) {
                setErrorMessage(errorMessage);
            } else {
                setErrorMessage(null);
            }
            wizard.getContainer().updateButtons();
        }

    }
}

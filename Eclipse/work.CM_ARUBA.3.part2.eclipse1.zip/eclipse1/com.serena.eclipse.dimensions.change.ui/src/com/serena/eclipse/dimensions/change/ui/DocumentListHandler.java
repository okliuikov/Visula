/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.change.ui;

import org.eclipse.core.runtime.QualifiedName;

import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DimensionsObjectList;
import com.serena.eclipse.dimensions.internal.change.ui.IDMChangePreferences;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListConfiguration;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListHandler;

/**
 * Opens change document list editor or view.
 *
 * @author V.Grishchenko
 */
public class DocumentListHandler extends DimensionsObjectListHandler {

    public DocumentListHandler() {
        super(DMChangeUiPlugin.DOC_SCOPES);
    }

    @Override
    protected boolean isViewMode() {
        return IDMChangePreferences.CHANGE_DOC_LIST_DISPLAY_VIEW_VAL.equals(DMChangeUiPlugin.getDefault()
                .getPreferenceStore()
                .getString(IDMChangePreferences.CHANGE_DOC_LIST_DISPLAY));
    }

    @Override
    protected boolean isMultiPage() {
        return true;
    }

    @Override
    protected DimensionsObjectListConfiguration createConfiguration(DimensionsObjectList list, QualifiedName qualifier) {
        return new DocumentListConfiguration(list.getConnectionDetails(), qualifier);
    }

    @Override
    protected QualifiedName getConfigQualifier(DimensionsObjectList list) {
        if (list instanceof ChangeDocumentList) {
            switch (list.getType()) {
            case ChangeDocumentList.MY_PENDING:
                // case ChangeDocumentList.DRAFT:
                return DocumentListConfiguration.MY_PENDING_KEY;
            case ChangeDocumentList.OTHER_PENDING:
                return DocumentListConfiguration.OTHER_PENDING_KEY;
            case ChangeDocumentList.CUSTOM:
                return DocumentListConfiguration.CUSTOM_KEY;
            case ChangeDocumentList.DRAFT:
                return DocumentListConfiguration.DRAFT_KEY;
            case ChangeDocumentList.JOB:
                return DocumentListConfiguration.JOB_KEY;
            case ChangeDocumentList.ACTIVE_ISSUES:
                return DocumentListConfiguration.ACTIVE_KEY;
            default:
                return DocumentListConfiguration.GENERIC_KEY;
            }
        }
        return DocumentListConfiguration.GENERIC_KEY;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.editors;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.eclipse.dimensions.internal.change.ui.forms.ActionDescriptionPanel;
import com.serena.eclipse.dimensions.internal.change.ui.model.IActionDescriptionModel;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditor;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorPage;
import com.serena.eclipse.dimensions.internal.ui.forms.ObjectDetailsSection;

/**
 * @author V.Grishchenko
 */
public class ActionDescriptionPage extends DimensionsObjectEditorPage {
    static final String ID = "details_page_id"; //$NON-NLS-1$
    private ActionDescriptionPanel adp;

    public ActionDescriptionPage(DimensionsObjectEditor editor, String title, String formText, IActionDescriptionModel model) {
        super(editor, ID, title, formText, model);
    }

    @Override
    protected void fillBody(IManagedForm managedForm, FormToolkit toolkit) {
        Composite body = managedForm.getForm().getBody();
        UIUtils.setGridLayout(body, 1);

        ObjectDetailsSection section = createObjectDetailsSection(body);
        if (section != null) {
            UIUtils.setGridData(section.getSection(), GridData.FILL_HORIZONTAL);
        }
        IActionDescriptionModel descriptionModel = (IActionDescriptionModel) getModel();

        adp = new ActionDescriptionPanel(managedForm, descriptionModel, body);
        UIUtils.setGridData(adp.getPanel(), GridData.FILL_BOTH);
        managedForm.addPart(adp);
    }

}

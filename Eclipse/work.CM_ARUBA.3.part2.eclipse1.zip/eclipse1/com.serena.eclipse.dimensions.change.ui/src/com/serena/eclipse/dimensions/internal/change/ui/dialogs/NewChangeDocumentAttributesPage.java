/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;

import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.RequestDetails;
import com.serena.dmclient.objects.AttributeDefinition;
import com.serena.dmclient.objects.RequestType;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.atts.SFAttributeValue;
import com.serena.eclipse.dimensions.internal.ui.forms.AttributePanel;
import com.serena.eclipse.dimensions.internal.ui.forms.FormWizardPage;
import com.serena.eclipse.dimensions.internal.ui.forms.IAttributePanelContainer;
import com.serena.eclipse.dimensions.internal.ui.model.AttributeModel;
import com.serena.eclipse.dimensions.internal.ui.model.ChangeDocumentAttributeModel;

/**
 * @author abollmann
 *
 *         Attributes page in the new object wizard
 */
public class NewChangeDocumentAttributesPage extends FormWizardPage {
    private DimensionsConnectionDetailsEx conn;
    private AttributePanel panel;
    private AttributeModel attrModel;
    private String description;
    private IWizard wizard;
    private Request lastSelectedIssue;
    private RequestType lastSelectedType;

    public NewChangeDocumentAttributesPage(String pageName, String title, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx conn) {
        super(pageName, title, titleImage);
        description = Messages.new_attr_description;
        setDescription(description);
        this.conn = conn;
    }

    @Override
    protected void createFormContents(Composite form) {
        UIUtils.setGridLayout(form, 1);
        prepareModel(true);
        panel = new AttributePanel(getManagedForm(), attrModel, form, SWT.NONE);
        getManagedForm().addPart(panel);
        UIUtils.setGridData(panel.getPanel(), GridData.FILL_BOTH);
        panel.setContainer(new AttributePanelContainer());

    }

    // creates and loads the model
    private boolean prepareModel(boolean reload) {
        wizard = getWizard();

        NewChangeDocumentBasedOnPage basedOnPage = (NewChangeDocumentBasedOnPage) wizard.getPage(Messages.new_baseIssueOn_pageName);
        Request selectedIssue = basedOnPage.getSelectedIssue();
        NewChangeDocumentBasicPage basicPage = (NewChangeDocumentBasicPage) wizard.getPage(Messages.new_basic_pageName);
        RequestType type = basicPage.getChdocTypeObject();
        if (selectedIssue == lastSelectedIssue && type == lastSelectedType) {
            return true;
        }
        lastSelectedIssue = selectedIssue;
        lastSelectedType = type;

        RequestDetails details = new RequestDetails();
        if (reload || attrModel == null) {
            attrModel = new ChangeDocumentAttributeModel(details, lastSelectedType, conn, selectedIssue);
            try {
                getWizard().getContainer().run(true, false, new IRunnableWithProgress() {
                    @Override
                    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                        try {
                            attrModel.load(monitor);
                            monitor.setTaskName(""); //$NON-NLS-1$
                            monitor.subTask(""); //$NON-NLS-1$
                        } catch (DMException e) {
                            throw new InvocationTargetException(e);
                        }
                    }
                });
                return true;
            } catch (InvocationTargetException e) {
                DMUIPlugin.getDefault().handle(e);
            } catch (InterruptedException ignore) {
            }
        } else {
            return true;
        }
        return false;
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            prepareModel(true);
            panel.setModel(attrModel);
        }
        super.setVisible(visible);
    }

    // updates the page with messages coming from the attribute panel
    class AttributePanelContainer implements IAttributePanelContainer {
        @Override
        public void validStateChanged(boolean newValidState) {
            wizard.getContainer().updateButtons();
        }

        @Override
        public void setInfoMessage(String msg) {
            NewChangeDocumentAttributesPage.this.setMessage(msg, INFORMATION);
        }

        @Override
        public void setWarningMessage(String msg) {
            NewChangeDocumentAttributesPage.this.setMessage(msg, WARNING);
        }

        @Override
        public void setMessage(String msg) {
            if (Utils.isNullEmpty(msg)) {
                msg = description;
            }
            NewChangeDocumentAttributesPage.this.setMessage(description);
        }

        @Override
        public void setErrorMessage(String msg) {
            NewChangeDocumentAttributesPage.this.setErrorMessage(msg);
        }

        @Override
        public void run(boolean fork, boolean cancelable, IRunnableWithProgress runnable) throws InvocationTargetException,
                InterruptedException {
            getContainer().run(fork, cancelable, runnable);
        }
    }

    @Override
    public boolean canFlipToNextPage() {
        return panel.isValid();
    }

    @Override
    public boolean isPageComplete() {
        if (panel == null) {
            try {
                wizard = getWizard();
                NewChangeDocumentBasicPage basicPage = (NewChangeDocumentBasicPage) wizard.getPage(Messages.new_basic_pageName);
                RequestType type = basicPage.getChdocTypeObject();
                AttributeDefinition[] attrDefs = conn.getAttributeDefinitions(type, "$ORIGINATOR", false, new NullProgressMonitor()); //$NON-NLS-1$
                for (int i = 0; i < attrDefs.length; i++) {
                    if (attrDefs[i].getMandatory()) {
                        return false;
                    }
                }

            } catch (DMException e) {
                DMUIPlugin.getDefault().handle(e);
            }

            return true;
        }
        return panel.isValid();
    }

    public String getChangedAttributesString() {
        String allAttributes = ""; //$NON-NLS-1$
        if (attrModel == null) {
            return allAttributes;
        }
        SFAttributeValue[] values = attrModel.getAllValues();
        for (int i = 0; i < values.length; i++) {
            SFAttributeValue value = values[i];
            if (value.isModified()) {
                allAttributes += value.getAttributeDefinition().getName();
                allAttributes += "="; //$NON-NLS-1$
                if (value.isSingle()) {
                    allAttributes += (String) value.getValue();
                    allAttributes += ","; //$NON-NLS-1$
                } else {
                    List valueList = (List) value.getValue();
                    for (int j = 0; j < valueList.size(); j++) {
                        allAttributes += (String) valueList.get(j);
                        allAttributes += ","; //$NON-NLS-1$
                    }
                }
            }
        }
        return allAttributes;
    }

    public List<SFAttributeValue> getChangedAttributes() {
        List<SFAttributeValue> attributes = new ArrayList<SFAttributeValue>();
        if (attrModel == null) {
            return attributes;
        }
        SFAttributeValue[] values = attrModel.getAllValues();
        for (int i = 0; i < values.length; i++) {
            SFAttributeValue value = values[i];
            if (value.isModified()) {
                attributes.add(value);
            }
        }
        return attributes;
    }

}

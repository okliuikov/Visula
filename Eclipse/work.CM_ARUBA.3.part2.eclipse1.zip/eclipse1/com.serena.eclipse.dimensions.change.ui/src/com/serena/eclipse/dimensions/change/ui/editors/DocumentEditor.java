/*
 * @DocumentEditor.java, created on May 16, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.change.ui.editors;

import java.util.Collection;
import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.editor.IFormPage;
import org.eclipse.ui.forms.widgets.ExpandableComposite;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.editors.ActionDescriptionPage;
import com.serena.eclipse.dimensions.internal.change.ui.editors.AttachmentsPage;
import com.serena.eclipse.dimensions.internal.change.ui.editors.DocumentDetailsPage;
import com.serena.eclipse.dimensions.internal.change.ui.editors.DocumentHistoryPage;
import com.serena.eclipse.dimensions.internal.change.ui.forms.DocumentDetailsSection;
import com.serena.eclipse.dimensions.internal.change.ui.model.ChangeDocumentModel;
import com.serena.eclipse.dimensions.internal.change.ui.model.IChangeDocumentHistoryModel;
import com.serena.eclipse.dimensions.internal.change.ui.model.IChangeDocumentModel;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.editors.AttributesPage;
import com.serena.eclipse.dimensions.internal.ui.editors.DelegatesPage;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditor;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorPage;
import com.serena.eclipse.dimensions.internal.ui.editors.PrivilegesPage;
import com.serena.eclipse.dimensions.internal.ui.editors.RelatedObjectsPage;
import com.serena.eclipse.dimensions.internal.ui.editors.TemplateViewPage;
import com.serena.eclipse.dimensions.internal.ui.editors.UsersAndRolesPage;
import com.serena.eclipse.dimensions.internal.ui.forms.IObjectDetailsSectionHelper;
import com.serena.eclipse.dimensions.internal.ui.forms.ObjectDetailsSection;
import com.serena.eclipse.dimensions.internal.ui.model.IAggregateModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;

/**
 * @author V.Grishchenko
 */
public class DocumentEditor extends DimensionsObjectEditor implements IObjectDetailsSectionHelper {
    public static final String ID = "com.serena.eclipse.dimensions.change.editors.chDoc"; //$NON-NLS-1$

    @Override
    protected void pageChange(int newPageIndex) {
        super.pageChange(newPageIndex);
        IFormPage activePage = getActivePageInstance();
        if (activePage instanceof AttachmentsPage || activePage instanceof RelatedObjectsPage) {
            getContainer().layout(true, true);
        }
    }

    @Override
    protected void addPages() {
        try {
            ChangeDocumentModel docModel = (ChangeDocumentModel) getModel();
            addPage(new DocumentDetailsPage(this, Messages.detailsPage_title, Messages.detailsPage_text,
                    docModel.getSystemAttributeModel()));
            addPage(new AttributesPage(this, Messages.attPage_title, Messages.attPage_text, docModel.getUserAttributeModel()));
            addPage(new RelatedObjectsPage(this, docModel.getRelatedObjectsModel()));
            addPage(new ActionDescriptionPage(this, Messages.descPage_title, Messages.descPage_text, docModel.getDescriptionModel()));
            addPage(new DocumentHistoryPage(this, Messages.historyPage_title, Messages.historyPage_text,
                    (IChangeDocumentHistoryModel) docModel.getHistoryModel()));
            addPage(new AttachmentsPage(this, Messages.attachPage_title, Messages.attachPage_title, docModel.getAttachmentsModel()));
            addPage(new DelegatesPage(this, Messages.delegatesPage_title, Messages.delegatesPage_text, docModel.getDelegateModel()));
            addPage(new UsersAndRolesPage(this, Messages.usersAndRoles_title, Messages.usersAndRoles_text,
                    docModel.getUsersAndRolesModel()));
            addPage(new PrivilegesPage(this, Messages.privilegesPage_title, Messages.privilegesPage_text,
                    docModel.getPrivilegesModel()));
            addPage(new TemplateViewPage(this, Messages.templatePage_title, null, docModel.getPreviewModel()));
            activateInitialPage();
        } catch (PartInitException e) {
            DMChangeUiPlugin.getDefault().getLog().log(e.getStatus());
            IStatus svcInfo = Utils.getServiceInfo(e, DMChangeUiPlugin.getDefault().getBundle());
            UIUtils.showError(getSite().getShell(), Messages.err_error, Messages.err_addEditorPage, svcInfo);
        }
    }

    @Override
    public void init(IEditorSite site, IEditorInput input) throws PartInitException {
        if (!(input instanceof DocumentEditorInput)) {
            throw new PartInitException("Unexpected input: " + input.getClass().getName()); //$NON-NLS-1$
        }
        super.init(site, input);
    }

    @Override
    protected IAggregateModel createModel(APIObjectAdapter object) {
        return new ChangeDocumentModel((ChangeDocumentAdapter) object);
    }

    @Override
    public ObjectDetailsSection createDetailsSection(/* IDimensionsArObjectModel model, */Composite parent,
            DimensionsObjectEditorPage page) {
        boolean detailsPage = DocumentDetailsPage.ID.equals(page.getId());
        int style = detailsPage ? SWT.NONE : ExpandableComposite.TITLE_BAR | ExpandableComposite.TWISTIE;
        String title = detailsPage ? null : Messages.detailsPage_text;
        IDimensionsArObjectModel sysModel = ((IChangeDocumentModel) getModel()).getSystemAttributeModel();
        DocumentDetailsSection section = new DocumentDetailsSection(page, sysModel, parent, title, style);
        return section;
    }

    @Override
    protected List getModelsToReload(Collection savedModels) {
        List toReload = super.getModelsToReload(savedModels);
        ChangeDocumentModel docModel = (ChangeDocumentModel) getModel();
        if (savedModels.contains(docModel.getDelegateModel())) {
            toReload.add(docModel.getUsersAndRolesModel());
        }
        toReload.add(docModel.getPreviewModel()); // always refresh preview
        return toReload;
    }

}

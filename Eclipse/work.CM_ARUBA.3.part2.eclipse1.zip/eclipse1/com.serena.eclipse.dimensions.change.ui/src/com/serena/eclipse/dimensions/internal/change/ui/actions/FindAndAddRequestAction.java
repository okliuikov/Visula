/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ECustomChangeDocumentList;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;

/**
 * Finds change documents and adds them to a custom list.
 * @author V.Grishchenko
 */
public class FindAndAddRequestAction extends DimensionsAction {

    public FindAndAddRequestAction() {
    }

    @Override
    public void run(IAction action) {
        final IStructuredSelection selection = getSelection();
        if (selection.isEmpty()) {
            return;
        }

        if (selection.getFirstElement() instanceof ECustomChangeDocumentList) {
            final ECustomChangeDocumentList requestList = (ECustomChangeDocumentList) selection.getFirstElement();
            FindObjectWizardDialog dialog = new FindObjectWizardDialog(getShell(), IDMConstants.CHANGEDOCUMENT,
                    requestList.getConnectionDetails(), null, false, false);
            if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {
                final List<String> ids = dialog.getSelectedNames();
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            monitor.beginTask(NLS.bind(Messages.customList_adding, requestList.getQualifier()), 1000);
                            try {
                                List adapters = lookupRequests(requestList.getConnectionDetails(), ids,
                                        Utils.subMonitorFor(monitor, 500));
                                requestList.addChangeDocuments(adapters, Utils.subMonitorFor(monitor, 500));
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            } finally {
                                monitor.done();
                            }
                        }
                    });
                } catch (InvocationTargetException e1) {
                    DMChangeUiPlugin.getDefault().handle(e1, getShell());
                } catch (InterruptedException e1) {
                }
            }
        }
    }

    private List lookupRequests(DimensionsConnectionDetailsEx connection, final List ids, final IProgressMonitor monitor)
            throws DMException {
        final ArrayList result = new ArrayList(ids.size());
        final Session session = connection.openSession(null);
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                try {
                    monitor.beginTask(null, ids.size());
                    for (Iterator iter = ids.iterator(); iter.hasNext();) {
                        String requestId = (String) iter.next();
                        Request request = session.getObjectFactory().findRequest(requestId);
                        if (request != null) {
                            result.add(session.adapt(request));
                        }
                        monitor.worked(1);
                    }
                } finally {
                    monitor.done();
                }
            }
        }, monitor);
        return result;
    }

}

/*
 * @IDMChangePreferences.java, created on May 5, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui;

/**
 * Version management preference constants.
 *
 * @author V.Grishchenko
 */
public interface IDMChangePreferences {
    /** a string value that controls whether change documents lists are shown in view or editor */
    String CHANGE_DOC_LIST_DISPLAY = "chdoc_display"; //$NON-NLS-1$
    /** value for showing ch. doc. list in a view */
    String CHANGE_DOC_LIST_DISPLAY_VIEW_VAL = "v"; //$NON-NLS-1$
    /** value for showing ch. doc. list in an editor */
    String CHANGE_DOC_LIST_DISPLAY_EDITOR_VAL = "e"; //$NON-NLS-1$
    /** a boolean that controls whether change docuemnt lists should be shown in a multi-page view or editor */
    String CHANGE_DOC_LIST_DISPLAY_MULTIPAGE = "chdoc_display_multi"; //$NON-NLS-1$
}

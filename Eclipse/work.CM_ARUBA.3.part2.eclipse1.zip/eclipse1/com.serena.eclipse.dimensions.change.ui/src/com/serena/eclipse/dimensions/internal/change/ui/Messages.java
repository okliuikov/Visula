/*
 * @Messages.java, created on May 5, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui;

import org.eclipse.osgi.util.NLS;

/**
 * NLS convenience methods for the plugin.
 *
 * @author V.Grishchenko
 */
public class Messages extends NLS {
    private static final String BUNDLE_NAME = "com.serena.eclipse.dimensions.internal.change.ui.messages"; //$NON-NLS-1$

    static {
        NLS.initializeMessages(BUNDLE_NAME, Messages.class);
    }

    // generic:
    public static String msg_noDetailsAvailable;

    // document list page titles
    public static String docList_page_myPending;
    public static String docList_page_otherPending;
    public static String docList_page_custom;
    public static String docList_page_drafts;

    // document editor strings
    public static String docEditor_initializing;
    public static String docEditor_tooltip;
    public static String detailsPage_title;
    public static String detailsPage_text;
    public static String attPage_title;
    public static String attPage_text;
    public static String historyPage_title;
    public static String historyPage_text;
    public static String attachPage_title;
    public static String delegatesPage_title;
    public static String delegatesPage_text;
    public static String usersAndRoles_title;
    public static String usersAndRoles_text;
    public static String privilegesPage_title;
    public static String privilegesPage_text;
    public static String templatePage_title;
    // templatePage.text=Template View
    public static String browserPage_title;
    public static String descPage_title;
    public static String descPage_text;

    // error
    public static String err_error;
    public static String err_genericMsg;
    public static String err_addEditorPage;
    public static String err_relatePartDesc;
    public static String err_relatePartMsg;
    public static String err_relateProjectDesc;
    public static String err_relateProjectMsg;

    // document details panel
    public static String docDetailsPnl_id;
    public static String docDetailsPnl_title;
    public static String docDetailsPnl_state;
    public static String docDetailsPnl_phase;
    public static String docDetailsPnl_originator;
    public static String docDetailsPnl_project;
    public static String docDetailsPnl_desc;
    public static String docDetailsPnl_stage;

    // Delete custom list/job dialogs
    public static String delCustomList_title;
    public static String delCustomList_single_question;
    public static String delCustomList_multiple_question;
    public static String delJob_single_question;
    public static String delJob_multiple_question;
    public static String delCustomListJob_question;
    public static String delCustomList_task;
    public static String delCustomList_msMsg;
    public static String delCustomList_errTitle;
    public static String delCustomList_errMsg;

    // New custom list dialog
    public static String newCustomList_title;
    public static String newCustomList_label;

    // new custom list action
    public static String newCustomList_errCreateTitle;
    public static String newCustomList_errCreateMessage;
    public static String newCustomList_validateMsg;

    // Add to custom list dialog
    public static String addToCustomList_title;
    public static String addToCustomList_label;

    // Remove from custom list dialog
    public static String remFromCustomList_title;
    public static String remFromCustomList_question;

    // New Job dialog
    public static String newJob_title;
    public static String newJob_label;

    // Remove from Job dialog
    public static String remFromJob_title;
    public static String remFromJob_question;

    // Attachment model
    public static String attachments_fetch;
    public static String attachments_save;

    // ActionDescription model
    public static String actionDesc_save;
    public static String actionDesc_exceptionText;
    public static String actionDesc_load;

    // Change doc preview model
    public static String chDocPreview_fetch;

    // New Change Document wizard
    public static String new_chdoc_createError;
    public static String new_chdoc_createMsg;

    public static String new_basic_pageName;
    public static String new_basic_chdoc_windowTitle;
    public static String new_basic_chdoc_title;
    public static String new_basic_chdoc_description;
    public static String new_basic_chdoc_product;
    public static String new_basic_chdoc_type;
    public static String new_basic_chdoc_titleLabel;
    public static String new_basic_description;
    public static String new_basic_fromFile;
    public static String new_basic_text;
    public static String new_basic_title_error;
    public static String new_basic_description_error;

    public static String new_baseIssueOn_pageName;
    public static String new_baseIssueOn_windowTitle;
    public static String new_baseIssueOn_title;
    public static String new_baseIssueOn_description;
    public static String new_baseIssueOn_baseOn;
    public static String new_baseIssueOn_relate;
    public static String new_baseIssueOn_error;
    public static String new_baseIssueOn_dependent;
    public static String new_baseIssueOn_information;

    public static String new_attr_pageName;
    public static String new_attr_title;
    public static String new_attr_windowTitle;
    public static String new_attr_description;

    public static String new_relate_pageName;
    public static String new_relate_title;
    public static String new_relate_windowTitle;
    public static String new_relate_description;
    public static String new_relate_part;
    public static String new_relate_project;

    public static String new_attach_pageName;
    public static String new_attach_title;
    public static String new_attach_windowTitle;
    public static String new_attach_description;

    public static String new_summary_pageName;
    public static String new_summary_title;
    public static String new_summary_windowTitle;
    public static String new_summary_description1;
    public static String new_summary_description2;

    public static String new_summary_text1;
    public static String new_summary_text2;
    public static String new_summary_text3;
    public static String new_summary_text4;
    public static String new_summary_noIssue;
    public static String new_summary_basedOnIssue;
    public static String new_summary_attrs;
    public static String new_summary_noAttrs;
    public static String new_summary_relate;
    public static String new_summary_relParts;
    public static String new_summary_noRelParts;
    public static String new_summary_relProjects;
    public static String new_summary_noRelProjects;
    public static String new_summary_noAttachment;
    public static String new_summary_attachment;
    public static String new_summary_draft;

    // preference page
    public static String preferences_change_title;
    public static String preferences_change_showIn;
    public static String preferences_change_showInEditor;
    public static String preferences_change_showInView;

    // Action description editor page
    public static String actionDesc_origLabel;
    public static String actionDesc_newLabel;
    public static String actionDesc_section;
    public static String actionDesc_rtfMessage;

    // add requests to custom
    public static String customList_adding;

    // request history page
    public static String DocumentHistoryPanel_0;
    public static String DocumentHistoryPanel_1;
    public static String DocumentHistoryPanel_10;
    public static String DocumentHistoryPanel_11;
    public static String DocumentHistoryPanel_12;
    public static String DocumentHistoryPanel_13;
    public static String DocumentHistoryPanel_14;
    public static String DocumentHistoryPanel_15;
    public static String DocumentHistoryPanel_16;
    public static String DocumentHistoryPanel_17;
    public static String DocumentHistoryPanel_18;
    public static String DocumentHistoryPanel_2;
    public static String DocumentHistoryPanel_3;
    public static String DocumentHistoryPanel_4;
    public static String DocumentHistoryPanel_5;
    public static String DocumentHistoryPanel_6;
    public static String DocumentHistoryPanel_7;
    public static String DocumentHistoryPanel_8;
    public static String DocumentHistoryPanel_9;

    public static String ChangeDocumentHistoryModel_task;
    public static String ChangeDocumentHistoryModel_structSubTask;

    // Action request list page
    public static String activateRequests_label;
    public static String activateRequests_tooltip;
    public static String deactivateRequests_label;
    public static String deactivateRequests_tooltip;

    // Request tree
    public static String treeNode_activatedRequests;
    public static String treeNode_requestLists;
    public static String treeNode_foundRequestLists;
    public static String treeNode_foundRequests;

    // Tree context menu actions
    public static String action_FindRequestList_label;
    public static String action_FindRequestList_tooltip;

}
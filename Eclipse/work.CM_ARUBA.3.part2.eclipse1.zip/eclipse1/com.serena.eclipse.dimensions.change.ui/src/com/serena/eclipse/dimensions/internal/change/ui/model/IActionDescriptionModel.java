/*
 * @IAttachmentsModel.java, created on May 19, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import com.serena.eclipse.dimensions.internal.ui.model.IBaseDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IEditable;
import com.serena.eclipse.dimensions.internal.ui.model.IPropertyModel;

/**
 * @author V.Grishchenko
 */
public interface IActionDescriptionModel extends IBaseDimensionsArObjectModel, IEditable, IPropertyModel {

    /**
     * Returns the current action description of the change document
     * @return String action description
     */
    public String getCompleteActionDescription();

    /**
     * Adds an action description to the change document
     * addActionDescription updates the model only, updated to
     * the db is done on the doSave.
     */
    void addActionDescription(String newDescription);

    /**
     * Returns the mime type of the browse template = mime type
     * of the action description
     */
    String getMimeType();

    boolean isTextPlain();

    boolean isTextHtml();

    boolean isRTF();

}

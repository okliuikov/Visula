/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.ContentViewer;
import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.jface.viewers.IColorProvider;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import com.serena.dmclient.api.UIProfile;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentList;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.DimensionsListEvent;
import com.serena.eclipse.dimensions.core.DimensionsObjectList;
import com.serena.eclipse.dimensions.core.ECustomChangeDocumentList;
import com.serena.eclipse.dimensions.core.IDimensionsObjectListListener;
import com.serena.eclipse.dimensions.core.MyWorkingChangeDocumentList;
import com.serena.eclipse.dimensions.core.OtherChDocPendingtList;
import com.serena.eclipse.dimensions.core.RequestListAdapter;
import com.serena.eclipse.dimensions.core.RequestListList;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.actions.FindRequestListAction;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListConfiguration;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListHandler;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectListPage;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectListContainer;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectListHandler;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.controls.DimensionsObjectListPanel;
import com.serena.eclipse.internal.ui.IUiConstants;
import com.serena.eclipse.internal.ui.UiPlugin;

/**
 * @author V.Grishchenko
 */
public class RequestListPage extends DimensionsObjectListPage implements /* IMenuListener, */IDimensionsObjectListListener {

    private Composite parent;
    private TreeViewer treeViewer;
    private Map panels = new HashMap(); // list ->panel
    private SashForm sashForm;
    private StackLayout stackLayout;

    private DimensionsConnectionDetailsEx con;
    private RequestListList requestListList;
    private ChangeDocumentList treeSelection;
    private Composite tableParent;
    private boolean processEvents = true;

    private Action activateAction = new ActivateAction();
    private Action deactivateAction = new DeactivateAction();

    private MyWorkingChangeDocumentList currActiveReqList; // added for convenience, reference to list is not changed, so we could
                                                           // save it
    private FoundListsProxy foundRequestListList;
    private RequestListsProxy requestListsProxy = new RequestListsProxy();

    private class TreeContentProvider implements ITreeContentProvider, IDimensionsObjectListListener {

        @Override
        public Object[] getChildren(Object parentElement) {
            if (parentElement instanceof FoundListsProxy) {
                List reqLists = ((FoundListsProxy) parentElement).getRequestLists();
                return reqLists.toArray(new ChangeDocumentList[reqLists.size()]);
            } else if (parentElement instanceof RequestListsProxy) {
                final Object[][] children = new Object[][] { Utils.ZERO_LENGTH_OBJECT_ARRAY };
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                processEvents = false;
                                RequestListList rll = RequestListList.getList(con);
                                rll.fetch(monitor);
                                Object[] lists = rll.getObjects();
                                children[0] = new ECustomChangeDocumentList[lists.length];
                                for (int i = 0; i < lists.length; i++) {
                                    RequestListAdapter rla = (RequestListAdapter) lists[i];
                                    children[0][i] = rla.getERequestList();
                                }
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            } finally {
                                processEvents = true;
                            }
                        }
                    });
                } catch (InvocationTargetException e) {
                    DMChangeUiPlugin.getDefault().handle(e);
                } catch (InterruptedException ignore) {
                }
                return children[0];
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public Object getParent(Object element) {
            if (element instanceof ChangeDocumentList) {
                if (((ChangeDocumentList) element).getType() == ChangeDocumentList.CUSTOM) {
                    return ChangeDocumentList.getMyPendingList(con);
                }
            }
            return null;
        }

        @Override
        public boolean hasChildren(Object element) {
            if (element instanceof RequestListsProxy) {
                return true;
            } else if (element instanceof FoundListsProxy) {
                return ((FoundListsProxy) element).getRequestLists().size() > 0;
            }
            return false;
        }

        @Override
        public Object[] getElements(Object inputElement) {
            if (inputElement instanceof DimensionsConnectionDetailsEx) {
                DimensionsConnectionDetailsEx _con = (DimensionsConnectionDetailsEx) inputElement;
                return new Object[] { new ActiveListProxy(), ChangeDocumentList.getDraftList(con),
                        ChangeDocumentList.getMyPendingList(_con), requestListsProxy, foundRequestListList };
            }
            return Utils.ZERO_LENGTH_OBJECT_ARRAY;
        }

        @Override
        public void dispose() {
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
            if (oldInput != null && newInput != null && oldInput.equals(newInput)) {
                return;
            }

            if (currActiveReqList != null) {
                currActiveReqList.removeListener(this);
            }

            if (newInput instanceof DimensionsConnectionDetailsEx) {
                if (foundRequestListList != null) {
                    foundRequestListList.flush();
                } else {
                    foundRequestListList = new FoundListsProxy(((DimensionsConnectionDetailsEx) newInput).getConnectionDetails());
                    foundRequestListList.addChangeListener(new ChangeListener() {
                        @Override
                        public void stateChanged(final ChangeEvent e) {
                            treeViewer.getTree().getDisplay().asyncExec(new Runnable() {
                                @Override
                                public void run() {
                                    refresh(); // TODO too expensive operation, should be optimized
                                    treeViewer.expandToLevel(e.getSource(), AbstractTreeViewer.ALL_LEVELS);
                                    treeViewer.setSelection(new StructuredSelection(
                                            ((FoundListsProxy) e.getSource()).lastAddedElement()));
                                }
                            });
                        }
                    });
                }
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                currActiveReqList = new ActiveListProxy().getActiveRequests(monitor);
                                DimensionsObjectListHandler handler = (DimensionsObjectListHandler) DMUIPlugin.getDefault()
                                        .getObjectListHandler(currActiveReqList.getTypeScope());
                                if (handler != null) {
                                    try {
                                        handler.prefetchList(currActiveReqList, monitor);
                                    } catch (PartInitException e) {
                                        DMChangeUiPlugin.getDefault().handle(e);
                                    }
                                }
                                currActiveReqList.addListener(TreeContentProvider.this);
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });
                } catch (InvocationTargetException e) {
                    DMChangeUiPlugin.getDefault().handle(e);
                } catch (InterruptedException ignore) {
                }
            }

        }

        @Override
        public void listChanged(final DimensionsListEvent e) {
            treeViewer.getTree().getDisplay().asyncExec(new Runnable() {
                @Override
                public void run() {
                    refresh(); // TODO too expensive operation, should be optimized
                    DimensionsObjectListPanel panel = getPanelForList(treeSelection);
                    panel.getViewer().update(treeSelection.getObjects(), null);
                }
            });
        }

    }

    private class TreeLabelProvider extends LabelProvider {
        private WorkbenchLabelProvider workbenchProvider = new WorkbenchLabelProvider();
        private Image activeIssuesImg;
        private Image foundRequestListsImg;
        private Image foundRequestListImg;
        private Image requestListsImg;

        @Override
        public String getText(Object element) {
            if (element instanceof ActiveListProxy) {
                final ActiveListProxy alp = (ActiveListProxy) element;
                final MyWorkingChangeDocumentList[] holder = new MyWorkingChangeDocumentList[1];
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            try {
                                holder[0] = alp.getActiveRequests(monitor);
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            }
                        }
                    });
                } catch (InvocationTargetException e) {
                    DMChangeUiPlugin.getDefault().handle(e);
                } catch (InterruptedException ignore) {
                }
                int count = (holder[0] != null) ? holder[0].getObjects().length : 0;
                return NLS.bind(Messages.treeNode_activatedRequests, String.valueOf(count));
            } else if (element instanceof RequestListsProxy) {
                return Messages.treeNode_requestLists;
            } else if (element instanceof FoundListsProxy) {
                return Messages.treeNode_foundRequestLists;
            } else if (element instanceof OtherChDocPendingtList) {
                if (foundRequestListList != null) {
                    int resIndex = foundRequestListList.getRequestLists().indexOf(element);
                    if (resIndex > -1) {
                        return NLS.bind(Messages.treeNode_foundRequests, String.valueOf(resIndex + 1));
                    }
                }
                return NLS.bind(Messages.treeNode_foundRequests, String.valueOf(0));
            }
            return workbenchProvider.getText(element);
        }

        @Override
        public Image getImage(Object element) {
            if (element instanceof ActiveListProxy) {
                if (activeIssuesImg == null) {
                    ImageDescriptor imageDescriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.ACTIVATED_ISSUES);
                    if (imageDescriptor != null) {
                        activeIssuesImg = imageDescriptor.createImage();
                    }
                }
                return activeIssuesImg;
            } else if (element instanceof FoundListsProxy) {
                if (foundRequestListsImg == null) {
                    ImageDescriptor imageDescriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.REQUEST_LISTS);
                    if (imageDescriptor != null) {
                        foundRequestListsImg = imageDescriptor.createImage();
                    }
                }
                return foundRequestListsImg;
            } else if (element instanceof RequestListsProxy) {
                if (requestListsImg == null) {
                    ImageDescriptor imageDescriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.REQUEST_LISTS);
                    if (imageDescriptor != null) {
                        requestListsImg = imageDescriptor.createImage();
                    }
                }
                return requestListsImg;
            } else if (element instanceof OtherChDocPendingtList) {
                if (foundRequestListImg == null) {
                    ImageDescriptor imageDescriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.REQUEST_LIST);
                    if (imageDescriptor != null) {
                        foundRequestListImg = imageDescriptor.createImage();
                    }
                }
                return foundRequestListImg;
            }
            return workbenchProvider.getImage(element);
        }

        @Override
        public void dispose() {
            if (activeIssuesImg != null) {
                activeIssuesImg.dispose();
            }
            if (foundRequestListsImg != null) {
                foundRequestListsImg.dispose();
            }
            if (foundRequestListImg != null) {
                foundRequestListImg.dispose();
            }
            if (requestListsImg != null) {
                requestListsImg.dispose();
            }
            super.dispose();
        }
    }

    private class ActiveListProxy {
        private MyWorkingChangeDocumentList activeRequests;

        MyWorkingChangeDocumentList getActiveRequests(IProgressMonitor monitor) throws DMException {
            monitor = Utils.monitorFor(monitor);
            try {
                if (activeRequests == null) {
                    activeRequests = ChangeDocumentList.getActiveRequestsList(con, monitor);
                }
            } finally {
                monitor.done();
            }
            return activeRequests;
        }

    }

    public class FoundListsProxy {
        private DimensionsConnectionDetailsEx con;
        private List foundReqLists = new ArrayList();
        private List changeListeners = new ArrayList();

        public FoundListsProxy(DimensionsConnectionDetailsEx con) {
            this.con = con;
        }

        public List getRequestLists() {
            return foundReqLists;
        }

        public boolean addRequestList(ChangeDocumentList requestList) {
            if (requestList != null) {
                foundReqLists.add(requestList);
                fireStateChanged();
                return true;
            }
            return false;
        }

        public ChangeDocumentList lastAddedElement() {
            if (!foundReqLists.isEmpty()) {
                return (ChangeDocumentList) foundReqLists.get(foundReqLists.size() - 1);
            }
            return null;
        }

        public void flush() {
            foundReqLists.clear();
            fireStateChanged();
        }

        public void addChangeListener(ChangeListener listener) {
            if (!changeListeners.contains(listener)) {
                changeListeners.add(listener);
            }
        }

        public void removeChangeListener(ChangeListener listener) {
            changeListeners.remove(listener);
        }

        public void fireStateChanged() {
            for (Iterator iter = changeListeners.iterator(); iter.hasNext();) {
                ChangeListener listener = (ChangeListener) iter.next();
                listener.stateChanged(new ChangeEvent(this));
            }
        }

        public DimensionsConnectionDetailsEx getConnectionDetails() {
            return con;
        }

    }

    // Pseudo-list, extends OtherChDocPendingtList to be opened in the view as empty list and get context menu contributions
    private class RequestListsProxy extends OtherChDocPendingtList {
        // this object is pseudo-list, should be empty
        @Override
        public synchronized void fetch(IProgressMonitor pm) throws DMException {
        }

        public RequestListsProxy() {
            super(null, RequestListsProxy.class.getName());
        }

        @Override
        public DimensionsConnectionDetailsEx getConnectionDetails() {
            return con;
        }
    }

    private class ActivateAction extends Action {
        public ActivateAction() {
            super(Messages.activateRequests_label);
            setToolTipText(Messages.activateRequests_tooltip);
        }

        @Override
        public void run() {
            if (treeSelection == null || treeSelection.getType() == ChangeDocumentList.ACTIVE_ISSUES) {
                return;
            }

            DimensionsObjectListPanel panel = getPanelForList(treeSelection);
            IStructuredSelection ss = (IStructuredSelection) panel.getSelection();
            if (!ss.isEmpty()) {
                List selectedRequests = ss.toList();
                try {
                    MyWorkingChangeDocumentList ai = ChangeDocumentList.getActiveRequestsList(con, null);
                    ai.addChangeDocuments(selectedRequests, null);
                } catch (DMException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

    }

    private class DeactivateAction extends Action {
        public DeactivateAction() {
            super(Messages.deactivateRequests_label);
            setToolTipText(Messages.deactivateRequests_tooltip);
        }

        @Override
        public void run() {
            if (treeSelection == null) {
                return;
            }
            DimensionsObjectListPanel panel = getPanelForList(treeSelection);
            IStructuredSelection ss = (IStructuredSelection) panel.getSelection();
            if (!ss.isEmpty()) {
                List selectedRequests = ss.toList();
                try {
                    MyWorkingChangeDocumentList ai = ChangeDocumentList.getActiveRequestsList(con, null);
                    ai.removeChangeDocuments(selectedRequests);
                } catch (DMException e) {
                    DMChangeUiPlugin.getDefault().getLog().log(e.getStatus());
                }
            }

        }
    }

    public RequestListPage(IDimensionsObjectListContainer part, Composite parent) {
        super(part);
        this.parent = parent;
    }

    @Override
    public void dispose() {
        if (requestListList != null) {
            requestListList.removeListener(this);
        }
        super.dispose();
    }

    @Override
    protected void doShowObjects(DimensionsObjectList list, DimensionsObjectListConfiguration config, String name) {
        con = config.getConnectionDetails();
        if (requestListList != null) {
            requestListList.removeListener(this);
        }
        requestListList = RequestListList.getList(con);
        requestListList.addListener(this);
        if (sashForm == null) {
            sashForm = new SashForm(parent, SWT.HORIZONTAL);
            if (parent.getLayout() instanceof GridLayout) {
                UIUtils.setGridData(sashForm, GridData.FILL_BOTH);
            }
            treeViewer = createTree(sashForm);

            treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {
                @Override
                public void selectionChanged(SelectionChangedEvent event) {
                    treeNodeSelected(((IStructuredSelection) treeViewer.getSelection()).getFirstElement());
                }
            });

            hookTreeMenuListener();

            tableParent = new Composite(sashForm, SWT.BORDER);
            stackLayout = new StackLayout();
            tableParent.setLayout(stackLayout);

            sashForm.setWeights(new int[] { 20, 80 });

            parent.layout();
        }

        DimensionsObjectListPanel panel = getPanelForList(list);
        if (panel == null) {
            panel = createTable(tableParent, config);
            panel.addSelectionChangedListener(new ISelectionChangedListener() {
                @Override
                public void selectionChanged(SelectionChangedEvent event) {
                    ISelection selection = event.getSelection();
                    if (selection instanceof IStructuredSelection) {
                        IStructuredSelection ss = (IStructuredSelection) selection;
                        if (!ss.isEmpty()) {
                            List selectedRequests = ss.toList();
                            if (selectedRequests != null) {
                                activateAction.setEnabled(false);
                                deactivateAction.setEnabled(false);
                                for (Iterator iter = selectedRequests.iterator(); iter.hasNext();) {
                                    Object element = iter.next();
                                    if (element instanceof ChangeDocumentAdapter) {
                                        ChangeDocumentAdapter request = (ChangeDocumentAdapter) element;
                                        if (request.isActive()) {
                                            deactivateAction.setEnabled(true);
                                        } else {
                                            activateAction.setEnabled(true);
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            });
            hookTableMenuListener(panel);
            panel.setModel(list);
            panels.put(list, panel);
        }

        stackLayout.topControl = panel;
        tableParent.layout();

        treeSelection = (ChangeDocumentList) list;
        if (treeSelection.getType() != ChangeDocumentList.ACTIVE_ISSUES) {
            treeViewer.setSelection(new StructuredSelection(list));
        }
    }

    private TreeViewer createTree(Composite parent1) {
        Tree tree = new Tree(parent1, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.BORDER);
        TreeViewer treeViewer = new TreeViewer(tree);
        treeViewer.setContentProvider(new TreeContentProvider());
        treeViewer.setLabelProvider(new TreeLabelProvider());
        treeViewer.setSorter(new ViewerSorter() {
            @Override
            public int category(Object element) {
                if (element instanceof ActiveListProxy) {
                    return 0;
                } else if (element instanceof RequestListsProxy) {
                    return 3;
                } else if (element instanceof ChangeDocumentList) {
                    if (((ChangeDocumentList) element).getType() == ChangeDocumentList.DRAFT) {
                        return 1;
                    } else if (((ChangeDocumentList) element).getType() == ChangeDocumentList.MY_PENDING) {
                        return 2;
                    }
                }
                return 4;
            }

            @Override
            public int compare(Viewer viewer, Object e1, Object e2) {
                if (e1 instanceof OtherChDocPendingtList && e2 instanceof OtherChDocPendingtList) {
                    IBaseLabelProvider provider = ((ContentViewer) viewer).getLabelProvider();
                    if (provider instanceof ILabelProvider) {
                        ILabelProvider lProvider = (ILabelProvider) provider;
                        String name1 = lProvider.getText(e1);
                        String name2 = lProvider.getText(e2);
                        // Sort objects of this type by order number in label. Imply it's separated from text with space ' '
                        int number1 = 0;
                        int number2 = 0;
                        try {
                            int index = -1;
                            if ((index = name1.lastIndexOf(' ')) > -1) {
                                number1 = Integer.parseInt(name1.substring(index + 1));
                            }
                            if ((index = name2.lastIndexOf(' ')) > -1) {
                                number2 = Integer.parseInt(name2.substring(index + 1));
                            }
                        } catch (IndexOutOfBoundsException e) {
                            // Swallow it
                        } catch (NumberFormatException ex) {
                            // Swallow it
                        }
                        return number1 - number2;
                    }
                }
                return super.compare(viewer, e1, e2);
            }
        });
        treeViewer.setInput(con);
        return treeViewer;
    }

    private void hookTreeMenuListener() {
        MenuManager menuMgr = new MenuManager();
        Menu menu = menuMgr.createContextMenu(treeViewer.getTree());
        menuMgr.addMenuListener(new IMenuListener() {
            @Override
            public void menuAboutToShow(IMenuManager manager) {
                RequestListPage.this.treeMenuAboutToShow(manager);
            }
        });
        menuMgr.setRemoveAllWhenShown(true);
        treeViewer.getTree().setMenu(menu);
        getPart().getSite().registerContextMenu(menuMgr, treeViewer);
    }

    public void treeMenuAboutToShow(IMenuManager manager) {
        IStructuredSelection selection = (IStructuredSelection) treeViewer.getSelection();
        if (selection.getFirstElement() instanceof FoundListsProxy) {
            final FindRequestListAction dimFindReqListAction = new FindRequestListAction();
            dimFindReqListAction.setSelection(selection);
            IAction findReqListAction = new Action() {
                @Override
                public void run() {
                    dimFindReqListAction.run(this);
                }
            };
            findReqListAction.setText(Messages.action_FindRequestList_label);
            findReqListAction.setToolTipText(Messages.action_FindRequestList_tooltip);
            findReqListAction.setImageDescriptor(DMUIPlugin.getDefault().getImageDescriptor(IDMImages.CHANGEDOC));
            manager.add(findReqListAction);
        }
        UiPlugin.addStandardGroupMarkers(manager);
    }

    private DimensionsObjectListPanel createTable(Composite parent1, DimensionsObjectListConfiguration config) {
        DimensionsObjectListPanel panel = new DimensionsObjectListPanel(parent1, SWT.NONE, config, this) {
            @Override
            protected TableViewer createTable(Composite parent) {
                TableViewer viewer = super.createTable(parent);
                viewer.setLabelProvider(new ObjectColorLabelProvider(viewer));
                return viewer;
            }

            class ObjectColorLabelProvider extends LabelProvider implements ITableLabelProvider, IColorProvider {
                private TableViewer viewer;

                public ObjectColorLabelProvider(TableViewer viewer) {
                    this.viewer = viewer;
                }

                @Override
                public Image getColumnImage(Object element, int columnIndex) {
                    return null;
                }

                @Override
                public String getColumnText(Object element, int columnIndex) {
                    if (element instanceof APIObjectAdapter) {
                        return getAttributeAsString((APIObjectAdapter) element, columnIndex);
                    }
                    return Utils.EMPTY_STRING;
                }

                @Override
                public Color getBackground(Object element) {
                    return null;
                }

                @Override
                public Color getForeground(Object element) {
                    if (element instanceof ChangeDocumentAdapter) {
                        ChangeDocumentAdapter request = (ChangeDocumentAdapter) element;
                        if (request.isActive()) {
                            Display display = viewer.getControl().getShell().getDisplay();
                            return display.getSystemColor(SWT.COLOR_BLUE);
                        }
                    }
                    return null;
                }
            }

        };
        return panel;
    }

    private void hookTableMenuListener(DimensionsObjectListPanel _panel) {
        MenuManager menuMgr = _panel.getMenuMgr();
        menuMgr.addMenuListener(new IMenuListener() {
            @Override
            public void menuAboutToShow(IMenuManager manager) {
                tableMenuAboutToShow(manager);
            }
        });
        getPart().getSite().registerContextMenu(menuMgr, _panel);
    }

    private void tableMenuAboutToShow(IMenuManager manager) {
        if (treeSelection == null) {
            return;
        }
        String provider = con.getRequestProviderType();
        if (!DimensionsConnectionDetailsEx.TYPE_REQUEST_PROVIDER_NONE.equals(provider) && checkUIPSettings(con)) {
            if (treeSelection.getType() == ChangeDocumentList.ACTIVE_ISSUES) {
                manager.appendToGroup(IUiConstants.MENU_GROUP0, deactivateAction);
            } else {
                manager.appendToGroup(IUiConstants.MENU_GROUP0, activateAction);
                manager.appendToGroup(IUiConstants.MENU_GROUP0, deactivateAction);
            }
        }
    }

    private boolean checkUIPSettings(DimensionsConnectionDetailsEx con) {
        String provider = con.getRequestProviderType();
        if (DimensionsConnectionDetailsEx.TYPE_REQUEST_PROVIDER_IDM.equals(provider)) {
            try {
                UIProfile activeProfile = con.getCurrentUiProfile();
                if (activeProfile != null && !activeProfile.isViewVisible(UIProfile.VIEW_REQUEST_INBOX)) {
                    return false;
                }
            } catch (DMException e) {// IGNORE THIS
            }
        } else if (provider == null || DimensionsConnectionDetailsEx.TYPE_REQUEST_PROVIDER_DM.equals(provider)) {
            try {
                UIProfile activeProfile = con.getCurrentUiProfile();
                if (activeProfile != null
                        && (!activeProfile.isViewVisible(UIProfile.VIEW_REQUEST_INBOX) || !activeProfile.isViewVisible(UIProfile.VIEW_REQUEST_LIST))) {
                    return false;
                }
            } catch (DMException e) {// IGNORE THIS
            }
        }
        return true;
    }

    private DimensionsObjectListPanel getPanelForList(DimensionsObjectList list) {
        return (DimensionsObjectListPanel) panels.get(list);
    }

    @Override
    public List getAllLists() {
        return Collections.EMPTY_LIST;
    }

    @Override
    public DimensionsObjectList getSelectedList() {
        return treeSelection;
    }

    @Override
    public boolean isMultiPage() {
        return true;
    }

    protected void treeNodeSelected(Object node) {
        if (treeSelection != null && treeSelection.equals(node)) {
            return; // nothing to do
        }

        ChangeDocumentList requestList = null;
        if (node instanceof ChangeDocumentList) {
            requestList = (ChangeDocumentList) node;
        } else if (node instanceof ActiveListProxy) {
            final ActiveListProxy alp = (ActiveListProxy) node;
            final ChangeDocumentList[] holder = new ChangeDocumentList[1];
            try {
                PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {
                    @Override
                    public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                        try {
                            holder[0] = alp.getActiveRequests(monitor);
                        } catch (DMException e) {
                            throw new InvocationTargetException(e);
                        }
                    }
                });
            } catch (InvocationTargetException e) {
                DMChangeUiPlugin.getDefault().handle(e);
            } catch (InterruptedException ignore) {
            }
            requestList = holder[0];
        } else if (node instanceof FoundListsProxy) {
        }

        if (requestList != null) {
            treeSelection = requestList;
            IDimensionsObjectListHandler handler = DMUIPlugin.getDefault().getObjectListHandler(requestList.getTypeScope());
            if (handler != null) {
                try {
                    handler.openList(requestList);
                    DimensionsObjectListPanel panel = getPanelForList(treeSelection);
                    if (panel != null) {
                        panel.getViewer().update(treeSelection.getObjects(), null);
                    }
                } catch (PartInitException e) {
                    DMChangeUiPlugin.getDefault().handle(e);
                }
            }
            getPart().setDescription(getSelectedConfig().getTypeFilterDescription());
        }
    }

    @Override
    public void refresh() {
        if (treeViewer != null) {
            DimensionsObjectList selectedList = getSelectedList();
            if (selectedList != null) {
                APIObjectAdapter[] apiObjects = getSelectedList().getObjects();
                if (apiObjects != null) {
                    for (APIObjectAdapter apiObject : apiObjects) {
                        if (apiObject instanceof ChangeDocumentAdapter) {
                            ChangeDocumentAdapter cd = (ChangeDocumentAdapter) apiObject;
                            cd.setHasReviews(true); 
                        }
                    }
                }
            }
            treeViewer.refresh();
        }
        super.refresh();
    }

    @Override
    public void listChanged(final DimensionsListEvent e) {
        if (!processEvents || treeViewer == null || con == null) {
            return;
        }

        final ECustomChangeDocumentList[] changes = new ECustomChangeDocumentList[e.changes.length];
        for (int i = 0; i < changes.length; i++) {
            changes[i] = ((RequestListAdapter) e.changes[i]).getERequestList();
        }

        Display.getDefault().asyncExec(new Runnable() {
            @Override
            public void run() {
                switch (e.type) {
                case DimensionsListEvent.OBJECTS_ADDED:
                    treeViewer.add(requestListsProxy, changes);
                    break;
                case DimensionsListEvent.OBJECTS_REMOVED:
                    treeViewer.remove(changes);
                    break;
                case DimensionsListEvent.OBJECTS_CHANGED:
                    treeViewer.update(changes, null);
                    break;
                }
            }
        });

    }

}

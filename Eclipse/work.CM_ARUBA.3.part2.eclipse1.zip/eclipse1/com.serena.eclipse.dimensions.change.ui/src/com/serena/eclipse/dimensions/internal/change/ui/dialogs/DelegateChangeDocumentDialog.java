/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.ManagedForm;

import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.dialogs.ResizableDialog;
import com.serena.eclipse.dimensions.internal.ui.forms.DelegatePanel;
import com.serena.eclipse.dimensions.internal.ui.model.IUsersAndRolesModel;
import com.serena.eclipse.dimensions.internal.ui.model.UsersAndRolesModel;

/**
 * @author abollmann
 *
 *         Attributes page in the new object wizard
 */
public class DelegateChangeDocumentDialog extends ResizableDialog {
    private IUsersAndRolesModel[] delModels;
    private APIObjectAdapter[] objects;

    public DelegateChangeDocumentDialog(Shell parentShell, APIObjectAdapter[] objects) {
        super(parentShell);
        this.objects = objects;

    }

    @Override
    protected Control createDialogArea(Composite parent) {
        // Composite composite = new Composite(parent, SWT.NONE);

        // Set the title
        getShell().setText(Messages.attachment_new_title);

        GridLayout layout = new GridLayout();
        layout.numColumns = 1;
        parent.setLayout(layout);
        IManagedForm managedForm = new ManagedForm(parent);
        prepareModel();
        DelegatePanel panel = new DelegatePanel(managedForm, delModels, parent, SWT.NONE);
        UIUtils.setGridData(panel.getPanel(), GridData.FILL_BOTH);
        return parent;
    }

    // creates and loads the model for the next status
    private boolean prepareModel() {
        delModels = new IUsersAndRolesModel[objects.length];
        for (int i = 0; i < objects.length; i++) {
            delModels[i] = new UsersAndRolesModel(objects[i]);
        }
        try {
            final Session session = objects[0].getConnectionDetails().openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {

                    for (int i = 0; i < delModels.length; i++) {
                        delModels[i].load(null);
                    }
                }
            });
        } catch (DMException e) {
            DMUIPlugin.getDefault().handle(e);
            return false;
        }
        return true;
    }

}

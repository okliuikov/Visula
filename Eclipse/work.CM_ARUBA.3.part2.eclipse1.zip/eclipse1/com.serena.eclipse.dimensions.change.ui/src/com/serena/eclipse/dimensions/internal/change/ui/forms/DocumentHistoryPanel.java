/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.forms;

import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.forms.FormColors;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.serena.dmfile.StructureHistoryRec;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.model.IChangeDocumentHistoryModel;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.forms.ActionHistoryPanel;

/**
 * Request history page/panel adds structure history.
 *
 * @author V.Grishchenko
 */
public class DocumentHistoryPanel extends ActionHistoryPanel {
    private Table changeHistoryTable;

    public DocumentHistoryPanel(IManagedForm managedForm, IChangeDocumentHistoryModel model, Composite parent) {
        super(managedForm, model, parent);
    }

    @Override
    protected Control createControl(Composite parent, FormToolkit toolkit) {

        CTabFolder tabFolder = new CTabFolder(parent, SWT.FLAT | SWT.TOP);
        toolkit.adapt(tabFolder);
        toolkit.getColors().initializeSectionToolBarColors();
        Color selectedColor1 = toolkit.getColors().getColor(FormColors.TB_BG);
        Color selectedColor2 = toolkit.getColors().getColor(FormColors.TB_GBG);
        tabFolder.setSelectionBackground(new Color[] { selectedColor1, selectedColor2, toolkit.getColors().getBackground() },
                new int[] { 50, 100 }, true);
        UIUtils.setGridData(tabFolder, GridData.FILL_BOTH);

        Composite ahPanel = toolkit.createComposite(tabFolder);
        FillLayout fl1 = UIUtils.setFillLayout(ahPanel);
        fl1.marginHeight = fl1.marginWidth = 1;
        createActionHistoryTable(ahPanel, toolkit);
        toolkit.paintBordersFor(ahPanel);

        CTabItem ahTab = new CTabItem(tabFolder, SWT.NONE);
        ahTab.setText(Messages.DocumentHistoryPanel_0);
        ahTab.setControl(ahPanel);

        Composite shPanel = toolkit.createComposite(tabFolder);
        FillLayout fl2 = UIUtils.setFillLayout(shPanel);
        fl2.marginHeight = fl2.marginWidth = 1;
        createChangeHistoryTable(shPanel, toolkit);
        toolkit.paintBordersFor(shPanel);

        CTabItem chTab = new CTabItem(tabFolder, SWT.NONE);
        chTab.setText(Messages.DocumentHistoryPanel_1);
        chTab.setControl(shPanel);

        tabFolder.setSelection(0);
        return tabFolder;
    }

    private void createChangeHistoryTable(Composite parent, FormToolkit toolkit) {
        changeHistoryTable = toolkit.createTable(parent, SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL | SWT.FULL_SELECTION);
        changeHistoryTable.setHeaderVisible(true);
        changeHistoryTable.setLinesVisible(true);

        TableLayout tableLayout = new TableLayout();
        changeHistoryTable.setLayout(tableLayout);

        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_3, 20, 20, true); // object type
        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_2, 20, 20, true); // change type
        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_7, 20, 20, true); // username
        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_5, 35, 20, true); // old path
        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_6, 35, 20, true); // new path
        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_8, 20, 20, true); // date-time
        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_9, 20, 20, true); // stage
        createColumn(changeHistoryTable, Messages.DocumentHistoryPanel_4, 30, 20, true); // item spec
    }

    private TableColumn createColumn(Table table, String text, int weight, int minimumWidth, boolean resizable) {
        TableColumn column = new TableColumn(table, SWT.NONE);
        column.setText(text);
        ((TableLayout) table.getLayout()).addColumnData(new ColumnWeightData(weight, minimumWidth, resizable));
        return column;
    }

    @Override
    public void refresh() {
        super.refresh();
        fillChangeHistory();
    }

    private void fillChangeHistory() {
        if (changeHistoryTable == null) {
            return;
        }
        if (changeHistoryTable.getItemCount() > 0) {
            changeHistoryTable.removeAll();
        }
        List structureHistory = ((IChangeDocumentHistoryModel) getModel()).getStructureHistory();
        if (structureHistory == null) {
            return;
        }
        for (Iterator iterator = structureHistory.iterator(); iterator.hasNext();) {
            StructureHistoryRec aRec = (StructureHistoryRec) iterator.next();
            TableItem tableItem = new TableItem(changeHistoryTable, SWT.NONE);
            tableItem.setText(0, Utils.getString(getObjectTypeName(aRec)));
            tableItem.setText(1, Utils.getString(getChangeTypeName(aRec)));
            tableItem.setText(2, Utils.getString(aRec.getUser()));
            tableItem.setText(3, Utils.getString(aRec.getOldPath()));
            tableItem.setText(4, Utils.getString(aRec.getNewPath()));
            tableItem.setText(5, Utils.getString(aRec.getUpdateTime()));
            tableItem.setText(6, Utils.getString(aRec.getStageId()));
            tableItem.setText(7, Utils.isNullEmpty(aRec.getObjectSpec()) ? Messages.DocumentHistoryPanel_18 : aRec.getObjectSpec());
        }
    }

    private String getChangeTypeName(StructureHistoryRec rec) {
        switch (rec.getChangeType()) {
        case StructureHistoryRec.CREATE:
            return Messages.DocumentHistoryPanel_10;
        case StructureHistoryRec.DELETION:
            return Messages.DocumentHistoryPanel_11;
        case StructureHistoryRec.MOVE:
            return Messages.DocumentHistoryPanel_12;
        case StructureHistoryRec.RENAME:
            return Messages.DocumentHistoryPanel_15;
        case StructureHistoryRec.MODIFY:
            return Messages.DocumentHistoryPanel_16;
        case StructureHistoryRec.IMPORT:
            return Messages.DocumentHistoryPanel_17;
        default:
            return null;
        }
    }

    private String getObjectTypeName(StructureHistoryRec rec) {
        switch (rec.getObjectType()) {
        case StructureHistoryRec.ITEM:
            return Messages.DocumentHistoryPanel_13;
        case StructureHistoryRec.FOLDER:
            return Messages.DocumentHistoryPanel_14;
        default:
            return null;
        }
    }

}

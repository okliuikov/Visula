/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.forms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.runtime.Status;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.api.IDMRequest;
import com.serena.dmclient.api.IDMRequestIdentifier;
import com.serena.dmclient.api.IDMRequestV2;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMPreferences;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorPage;
import com.serena.eclipse.dimensions.internal.ui.forms.FormEntry;
import com.serena.eclipse.dimensions.internal.ui.forms.FormEntryAdapter;
import com.serena.eclipse.dimensions.internal.ui.forms.ObjectDetailsSection;
import com.serena.eclipse.dimensions.internal.ui.model.DimensionsChangeDocumentModel;
import com.serena.eclipse.dimensions.internal.ui.model.IDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IdmRequestData;

import merant.adm.dimensions.server.core.Constants;

/**
 * @author V.Grishchenko
 */
public class DocumentDetailsSection extends ObjectDetailsSection {
    private FormEntry id;
    private FormEntry title;
    private FormEntry state;
    private FormEntry phase;
    private FormEntry stage;
    private FormEntry originator;
    private FormEntry project;
    private FormEntry description;
    private FormEntry link;

    private boolean updatingModel;

    public DocumentDetailsSection(DimensionsObjectEditorPage page, IDimensionsArObjectModel model, Composite parent, String title,
            int style) {
        super(page, model, parent, style, title);
    }

    @Override
    protected void createClient(Section section, FormToolkit toolkit) {
        final DimensionsChangeDocumentModel model = (DimensionsChangeDocumentModel) getModel();
        final String requestProviderType = model.getConnection().getRequestProviderType(); 
        Composite panel = toolkit.createComposite(section);
        UIUtils.setGridLayout(panel, 2).verticalSpacing = 6;

        id = new FormEntry(panel, toolkit, Messages.docDetailsPnl_id, SWT.SINGLE);
        // id.setValue(model.getObjectId(), true);
        id.getText().setEditable(false);

        title = new FormEntry(panel, toolkit, Messages.docDetailsPnl_title, SWT.SINGLE);
        title.getText().setEditable(model.isTitleEditable());
        title.setFormEntryListener(new FormEntryAdapter(this) {
            @Override
            public void textValueChanged(FormEntry entry) {
                updatingModel = true;
                model.setTitle(title.getValue());
                updatingModel = false;
            }
        });

        state = new FormEntry(panel, toolkit, Messages.docDetailsPnl_state, SWT.SINGLE);
        // state.setValue(model.getStatus(), true);
        state.getText().setEditable(false);
        if (model.getConnection().isSbmRequestProvider()) {
            phase = new FormEntry(panel, toolkit, Messages.docDetailsPnl_phase, SWT.SINGLE);
            // phase.setValue(model.getCMPhase(), true);
            phase.getText().setEditable(false);
    
            stage = new FormEntry(panel, toolkit, Messages.docDetailsPnl_stage, SWT.SINGLE);
            stage.getText().setEditable(false);
        }
        
        originator = new FormEntry(panel, toolkit, Messages.docDetailsPnl_originator, SWT.SINGLE);
        // originator.setValue(model.getOriginator(), true);
        originator.getText().setEditable(false);

        project = new FormEntry(panel, toolkit, Messages.docDetailsPnl_project, SWT.SINGLE);
        project.getText().setEditable(false);

        description = new FormEntry(panel, toolkit, Messages.docDetailsPnl_desc, SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL | SWT.WRAP);
        description.getText().setEditable(model.isDescriptionEditable());
        description.getText().setFont(JFaceResources.getFontRegistry().get(IDMPreferences.REQUEST_DESCR_FONT));

        description.setFormEntryListener(new FormEntryAdapter(this) {
            @Override
            public void textValueChanged(FormEntry entry) {
                updatingModel = true;
                model.setDescription(description.getValue());
                updatingModel = false;
            }
        });

        if (requestProviderType.equals(Constants.REQUEST_PROVIDER_IDM_OCTANE) || requestProviderType.equals(Constants.REQUEST_PROVIDER_IDM_JIRA)) {
            try {
                final Session session = model.getConnection().openSession(null);
                IDMHelper helper = session.getObjectFactory().getIDMHelper();
                RequestProvider provider = session.getObjectFactory().getRequestProvider(null);
                IDMRequestIdentifier identifier = new IDMRequestIdentifier(
                        provider.getUID(), 
                        model.getUnderlyingObject().getAPIObject().getName());
                List<IDMRequestV2> requests = helper.getIDMRequests(Arrays.asList(identifier));
                if (requests != null && requests.size() == 1) {
                    link = new FormEntry(panel, toolkit, "Open request in external browser", requests.get(0).getUrl(), true);
                }
            } catch (Exception e) {
                DMChangeUiPlugin.getDefault().getLog().log(new Status(Status.WARNING, DMChangeUiPlugin.ID, Messages.err_genericMsg, e));
            }
        }

        toolkit.paintBordersFor(panel);
        section.setClient(panel);
    }

    @Override
    protected void modelPropertyChanged(PropertyChangeEvent event) {
        if (!updatingModel
                && (IDimensionsArObjectModel.TITLE.equals(event.getProperty()) || IDimensionsArObjectModel.DESCRIPTION.equals(event.getProperty()))) {
            markStale();
        }
        super.modelPropertyChanged(event);
    }

    // form part methods ---------------

    @Override
    public void commit(boolean onSave) {
        title.commit();
        description.commit();
        super.commit(onSave);
    }

    @Override
    public void refresh() {
        DimensionsChangeDocumentModel model = (DimensionsChangeDocumentModel) getModel();
        id.setValue(model.getObjectId(), true);
        title.setValue(model.getTitle(), true);
        title.getText().setEditable(model.isTitleEditable());
        state.setValue(model.getStatus(), true);
        if (model.getConnection().isSbmRequestProvider()) {
            phase.setValue(model.getCMPhase(), true);
            stage.setValue(model.getStage(), true);
        }
        originator.setValue(model.getOriginator(), true);
        project.setValue(model.getRelatedProject(), true);
        description.setValue(model.getDescription(), true);
        description.getText().setEditable(model.isDescriptionEditable());
        super.refresh();
    }

    @Override
    public void cancelEdit() {
        title.cancelEdit();
        description.cancelEdit();
        super.cancelEdit();
    }

}

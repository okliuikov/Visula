/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.dialogs;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Composite;

import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.forms.AttachmentPanel;
import com.serena.eclipse.dimensions.internal.change.ui.model.AttachmentDetails;
import com.serena.eclipse.dimensions.internal.change.ui.model.AttachmentsModel;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.forms.FormWizardPage;

/**
 * @author abollmann
 *
 *         Attributes page in the new object wizard
 */
public class NewChangeDocumentAttachmentPage extends FormWizardPage {
    private AttachmentPanel panel;
    private DimensionsConnectionDetailsEx conn;
    private AttachmentsModel model;

    public NewChangeDocumentAttachmentPage(String pageName, String title, ImageDescriptor titleImage,
            DimensionsConnectionDetailsEx conn) {
        super(pageName, title, titleImage);
        setDescription(Messages.new_attach_description);
        this.conn = conn;
    }

    @Override
    protected void createFormContents(Composite form) {
        UIUtils.setGridLayout(form, 1);
        ChangeDocumentAdapter chdocAdapter = new ChangeDocumentAdapter(null, conn);
        model = new AttachmentsModel(chdocAdapter);
        panel = new AttachmentPanel(getManagedForm(), model, form);
        getManagedForm().addPart(panel);
    }

    public AttachmentDetails[] getAttachments() {
        if (model == null) {
            return new AttachmentDetails[0];
        }
        return model.getAttachments();
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.change.ui;

import com.serena.eclipse.dimensions.change.ui.editors.DocumentEditor;
import com.serena.eclipse.dimensions.change.ui.editors.DocumentEditorInput;
import com.serena.eclipse.dimensions.change.ui.editors.IDMRequestEditor;
import com.serena.eclipse.dimensions.change.ui.editors.IDMRequestEditorInput;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.IDMRequestAdapter;
import com.serena.eclipse.dimensions.internal.change.ui.editors.DocumentDetailsPage;
import com.serena.eclipse.dimensions.internal.ui.DimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.editors.BrowserPage;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorInput;

/**
 * Opens change docuemnt editor.
 *
 * @author V.Grishchenko
 */
public class DocumentEditHandler extends DimensionsObjectEditHandler {

    public DocumentEditHandler() {
        super(DMChangeUiPlugin.DOC_SCOPES);
    }

    @Override
    protected String getObjectEditorId(APIObjectAdapter dmObj) {
        if (dmObj instanceof IDMRequestAdapter) {
            return IDMRequestEditor.ID;
        }
        return DocumentEditor.ID;
    }

    @Override
    protected DimensionsObjectEditorInput createEditorInput(APIObjectAdapter dmObj, String pageId) {
        if (pageId == null) {
            pageId = DocumentDetailsPage.ID;
        }

        if (dmObj instanceof IDMRequestAdapter) {
            return new IDMRequestEditorInput((IDMRequestAdapter) dmObj, BrowserPage.ID);
        }
        return new DocumentEditorInput((ChangeDocumentAdapter) dmObj, pageId);
    }

}

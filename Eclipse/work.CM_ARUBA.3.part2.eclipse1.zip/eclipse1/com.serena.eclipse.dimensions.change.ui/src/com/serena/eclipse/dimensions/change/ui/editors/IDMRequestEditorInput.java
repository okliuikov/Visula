package com.serena.eclipse.dimensions.change.ui.editors;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.IEditorInput;

import com.serena.dmclient.api.IDMHelper;
import com.serena.dmclient.api.IDMRequest;
import com.serena.dmclient.api.IDMRequestIdentifier;
import com.serena.dmclient.api.IDMRequestV2;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.IDMRequestAdapter;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.sbm.ISBMConnection;
import com.serena.eclipse.dimensions.core.sbm.SBMClientHelper;
import com.serena.eclipse.dimensions.core.sbm.SBMConnectionDetails;
import com.serena.eclipse.dimensions.core.sbm.SBMHelper;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.editors.DimensionsObjectEditorInput;

public class IDMRequestEditorInput extends DimensionsObjectEditorInput implements IEditorInput {
    private String url; // URL to open in a browser. Doesn't contain credentials
    private String title;

    public IDMRequestEditorInput(IDMRequestAdapter request, String initialPage) {
        super(request, initialPage);
    }

    public IDMRequestAdapter getIDMRequestAdapter() {
        return (IDMRequestAdapter) getAPIObjectAdapter();
    }

    protected String[] getRequiredStringAttributes() {
        return new String[] { SBMClientHelper.TS_SYSFLD_TITLE, SBMClientHelper.TS_SYSFLD_URL };
    }

    @Override
    public void initialize(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.docEditor_initializing, 20);
        try {
            IDMRequest request = (IDMRequest) getAPIObjectAdapter().getAPIObject();
            url = request.getItemUrl();
            title = request.getTitle();
            if (Utils.isNullEmpty(url) || Utils.isNullEmpty(title)) {
                if (getAPIObjectAdapter().getConnectionDetails().getSBMConnection() != null ) {
                    final SBMClientHelper helper = new SBMClientHelper(getAPIObjectAdapter().getConnectionDetails().getSBMConnection());
                    final Session session = getAPIObjectAdapter().getConnectionDetails().openSession(Utils.subMonitorFor(monitor, 5)); // 5
                    session.run(new ISessionRunnable() {
                        @Override
                        public void run() throws Exception {
                            Map attrs = helper.readAttribsForIDMRequest((IDMRequest) getAPIObjectAdapter().getAPIObject(),
                                    getRequiredStringAttributes());
                            url = (String) attrs.get(SBMClientHelper.TS_SYSFLD_URL);
                            title = (String) attrs.get(SBMClientHelper.TS_SYSFLD_TITLE);
                        }
                    }, monitor);
                } else {
                    try {
                        final Session session = getAPIObjectAdapter().getConnectionDetails().openSession(null);
                        IDMHelper helper = session.getObjectFactory().getIDMHelper();
                        RequestProvider provider = session.getObjectFactory().getRequestProvider(null);
                        IDMRequestIdentifier identifier = new IDMRequestIdentifier(provider.getUID(), request.getName());
                        List<IDMRequestV2> requests = helper.getIDMRequests(Arrays.asList(identifier));
                        if (requests != null && requests.size() == 1) {
                            url = requests.get(0).getUrl();
                            title = requests.get(0).getTitle();
                        }
                    } catch (Exception e) {
                        DMUIPlugin.getDefault().getLog().log(new Status(Status.WARNING, DMUIPlugin.ID, Messages.err_genericMsg, e));
                    }
                }
            }
        } catch (Exception e) {
            DMUIPlugin.getDefault().handle(e);
        } finally {
            monitor.done(); // 20 elapsed
        }
    }

    /*
     * Get the display URL to show in browser. Contains credentials
     */
    public String getDisplayURL() {
        ISBMConnection sbmConn = getAPIObjectAdapter().getConnectionDetails().getSBMConnection();
        if (sbmConn != null) {
            SBMConnectionDetails details = sbmConn.getDetails();
            return url + '&' + SBMHelper.getCredentials(details.getUser(), details.getPassword(), true);
        }
        return url;
    }

    @Override
    public String getName() {
        String name = getIDMRequestAdapter().getIDMRequest().getName();
        if (name == null) {
            name = Utils.EMPTY_STRING;
        }
        return name;
    }

    @Override
    protected String getFullToolTipText() {
        String[] params = new String[] { DMTypeScope.REQUEST.getDisplayText(), getName(),
                title != null ? title : Utils.EMPTY_STRING };
        return NLS.bind(Messages.docEditor_tooltip, params);
    }

}

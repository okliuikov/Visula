/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui.model;

import java.io.File;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.core.APIObjectAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.model.BaseDimensionsArObjectModel;
import com.serena.eclipse.dimensions.internal.ui.model.IPreviewModel;

/**
 * @author V.Grishchenko
 */
public class ChangeDocumentPreviewModel extends BaseDimensionsArObjectModel implements IPreviewModel {

    // change doc preview temp file prefix
    private static final String TMPFILE_PREFIX = "cdpv"; //$NON-NLS-1$
    private static final String EXT_TXT = "txt"; //$NON-NLS-1$
    private static final String EXT_HTML = "html"; //$NON-NLS-1$
    private static final String EXT_RTF = "rtf"; //$NON-NLS-1$

    private Request changeDocument;
    private String fileName;
    private String mimeType;
    private String charEncoding = Utils.DEFAULT_ENCODING_NAME;

    public ChangeDocumentPreviewModel(APIObjectAdapter object) {
        super(object);
        changeDocument = (Request) object.getAPIObject();
    }

    @Override
    protected long doLoad(IProgressMonitor pm) throws DMException {
        final IProgressMonitor _pm = Utils.monitorFor(pm);
        // 20 - session, 60 - timestamp, 20 - preview
        _pm.beginTask(Messages.chDocPreview_fetch, 100);
        final Session session = getUnderlyingObject().getConnectionDetails().openSession(Utils.subMonitorFor(_pm, 20));
        final long[] timeStamp = new long[1];
        try {
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    checkCanceled(_pm);
                    // There is no atomic operation to fetch the preview and the
                    // timestamp at once. Fetching the timestamp first for the preview
                    // is safer as it is OK to have a potential false "out of sync"
                    // condition, but it is not OK to have a potential false
                    // "in sync" condition
                    timeStamp[0] = fetchTimeStamp();
                    _pm.worked(60);
                    checkCanceled(_pm);

                    charEncoding = session.getUnderlyingConnection().getCharEncoding();
                    mimeType = changeDocument.getBrowseTemplateMimeType();
                    String ext = getExtension();
                    String suffix = ext == null ? null : "." + ext; //$NON-NLS-1$
                    File tmpFile = File.createTempFile(TMPFILE_PREFIX, suffix, null);
                    fileName = tmpFile.getAbsolutePath();
                    changeDocument.getPreview(fileName);
                    tmpFile.setReadOnly();
                    _pm.worked(20);
                }
            }, _pm);
        } finally {
            _pm.done();
        }
        return timeStamp[0];
    }

    @Override
    public String getExtension() {
        if (isTextPlain()) {
            return EXT_TXT;
        }
        if (isTextHtml()) {
            return EXT_HTML;
        }
        if (isRTF()) {
            return EXT_RTF;
        }
        return null;
    }

    @Override
    public void dispose() {
        deleteTempFile();
        super.dispose();
    }

    @Override
    public String getMimeType() {
        return mimeType;
    }

    @Override
    public String getFileName() {
        return fileName;
    }

    @Override
    public void reset() {
        deleteTempFile();
        fileName = mimeType = null;
        super.reset();
    }

    void deleteTempFile() {
        if (fileName != null) {
            File file = new File(fileName);
            file.delete();
        }
    }

    @Override
    public boolean isTextPlain() {
        return TEXT_PLAIN.equalsIgnoreCase(mimeType);
    }

    @Override
    public boolean isTextHtml() {
        return TEXT_HTML.equalsIgnoreCase(mimeType);
    }

    @Override
    public boolean isRTF() {
        // html, text, rtf is the only mime types possible (is it true?), so
        // if it is not text and it is not html it must be rtf.
        return !isTextPlain() && !isTextHtml();
    }

    @Override
    public String getCharEncoding() {
        return charEncoding;
    }

}

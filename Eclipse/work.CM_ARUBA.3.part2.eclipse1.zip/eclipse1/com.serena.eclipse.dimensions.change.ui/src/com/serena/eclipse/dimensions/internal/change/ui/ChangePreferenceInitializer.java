/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.internal.change.ui;

import org.eclipse.core.runtime.Preferences;
import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;

import com.serena.eclipse.dimensions.change.ui.DMChangeUiPlugin;

/**
 * @author V.Grishchenko
 */
public class ChangePreferenceInitializer extends AbstractPreferenceInitializer implements IDMChangePreferences {

    public ChangePreferenceInitializer() {
    }

    @Override
    public void initializeDefaultPreferences() {
        Preferences preferences = DMChangeUiPlugin.getDefault().getPluginPreferences();

        // list display preferences
        preferences.setDefault(CHANGE_DOC_LIST_DISPLAY, CHANGE_DOC_LIST_DISPLAY_VIEW_VAL);
        preferences.setDefault(CHANGE_DOC_LIST_DISPLAY_MULTIPAGE, false);
    }

}

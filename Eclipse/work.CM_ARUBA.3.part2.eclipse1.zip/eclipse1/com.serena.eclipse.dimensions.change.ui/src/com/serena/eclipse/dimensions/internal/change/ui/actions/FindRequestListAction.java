package com.serena.eclipse.dimensions.internal.change.ui.actions;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.osgi.util.NLS;
import org.eclipse.ui.PlatformUI;

import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.core.ChangeDocumentAdapter;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMTypeScope;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.OtherChDocPendingtList;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.change.ui.Messages;
import com.serena.eclipse.dimensions.internal.change.ui.RequestListPage;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDimensionsObjectEditHandler;
import com.serena.eclipse.dimensions.internal.ui.actions.DimensionsAction;
import com.serena.eclipse.dimensions.internal.ui.dialogs.FindObjectWizardDialog;

/**
 * @author kberezovchuk
 */
public class FindRequestListAction extends DimensionsAction {

    @Override
    public void run(IAction action) {
        IStructuredSelection selection = getSelection();

        if (selection.isEmpty() || !(selection.getFirstElement() instanceof RequestListPage.FoundListsProxy)) {
            return;
        }
        final RequestListPage.FoundListsProxy foundListProxy = (RequestListPage.FoundListsProxy) selection.getFirstElement();
        final DimensionsConnectionDetailsEx conn = foundListProxy.getConnectionDetails();

        // @formatter:off
        FindObjectWizardDialog dialog = new FindObjectWizardDialog(
                getShell(),
                IDMConstants.CHANGEDOCUMENT,
                conn,
                null,
                false,
                false,
                conn.isOnlyStreamsActive(),
                conn.isOnlyProjectsActive());
        // @formatter:on

        if (dialog.open() == Window.OK && !dialog.getFindResult().isEmpty()) {
            IDimensionsObjectEditHandler handler = DMUIPlugin.getDefault().getEditHandler(DMTypeScope.REQUEST);
            if (handler != null) {
                final List<String> ids = dialog.getSelectedNames();
                try {
                    PlatformUI.getWorkbench().getProgressService().busyCursorWhile(new IRunnableWithProgress() {

                        @Override
                        public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
                            String listQualifier = RequestListPage.FoundListsProxy.class.getName() + System.currentTimeMillis();
                            monitor.beginTask(NLS.bind(Messages.customList_adding, listQualifier), 1000);
                            try {
                                final List adapters = lookupRequests(conn, ids, Utils.subMonitorFor(monitor, 500));
                                if (!adapters.isEmpty()) {

                                    OtherChDocPendingtList requestList = new OtherChDocPendingtList(conn, listQualifier) {

                                        private List chDocuments = new ArrayList();
                                        {
                                            for (Iterator iter = adapters.listIterator(); iter.hasNext();) {
                                                Request changeDocument = ((ChangeDocumentAdapter) iter.next()).getChangeDocument();
                                                chDocuments.add(changeDocument);
                                            }
                                        }

                                        @Override
                                        protected List doFetch(Session session, IProgressMonitor pm) throws DMException {
                                            return chDocuments;
                                        }
                                    };

                                    foundListProxy.addRequestList(requestList);
                                }
                            } catch (DMException e) {
                                throw new InvocationTargetException(e);
                            } finally {
                                monitor.done();
                            }
                        }

                    });
                } catch (InvocationTargetException e1) {
                    DMUIPlugin.getDefault().handle(e1, getShell());
                } catch (InterruptedException e1) {
                }
            }
        }
    }

    private List lookupRequests(DimensionsConnectionDetailsEx connection, final List ids, final IProgressMonitor monitor)
            throws DMException {
        final ArrayList result = new ArrayList(ids.size());
        final Session session = connection.openSession(null);

        session.run(new ISessionRunnable() {

            @Override
            public void run() throws Exception {
                try {
                    monitor.beginTask(null, ids.size());
                    for (Iterator iter = ids.iterator(); iter.hasNext();) {
                        String requestId = (String) iter.next();
                        Request request = session.getObjectFactory().findRequest(requestId);
                        if (request != null) {
                            result.add(session.adapt(request));
                        }
                        monitor.worked(1);
                    }
                } finally {
                    monitor.done();
                }
            }

        }, monitor);

        return result;
    }

}

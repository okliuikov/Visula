/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.internal.change.ui.forms;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.events.HyperlinkEvent;
import org.eclipse.ui.forms.events.IHyperlinkListener;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.ImageHyperlink;
import org.eclipse.ui.forms.widgets.Section;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.internal.change.ui.dialogs.NewAttachmentDialog;
import com.serena.eclipse.dimensions.internal.change.ui.model.AttachmentDetails;
import com.serena.eclipse.dimensions.internal.change.ui.model.IAttachmentsModel;
import com.serena.eclipse.dimensions.internal.ui.DMUIPlugin;
import com.serena.eclipse.dimensions.internal.ui.IDMImages;
import com.serena.eclipse.dimensions.internal.ui.Messages;
import com.serena.eclipse.dimensions.internal.ui.UIUtils;
import com.serena.eclipse.dimensions.internal.ui.forms.DimensionsFormPart;

/**
 * @author abollmann
 *
 *         Class to create the panel for the Attachment dialog/editor
 */
public class AttachmentPanel extends DimensionsFormPart {
    private Composite panel;
    private Table table;
    private String originalDescription;
    final int EDITABLECOLUMN = 1;
    private Image addImage;
    private Image removeImage;
    private Image browseImage;
    private Image saveImage;
    private List attachmentFileList = null;
    private Font font = null;
    private boolean existingChdoc;
    ImageHyperlink browseButton = null;
    ImageHyperlink saveButton = null;

    public AttachmentPanel(IManagedForm managedForm, IAttachmentsModel model, Composite parent/* , FormToolkit toolkit */) {
        super(managedForm, model);
        this.panel = parent;

        existingChdoc = model.getUnderlyingObject().getAPIObject() != null;

        // create Title Section
        Section section = getToolkit().createSection(parent, ExpandableComposite.TITLE_BAR | Section.DESCRIPTION);
        section.setText(Messages.attachment_title);
        section.setDescription(Messages.attachment_sectionDesc);
        GridData gd = UIUtils.setGridData(section, GridData.FILL_BOTH);
        gd.widthHint = 10;
        gd.heightHint = 200;

        // Composite for all buttons, placed in the section text client
        Composite compButton = getToolkit().createComposite(section);
        UIUtils.setGridLayout(compButton, 4).marginHeight = 0;
        section.setTextClient(compButton);
        compButton.setBackground(section.getTitleBarGradientBackground());

        // Add all the buttons (hyperlinks)
        ImageHyperlink addButton = getToolkit().createImageHyperlink(compButton, SWT.NONE);
        addButton.setToolTipText(Messages.attachment_tooltip_add);
        ImageDescriptor descriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.ADD);
        addImage = descriptor.createImage();
        addButton.setImage(addImage);
        addButton.setBackground(section.getTitleBarGradientBackground());
        addButton.addHyperlinkListener(new AddListener());

        ImageHyperlink removeButton = getToolkit().createImageHyperlink(compButton, SWT.NONE);
        removeButton.setToolTipText(Messages.attachment_tooltip_remove);
        removeButton.addHyperlinkListener(new DeleteListener());
        descriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.REMOVE);
        removeImage = descriptor.createImage();
        removeButton.setImage(removeImage);
        removeButton.setBackground(section.getTitleBarGradientBackground());

        if (existingChdoc) {
            browseButton = getToolkit().createImageHyperlink(compButton, SWT.NONE);
            browseButton.setToolTipText(Messages.attachment_tooltip_browse);

            descriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.BROWSE);
            browseImage = descriptor.createImage();
            browseButton.setImage(browseImage);
            browseButton.setBackground(section.getTitleBarGradientBackground());
            browseButton.addHyperlinkListener(new BrowseListener());
            browseButton.setEnabled(false);
        }
        if (existingChdoc) {
            saveButton = getToolkit().createImageHyperlink(compButton, SWT.NONE);
            saveButton.setToolTipText(Messages.attachment_tooltip_save);
            descriptor = DMUIPlugin.getDefault().getImageDescriptor(IDMImages.SAVE);
            saveImage = descriptor.createImage();
            saveButton.setImage(saveImage);
            saveButton.setBackground(section.getTitleBarGradientBackground());
            saveButton.addHyperlinkListener(new SaveListener());
            saveButton.setEnabled(false);
        }

        // 3.2 draws border around section description (bug?) - ugly
        // put table into holder as need border around table only
        Composite tableArea = getToolkit().createComposite(section);
        FillLayout fillLayout = new FillLayout();
        fillLayout.marginHeight = fillLayout.marginWidth = 1; // reserve 1 pixel for table border
        tableArea.setLayout(fillLayout);
        section.setClient(tableArea);
        getToolkit().paintBordersFor(tableArea);

        table = getToolkit().createTable(tableArea, SWT.MULTI | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
        table.setHeaderVisible(true);
        table.setLinesVisible(true);

        TableLayout tlayout = new TableLayout();
        table.setLayout(tlayout);

        TableColumn col1 = new TableColumn(table, SWT.NONE, 0);
        col1.setText(Messages.attachment_id);
        col1.setResizable(true);
        if (model.getUnderlyingObject().getAPIObject() != null) {
            tlayout.addColumnData(new ColumnWeightData(15, 100, true));
        } else {
            tlayout.addColumnData(new ColumnWeightData(10, 30, true));
        }
        TableColumn col2 = new TableColumn(table, SWT.NONE, 1);
        col2.setText(Messages.attachment_description);
        if (existingChdoc) {
            tlayout.addColumnData(new ColumnWeightData(15, 300, true));
        } else {
            tlayout.addColumnData(new ColumnWeightData(10, 30, true));
        }
        if (existingChdoc) {
            TableColumn col3 = new TableColumn(table, SWT.NONE, 2);
            col3.setText(Messages.attachment_size);
            tlayout.addColumnData(new ColumnWeightData(15, 60, true));
        }

        final TableEditor editor = new TableEditor(table);
        // The editor must have the same size as the cell and must
        // not be any smaller than 50 pixels.
        editor.horizontalAlignment = SWT.LEFT;
        editor.grabHorizontal = true;
        editor.minimumWidth = 50;
        table.addMouseListener(new MouseListener() {

            @Override
            public void mouseDoubleClick(MouseEvent e) {
                // Clean up any previous editor control
                Control oldEditor = editor.getEditor();
                if (oldEditor != null) {
                    oldEditor.dispose();
                }
                // Identify the selected row
                Table table = (Table) e.widget;
                TableItem item = table.getItem(table.getSelectionIndex());
                if (item == null) {
                    return;
                }

                // The control that will be the editor must be a child of the Table
                Text newEditor = new Text(table, SWT.NONE);
                newEditor.setText(item.getText(EDITABLECOLUMN));
                originalDescription = item.getText(EDITABLECOLUMN);

                newEditor.addKeyListener(new KeyListener() {
                    @Override
                    public void keyPressed(KeyEvent e) {
                        Text text = (Text) editor.getEditor();

                        if (e.character == SWT.ESC) {
                            editor.getItem().setText(EDITABLECOLUMN, originalDescription);
                            text.dispose();
                        } else if (e.character == SWT.CR) {
                            if (editor.getItem().getText(EDITABLECOLUMN) == originalDescription) {
                                text.dispose();
                                return;
                            }

                            // update the description of the attachment in the database
                            editor.getItem().setText(EDITABLECOLUMN, text.getText());
                            originalDescription = editor.getItem().getText(EDITABLECOLUMN);
                            String id = editor.getItem().getText(0);
                            updateAttachment(id, text.getText());
                            text.dispose();
                        } else {
                            editor.getItem().setText(EDITABLECOLUMN, text.getText());
                        }
                    }

                    @Override
                    public void keyReleased(KeyEvent e) {
                    }
                });

                newEditor.selectAll();
                newEditor.setFocus();
                editor.setEditor(newEditor, item, EDITABLECOLUMN);
            }

            @Override
            public void mouseDown(MouseEvent e) {
            }

            @Override
            public void mouseUp(MouseEvent e) {
                // Clean up any previous editor control
                Control oldEditor = editor.getEditor();
                if (oldEditor != null) {
                    oldEditor.dispose();
                }
                // Identify the selected row
                Table table = (Table) e.widget;
                TableItem item = null;
                if (table.getSelectionIndex() >= 0) {
                    item = table.getItem(table.getSelectionIndex());
                }
                if (item != null) {
                    saveButton.setEnabled(true);
                    browseButton.setEnabled(true);
                } else {
                    saveButton.setEnabled(false);
                    browseButton.setEnabled(false);
                }
            }

        });

        getToolkit().paintBordersFor(table);

    }

    private IAttachmentsModel getAttachmentModel() {
        return (IAttachmentsModel) getModel();
    }

    private void fillTable() {
        // remove all previous entries
        if (table.getItemCount() > 0) {
            table.removeAll();
        }
        AttachmentDetails[] attachments = getAttachmentModel().getAttachments();
        if (attachments == null) {
            attachments = new AttachmentDetails[0];
        }
        for (int i = 0; i < attachments.length; i++) {
            AttachmentDetails attach = attachments[i];

            String fileName = attach.getName();
            TableItem item = new TableItem(table, SWT.NONE);
            String description = attach.getDescription();
            String size = attach.getSize();
            if (attach.getModus() == AttachmentDetails.NEW || attach.getModus() == AttachmentDetails.UPDATED) {
                if (font == null) {
                    font = item.getFont();
                    FontData data[] = font.getFontData();
                    data[0].setStyle(SWT.ITALIC);
                    font = new Font(panel.getShell().getDisplay(), data[0]);
                }
                item.setFont(font);
            }
            item.setText(new String[] { fileName, description, size });
        }
    }

    @Override
    public void dispose() {
        if (addImage != null) {
            addImage.dispose();
        }
        if (removeImage != null) {
            removeImage.dispose();
        }
        if (saveImage != null) {
            saveImage.dispose();
        }
        if (browseImage != null) {
            browseImage.dispose();
        }
        if (font != null) {
            font.dispose();
        }
        // delete all created temporary files.
        if (attachmentFileList != null) {
            for (int i = 0; i < attachmentFileList.size(); i++) {
                File file = (File) attachmentFileList.get(i);
                file.delete();
            }
        }
        super.dispose();
    }

    @Override
    public void refresh() {
        fillTable();
        super.refresh();
    }

    /**
     * @return Returns the panel.
     */
    public Composite getPanel() {
        return panel;
    }

    class AddListener implements IHyperlinkListener {
        @Override
        public void linkEntered(HyperlinkEvent e) {
        }

        @Override
        public void linkExited(HyperlinkEvent e) {
        }

        @Override
        public void linkActivated(HyperlinkEvent e) {
            NewAttachmentDialog dialog = new NewAttachmentDialog(panel.getShell(), getAttachmentModel());
            dialog.open();
            fillTable();
        }
    }

    class SaveListener implements IHyperlinkListener {
        @Override
        public void linkEntered(HyperlinkEvent e) {
        }

        @Override
        public void linkExited(HyperlinkEvent e) {
        }

        @Override
        public void linkActivated(HyperlinkEvent e) {
            if (getAttachmentModel().isDirty()) {
                // There are attachments that haven't been saved yet. Don't allow any action until the editor is saved.
                MessageBox messageBox = new MessageBox(panel.getShell(), SWT.ICON_ERROR);
                messageBox.setText(Messages.message_error);
                messageBox.setMessage(Messages.attachment_notSaved);
                messageBox.open();
                return;
            }
            FileDialog fileDialog = new FileDialog(panel.getShell(), SWT.SAVE);
            int selection = table.getSelectionIndex();
            if (selection == -1) {
                return;
            }
            TableItem item = table.getItem(selection);
            String fileName = item.getText();
            fileDialog.setFileName(fileName);
            String fullFileName = fileDialog.open();
            if (fullFileName != null) {
                // save the attachment to file
                try {
                    getAttachmentModel().saveAttachmentToFile(fileName, fullFileName);
                } catch (DMException dmException) {
                    MessageBox messageBox = new MessageBox(panel.getShell(), SWT.ICON_ERROR);
                    messageBox.setMessage(dmException.getMessage());
                    messageBox.setText(Messages.message_error);
                    messageBox.open();
                }
            }
        }
    }

    class DeleteListener implements IHyperlinkListener {

        @Override
        public void linkEntered(HyperlinkEvent e) {
        }

        @Override
        public void linkExited(HyperlinkEvent e) {
        }

        @Override
        public void linkActivated(HyperlinkEvent e) {
            MessageBox messageBox = new MessageBox(panel.getShell(), SWT.ICON_QUESTION | SWT.YES | SWT.NO);
            messageBox.setMessage(Messages.attachment_deletion_confirm);
            messageBox.setText(Messages.attachment_confirm);
            int ret = messageBox.open();
            if (ret == SWT.YES) {
                TableItem item = table.getItem(table.getSelectionIndex());
                String id = item.getText(0);
                try {
                    getAttachmentModel().removeAttachment(id);
                    fillTable();
                } catch (DMException dme) {
                    messageBox = new MessageBox(panel.getShell(), SWT.ICON_ERROR);
                    messageBox.setMessage(dme.getLocalizedMessage());
                    messageBox.open();
                }
            }
        }
    }

    class BrowseListener implements IHyperlinkListener {

        @Override
        public void linkEntered(HyperlinkEvent e) {
        }

        @Override
        public void linkExited(HyperlinkEvent e) {
        }

        @Override
        public void linkActivated(HyperlinkEvent e) {
            if (getAttachmentModel().isDirty()) {
                // There are attachments that haven't been saved yet. Don't allow any action until the editor is saved.
                MessageBox messageBox = new MessageBox(panel.getShell(), SWT.ICON_ERROR);
                messageBox.setText(Messages.message_error);
                messageBox.setMessage(Messages.attachment_notSaved);
                messageBox.open();
                return;
            }
            MessageBox messageBox = new MessageBox(panel.getShell(), SWT.ICON_ERROR);
            int selected = table.getSelectionIndex();
            if (selected == -1) {
                messageBox.setText(Messages.message_error);
                messageBox.setMessage(Messages.attachment_noneSelected);
                messageBox.open();
                return; // no selection

            }
            TableItem item = table.getItem(selected);
            String id = item.getText(0);
            int index = id.lastIndexOf("."); //$NON-NLS-1$
            String extension = id.substring(index, id.length());
            String prefix = id.substring(0, index);
            // prefix has to be at least 3 characters long!
            if (prefix.length() == 1) {
                prefix += "00"; //$NON-NLS-1$
            } else if (prefix.length() == 2) {
                prefix += "0"; //$NON-NLS-1$
            }
            String fileName;
            try {
                File file = File.createTempFile(prefix, extension);
                fileName = file.getAbsolutePath();
                if (attachmentFileList == null) {
                    attachmentFileList = new ArrayList();
                }
                attachmentFileList.add(file);
                getAttachmentModel().saveAttachmentToFile(id, fileName);
                getAttachmentModel().getMimeType(id);
                Program program = Program.findProgram(extension);
                if (program != null) {
                    program.execute(fileName);
                } else {
                    messageBox.setText(Messages.message_error);
                    messageBox.setMessage(Messages.attachment_noFileAssociation);
                    messageBox.open();
                }

            } catch (DMException dme) {
                messageBox.setMessage(dme.getLocalizedMessage());
                messageBox.open();
            } catch (IOException ioe) {
                messageBox.setMessage(ioe.getMessage());
                messageBox.open();
            }
        }
    }

    private void updateAttachment(String id, String newDescription) {
        getAttachmentModel().updateAttachment(id, newDescription);
        // TODO can we change the ChangeListener to listen to the isDirty event as well?
        // Then we wouldn't need to call the fillTable here. Is is save to fill the table again
        // every time the model is set to dirty? I think so.
        fillTable();
    }

}

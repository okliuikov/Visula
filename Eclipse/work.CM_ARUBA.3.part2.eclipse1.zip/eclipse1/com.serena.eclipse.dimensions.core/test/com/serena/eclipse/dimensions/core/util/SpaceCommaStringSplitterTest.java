package com.serena.eclipse.dimensions.core.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Assert;
import org.junit.Test;

import com.serena.eclipse.dimensions.core.util.SpaceCommaStringSplitter.ResultCase;

public class SpaceCommaStringSplitterTest {

    private static final String stringToSplit = " Bu, Bu ,Bu , dU,dU dU ,, ,, uf ";

    @Test
    public void testSplit() {
        Collection<String> split = SpaceCommaStringSplitter.split(stringToSplit, ResultCase.UNMODIFIED);
        Assert.assertEquals(new ArrayList<String>(split), Arrays.asList(new String[] { "Bu", "Bu", "Bu", "dU", "dU", "dU", "uf" }));
    }

    @Test
    public void testSplitUpper() {
        Collection<String> split = SpaceCommaStringSplitter.split(stringToSplit, ResultCase.UPPER);
        Assert.assertEquals(new ArrayList<String>(split), Arrays.asList(new String[] { "BU", "BU", "BU", "DU", "DU", "DU", "UF" }));
    }

    @Test
    public void testSplitLower() {
        Collection<String> split = SpaceCommaStringSplitter.split(stringToSplit, ResultCase.LOWER);
        Assert.assertEquals(new ArrayList<String>(split), Arrays.asList(new String[] { "bu", "bu", "bu", "du", "du", "du", "uf" }));
    }

    @Test
    public void testSplitUniqueOrdered() {
        Collection<String> splitUnique = SpaceCommaStringSplitter.splitUnique(stringToSplit, ResultCase.UNMODIFIED,
                NumberAwareStringComparator.INSTANCE);
        Assert.assertEquals(new ArrayList<String>(splitUnique), Arrays.asList(new String[] { "Bu", "dU", "uf" }));

    }

    @Test
    public void testSplitUniqueOrderedNullComparator() {
        Collection<String> splitUnique = SpaceCommaStringSplitter.splitUnique(stringToSplit, ResultCase.UNMODIFIED, null);
        Assert.assertEquals(new ArrayList<String>(splitUnique), Arrays.asList(new String[] { "Bu", "dU", "uf" }));
    }

    @Test
    public void testSplitUniqueOrderedUpper() {
        Collection<String> splitUnique = SpaceCommaStringSplitter.splitUnique(stringToSplit, ResultCase.UPPER, null);
        Assert.assertEquals(new ArrayList<String>(splitUnique), Arrays.asList(new String[] { "BU", "DU", "UF" }));
    }

    @Test
    public void testSplitUniqueOrderedLower() {
        Collection<String> splitUnique = SpaceCommaStringSplitter.splitUnique(stringToSplit, ResultCase.LOWER, null);
        Assert.assertEquals(new ArrayList<String>(splitUnique), Arrays.asList(new String[] { "bu", "du", "uf" }));
    }
}

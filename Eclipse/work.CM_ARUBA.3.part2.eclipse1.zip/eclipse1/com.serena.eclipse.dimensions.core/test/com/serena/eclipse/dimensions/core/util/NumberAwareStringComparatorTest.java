package com.serena.eclipse.dimensions.core.util;

import org.junit.Assert;
import org.junit.Test;

import com.serena.eclipse.dimensions.core.util.NumberAwareStringComparator;

public class NumberAwareStringComparatorTest {

    @Test
    public void testCompare() {
        NumberAwareStringComparator comparator = NumberAwareStringComparator.INSTANCE;

        Assert.assertEquals("AAA_2".compareTo("AAA_10"), 1); // default
        Assert.assertEquals(comparator.compare("AAA_2", "AAA_10"), -1); // correct
        Assert.assertEquals(comparator.compare("AAA_10", "AAA_2"), 1);
        Assert.assertEquals(comparator.compare("AAA_10", "AAA_10"), 0);
        Assert.assertEquals(comparator.compare("2", "10"), -1);
        Assert.assertEquals(comparator.compare("2_A", "10_A"), -1);

        Assert.assertEquals(comparator.compare("AAA_2_BBB", "AAA_10_BBB"), -1);
        Assert.assertEquals(comparator.compare("AAA_10_BBB", "AAA_2_BBB"), 1);

        Assert.assertEquals("AAA_2_CCC_3".compareTo("AAA_2_CCC_20"), 1); // default
        Assert.assertEquals(comparator.compare("AAA_2_CCC_3", "AAA_2_CCC_20"), -1); // correct

        Assert.assertEquals("AAA_2_CCC_20".compareTo("AAA_10_CCC_20"), 1); // default
        Assert.assertEquals(comparator.compare("AAA_2_CCC_20", "AAA_10_CCC_20"), -1); // correct

        Assert.assertEquals(comparator.compare("AAA_2", "AAA_2_CCC_20"), -1);
        Assert.assertEquals(comparator.compare("AAA_2_CCC_20", "AAA_2"), 1);

        Assert.assertEquals(comparator.compare("AAA_2_CCC_20", "AAA"), 1);
        Assert.assertEquals(comparator.compare("AAA", "AA"), 1);
        Assert.assertEquals(comparator.compare("AAA", ""), 1);

    }

}

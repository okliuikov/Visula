/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import merant.adm.exception.AdmObjectException;

import com.serena.dmclient.api.IDMReport;
import com.serena.eclipse.sbm.ws.clientapi.xsd.QueryRange;
import com.serena.eclipse.sbm.ws.clientapi.xsd.ReportInfo;

/**
 * @author S.Korniychuk
 */
class SBMReportsResult implements ISBMReportsResult {

    private ISBMReport[] data;
    private int totalCount;

    private DateFormat dateFormat;

    public SBMReportsResult(ISBMConnection connection, List<IDMReport> result, DateFormat df) throws AdmObjectException {
    	if (result != null && result.size() > 0) {
    		List resList = new ArrayList();
    		for(IDMReport report: result){
    			String url = (String) report.getUrl();
    			String author = (String) report.getOriginator();
    			Date createDate = (Date) report.getCreateDate();
    			String reportName = (String) report.getName();
    			String reportID = (String) report.getID();
    			
    			SBMReport sbmReport = new SBMReport(connection, url, connection);
    			
    			sbmReport.setAuthor(author);
    			if (createDate == null) {
                    sbmReport.setCreateDate(null);
                } else {
                    sbmReport.setCreateDate(df.format(createDate));
                }
    			sbmReport.setLastModifiedUser(null);
                sbmReport.setTitle(reportName);
                sbmReport.setUrl(url);
                sbmReport.setReportUUID(reportID);
    			
                resList.add(sbmReport);
    		}
    		
    		data = (ISBMReport[]) resList.toArray(new ISBMReport[resList.size()]);
            dateFormat = df;
    	}
    }
    
    @Override
    public ISBMReport[] getData() {
        return data;
    }

    public void setData(ISBMReport[] data) {
        this.data = data;
    }

    @Override
    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    @Override
    public DateFormat getDateFormat() {
        return dateFormat;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.QualifiedName;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author V.Grishchenko
 */
public class RequestListList extends DimensionsObjectList {
    private static final QualifiedName KEY = new QualifiedName(RequestListList.class.getName(), "list"); //$NON-NLS-1$

    public static RequestListList getList(DimensionsConnectionDetailsEx con) {
        RequestListList list = (RequestListList) con.getSessionProperty(KEY);
        if (list == null) {
            list = new RequestListList(con);
            con.setSessionProperty(KEY, list);
        }
        return list;
    }

    public RequestListList(DimensionsConnectionDetailsEx con) {
        super(con, 0);
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        Assert.isLegal(objectDetails instanceof ERequestListDetails);
        monitor.beginTask(Messages.objectCreate_task, IProgressMonitor.UNKNOWN);
        monitor.subTask(getTypeScope().getObjectId(objectDetails));
        try {
            return session.getObjectFactory().createRequestList(((ERequestListDetails) objectDetails).getDetails());
        } finally {
            monitor.done();
        }
    }

    @Override
    protected List doFetch(final Session session, IProgressMonitor pm) throws DMException {
        pm.beginTask("Getting custom request lists", IProgressMonitor.UNKNOWN);
        final List[] result = new List[1];
        try {
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    // exclude jobs and active issues
                    Filter filter = new Filter();
                    filter.criteria().add(
                            new Filter.Criterion(SystemAttributes.OBJECT_ID, ECustomChangeDocumentList.jobPrefix + '%',
                                    Filter.Criterion.NOT));
                    filter.criteria().add(
                            new Filter.Criterion(SystemAttributes.OBJECT_ID, ECustomChangeDocumentList.ACTIVE_REQUESTS_LIST,
                                    Filter.Criterion.NOT));
                    result[0] = session.getObjectFactory().getCurrentUser().getRequestLists(filter);
                }
            }, pm);
        } finally {
            pm.done();
        }
        return result[0];
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.REQUEST_LIST;
    }

    @Override
    protected String getUniqueId(DimensionsArObject object) {
        return object.getName();
    }

    /**
     * Deletes the supplied list and fires notifications to listeners.
     */
    public void deleteList(ECustomChangeDocumentList list, IProgressMonitor monitor) throws DMException {
        String name = list.getQualifier();
        list.delete(monitor);
        RequestListAdapter deleted = null;
        APIObjectAdapter[] objects = getObjects();
        for (int i = 0; i < objects.length; i++) {
            RequestListAdapter rla = (RequestListAdapter) objects[i];
            if (rla.getRequestList().getName().equals(name)) {
                deleted = rla;
                break;
            }
        }
        if (deleted != null) {
            removeObjects(new APIObjectAdapter[] { deleted });
        }
    }

}

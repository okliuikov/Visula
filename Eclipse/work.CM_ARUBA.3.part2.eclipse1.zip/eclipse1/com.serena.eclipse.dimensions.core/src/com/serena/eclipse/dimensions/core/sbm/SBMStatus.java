/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.dimensions.core.DMPlugin;

/**
 * @author V.Grishchenko
 */
public class SBMStatus extends Status {

    public static final int TEAMTRACK_OK = 1;
    public static final int TEAMTRACK_ERROR = -1;
    public static final int MISSING_PARAMETER = -2;
    public static final int NO_PERMISSION = -3;
    public static final int NO_SUCH_FIELD = -4;
    public static final int MEMORY_ERROR = -5;
    public static final int SOCKET_READ_ERROR = -6;
    public static final int SOCKET_WRITE_ERROR = -7;
    public static final int SOCKET_CONNECT_FAILED = -8;
    public static final int SOCKET_CREATE_FAILED = -9;
    public static final int INVALID_DATATYPE = -10;
    public static final int INVALID_USER = -11;
    public static final int NO_RESULTS = -12;
    public static final int SERVER_ERROR = -13;
    public static final int INVALID_VERSION = -14;
    public static final int INVALID_PARAMETERS = -15;
    public static final int RECORD_LOCKED = -16;
    public static final int RECORD_LOCK_BROKEN = -17;
    public static final int INVALID_FIELDS = -18;
    public static final int TRANSITION_INVALID = -19;
    public static final int ITEM_NOT_FOUND = -20;
    public static final int NOT_UPDATEABLE = -21;
    public static final int INCORRECT_MODE = -22;
    public static final int FILE_NOT_FOUND = -23;
    public static final int FILE_SEEK_ERROR = -24;
    public static final int FILE_READ_ERROR = -25;
    public static final int ADD_TABLE_ERROR = -26;
    public static final int INVALID_PREFIX = -27;
    public static final int PARAMETER_NOT_UNIQUE = -28;
    public static final int STRING_TOO_LONG = -29;
    public static final int SOCKET_READ_LIST_END = -30;
    public static final int INVALID_QUERY = -31;
    public static final int NO_IP_ADDRESS = -100;
    public static final int LICENSING_VIOLATION = -101;
    public static final int CONCURRENT_LICENSE_UNAVAILABLE = -102;
    public static final int CONCURRENT_LICENSE_EXPIRED = -103;
    public static final int NAMED_LICENSE_UNAVAILABLE = -104;

    /**
     * Return an error message which corresponds to the numeric code returned
     * by TeamTrack.
     *
     * The list of codes is taken from TSDef.h.
     *
     * @param code The integer return code from TeamTrack.
     * @return String which represents the return code.
     */
    public static String getStatusMessage(int code) {
        switch (code) {
        case TEAMTRACK_OK:
            return "Ok";
        case TEAMTRACK_ERROR:
            return "TeamTrack error";
        case MISSING_PARAMETER:
            return "Missing parameter";
        case NO_PERMISSION:
            return "No permission";
        case NO_SUCH_FIELD:
            return "No such field";
        case MEMORY_ERROR:
            return "Memory error";
        case SOCKET_READ_ERROR:
            return "Socket read error";
        case SOCKET_WRITE_ERROR:
            return "Socket write error";
        case SOCKET_CONNECT_FAILED:
            return "Socket connect failed";
        case SOCKET_CREATE_FAILED:
            return "Socket create failed";
        case INVALID_DATATYPE:
            return "Invalid datatype";
        case INVALID_USER:
            return "Invalid User ID or Password";
        case NO_RESULTS:
            return "No results";
        case SERVER_ERROR:
            return "Server error";
        case INVALID_VERSION:
            return "Invalid version";
        case INVALID_PARAMETERS:
            return "Invalid parameters";
        case RECORD_LOCKED:
            return "Record locked";
        case RECORD_LOCK_BROKEN:
            return "Record lock broken";
        case INVALID_FIELDS:
            return "Invalid fields";
        case TRANSITION_INVALID:
            return "Transition invalid";
        case ITEM_NOT_FOUND:
            return "Item not found";
        case NOT_UPDATEABLE:
            return "Not updateable";
        case INCORRECT_MODE:
            return "Incorrect mode";
        case FILE_NOT_FOUND:
            return "File not found";
        case FILE_SEEK_ERROR:
            return "File seek error";
        case FILE_READ_ERROR:
            return "File read error";
        case ADD_TABLE_ERROR:
            return "Add table error";
        case INVALID_PREFIX:
            return "Invalid prefix";
        case PARAMETER_NOT_UNIQUE:
            return "Parameter not unique";
        case STRING_TOO_LONG:
            return "String too long";
        case SOCKET_READ_LIST_END:
            return "Socket read list end";
        case INVALID_QUERY:
            return "Invalid query";
        case NO_IP_ADDRESS:
            return "No ip address";
        case LICENSING_VIOLATION:
            return "Licensing violation";
        case CONCURRENT_LICENSE_UNAVAILABLE:
            return "Concurrent license unavailable";
        case CONCURRENT_LICENSE_EXPIRED:
            return "Concurrent license expired";
        case NAMED_LICENSE_UNAVAILABLE:
            return "Named license unavailable";
        default:
            return "Undefined TeamTrack Error";
        }
    }

    public SBMStatus(int code, Throwable exception) {
        super(IStatus.ERROR, DMPlugin.ID, code, getStatusMessage(code), exception);
    }

    public SBMStatus(String pluginId, int code, Throwable exception) {
        super(IStatus.ERROR, pluginId, code, getStatusMessage(code), exception);
    }

    /**
     * @param severity
     * @param pluginId
     * @param code
     * @param message
     * @param exception
     */
    public SBMStatus(int severity, String pluginId, int code, String message, Throwable exception) {
        super(severity, pluginId, code, message, exception);
    }

}

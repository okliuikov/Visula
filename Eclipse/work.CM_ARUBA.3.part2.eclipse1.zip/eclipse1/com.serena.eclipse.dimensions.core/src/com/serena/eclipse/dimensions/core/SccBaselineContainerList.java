/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmfile.dto.Unit;

/**
 * @author V.Grishchenko
 */
public class SccBaselineContainerList extends BaselineList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = SccBaselineContainerList.class.getName();

    private SccProjectContainer parentContainer;

    public SccBaselineContainerList(SccProjectContainer projectContainer) {
        super(projectContainer.getConnectionDetails(), SCC_BASELINE_CONTAINERS);
        this.parentContainer = projectContainer;
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List<Baseline> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        pm.beginTask(null, IProgressMonitor.UNKNOWN);
        final Unit<List<Baseline>> holder = new Unit<List<Baseline>>();
        EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
        final EclipseProjectsFetcher<Baseline> listsEclipse = listFactory.createEclipseProjectsFetcher();
        final String includeClosedFilter = getIncludeClosedFilter();
        try {
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    Integer parentIdeUid = new Integer(parentContainer.getIdeUid());
                    List<Baseline> containersBaselines = listsEclipse.getContainersBaselines(parentIdeUid,
                            session.getConnectionDetails().getMaxRecentCount(), includeClosedFilter);
                    holder.setValue(containersBaselines);

                }
            }, pm);

        } finally {
            pm.done();
        }
        return holder.getValue();
    }

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        Baseline baseline = (Baseline) dimensionsObject;
        String ideTag = (String) baseline.getAttribute(SystemAttributes.IDE_TAG);
        return new SccBaselineContainer(baseline, getConnectionDetails(), ideTag);
    }

    @Override
    public String getQualifier() {
        return parentContainer.getObjectSpec();
    }

    public SccProjectContainer getParentContainer() {
        return parentContainer;
    }

}

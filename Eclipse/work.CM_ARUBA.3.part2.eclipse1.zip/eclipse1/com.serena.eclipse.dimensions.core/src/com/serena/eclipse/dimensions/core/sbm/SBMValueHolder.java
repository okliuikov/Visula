package com.serena.eclipse.dimensions.core.sbm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.serena.dmclient.api.IDMReportRequest;
import com.serena.dmclient.api.IDMReportColumn;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.sbm.ws.clientapi.xsd.ExtraValue;
import com.serena.eclipse.sbm.ws.clientapi.xsd.ReportResult;

class SBMValueHolder implements ISBMValueHolder {

	private static final long serialVersionUID = -7603566730193377535L;

	private ISBMConnection connection;
	private String id;
	private String sbmItemId;
	private String title;
	private String sourceUUID;
	private String url;
	private Map values;

	SBMValueHolder(String reportUUID, ReportResult result,
			SBMProperty[] columns, ISBMConnection connection) {
		this.connection = connection;
		this.sourceUUID = reportUUID;
		if (result != null) {
			id = result.getItemName();
			sbmItemId = result.getItemId();
			url = result.getItemURL();
			ExtraValue[] rValues = result.getFieldValue();
			if (rValues != null && columns != null
					&& rValues.length == columns.length) {
				values = new HashMap();
				for (int i = 0; i < columns.length; i++) {
					values.put(columns[i].getId(), rValues[i].getValue());
					if (ISBMReport.FIELD_REPORT_TITLE
							.equals(columns[i].getId())) {
						title = rValues[i].getValue();
					}
				}
			}
		}
	}

	SBMValueHolder(IDMReportRequest result) {
		id = (String) result.getName();
		sbmItemId = (String) result.getID();
		url = (String) result.getUrl();
		List<IDMReportColumn> columns = result.getColumns();
		List<String> rowValues = result.getGridVals();
		values = new HashMap();
		
		for (int i = 0; i < columns.size(); i++) {
			IDMReportColumn column = columns.get(i);
			String name = column.getDisplayName();
			String value = rowValues.get(i);
			values.put(name, value);
			if (ISBMReport.FIELD_REPORT_TITLE.equals(name)) {
				title = String.valueOf(value);
			}
		}
	}

	@Override
	public String getUrl() {
		return url;
	}

	@Override
	public String getValue(String field) {
		if (values == null) {
			return null;
		}
		Object obj = values.get(field);
		return (obj == null) ? "" : obj.toString();
	}

	@Override
	public String getID() {
		return id;
	}

	@Override
	public boolean isActive() throws SBMException {
		return ((SBMManager) getConnection().getSBMManager())
				.isActive(getUrl());
	}

	@Override
	public String getItemID() {
		return sbmItemId;
	}

	@Override
	public ISBMConnection getConnection() {
		return connection;
	}

	@Override
	public String getDisplayUrl() {
		return getUrl();
	}

	@Override
	public ISBMContainer getParent() {
		return null;
	}

	@Override
	public int getType() {
		return 0;
	}

	@Override
	public DimensionsConnectionDetailsEx getConnectionDetails() {
		return null;
	}

	@Override
	public String getServiceId() {
		return null;
	}

	@Override
	public boolean isContainer() {
		return false;
	}

	@Override
	public Object getAdapter(Class adapter) {
		return null;
	}

	@Override
	public SBMProperty[] getProperties() {
		return null;
	}

	@Override
	public String getProperty(SBMProperty id) {
		return null;
	}

	@Override
	public String getSourceUUID() {
		return sourceUUID;
	}

	@Override
	public String getTitle() {
		return title;
	}

	Map getPropertyValues() {
		return values;
	}

}

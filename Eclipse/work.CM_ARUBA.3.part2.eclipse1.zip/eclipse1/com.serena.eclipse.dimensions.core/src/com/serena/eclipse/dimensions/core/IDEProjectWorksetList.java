/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public class IDEProjectWorksetList extends WorksetList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = IDEProjectWorksetList.class.getName();

    private DimensionsIDEProject project;

    /**
     * Creates project member list
     *
     * @param con
     * @param includeOnlyStreams
     *            - List will include only Streams
     * @param includeOnlyProjects
     *            - List will include only Projects
     *            If both includeOnlyStreams and includeOnlyProjects are false then projects and streams will be included in the
     *            list.
     */
    public IDEProjectWorksetList(DimensionsConnectionDetailsEx con, DimensionsIDEProject project, boolean includeOnlyStreams,
            boolean includeOnlyProjects) {
        // @formatter:off
        super(con, includeOnlyStreams ? IDE_PROJECT_MEMBER_STREAM :
            includeOnlyProjects ? IDE_PROJECT_MEMBER_WORKSET : IDE_PROJECT_MEMBER);
        // @formatter:on
        Assert.isLegal(project != null);
        this.project = project;
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    public DimensionsIDEProject getProject() {
        return project;
    }

    @Override
    protected List<Project> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);

            final Unit<List<Project>> holder = new Unit<List<Project>>();

            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    Filter wsf = new Filter();
                    wsf.criteria().add(
                            new Filter.Criterion(SystemAttributes.IDE_DM_UID, new Long(project.getIDEUid()),
                                    Filter.Criterion.EQUALS));
                    DimensionsObjectList dol = project.getObjectList();
                    if (dol != null && dol instanceof DimensionsIDEProjectsList) {
                        if (((DimensionsIDEProjectsList) dol).isIncludeOnlyProjects()) {
                            wsf.criteria().add(new Filter.Criterion(SystemAttributes.WSET_IS_STREAM, "Y", Filter.Criterion.NOT));
                        } else if (((DimensionsIDEProjectsList) dol).isIncludeOnlyStreams()) {
                            wsf.criteria().add(new Filter.Criterion(SystemAttributes.WSET_IS_STREAM, "Y", Filter.Criterion.EQUALS));
                        }
                    }
                    if (DMPlugin.getDefault().isFilterClosedProjects()) {
                        addNotClosedCriterion(wsf);
                    }
                    holder.setValue(session.getObjectFactory().getProjects(wsf));
                }

            }, pm);
            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        WorksetAdapter workset = (WorksetAdapter) super.adapt(session, dimensionsObject);
        workset.setParentAdapter(project);
        return workset;
    }

    @Override
    public String getQualifier() {
        return (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
    }

    @Override
    protected boolean accept(DimensionsArObject workset) {
        // do not accept locked worksets
        return true;

    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        // not a container
        return createIdeObject(session, (DimensionsIDEProjectDetails) objectDetails, IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG,
                IDMConstants.DURULES_ID, false, new Long(project.getIDEUid()), false, monitor);
    }

}

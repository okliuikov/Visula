/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.Serializable;

import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public class SBMItemId implements Serializable {
    static final long serialVersionUID = -166238928618836601L;

    private static final char SEPARATOR = ':';

    private int tableId = -1;
    private int recordId = -1;

    private static String[] parseIds(String id) {
        Assert.isNotNull(id);
        int idx = id.indexOf(SEPARATOR);
        if (idx == -1) {
            throw new IllegalArgumentException("tableId:recordId expected, received " + id); //$NON-NLS-1$
        }
        if (idx == id.length() - 1) {
            throw new IllegalArgumentException("missing record id in " + id); //$NON-NLS-1$
        }
        return new String[] { id.substring(0, idx), id.substring(idx + 1) };
    }

    public static String parseItemId(String tableId, String recordId) {
        return new StringBuffer().append(tableId).append(SEPARATOR).append(recordId).toString();
    }

    /**
     * @param id tableId,recordId
     */
    public SBMItemId(String id) {
        this(parseIds(id));
    }

    /**
     * @param id {tableId, recordId}
     */
    public SBMItemId(String[] id) {
        this(id[0], id[1]);
    }

    public SBMItemId(String tableId, String recordId) {
        if (tableId != null) {
            this.tableId = Integer.parseInt(tableId);
        }
        if (recordId != null) {
            this.recordId = Integer.parseInt(recordId);
        }
    }

    public SBMItemId(int tableId, int recordId) {
        this.tableId = tableId;
        this.recordId = recordId;
    }

    public int getTableId() {
        return tableId;
    }

    public String getTableIdAsString() {
        return String.valueOf(tableId);
    }

    public int getRecordId() {
        return recordId;
    }

    public String getRecordIdAsString() {
        return String.valueOf(recordId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof SBMItemId) {
            SBMItemId otherId = (SBMItemId) obj;
            return tableId == otherId.tableId && recordId == otherId.recordId;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return tableId ^ recordId;
    }

    @Override
    public String toString() {
        return new StringBuffer().append(tableId).append(SEPARATOR).append(recordId).toString();
    }

}

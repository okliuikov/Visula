/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.Collections;
import java.util.List;

/**
 * @author V.Grishchenko
 */
public class DimensionsIDEProjectGroupDetails extends DimensionsIDEProjectDetails {
    private List<APIObjectAdapter> members;

    public DimensionsIDEProjectGroupDetails(String product, String name, String description) {
        super(product, name, description);
    }

    public List<APIObjectAdapter> getMembers() {
        if (members == null) {
            return Collections.emptyList();
        }
        return members;
    }

    public void setMembers(List<APIObjectAdapter> members) {
        this.members = members;
    }
}

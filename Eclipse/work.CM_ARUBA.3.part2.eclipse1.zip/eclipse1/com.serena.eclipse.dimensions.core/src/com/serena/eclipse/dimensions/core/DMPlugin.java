/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.core;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.FileAppender;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;
import org.eclipse.core.runtime.Status;
import org.osgi.framework.BundleContext;
import org.slf4j.ILoggerFactory;
import org.slf4j.LoggerFactory;

import com.serena.dmclient.api.DimensionsConnectionDetails;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.util.Utils;

public class DMPlugin extends Plugin {
    public static final String ID = "com.serena.eclipse.dimensions.core"; //$NON-NLS-1$
    public static final String AUTHENTICATOR_EP = "authenticator"; //$NON-NLS-1$
    public static final String CONNECTION_SUBSCRIBER_EP = "connectionSubscriber"; //$NON-NLS-1$
    public static final String SERVICE_ID = "com.serena.eclipse.dimensions"; //$NON-NLS-1$

    private static final String UI_PROFILE = "ui_profile"; //$NON-NLS-1$
    private static final String SERVER_LOCALE = "server_locale"; //$NON-NLS-1$
    private static final String UI_RECENT_COUNT = "ui_recent_count"; //$NON-NLS-1$
    private static final String UI_RECENT_EXPANDED = "ui_recent_expanded"; //$NON-NLS-1$
    private static final String UI_FAVOURITES_EXPANDED = "ui_favourite_expanded"; //$NON-NLS-1$
    private static final String SBM_SOAP_URL = "sbm_soap_url"; //$NON-NLS-1$
    private static final String SBM_WEB_URL = "sbm_web_url"; //$NON-NLS-1$
    private static final String SBM_SOLUTION = "sbm_solution"; //$NON-NLS-1$
    private static final String SBM_AUTH_MODE = "sbm_auth_mode"; //$NON-NLS-1$
    private static final String SBM_USERNAME = "sbm_username"; //$NON-NLS-1$
    private static final String SBM_DOMAIN = "sbm_domain";

    // api logging debug options
    private static final String LOG_CMD = ID + "/log_cmd"; //$NON-NLS-1$
    private static final String LOG_CMD_LEVEL = ID + "/log_cmd_level"; //$NON-NLS-1$
    private static final String LOG_CMD_FILE = ID + "/log_cmd_file"; //$NON-NLS-1$
    private static final String LOG_NET = ID + "/log_net"; //$NON-NLS-1$
    private static final String LOG_NET_LEVEL = ID + "/log_net_level"; //$NON-NLS-1$
    private static final String LOG_NET_FILE = ID + "/log_net_file"; //$NON-NLS-1$
    // default log locations
    private static final String DEFAULT_LOG_DIR = "logs"; //$NON-NLS-1$
    private static final String DEFAULT_LOG_FILE_CMD = "cmdlog.txt"; //$NON-NLS-1$
    private static final String DEFAULT_LOG_FILE_NET = "netlog.txt"; //$NON-NLS-1$
    // sbm logging
    private static final String DEBUG_SBM = ID + "/sbmdebug"; //$NON-NLS-1$

    // internal event types dispatched to registry listener methods
    private static final int ADDED = 1;
    private static final int DELETED = 2;
    private static final int UPDATED = 3;

    // The shared instance.
    private static DMPlugin plugin;

    private List<DimensionsConnectionDetailsEx> locs;
    private IDMConsoleListener console;
    private List<IConnectionSubscriber> connectonSubscribers;
    private boolean gotConnectionSubscribers; // set after call to getConnectionSubscribers

    // Resource bundle.
    private ResourceBundle resourceBundle;
    private DmSettings settings;

    private List<IConnectionRegistryListener> listeners = new ArrayList<IConnectionRegistryListener>();
    private boolean loggerInitialized;

    // both true by default, value could be changed by user settings if they were initialized
    private boolean filterClosedProjects = true;
    private boolean filterClosedBaselines = true;

    /**
     * The constructor.
     */
    public DMPlugin() {
        super();
        plugin = this;
        try {
            resourceBundle = ResourceBundle.getBundle("com.serena.eclipse.dimensions.core.CorePluginResources"); //$NON-NLS-1$
        } catch (MissingResourceException x) {
            resourceBundle = null;
        }
    }

    /**
     * This method is called upon plug-in activation
     */
    @Override
    public void start(BundleContext context) throws Exception {
        super.start(context);
        // now get the Persisted Connection information
        this.settings = DmSettings.getInstance();

        // make sure initialized only once per DimensionsConnectionManager.setDebugLogFile()'s
        // javadoc if started more than once
        if (!loggerInitialized) {
            initializeLogger();
            loggerInitialized = true;
        }
    }

    /**
     * This method is called when the plug-in is stopped
     */
    @Override
    public void stop(BundleContext context) throws Exception {
        super.stop(context);

        if (locs != null) {
            for (DimensionsConnectionDetailsEx loc : locs) {
                persistConnectionUiExtraData(loc);
            }
        }

    }

    /**
     * Returns the shared instance.
     */
    public static DMPlugin getDefault() {
        return plugin;
    }

    /**
     * Returns the string from the plugin's resource bundle,
     * or 'key' if not found.
     */
    public static String getResourceString(String key) {
        ResourceBundle bundle = DMPlugin.getDefault().getResourceBundle();
        try {
            return (bundle != null) ? bundle.getString(key) : key;
        } catch (MissingResourceException e) {
            return key;
        }
    }

    /**
     * Returns the plugin's resource bundle,
     */
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    public void addRegistryListener(IConnectionRegistryListener listener) {
        synchronized (listeners) {
            if (!listeners.contains(listener)) {
                listeners.add(listener);
            }
        }
    }

    public void removeRegistryListener(IConnectionRegistryListener listener) {
        synchronized (listeners) {
            listeners.remove(listener);
        }
    }

    private void notifyListeners(DimensionsConnectionDetailsEx con1, DimensionsConnectionDetailsEx con2, int type) {
        List<IConnectionRegistryListener> listeneresCopy;
        synchronized (listeners) {
            listeneresCopy = new ArrayList<IConnectionRegistryListener>(listeners);
        }
        for (Iterator<IConnectionRegistryListener> iter = listeneresCopy.iterator(); iter.hasNext();) {
            IConnectionRegistryListener aListener = iter.next();
            switch (type) {
            case ADDED:
                aListener.connectionAdded(con1);
                break;
            case DELETED:
                aListener.connectionDeleted(con1);
                break;
            case UPDATED:
                aListener.connectionUpdated(con1, con2);
                break;
            default:
                assert false;
            }
        }
    }

    public IDMConnectionReconciliator getPluggedInReconciliator() {
        // preserve local data for now
        return new IDMConnectionReconciliator() {

            @Override
            public boolean reconcile(ConnectionConflict[] conflicts) {
                try {
                    for (int i = 0; i < conflicts.length; i++) {
                        conflicts[i].acceptInternal();
                    }
                } catch (DMException e) {
                    e.printStackTrace();
                }
                return true;
            }
        };
    }

    public IUserAuthenticator getPluggedInAuthenticator() {
        IUserAuthenticator result = null;
        if (isDebugging()) {
            System.out.println("-- locating plugged-in authenticator"); //$NON-NLS-1$
        }
        IExtensionPoint authPoint = Platform.getExtensionRegistry().getExtensionPoint(ID, AUTHENTICATOR_EP);
        if (authPoint != null) {
            IExtension[] extensions = authPoint.getExtensions();
            if (extensions.length == 0) {
                if (isDebugging()) {
                    System.out.println("-- no authenticator found!"); //$NON-NLS-1$
                }
                return null;
            }

            // consider 1st extension only
            if (isDebugging()) {
                System.out.println("-- using authenticator from contribution: " + extensions[0].getUniqueIdentifier()); //$NON-NLS-1$
            }

            IConfigurationElement[] elements = extensions[0].getConfigurationElements();
            for (int i = 0; i < elements.length; i++) {
                if (!elements[i].getName().equals("run")) { //$NON-NLS-1$
                    continue;
                }
                try {
                    Object o = elements[i].createExecutableExtension("class"); //$NON-NLS-1$
                    if (!(o instanceof IUserAuthenticator)) {
                        throw new CoreException(new Status(IStatus.ERROR, ID, 0, o.getClass().getName()
                                + " is not IUserAuthenticator", null)); //$NON-NLS-1$
                    }
                    if (isDebugging()) {
                        System.out.println("-- found authenticator: " + o.getClass().getName()); //$NON-NLS-1$
                    }
                    result = (IUserAuthenticator) o;
                    break;
                } catch (CoreException e) {
                    if (isDebugging()) {
                        System.out.println("-- no class element found for authenticator or other error, see the .log file for more details."); //$NON-NLS-1$
                    }
                    getLog().log(e.getStatus());
                }
            }
        }
        return result;
    }

    public List<IConnectionSubscriber> getConnectionSubscribers() {
        if (connectonSubscribers == null && !gotConnectionSubscribers) {
            connectonSubscribers = getPluggedInConnectionSubscribers();
            gotConnectionSubscribers = true;
        }
        return connectonSubscribers;
    }

    private List<IConnectionSubscriber> getPluggedInConnectionSubscribers() {
        if (isDebugging()) {
            System.out.println("-- locating plugged-in connectionSubscribers"); //$NON-NLS-1$
        }
        IExtensionPoint connPoint = Platform.getExtensionRegistry().getExtensionPoint(ID, CONNECTION_SUBSCRIBER_EP);
        if (connPoint != null) {

            IExtension[] extensions = connPoint.getExtensions();
            if (extensions.length == 0) {
                if (isDebugging()) {
                    System.out.println("-- no connection subscrivers found!"); //$NON-NLS-1$
                }
                return Collections.emptyList();
            }
            List<IConnectionSubscriber> subscribers = new ArrayList<IConnectionSubscriber>();

            // consider 1st extension only
            if (isDebugging()) {
                System.out.println("-- using connectionSubscriber from contribution: " + extensions[0].getUniqueIdentifier()); //$NON-NLS-1$
            }
            for (int exts = 0; exts < extensions.length; exts++) {
                IConfigurationElement[] elements = extensions[exts].getConfigurationElements();
                subscribers.add(new ConnectionSubscriberProxy(elements[0]));

            }
            return subscribers;
        }
        return Collections.emptyList();
    }

    public synchronized DimensionsConnectionDetailsEx[] getKnownLocations() {
        List<DimensionsConnectionDetailsEx> cList = getKnownLocationsList();
        return cList.toArray(new DimensionsConnectionDetailsEx[cList.size()]);
    }

    /**
     * @return cached connections list
     */
    public List<DimensionsConnectionDetailsEx> getKnownLocationsList() {
        // check for timestamp and call for reconcile if needed ?
        if (locs == null) {
            initConnectionsList();
        }
        return locs;
    }

    /**
     * init new cached connections list
     */
    private void initConnectionsList() {
        locs = new ArrayList<DimensionsConnectionDetailsEx>();
        if (isSettingsConnectionsInitialized()) {
            DmSettings.ConnectionDefinition[] persistedConnections = settings.getConnectionDefinitions();
            for (DmSettings.ConnectionDefinition connectionDefinition : persistedConnections) {
                DimensionsConnectionDetailsEx con = initConnectionDetailsFrom(connectionDefinition);
                locs.add(con);
            }
        }
    }

    /**
     * @return true if settings connections had been initialized
     */
    private boolean isSettingsConnectionsInitialized() {
        if (!settings.isConnectionsInitialized()) {
            settings.initializeConnections();
        }
        if (settings.isConnectionsInitialized()) {
            return true;
        }
        return false;
    }

    /**
     * @return new DimensionsConnectionDetailsEx object from ConnectionDefinition
     */
    private DimensionsConnectionDetailsEx initConnectionDetailsFrom(DmSettings.ConnectionDefinition connectionDefinition) {
        long lastLogin;

        try {
            lastLogin = Long.parseLong(connectionDefinition.getLastLogin());
        } catch (NumberFormatException e) {
            lastLogin = 0L; // default to the epoch
        }

        DimensionsConnectionDetails det = new DimensionsConnectionDetails();
        det.setUsername(connectionDefinition.getUser());
        det.setDbName(connectionDefinition.getDmDb());
        det.setDbConn(connectionDefinition.getDsn());
        det.setServer(connectionDefinition.getHost());

        DimensionsConnectionDetailsEx con = new DimensionsConnectionDetailsEx(det, connectionDefinition.getDefinitionName(),
                connectionDefinition.isAuto(), connectionDefinition.getTypeString(), lastLogin,
                connectionDefinition.getCertificateId(), connectionDefinition.getIsSmartCardLogin(),
                connectionDefinition.getCertificateLabel());
        String uiProfile = settings.getConnectionExtraData(connectionDefinition.getDefinitionName(), UI_PROFILE);
        con.setCurrentUiProfileName(uiProfile);
        String serverLocale = settings.getConnectionExtraData(connectionDefinition.getDefinitionName(), SERVER_LOCALE);
        con.setServerLocaleName(serverLocale);

        String recentCount = settings.getConnectionExtraData(connectionDefinition.getDefinitionName(), UI_RECENT_COUNT);

        if (!StringPath.isNullorEmpty(recentCount)) {
            try {
                int parseInt = Integer.parseInt(recentCount);
                con.setMaxRecentCount(parseInt);
            } catch (NumberFormatException e) {
                log(new Status(IStatus.ERROR, ID, e.toString()));
            }
        }

        String recentExpanded = settings.getConnectionExtraData(connectionDefinition.getDefinitionName(), UI_RECENT_EXPANDED);
        if (!StringPath.isNullorEmpty(recentExpanded)) {
            con.setRecentExpanded(Boolean.parseBoolean(recentExpanded));
        }

        String favouritesExpanded = settings.getConnectionExtraData(connectionDefinition.getDefinitionName(),
                UI_FAVOURITES_EXPANDED);
        if (!StringPath.isNullorEmpty(favouritesExpanded)) {
            con.setFavouritesExpanded(Boolean.parseBoolean(favouritesExpanded));
        }

        return con;
    }

    public DimensionsConnectionDetailsEx[] getKnownConnectedLocations() {
        DimensionsConnectionDetailsEx[] cons = getKnownLocations();
        List<DimensionsConnectionDetailsEx> connected = new ArrayList<DimensionsConnectionDetailsEx>();
        for (int c = 0; c < cons.length; c++) {
            if (cons[c].isSessionOpen()) {
                connected.add(cons[c]);
            }

        }
        return connected.toArray(new DimensionsConnectionDetailsEx[connected.size()]);
    }

    public DimensionsConnectionDetailsEx[] getKnownUnconnectedLocations() {
        DimensionsConnectionDetailsEx[] cons = getKnownLocations();
        List<DimensionsConnectionDetailsEx> unconnected = new ArrayList<DimensionsConnectionDetailsEx>();
        for (int c = 0; c < cons.length; c++) {
            if (!cons[c].isSessionOpen()) {
                unconnected.add(cons[c]);
            }

        }
        return unconnected.toArray(new DimensionsConnectionDetailsEx[unconnected.size()]);
    }

    public DimensionsConnectionDetailsEx getConnection(String name) {
        DimensionsConnectionDetailsEx[] cons = getKnownLocations();
        for (int i = 0; i < cons.length; i++) {
            if (cons[i].getConnName().equals(name)) {
                return cons[i];
            }
        }
        return null;
    }

    public void deleteConnection(DimensionsConnectionDetailsEx con) throws DMException {
        // 1. obtain a lock on external storage
        // 2. check timestamp, reparse and call reconcile() if external storage is newer,
        // no need to reconcile() if connection being deleted is already deleted from ext
        // and it is the only change
        // 2. delete from both Eclipse and external storage if still needed
        // 3. release lock
        // 4. notify listeners
        deleteInternal(con);
        deleteExternal(con);

    }

    public void persistConnectionUiExtraData(DimensionsConnectionDetailsEx con) {
        settings.setConnectionExtraData(con.getConnName(), UI_RECENT_EXPANDED, String.valueOf(con.isRecentExpanded()));
        settings.setConnectionExtraData(con.getConnName(), UI_FAVOURITES_EXPANDED, String.valueOf(con.isFavouritesExpanded()));
    }

    public void updateConnection(DimensionsConnectionDetailsEx con) throws DMException {
        // do we allow connection name changes?
        // 1. update internal
        // 1. obtain a lock on external storage
        // 2. check timestamp, reparse and call reconcile() if external storage is newer
        // 4. release lock
        // 5. notify listeners about updated connection
        DmSettings.ConnectionDefinition settingsDef = new DmSettings.ConnectionDefinition();
        settingsDef.setDefinitionName(con.getConnName());
        settingsDef.setUser(con.getUsername());
        settingsDef.setDmDb(con.getDbName());
        settingsDef.setDsn(con.getDbConn());
        settingsDef.setHost(con.getServer());
        settingsDef.setTypeString(con.getTypeString());
        settingsDef.setAuto(con.isAuto());
        settingsDef.setCertificateId(con.getCertificateId());
        settingsDef.setIsSmartCardLogin(con.getIsSmartCardLogin());
        settingsDef.setCertificateLabel(con.getCertificateLabel());

        // need to handle extra data
        settingsDef.setLastLogin(Long.toString(con.getLastLogin()));
        settings.setConnectionExtraData(con.getConnName(), UI_PROFILE, con.getCurrentUiProfileName());
        settings.setConnectionExtraData(con.getConnName(), SERVER_LOCALE, con.getServerLocaleName());

        // sbm
        settings.setConnectionExtraData(con.getConnName(), SBM_SOAP_URL, con.getSbmSoapUrl());
        settings.setConnectionExtraData(con.getConnName(), SBM_WEB_URL, con.getSbmWebUrl());
        settings.setConnectionExtraData(con.getConnName(), SBM_SOLUTION, con.getSbmSolution());
        settings.setConnectionExtraData(con.getConnName(), SBM_USERNAME, con.getSBMUser());
        settings.setConnectionExtraData(con.getConnName(), SBM_AUTH_MODE, Integer.toString(con.getSBMAuthMode()));
        String sbmDomain = con.getSBMDomain();
        if (sbmDomain != null && sbmDomain.length() == 0) {
            sbmDomain = null;
        }
        settings.setConnectionExtraData(con.getConnName(), SBM_DOMAIN, sbmDomain);

        // recent count
        settings.setConnectionExtraData(con.getConnName(), UI_RECENT_COUNT, Integer.toString(con.getMaxRecentCount()));

        settings.saveConnectionDefinitionInfo(settingsDef);
        notifyListeners(con, null, UPDATED);
    }

    /**
     * @param con
     * @param force
     * @throws DMException
     */
    public void addConnection(DimensionsConnectionDetailsEx con) throws DMException {
        // 1. obtain a lock on external storage
        // 2. check timestamp, reparse and call reconcile() if external storage is newer
        // 3. in case of connection name collision throw exception
        // 4. release lock
        // 5. notify listeners about added connection
        if (locs.contains(con)) {
        }
        // else add it
        try {
            addInternal(con);
            addExternal(con);
        } catch (DMException e) {
        }

    }

    void addInternal(DimensionsConnectionDetailsEx intCon) throws DMException {
        // 1. add entry to internal
        // if exists remove
        if (locs.contains(intCon)) {
            locs.remove(intCon);
        }
        locs.add(intCon);
        // 2. notify listeners
        notifyListeners(intCon, null, ADDED);
    }

    // must hold external storage lock to call this method
    void addExternal(DimensionsConnectionDetailsEx extCon) throws DMException {
        // 1. copy entry to external
        DmSettings.ConnectionDefinition settingsDef = new DmSettings.ConnectionDefinition();
        settingsDef.setDefinitionName(extCon.getConnName());
        settingsDef.setUser(extCon.getUsername());
        settingsDef.setDmDb(extCon.getDbName());
        settingsDef.setDsn(extCon.getDbConn());
        settingsDef.setHost(extCon.getServer());
        settingsDef.setTypeString(extCon.getTypeString());
        settingsDef.setAuto(extCon.isAuto());
        settingsDef.setLastLogin(Long.toString(0L));
        settingsDef.setCertificateId(extCon.getCertificateId());
        settingsDef.setIsSmartCardLogin(extCon.getIsSmartCardLogin());
        settingsDef.setCertificateId(extCon.getCertificateLabel());

        settings.saveConnectionDefinitionInfo(settingsDef);

        // sbm - cannot add extra data before the connection is saved
        if (!Utils.isNullEmpty(extCon.getSbmSoapUrl())) {
            settings.setConnectionExtraData(extCon.getConnName(), SBM_SOAP_URL, extCon.getSbmSoapUrl());
            settings.setConnectionExtraData(extCon.getConnName(), SBM_WEB_URL, extCon.getSbmWebUrl());
            settings.setConnectionExtraData(extCon.getConnName(), SBM_SOLUTION, extCon.getSbmSolution());
            settings.setConnectionExtraData(extCon.getConnName(), SBM_USERNAME, extCon.getSBMUser());
            settings.setConnectionExtraData(extCon.getConnName(), SBM_AUTH_MODE, Integer.toString(extCon.getSBMAuthMode()));
            String sbmDomain = extCon.getSBMDomain();
            if (sbmDomain != null && sbmDomain.length() == 0) {
                sbmDomain = null;
            }
            settings.setConnectionExtraData(extCon.getConnName(), SBM_DOMAIN, sbmDomain);
        }

        settings.setConnectionExtraData(extCon.getConnName(), UI_RECENT_COUNT, Integer.toString(extCon.getMaxRecentCount()));

        settings.saveConnectionDefinitionInfo(settingsDef);
    }

    void deleteInternal(DimensionsConnectionDetailsEx intCon) throws DMException {
        // 1. delete internal entry
        locs.remove(intCon);
        // 2. notify listeners
        notifyListeners(intCon, null, DELETED);
    }

    // delete corresponding entry from the external file
    void deleteExternal(DimensionsConnectionDetailsEx extCon) throws DMException {
        // 1. delete external entry
        if (!settings.deleteConnectionDefinition(extCon.getConnName())) {
        }
    }

    boolean mergeConnections(DimensionsConnectionDetailsEx internal, DimensionsConnectionDetailsEx external) throws DMException {
        if (!isAutoMergeable(internal, external)) {
            return false;
        }
        // do merge and update
        return true;
    }

    boolean isAutoMergeable(DimensionsConnectionDetailsEx internal, DimensionsConnectionDetailsEx external) {
        return false;
    }

    public static void log(IStatus status) {
        plugin.getLog().log(status);
    }
    
    public static IStatus getStatusFromStatusChain(String message, int severity, int code, IStatus status) {
        IStatus result = status;
        Throwable throwable = status.getException();
        IStatus[] childrenStatuses = status.getChildren();
        if ((throwable != null && throwable.getCause() != null) || (childrenStatuses != null && childrenStatuses.length != 0)) {
            result = new MultiStatus(status.getPlugin(), status.getCode(), status.getMessage(), throwable);
            if (throwable != null && throwable.getCause() != null) {
                IStatus statusFromThrowable = getStatusFromExceptionChain(message, severity, code, throwable);
                ((MultiStatus) result).add(statusFromThrowable);
            }
            if (childrenStatuses != null && childrenStatuses.length != 0) {
                for (IStatus childStatus : childrenStatuses) {
                    IStatus modifiedChildStatus = getStatusFromStatusChain(childStatus.getMessage(), childStatus.getSeverity(),
                            childStatus.getCode(), childStatus);
                    ((MultiStatus) result).add(modifiedChildStatus);
                }
            }
        }
        return result;
    }

    public static Status getStatusFromExceptionChain(String message, int severity, int code, Throwable e) {
        Throwable cause = e.getCause();
        if (e == null || (cause == null && !(e instanceof CoreException))) {
            return new Status(severity, DMPlugin.ID, code, message, e);
        }

        MultiStatus result = new MultiStatus(DMPlugin.ID, code, message, e);
        if (cause != null) {
            Status status = getStatusFromExceptionChain(message, severity, code, cause);
            if (status != null) {
                result.add(status);
            }
        }
        if (e instanceof CoreException && ((CoreException) e).getStatus().getException() != cause) {
            IStatus status = getStatusFromStatusChain(message, severity, code, ((CoreException) e).getStatus());
            if (status != null) {
                result.add(status);
            }
        }
        return result;
    }

    /**
     * @return current console, guaranteed not to be <code>null</code>
     */
    public IDMConsoleListener getConsole() {
        if (console == null) {
            console = new NullConsole();
        }
        return console;
    }

    /**
     * Sets the console
     *
     * @param console
     *            new console
     */
    public void setConsole(IDMConsoleListener console) {
        this.console = console;
    }

    public boolean isFilterClosedProjects() {
        return filterClosedProjects;
    }

    public void setFilterClosedProjects(boolean filterClosedProjects) {
        this.filterClosedProjects = filterClosedProjects;
    }

    public boolean isFilterClosedBaselines() {
        return filterClosedBaselines;
    }

    public void setFilterClosedBaselines(boolean filterClosedBaselines) {
        this.filterClosedBaselines = filterClosedBaselines;
    }

    public boolean isSBMDebugEnabled() {
        return Boolean.valueOf(Platform.getDebugOption(DEBUG_SBM)).booleanValue();
    }

    private void initializeLogger() {
        boolean logCmd = Boolean.valueOf(Platform.getDebugOption(LOG_CMD)).booleanValue();
        int logCmdLevel = Utils.parseInt(Platform.getDebugOption(LOG_CMD_LEVEL), 0);
        String logCmdFile = Utils.getString(Platform.getDebugOption(LOG_CMD_FILE)).trim();
        if (logCmdFile.length() == 0) {
            logCmdFile = getDefaultLogFile(DEFAULT_LOG_FILE_CMD);
        }

        boolean logNet = Boolean.valueOf(Platform.getDebugOption(LOG_NET)).booleanValue();
        int logNetLevel = Utils.parseInt(Platform.getDebugOption(LOG_NET_LEVEL), 0);
        String logNetFile = Utils.getString(Platform.getDebugOption(LOG_NET_FILE)).trim();
        if (logNetFile.length() == 0) {
            logNetFile = getDefaultLogFile(DEFAULT_LOG_FILE_NET);
        }

        if (isDebugging()) { // confirm settings to stdout if debugging
            System.out.println("Dimensions Java API logging settings:"); //$NON-NLS-1$
            System.out.println("  log cmd=" + logCmd); //$NON-NLS-1$
            System.out.println("  log cmd level=" + logCmdLevel); //$NON-NLS-1$
            System.out.println("  log cmd file=" + logCmdFile); //$NON-NLS-1$
            System.out.println("  log net=" + logNet); //$NON-NLS-1$
            System.out.println("  log net level=" + logNetLevel); //$NON-NLS-1$
            System.out.println("  log net file=" + logNetFile); //$NON-NLS-1$
        }

        // could not get API to log anything if no parents, make sure they exist here
        if (logCmd) {
            if (!ensureParentExists(logCmdFile)) {
                logParentCreationFailure(logCmdFile);
            }
            createLoggerFor("com.serena.javaapi", logCmdFile, logCmdLevel); //$NON-NLS-1$
        }

        if (logNet) {
            if (!ensureParentExists(logNetFile)) {
                logParentCreationFailure(logNetFile);
            }
            createLoggerFor("com.serena.dmnet", logNetFile, logNetLevel); //$NON-NLS-1$
        }
    }

    private void createLoggerFor(String loggerName, String logFile, int logLevel) {
        ILoggerFactory loggerFactory = LoggerFactory.getILoggerFactory();
        if (loggerFactory instanceof LoggerContext == false) {
            log(new Status(IStatus.WARNING, ID, 0,
                    "Invalid logger factory class. Expected: " + LoggerContext.class + ". Actual: " + loggerFactory, null)); //$NON-NLS-1$
            return;
        }
        LoggerContext lc = (LoggerContext) loggerFactory;

        PatternLayoutEncoder ple = new PatternLayoutEncoder();
        ple.setPattern("%date{MM-dd-yyyy HH:mm:ss.SSS Z} %-5level [%thread] %logger{40}: %msg%n");
        ple.setContext(lc);
        ple.start();

        FileAppender<ILoggingEvent> fileAppender = new FileAppender<ILoggingEvent>();
        fileAppender.setFile(logFile);
        fileAppender.setEncoder(ple);
        fileAppender.setContext(lc);
        fileAppender.setAppend(true);
        fileAppender.start();

        org.slf4j.Logger logger = LoggerFactory.getLogger(loggerName);
        if (logger instanceof Logger == false) {
            log(new Status(IStatus.WARNING, ID, 0, "Invalid logger class. Expected: " + Logger.class + ". Actual: " + logger, //$NON-NLS-1$
                    null));
            return;
        }
        Logger l = (Logger) logger;
        l.addAppender(fileAppender);
        l.setLevel(Level.toLevel(logLevel));
    }

    private String getDefaultLogFile(String filename) {
        return getStateLocation().append(DEFAULT_LOG_DIR).append(filename).toOSString();
    }

    private static boolean ensureParentExists(String path) {
        File file = new File(path);
        File parent = file.getParentFile();
        if (!parent.exists()) {
            return parent.mkdirs();
        }
        return true;
    }

    private static void logParentCreationFailure(String filename) {
        log(new Status(IStatus.WARNING, ID, 0, "Failed to create parent folder for " + filename, null)); //$NON-NLS-1$
    }

}

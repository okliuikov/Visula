/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;

public abstract class FavouriteRecentProjectList extends WorksetList {

    public FavouriteRecentProjectList(DimensionsConnectionDetailsEx con, int type) {
        super(con, type);
        attributeSubscribe(getSubscriberId(), DEFAULT_ATTRIBUTES);
    }

    protected abstract String getSubscriberId();

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        Project workset = (Project) dimensionsObject;
        String ideTag = (String) workset.getAttribute(SystemAttributes.IDE_TAG);

        if (ideTag != null && ideTag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1) {
            return new SccProjectContainerWorkset(workset, getConnectionDetails(), ideTag);
        } else {
            return super.adapt(session, dimensionsObject);
        }
    }

    @Override
    protected boolean accept(DimensionsArObject workset) {
        return true;
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        // FIXME: DEF266809 - find more appropriate list for object as we can lost creation notification
        DimensionsConnectionDetailsEx details = session.getConnectionDetails();
        WorksetList list = WorksetList.getOtherProjectsList(session.getConnectionDetails(), details.isOnlyStreamsActive(),
                details.isOnlyProjectsActive());
        return list.doCreateObject(session, objectDetails, monitor);
    }

}

package com.serena.eclipse.dimensions.core;

import java.util.HashMap;
import java.util.List;

class ConnectionListsHashMap<K extends DimensionsConnectionDetailsEx, V extends List<DimensionsObjectList>> extends HashMap<K, V> {

    private static final long serialVersionUID = -5290963472129296686L;

    @Override
    public V get(Object object) {
        for (K key : super.keySet()) {
            if (key.equals(object) && key == object) {
                return super.get(object);
            } else if (key.equals(object) && key != object) {
                super.remove(key);
                return null;
            }
        }
        return null;
    }

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import com.serena.dmclient.api.DimensionsArObject;

/**
 * Common superclass for object management object adapters.
 * @author V.Grishchenko
 */
public abstract class VersionManagementAdapter extends APIObjectAdapter {

    /**
     * @param apiObject
     * @param connection
     */
    public VersionManagementAdapter(DimensionsArObject apiObject, DimensionsConnectionDetailsEx connection) {
        super(apiObject, connection);
    }

}

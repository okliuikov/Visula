/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.Serializable;

import com.serena.eclipse.dimensions.core.IDimensionsServiceResource;

public interface ISBMObject extends IDimensionsServiceResource, Serializable {
    /** type constant for connection */
    int CONNECTION = 0x0001;
    /** type constant for folder */
    int FOLDER = 0x0002;
    /** type constant for report */
    int REPORT = 0x0004;
    /** type constant for item */
    int ITEM = 0x0008;
    /** type constant for active items container */
    int ACTIVE_ITEMS = 0x0010;
    /** type constant for associations container */
    int ASSOCIATIONS = 0x0020;

    /**
     * @return object type
     */
    int getType();

    /**
     * @return corresponding connection
     */
    ISBMConnection getConnection();

    /**
     * @return a URL identifying this object
     */
    String getUrl();

    /**
     * @return a URL for opening in a browser, the caller is responsible for
     *         making sure the underlying connection has been authenticated,
     *         otherwise the display url may not contain proper authentication
     *         parameters
     */
    String getDisplayUrl();

    /**
     * @return parent object or <code>null</code> if none
     */
    ISBMContainer getParent();

}

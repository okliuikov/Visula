/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class ReportHandler extends SBMContentHandler {

    private List reports;
    private SBMReport lastReport;
    private boolean inReport;

    /**
     * @param connection
     */
    public ReportHandler(ISBMConnection connection) {
        super(connection);
    }

    @Override
    public void recycle() {
        reports = null;
        lastReport = null;
        inReport = false;
        super.recycle();
    }

    /**
     * Return an ArrayList of TTReport objects parsed from the XML stream. If
     *
     * @return list of TTReport objects parsed from the XML.
     */
    public List getReports() {
        if (reports == null) {
            return Collections.EMPTY_LIST;
        }
        return reports;
    }

    /**
     * This method is called when parsing of an XML element is starting.
     * If the element is a Report, then allocate a new TTReport and add it
     * to an ArrayList of reports.
     *
     * @param namespaceURI
     * @param localName The local name (without prefix), or the empty
     *            string if Namespace processing is not being
     *            performed.
     * @param qName The qualified name (with prefix), or the
     *            empty string if qualified names are not
     *            available.
     * @param attributes The specified or defaulted attributes.
     *
     * @see ContentHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
     */
    @Override
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
        String elementName = getElementName(localName, qName);

        if (elementName.equals(REPORT_TAG)) { // "Report"
            inReport = true;
            lastReport = new SBMReport(connection, null, connection); // reports are members of connection
        } else if (elementName.equals(RETURN_CODE_TAG)) { // "returnCode"
            m_TTReturnCode = atts.getValue(RETURN_CODE_ID_ATTR);
        }

        // Empty the buffer
        if (m_buffer.length() > 0) {
            m_buffer.setLength(0);
        }
    }

    /**
     * This method is called when an parsing of an XML element is ending.
     *
     * @param namespaceURI
     * @param localName
     *            The local name (without prefix), or the empty string if
     *            Namespace processing is not being performed.
     * @param qName
     *            The qualified name (with prefix), or the empty string if
     *            qualified names are not available.
     */
    @Override
    public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
        String elementName = getElementName(localName, qName);

        // If we are currently processing a Report element, then look for
        // child elements that are of interest. For example, we only want to
        // look at "title" if we are inside a Report element, since
        // "Issue_Columns" and "Issue HTML" also contain "title" elements.
        if (inReport) {
            String elementContents = m_buffer.toString();
            if (HTML_TAG.equals(elementName)) {
                lastReport.setUrl(elementContents);
            } else if (TITLE_TAG.equals(elementName)) {
                lastReport.setTitle(elementContents);
            } else if (XML_TAG.equals(elementName)) {
                if (elementContents.length() > 0) {
                    lastReport.setXmlUrl(elementContents);
                }
            } else if (ACCESS_TAG.equals(elementName)) {
                lastReport.setAccess(elementContents);
            } else if (CREATE_DATE_TAG.equals(elementName)) {
                lastReport.setCreateDate(elementContents);
            } else if (AUTHOR_ID_TAG.equals(elementName)) {
                lastReport.setAuthor(elementContents);
            } else if (LAST_MODIFIED_DATE_TAG.equals(elementName)) {
                lastReport.setLastModifiedDate(elementContents);
            } else if (LAST_MODIFIER_TAG.equals(elementName)) {
                lastReport.setLastModifiedUser(elementContents);
            } else if (LAST_EXEC_DATE_TAG.equals(elementName)) {
                lastReport.setLastExecDate(elementContents);
            } else if (REPORT_TYPE_TAG.equals(elementName)) {
                lastReport.setReportType(elementContents);
            }
        }

        // We're finished with the current Report.
        if (elementName.equals(REPORT_TAG)) {
            if (!Utils.isNullEmpty(lastReport.getXMLUrl())) {
                if (reports == null) {
                    reports = new ArrayList();
                }
                reports.add(lastReport);
            }
            lastReport = null;
            inReport = false;
        }

    }

}

/*
 * @DMException.java, created on Apr 13, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Status;

/**
 * @author V.Grishchenko
 */
@SuppressWarnings("serial")
public class DMException extends CoreException {

    private Throwable originalException = null;

    public DMException(IStatus status) {
        super(status);
    }

    public DMException(int severity, int code, String message, Throwable t) {
        super(new Status(severity, DMPlugin.ID, code, message, t));
        this.originalException = t;
    }

    public DMException(String message, Throwable t) {
        this(t instanceof OperationCanceledException ? IStatus.CANCEL : IStatus.ERROR, 0, message, t);
        this.originalException = t;
    }

    protected DMException(CoreException e, String plugin) {
        super(asStatus(e, plugin));
    }

    private static IStatus asStatus(CoreException e, String plugin) {
        IStatus status = e.getStatus();
        return new Status(status.getSeverity(), plugin, status.getCode(), status.getMessage(), e);
    }

    public static DMException asDMException(CoreException ce) {
        return asDMException(ce, DMPlugin.ID);
    }

    public static DMException asDMException(CoreException ce, String plugin) {
        if (ce instanceof DMException) {
            return (DMException) ce;
        }
        return new DMException(ce, plugin);
    }

    public Throwable getOriginalException() {
        return originalException;
    }

}

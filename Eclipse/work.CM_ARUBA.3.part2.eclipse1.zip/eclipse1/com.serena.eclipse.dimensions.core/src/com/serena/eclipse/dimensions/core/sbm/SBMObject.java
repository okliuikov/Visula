/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.Map;

import org.eclipse.core.runtime.PlatformObject;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * @author V.Grishchenko
 */
abstract class SBMObject extends PlatformObject implements ISBMObject {

    private ISBMConnection connection;
    private String url;
    private SBMProperty[] properties;
    private Map propertiesMap; // sbmproperty -> value
    private ISBMContainer parent;

    public SBMObject(ISBMConnection connection, String url, ISBMContainer parent) {
        this.connection = connection;
        if (url != null) {
            setUrl(url);
        }
        this.parent = parent;
    }

    @Override
    public String getServiceId() {
        return DMPlugin.SERVICE_ID;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnectionDetails() {
        return getConnection().getConnectionDetails();
    }

    @Override
    public ISBMConnection getConnection() {
        return connection;
    }

    @Override
    public String getUrl() {
        return url;
    }

    @Override
    public String getDisplayUrl() {
        SBMConnectionDetails details = getConnection().getDetails();
        return url + '&' + SBMHelper.getCredentials(details.getUser(), details.getPassword(), true);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof SBMObject) {
            SBMObject otherObject = (SBMObject) obj;
            return getConnection().equals(otherObject.getConnection())
                    && ((parent == otherObject.parent) || parent != null && parent.equals(otherObject.parent))
                    && getUrl().equals(otherObject.getUrl());
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hc = connection.hashCode();
        if (parent != null) {
            hc ^= parent.hashCode();
        }
        hc ^= getUrl().hashCode();
        return hc;
    }

    @Override
    public ISBMContainer getParent() {
        return parent;
    }

    protected String getAbsoluteURL(String url) {
        if (url.startsWith("tmtrack.dll")) {
            return SBMHelper.getAbsoluteUrl(connection.getDetails().getWebUrl(), url);
        }
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url;
        }
        if (!url.startsWith(connection.getDetails().getWebUrl())) { // combine with relative
            return SBMHelper.getAbsoluteUrl(connection.getDetails().getWebUrl(), url);
        }
        return url;
    }

    void setUrl(String url) {
        this.url = getAbsoluteURL(url);
    }

    public SBMProperty[] getProperties() {
        return properties;
    }

    public String getProperty(SBMProperty id) {
        if (propertiesMap == null) {
            return null;
        }
        // currently SBMproperty implements equals in terms of its display name,
        // if lookup by display name fails attempt to lookup by property id.
        String result = (String) propertiesMap.get(id);
        if (result == null) {
            result = (String) propertiesMap.get(new SBMProperty(id.getId(), id.getUUID(), id.getDisplayName()));
        }
        return result;
    }

    void setProperties(SBMProperty[] properties) {
        this.properties = properties;
    }

    void setPropertyValues(Map map) {
        this.propertiesMap = map;
    }

    Map getPropertyValues() {
        return propertiesMap;
    }

    protected SBMManager getManager() {
        return (SBMManager) getConnection().getSBMManager();
    }

}

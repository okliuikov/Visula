/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
class SBMConnection extends SBMContainer implements ISBMConnection {
    static final long serialVersionUID = -5198675827083927513L;

    private SBMConnectionDetails details;
    private transient ISBMManager manager;
    private transient DimensionsConnectionDetailsEx dmConnection;

    public SBMConnection(SBMConnectionDetails details, DimensionsConnectionDetailsEx dmConnection) {
        super(null, details.getWebUrl(), null);
        this.details = details;
        this.dmConnection = dmConnection;
    }

    @Override
    public int getType() {
        return CONNECTION;
    }

    @Override
    public SBMConnectionDetails getDetails() {
        return details;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnectionDetails() {
        return dmConnection;
    }

    @Override
    public boolean authenticate(boolean allowPrompt, IProgressMonitor monitor) throws SBMException {
        return ((SBMManager) getSBMManager()).authenticate(allowPrompt, monitor);
    }

    @Override
    public boolean isAuthenticated() {
        return ((SBMManager) getSBMManager()).isAuthenticated();
    }

    @Override
    public ISBMConnection getConnection() {
        return this;
    }

    @Override
    public String getDisplayUrl() {
        return SBMHelper.getHomePageUrl(details.getWebUrl(), details.getUser(), details.getPassword());
    }

    @Override
    public List getMembers() {
        try {
            return Collections.singletonList(getSBMManager().getRoot(false, null));
        } catch (SBMException ignore) { // shouldn't happen
        }
        return null;
    }

    @Override
    public void refresh(IProgressMonitor monitor) {
        // Nothing to refresh as member list is fixed
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof SBMConnection) {
            return details.equals(((SBMConnection) obj).details)
                    && dmConnection.getConnName().equals((((SBMConnection) obj).dmConnection.getConnName()));
        }
        return false;
    }

    @Override
    public int hashCode() {
        return details.hashCode() ^ dmConnection.getConnName().hashCode();
    }

    @Override
    public ISBMManager getSBMManager() {
        if (manager == null) {
            this.manager = SBMHelper.getSBMManager(dmConnection);
        }
        return manager;
    }

    @Override
    protected String getMembersUrl() {
        return null;
    }

    @Override
    protected String getAbsoluteURL(String _url) {
        return _url; // connection url is absolute
    }

    @Override
    public String toString() {
        return "[CONNECTION] url=\"" + getUrl() + "\"; username=\"" + details.getUser() + "\"";
    }

    // serialization ---------------

    // called during deserialization
    private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
        String dmcName = stream.readUTF();
        if (dmcName.length() > 0) {
            dmConnection = DMPlugin.getDefault().getConnection(dmcName);
        }
        stream.defaultReadObject();
    }

    // called during serialization
    private void writeObject(ObjectOutputStream stream) throws IOException {
        stream.writeUTF(dmConnection == null ? Utils.EMPTY_STRING : dmConnection.getConnName());
        stream.defaultWriteObject();
    }

    // called during deserialization - replace with a corresponding connection
    private Object readResolve() throws ObjectStreamException {
        if (dmConnection != null) {
            ISBMConnection sbmc = dmConnection.getSBMConnection();
            if (sbmc != null && getUrl().equals(sbmc.getUrl())) {
                return sbmc;
            }
        }
        return this;
    }

}

package com.serena.eclipse.dimensions.core.sbm;

import java.text.DateFormat;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.DMException;

public interface ISBMManager {
    void addListener(ISBMListener listener);

    void removeListener(ISBMListener listener);

    ISBMConnection getConnection();

    ISBMContainer getRoot(boolean refresh, IProgressMonitor monitor) throws SBMException;

    ISBMContainer getActiveRequests() throws DMException;

    void addToActiveRequests(ISBMRequest[] requests) throws DMException;

    void removeFromActiveRequests(ISBMRequest[] requests) throws DMException;

    void associate(AssociateInput input, IProgressMonitor monitor) throws SBMException;

    ISBMAssociations getAssociations(String path) throws SBMException;

    ISBMContainer findCachedParent(int type, String url);

    boolean authenticate(boolean allowPrompt, IProgressMonitor monitor) throws SBMException;

    void setReportsProvider(ISBMReportsProvider reportsProvider);

    ISBMReportsProvider getReportsProvider();

    DateFormat getDateFormatForContainer(ISBMContainer container);

    DateFormat getDateFormatForContainer(ISBMContainer container, boolean refresh);

}

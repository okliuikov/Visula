/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author abollmann
 */
public class SccProjectContainerWorksetList extends WorksetList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = SccProjectContainerWorksetList.class.getName();

    private SccProjectContainer project;

    /**
     * Creates project member list
     *
     * @param con
     * @param includeOnlyStreams
     *            - Include only Streams in the list
     * @param includeOnlyProjects
     *            - Include only Projects in the list
     * @param draft
     */
    public SccProjectContainerWorksetList(DimensionsConnectionDetailsEx con, SccProjectContainer project,
            boolean includeOnlyStreams, boolean includeOnlyProjects) {
        // @formatter:off
        super(con, includeOnlyStreams ? SCC_PROJECT_CONTAINERS_STREAM_MEMBERS :
            includeOnlyProjects ? SCC_PROJECT_CONTAINERS_WORKSET_MEMBERS : SCC_PROJECT_CONTAINERS_MEMBER);
        // @formatter:on
        Assert.isLegal(project != null);
        this.project = project;
        // subscribe for ide tag so can filter ide
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    public SccProjectContainer getProject() {
        return project;
    }

    @Override
    protected List<Project> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);

            final Unit<List<Project>> holder = new Unit<List<Project>>();

            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    Filter wsf = new Filter();
                    wsf.criteria().add(
                            new Filter.Criterion(SystemAttributes.IDE_DM_UID, new Long(project.getIdeUid()),
                                    Filter.Criterion.EQUALS));

                    DimensionsObjectList objectList = project.getObjectList();

                    if (objectList != null && objectList instanceof SccProjectContainerList) {
                        if (((SccProjectContainerList) objectList).isIncludeOnlyProjects()) {
                            wsf.criteria().add(new Filter.Criterion(SystemAttributes.WSET_IS_STREAM, "Y", Filter.Criterion.NOT));
                        } else if (((SccProjectContainerList) objectList).isIncludeOnlyStreams()) {
                            wsf.criteria().add(new Filter.Criterion(SystemAttributes.WSET_IS_STREAM, "Y", Filter.Criterion.EQUALS));
                        }
                    }
                    if (DMPlugin.getDefault().isFilterClosedProjects()) {
                        addNotClosedCriterion(wsf);
                    }
                    holder.setValue(session.getObjectFactory().getProjects(wsf));
                }

            }, pm);
            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        Project workset = (Project) dimensionsObject;
        String ideTag = (String) workset.getAttribute(SystemAttributes.IDE_TAG);
        SccProjectContainerWorkset adapter = new SccProjectContainerWorkset(workset, getConnectionDetails(), ideTag);
        adapter.setParentAdapter(project);
        return adapter;
    }

    @Override
    public String getQualifier() {
        return (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
    }

    @Override
    protected boolean accept(DimensionsArObject workset) {
        // do not accept locked worksets
        return true;
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        return createIdeObject(session, (DimensionsIDEProjectDetails) objectDetails, IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG, null,
                false, new Long(project.getIdeUid()), true, monitor);
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public abstract class TestSBMManager implements ISBMManager {
    private static final int REQUEST_COUNT = 10;
    private static final int REPORT_COUNT = 6;
    private static final int REPOER_REQUEST_COUNT = 5;

    private static final String[] VALID_STATES = { "New", "Assigned", "Closed" };

    private ISBMConnection connection;

    /**
     *
     */
    public TestSBMManager(ISBMConnection connection) {
        this.connection = connection;
    }

    @Override
    public ISBMConnection getConnection() {
        return connection;
    }

    public ISBMReport[] getReports(IProgressMonitor monitor) throws SBMException {
        return null;
    }

    public ISBMRequest[] getRequests(IProgressMonitor monitor) throws SBMException {
        getRoot(monitor);
        return new ISBMRequest[0];
    }

    /*
     * @return repository root, populates it if necessary with synthetic data
     */
    private File getRoot(IProgressMonitor monitor) throws SBMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        URL url = null;// connection.getDetails().getUrl();
        try {
            File root = new File(new URI(url.toString()));
            String error = null;
            if (root.exists()) {
                if (!root.isDirectory()) {
                    error = root.getAbsolutePath() + " exists and it is not a directory";
                }
            } else {
                if (root.mkdirs()) {
                    populate(root, Utils.subMonitorFor(monitor, 10));
                } else {
                    error = root.getAbsolutePath() + " could not be created";
                }
            }
            if (error != null) {
                throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, error, null));
            }
            return root;
        } catch (URISyntaxException e) {
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, "Invalid URI " + url.toString(), e));
        } catch (IOException e) {
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, "Failed to populate the repository at "
                    + url.toString(), e));
        } finally {
            monitor.done();
        }
    }

    private void populate(File root, IProgressMonitor monitor) throws IOException {
        assert root.exists() && root.isDirectory();
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        monitor.subTask("populating repository");

        writeRequests(root, REQUEST_COUNT);

        for (int i = 0; i < REPORT_COUNT; i++) {
            File reportDir = new File(root, "Report_" + i);
            if (reportDir.mkdir()) {
                writeRequests(reportDir, REPOER_REQUEST_COUNT);
            }
        }

    }

    private void writeRequests(File root, int requestCount) throws IOException {
        for (int i = 0; i < requestCount; i++) {
            String id = String.valueOf(i);
            String state = VALID_STATES[i % VALID_STATES.length];
            String title = i + " Title";
            File requestFile = new File(root, "request" + i + ".xml");
            writeRequest(id, state, title, requestFile);
        }
    }

    private void writeRequest(String id, String state, String title, File file) throws IOException {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file)));
        } finally {
            if (writer != null) {
                writer.flush();
                writer.close();
            }
        }

    }

    private void printElement(String element, boolean end, boolean newLine, PrintWriter writer) {
        writer.print('<');
        if (end) {
            writer.print('/');
        }
        writer.print(element);
        writer.print('>');
        if (end || newLine) {
            writer.println();
        }
    }

    private void printIndentation(int level, PrintWriter writer) {
        for (int i = 0; i < level; i++) {
            writer.print(' ');
        }
    }

    @Override
    public void addListener(ISBMListener listener) {

    }

    @Override
    public void addToActiveRequests(ISBMRequest[] requests) {

    }

    @Override
    public ISBMContainer getActiveRequests() {
        return null;
    }

    @Override
    public ISBMContainer getRoot(boolean refresh, IProgressMonitor monitor) throws SBMException {
        return null;
    }

    @Override
    public void removeFromActiveRequests(ISBMRequest[] requests) {

    }

    @Override
    public void removeListener(ISBMListener listener) {

    }

    public void associate(ActionDetails[] files, ISBMRequest[] requests, IProgressMonitor monitor) throws SBMException {

    }

}

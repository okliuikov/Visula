/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

/**
 * Constants for XML tags.
 *
 * @author V.Grishchenko
 */
interface ISBMTags {

    // common
    static final String RETURN_CODE_TAG = "returnCode"; //$NON-NLS-1$
    static final String RETURN_CODE_ID_ATTR = "id"; //$NON-NLS-1$

    // request
    static final String COLUMNS_TAG = "Issue_Columns"; //$NON-NLS-1$
    static final String ISSUE_TAG = "Issue"; //$NON-NLS-1$
    static final String DISPLAY_TAG = "displayid"; //$NON-NLS-1$
    static final String HTML_ATTR = "HTML"; //$NON-NLS-1$

    // associations
    static final String RESULT_TAG = "result";
    static final String ITEM_TAG = "item";
    static final String TAG_TAG = "tag";
    static final String TAG_TYPE_ID_ATTR = "type";
    static final String TAG_VALUE_ID_ATTR = "value";
    static final String RETURN_TAG = "return";
    static final String DESCR_ATTR_NAME = "descr";//$NON-NLS-1$
    static final String LABEL_ATTR_NAME = "label";//$NON-NLS-1$

    // reports
    static final String REPORT_TAG = "Report"; //$NON-NLS-1$
    static final String HTML_TAG = "HTML"; //$NON-NLS-1$
    static final String TITLE_TAG = "title"; //$NON-NLS-1$
    static final String XML_TAG = "XML"; //$NON-NLS-1$
    static final String ACCESS_TAG = "access";
    static final String CREATE_DATE_TAG = "createdate";
    static final String AUTHOR_ID_TAG = "authorid";
    static final String LAST_MODIFIED_DATE_TAG = "lastmodifieddate";
    static final String LAST_MODIFIER_TAG = "lastmodifier";
    static final String LAST_EXEC_DATE_TAG = "lastexecdate";
    static final String REPORT_TYPE_TAG = "Type";

}

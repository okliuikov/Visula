/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Represents an SCC IDE project marker file.
 *
 * @author V.Grishchenko
 */
public class SccProject extends VersionManagementProject {
    private String name;

    /**
     * @param marker
     *            project marker item
     * @param connection
     *            corresponding dimensions connection
     * @param container
     *            <code>SccProjectContainer</code> or <code>SccBaselineContainer</code>
     */
    public SccProject(ItemRevision marker, DimensionsConnectionDetailsEx connection, APIObjectAdapter container) {
        super(marker, connection);
        Assert.isLegal(container instanceof SccProjectContainerWorkset || container instanceof SccBaselineContainer,
                "project or baseline container expected"); //$NON-NLS-1$
        setParentAdapter(container);
    }

    /**
     * @return Returns the marker.
     */
    public ItemRevision getMarker() {
        return getAPIObject();
    }

    /**
     * @return underlying API object
     */
    @Override
    public ItemRevision getAPIObject() {
        return (ItemRevision) super.getAPIObject();
    }

    /**
     * @return a revision adapter for the underlying marker item
     */
    public ItemRevisionAdapter toItemRevisionAdapter() {
        return new ItemRevisionAdapter(getMarker(), getConnectionDetails());
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.ITEM;
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    public APIObjectAdapter getProjectContainer() {
        return getParentAdapter();
    }

    public String getName() {
        if (name == null) {
            String filename = (String) getMarker().getAttribute(SystemAttributes.ITEMFILE_FILENAME);
            int idx = filename.lastIndexOf('.');
            if (idx != -1) {
                name = filename.substring(0, idx);
            } else {
                name = filename;
            }
        }
        return name;
    }

    public String getOffset() {
        return (String) getMarker().getAttribute(SystemAttributes.ITEMFILE_DIR);
    }

    @Override
    public String getProjectSpec() {
        return getProjectContainer().getObjectSpec();
    }

    @Override
    protected boolean isEquivalent(IMappedObjectDetails details) {
        if (((VersionManagementProject) getProjectContainer()).isEquivalent(details)) {
            IPath otherOffset = details.getRemoteOffset();
            return otherOffset.equals(new Path(getOffset()));
        }
        return false;
    }

    @Override
    protected APIObjectAdapter doGetCopy(DimensionsObjectFactory factory) throws Exception {
        // resolve parent object
        DimensionsArObject parent = getAPIObject().getProject();
        if (parent == null) {
            parent = getAPIObject().getBaseline();
            if (parent == null) {
                parent = factory.getGlobalProject();
            }
        }

        // lookup copy
        ItemRevision copy = null;
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, getObjectSpec(), Filter.Criterion.EQUALS));
        parent.flushRelatedObjects(ItemRevision.class, true);
        List rels = parent.getChildItems(filter);
        parent.flushRelatedObjects(ItemRevision.class, true);
        if (rels.size() > 0) {
            copy = (ItemRevision) ((DimensionsRelatedObject) rels.get(0)).getObject();
        }

        // check if found
        if (copy == null) {
            IStatus notFoundStatus = new Status(IStatus.ERROR, DMPlugin.ID, 0, NLS.bind(Messages.sccproject_notfound, getName()),
                    null);
            throw new DMException(notFoundStatus);
        }

        return new SccProject(copy, getConnectionDetails(), getProjectContainer());
    }

}

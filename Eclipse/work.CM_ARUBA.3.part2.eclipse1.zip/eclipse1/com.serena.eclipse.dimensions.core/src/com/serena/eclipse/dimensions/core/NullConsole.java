/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IStatus;

/**
 * No-operations console
 */
class NullConsole implements IDMConsoleListener {

    @Override
    public void operationStarted(String message) {
    }

    @Override
    public void operationCompleted(IStatus status, Exception e) {
    }

    @Override
    public void printMessage(String message) {
    }

    @Override
    public void printError(String error) {
    }

    @Override
    public boolean isOperaionStarted() {
        return false;
    }
}
package com.serena.eclipse.dimensions.core.sbm;

public interface ISBMReport extends ISBMContainer, ISBMPropertySource {

    static final String FIELD_REPORT_TITLE = "Title";
    static final String FIELD_REPORT_AUTHOR = "Author";
    static final String FIELD_REPORT_CREATEDATE = "Created Date";
    static final String FIELD_REPORT_URL = "URL";

    String getXMLUrl();

    String getTitle();

    String getAccess();

    String getCreateDate();

    String getAuthor();

    String getLastModifiedDate();

    String getLastModifiedUser();

    String getLastExecDate();

    String getReportType();

    String getReportUUID();

}

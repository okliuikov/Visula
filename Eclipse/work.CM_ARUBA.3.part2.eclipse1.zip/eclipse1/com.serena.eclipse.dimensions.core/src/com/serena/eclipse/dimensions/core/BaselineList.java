/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.BaselineDetails;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;
import com.serena.eclipse.internal.core.IRemoteQueryAwareTreeElement;

/**
 *
 * @author bstephenson for baselines
 *
 */
public abstract class BaselineList extends DimensionsObjectList implements IRemoteQueryAwareTreeElement {

    public static final int OTHER_BASELINES = 1; // All baselines
    public static final int PROJECT_BASELINES = 2; // baselines of projects
    public static final int GROUP_BASELINES = 3; // baselines of groups
    public static final int GROUP_BASELINE_CONTENTS = 4; // baselines of groups
    public static final int SCC_BASELINE_CONTAINERS = 5; // legacy IDE baseline containers

    // @formatter:off
    protected static final int[] DEFAULT_ATTRIBUTES = new int[] {
        SystemAttributes.OBJECT_ID,
        SystemAttributes.OBJECT_SPEC,
        SystemAttributes.DESCRIPTION,
        SystemAttributes.CREATION_DATE,
        SystemAttributes.IDE_TAG,
        SystemAttributes.IDE_PROJECT_NAME,
        SystemAttributes.IDE_DM_UID,
        SystemAttributes.STATUS};
    // @formatter:on

    private static ISessionListener sessList = new ISessionListener() {

        @Override
        public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
            lists.remove(loc);
        }

        @Override
        public void sessionCreated(DimensionsConnectionDetailsEx loc) {
        }
    };

    // connection -> {project workset , member workset etc}
    private static Map<DimensionsConnectionDetailsEx, List<DimensionsObjectList>> lists = new ConnectionListsHashMap<DimensionsConnectionDetailsEx, List<DimensionsObjectList>>();

    private boolean queryRemote = true;

    public BaselineList(DimensionsConnectionDetailsEx con, int type) {
        super(con, type);
        DimensionsConnectionDetailsEx.addSessionListener(sessList);
    }

    public static BaselineList getOtherBaselinesList(DimensionsConnectionDetailsEx con) {
        BaselineList myList = lookupList(con, OTHER_BASELINES, null);
        if (myList == null) {
            myList = new OtherBaselinesList(con);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    public static BaselineList getIDEProjectBaselinesList(DimensionsConnectionDetailsEx con, DimensionsIDEProject project) {
        BaselineList myList = lookupList(con, PROJECT_BASELINES,
                (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC));
        if (myList == null) {
            myList = new IDEProjectBaselinesList(con, project);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    public static BaselineList getProjectGroupBaselinesList(DimensionsConnectionDetailsEx con, DimensionsIDEProjectGroup group) {
        BaselineList myList = lookupList(con, GROUP_BASELINES,
                (String) group.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC));
        if (myList == null) {
            myList = new ProjectGroupBaselinesList(con, group);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    public static BaselineList getSccBaselineContainerList(SccProjectContainer container) {
        BaselineList containers = lookupList(container.getConnectionDetails(), SCC_BASELINE_CONTAINERS, container.getObjectSpec());
        if (containers == null) {
            containers = new SccBaselineContainerList(container);
            containers.addListener(container.getConnectionDetails().getSearchObjectsStorage());
            registerList(containers);
        }
        return containers;
    }

    /**
     * @return currently known lists for the specified connection
     */
    public static List<DimensionsObjectList> getLists(DimensionsConnectionDetailsEx con) {
        List<DimensionsObjectList> conLists = lists.get(con);
        if (conLists == null) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(conLists);
    }

    private static BaselineList lookupList(DimensionsConnectionDetailsEx con, int listType, String qualifier) {
        List<DimensionsObjectList> conLists = lists.get(con);
        if (conLists == null) {
            return null;
        }

        for (Iterator<DimensionsObjectList> iter = conLists.iterator(); iter.hasNext();) {
            BaselineList aList = (BaselineList) iter.next();
            if (aList.getType() == listType
                    && ((qualifier == aList.getQualifier()) || (qualifier != null && qualifier.equals(aList.getQualifier())))) {
                DimensionsObjectList.replaceEqualConnectionInstances(con, aList);
                return aList;
            }
        }
        return null;
    }

    private static void registerList(BaselineList list) {
        List<DimensionsObjectList> conLists = lists.get(list.getConnectionDetails());
        if (conLists == null) {
            conLists = new ArrayList<DimensionsObjectList>(4);
            lists.put(list.getConnectionDetails(), conLists);
        }
        conLists.add(list);
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.BASELINE;
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        Assert.isLegal(objectDetails instanceof BaselineDetails);
        monitor.beginTask(Messages.objectCreate_task, IProgressMonitor.UNKNOWN);
        monitor.subTask(getTypeScope().getObjectId(objectDetails));
        try {
            // now can create template and revised but can't pass in without changing all doCreateObject
            // infer from details
            // if has part => TEMPLATE
            // if has either Update or Remove Requests and input baseline => REVISED
            // otherwise is TIP
            BaselineDetails det = (BaselineDetails) objectDetails;
            int code = 0;
            if (!Utils.isNullEmpty(det.getOwningPartSpecification())) {
                code = DimensionsObjectFactory.BL_DESIGN_PART;
            } else if ((det.getUpdateRequests() != null || det.getRemoveRequests() != null)
                    && !Utils.isNullEmpty(det.getBasedOnBaseline())) {
                code = DimensionsObjectFactory.BL_REVISED;
            } else {
                code = DimensionsObjectFactory.BL_PROJECT;
            }

            return session.getObjectFactory().createBaseline(det, code);
        } finally {
            monitor.done();
        }
    }

    @Override
    protected String getUniqueId(DimensionsArObject object) {
        // use the object spec now
        return object.getName();
    }

    @Override
    public boolean isQueryRemote() {
        return queryRemote;
    }

    @Override
    public void setQueryRemote(boolean queryRemote) {
        this.queryRemote = queryRemote;
    }

}

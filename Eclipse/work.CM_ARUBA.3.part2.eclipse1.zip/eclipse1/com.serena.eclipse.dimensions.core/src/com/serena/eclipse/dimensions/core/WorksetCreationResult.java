package com.serena.eclipse.dimensions.core;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Project;

// a result that can hold the just created object
class WorksetCreationResult extends DimensionsResult {
    Project workset;

    public WorksetCreationResult(DimensionsResult result, Project workset) {
        super(result.getMessage());
        this.workset = workset;
    }
}
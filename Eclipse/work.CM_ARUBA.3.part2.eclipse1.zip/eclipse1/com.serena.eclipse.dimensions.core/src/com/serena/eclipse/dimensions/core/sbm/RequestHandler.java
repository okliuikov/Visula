/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * @author V.Grishchenko
 */
class RequestHandler extends SBMContentHandler {

    // Constants for the state machine
    private static final int STATE_NORMAL = 0;
    private static final int STATE_READING_COLUMN_HEADINGS = 1;
    private static final int STATE_READING_ISSUE = 2;

    private int m_state = STATE_NORMAL;
    private ArrayList columns;
    private SBMProperty[] properties;
    private Map values = new HashMap();
    private List m_issues = new ArrayList();
    private SBMRequest m_lastIssue;
    private ISBMContainer parent;

    /**
     * Creates a new SAX content handler for reading request information
     * @param connection
     * @param parent
     */
    public RequestHandler(ISBMConnection connection, ISBMContainer parent) {
        super(connection);
        this.parent = parent;
    }

    @Override
    public void recycle() {
        m_state = STATE_NORMAL;
        columns = null;
        properties = null;
        values.clear();
        m_issues.clear();
        m_lastIssue = null;
        super.recycle();
    }

    /**
     * @return list of <code>ISBMRequest</code> objects created from XML contents
     */
    public List getRequests() {
        if (m_issues == null) {
            return Collections.EMPTY_LIST;
        }
        return m_issues;
    }

    @Override
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
        String elementName = getElementName(localName, qName);

        if (elementName.equals(COLUMNS_TAG)) {// "Issue_Columns"
            columns = new ArrayList();
            // m_orderedIssueColumns = new ArrayList();
            m_state = STATE_READING_COLUMN_HEADINGS;
        } else if (elementName.equals(ISSUE_TAG)) { // "Issue"
            m_state = STATE_READING_ISSUE;
            String hostUrl = connection.getDetails().getWebUrl();
            String issueURL = hostUrl.substring(0, hostUrl.length() - 11) + atts.getValue(HTML_ATTR);
            m_lastIssue = new SBMRequest(connection, issueURL, parent);
            m_lastIssue.setProperties(properties);
        } else if (elementName.equals(RETURN_CODE_TAG)) { // "returnCode"
            m_TTReturnCode = atts.getValue(RETURN_CODE_ID_ATTR);
        }

        // Empty the buffer
        if (m_buffer.length() > 0) {
            m_buffer.setLength(0);
        }
    }

    @Override
    public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
        String elementName = getElementName(localName, qName);

        if (elementName.equals(COLUMNS_TAG)) { // "Issue_Columns"
            // We just finished reading all of the column headings and IDs.
            properties = (SBMProperty[]) columns.toArray(new SBMProperty[columns.size()]);
            m_state = STATE_NORMAL;
        } else if (elementName.equals(ISSUE_TAG)) { // "Issue"
            m_state = STATE_NORMAL;
            m_lastIssue.setPropertyValues(values); // add column values to our Issue object.
            m_issues.add(m_lastIssue); // add the completed Issue object to our array.
            values = new HashMap();
        } else if (m_state == STATE_READING_COLUMN_HEADINGS) {
            columns.add(new SBMProperty(elementName, m_buffer.toString())); // record
            // columnId:Heading
            // pair
        } else if (m_state == STATE_READING_ISSUE) {
            SBMProperty property = findProperty(elementName);
            if (property != null) {
                values.put(property, m_buffer.toString()); // got a column value
            }

            // Handle the special sometimes-guaranteed-to-be-there element
            // "displayid". If it's present, in addition to adding it to our
            // column map we also set the special ID field in the Issue.
            if (elementName.equals(DISPLAY_TAG)) {
                m_lastIssue.setID(m_buffer.toString());
            }
        }
    }

    SBMProperty findProperty(String id) {
        for (int i = 0; i < properties.length; i++) {
            if (properties[i].getId().equals(id)) {
                return properties[i];
            }
        }
        return null;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.math.BigInteger;
import java.net.URI;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.serena.dmclient.api.IDMReportRequest;
import merant.adm.exception.AdmObjectException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.IDMReport;
import com.serena.dmclient.api.DimensionsConnection;
import com.serena.dmclient.api.DimensionsConnectionManager;
import com.serena.dmclient.api.IDMRequest;
import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.sbm.ws.clientapi.AEWebservicesFaultFault;
import com.serena.eclipse.sbm.ws.clientapi.Aewebservices71Stub;
import com.serena.eclipse.sbm.ws.clientapi.ClientHelper;
import com.serena.eclipse.sbm.ws.clientapi.xsd.Auth;
import com.serena.eclipse.sbm.ws.clientapi.xsd.DatePreference;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetItems;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetItemsByQuery;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetItemsByQueryResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetItemsByQueryWithName;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetItemsByQueryWithNameResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetItemsResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetSolutions;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetSolutionsResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetSolutionsWithUniqueName;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetSolutionsWithUniqueNameResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetTables;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetTablesResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetUser;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetUserResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetUserWithPreferences;
import com.serena.eclipse.sbm.ws.clientapi.xsd.GetUserWithPreferencesResponse;
import com.serena.eclipse.sbm.ws.clientapi.xsd.NameValue;
import com.serena.eclipse.sbm.ws.clientapi.xsd.SolutionData;
import com.serena.eclipse.sbm.ws.clientapi.xsd.SolutionWithUniqueName;
import com.serena.eclipse.sbm.ws.clientapi.xsd.TTItem;
import com.serena.eclipse.sbm.ws.clientapi.xsd.TableData;
import com.serena.eclipse.sbm.ws.clientapi.xsd.TableType;
import com.serena.eclipse.sbm.ws.clientapi.xsd.TimePreference;
import com.serena.eclipse.sbm.ws.clientapi.xsd.User;
import com.serena.eclipse.sbm.ws.clientapi.xsd.UserWithPreferences;

/**
 * Helper to get pending items using SBM web service call
 *
 * @author S. Korniychuk
 */
public class SBMClientHelper {

    private static final int MAX_REPORTS_LIST_VISIBLE_SIZE = 100;
    private static final int MAX_RUN_REPORT_DATA_VISIBLE_SIZE = 100;

    public static final String TS_SYSFLD_TITLE = "TITLE";

    public static final String TS_SYSFLD_DESC = "DESCRIPTION";

    public static final String TS_SYSFLD_STATE = "STATE";

    public static final String TS_SYSFLD_DT_CREATE = "SUBMITDATE";

    public static final String TS_SYSFLD_DT_LASTMODIFIED = "LASTMODIFIEDDATE";

    public static final String TS_SYSFLD_USER_OWNER = "OWNER";

    public static final String TS_SYSFLD_USER_SUBMITTER = "SUBMITTER";

    public static final String TS_SYSFLD_USER_LASTMODIFIER = "LASTMODIFIER";

    public static final String TS_SYSFLD_BIN_ACTIVEINACTIVE = "ACTIVEINACTIVE";

    public static final String TS_SYSFLD_ID = "ID";
    public static final String TS_SYSFLD_CREATOR = "Creator";
    public static final String TS_SYSFLD_URL = "URL";
    public static final String TS_SYSFLD_STAGE = "Stage";
    public static final String TS_SYSFLD_PROJECT = "Project";

    private static final String STAGE_IN_WORK = "In Work";
    private static final String STAGE_CLOSED = "Closed";

    private static final String SDF_FROM_LOCAL = "DATE-FORMAT-FROM-LOCALE";
    private static final String SDF_MM_DD_YYYY = "DATE-FORMAT-MM-DD-YYYY";
    private static final String SDF_DD_MM_YYYY = "DATE-FORMAT-DD-MM-YYYY";
    private static final String SDF_DD_MM_YYYY_S = "DATE-FORMAT-DD-MM-YYYY.S";
    private static final String SDF_YYYY_MM_DD = "DATE-FORMAT-YYYY-MM-DD";

    public static final DateFormat DF_FROM_LOCAL = new SimpleDateFormat();
    public static final DateFormat DF_MM_DD_YYYY = new SimpleDateFormat("MM/dd/yyyy");
    public static final DateFormat DF_DD_MM_YYYY = new SimpleDateFormat("dd/MM/yyyy");
    public static final DateFormat DF_DD_MM_YYYY_S = new SimpleDateFormat("dd.MM.yyyy");
    public static final DateFormat DF_YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");

    private static final String STF_24H = "TIME-FORMAT-24HOUR";
    private static final String STF_12H = "TIME-FORMAT-12HOUR";

    public static final DateFormat DTF_MM_DD_YYYY_24H = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    public static final DateFormat DTF_MM_DD_YYYY_12H = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
    public static final DateFormat DTF_DD_MM_YYYY_24H = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    public static final DateFormat DTF_DD_MM_YYYY_12H = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
    public static final DateFormat DTF_DD_MM_YYYY_S_24H = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    public static final DateFormat DTF_DD_MM_YYYY_S_12H = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss a");
    public static final DateFormat DTF_YYYY_MM_DD_24H = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final DateFormat DTF_YYYY_MM_DD_12H = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");

    public static final String TS_SYSFLD_ID_CAPTION = "Item Id";
    public static final String TS_SYSFLD_TITLE_CAPTION = "Title";

    public static final SBMProperty PROPERTY_ITEM_ID = new SBMProperty(TS_SYSFLD_ID, TS_SYSFLD_ID_CAPTION);
    public static final SBMProperty PROPERTY_TITLE = new SBMProperty(TS_SYSFLD_TITLE, TS_SYSFLD_TITLE_CAPTION);

    public static final SBMProperty[] DEFAULT_IDM_REQUEST_PROPERTIES = new SBMProperty[] { PROPERTY_ITEM_ID, PROPERTY_TITLE };

    private ISBMConnection connection = null;
    private ClientHelper helper = null;
    private Aewebservices71Stub wsStub = null;
    private Auth wsAuth = null;
    private String currentUserName = null;

    /**
     * @param connection
     */
    public SBMClientHelper(ISBMConnection connection) throws Exception {
        this.connection = connection;
        SBMConnectionDetails conDetails = connection.getDetails();
        currentUserName = conDetails.getUser();
        String url = conDetails.getSoapUrl();
        // url = "http://wh04252/gsoap/gsoap_ssl.dll?aewebservices71";
        helper = new ClientHelper(new URI(url), currentUserName, conDetails.getPassword(), conDetails.getSsoToken());
        wsStub = helper.getStub();
        wsAuth = helper.getAuth();
    }

    public void logout() throws Exception {
        helper.logOut(wsStub, wsAuth);
    }

    public int getUserId(String userName, IProgressMonitor monitor) throws Exception {
        GetUser getUserReq = new GetUser();
        getUserReq.setAuth(wsAuth);
        getUserReq.setUserId(currentUserName);
        GetUserResponse guRes = wsStub.getUser(getUserReq);
        User user = guRes.get_return();
        int user_id = 0;
        if (user != null) {
            user_id = user.getId().intValue();
        }
        return user_id;
    }

    public DateFormat getUserDateFormat() throws RemoteException, AEWebservicesFaultFault {
        GetUserWithPreferences getUserReq = new GetUserWithPreferences();
        getUserReq.setAuth(wsAuth);
        getUserReq.setUserId(currentUserName);
        GetUserWithPreferencesResponse guRes = wsStub.getUserWithPreferences(getUserReq);
        UserWithPreferences user = guRes.get_return();
        DateFormat res = DF_FROM_LOCAL;
        if (user != null) {
            DatePreference dp = user.getDatePreference();
            if (dp != null) {
                String sdf = dp.getValue();
                if (SDF_FROM_LOCAL.equals(sdf)) {
                    res = DF_FROM_LOCAL;
                } else if (SDF_MM_DD_YYYY.equals(sdf)) {
                    res = DF_MM_DD_YYYY;
                } else if (SDF_DD_MM_YYYY.equals(sdf)) {
                    res = DF_DD_MM_YYYY;
                } else if (SDF_DD_MM_YYYY_S.equals(sdf)) {
                    res = DF_DD_MM_YYYY_S;
                } else if (SDF_YYYY_MM_DD.equals(sdf)) {
                    res = DF_YYYY_MM_DD;
                }
            }
        }
        return res;
    }

    public int getSolutionId() throws RemoteException, AEWebservicesFaultFault {
        String solutionName = connection.getDetails().getSolution();
        if (solutionName == null) {
            return 0;
        }
        GetSolutionsWithUniqueName getReq = new GetSolutionsWithUniqueName();
        getReq.setAuth(wsAuth);
        GetSolutionsWithUniqueNameResponse gsRes = wsStub.getSolutionsWithUniqueName(getReq);
        SolutionWithUniqueName[] data = gsRes.get_return();
        if (data != null) {
            for (int i = 0; i < data.length; i++) {
                if (solutionName.equalsIgnoreCase(data[i].getUniqueName())) {
                    return data[i].getSolutionID().intValue();
                }
            }
        }
        return 0;
    }

    public List readPendingRequests(ISBMContainer container, IProgressMonitor monitor) throws Exception {
        ArrayList result = new ArrayList();

        GetUser getUserReq = new GetUser();
        getUserReq.setAuth(wsAuth);
        getUserReq.setUserId(currentUserName);
        GetUserResponse guRes = wsStub.getUser(getUserReq);
        User user = guRes.get_return();
        int user_id = 0;
        if (user != null) {
            user_id = user.getId().intValue();
        }

        // send the request

        GetItemsByQueryWithName getItemsByQuery = new GetItemsByQueryWithName();
        getItemsByQuery.setAuth(wsAuth);
        getItemsByQuery.setTableDBName("TTT_BASE_IDT_WORKFLOW");
        getItemsByQuery.setQueryWhereClause("TS_OWNER = " + user_id + " AND TS_ACTIVEINACTIVE = 0");

        GetItemsByQueryWithNameResponse res = wsStub.getItemsByQueryWithName(getItemsByQuery);
        TTItem[] items = res.get_return();
        if (items != null) {
            SBMProperty[] properties = new SBMProperty[] { new SBMProperty("ID", "Item Id"), new SBMProperty("TITLE", "Title"),
                    new SBMProperty("DESC", "Description") };
            for (int i = 0; i < items.length; i++) {
                TTItem item = items[i];
                SBMRequest ti = new SBMRequest(connection, item.getUrl(), container);
                ti.setID(item.getGenericItem().getItemName());
                ti.setProperties(properties);
                Map values = new HashMap();
                values.put(properties[0], item.getGenericItem().getItemName());
                values.put(properties[1], item.getTitle());
                values.put(properties[2], item.getDescription());
                ti.setPropertyValues(values);
                result.add(ti);
            }
        }
        return result;
    }

    public ISBMReportsResult readReportsInfo(SBMReportFilter filter) throws SBMException {
    	
    	DimensionsConnection con = DimensionsConnectionManager.getConnection(connection.getConnectionDetails());
        
    	Project project = con.getObjectFactory().getCurrentUser().getCurrentProject();
    	
    	List<IDMReport> res = con.getObjectFactory().getIDMReports(project);
    	
        if (res != null) {
        	
        	DateFormat df = DF_FROM_LOCAL;
        	try {
        		return new SBMReportsResult(connection, res, df);
        	}catch (AdmObjectException e) {
        		throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading reading reports info : "
                        + e.getMessage(), e));
        	}
        }
        return null;
    }
    
    
    
    public ISBMTableDataProvider runReport(String reportUUID, ISBMContainer container) throws SBMException {

		List<IDMReportRequest> res = null;
		DimensionsConnection con = DimensionsConnectionManager.getConnection(container.getConnectionDetails());
		
			
		Project project = con.getObjectFactory().getCurrentUser().getCurrentProject();
			
		res = con.getObjectFactory().runIDMReportByName(reportUUID, project);
				
        if (res != null) {
        	return new SBMTableDataProvider(res, connection, container, reportUUID);
        }
        return null;
    }

    public void refreshRequests(List requests, ISBMContainer container) throws SBMException {

        List non_refreshed_requests = refreshFromReports(requests, container);

        if (non_refreshed_requests == null || non_refreshed_requests.size() == 0) {
            return;
        }

        // try to refresh using GetItems web service then
        Map itemsById = new HashMap();
        ArrayList allProperties = new ArrayList();

        GetItems getItems = new GetItems();
        getItems.setAuth(wsAuth);
        for (Iterator iter = non_refreshed_requests.iterator(); iter.hasNext();) {
            Object element = iter.next();
            if (element instanceof ISBMRequest) {
                ISBMRequest req = (ISBMRequest) element;
                String itemId = req.getItemID();
                getItems.addItemIdList(itemId);
                itemsById.put(itemId, element);
                SBMProperty[] properties = req.getProperties();
                for (int k = 0; k < properties.length; k++) {
                    if (!allProperties.contains(properties[k])) {
                        allProperties.add(properties[k]);
                    }
                }
            }
        }

        GetItemsResponse giRes = null;
        DateFormat df = DF_FROM_LOCAL;
        try {
            giRes = wsStub.getItems(getItems);
            df = getUserDateFormat();
        } catch (RemoteException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data : "
                    + e.getMessage(), e));
        } catch (AEWebservicesFaultFault e) {
            String message = null;
            if (e.getFaultMessage() != null) {
                message = e.getFaultMessage().getAEWebservicesFault();
            }
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data"
                    + (message != null ? " : " + message : ""), e));
        }
        if (giRes != null) {
            TTItem[] items = giRes.get_return();
            if (items != null) {
                for (int i = 0; i < items.length; i++) {
                    TTItem item = items[i];
                    String itemId = item.getGenericItem().getItemID();
                    Object obj = itemsById.get(itemId);
                    Map propValues = null;
                    if (obj instanceof SBMRequest) {
                        propValues = ((SBMRequest) obj).getPropertyValues();
                    }
                    if (obj instanceof SBMValueHolder) {
                        propValues = ((SBMValueHolder) obj).getPropertyValues();
                    }
                    if (propValues != null) {
                        for (Iterator iter = allProperties.iterator(); iter.hasNext();) {
                            SBMProperty prop = (SBMProperty) iter.next();
                            String value = readValueFromTTItem(item, prop, df);
                            if (value != null) {
                                propValues.put(prop, value);
                            }
                        }
                    }
                }
            }
        }
    }

    private String readValueFromTTItem(TTItem item, SBMProperty prop, DateFormat df) {
        if (item == null || prop == null) {
            return null;
        }
        String pName = prop.getId();
        String pUUID = prop.getUUID();
        NameValue[] extFields = item.getExtendedFieldList();
        for (int i = 0; i < extFields.length; i++) {
            NameValue value = extFields[i];
            if (pUUID.equals(value.getUuid())) {
                return getValue(value);
            }
        }
        // TODO change name comparision from titles to field names
        if (pName.equalsIgnoreCase(TS_SYSFLD_TITLE)) {
            return item.getTitle();
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_DESC)) {
            return item.getDescription();
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_STATE)) {
            return item.getState();
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_USER_OWNER)) {
            return item.getOwner();
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_USER_SUBMITTER)) {
            return item.getCreatedBy();
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_USER_LASTMODIFIER)) {
            return item.getModifiedBy();
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_BIN_ACTIVEINACTIVE)) {
            return item.getActiveInactive();
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_DT_CREATE)) {
            return df.format(new Date(item.getCreateDate().getTimeInMillis()));
        }
        if (pName.equalsIgnoreCase(TS_SYSFLD_DT_LASTMODIFIED)) {
            return df.format(new Date(item.getModifiedDate().getTimeInMillis()));
        }

        return null;
    }

    private String getValue(NameValue value) {
        if (value == null) {
            return null;
        }
        if (value.getNameValueChoice_type0() != null) {
            if (value.getNameValueChoice_type0().getValue() != null) {
                return value.getNameValueChoice_type0().getValue().getDisplayValue();
            } else {
                if (value.getNameValueChoice_type0().getValues() != null) {
                    StringBuffer sb = new StringBuffer();
                    for (int j = 0; j < value.getNameValueChoice_type0().getValues().length; j++) {
                        if (j != 0) {
                            sb.append(",");
                        }
                        sb.append(value.getNameValueChoice_type0().getValues()[j].getDisplayValue());
                    }
                    return sb.toString();
                }
            }
        }
        return null;
    }

    private List refreshFromReports(List requests, ISBMContainer container) throws SBMException {
        if (requests == null || requests.size() == 0) {
            return requests;
        }
        Map reports_requests = new HashMap();
        for (Iterator iter = requests.iterator(); iter.hasNext();) {
            Object element = iter.next();
            if (element instanceof ISBMRequest) {
                ISBMRequest req = (ISBMRequest) element;
                String sourceUUID = req.getSourceUUID();
                if (sourceUUID != null) {
                    Object obj = reports_requests.get(sourceUUID);
                    List requests_in_report = null;
                    if (obj instanceof List) {
                        requests_in_report = (List) obj;
                    } else {
                        requests_in_report = new ArrayList();
                        reports_requests.put(sourceUUID, requests_in_report);
                    }
                    if (!requests_in_report.contains(req)) {
                        requests_in_report.add(req);
                    }
                }
            }
        }

        List result = new ArrayList();

        for (Iterator iter = reports_requests.entrySet().iterator(); iter.hasNext();) {
            Map.Entry entry = (Map.Entry) iter.next();
            String reportUUID = (String) entry.getKey();
            List requests_in_report = (List) entry.getValue();
            List non_refreshed_requests = requests_in_report;
            try {
                ISBMTableDataProvider dataProvider = runReport(reportUUID, container);
                if (dataProvider != null) {
                    non_refreshed_requests = dataProvider.refreshRequests(requests_in_report);
                }
            } catch (SBMException ex) {
                DMPlugin.log(ex.getStatus());
            }
            if (non_refreshed_requests != null && non_refreshed_requests.size() > 0) {
                for (Iterator iterator = non_refreshed_requests.iterator(); iterator.hasNext();) {
                    Object element = iterator.next();
                    if (!result.contains(element)) {
                        result.add(element);
                    }
                }
            }
        }

        return result;
    }

    public Map queryTitleForIDMRequests(List idmrequests) throws SBMException {

        Map result = new HashMap();

        if (idmrequests == null) {
            return result;
        }
        GetItems getItems = new GetItems();
        getItems.setAuth(wsAuth);
        for (Iterator iter = idmrequests.iterator(); iter.hasNext();) {
            Object element = iter.next();
            if (element instanceof IDMRequest) {
                IDMRequest req = (IDMRequest) element;
                String itemId = req.getID();
                getItems.addItemIdList(itemId);
            }
        }

        GetItemsResponse giRes = null;
        try {
            giRes = wsStub.getItems(getItems);
        } catch (RemoteException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data : "
                    + e.getMessage(), e));
        } catch (AEWebservicesFaultFault e) {
            String message = null;
            if (e.getFaultMessage() != null) {
                message = e.getFaultMessage().getAEWebservicesFault();
            }
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data"
                    + (message != null ? " : " + message : ""), e));
        }
        if (giRes != null) {
            TTItem[] items = giRes.get_return();
            if (items != null) {
                for (int i = 0; i < items.length; i++) {
                    TTItem item = items[i];
                    String itemId = item.getGenericItem().getItemID();
                    String itemName = item.getTitle();
                    result.put(itemId, itemName);
                }
            }
        }
        return result;
    }

    public String readURLForIDMRequests(IDMRequest request) throws SBMException {

        if (request == null) {
            return null;
        }
        GetItems getItems = new GetItems();
        getItems.setAuth(wsAuth);
        getItems.addItemIdList(request.getID());

        GetItemsResponse giRes = null;
        try {
            giRes = wsStub.getItems(getItems);
        } catch (RemoteException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data : "
                    + e.getMessage(), e));
        } catch (AEWebservicesFaultFault e) {
            String message = null;
            if (e.getFaultMessage() != null) {
                message = e.getFaultMessage().getAEWebservicesFault();
            }
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data"
                    + (message != null ? " : " + message : ""), e));
        }
        if (giRes != null) {
            TTItem[] items = giRes.get_return();
            if (items != null && items.length == 1) {
                return items[0].getUrl();
            }
        }
        return null;
    }

    private String getNumericKeyFromId(String id) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < id.length(); i++) {
            if (Character.isDigit(id.charAt(i))) {
                sb.append(id.charAt(i));
            }
        }
        return sb.toString();
    }

    public String readRequestTitleById(String id, IProgressMonitor monitor) throws Exception {
        if (id == null) {
            return null;
        }
        String solutionName = connection.getConnectionDetails().getSbmSolution();
        if (solutionName == null) {
            return null;
        }
        GetSolutions getReq = new GetSolutions();
        getReq.setAuth(wsAuth);
        GetSolutionsResponse solRes = wsStub.getSolutions(getReq);
        SolutionData[] sdata = solRes.get_return();
        if (sdata != null) {
            for (int i = 0; i < sdata.length; i++) {
                SolutionData data = sdata[i];
                if (solutionName.equalsIgnoreCase(data.getName())) {
                    GetTables getTables = new GetTables();
                    getTables.setAuth(wsAuth);
                    getTables.setSolutionID(data.getSolutionID());
                    getTables.setTableType(TableType.value3);
                    GetTablesResponse gtRes = wsStub.getTables(getTables);
                    TableData[] tdata = gtRes.get_return();
                    if (tdata != null && tdata.length == 1) {
                        TableData td = tdata[0];
                        GetItemsByQuery getItemsByQuery = new GetItemsByQuery();
                        getItemsByQuery.setAuth(wsAuth);
                        getItemsByQuery.setTableID(td.getTableID());
                        getItemsByQuery.setQueryWhereClause("TS_ISSUEID='" + getNumericKeyFromId(id) + "'");
                        GetItemsByQueryResponse res = wsStub.getItemsByQuery(getItemsByQuery);
                        TTItem[] items = res.get_return();
                        if (items != null) {
                            for (int j = 0; j < items.length; j++) {
                                TTItem item = items[j];
                                if (id.equals(item.getGenericItem().getItemName())) {
                                    return item.getTitle();
                                }
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    public Map readAttribsForIDMRequest(IDMRequest request, String[] attrs) throws SBMException {
        Map result = new HashMap();

        if (request == null) {
            return null;
        }
        GetItems getItems = new GetItems();
        getItems.setAuth(wsAuth);
        getItems.addItemIdList(request.getID());

        GetItemsResponse giRes = null;
        try {
            giRes = wsStub.getItems(getItems);
        } catch (RemoteException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data : "
                    + e.getMessage(), e));
        } catch (AEWebservicesFaultFault e) {
            String message = null;
            if (e.getFaultMessage() != null) {
                message = e.getFaultMessage().getAEWebservicesFault();
            }
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while reading items data"
                    + (message != null ? " : " + message : ""), e));
        }
        if (giRes != null) {
            TTItem[] items = giRes.get_return();
            if (items != null && items.length == 1) {
                for (int i = 0; i < attrs.length; i++) {

                    if (attrs[i].equals(TS_SYSFLD_ID)) {
                        result.put(TS_SYSFLD_ID, items[0].getGenericItem().getItemName());
                    } else if (attrs[i].equals(TS_SYSFLD_TITLE)) {
                        result.put(TS_SYSFLD_TITLE, items[0].getTitle());
                    } else if (attrs[i].equals(TS_SYSFLD_STATE)) {
                        result.put(TS_SYSFLD_STATE, items[0].getState());
                    } else if (attrs[i].equals(TS_SYSFLD_CREATOR)) {
                        result.put(TS_SYSFLD_CREATOR, items[0].getCreatedBy());
                    } else if (attrs[i].equals(TS_SYSFLD_DESC)) {
                        result.put(TS_SYSFLD_DESC, items[0].getDescription());
                    } else if (attrs[i].equals(TS_SYSFLD_URL)) {
                        result.put(TS_SYSFLD_URL, items[0].getUrl());
                    } else if (attrs[i].equals(TS_SYSFLD_STAGE)) {
                        result.put(TS_SYSFLD_STAGE, items[0].getActiveInactive().equals("true") ? STAGE_IN_WORK : STAGE_CLOSED);
                    } else if (attrs[i].equals(TS_SYSFLD_PROJECT)) {
                        result.put(TS_SYSFLD_PROJECT, items[0].getClassification());
                    }

                }
            }
        }
        return result;
    }

    public DateFormat getUserDateTimeFormat() throws RemoteException, AEWebservicesFaultFault {
        GetUserWithPreferences getUserReq = new GetUserWithPreferences();
        getUserReq.setAuth(wsAuth);
        getUserReq.setUserId(currentUserName);
        GetUserWithPreferencesResponse guRes = wsStub.getUserWithPreferences(getUserReq);
        UserWithPreferences user = guRes.get_return();
        DateFormat res = DF_FROM_LOCAL;
        if (user != null) {
            DatePreference dp = user.getDatePreference();
            if (dp != null) {
                String sdf = dp.getValue();
                if (SDF_FROM_LOCAL.equals(sdf)) {
                    res = DF_FROM_LOCAL;
                } else {
                    TimePreference tp = user.getTimePreference();
                    if (tp != null) {
                        String stf = tp.getValue();
                        if (STF_24H.equals(stf)) {
                            if (SDF_MM_DD_YYYY.equals(sdf)) {
                                res = DTF_MM_DD_YYYY_24H;
                            } else if (SDF_DD_MM_YYYY.equals(sdf)) {
                                res = DTF_DD_MM_YYYY_24H;
                            } else if (SDF_DD_MM_YYYY_S.equals(sdf)) {
                                res = DTF_DD_MM_YYYY_S_24H;
                            } else if (SDF_YYYY_MM_DD.equals(sdf)) {
                                res = DTF_YYYY_MM_DD_24H;
                            }

                        } else if (STF_12H.equals(stf)) {
                            if (SDF_MM_DD_YYYY.equals(sdf)) {
                                res = DTF_MM_DD_YYYY_12H;
                            } else if (SDF_DD_MM_YYYY.equals(sdf)) {
                                res = DTF_DD_MM_YYYY_12H;
                            } else if (SDF_DD_MM_YYYY_S.equals(sdf)) {
                                res = DTF_DD_MM_YYYY_S_12H;
                            } else if (SDF_YYYY_MM_DD.equals(sdf)) {
                                res = DTF_YYYY_MM_DD_12H;
                            }
                        }
                    } else {
                        return getUserDateFormat();
                    }
                }
            }
        }
        return res;
    }

    private final static String MSG_INVALID_UUID = "Invalid UUID specified";

    private String checkInvalidReportErrorMessage(String message, String reportTitle, String reportUUID) {
        if (message == null) {
            return "Encountered error while refreshing reports info";
        }
        if (message.indexOf(MSG_INVALID_UUID) >= 0) {
            if (reportTitle != null && reportTitle.trim().length() > 0) {
                return "Report '" + reportTitle + "' has been removed from server.";
            } else if (reportUUID != null && reportUUID.trim().length() > 0) {
                return "Report has been removed from server. (UUID=" + reportUUID + ")";
            }
            return "Report has been removed from server.";
        }
        return "Encountered error while refreshing reports info : " + message;
    }

    public void refreshReports(ISBMReport[] selectedReports, DateFormat df) throws SBMException, AdmObjectException {

        if (selectedReports == null || selectedReports.length == 0) {
            return;
        }

        if (df == null) {
            df = DF_FROM_LOCAL;
        }

        DimensionsConnection con = DimensionsConnectionManager.getConnection(connection.getConnectionDetails());
        
        for (int i = 0; i < selectedReports.length; i++) {
            if (selectedReports[i] instanceof SBMReport) {
                SBMReport report = (SBMReport) selectedReports[i];
                String reportUUID = report.getReportUUID();
                report.setUrl(reportUUID);
            }
        }
    }

}

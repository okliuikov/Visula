/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.internal.core.IAutoExpandable;

public class RecentProjectsList extends FavouriteRecentProjectList implements IDMConstants, IAutoExpandable {

	private static final String LIST_SUBSCRIBER_ID = RecentProjectsList.class.getName();

    public RecentProjectsList(DimensionsConnectionDetailsEx con, boolean includeOnlyStreams, boolean includeOnlyProjects) {
        super(con, includeOnlyStreams ? RECENT_STREAMS : includeOnlyProjects ? RECENT_PROJECTS : RECENT_PROJECTS_AND_STREAMS);
		this.includeOnlyStreams = includeOnlyStreams;
		this.includeOnlyProjects = includeOnlyProjects;
	}

	@Override
	protected String getSubscriberId() {
		return LIST_SUBSCRIBER_ID;
	}

	@Override
	protected List<Project> doFetch(final Session session, IProgressMonitor pm) throws DMException {
		try {
			pm.beginTask(null, IProgressMonitor.UNKNOWN);
			final Unit<List<Project>> unit = new Unit<List<Project>>();
	        EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
		    final EclipseProjectsFetcher<Project> listsEclipse = listFactory.createEclipseProjectsFetcher();
			session.run(new ISessionRunnable() {

				@Override
				public void run() throws Exception {
					List<Project> recent = listsEclipse.getRecent(session.getConnectionDetails().getMaxRecentCount());
					unit.setValue(recent);
				}
			}, pm);
			return unit.getValue();
		} finally {
			pm.done();
		}
	}

	@Override
	public boolean shouldExpands() {
		DimensionsConnectionDetailsEx connectionDetails = getConnectionDetails();
		return connectionDetails.isRecentExpanded();
	}

	@Override
	public void expanded() {
		DimensionsConnectionDetailsEx connectionDetails = getConnectionDetails();
		connectionDetails.setRecentExpanded(true);
	}

	@Override
	public void collapsed() {
		DimensionsConnectionDetailsEx connectionDetails = getConnectionDetails();
		connectionDetails.setRecentExpanded(false);
	}

}

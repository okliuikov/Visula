/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import com.serena.dmclient.objects.Type;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * <p>
 * Encapsulates basic type information and implements equals() and hashCode() so that it can be used where these methods are
 * necessary.
 *
 * <p>
 * 2 type references are considered to be equal if they reference the same type of the same scope of the same product on one
 * connection.
 *
 * @author V.Grishchenko
 */
public final class TypeReference {
    private DimensionsConnectionDetailsEx connection;
    private String product;
    private DMTypeScope scope;
    private String typeName;
    private Integer hash;
    private Type type;

    /**
     * Creates a new type reference, all parameters must be non-null and not
     * empty.
     *
     * @param connection
     * @param product
     * @param scope
     * @param typeName
     */
    public TypeReference(DimensionsConnectionDetailsEx connection, String product, DMTypeScope scope, String typeName) {

        Assert.isNotNull(connection, "connection"); //$NON-NLS-1$
        Assert.isLegal(!Utils.isNullEmpty(product), "missing product"); //$NON-NLS-1$
        Assert.isNotNull(scope, "scope"); //$NON-NLS-1$
        Assert.isLegal(!Utils.isNullEmpty(typeName), "missing type"); //$NON-NLS-1$

        this.connection = connection;
        this.product = product;
        this.scope = scope;
        this.typeName = typeName;
    }

    /**
     * @return the connection
     */
    public DimensionsConnectionDetailsEx getConnection() {
        return connection;
    }

    /**
     * @return the type scope for this reference
     */
    public DMTypeScope getTypeScope() {
        return scope;
    }

    /**
     * @return the product.
     */
    public String getProduct() {
        return product;
    }

    /**
     * @return the type name.
     */
    public String getTypeName() {
        return typeName;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj.getClass() != TypeReference.class) {
            return false;
        }

        TypeReference otherReference = (TypeReference) obj;

        if (!connection.equals(otherReference.connection)) {
            return false;
        }

        if (!product.equalsIgnoreCase(otherReference.product)) {
            return false;
        }

        if (!scope.equals(otherReference.scope)) {
            return false;
        }

        return typeName.equalsIgnoreCase(otherReference.typeName);
    }

    @Override
    public int hashCode() {
        if (hash == null) {
            int hashCode = connection.hashCode();
            hashCode ^= product.toUpperCase().hashCode();
            hashCode ^= scope.hashCode();
            hashCode ^= typeName.toUpperCase().hashCode();
            hash = new Integer(hashCode);
        }
        return hash.intValue();
    }

    /**
     * @return value suitable for debugging purposes only
     */
    @Override
    public String toString() {
        return connection.getConnName() + '/' + product + '/' + scope.toString() + '/' + typeName;
    }

    /**
     * @return the corresponding API type
     * @throws DMException
     */
    public Type getType() throws DMException {
        if (type == null) {
            type = connection.getType(scope, product, typeName);
        }
        return type;
    }

}

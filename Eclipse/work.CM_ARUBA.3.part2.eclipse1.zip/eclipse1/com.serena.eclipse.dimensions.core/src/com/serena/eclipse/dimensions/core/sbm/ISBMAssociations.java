/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

/**
 * @author V.Grishchenko
 */
public interface ISBMAssociations extends ISBMContainer {
    // property ids for the member request, they are said to be fixed and don't change

    /** property id for the string containing sbm item id and title */
    String ID_AND_TITLE = "f2"; //$NON-NLS-1$
    /** property id for the filename string */
    String FILENAME = "f4"; //$NON-NLS-1$
    /** property id for initiating revision */
    String INITIATING_REVISION = "f9"; //$NON-NLS-1$
    /** property id for closing revision */
    String CLOSING_REVISION = "f14"; //$NON-NLS-1$
    /** property id for log message (comment) */
    String LOG_MESSAGE = "f17"; //$NON-NLS-1$
    /** property id for the item table name */
    String ITEM_TABLE = "f1"; //$NON-NLS-1$

    String getPath();
}

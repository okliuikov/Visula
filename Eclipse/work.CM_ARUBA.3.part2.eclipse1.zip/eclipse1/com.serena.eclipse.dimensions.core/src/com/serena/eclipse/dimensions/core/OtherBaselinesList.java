/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.dto.Unit;

/**
 * @author V.Grishchenko
 */
class OtherBaselinesList extends BaselineList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = OtherBaselinesList.class.getName();

    Set<Long> ideInitialWorksets = null;

    /**
     * Creates my pending or draft list.
     *
     * @param con
     * @param draft
     */
    public OtherBaselinesList(DimensionsConnectionDetailsEx con) {
        super(con, OTHER_BASELINES);
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List<Baseline> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final Unit<List<Baseline>> holder = new Unit<List<Baseline>>();
            EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
    	    final EclipseProjectsFetcher<Baseline> listsEclipse = listFactory.createEclipseProjectsFetcher();
            final String includeClosedFilter = getIncludeClosedFilter();
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                	
                    List<Baseline> allBls = listsEclipse.getOtherBaselines(session.getConnectionDetails().getMaxRecentCount(),
                            includeClosedFilter);
                    holder.setValue(allBls);
                }

            }, pm);

            getIdeInitalWorksets();
            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject baseline) {
        String ideTag = (String) baseline.getAttribute(SystemAttributes.IDE_TAG);
        if (ideTag == null) {
            return true; // non ide baselines - no ide tag
        }
        // has an ide tag
        // if a project group baseline include if
        // created from workset no longer exists
        if (IDMConstants.ECLIPSE_PROJECT_GROUP_TAG.equals(ideTag)) {
            try {
                final Session session = getConnectionDetails().openSession(null);
                final boolean[] res = new boolean[1];
                final DimensionsArObject baselinef = baseline;

                session.run(new ISessionRunnable() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void run() {
                        Filter filter = new Filter();
                        Filter.Criterion criterion = new Filter.Criterion();
                        criterion.setAttribute(FilterOptions.DERIVED_RELATIONSHIP);
                        criterion.setValue(Boolean.TRUE);
                        criterion.setFlags(0);
                        filter.criteria().add(criterion);

                        baselinef.flushRelatedObjects(Project.class, false);
                        List<DimensionsRelatedObject> basedOnWorksets = baselinef.getParentProjects(filter);
                        baselinef.flushRelatedObjects(Project.class, false);
                        // can only be based on one or the other and only one deriving input
                        if (basedOnWorksets.isEmpty()) {
                            res[0] = true;
                        }
                    }

                }, new NullProgressMonitor());

                return res[0];
            } catch (DMException e) {
                return false;
            }
        } else if (IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG.equals(ideTag) || ideTag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1) {
            // if an eclipse project baseline
            // include if the initial workset does not exist
            // get the uid
            final Long ideUid = (Long) baseline.getAttribute(SystemAttributes.IDE_DM_UID);
            // find initial workset with this uid
            final boolean[] res = new boolean[1];

            if (ideInitialWorksets != null && !ideInitialWorksets.contains(ideUid)) {
                res[0] = true;
            }
            return res[0];
        } else {
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    private void getIdeInitalWorksets() {
        int attributes[] = { SystemAttributes.IDE_DM_UID };

        try {
            final Session session = getConnectionDetails().openSession(null);
            Filter filter = new Filter();
            filter.criteria().add(new Filter.Criterion(SystemAttributes.IDE_INITIAL, "Y", Filter.Criterion.EQUALS)); //$NON-NLS-1$
            List<Project> ws = session.getObjectFactory().getProjects(filter);
            if (!ws.isEmpty()) {
                BulkOperator boper = session.getObjectFactory().getBulkOperator(ws);
                boper.queryAttribute(attributes);

                // Initialize ideInitialWorkset here because other below operation won't throw Exception
                // and we are sure that hashset will be created correct, otherwise it will be null.
                ideInitialWorksets = new HashSet<Long>();

                Iterator<Project> iterator = ws.iterator();
                while (iterator != null && iterator.hasNext()) {
                    Project project = iterator.next();
                    ideInitialWorksets.add((Long) project.getAttribute(SystemAttributes.IDE_DM_UID));
                }
            }
        } catch (DMException e) {
        }
    }
}

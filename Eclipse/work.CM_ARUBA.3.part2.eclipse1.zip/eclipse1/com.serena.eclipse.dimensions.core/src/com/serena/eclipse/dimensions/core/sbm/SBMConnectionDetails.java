/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.Serializable;

import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Details for connecting to an SBM server.
 *
 * @author V.Grishchenko
 */
public class SBMConnectionDetails implements Serializable {
    static final long serialVersionUID = -2486394777452628754L;

    private String soapUrl;
    private String webUrl;
    private String solution;
    private String user;
    transient private String password;
    private String domain;
    private String ssoToken;

    /**
     * @param url
     * @param user
     * @param password
     * @param domain
     */
    public SBMConnectionDetails(String soapUrl, String webUrl, String solution, String user, String password, String domain,
            String ssoToken) {
        Assert.isNotNull(soapUrl);
        this.soapUrl = soapUrl;
        this.webUrl = webUrl;
        this.solution = solution;
        this.user = user;
        this.password = password;
        this.domain = domain;
        this.ssoToken = ssoToken;
    }

    /**
     * @return connect url
     */
    public String getSoapUrl() {
        return soapUrl;
    }

    public String getSolution() {
        return solution;
    }

    public String getWebUrl() {
        return webUrl;
    }

    /**
     * @return username
     */
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return password
     */
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getSsoToken() {
        return ssoToken;
    }

    public void setSsoToken(String ssoToken) {
        this.ssoToken = ssoToken;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof SBMConnectionDetails) {
            SBMConnectionDetails otherDetails = (SBMConnectionDetails) obj;
            return soapUrl.equals(otherDetails.soapUrl) && getNonNullUser().equals(otherDetails.getNonNullUser());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return soapUrl.hashCode() ^ getNonNullUser().hashCode();
    }

    private String getNonNullUser() {
        return user != null ? user : Utils.EMPTY_STRING;
    }

}

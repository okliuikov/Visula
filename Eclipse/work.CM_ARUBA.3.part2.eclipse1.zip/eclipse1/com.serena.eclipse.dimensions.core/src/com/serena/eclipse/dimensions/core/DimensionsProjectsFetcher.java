/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.core;

import java.util.List;

import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.ObjectListsQuery;
import com.serena.dmclient.api.ObjectListsQuery.WorksetType;
import com.serena.dmclient.api.ObjectListsQueryFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;

/**
 * Allows to fetch all projects using separate dimensions connection
 */
class DimensionsProjectsFetcher extends DimensionsObjectFetcher<WorksetAdapter, Project> {

    public static final int[] PROJECT_ATTRIBUTES = WorksetList.DEFAULT_ATTRIBUTES;

    DimensionsProjectsFetcher(DimensionsConnectionDetailsEx details) {
        super(details);
    }

    @Override
    protected List<Project> getObjects() {
        DimensionsObjectFactory factory = connection.getObjectFactory();
        ObjectListsQueryFactory listsQueryFactory = factory.getObjectListsQueryFactory();
        ObjectListsQuery<Project> listsQuery = null;
        if (details.isOnlyStreamsActive()) {
            listsQuery = listsQueryFactory.createProjectListsQuery(WorksetType.STREAMS);
        } else if (details.isOnlyProjectsActive()) {
            listsQuery = listsQueryFactory.createProjectListsQuery(WorksetType.PROJECTS_EXCEPT_GENERIC);
        } else {
            listsQuery = listsQueryFactory.createProjectListsQuery(WorksetType.ALL_EXCEPT_GENERIC);
        }

        return listsQuery.getAll(null);
    }

    @Override
    protected void queryAttributes(List<Project> objects) {
        BulkOperator boper = connection.getObjectFactory().getBulkOperator(objects);
        boper.queryAttribute(PROJECT_ATTRIBUTES);
    }

    @Override
    protected WorksetAdapter adapt(Project object) {
        String ideTag = (String) object.getAttribute(SystemAttributes.IDE_TAG);

        WorksetAdapter adapter = null;
        if (ideTag != null && ideTag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1) {
            adapter = new SccProjectContainerWorkset(object, details, ideTag);
        } else {
            adapter = new WorksetAdapter(object, details);
        }

        return adapter;
    }

}
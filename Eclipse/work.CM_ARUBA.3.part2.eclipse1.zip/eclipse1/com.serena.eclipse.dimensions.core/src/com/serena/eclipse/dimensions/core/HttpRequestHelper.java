package com.serena.eclipse.dimensions.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author kberezovchuk
 *         NOT USED, COULD BE DELETED
 *
 *
 */
public class HttpRequestHelper {
    private String requestBody;
    private String page;

    private static final String USER_AGENT = "Mozilla/4.0"; //$NON-NLS-1$
    private static final String CONTENT_TYPE_URL_ENCODED = "application/x-www-form-urlencoded"; //$NON-NLS-1$

    public static final String HTTP_GET = "GET"; //$NON-NLS-1$
    public static final String HTTP_POST = "POST"; //$NON-NLS-1$

    public HttpRequestHelper(String requestBody, String page) {
        setRequestBody(requestBody);
        setPage(page);
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public InputStream getResponse(String urlStr, String method, IProgressMonitor monitor) throws DMException {
        assert urlStr != null;

        if (page != null) {
            urlStr = urlStr + "?" + page;
        }

        if (HTTP_POST.equals(method)) {
            return getPOSTInputStream(urlStr, requestBody, monitor);
        } else {
            return getGETInputStream(urlStr, requestBody, monitor);
        }

    }

    public String getResponseString(String urlStr, String method, String charsetName, IProgressMonitor monitor) throws DMException,
            IOException {
        InputStream inStream = getResponse(urlStr, method, monitor);
        if (inStream != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8 * 1024];
            int bytesRead;
            while ((bytesRead = inStream.read(buf)) != -1) {
                baos.write(buf, 0, bytesRead);
            }
            byte[] allBytes = baos.toByteArray();
            return new String(allBytes, charsetName);
        }
        return "";
    }

    protected InputStream getGETInputStream(String urlStr, String requestBody, IProgressMonitor monitor) throws DMException {
        // NYI
        return null;
    }

    protected InputStream getPOSTInputStream(String urlStr, String requestBody, IProgressMonitor monitor) throws DMException {
        boolean debug = true;
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(urlStr, IProgressMonitor.UNKNOWN);
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            if (debug) {
                debug("POST " + urlStr + " " + requestBody); //$NON-NLS-1$
            }
            conn = openHttpConnection(url, HTTP_POST, requestBody, null);
            int respCode = conn.getResponseCode();
            if (debug) {
                debug(" Status Code=" + String.valueOf(respCode)); //$NON-NLS-1$
                debug(" Content-Type=" + conn.getContentType()); //$NON-NLS-1$
                debug(" Set-Cookie=" + conn.getHeaderField("Set-Cookie")); //$NON-NLS-1$
            }

            checkUnauthorized(debug, respCode);
            return getResultInputStream(conn.getInputStream(), debug);
        } catch (UnknownHostException e) {
            String msg = "The specified host is unknown (" + e.getLocalizedMessage() + ")";
            throw new DMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } catch (MalformedURLException e) {
            String msg = "The specified URL is not formed correctly (" + e.getLocalizedMessage() + ")";
            throw new DMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } catch (IOException e) {
            String msg = "An I/O error occured while executing the request (" + e.getLocalizedMessage() + ")";
            throw new DMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
            monitor.done();
        }
    }

    private HttpURLConnection openHttpConnection(URL url, String method, String requestBody, String cookie) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        // The default method is GET
        if (method != null) {
            conn.setRequestMethod(method);
        }
        conn.setRequestProperty("User-Agent", USER_AGENT); //$NON-NLS-1$
        conn.setAllowUserInteraction(true);
        conn.setInstanceFollowRedirects(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false); // go "tunnel through"
        if (cookie != null) {
            conn.setRequestProperty("Cookie", cookie);//$NON-NLS-1$
        }
        byte[] requestBytes = null;
        if (requestBody != null) {
            requestBytes = requestBody.getBytes(); // use default charset to get bytes
            conn.setRequestProperty("Content-Type", CONTENT_TYPE_URL_ENCODED); //$NON-NLS-1$
            conn.setRequestProperty("Content-Length", Integer.toString(requestBytes.length)); //$NON-NLS-1$
        }

        conn.connect(); // actual connect

        if (requestBytes != null) {
            OutputStream os = conn.getOutputStream();
            os.write(requestBytes);
            os.flush();
        }

        return conn;
    }

    private InputStream getResultInputStream(InputStream inStream, boolean debug) throws IOException {
        if (debug) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8 * 1024];
            int bytesRead;
            while ((bytesRead = inStream.read(buf)) != -1) {
                baos.write(buf, 0, bytesRead);
            }
            byte[] allBytes = baos.toByteArray();
            debug("response=" + new String(allBytes, "UTF-8")); //$NON-NLS-1$
            return new ByteArrayInputStream(allBytes);
        } else {
            return inStream;
        }
    }

    private void checkUnauthorized(boolean debug, int respCode) throws DMException {
        // Specific handling could be implemented in the future
        if (respCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
            if (debug) {
                debug("unauthorized"); //$NON-NLS-1$
            }
            throw new DMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, "Authentication failed.", null));
        }
    }

    private static void debug(String msg) {
        System.out.println("[HttpRequestHelper] " + msg);
    }

}

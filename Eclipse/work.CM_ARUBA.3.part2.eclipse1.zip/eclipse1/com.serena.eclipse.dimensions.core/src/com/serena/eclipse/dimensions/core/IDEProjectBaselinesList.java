/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public class IDEProjectBaselinesList extends BaselineList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = IDEProjectBaselinesList.class.getName();

    private DimensionsIDEProject project;

    /**
     * Creates project baselines list
     *
     * @param con
     * @param draft
     *
     */
    public IDEProjectBaselinesList(DimensionsConnectionDetailsEx con, DimensionsIDEProject project) {
        super(con, PROJECT_BASELINES);
        Assert.isLegal(project != null);
        this.project = project;
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List<Baseline> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);

            final Unit<List<Baseline>> holder = new Unit<List<Baseline>>();

            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    Filter blf = new Filter();
                    blf.criteria().add(
                            new Filter.Criterion(SystemAttributes.IDE_DM_UID, new Long(project.getIDEUid()),
                                    Filter.Criterion.EQUALS));
                    if (DMPlugin.getDefault().isFilterClosedBaselines()) {
                        addNotClosedCriterion(blf);
                    }
                    holder.setValue(session.getObjectFactory().getBaselines(blf));
                }

            }, pm);

            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject doc) {
        return true;
    }

    @Override
    public String getQualifier() {
        return (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
    }
}

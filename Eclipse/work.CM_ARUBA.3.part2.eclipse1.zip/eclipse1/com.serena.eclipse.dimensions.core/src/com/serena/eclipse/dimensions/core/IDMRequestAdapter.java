/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/
package com.serena.eclipse.dimensions.core;

import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.IDMRequest;

/**
 * Adapter for IDM change documents.
 *
 */
public class IDMRequestAdapter extends APIObjectAdapter implements IDeletable {

    /**
     * Creates a new IDM change document adapter. Simply calls super class
     * constructor with the supplied arguments.
     *
     * @param apiObject
     * @param connectionDetails
     * @see APIObjectAdapter#APIObjectAdapter(DimensionsLcObject, DimensionsConnectionDetailsEx)
     */
    public IDMRequestAdapter(IDMRequest request, DimensionsConnectionDetailsEx loc) {
        super(request, loc);
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    /**
     * @return underlying IDM change document
     */
    public IDMRequest getIDMRequest() {
        return (IDMRequest) getAPIObject();
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.REQUEST;
    }

    @Override
    protected APIObjectAdapter doGetCopy(DimensionsObjectFactory factory) throws Exception {
        return new IDMRequestAdapter((IDMRequest) getAPIObject(), getConnectionDetails());
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

/**
 * SBM item.
 *
 * @author V.Grishchenko
 */
public interface ISBMRequest extends ISBMObject, ISBMPropertySource {

    /**
     * @return the human-readable ID, or <code>null</code> if unavailable
     */
    String getID();

    /**
     * @return system id consisting of table and record identifiers
     */
    String getItemID();

    /**
     * @return <code>true</code> if this request is active, returns false
     *         otherwise
     */
    boolean isActive() throws SBMException;

    /**
     * @return title of this request
     */
    String getTitle();

    /**
     * @return system UUID of source where this request came from
     */
    String getSourceUUID();

}

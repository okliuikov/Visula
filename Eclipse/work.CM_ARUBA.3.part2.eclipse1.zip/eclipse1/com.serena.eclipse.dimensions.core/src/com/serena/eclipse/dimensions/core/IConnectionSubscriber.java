/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;

/**
 * To allow core and team plugins to signal connection removal and determine loaded
 * projects.
 *
 * @author B Stephenson
 */
public interface IConnectionSubscriber {

    /**
     * can return multiple errors/warnings in multi-status, the top-level plugin would first call this method
     * and then show the status messages if any, and would not allow to delete a connection if status is error
     * @param con
     * @return IStatus containing errors
     */
    IStatus validateConnectionDeletion(DimensionsConnectionDetailsEx con);

    /**
     * subscribers are expected to clean any connection state in this method, if exception is raised
     * the connection is not deleted by the top level plugin
     * @param con
     * @throws CoreException
     */
    void preDeleteConnection(DimensionsConnectionDetailsEx con) throws CoreException;

    /**
     * final notification, should not throw exceptions
     * @param con
     */
    void postDeleteConnection(DimensionsConnectionDetailsEx con);

    /**
     * Returns information about mapped objects as a list of <code>IMappedObjectDetails</code> objects. This method does not
     * contact the server.
     *
     * @param con
     *            optional parameter to filter mapped objects by their connection
     * @return list of appropriate <code>IMappedObjectDetails</code>
     * @throws CoreException
     */
    List<? extends IMappedObjectDetails> getMappedObjectDetails(DimensionsConnectionDetailsEx con) throws CoreException;

}

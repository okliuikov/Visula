/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IPath;

import com.serena.dmclient.api.DimensionsLcObject;

/**
 * Proxy for a remote object mapped to a local entity.
 *
 * @author V.Grishchenko
 */
public interface IMappedObjectDetails {

    /**
     * @return object id (spec)
     */
    String getId();

    /**
     * @return type scope of a mapped object
     */
    DMTypeScope getTypeScope();

    /**
     * @return project or baseline ide_uid
     */
    long getMainUid();

    /**
     * @return remote offset
     */
    IPath getRemoteOffset();

    /**
     * @return corresponding connection
     */
    DimensionsConnectionDetailsEx getConnection();

    /**
     * Attempts to construct a proper DM object from this proxy details.
     * @return proper DM object
     * @throws DMException
     */
    DimensionsLcObject getDimensionsObject() throws DMException;

    /**
     * @return mapped local project
     */
    IProject getProject();

}

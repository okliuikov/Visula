/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.List;

/**
 * @author V.Grishchenko
 */
public class ActionDetails {
    public static final String ADD = "Add"; //$NON-NLS-1$
    public static final String CHECKOUT = "Checkout"; //$NON-NLS-1$
    public static final String CHECKIN = "Checkin"; //$NON-NLS-1$
    public static final String UNCHECKOUT = "Uncheckout"; //$NON-NLS-1$
    public static final String ASSOCIATE = "Associate"; //$NON-NLS-1$

    private List itemIds;
    private String action;
    private String path;
    private int assetId;
    private String prevRevision;
    private String newRevision;
    private String comment;

    public ActionDetails() {
    }

    public List/* <SBMItemId> */getItemIds() {
        return itemIds;
    }

    public void setItemIds(List/* <SBMItemId> */itemIds) {
        this.itemIds = itemIds;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getAssetId() {
        return assetId;
    }

    public void setAssetId(int assetId) {
        this.assetId = assetId;
    }

    public String getPrevRevision() {
        return prevRevision;
    }

    public void setPrevRevision(String prevRevision) {
        this.prevRevision = prevRevision;
    }

    public String getNewRevision() {
        return newRevision;
    }

    public void setNewRevision(String newRevision) {
        this.newRevision = newRevision;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

}

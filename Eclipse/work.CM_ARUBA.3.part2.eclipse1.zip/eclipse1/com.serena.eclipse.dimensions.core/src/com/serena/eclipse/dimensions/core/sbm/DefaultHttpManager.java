/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.UnknownHostException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IUserAuthenticator;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Based on java.net.URLConnection
 *
 * @author V.Grishchenko
 */
public class DefaultHttpManager extends HTTPManager {
    private static final int AUTH_MAX_ATTEMPTS_EXCEEDED = 1;
    private static final int AUTH_NO_USER_AUTHENTICATOR = 2;

    // have to use thread locals as authentication is of static nature in java.net
    // private static final ThreadLocal CURRENT_DETAILS = new ThreadLocal();
    private static final ThreadLocal MANAGER = new ThreadLocal();
    private static final ThreadLocal ATTEMPTS = new ThreadLocal();
    private static final ThreadLocal AUTH_STATUS = new ThreadLocal();

    private static final Authenticator AUTHENTICATOR = new Authenticator() {

        @Override
        protected PasswordAuthentication getPasswordAuthentication() {

            int attempt = ATTEMPTS.get() == null ? 0 : ((Integer) ATTEMPTS.get()).intValue();
            attempt++;
            ATTEMPTS.set(new Integer(attempt));

            boolean debug = DMPlugin.getDefault().isSBMDebugEnabled();

            // @formatter:off
            if (debug) {
                System.out.println("[DefaultHttpManager] got auth challenge"
                        + " host=" + getRequestingHost()
                        + " port=" + getRequestingPort()
                        + " protocol=" + getRequestingProtocol()
                        + " prompt=" + getRequestingPrompt()
                        + " scheme=" + getRequestingScheme());
            }
            // @formatter:on

            if (attempt > MAX_LOGIN_ATTEMPTS) {
                AUTH_STATUS.set(new Status(IStatus.ERROR, DMPlugin.ID, AUTH_MAX_ATTEMPTS_EXCEEDED,
                        "Authentication failed. Maximum number of login attempts exceeded.", null));
                return null;
            }

            IUserAuthenticator userAuthenticator = DMPlugin.getDefault().getPluggedInAuthenticator();
            if (userAuthenticator == null) {
                AUTH_STATUS.set(new Status(IStatus.ERROR, DMPlugin.ID, AUTH_NO_USER_AUTHENTICATOR,
                        "Authentication failed. No plugged in user authenticator", null));
                return null;
            }

            PasswordAuthentication result = null;
            ChallengeDetails challenge = createChallengeDetails(getRequestingHost(), getRequestingPort(), ChallengeDetails.UNKNOWN,
                    getRequestingPrompt(), getRequestingScheme(), null, null);
            DefaultHttpManager manager = (DefaultHttpManager) MANAGER.get();
            SBMConnectionDetails details = manager != null ? manager.getConnection().getDetails() : null;

            if (details != null) {

                if (attempt == 1) {
                    // got a HTTP challenge because:
                    // 1. server insists on HTTP authentication
                    // 2. pass-through NTLM didn't work
                    //
                    // If already cached enough data for requesting scheme silently send credentials on 1st challenge
                    boolean ntlm = getRequestingScheme().equalsIgnoreCase("ntlm"); //$NON-NLS-1$
                    if (!Utils.isNullEmpty(details.getUser()) /* && details.getPassword() != null */) {
                        char[] password = details.getPassword() != null ? details.getPassword().toCharArray() : new char[0];
                        if (ntlm) {
                            if (!Utils.isNullEmpty(details.getDomain())) {
                                result = new PasswordAuthentication(details.getDomain() + '\\' + details.getUser(), password);
                            }
                        } else {
                            result = new PasswordAuthentication(details.getUser(), password);
                        }
                    }
                }

                if (result == null) {
                    challenge.username = details.getUser();
                    challenge.domain = details.getDomain();
                }

            } else { // this is unusual - log and continue
                if (debug) {
                    StringWriter buffer = new StringWriter();
                    PrintWriter printer = new PrintWriter(buffer);
                    new Exception().printStackTrace(printer);
                    printer.flush();
                    DMPlugin.log(new Status(IStatus.WARNING, DMPlugin.ID, 0, Messages.getConnectionDetails_warning
                            + buffer.toString(), null));
                }
            }

            if (result == null && !manager.isAuthenticating()) { // prompt if still no luck but not when authenticating
                Status status = null;
                if (attempt > 1) {
                    status = new SBMStatus(SBMStatus.INVALID_USER, null);
                }
                LoginCredentials credentials = userAuthenticator.promptForConnectionDetails(challenge, status);
                if (credentials != null) {
                    result = credentials.toPasswordAuthentication();
                }
            }

            if (result == null) {
                if (manager.isAuthenticating()) {
                    AUTH_STATUS.set(new Status(IStatus.ERROR, DMPlugin.ID, AUTH_MAX_ATTEMPTS_EXCEEDED, "Authentication failed. ",
                            null));
                } else {
                    AUTH_STATUS.set(new Status(IStatus.CANCEL, DMPlugin.ID, IStatus.CANCEL, "Login was cancelled by user", null));
                }
            }

            return result;
        }

    };

    public DefaultHttpManager(DimensionsConnectionDetailsEx connection) {
        super(connection);
    }

    private void initLocals() {
        MANAGER.set(this);
        ATTEMPTS.set(new Integer(0));
        AUTH_STATUS.set(Status.OK_STATUS);
        Authenticator.setDefault(AUTHENTICATOR);
    }

    /*
     * Creates and opens a connection to the specified url using the specified method
     */
    private HttpURLConnection openHttpConnection(URL url, String method, String requestBody, String cookie) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        if (method != null) {
            conn.setRequestMethod(method);
        }
        conn.setRequestProperty("User-Agent", USER_AGENT);//$NON-NLS-1$
        conn.setAllowUserInteraction(true);
        conn.setInstanceFollowRedirects(false);
        conn.setDoInput(true);
        conn.setUseCaches(false);
        if (cookie == null) {
            cookie = getCredentials(false);
        }
        if (cookie != null) {
            conn.setRequestProperty("Cookie", cookie);//$NON-NLS-1$
        }
        byte[] requestBytes = null;
        if (requestBody != null) {
            requestBytes = requestBody.getBytes(); // need UTF-8 ?
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded"); //$NON-NLS-1$
            conn.setRequestProperty("Content-Length", Integer.toString(requestBytes.length)); //$NON-NLS-1$
        }

        conn.connect();

        if (requestBytes != null) {
            OutputStream os = conn.getOutputStream();
            os.write(requestBytes);
            os.flush();
        }

        return conn;
    }

    private static void debug(String msg) {
        System.out.println("[DefaultHttpManager] " + msg);
    }

    /**
     * 1. hit the server with URL/Cookie authentication
     * 2. If that fails attempt basic in the authenticator
     */
    @Override
    protected InputStream getGETInputStream(String urlStr, IProgressMonitor monitor) throws SBMException {
        monitor = Utils.monitorFor(monitor);
        initLocals();
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        monitor.subTask(urlStr);
        HttpURLConnection conn = null;
        try {
            boolean debug = DMPlugin.getDefault().isSBMDebugEnabled();
            URL url = new URL(urlStr);
            if (debug) {
                debug("GET " + urlStr); //$NON-NLS-1$
            }
            // Open a connection to the server. Handle redirection manually.
            // Versions of the JRE prior to 1.4.2 do not handle relative redirects. We
            // don't want to require a particular version, so we just handle redirects ourselves.
            conn = openHttpConnection(url, null, null, null);
            String cookie = null;
            if (conn.getHeaderField("Set-Cookie") != null) {
                cookie = conn.getHeaderField("Set-Cookie");//$NON-NLS-1$
            }
            int numRedirects = 1;
            int respCode = conn.getResponseCode();
            if (debug) {
                debug(" SC=" + String.valueOf(respCode)); //$NON-NLS-1$
            }
            // See if the server wants to redirect, if so grab the new URL we're being redirected to, and open a new connection to
            // it.
            while ((respCode == HttpURLConnection.HTTP_MOVED_PERM) || (respCode == HttpURLConnection.HTTP_MOVED_TEMP)) {
                String newLoc = conn.getHeaderField("Location");
                if (debug) {
                    debug("redirect=" + newLoc);
                }
                URL newUrl = new URL(url, newLoc);
                conn = openHttpConnection(newUrl, null, null, cookie);
                if (conn.getHeaderField("Set-Cookie") != null) {
                    cookie = conn.getHeaderField("Set-Cookie");//$NON-NLS-1$
                }

                // The response code should be 200 ("OK") at this point.
                respCode = conn.getResponseCode();
                if (debug) {
                    debug(" SC=" + String.valueOf(respCode)); //$NON-NLS-1$
                }

                // Be sure we're not in an infinite loop--bail out after five
                // attempts.
                if (numRedirects++ > 5) {
                    throw new IOException("Too many redirects. Illegal URL redirect--stopped after five successive redirects.");
                }
            }

            checkUnauthorized(debug, respCode);

            return getResultInputStream(conn.getInputStream(), debug);
        } catch (UnknownHostException e) {
            // m_lastTTErrorString = "The specified host is unknown " + " (" + e.getLocalizedMessage() + ")";
            String msg = "The specified host is unknown (" + e.getLocalizedMessage() + ")";
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } catch (MalformedURLException e) {
            String msg = "The specified URL is not formed correctly (" + e.getLocalizedMessage() + ")";
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } catch (IOException e) {
            String msg = "An I/O error occured while executing the request (" + e.getLocalizedMessage() + ")";
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
            monitor.done();
        }
    }

    @Override
    protected InputStream getPOSTInputStream(String urlStr, String body, IProgressMonitor monitor) throws SBMException {
        monitor = Utils.monitorFor(monitor);
        initLocals();
        monitor.beginTask(null, IProgressMonitor.UNKNOWN);
        monitor.subTask(urlStr);
        HttpURLConnection conn = null;
        try {
            boolean debug = DMPlugin.getDefault().isSBMDebugEnabled();
            URL url = new URL(urlStr);
            if (debug) {
                debug("POST " + urlStr + " " + body); //$NON-NLS-1$
            }
            conn = openHttpConnection(url, "POST", body, null);
            int respCode = conn.getResponseCode();
            if (debug) {
                debug(" SC=" + String.valueOf(respCode)); //$NON-NLS-1$
            }

            checkUnauthorized(debug, respCode);

            return getResultInputStream(conn.getInputStream(), debug);
        } catch (UnknownHostException e) {
            String msg = "The specified host is unknown (" + e.getLocalizedMessage() + ")";
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } catch (MalformedURLException e) {
            String msg = "The specified URL is not formed correctly (" + e.getLocalizedMessage() + ")";
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } catch (IOException e) {
            String msg = "An I/O error occured while executing the request (" + e.getLocalizedMessage() + ")";
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, msg, e));
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
            monitor.done();
        }
    }

    private InputStream getResultInputStream(InputStream originalStream, boolean debug) throws IOException {
        if (debug) { // print response if debugging
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8 * 1024];
            int bytesRead;
            while ((bytesRead = originalStream.read(buf)) != -1) {
                baos.write(buf, 0, bytesRead);
            }
            byte[] allBytes = baos.toByteArray();
            debug("response=" + new String(allBytes, "UTF-8")); //$NON-NLS-1$
            return new ByteArrayInputStream(allBytes);
        }
        return asTempFileStream(originalStream);
    }

    private void checkUnauthorized(boolean debug, int respCode) throws SBMException {
        if (respCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
            if (debug) {
                debug("unauthorized"); //$NON-NLS-1$
            }
            getConnection().getDetails().setPassword(null); // auth failed - clear password
            String msg = AUTH_STATUS.get() == null ? "Authentication failed." : ((IStatus) AUTH_STATUS.get()).getMessage();
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, SBMStatus.INVALID_USER, msg, null));
        }
    }

}

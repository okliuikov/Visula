/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.QualifiedName;

/**
 * A collections of various Dimensions constants.
 *
 * @author V.Grishchenko
 */
public interface IDMConstants {
    /* phases */
    String REJECTED_PHASE = "REJECTED"; //$NON-NLS-1$
    String OFFNORM_PHASE = "OFF NORM"; //$NON-NLS-1$
    String HELD_PHASE = "HELD"; //$NON-NLS-1$
    String CREATE_PHASE = "CREATE"; //$NON-NLS-1$
    String ANALYSIS_PHASE = "ANALYSIS"; //$NON-NLS-1$
    String ANWORK_PHASE = "AN+WORK"; //$NON-NLS-1$
    String WORK_PHASE = "WORK"; //$NON-NLS-1$
    String FROZEN_PHASE = "FROZEN"; //$NON-NLS-1$
    String CLOSED_PHASE = "CLOSED"; //$NON-NLS-1$

    /** Template product name */
    String TEMPLATE_PRODUCT = "$GENERIC"; //$NON-NLS-1$
    /** Global workset spec */
    String GLOBAL_WORKSET = TEMPLATE_PRODUCT + ":$GLOBAL"; //$NON-NLS-1$

    /** Primary capability for delegation */
    String PRIMARY_CAPABILITY = "P"; //$NON-NLS-1$
    /** Secondary capability for delegation */
    String SECONDARY_CAPABILITY = "S"; //$NON-NLS-1$
    /** Leader capability for delegation */
    String LEADER_CAPABILITY = "L"; //$NON-NLS-1$

    String FULL_PRIMARY_CAPABILITY = "Primary"; //$NON-NLS-1$
    String FULL_SECONDARY_CAPABILITY = "Secondary"; //$NON-NLS-1$
    String FULL_LEADER_CAPABILITY = "Leader"; //$NON-NLS-1$

    /** all attributes in attribute editing */
    String ROLE_SECTION_ALL = "$ALL"; //$NON-NLS-1$
    /** all attributes in non-default role section */
    String ROLE_SECTION_ALL_SECTIONS = "$ALL_ROLE_SECTIONS"; //$NON-NLS-1$
    /** Phase name for workset locking */
    String LOCKED_YES = "Yes"; //$NON-NLS-1$
    String LOCKED_NO = "No"; //$NON-NLS-1$

    /** int representation of object types */
    int BASELINE = 0;
    int CHANGEDOCUMENT = 1;
    int ITEM = 2;
    int PART = 3;
    int PRODUCT = 4;
    int PROJECT = 5;

    /** eclipse single project identifier */
    String ECLIPSE_SINGLE_PROJECT_TAG = "$ecl3"; //$NON-NLS-1$
    /** eclipse project group identifier */
    String ECLIPSE_PROJECT_GROUP_TAG = "$ecl3p"; //$NON-NLS-1$
    /** eclipse project container identifier */
    String SCC_ECLIPSE_PROJECT_CONTAINER_TAG = ";ecl;"; //$NON-NLS-1$
    String SCC_ECLIPSE_PROJECT_CONTAINER_TAG_MASK = "%" + SCC_ECLIPSE_PROJECT_CONTAINER_TAG + "%"; //$NON-NLS-1$ //$NON-NLS-2$
    /** marker file extension for projects inside project container */
    String SCC_ECLIPSE_PROJECT_MARKER = "ecl"; //$NON-NLS-1$
    /** pattern to match marker files for contained eclipse projects (%.ecl) */
    String SCC_ECLIPSE_PROJECT_MARKER_MASK = "%." + SCC_ECLIPSE_PROJECT_MARKER; //$NON-NLS-1$

    /** DuRules Prefix */
    String DURULES_PREFIX = "$$"; //$NON-NLS-1$
    /** upload rules id for single eclipse projects */
    String DURULES_ID = DURULES_PREFIX + ECLIPSE_SINGLE_PROJECT_TAG;
    /** upload rules id for eclipse project container */
    String SCC_DURULES_ID = DURULES_PREFIX + SCC_ECLIPSE_PROJECT_MARKER;
    /** upload rules id for eclipse project group */
    String DURULES_GROUP_ID = DURULES_PREFIX + ECLIPSE_PROJECT_GROUP_TAG;

    QualifiedName ACTIVE_REQUEST = new QualifiedName("defreq", "active_request"); //$NON-NLS-1$//$NON-NLS-2$

    /** namespace project pattern */
    String NAMESPACE_PROJECT_PATTERN = "%:NS-%"; //$NON-NLS-1$
    /** type named PROJECT, typically used for designation of SCC project files */
    String TYPE_PROJECT = "PROJECT"; //$NON-NLS-1$

    /** dd-MMM-yyyy HH:mm:ss */
    String DEFAULT_DATETIME_PATTERN = "dd-MMM-yyyy HH:mm:ss"; //$NON-NLS-1$
    /** dd-MMM-yyyy */
    String DEFAULT_DATE_PATTERN = "dd-MMM-yyyy"; //$NON-NLS-1$

    /** respect rules set on item-types */
    char PROJECT_CM_RULES_DEFAULT = 'X';
    /** always require requests */
    char PROJECT_CM_RULES_ON = 'Y';
    /** never require requests */
    char PROJECT_CM_RULES_OFF = 'N';

    long INVALID_UID = -1L;

    String TEMPLATE_MECHANISM = "Normal"; //$NON-NLS-1$

    // project types
    String WORKSET_TYPE_NAME = "WORKSET";
    String STREAM_TYPE_NAME = "STREAM";
    String PERSONAL_TYPE_NAME = "PERSONAL";
    String BASELINE_TYPE_NAME = "BASELINE";
    String TOPIC_TYPE_NAME = "TOPIC";
    
    // user privilege levels
    String USER_PRIVILEGE_DORMANT = "-1";
    String USER_PRIVILEGE_ACTIVE = "0";
    String USER_PRIVILEGE_AUTOREGISTERED = "1";
    

}

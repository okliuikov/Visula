/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import com.serena.dmclient.api.ProjectDetails;

/**
 * Adds necessary elements to represent an IDE project workset.
 *
 * @author V.Grishchenko
 */
public class DimensionsIDEProjectDetails extends ProjectDetails {
    private String project;
    private String part;
    private boolean initial;

    public DimensionsIDEProjectDetails(String product, String name, String description) {
        super(product, name, description);
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getPart() {
        return part;
    }

    public void setPart(String part) {
        this.part = part;
    }

    public boolean isInitial() {
        return initial;
    }

    public void setInitial(boolean value) {
        this.initial = value;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.internal.core.IRemoteQueryAwareTreeElement;

/**
 * A project(workset) that contains SCC project marker files.
 *
 * @author abollmann
 */
public class SccProjectContainerWorkset extends WorksetAdapter implements IWithAPIMembers, IRemoteQueryAwareTreeElement {

    private String ide;
    private boolean queryRemote = true;

    /**
     * @param container
     *            adaptee with marker files
     * @param connection
     *            corresponding connection
     */
    public SccProjectContainerWorkset(Project container, DimensionsConnectionDetailsEx connection) {
        super(container, connection);
    }

    public SccProjectContainerWorkset(Project container, DimensionsConnectionDetailsEx connection, String ide) {
        super(container, connection);
        this.ide = ide;
    }

    public SccProjectContainerWorkset(WorksetAdapter worksetAdapter) {
        super(worksetAdapter.getWorkset(), worksetAdapter.getConnectionDetails());
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    public SccProjectList getMemberList() {
        return SccProjectList.getProjectList(this);
    }

    public String getIde() {
        return ide;
    }

    public String getIdeUid() {
        Long uid = (Long) getAPIObject().getAttribute(SystemAttributes.IDE_DM_UID);
        return uid.toString();
    }

    @Override
    public APIObjectAdapter[] getMembers(final IProgressMonitor monitor) {
        DimensionsConnectionDetailsEx loc = getConnectionDetails();
        final SccProjectContainerWorkset sccWs = this;
        final APIObjectAdapter[][] remoteProjects = new APIObjectAdapter[1][];
        try {
            final Session session = loc.openSession(monitor);

            session.run(new ISessionRunnable() {
                @Override
                public void run() throws DMException {
                    sccWs.getMemberList().fetch(monitor);
                    remoteProjects[0] = sccWs.getMemberList().getObjects();
                }
            }, monitor);
        } catch (DMException e1) {
            DMPlugin.log(e1.getStatus());
        }
        return remoteProjects[0];
    }

    @Override
    public boolean isQueryRemote() {
        return queryRemote ;
    }

    @Override
    public void setQueryRemote(boolean queryRemote) {
        this.queryRemote = queryRemote;
    }

}

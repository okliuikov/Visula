package com.serena.eclipse.dimensions.core;

public interface IMyConsumer<T> {
    void accept(T arg);
}

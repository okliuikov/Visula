package com.serena.eclipse.dimensions.core;

import java.io.UnsupportedEncodingException;

final class PrivateCredentials {

    public static final int AUTHORIZED = 0;
    public static final int DECRYPTION_STRING_NULL = 1;
    public static final int TIMESTAMP_TOO_OLD = 2;
    public static final int INVALID_TOKEN = 3;
    public static final int BAD_AUTHORIZATION_TYPE = 4;
    public static final int BAD_AUTHORIZATION_ID = 5;

    /** The private keys used to authorize between Dimensions and RTM */
    private static final String FIXED_SALT = "I am RTM";
    private static final byte[] OUTER_KEY = { (byte) 84, (byte) 104, (byte) 111, (byte) 109, (byte) 97, (byte) 115, };

    private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', };

    private PrivateCredentials() {
        /* prevent instantiation */
    }

    // conventionally the parameterized salt is the user ID.
    public static String encryptPassword(String salt, String password) {
        String retVal;
        try {
            retVal = PrivateCredentials.encrypt(salt, password, null);
        } catch (UnsupportedEncodingException uee) {
            retVal = null;
        }
        return retVal;
    }

    public static String decryptPassword(String message) {
        String retVal;
        try {
            StringBuffer password = new StringBuffer();
            int err = PrivateCredentials.decrypt(message, null, -1L, null, password);
            if (err == 0) {
                retVal = password.toString();
            } else {
                retVal = null;
            }
        } catch (UnsupportedEncodingException uee) {
            retVal = null;
        }
        return retVal;
    }

    private static String encrypt(String userID, String password, String encoding, int currentTime)
            throws UnsupportedEncodingException {
        // Append the user ID, password, and fixed salt together.
        String message = userID + ":" + password + ":" + FIXED_SALT;

        // Encrypt the inner block with the timestamp as the key
        byte[] timebytes = intToByteArray(currentTime);
        byte[] encStr = Blowfish.encrypt(encoding != null ? message.getBytes(encoding) : message.getBytes(), timebytes);
        String hexEncStr = PrivateCredentials.encodeHex(encStr);
        message = hexEncStr;

        // Add the timestamp
        byte[] messagePlusTimestamp = new byte[message.getBytes().length + timebytes.length + 1];
        System.arraycopy(timebytes, 0, messagePlusTimestamp, 0, timebytes.length);
        System.arraycopy(message.getBytes(), 0, messagePlusTimestamp, timebytes.length, message.getBytes().length);

        // Now encrypt all the values together
        encStr = Blowfish.encrypt(messagePlusTimestamp, OUTER_KEY);
        hexEncStr = PrivateCredentials.encodeHex(encStr);
        message = hexEncStr;

        return message;
    }

    public static String encrypt(String userID, String password, String encoding) throws UnsupportedEncodingException {
        // Get the current time in seconds since 1970
        int currentTime = (int) (System.currentTimeMillis() / 1000L);
        return encrypt(userID, password, encoding, currentTime);
    }

    /**
     * Decrypt the string, and check access.
     *
     * @param message
     * @param userID
     * @param password
     * @param encoding
     * @param millisTolerance
     * @return
     */
    public static int decrypt(String message, String encoding, long millisTolerance, StringBuffer userID, StringBuffer password)
            throws UnsupportedEncodingException {
        if (message == null || message.length() == 0) {
            return DECRYPTION_STRING_NULL;
        }

        // Decrypt the message into a byte array
        byte[] hexDecStr = PrivateCredentials.decodeHex(message);
        byte[] decStr = Blowfish.decrypt(hexDecStr, OUTER_KEY);

        // Get the inner block and timestamp from the decrypted string
        byte[] timebytes = new byte[4];
        System.arraycopy(decStr, 0, timebytes, 0, 4);
        // Verify the date is within tolerance milliseconds of the current time
        if (millisTolerance >= 0) {
            long messageTime = byteArrayToLong(timebytes) * 1000L;
            long currentTime = System.currentTimeMillis();
            if (Math.abs(currentTime - messageTime) > millisTolerance) {
                return TIMESTAMP_TOO_OLD;
            }
        }

        // note that this string should only contain hex digits
        String authValues = (encoding != null ? new String(decStr, 4, decStr.length - 4, encoding) : new String(decStr, 4,
                decStr.length - 4));
        authValues = trimZeroPadding(authValues);

        // Decrypt the innerblock
        hexDecStr = PrivateCredentials.decodeHex(authValues);
        byte[] bytes = Blowfish.decrypt(hexDecStr, timebytes);
        authValues = (encoding != null ? new String(bytes, encoding) : new String(bytes));
        authValues = trimZeroPadding(authValues);

        // Get the values from the decrypted string
        int firstColon = authValues.indexOf(":");
        if (firstColon == -1) {
            // Can't find username
            return INVALID_TOKEN;
        }

        int lastColon = authValues.lastIndexOf(":");
        if (lastColon == -1 || lastColon == firstColon) {
            // Can't find password
            return INVALID_TOKEN;
        }

        String authFixedSalt = authValues.substring(lastColon + 1);
        // Verify the auth_id
        if (!FIXED_SALT.equals(authFixedSalt)) {
            return BAD_AUTHORIZATION_ID;
        }

        if (userID != null) {
            String authUserID = authValues.substring(0, firstColon);
            userID.append(authUserID);
        }
        if (password != null) {
            String authPassword = authValues.substring(firstColon + 1, lastColon);
            password.append(authPassword);
        }
        return AUTHORIZED;
    }

    private static byte[] intToByteArray(int value) {
        byte[] bytes = new byte[4];
        int len = bytes.length;
        for (int i = 0; i < len; i++) {
            int offset = (len - i - 1) * 8;
            bytes[i] = (byte) ((value >>> offset) & 0xff);
        }
        return bytes;
    }

    private static long byteArrayToLong(byte[] bytes) {
        long value = 0;
        int len = bytes.length;
        for (int i = 0; i < len; i++) {
            value |= (bytes[i] & 0xff);
            if (i < len - 1) {
                value <<= 8;
            }
        }
        return value;
    }

    private static byte[] decodeHex(String s) {
        // this special case seems wrong...
        // null input should give NullPointerException
        if (s == null) {
            return new byte[0];
        }
        byte[] buffer = new byte[s.length() / 2];
        for (int i = 0; i < s.length(); i += 2) {
            int d1 = Integer.parseInt(String.valueOf(s.charAt(i)), 16);
            int d2 = Integer.parseInt(String.valueOf(s.charAt(i + 1)), 16);
            byte by = (byte) (((d1 << 4) & 0xf0) + (d2 & 0x0f));
            buffer[i / 2] = by;
        }
        return buffer;
    }

    private static String encodeHex(byte[] buffer) {
        if (buffer == null || buffer.length == 0) {
            return "";
        }
        StringBuffer sb = new StringBuffer(buffer.length * 2);
        for (int i = 0; i < buffer.length; i++) {
            byte by = buffer[i];
            sb.append(PrivateCredentials.HEX_DIGITS[(by >> 4) & 0x0f]);
            sb.append(PrivateCredentials.HEX_DIGITS[by & 0x0f]);
        }
        return sb.toString();
    }

    private static String trimZeroPadding(String s) {
        if (s == null || s.length() == 0 || s.charAt(s.length() - 1) != 0) {
            return s;
        }
        int lastNonZero = s.length() - 2;
        while (lastNonZero >= 0 && s.charAt(lastNonZero) == 0) {
            --lastNonZero;
        }
        String retVal;
        if (lastNonZero >= 0) {
            retVal = new String(s.toCharArray(), 0, lastNonZero + 1);
        } else {
            retVal = "";
        }
        return retVal;
    }

    // Testing code below this line

    public static void main(String[] args) throws UnsupportedEncodingException {
        byte[] plaintext = "chris:foo:I am RTM".getBytes();
        byte[] crypkey = new byte[] { 0x44, 0x32, (byte) 0xd2, 0x61 };
        byte[] cryptext = Blowfish.encrypt(plaintext, crypkey);
        String test = PrivateCredentials.encodeHex(cryptext);
        if (!"99DE42B728A66B3E17B168596B3DFE3879574B365E2C8A73".equals(test)) {
            System.err.println("test #1 failed");
            System.err.println("bad value is " + test);
        } else {
            System.out.println("test #1 passed");
        }

        StringBuffer userID = new StringBuffer();
        StringBuffer password = new StringBuffer();

        String message = PrivateCredentials.encrypt("UserID", "Password", null);
        int ret = PrivateCredentials.decrypt(message, null, 5000L, userID, password);
        if (!"UserID".equals(userID.toString()) || !"Password".equals(password.toString())) {
            System.err.println("test #2 failed");
            System.err.println("bad values are " + userID.toString() + ":" + password.toString());
            System.err.println("ret = " + ret);
        } else {
            System.out.println("test #2 passed");
            System.out.println("ret = " + ret);
        }

        message = PrivateCredentials.encrypt("UserID", "Password", "Cp1252", 1095379200); // 17-Sep-2004 00:00-ish
        if (!"741CDAA264F9EB34B68F3CD69A22875501D37A441C6A50006E4BD20FD4ED1D248BD61FD6AF22FBE2CC86D952470B2B383E16C8A5205E2377".equals(message)) {
            System.err.println("test #2a failed");
            System.err.println("bad value is " + message);
        } else {
            System.out.println("test #2a passed");
        }

        message = PrivateCredentials.encrypt("chris", "foo", "Cp1252", 1172753664); // 1-Mar-2007 12:54-ish
        if (!"5A0D8D5D9C901844688470C767DEC55E1A47914F878AB3832967E7EF9F4DAE7BC7AD2661F2A286CE5B596DD69C7002B076E11D48B0CD1242".equals(message)) {
            System.err.println("test #2b failed");
            System.err.println("bad value is " + message);
        } else {
            System.out.println("test #2b passed");
        }

        userID.setLength(0);
        password.setLength(0);

        // this is "chris:foo:I am RTM" at some long distant time
        String cs_test_2 = "05DFCE013EC7EBC86BE042DC70280B481611DE88F2AD9812AB8886934C632F5BAEAC58CA1F94A2FE75232B17FB113D78E11430EFE793DE39";
        ret = PrivateCredentials.decrypt(cs_test_2, null, 1000L, userID, password);
        if (ret != 2 || userID.length() != 0 || password.length() != 0) {
            System.err.println("test #3 failed");
            System.err.println("bad values are " + userID.toString() + ":" + password.toString());
            System.err.println("ret = " + ret);
        } else {
            System.out.println("test #3 passed");
            System.out.println("ret = " + ret);
        }

        userID.setLength(0);
        password.setLength(0);

        ret = PrivateCredentials.decrypt(cs_test_2, null, -1L, userID, password);
        if (ret != 0 || userID.length() == 0 || password.length() == 0) {
            System.err.println("test #4 failed");
            System.err.println("bad values are " + userID.toString() + ":" + password.toString());
            System.err.println("ret = " + ret);
        } else {
            System.out.println("test #4 passed");
            System.out.println("ret = " + ret);
        }

        String encpass = PrivateCredentials.encryptPassword("anythingatall", "MyPassword");
        String decpass = PrivateCredentials.decryptPassword(encpass);
        if (!"MyPassword".equals(decpass)) {
            System.err.println("test #5a failed");
            System.err.println("bad value is " + decpass);
        } else {
            System.out.println("test #5a passed");
        }

        encpass = PrivateCredentials.encryptPassword("userID cannot contain a colon but \\ is OK", "");
        decpass = PrivateCredentials.decryptPassword(encpass);
        if (!"".equals(decpass)) {
            System.err.println("test #5b failed");
            System.err.println("bad value is " + decpass);
        } else {
            System.out.println("test #5b passed");
        }

        encpass = PrivateCredentials.encryptPassword("", ":::");
        decpass = PrivateCredentials.decryptPassword(encpass);
        if (!":::".equals(decpass)) {
            System.err.println("test #5c failed");
            System.err.println("bad value is " + decpass);
        } else {
            System.out.println("test #5c passed");
        }

        plaintext = new byte[] { 99, 0, 99, 0, 0 };
        String trimmed = PrivateCredentials.trimZeroPadding(new String(plaintext));
        if (!trimmed.equals("c\u0000c")) {
            System.err.println("test #6 failed");
            System.err.println("bad value is " + trimmed);
        } else {
            System.out.println("test #6 passed");
        }

        // NOW TEST THE encodeHex and decodeHex methods:

        // First, a few null tests to make sure that there are no exceptions (?)
        encodeHex(null).length();
        decodeHex(null);

        // NO I18N - START
        String testString = "This is Chris's test";
        byte[] testBytes = testString.getBytes();
        String hexString = encodeHex(testBytes);
        if (hexString.length() != testBytes.length * 2) {
            System.err.println("hex test #1 failed");
            System.err.println("bad value is " + hexString);
        } else {
            System.out.println("hex test #1 succeeded");
        }
        byte[] unhexBytes = decodeHex(hexString);
        if (!java.util.Arrays.equals(testBytes, unhexBytes)) {
            System.err.println("hex test #2 failed");
            System.err.println("bad value is " + unhexBytes);
        } else {
            System.out.println("hex test #2 succeeded");
        }
        String unhexString = new String(unhexBytes);
        if (!unhexString.equals(testString)) {
            System.err.println("hex test #3 failed");
            System.err.println("bad value is " + unhexString);
        } else {
            System.out.println("hex test #3 succeeded");
        }
    }
}

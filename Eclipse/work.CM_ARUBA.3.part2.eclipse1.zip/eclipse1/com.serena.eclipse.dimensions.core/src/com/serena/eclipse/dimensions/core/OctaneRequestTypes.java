package com.serena.eclipse.dimensions.core;

import java.util.Arrays;
import java.util.List;

public class OctaneRequestTypes {
    public static String DEFECT = "Defect";
    public static String USER_STORY = "User Story";
    public static String TASK ="Task";
    public static String QUALITY_STORY ="Quality Story";
    public static String ALL = "All";
    
    public static List<String> typesList() {
        return Arrays.asList(DEFECT, USER_STORY, TASK, QUALITY_STORY, ALL);
    }
}

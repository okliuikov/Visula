/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.Comparator;

import com.serena.dmclient.api.UserRoleCapability;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Compares instances of <code>UserRoleCapability</code> by the level
 * of responsibility. It is considered that S &lt; P &lt; L in ascending mode.
 *
 * @author V.Grishchenko
 * @see com.serena.eclipse.dimensions.core.IDMConstants#LEADER_CAPABILITY
 * @see com.serena.eclipse.dimensions.core.IDMConstants#PRIMARY_CAPABILITY
 * @see com.serena.eclipse.dimensions.core.IDMConstants#SECONDARY_CAPABILITY
 */
public class UserRoleCapabilityComparator implements Comparator {
    boolean descending = false;

    /**
     * Creates a new ascending user role capability comparator.
     */
    public UserRoleCapabilityComparator() {
    }

    /**
     * Creates a new user role capability comparator with the specified
     * compare order.
     *
     * @param descending
     */
    public UserRoleCapabilityComparator(boolean descending) {
        this.descending = descending;
    }

    @Override
    public int compare(Object o1, Object o2) {
        Assert.isLegal(o1 instanceof UserRoleCapability);
        Assert.isLegal(o2 instanceof UserRoleCapability);
        int rl1 = getResponsibilityLevel(((UserRoleCapability) o1).getCapability());
        int rl2 = getResponsibilityLevel(((UserRoleCapability) o2).getCapability());
        int result = rl1 - rl2;
        if (descending) {
            result = -result;
        }
        return result;
    }

    private int getResponsibilityLevel(String respLevel) {
        if (IDMConstants.SECONDARY_CAPABILITY.equalsIgnoreCase(respLevel)) {
            return 0;
        }
        if (IDMConstants.PRIMARY_CAPABILITY.equalsIgnoreCase(respLevel)) {
            return 1;
        }
        if (IDMConstants.LEADER_CAPABILITY.equalsIgnoreCase(respLevel)) {
            return 2;
        }
        assert false : "unknown responsibility level"; //$NON-NLS-1$
        return 0;
    }

}

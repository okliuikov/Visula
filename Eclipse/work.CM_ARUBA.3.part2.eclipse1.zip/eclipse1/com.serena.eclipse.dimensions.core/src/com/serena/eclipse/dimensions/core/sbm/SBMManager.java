package com.serena.eclipse.dimensions.core.sbm;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.SubProgressMonitor;

import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IUserAuthenticator;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

abstract class SBMManager implements ISBMManager {
    static final int MAX_LOGIN_ATTEMPTS = 3;
    static final String ACTIVE_ITEMS = "/~ActiveItems~";

    private static final String DATE_FORMAT_PROP = "DATE_FORMAT_PROPERTY";

    private DimensionsConnectionDetailsEx dmcon;
    private ISBMConnection connection;
    private ISBMContainer root;
    private List listeners = new ArrayList();
    protected boolean authenticating;
    protected boolean authenticated;
    protected ISBMReportsProvider reportsProvider;
    protected Map containerProperties = new HashMap();
    private ActiveItems activeItems = null;

    private static Map getMemberMap(ISBMConnection connection) {
        return ConnectionData.getInstance().getMemberMap(connection);
    }

    /**
     * @param connection
     */
    public SBMManager(DimensionsConnectionDetailsEx con) {
        this.dmcon = con;
        this.connection = con.getSBMConnection();
        this.root = new IDEFolder(dmcon);
    }

    @Override
    public void addListener(ISBMListener listener) {
        if (listener == null) {
            throw new NullPointerException("null listener"); //$NON-NLS-1$
        }
        synchronized (listeners) {
            if (!listeners.contains(listener)) {
                listeners.add(listener);
            }
        }
    }

    @Override
    public void removeListener(ISBMListener listener) {
        synchronized (listeners) {
            listeners.remove(listener);
        }
    }

    void fireEvent(ISBMObject object, int eventType) {
        SBMEvent event = new SBMEvent(object, eventType);
        synchronized (listeners) {
            for (Iterator iterator = listeners.iterator(); iterator.hasNext();) {
                ISBMListener aListener = (ISBMListener) iterator.next();
                aListener.update(event);
            }
        }
    }

    public boolean isAuthenticating() {
        return authenticating;
    }

    @Override
    public ISBMConnection getConnection() {
        return connection;
    }

    @Override
    public ISBMContainer getRoot(boolean refresh, IProgressMonitor monitor) throws SBMException {
        if (refresh) {
            root.refresh(monitor);
        }
        return root;
    }

    @Override
    public void addToActiveRequests(ISBMRequest[] items) throws DMException {
        if (items == null || items.length == 0) {
            return;
        }
        getActiveItemsContainer().addToActiveRequests(items);
        for (int i = 0; i < items.length; i++) {
            ISBMRequest request = items[i];
            fireEvent(request, SBMEvent.PROPERTY_CHANGE);
        }
    }

    @Override
    public ISBMContainer getActiveRequests() throws DMException {
        return getActiveItemsContainer();
    }

    private ActiveItems getActiveItemsContainer() {
        if (activeItems == null) {
            activeItems = new ActiveItems(dmcon);
        }
        return activeItems;
    }

    @Override
    public void removeFromActiveRequests(ISBMRequest[] items) throws DMException {
        if (items == null || items.length == 0) {
            return;
        }
        getActiveItemsContainer().removeFromActiveRequests(items);
        for (int i = 0; i < items.length; i++) {
            ISBMRequest request = items[i];
            fireEvent(request, SBMEvent.PROPERTY_CHANGE);
        }
    }

    @Override
    public ISBMContainer findCachedParent(int type, String url) {
        Assert.isNotNull(url);
        if (type == ISBMObject.ACTIVE_ITEMS) {
            return getActiveItemsContainer();
        } else if (type == ISBMObject.ASSOCIATIONS) {
            return null; // TODO VG on Jul 6, 2008: handle this
        } else if (url.equals(root.getUrl())) {
            return root;
        } else {
            List rootMembers = getContainerMembers(root);
            if (rootMembers != null) {
                for (Iterator iterator = rootMembers.iterator(); iterator.hasNext();) {
                    ISBMObject aMember = (ISBMObject) iterator.next();
                    if (aMember.getType() == ISBMObject.REPORT && url.equals(aMember.getUrl())) {
                        return (ISBMReport) aMember;
                    }
                }
            }
        }

        return null;
    }

    @Override
    public ISBMAssociations getAssociations(String path) throws SBMException {
        return new SBMAssociations(connection, path);
    }

    protected boolean isAuthenticated() {
        return authenticated;
    }

    protected void setAuthenticated(boolean authenticated) {
        this.authenticated = authenticated;
    }

    @Override
    public synchronized boolean authenticate(boolean allowPrompt, IProgressMonitor monitor) throws SBMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask("Authenticating", IProgressMonitor.UNKNOWN);
        boolean success = true;
        try {
            authenticating = !allowPrompt;
            getRoot(true, Utils.subMonitorFor(monitor, 10, SubProgressMonitor.SUPPRESS_SUBTASK_LABEL));
        } catch (SBMException e) {
            if (e.getStatus().getCode() != SBMStatus.INVALID_USER) {
                throw e;
            }
            success = false;
        } finally {
            authenticating = false;
            monitor.done();
        }
        return success;
    }

    protected abstract List fetchContainerMembers(ISBMContainer container, IProgressMonitor monitor) throws SBMException;

    List getContainerMembers(ISBMContainer container) {
        Map members = getMemberMap(connection);
        synchronized (members) {
            return (List) members.get(container);
        }
    }

    void refreshContainer(ISBMContainer container, IProgressMonitor monitor) throws SBMException {
        List memberList = fetchContainerMembers(container, monitor);
        Map members = getMemberMap(connection);
        synchronized (members) {
            HashSet newChildContainers = new HashSet();
            for (Iterator iterator = memberList.iterator(); iterator.hasNext();) {
                ISBMObject object = (ISBMObject) iterator.next();
                if (object.isContainer()) {
                    newChildContainers.add(object);
                }
            }
            // purge deleted containers, if any
            for (Iterator iterator = members.entrySet().iterator(); iterator.hasNext();) {
                Map.Entry entry = (Map.Entry) iterator.next();
                ISBMContainer cachedContainer = (ISBMContainer) entry.getKey();
                if (container.equals(cachedContainer.getParent()) && !newChildContainers.contains(cachedContainer)) {
                    iterator.remove();
                    containerProperties.remove(cachedContainer);
                }
            }
            members.put(container, memberList);
        }
        fireEvent(container, SBMEvent.STRUCTURE_CHANGE);
    }

    protected IStatus promptForCredentials(ChallengeDetails challenge, IStatus status) {
        IUserAuthenticator userAuthenticator = DMPlugin.getDefault().getPluggedInAuthenticator();
        if (userAuthenticator == null) {
            return new SBMStatus(IStatus.ERROR, DMPlugin.ID, SBMStatus.INVALID_USER,
                    "Authentication failed. No plugged in user authenticator", null);
        }
        SBMConnectionDetails conDetails = getConnection().getDetails();
        LoginCredentials credentials = userAuthenticator.promptForConnectionDetails(challenge, status);
        if (credentials == null) {
            return new SBMStatus(IStatus.CANCEL, DMPlugin.ID, SBMStatus.INVALID_USER, "Login was cancelled by user", null);
        }
        conDetails.setUser(credentials.userName);
        conDetails.setPassword(credentials.password);
        conDetails.setSsoToken(null);
        // conDetails.setDomain(domain)
        return Status.OK_STATUS;
    }

    boolean isActive(String itemID) throws SBMException {
        List activeItems = getActiveItems();
        if (activeItems != null) {
            for (Iterator iterator = activeItems.iterator(); iterator.hasNext();) {
                ISBMRequest anActiveItem = (ISBMRequest) iterator.next();
                if (itemID.equals(anActiveItem.getItemID())) {
                    return true;
                }
            }
        }
        return false;
    }

    private List getActiveItems() throws SBMException {
        return getActiveItemsContainer().getMembers();
    }

    static String getActiveItemsUrl(DimensionsConnectionDetailsEx connection) {
        return connection.getConnName() + "/" + ACTIVE_ITEMS;
    }

    @Override
    public void setReportsProvider(ISBMReportsProvider reportsProvider) {
        this.reportsProvider = reportsProvider;
    }

    @Override
    public ISBMReportsProvider getReportsProvider() {
        return reportsProvider;
    }

    @Override
    public DateFormat getDateFormatForContainer(ISBMContainer container, boolean refresh) {
        return getDateFormatForContainer(container);
    }

    @Override
    public DateFormat getDateFormatForContainer(ISBMContainer container) {
        Map members = getMemberMap(connection);
        synchronized (members) {
            Map properties = (Map) containerProperties.get(container);
            if (properties != null) {
                return (DateFormat) properties.get(DATE_FORMAT_PROP);
            }
        }
        return null;
    }

    protected void setDateFormatForContainer(ISBMContainer container, DateFormat format) {
        Map members = getMemberMap(connection);
        synchronized (members) {
            Map properties = (Map) containerProperties.get(container);
            if (properties == null) {
                properties = new HashMap();
                containerProperties.put(container, properties);
            }
            properties.put(DATE_FORMAT_PROP, format);
        }
    }

}

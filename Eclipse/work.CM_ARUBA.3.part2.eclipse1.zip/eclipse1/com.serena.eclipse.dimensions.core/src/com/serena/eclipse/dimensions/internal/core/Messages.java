/*
 * @Messages.java, created on May 10, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.internal.core;

import org.eclipse.osgi.util.NLS;

/**
 * NLS convenience methods for the plugin.
 *
 * @author V.Grishchenko
 */
public class Messages extends NLS {

    private static final String BUNDLE_NAME = "com.serena.eclipse.dimensions.internal.core.messages"; //$NON-NLS-1$

    static {
        NLS.initializeMessages(BUNDLE_NAME, Messages.class);
    }

    // authenticator
    public static String login_default_title;
    public static String login_default_message;

    // progress messages
    public static String session_connect;
    public static String progress_loadObjList;
    public static String progress_loadObjListIds;
    public static String progress_loadObjListAttrs;
    public static String connectJob_name;
    public static String progress_loadProducts;
    public static String progress_loadUsers;
    public static String progress_loadTypes;
    public static String progress_loadType;
    public static String progress_loadRoleAttributes;
    public static String progress_loadParts;

    // errorLogging
    public static String log_unknownValue;
    public static String log_detectedIn;
    public static String log_originatedIn;
    public static String log_vendorName;
    public static String log_pluginName;
    public static String log_pluginID;
    public static String log_pluginVersion;
    public static String log_exception;
    public static String log_class;
    public static String log_method;

    public static String error_noDetails;
    public static String error_productNotFound;

    public static String session_reconnect;
    public static String session_reconnectNoDetails;
    public static String session_reconnectFailed;
    public static String session_reconnectFailedNoDetails;
    public static String session_reconnectSucceeded;
    public static String session_dariusSessionLoggedOut;

    public static String connection_loginCanceled;

    public static String requestList_delete;
    public static String requestList_delete1;
    public static String requestList_add;
    public static String requestList_remove;
    public static String requestList_notFound;

    // Dimensions Objects display

    // This fields are used by reflection mechanism and
    // stay discoverable through 'Find Broken Externalized Strings' wizard
    public static String display_item;
    public static String display_item_multiple;
    public static String display_item_multiple_optional;
    public static String display_request;
    public static String display_request_multiple;
    public static String display_request_multiple_optional;
    public static String display_project;
    public static String display_stream;
    public static String display_project_multiple;
    public static String display_project_multiple_optional;
    public static String display_baseline;
    public static String display_baseline_multiple;
    public static String display_baseline_multiple_optional;
    public static String display_product;
    public static String display_product_multiple;
    public static String display_product_multiple_optional;
    public static String display_part;
    public static String display_part_multiple;
    public static String display_part_multiple_optional;
    public static String display_project_group_member;
    public static String display_project_group_member_multiple;
    public static String display_project_group_member_multiple_optional;
    public static String display_RequestList;
    public static String display_RequestList_multiple;
    public static String display_RequestList_multiple_optional;

    public static String display_withId;

    // object delete
    public static String objectDelete_task;
    public static String objectDelete_console;

    // object create
    public static String objectCreate_task;
    public static String objectCreate_console;

    // object get copy
    public static String objectGetCopy_task;

    // attr update
    public static String objectUpdateAttrs_task;
    public static String objectUpdateAttrs_console;
    public static String objectUpdateAttrs_ok;

    // action
    public static String objectAction_task;
    public static String objectAction_console;
    public static String objectAddToFavourites_consoleAddMultiple;
    public static String objectAddToFavourites_consoleAddSingle;
    public static String objectAddToFavourites_consoleRemoveMultiple;
    public static String objectAddToFavourites_consoleRemoveSingle;
    // Containers
    public static String containers_IDEidentifier;

    // Adapter copy not found messages
    public static String baseline_notfound;
    public static String request_notfound;
    public static String itemrevision_notfound;
    public static String project_notfound;
    public static String sccproject_notfound;
    public static String requestlist_notfound;

    public static String connectionDataSaving_error;
    public static String consoleOk;
    public static String getConnectionDetails_warning;
    public static String maintainPLCD_executionSkipped;
    public static String maintainPLCD_JobName;
    public static String maintainPLCD_executionSuccess;
}
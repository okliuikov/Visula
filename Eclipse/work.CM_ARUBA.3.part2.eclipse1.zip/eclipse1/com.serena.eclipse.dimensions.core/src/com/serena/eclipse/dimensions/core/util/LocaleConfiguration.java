/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.util;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DmSettings;
import com.serena.eclipse.dimensions.core.IDMConstants;

/*
 * Interface to locale properties file.
 * @author V.Grishchenko
 */
public class LocaleConfiguration {
    private static final String CONFIG_FILE = "locale.properties"; //$NON-NLS-1$
    private static final String PATTERN_KEY_PREFIX = "datepattern."; //$NON-NLS-1$

    // Oracle adds a space for korean dates prior to October to satisfy MMM
    private static final String KOREAN_DATETIME_ORACLE_PATTERN = "dd-MMM -yyyy HH:mm:ss"; //$NON-NLS-1$
    private static final String KOREAN_DATE_ORACLE_PATTERN = "dd-MMM -yyyy"; //$NON-NLS-1

    // additional patterns known to exist in the past
    private static final String AUX_DATETIME_PATTERN_1 = "yyyy-MM-dd HH:mm:ss"; //$NON-NLS-1$
    private static final String AUX_DATE_PATTERN_1 = "yyyy-MM-dd"; //$NON-NLS-1$
    // sys attrs ODBC servers - per DVDC
    private static final String AUX_DATETIME_PATTERN_2 = "yyyy-MM-dd HH:mm:ss.S"; //$NON-NLS-1$
    // sys attrs DB/2+CLI servers - per DVDC
    private static final String AUX_DATETIME_PATTERN_3 = "yyyy-MM-dd-HH:mm:ss,S"; //$NON-NLS-1$

    private static final String[] DEFAULT_PATTERNS = new String[] { IDMConstants.DEFAULT_DATETIME_PATTERN,
            IDMConstants.DEFAULT_DATE_PATTERN, KOREAN_DATETIME_ORACLE_PATTERN, KOREAN_DATE_ORACLE_PATTERN, AUX_DATETIME_PATTERN_1,
            AUX_DATE_PATTERN_1, AUX_DATETIME_PATTERN_2, AUX_DATETIME_PATTERN_3 };

    private static final LocaleConfiguration instance = new LocaleConfiguration();

    private String[] patterns;

    public static LocaleConfiguration getInstance() {
        return instance;
    }

    private LocaleConfiguration() {
        if (!initialize()) {
            patterns = DEFAULT_PATTERNS.clone();
        }
    }

    private boolean initialize() {
        File configFile = new File(DmSettings.getInstance().getPreferencesFolder(), CONFIG_FILE);
        if (!configFile.exists()) {
            if (!createDefautConfigFile(configFile)) {
                return false;
            }
        }
        BufferedInputStream in = null;
        try {
            // read properties file
            in = new BufferedInputStream(new FileInputStream(configFile), 4096);
            Properties configEntries = new Properties();
            configEntries.load(in);

            // find all patterns
            ArrayList list = new ArrayList();
            Enumeration keys = configEntries.propertyNames();
            while (keys.hasMoreElements()) {
                String key = (String) keys.nextElement();
                if (key.startsWith(PATTERN_KEY_PREFIX)) {
                    int order = -1;
                    if (key.length() > PATTERN_KEY_PREFIX.length()) {
                        order = Utils.parseInt(key.substring(PATTERN_KEY_PREFIX.length()), -1);
                    }
                    if (order >= 0) {
                        String value = configEntries.getProperty(key);
                        Pattern pattern = new Pattern(value, order);
                        list.add(pattern);
                    } else {
                        IStatus warn = new Status(IStatus.WARNING, DMPlugin.ID, 0, "Invalid pattern key: " + key, null); //$NON-NLS-1$
                        DMPlugin.log(warn);
                    }
                }
            }
            Collections.sort(list);
            patterns = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                Pattern aPattern = (Pattern) list.get(i);
                patterns[i] = aPattern.pattern;
            }
            return patterns.length > 0;
        } catch (IOException e) {
            IStatus error = new Status(IStatus.ERROR, DMPlugin.ID, 0,
                    "Failed to read in locale configuration from " + configFile.getAbsolutePath(), e); //$NON-NLS-1$
            DMPlugin.log(error);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignore) {
                }
            }
        }
        return false;
    }

    private boolean createDefautConfigFile(File configFile) {
        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(configFile), "ISO-8859-1")); //$NON-NLS-1$
            out.write("#This file can be used to specify locale specific processing parameters."); //$NON-NLS-1$
            out.newLine();
            out.write("#It must be in ISO-8859-1 encoding and be compliant with Java properties file format."); //$NON-NLS-1$
            out.newLine();
            out.write("#" + new Date().toString()); //$NON-NLS-1$
            out.newLine();
            out.newLine();
            out.write("#Date patterns, will attempt to parse dates in the order specified by the numeric key suffix"); //$NON-NLS-1$
            out.newLine();
            for (int i = 0; i < DEFAULT_PATTERNS.length; i++) {
                out.write(PATTERN_KEY_PREFIX + i + "=" + DEFAULT_PATTERNS[i]); //$NON-NLS-1$
                out.newLine();
            }
            return true;
        } catch (IOException e) {
            IStatus error = new Status(IStatus.ERROR, DMPlugin.ID, 0,
                    "Failed to create default locale configuration file at " + configFile.getAbsolutePath(), e); //$NON-NLS-1$
            DMPlugin.log(error);
        } finally {
            if (out != null) {
                try {
                    out.flush();
                    out.close();
                } catch (IOException ignore) {
                }
            }
        }
        return false;
    }

    public String[] getPatterns() {
        return patterns;
    }

    private static class Pattern implements Comparable {
        String pattern;
        int order;

        Pattern(String pattern, int order) {
            this.pattern = pattern;
            this.order = order;
        }

        @Override
        public int compareTo(Object o) {
            Pattern otherPattern = (Pattern) o;
            return order - otherPattern.order;
        }
    }

    // public static void main(String[] args) {
    // LocaleConfiguration config = new LocaleConfiguration();
    // String[] patterns = config.getPatterns();
    // for (int i = 0; i < patterns.length; i++) {
    // System.out.println(patterns[i]);
    // }
    // System.out.println("locale: " + config.getServerLocale());
    // }

}

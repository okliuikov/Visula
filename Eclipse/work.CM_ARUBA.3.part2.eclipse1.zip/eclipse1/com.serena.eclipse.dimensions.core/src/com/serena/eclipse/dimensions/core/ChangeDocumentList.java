/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.RequestDetails;
import com.serena.dmclient.api.RequestList;
import com.serena.dmclient.api.RequestListDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.WorkingCMRequestList;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author V.Grishchenko
 */
public abstract class ChangeDocumentList extends DimensionsObjectList {
    public static final int MY_PENDING = 1;
    public static final int OTHER_PENDING = 2;
    public static final int CUSTOM = 3;
    public static final int DRAFT = 4;
    public static final int JOB = 5;
    public static final int ACTIVE_ISSUES = 6;
    public static final int WORKING_CM_ISSUES = 7;
    public static final int WORKING_IDM_ISSUES = 8;

    private static ISessionListener sessList = new ISessionListener() {

        @Override
        public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
            lists.remove(loc);
        }

        @Override
        public void sessionCreated(DimensionsConnectionDetailsEx loc) {
        }
    };

    // connection -> {my, other, custom, job}
    private static Map<DimensionsConnectionDetailsEx, List<DimensionsObjectList>> lists = new ConnectionListsHashMap<DimensionsConnectionDetailsEx, List<DimensionsObjectList>>();

    public static ChangeDocumentList getMyPendingList(DimensionsConnectionDetailsEx con) {
        ChangeDocumentList myList = lookupList(con, MY_PENDING, null);
        if (myList == null) {
            myList = new MyPendingList(con);
            registerList(myList);
        }
        return myList;
    }

    public static ChangeDocumentList getOtherPendingList(DimensionsConnectionDetailsEx con, String username) {
        ChangeDocumentList otherPending = lookupList(con, OTHER_PENDING, username);
        if (otherPending == null) {
            otherPending = new OtherChDocPendingtList(con, username);
            registerList(otherPending);
        }
        return otherPending;
    }

    public static ChangeDocumentList getCustomList(DimensionsConnectionDetailsEx con, RequestList customList) {
        ChangeDocumentList myCustomList = lookupList(con, CUSTOM, customList.getName());
        if (myCustomList == null) {
            myCustomList = new ECustomChangeDocumentList(con, customList, CUSTOM);
            // add object spec to ensure query for spec when updating works
            myCustomList.attributeSubscribe(ECustomChangeDocumentList.class.getName(), new int[] { SystemAttributes.OBJECT_SPEC });
            registerList(myCustomList);
        }

        return myCustomList;
    }

    public static ChangeDocumentList getDraftList(DimensionsConnectionDetailsEx con) {
        ChangeDocumentList myDraftList = lookupList(con, DRAFT, null);
        if (myDraftList == null) {
            myDraftList = new MyPendingList(con, true);
            registerList(myDraftList);
        }
        return myDraftList;
    }

    public static ChangeDocumentList getJobDocumentList(DimensionsConnectionDetailsEx con, RequestList customList) {
        ChangeDocumentList myCustomList = lookupList(con, JOB, customList.getName());
        if (myCustomList == null) {
            myCustomList = new ECustomChangeDocumentList(con, customList, JOB);
            registerList(myCustomList);
        }
        return myCustomList;
    }

    /**
     * Obtains active request list, creating one if necessary
     */
    public static MyWorkingChangeDocumentList getActiveRequestsList(DimensionsConnectionDetailsEx con, IProgressMonitor monitor)
            throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask("Looking up active request list...", IProgressMonitor.UNKNOWN);
        try {
            MyWorkingChangeDocumentList activeList = (MyWorkingChangeDocumentList) lookupList(con, WORKING_CM_ISSUES, null);
            if (activeList == null) {
                final Session session = con.openSession(Utils.subMonitorFor(monitor, 10));
                final WorkingCMRequestList[] listHolder = new WorkingCMRequestList[1];
                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        listHolder[0] = lookupActiveRequests(session.getObjectFactory());
                    }

                }, monitor);

                if (listHolder[0] == null) {
                    // create
                    session.run(new APIOperation("Creating active requests list") {

                        @Override
                        protected DimensionsResult doRun() throws Exception {
                            return session.getObjectFactory().createWorkingCMRequestList(
                                    new RequestListDetails(MyWorkingChangeDocumentList.MY_WORKING_LIST));
                        }

                    }, monitor);

                    // lookup again
                    session.run(new ISessionRunnable() {

                        @Override
                        public void run() throws Exception {
                            listHolder[0] = lookupActiveRequests(session.getObjectFactory());
                        }

                    }, monitor);
                }

                if (listHolder[0] == null) {
                    throw new DMException(IStatus.ERROR, 0, "Cannot obtain active requests list", null);
                }

                activeList = new MyWorkingChangeDocumentList(con, listHolder[0], WORKING_CM_ISSUES);

                // add object spec to ensure query for spec when updating works

                // @formatter:off
                activeList.attributeSubscribe(
                        MyWorkingChangeDocumentList.class.getName(),
                        new int[] {
                            SystemAttributes.PRODUCT_NAME,
                            SystemAttributes.CM_PHASE,
                            SystemAttributes.OBJECT_SPEC });
                // @formatter:on

                registerList(activeList);
            }
            return activeList;
        } finally {
            monitor.done();
        }
    }

    private static WorkingCMRequestList lookupActiveRequests(DimensionsObjectFactory factory) {
        Filter filter = new Filter();
        filter.criteria().add(
                new Filter.Criterion(SystemAttributes.OBJECT_ID, MyWorkingChangeDocumentList.MY_WORKING_LIST,
                        Filter.Criterion.EQUALS));
        List cLists = factory.getCurrentUser().getWorkingCMRequestLists(filter);
        return cLists.isEmpty() ? null : (WorkingCMRequestList) cLists.get(0);
    }

    /**
     * @return currently known lists for the specified connection
     */
    public static List getLists(DimensionsConnectionDetailsEx con) {
        List<DimensionsObjectList> conLists = lists.get(con);
        if (conLists == null) {
            return Collections.EMPTY_LIST;
        }
        return Collections.unmodifiableList(conLists);
    }

    private static ChangeDocumentList lookupList(DimensionsConnectionDetailsEx con, int listType, String qualifier) {
        List<DimensionsObjectList> conLists = lists.get(con);
        if (conLists == null) {
            return null;
        }

        for (Iterator<DimensionsObjectList> iter = conLists.iterator(); iter.hasNext();) {
            ChangeDocumentList aList = (ChangeDocumentList) iter.next();
            if (aList.getType() == listType
                    && ((qualifier == aList.getQualifier()) || (qualifier != null && qualifier.equals(aList.getQualifier())))) {
                DimensionsObjectList.replaceEqualConnectionInstances(con, aList);
                return aList;
            }
        }
        return null;
    }

    private static void registerList(ChangeDocumentList list) {
        List<DimensionsObjectList> conLists = lists.get(list.getConnectionDetails());
        if (conLists == null) {
            conLists = new ArrayList<DimensionsObjectList>(4);
            lists.put(list.getConnectionDetails(), conLists);
        }
        conLists.add(list);
    }

    /**
     * Retrieves and registers all jobs for the current user
     * on the specified connection.
     *
     * @param con
     * @param pm
     * @return
     * @throws DMException
     */
    public static ECustomChangeDocumentList[] getJobs(final DimensionsConnectionDetailsEx con, IProgressMonitor pm)
            throws DMException {
        final Session session = con.openSession(null);
        final ArrayList result = new ArrayList();
        session.run(new ISessionRunnable() {
            @Override
            public void run() throws Exception {
                Filter filter = new Filter();
                Filter.Criterion criterion = new Filter.Criterion();
                criterion.setAttribute(SystemAttributes.OBJECT_ID);
                criterion.setValue(ECustomChangeDocumentList.jobPrefix + '%');
                criterion.setFlags(Filter.Criterion.EQUALS);
                filter.criteria().add(criterion);
                List cLists = session.getObjectFactory().getCurrentUser().getRequestLists(filter);
                result.ensureCapacity(cLists.size());
                for (Iterator iter = cLists.iterator(); iter.hasNext();) {
                    RequestList cList = (RequestList) iter.next();
                    ChangeDocumentList ecList = getJobDocumentList(con, cList);
                    result.add(ecList);
                }
            }
        }, pm);
        return (ECustomChangeDocumentList[]) result.toArray(new ECustomChangeDocumentList[result.size()]);
    }

    public ChangeDocumentList(DimensionsConnectionDetailsEx con, int type) {
        super(con, type);
        DimensionsConnectionDetailsEx.addSessionListener(sessList);
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.REQUEST;
    }

    @Override
    protected String getUniqueId(DimensionsArObject object) {
        Object name = object.getName();
        return name != null ? name.toString() : null;
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        Assert.isLegal(objectDetails instanceof RequestDetails);
        monitor.beginTask(Messages.objectCreate_task, IProgressMonitor.UNKNOWN);
        monitor.subTask(getTypeScope().getObjectId(objectDetails));
        try {
            return session.getObjectFactory().createRequest((RequestDetails) objectDetails);
        } finally {
            monitor.done();
        }
    }

}

package com.serena.eclipse.dimensions.core.sbm;

import java.util.Map;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * Light substitute of ISBMPropertySource descendants
 * @author kberezovchuk
 */
public class StringPropertySource implements ISBMPropertySource {
    private SBMProperty[] properties; // definition of properties
    private Map propertyValueMap; // property values

    public StringPropertySource(SBMProperty[] properties, Map propertyValueMap) {
        this.properties = properties;
        this.propertyValueMap = propertyValueMap;
    }

    @Override
    public SBMProperty[] getProperties() {
        return properties;
    }

    @Override
    public String getProperty(SBMProperty propertyKey) {
        if (propertyValueMap == null) {
            return null;
        }
        // currently SBMproperty implements equals in terms of its display name,
        // if lookup by display name fails attempt to lookup by property id.
        String result = (String) propertyValueMap.get(propertyKey);
        if (result == null) {
            result = (String) propertyValueMap.get(new SBMProperty(propertyKey.getId(), propertyKey.getDisplayName()));
        }
        return result;
    }

    @Override
    public ISBMConnection getConnection() {
        return null;
    }

    @Override
    public String getDisplayUrl() {
        return null;
    }

    @Override
    public ISBMContainer getParent() {
        return null;
    }

    @Override
    public int getType() {
        return 0;
    }

    @Override
    public String getUrl() {
        return null;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnectionDetails() {
        return null;
    }

    @Override
    public String getServiceId() {
        return null;
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    @Override
    public Object getAdapter(Class adapter) {
        return null;
    }

}

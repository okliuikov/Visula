/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2013, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IProgressMonitor;

/**
 * Provides a possibility to get all nested members
 */
public interface IWithAPIMembers {

    /**
     * @param monitor
     * @return all nested members which are an APIObjectAdapter
     */
    APIObjectAdapter[] getMembers(IProgressMonitor monitor);

}

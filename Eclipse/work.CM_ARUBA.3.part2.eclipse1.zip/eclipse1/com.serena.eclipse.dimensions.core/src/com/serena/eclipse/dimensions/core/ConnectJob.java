/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.osgi.util.NLS;

import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Opens a session for a connection.
 *
 * @author V.Grishchenko
 */
public class ConnectJob extends Job {
    private DimensionsConnectionDetailsEx con;

    public ConnectJob(DimensionsConnectionDetailsEx con) {
        this(null, con);
    }

    public ConnectJob(String name, DimensionsConnectionDetailsEx con) {
        super(name == null ? NLS.bind(Messages.connectJob_name, con.getConnName()) : name);
        assert con != null;
        this.con = con;
        setRule(con);
    }

    @Override
    protected IStatus run(IProgressMonitor monitor) {
        IStatus result = Status.OK_STATUS;
        if (con.isSessionOpen()) {
            return result;
        }
        try {
            con.setOffline(false);
            con.openSession(monitor);
        } catch (DMException e) {
            result = e.getStatus();
        }

        // if we have connected

        return result;
    }

}

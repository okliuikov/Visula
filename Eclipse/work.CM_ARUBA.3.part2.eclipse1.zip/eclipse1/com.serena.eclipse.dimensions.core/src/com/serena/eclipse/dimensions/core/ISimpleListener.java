/*
 * @ISimpleListener.java,
 * Copyright SERENA Software,Inc. 1998-2006. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

/**
 * Receives simple notifications about content changes.
 *
 *
 * @author B.Stephenson
 */
public interface ISimpleListener {
    void contentsChanged();
}

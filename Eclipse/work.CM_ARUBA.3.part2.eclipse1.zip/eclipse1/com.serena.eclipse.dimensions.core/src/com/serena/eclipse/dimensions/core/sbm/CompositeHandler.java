/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Wraps a request and report handlers and forwards SAX calls to both.
 *
 * @author V.Grishchenko
 */
class CompositeHandler extends SBMContentHandler {
    private RequestHandler requestHandler;
    private ReportHandler reportHandler;

    /**
     * @param parent
     */
    public CompositeHandler(ISBMConnection connection, ISBMContainer parent) {
        super(connection);
        requestHandler = new RequestHandler(connection, parent);
        reportHandler = new ReportHandler(connection);
    }

    @Override
    public void recycle() {
        requestHandler.recycle();
        reportHandler.recycle();
        super.recycle();
    }

    @Override
    public int getTTReturnCode() {
        return requestHandler.getTTReturnCode();
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        requestHandler.characters(ch, start, length);
        reportHandler.characters(ch, start, length);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        requestHandler.startElement(uri, localName, qName, attributes);
        reportHandler.startElement(uri, localName, qName, attributes);
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        requestHandler.endElement(uri, localName, qName);
        reportHandler.endElement(uri, localName, qName);
    }

    /**
     * @return requests contained in XML
     */
    public List getRequests() {
        return requestHandler.getRequests();
    }

    /**
     * @return reports contained in XML
     */
    public List getReports() {
        return reportHandler.getReports();
    }

}

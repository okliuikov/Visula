/*
 * @IDMConnectionReconciliator.java, created on May 17, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

/**
 * Implementors are responsible for resolving conflicts between Eclipse
 * persisted connection data and externally persisted connecton data.
 *
 * @author V.Grishchenko
 */
public interface IDMConnectionReconciliator {

    /**
     * Describes a connection conflict and provides methods for accepting
     * and merging changes. Because the plugin always keeps Eclipse connection
     * details in sync any change represented by this class should be considered
     * a to the external store.
     */
    public static class ConnectionConflict {
        private DimensionsConnectionDetailsEx internal;
        private DimensionsConnectionDetailsEx external;
        private boolean reconciled;

        ConnectionConflict(DimensionsConnectionDetailsEx internal, DimensionsConnectionDetailsEx external) {
            this.internal = internal;
            this.external = external;
        }

        /**
         * Accepts all changes from the Eclipse storage and saves them into external storage
         * @throws DMException if failed to persist connection details
         */
        public void acceptInternal() throws DMException {
            if (reconciled) {
                return;
            }
            if (internal == null) {
                DMPlugin.getDefault().deleteExternal(external);
            } else {
                DMPlugin.getDefault().addExternal(internal);
            }
            reconciled = true;
        }

        /**
         * accepts all changes from the external storage and saves them into Eclipse storage
         * @throws DMException if failed to persist connection details
         */
        public void acceptExternal() throws DMException {
            if (reconciled) {
                return;
            }
            if (external != null) {
                DMPlugin.getDefault().addInternal(external);
            } else {
                DMPlugin.getDefault().deleteInternal(internal);
            }
            reconciled = true;
        }

        /**
         * Attempts to merge changes and saves them to both internal and external storages
         *
         * @return <code>true</code> if merge succeeded, returns <code>false otherwise</code>
         * @throws DMException if failed to persist connection details
         */
        public boolean merge() throws DMException {
            if (!reconciled && internal != null && external != null) {
                reconciled = DMPlugin.getDefault().mergeConnections(internal, external);
            }
            return reconciled;
        }

        /**
         * @return <code>true</code> if there are no conflicting connection
         *         properties, returns <code>false</code> otherwise
         */
        public boolean isAutoMergeable() {
            return DMPlugin.getDefault().isAutoMergeable(internal, external);
        }

        /**
         * @return if this conflict was reconciled
         */
        public boolean isReconciled() {
            return reconciled;
        }
    }

    /**
     * This method is called whenever changes to the external file are
     * detected. It is guaranteed that while this method is running the
     * external store will be locked.
     *
     * @param conflicts array of object describing conflict detrails
     * @return <code>true</code> if conflicts were successfully reconciled,
     *         returns <code>false</code> otherwise
     */
    boolean reconcile(ConnectionConflict[] conflicts);
}

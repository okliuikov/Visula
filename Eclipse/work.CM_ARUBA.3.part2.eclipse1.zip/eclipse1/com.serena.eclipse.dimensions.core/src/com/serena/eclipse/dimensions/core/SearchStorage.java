/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.locks.ReentrantLock;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmfile.dto.Pair;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Storage maintains dimensions object lists for fast lookup
 */
public class SearchStorage implements IDimensionsObjectListListener {

    public interface FilterCallback {
        String getFilter();
    }

    private ExecutorService executor = Executors.newFixedThreadPool(2);
    private ReentrantLock lock = new ReentrantLock();

    private Callable<FetchResult<WorksetAdapter>> projectsFetcher;
    private Future<FetchResult<WorksetAdapter>> projectsFetchResult;
    private List<DimensionsListEvent> projectsEvents = new ArrayList<DimensionsListEvent>();

    private Callable<FetchResult<BaselineAdapter>> baselinesFetcher;
    private Future<FetchResult<BaselineAdapter>> baselinesFetchResult;
    private List<DimensionsListEvent> baselinesEvents = new ArrayList<DimensionsListEvent>();

    private List<IDimensionsObjectListListener> listeners = new ArrayList<IDimensionsObjectListListener>();

    private DimensionsConnectionDetailsEx parentConnection;

    SearchStorage(DimensionsConnectionDetailsEx parentConnection) {
        Assert.isNotNull(parentConnection);
        this.parentConnection = parentConnection;
        this.projectsFetcher = new DimensionsProjectsFetcher(parentConnection);
        this.baselinesFetcher = new DimensionsBaselinesFetcher(parentConnection);
        DimensionsConnectionDetailsEx.addSessionListener((ISessionListener) projectsFetcher);
        DimensionsConnectionDetailsEx.addSessionListener((ISessionListener) baselinesFetcher);
    }

    /**
     * Refresh storage
     */
    public void refresh() {
        lock.lock();
        try {
            // allow to refresh iff previous refresh was completed

            if (projectsFetchResult == null || projectsFetchResult.isDone()) {
                this.projectsFetchResult = executor.submit(projectsFetcher);
            }

            if (baselinesFetchResult == null || baselinesFetchResult.isDone()) {
                this.baselinesFetchResult = executor.submit(baselinesFetcher);
            }

        } finally {
            lock.unlock();
        }
    }

    /**
     * Return spec to adapter mapping. Waits if necessary for the refresh to complete.
     *
     * @param clazz
     *            {@link WorksetAdapter} or {@link BaselineAdapter}
     * @return adapters map of given type for fast lookup
     */
    public <T extends APIObjectAdapter> Map<String, T> get(Class<T> clazz) {
        lock.lock();
        try {
            if (projectsFetchResult == null || baselinesFetchResult == null) {
                refresh();
            }
            return internalGetAndUpdate(clazz, null).getObjects();
        } finally {
            lock.unlock();
        }
    }

    /**
     * Return list of adapters. Waits if necessary for the refresh to complete.
     *
     * @param clazz
     *            {@link WorksetAdapter} or {@link BaselineAdapter}
     * @param includeFilter
     *            callback to get filter after wait operation, if object spec contains filter such object will be accepted
     * @param excludeFilters
     *            system attribute to attribute value pairs for excluding objects from result
     * @return list of given type
     */
    public <T extends APIObjectAdapter> List<T> get(Class<T> clazz, FilterCallback includeFilter,
            List<Pair<Integer, Object>> excludeFilters) {
        Map<String, T> cachedResult = get(clazz);
        String filter = includeFilter.getFilter();

        List<T> result = filter(cachedResult, filter, excludeFilters);

        return result;
    }

    /**
     * Return list of adapters. Waits if necessary for the refresh to complete.
     *
     * @param clazz
     *            {@link WorksetAdapter} or {@link BaselineAdapter}
     * @param includeFilter
     *            if object spec contains filter such object will be accepted
     * @param excludeFilters
     *            system attribute to attribute value pairs for excluding objects from result
     * @return list of given type
     */
    public <T extends APIObjectAdapter> List<T> get(Class<T> clazz, String includeFilter, List<Pair<Integer, Object>> excludeFilters) {
        Map<String, T> cachedResult = get(clazz);

        List<T> result = filter(cachedResult, includeFilter, excludeFilters);

        return result;
    }

    private <T extends APIObjectAdapter> List<T> filter(Map<String, T> cachedResult, String includeFilter,
            List<Pair<Integer, Object>> excludeFilters) {
        if (includeFilter == null) {
            includeFilter = "";
        }
        includeFilter = includeFilter.trim().toUpperCase();

        List<T> result = new ArrayList<T>();
        for (Map.Entry<String, T> entry : cachedResult.entrySet()) {
            if (entry.getKey().contains(includeFilter)) {
                if (excludeFilters == null || excludeFilters.isEmpty()) {
                    result.add(entry.getValue());
                } else {
                    for (Pair<Integer, Object> excludeFilter : excludeFilters) {
                        Integer attrNum = excludeFilter.getFirst();
                        Object attrValue = excludeFilter.getSecond();

                        T adapter = entry.getValue();

                        if (adapter.getAPIObject().getAttribute(attrNum) != null) {
                            if (!adapter.getAPIObject().getAttribute(attrNum).equals(attrValue)) {
                                // add if not same as exclude filter value
                                result.add(entry.getValue());
                            }
                        } else {
                            // add if attribute not found
                            result.add(entry.getValue());
                        }
                    }
                }
            }
        }
        return result;
    }

    public void clear() {
        lock.lock();
        try {
            projectsEvents.clear();
            baselinesEvents.clear();
            listeners.clear();

            if (projectsFetchResult != null) {
                projectsFetchResult.cancel(true);
                this.projectsFetchResult = null;
            }

            if (baselinesFetchResult != null) {
                baselinesFetchResult.cancel(true);
                this.baselinesFetchResult = null;
            }
        } finally {
            lock.unlock();
        }
    }

    public void addListener(IDimensionsObjectListListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    @Override
    public void listChanged(DimensionsListEvent e) {
        lock.lock();
        try {
            if (projectsFetchResult == null && baselinesFetchResult == null) {
                // nothing to update
                return;
            }

            List<APIObjectAdapter> prjChanges = new ArrayList<APIObjectAdapter>();
            List<APIObjectAdapter> bslChanges = new ArrayList<APIObjectAdapter>();

            for (APIObjectAdapter change : e.changes) {
                if (change instanceof WorksetAdapter) {
                    prjChanges.add(change);
                } else if (change instanceof BaselineAdapter) {
                    bslChanges.add(change);
                }
            }

            // divide initial event for project and baseline changes
            APIObjectAdapter[] changes = prjChanges.toArray(new APIObjectAdapter[prjChanges.size()]);
            DimensionsListEvent prjEvent = new DimensionsListEvent(e.getSource(), e.type, changes);
            changes = bslChanges.toArray(new APIObjectAdapter[bslChanges.size()]);
            DimensionsListEvent bslEvent = new DimensionsListEvent(e.getSource(), e.type, changes);

            if (projectsFetchResult != null && !prjChanges.isEmpty()) {
                if (projectsFetchResult.isDone()) {
                    immediateUpdate(WorksetAdapter.class, new ArrayList<DimensionsListEvent>(Collections.singletonList(prjEvent)));
                } else {
                    projectsEvents.add(prjEvent);
                }
            }

            if (baselinesFetchResult != null && !bslChanges.isEmpty()) {
                if (baselinesFetchResult.isDone()) {
                    immediateUpdate(BaselineAdapter.class, new ArrayList<DimensionsListEvent>(Collections.singletonList(bslEvent)));
                } else {
                    baselinesEvents.add(bslEvent);
                }
            }

        } finally {
            lock.unlock();
        }
    }

    private <T extends APIObjectAdapter> void immediateUpdate(Class<T> clazz, List<DimensionsListEvent> pushBackEvents) {
        // update immediately
        internalGetAndUpdate(clazz, pushBackEvents);

        // push events back to listeners
        for (IDimensionsObjectListListener listener : listeners) {
            for (DimensionsListEvent event : pushBackEvents) {
                listener.listChanged(event);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private <T extends APIObjectAdapter> FetchResult<T> internalGetAndUpdate(Class<T> clazz,
            List<DimensionsListEvent> pushBackEvents) {
        try {
            if (clazz == WorksetAdapter.class) {
                FetchResult<T> fetchResult = (FetchResult<T>) projectsFetchResult.get();
                processListEvents(fetchResult, clazz, projectsEvents, pushBackEvents);
                return fetchResult;
            } else if (clazz == BaselineAdapter.class) {
                FetchResult<T> fetchResult = (FetchResult<T>) baselinesFetchResult.get();
                processListEvents(fetchResult, clazz, baselinesEvents, pushBackEvents);
                return fetchResult;
            }
        } catch (InterruptedException e) {
        } catch (ExecutionException e) {
            DMPlugin.log(new Status(IStatus.ERROR, DMPlugin.ID, e.getCause().getMessage()));
        } finally {
            if (clazz == WorksetAdapter.class) {
                projectsEvents.clear();
            } else if (clazz == BaselineAdapter.class) {
                baselinesEvents.clear();
            }
        }

        return new FetchResult<T>();
    }

    private <T extends APIObjectAdapter> void processListEvents(FetchResult<T> fetchResult, Class<T> clazz,
            List<DimensionsListEvent> postponedEvents, List<DimensionsListEvent> pushBackEvents) {

        // process postponed events from events list
        if (postponedEvents != null) {
            for (DimensionsListEvent event : postponedEvents) {
                for (APIObjectAdapter change : event.changes) {
                    String spec = change.getObjectSpec();
                    if (clazz.isAssignableFrom(change.getClass())) {
                        switch (event.type) {
                        case DimensionsListEvent.OBJECTS_ADDED:
                            fetchResult.put(spec, resetToDeafult(clazz.cast(change), clazz));
                            break;
                        case DimensionsListEvent.OBJECTS_REMOVED:
                            fetchResult.remove(spec);
                            break;
                        case DimensionsListEvent.OBJECTS_CHANGED:
                            fetchResult.put(spec, resetToDeafult(clazz.cast(change), clazz));
                            break;
                        default:
                            break;
                        }
                    }

                }
            }
        }

        // process events that should be returned to listeners immediately
        if (pushBackEvents != null) {
            List<DimensionsListEvent> newEvents = new ArrayList<DimensionsListEvent>();

            for (DimensionsListEvent pushEvent : pushBackEvents) {

                List<APIObjectAdapter> added = new ArrayList<APIObjectAdapter>();
                List<APIObjectAdapter> changed = new ArrayList<APIObjectAdapter>();
                List<APIObjectAdapter> removed = new ArrayList<APIObjectAdapter>();

                for (APIObjectAdapter change : pushEvent.changes) {
                    if (clazz.isAssignableFrom(change.getClass())) {
                        String spec = change.getObjectSpec();
                        
                        // Do not store streams/projects if they are disallowed by connection settings
                        // (such situations happens because SccProjectContainer can be backed by stream/project)
                        Boolean isStreamAttr = (Boolean) change.getAPIObject().getAttribute(SystemAttributes.WSET_IS_STREAM);
                        if (isStreamAttr!=null) {
                            if (parentConnection.isOnlyStreamsActive() && !isStreamAttr) {
                                continue;
                            }
                            if (parentConnection.isOnlyProjectsActive() && isStreamAttr) {
                                continue;
                            }
                        }
                        
                        switch (pushEvent.type) {
                        case DimensionsListEvent.OBJECTS_ADDED:
                            addChangeToList(change, added, changed, fetchResult, clazz);
                            fetchResult.put(spec, resetToDeafult(clazz.cast(change), clazz));
                            break;
                        case DimensionsListEvent.OBJECTS_CHANGED:
                            addChangeToList(change, added, changed, fetchResult, clazz);
                            fetchResult.put(spec, resetToDeafult(clazz.cast(change), clazz));
                            break;
                        case DimensionsListEvent.OBJECTS_REMOVED:
                            fetchResult.remove(spec);
                            removed.add(change);
                            break;
                        default:
                            break;
                        }
                    }

                }

                if (!added.isEmpty()) {
                    newEvents.add(new DimensionsListEvent(pushEvent.getSource(), DimensionsListEvent.OBJECTS_ADDED,
                            added.toArray(new APIObjectAdapter[added.size()])));
                }
                if (!changed.isEmpty()) {
                    newEvents.add(new DimensionsListEvent(pushEvent.getSource(), DimensionsListEvent.OBJECTS_CHANGED,
                            changed.toArray(new APIObjectAdapter[changed.size()])));
                }
                if (!removed.isEmpty()) {
                    newEvents.add(new DimensionsListEvent(pushEvent.getSource(), DimensionsListEvent.OBJECTS_REMOVED,
                            removed.toArray(new APIObjectAdapter[removed.size()])));
                }
            }

            pushBackEvents.clear();
            pushBackEvents.addAll(newEvents);

        }

    }

    private <T extends APIObjectAdapter> void addChangeToList(APIObjectAdapter change, List<APIObjectAdapter> added,
            List<APIObjectAdapter> changed, FetchResult<T> fetchResult, Class<T> clazz) {
        String spec = change.getObjectSpec();
        if (!fetchResult.contains(spec)) {
            added.add(change);
        } else {
            T old = fetchResult.get(spec);
            if (!Utils.compareAttributes(getAttributes(clazz), old.getAPIObject(), change.getAPIObject())) {
                changed.add(change);
            }
        }
    }

    /**
     * Reset adapter to state that is allowed by search storage.
     *
     * @param adapter
     * @param clazz
     * @return
     */
    private <T extends APIObjectAdapter> T resetToDeafult(T adapter, Class<T> clazz) {
        String ideTag = (String) adapter.getAPIObject().getAttribute(SystemAttributes.IDE_TAG);
        T result = adapter;

        if (clazz == WorksetAdapter.class) {
            WorksetAdapter workset = (WorksetAdapter) adapter;

            Project apiObject = workset.getAPIObject();

            WorksetAdapter newAdapter = null;
            if (ideTag != null && ideTag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1) {
                newAdapter = new SccProjectContainerWorkset(apiObject, parentConnection, ideTag);
            } else {
                newAdapter = new WorksetAdapter(apiObject, parentConnection);
            }

            result = clazz.cast(newAdapter);
        } else if (clazz == BaselineAdapter.class) {
            BaselineAdapter baseline = (BaselineAdapter) adapter;

            Baseline apiObject = baseline.getAPIObject();

            BaselineAdapter newAdapter = null;
            if (ideTag != null) {
                newAdapter = new SccBaselineContainer(apiObject, parentConnection, ideTag);
            } else {
                newAdapter = new BaselineAdapter(apiObject, parentConnection);
            }

            result = clazz.cast(newAdapter);
        }

        result.setStoredInSearchStorage(true);
        result.setObjectList(adapter.getObjectList());
        return result;

    }

    private static <T extends APIObjectAdapter> int[] getAttributes(Class<T> clazz) {
        if (clazz == WorksetAdapter.class) {
            return DimensionsProjectsFetcher.PROJECT_ATTRIBUTES;
        } else if (clazz == BaselineAdapter.class) {
            return DimensionsBaselinesFetcher.BASELINE_ATTRIBUTES;
        } else {
            return new int[0];
        }
    }

}
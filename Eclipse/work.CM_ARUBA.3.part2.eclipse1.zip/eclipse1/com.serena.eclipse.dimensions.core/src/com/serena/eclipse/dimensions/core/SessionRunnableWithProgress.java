/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Session runnable with a progress monitor.
 *
 * @author V.Grishchenko
 */
public abstract class SessionRunnableWithProgress implements ISessionRunnable {
    protected IProgressMonitor progress;

    /**
     * Creates a new session runnable.
     * @param progress progress monitor, can be <code>null</code>
     */
    public SessionRunnableWithProgress(IProgressMonitor progress) {
        this.progress = Utils.monitorFor(progress);
    }

    /**
     * @return Returns the progress.
     */
    public IProgressMonitor getProgress() {
        return progress;
    }

}

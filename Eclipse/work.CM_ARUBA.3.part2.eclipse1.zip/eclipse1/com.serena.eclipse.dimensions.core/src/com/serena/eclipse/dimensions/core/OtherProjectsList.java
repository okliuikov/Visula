/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Non ide projects
 *
 * @author V.Grishchenko
 */
class OtherProjectsList extends WorksetList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = OtherProjectsList.class.getName();

    /**
     * Creates my pending or draft list.
     *
     * @param con
     * @param includeOnlyStreams
     *            - List will include only Streams
     * @param includeOnlyProjects
     *            - List will include only Projects.
     *            If both includeOnlyStreams and includeOnlyProjects are false then projects and streams will be included in the
     *            list.
     */
    public OtherProjectsList(DimensionsConnectionDetailsEx con, boolean includeOnlyStreams, boolean includeOnlyProjects) {
        super(con, includeOnlyStreams ? OTHER_STREAMS : includeOnlyProjects ? OTHER_PROJECTS : OTHER_PROJECTS_AND_STREAMS);
        // subscribe for ide tag so can filter ide

        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
        this.includeOnlyStreams = includeOnlyStreams;
        this.includeOnlyProjects = includeOnlyProjects;
    }

    @Override
    protected List<Project> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final Unit<List<Project>> holder = new Unit<List<Project>>();
            EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
    	    final EclipseProjectsFetcher<Project> listsEclipse = listFactory.createEclipseProjectsFetcher();
            final String includeClosedFilter = getIncludeClosedFilter();
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    List<Project> allProjects = listsEclipse.getOtherProjects(session.getConnectionDetails().getMaxRecentCount(),
                            includeClosedFilter);
                    holder.setValue(allProjects);
                }

            }, pm);
            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject workset) {
        // do not accept locked worksets
        String ideTag = (String) workset.getAttribute(SystemAttributes.IDE_TAG);
        return ideTag == null || (ideTag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) == -1 && ideTag.startsWith(";"));
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        Assert.isLegal(objectDetails instanceof ProjectDetails);
        monitor.beginTask(Messages.objectCreate_task, IProgressMonitor.UNKNOWN);
        monitor.subTask(getTypeScope().getObjectId(objectDetails));
        try {
            return session.getObjectFactory().createProject((ProjectDetails) objectDetails);
        } finally {
            monitor.done();
        }
    }

}

/*
 * @IConnectionRegistryListener.java, created on May 17, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

/**
 * @author V.Grishchenko
 */
public interface IConnectionRegistryListener {
    void connectionAdded(DimensionsConnectionDetailsEx addedCon);

    void connectionUpdated(DimensionsConnectionDetailsEx oldCon, DimensionsConnectionDetailsEx newCon);

    void connectionDeleted(DimensionsConnectionDetailsEx deletedCon);
}

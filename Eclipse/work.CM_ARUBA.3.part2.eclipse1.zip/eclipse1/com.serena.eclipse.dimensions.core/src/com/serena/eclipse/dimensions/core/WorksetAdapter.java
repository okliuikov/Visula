/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsFavouriteObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Project;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Adapter for Dimensions Worksets.
 *
 * @author V.Grishchenko - B Stephenson for Worksets
 */
public class WorksetAdapter extends VersionManagementProject implements IDeletable, IFavouriteObject {

    /**
     * Creates a new workset adapter. Simply calls super class
     * constructor with the supplied arguments.
     *
     * @param apiObject
     * @param connectionDetails
     * @see APIObjectAdapter#APIObjectAdapter(DimensionsLcObject, DimensionsConnectionDetailsEx)
     */
    public WorksetAdapter(Project toAdapt, DimensionsConnectionDetailsEx loc) {
        super(toAdapt, loc);
    }

    /**
     * @return underlying API object
     */
    @Override
    public Project getAPIObject() {
        return (Project) super.getAPIObject();
    }

    @Override
    public String getObjectSpec() {
        return getAPIObject().getName();
    }

    @Override
    public boolean isFavourite() {
        if (getAPIObject() instanceof DimensionsFavouriteObject) {

            DimensionsFavouriteObject favouriteObject = getAPIObject();

            // check in favourites list as it always up to date
            DimensionsConnectionDetailsEx loc = getConnectionDetails();
            FavouriteProjectsList list = WorksetList.getFavouriteProjectsList(loc, loc.isOnlyStreamsActive(),
                    loc.isOnlyProjectsActive());

            if (list.contains(this)) {
                favouriteObject.setFavourite(true, false);
                return true;
            } else {
                favouriteObject.setFavourite(false, false);
                return false;
            }
        }
        return false;
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    /**
     * @return underlying Project
     */
    public Project getWorkset() {
        return getAPIObject();
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.PROJECT;
    }

    /**
     * Obtains the logical baseline list for this workset. This is the baseline
     * list that contains baselines created for this workset.
     *
     * @return baseline list for this workset
     */
    @Override
    public BaselineList getBaselineList() {
        if (getParentAdapter() != null) {
            return ((WorksetAdapter) getParentAdapter()).getBaselineList();
        }
        return BaselineList.getOtherBaselinesList(getConnectionDetails());
    }

    @Override
    public void delete(IProgressMonitor monitor) throws DMException {
        super.delete(monitor);
        // a workset can be in multiple lists (group members)
        List<?> worksetListList = WorksetList.getLists(getConnectionDetails());
        for (Iterator<?> iter = worksetListList.iterator(); iter.hasNext();) {
            DimensionsObjectList aList = (DimensionsObjectList) iter.next();
            aList.removeObjects(new APIObjectAdapter[] { this });
        }
        // just remove project members, it is ok not to check if we are ide project
        WorksetList.removeDimensionsIDEProjectWorksetList(this);
    }

    @Override
    protected APIObjectAdapter doGetCopy(DimensionsObjectFactory factory) throws Exception {
        Project copy = factory.getProject(getAPIObject().getName());
        if (copy == null) {
            IStatus notFoundStatus = new Status(IStatus.ERROR, DMPlugin.ID, 0, NLS.bind(Messages.project_notfound,
                    getAPIObject().getName()), null);
            throw new DMException(notFoundStatus);
        }

        if (getAPIObject() instanceof DimensionsFavouriteObject) {
            copy.setFavourite(isFavourite(), false);
        }

        return new WorksetAdapter(copy, getConnectionDetails());
    }

}

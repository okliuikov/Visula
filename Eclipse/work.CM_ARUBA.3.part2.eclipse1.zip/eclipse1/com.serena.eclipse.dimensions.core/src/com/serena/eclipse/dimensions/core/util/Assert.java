package com.serena.eclipse.dimensions.core.util;

/**
 * A simple assertion-like convenience methods. Use it in situations when
 * Java assertion facility is not recommended (public method parameter
 * checking, etc.).
 *
 * @author V.Grishchenko
 */
public class Assert {

    /* no instances allowed */
    private Assert() {
    }

    /**
     * Asserts that an argument is legal. If the given boolean is
     * not <code>true</code>, an <code>IllegalArgumentException</code> is thrown.
     *
     * @param expression the outcode of the check
     * @return <code>true</code> if the check passes (does not return
     *         if the check fails)
     * @exception IllegalArgumentException if the legality test failed
     */
    public static boolean isLegal(boolean expression) {
        return isLegal(expression, ""); //$NON-NLS-1$
    }

    /**
     * Asserts that an argument is legal. If the given boolean is
     * not <code>true</code>, an <code>IllegalArgumentException</code> is thrown.
     * The given message is included in that exception, to aid debugging.
     *
     * @param expression the outcode of the check
     * @param message the message to include in the exception
     * @return <code>true</code> if the check passes (does not return
     *         if the check fails)
     * @exception IllegalArgumentException if the legality test failed
     */
    public static boolean isLegal(boolean expression, String message) {
        if (!expression) {
            throw new IllegalArgumentException(message);
        }
        return expression;
    }

    /**
     * Asserts that the given object is not <code>null</code>. If this
     * is not the case, some kind of unchecked exception is thrown.
     *
     * @param object the value to test
     * @exception IllegalArgumentException if the object is <code>null</code>
     */
    public static void isNotNull(Object object) {
        isNotNull(object, ""); //$NON-NLS-1$
    }

    /**
     * Asserts that the given object is not <code>null</code>. If this
     * is not the case, some kind of unchecked exception is thrown.
     * The given message is included in that exception, to aid debugging.
     *
     * @param object the value to test
     * @param message the message to include in the exception
     * @exception IllegalArgumentException if the object is <code>null</code>
     */
    public static void isNotNull(Object object, String message) {
        if (object == null) {
            throw new NullPointerException("null argument: " + message); //$NON-NLS-1$
        }
    }

}

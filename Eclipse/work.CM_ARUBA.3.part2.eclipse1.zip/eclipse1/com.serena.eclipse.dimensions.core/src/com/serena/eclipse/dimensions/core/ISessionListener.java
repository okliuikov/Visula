/*
 * @ISessionListener.java, created on Apr 13, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

/**
 * Receives notifications about session creations and destructions.
 *
 * @see com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx#addSessionListener(ISessionListener)
 * @see com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx#removeSessionListener(ISessionListener)
 * @author V.Grishchenko
 */
public interface ISessionListener {
    void sessionCreated(DimensionsConnectionDetailsEx loc);

    void sessionDestroyed(DimensionsConnectionDetailsEx loc);
}

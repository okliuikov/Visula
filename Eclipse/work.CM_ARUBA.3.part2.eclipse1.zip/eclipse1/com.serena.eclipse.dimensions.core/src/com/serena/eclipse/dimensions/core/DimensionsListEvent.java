/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.EventObject;

/**
 * @author V.Grishchenko
 */
@SuppressWarnings("serial")
public class DimensionsListEvent extends EventObject {
    public static final int OBJECTS_ADDED = 1;
    public static final int OBJECTS_REMOVED = 2;
    public static final int OBJECTS_CHANGED = 3;
    public static final int FAVOURITES_REMOVED = 4; // deletion only from favourites

    public final int type;
    public final APIObjectAdapter[] changes;

    public DimensionsListEvent(Object source, int type, APIObjectAdapter[] changes) {
        super(source);
        this.type = type;
        this.changes = changes;
    }

}

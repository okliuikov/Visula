/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmfile.dto.Unit;

/**
 * @author V.Grishchenko
 */
public class SccProjectContainerList extends WorksetList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = SccProjectContainerList.class.getName();

    public SccProjectContainerList(DimensionsConnectionDetailsEx con, boolean includeOnlyStreams, boolean includeOnlyProjects) {
        super(con, includeOnlyStreams ? SCC_STREAM_CONTAINERS :
            includeOnlyProjects ? SCC_PROJECT_CONTAINERS : SCC_PROJECT_AND_STREAM_CONTAINERS);
        this.includeOnlyStreams = includeOnlyStreams;
        this.includeOnlyProjects = includeOnlyProjects;
        // subscribe for ide tag so can filter ide
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List<Project> doFetch(final Session session, final IProgressMonitor pm) throws DMException {
        final Unit<List<Project>> holder = new Unit<List<Project>>();
        EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
	    final EclipseProjectsFetcher<Project> listsEclipse = listFactory.createEclipseProjectsFetcher();
        final String includeClosedFilter = getIncludeClosedFilter();
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    List<Project> plistss = listsEclipse.getContainersProjects(session.getConnectionDetails().getMaxRecentCount(),
                            includeClosedFilter);
                    holder.setValue(plistss);
                }

            }, pm);
        } finally {
            pm.done();
        }
        return holder.getValue();
    }

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        Project workset = (Project) dimensionsObject;
        String ideTag = (String) workset.getAttribute(SystemAttributes.IDE_TAG);
        Long ideUid = (Long) workset.getAttribute(SystemAttributes.IDE_DM_UID);

        if (ideUid == null) {
            ideUid = (Long) workset.getAttribute(SystemAttributes.OBJECT_UID);
        }

        return new SccProjectContainer(workset, getConnectionDetails(), ideTag, ideUid.toString());
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        // create as a container
        return createIdeObject(session, (DimensionsIDEProjectDetails) objectDetails, IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG, null,
                true, null, true, monitor);
    }

}

/*
 * @DMTypeScope.java, created on 10-Feb-2006
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, 2006 Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.lang.reflect.Field;

import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.BaselineDetails;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionDetails;
import com.serena.dmclient.api.Part;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.ProjectDetails;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.RequestDetails;
import com.serena.dmclient.api.RequestList;
import com.serena.dmclient.api.RequestListDetails;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmclient.objects.TypeScope;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author bstephenson
 *
 *         Class providing utilities for getting output strings and for scoping
 *         replaces dmclient TypeScope as this is non localized and uppercase only
 */
public class DMTypeScope {

    public static final DMTypeScope BASELINE = new DMTypeScope(TypeScope.BASELINE, "baseline"); //$NON-NLS-1$
    public static final DMTypeScope REQUEST = new DMTypeScope(TypeScope.REQUEST, "request"); //$NON-NLS-1$
    public static final DMTypeScope PROJECT = new DMTypeScope(TypeScope.PROJECT, "project"); //$NON-NLS-1$
    public static final DMTypeScope ITEM = new DMTypeScope(TypeScope.ITEM, "item"); //$NON-NLS-1$
    public static final DMTypeScope PART = new DMTypeScope(TypeScope.DESIGN_PART, "part"); //$NON-NLS-1$
    public static final DMTypeScope PROJECT_GROUP_MEMBER = new CompositeTypeScope(new TypeScope[] { TypeScope.PROJECT,
            TypeScope.BASELINE }, "project_group_member"); //$NON-NLS-1$
    public static final DMTypeScope REQUEST_LIST = new DMTypeScope(null, "RequestList"); //$NON-NLS-1$

    /**
     * A type scope that allows mapping to several dmclient type scopes
     */
    public static class CompositeTypeScope extends DMTypeScope {
        private TypeScope[] ids;

        CompositeTypeScope(TypeScope[] ids, String scopeString) {
            super(ids[0], scopeString);
            this.ids = ids;
        }

        public TypeScope[] getClientTypeScopes() {
            return ids.clone(); // don't leak the internal array
        }

        @Override
        public String toString() {
            String[] sa = new String[ids.length];
            for (int i = 0; i < sa.length; i++) {
                sa[i] = ids[i].toString();
            }
            return Utils.toCsvString(sa, false);
        }
    }

    // private instance variables
    private TypeScope id;
    private String objectString;
    private String objectMultipleString;
    private String objectMultipleOptionalString;

    // private constructor
    private DMTypeScope(TypeScope id, String scopeString) {
        this.id = id;
        Field objectString;
        Field objectMultipleStringField;
        Field objectMultipleOptionalString;
        try {
            objectString = Messages.class.getDeclaredField("display_" + scopeString);
            objectMultipleStringField = Messages.class.getDeclaredField("display_" + scopeString + "_multiple"); //$NON-NLS-1$ //$NON-NLS-2$
            objectMultipleOptionalString = Messages.class.getDeclaredField("display_" + scopeString + "_multiple_optional"); //$NON-NLS-1$ //$NON-NLS-2$
            this.objectString = (String) objectString.get(String.class);
            this.objectMultipleString = (String) objectMultipleStringField.get(String.class);
            this.objectMultipleOptionalString = (String) objectMultipleOptionalString.get(String.class);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public String getDisplayText() {
        return objectString;
    }

    public String getDisplayText(String objId) {
        return NLS.bind(Messages.display_withId, getDisplayText(), objId);
    }

    public String getMultipleDisplayText(boolean optional) {
        return optional ? objectMultipleOptionalString : objectMultipleString;
    }

    public TypeScope getClientTypeScope() {
        return id;
    }

    @Override
    public String toString() {
        if (id == null) {
            return getDisplayText();
        }
        return id.toString();
    }

    /**
     * @return inferred object id from the object details, can only produce
     *         correct ids for worksets and baselines, others
     *         are ok for display purposes only: "creating XYZ..."
     */
    public String getObjectId(DimensionsObjectDetails objectDetails) {
        // TODO VG on Feb 10, 2006: create subclasses? conditional is ok for now
        if (objectDetails instanceof ProjectDetails) {
            ProjectDetails worksetDetails = (ProjectDetails) objectDetails;
            return (worksetDetails.getProductName() + ':' + worksetDetails.getName()).toUpperCase();
        }
        if (objectDetails instanceof BaselineDetails) {
            BaselineDetails baselineDetails = (BaselineDetails) objectDetails;
            return (baselineDetails.getProductName() + ':' + baselineDetails.getName()).toUpperCase();
        }
        if (objectDetails instanceof RequestDetails) {
            RequestDetails documentDetails = (RequestDetails) objectDetails;
            return documentDetails.getProductName() + '_' + documentDetails.getTypeName() + "_?NUM?"; //$NON-NLS-1$
        }
        if (objectDetails instanceof ItemRevisionDetails) {
            ItemRevisionDetails revisionDetails = (ItemRevisionDetails) objectDetails;
            return revisionDetails.getProductName() + ':' + revisionDetails.getItemId() + '.' + revisionDetails.getVariant() + ';'
                    + revisionDetails.getTypeName();
        }
        if (objectDetails instanceof ERequestListDetails) {
            RequestListDetails requestListDetails = ((ERequestListDetails) objectDetails).getDetails();
            return requestListDetails.getName();
        }
        return "???";
    }

    public Class getScopeClass() {
        // static constants so can use reference ==
        if (id == TypeScope.BASELINE) {
            return Baseline.class;
        } else if (id == TypeScope.PROJECT) {
            return Project.class;
        } else if (id == TypeScope.REQUEST) {
            return Request.class;
        } else if (id == TypeScope.DESIGN_PART) {
            return Part.class;
        } else if (id == TypeScope.ITEM) {
            return ItemRevision.class;
        } else if (this == REQUEST_LIST) {
            return RequestList.class;
        } else {
            return null;
        }

    }
}

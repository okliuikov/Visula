/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Filter.Criterion;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmfile.dto.Unit;

/**
 * @author V.Grishchenko
 */
public class ProjectGroupBaselinesList extends BaselineList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = ProjectGroupBaselinesList.class.getName();

    private DimensionsIDEProjectGroup group;

    /**
     * Creates project baselines list
     *
     * @param con
     * @param draft
     */
    public ProjectGroupBaselinesList(DimensionsConnectionDetailsEx con, DimensionsIDEProjectGroup group) {
        super(con, GROUP_BASELINES);
        this.group = group;
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List<Baseline> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final Unit<List<Baseline>> holder = new Unit<List<Baseline>>();

            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    Filter blf = new Filter();
                    blf.criteria().add(new Criterion(FilterOptions.DERIVED_RELATIONSHIP, Boolean.TRUE, 0));
                    if (DMPlugin.getDefault().isFilterClosedBaselines()) {
                        addNotClosedCriterion(blf);
                    }

                    group.getWorkset().flushRelatedObjects(Baseline.class, true);
                    List<DimensionsRelatedObject> relBl = group.getWorkset().getChildBaselines(blf);
                    group.getWorkset().flushRelatedObjects(Baseline.class, true);
                    List<Baseline> realBl = new ArrayList<Baseline>();
                    for (Iterator<DimensionsRelatedObject> blrelit = relBl.iterator(); blrelit.hasNext();) {
                        realBl.add((Baseline) blrelit.next().getObject());
                    }
                    // any baselines created from the group workset
                    holder.setValue(realBl);
                }

            }, pm);

            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject doc) {
        return true;
    }

    @Override
    public String getQualifier() {
        return group.getWorkset().getName();
    }
}

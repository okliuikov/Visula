/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.CoreException;

import com.serena.dmclient.api.DimensionsArObject;

/**
 * @author V.Grishchenko
 */
public abstract class VersionManagementProject extends VersionManagementAdapter {

    /**
     * @param apiObject
     * @param connection
     */
    public VersionManagementProject(DimensionsArObject apiObject, DimensionsConnectionDetailsEx connection) {
        super(apiObject, connection);
    }

    /**
     * @return specifications for the corresponding project or baseline
     */
    public String getProjectSpec() {
        return getObjectSpec();
    }

    /**
     * Call this method to check if project is mapped to workspace. For
     * ide-info with initial=Y returns true if any of the descendants are
     * in the workspace.
     *
     * @return
     * @throws CoreException
     */
    public boolean isMapped() throws CoreException {
        return !getMappings().isEmpty();
    }

    /**
     * @return a list of <code>IMappedObjectDetails</code> objects, guaranteed
     *         not to return <code>null</code>
     */
    public List<IMappedObjectDetails> getMappings() throws CoreException {
        List<IMappedObjectDetails> result = new ArrayList<IMappedObjectDetails>();
        List<IConnectionSubscriber> subscribers = DMPlugin.getDefault().getConnectionSubscribers();
        for (Iterator<IConnectionSubscriber> iter = subscribers.iterator(); iter.hasNext();) {
            IConnectionSubscriber cSub = iter.next();
            List<? extends IMappedObjectDetails> mapped = cSub.getMappedObjectDetails(getConnectionDetails());

            for (Iterator<? extends IMappedObjectDetails> iterator = mapped.iterator(); iterator.hasNext();) {
                IMappedObjectDetails details = iterator.next();
                if (isEquivalent(details)) {
                    result.add(details);
                }
            }
        }
        return result;
    }

    protected boolean isEquivalent(IMappedObjectDetails details) {
        return getTypeScope().equals(details.getTypeScope()) && getObjectSpec().equals(details.getId());
    }

    public BaselineList getBaselineList() {
        return BaselineList.getOtherBaselinesList(getConnectionDetails());
    }

}

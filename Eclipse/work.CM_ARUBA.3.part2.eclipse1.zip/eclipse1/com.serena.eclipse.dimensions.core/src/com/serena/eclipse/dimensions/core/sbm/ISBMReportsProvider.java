package com.serena.eclipse.dimensions.core.sbm;

import java.text.DateFormat;

public interface ISBMReportsProvider {
    ISBMReport[] getSelectedReports(ISBMConnection connection);

    void saveSelectedReports(ISBMReport[] reports);

    String getSavedSolutionName();

    void saveSolutionName(String solutionName);

    void setUserDateFormat(DateFormat userDateFormat);
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.Serializable;

import com.serena.dmclient.api.IDMReportColumnType;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public class SBMProperty implements Serializable {
    static final long serialVersionUID = 2873186336293817323L;

    private String id;
    private String uuid;
    private String displayName;
    private IDMReportColumnType type = IDMReportColumnType.STRING;

    /**
     * @param id property id
     * @param uuid unique id
     * @param displayName user-friendly property display name
     * @param type property data type
     */
    public SBMProperty(String id, String uuid, String displayName, IDMReportColumnType type) {
        Assert.isNotNull(id, "id"); //$NON-NLS-1$
        Assert.isNotNull(displayName, "display name"); //$NON-NLS-1$
        this.id = id;
        this.uuid = uuid;
        this.displayName = displayName;
        this.type = type;
    }

    /**
     * @param id property id
     * @param displayName user-friendly property display name
     */
    public SBMProperty(String id, String uuid, String displayName) {
        Assert.isNotNull(id, "id"); //$NON-NLS-1$
        Assert.isNotNull(displayName, "display name"); //$NON-NLS-1$
        this.id = id;
        this.uuid = uuid;
        this.displayName = displayName;
    }

    public SBMProperty(String id, String displayName) {
        this(id, id, displayName);
    }

    public SBMProperty(String id) {
        this(id, id);
    }

    public SBMProperty(String id, IDMReportColumnType type) {
        this(id, id);
        this.type = type;
    }

    /**
     * @return property id
     */
    public String getId() {
        return id;
    }

    public String getUUID() {
        return uuid;
    }

    /**
     * @return user-friendly property display name
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * @return property type
     */
    public IDMReportColumnType getType() {
        return type;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof SBMProperty) {
            SBMProperty otherProperty = (SBMProperty) obj;
            // need to consider display name as properties from different reports may have
            // different ids but physically be the same property - this is an issue when
            // showing objects obtained from different sources in the same table, e.g. active issues
            return /* id.equals(otherProperty.id) || */displayName.equals(otherProperty.displayName);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return /* id.hashCode() ^ */displayName.hashCode();
    }

    @Override
    public String toString() {
        return "[SBMProperty] id=" + id + ";uuid=" + uuid + "; displayName=" + displayName + "; type=" + type; //$NON-NLS-1$ //$NON-NLS-2$
    }

}

package com.serena.eclipse.dimensions.core.sbm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.serena.dmclient.api.IDMReportColumnType;
import com.serena.dmclient.api.IDMReportRequest;
import com.serena.dmclient.api.IDMReportColumn;

class SBMTableDataProvider implements ISBMTableDataProvider {

    private SBMProperty[] columns;
    private ISBMValueHolder[] rows;
    private int totalCount;

    private ISBMConnection connection;
    private ISBMContainer parent;

    SBMTableDataProvider(List<IDMReportRequest> result, ISBMConnection connection, ISBMContainer parent, String reportUUID) {
    	this.connection = connection;
        this.parent = parent;
        if (result != null) {
        	totalCount = result.size();
        	fillColumns(result);
        	fillRows(result, reportUUID);
        }
    }
    
    private void fillColumns(List<IDMReportRequest> result) {
    	if(result.size()>0){
            IDMReportRequest er = result.get(0);
    		List<IDMReportColumn> idmColumns = er.getColumns();
    		
    		columns = new SBMProperty[idmColumns.size()];
    		for(int i = 0; i < idmColumns.size(); i++){
                IDMReportColumn idmColumn = idmColumns.get(i);
    			String columnName = idmColumn.getDisplayName();
    			IDMReportColumnType columnType = idmColumn.getColumnType();
    			columns[i] = new SBMProperty(columnName, columnType);
    		}
    	}
    }
    
    private void fillRows(List<IDMReportRequest> result, String reportUUID) {
    	rows = new ISBMValueHolder[result.size()];
    	for(int i = 0; i<result.size(); i++){
    		rows[i] = new SBMValueHolder(result.get(i));
    	}
    	
    }
    
    @Override
    public SBMProperty[] getColumns() {
        return columns;
    }

    @Override
    public ISBMValueHolder[] getRows() {
        return rows;
    }

    @Override
    public int getTotalCount() {
        return totalCount;
    }

    @Override
    public ISBMRequest[] getRequests() {
        List result = new ArrayList();
        if (rows != null) {
            for (int i = 0; i < rows.length; i++) {
                ISBMValueHolder holder = rows[i];
                Map values = new HashMap();
                for (int j = 0; j < columns.length; j++) {
                    SBMProperty col = columns[j];
                    values.put(col, holder.getValue(col.getId()));
                }
                result.add(SBMHelper.getRequest(connection, holder.getID(), holder.getItemID(), holder.getUrl(), holder.getTitle(),
                        holder.getSourceUUID(), columns, values, parent));
            }
        }
        return (ISBMRequest[]) result.toArray(new ISBMRequest[result.size()]);
    }

    @Override
    public List refreshRequests(List requests) {
        List result = new ArrayList();
        result.addAll(requests); // add all as non-refreshed
        if (rows != null) {
            for (int i = 0; i < rows.length; i++) {
                ISBMValueHolder holder = rows[i];
                String itemId = holder.getItemID();
                if (itemId == null) {
                    continue;
                }
                for (int j = 0; j < requests.size(); j++) {
                    Object obj = requests.get(j);
                    if (obj instanceof SBMRequest && itemId.equals(((SBMRequest) obj).getItemID())) {
                        SBMRequest request = (SBMRequest) obj;
                        request.setProperties(columns);
                        request.setID(holder.getID());
                        request.setUrl(holder.getUrl());
                        SBMProperty[] properties = request.getProperties();
                        Map propValues = request.getPropertyValues();
                        for (int k = 0; k < properties.length; k++) {
                            SBMProperty prop = properties[k];
                            String value = holder.getValue(prop.getId());
                            if (value != null) {
                                propValues.put(prop, value);
                            }
                        }
                        result.remove(request);
                        break;
                    }
                }
            }
        }
        return result;
    }

}

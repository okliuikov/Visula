/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.internal.core.IRemoteQueryAwareTreeElement;

/**
 * A baseline that contains SCC project marker files.
 *
 * @author V.Grishchenko
 */
public class SccBaselineContainer extends BaselineAdapter implements IWithAPIMembers, IRemoteQueryAwareTreeElement {

    /**
     * @param container
     *            adaptee with marker files
     * @param connection
     *            corresponding connection
     */
    private String ide;
    private boolean queryRemote = true;

    public SccBaselineContainer(Baseline container, DimensionsConnectionDetailsEx connection, String ide) {
        super(container, connection);
        this.ide = ide;
    }

    public SccBaselineContainer(Baseline container, DimensionsConnectionDetailsEx connection) {
        super(container, connection);
    }

    public SccBaselineContainer(BaselineAdapter adapter) {
        super(adapter.getBaseline(), adapter.getConnectionDetails());
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    public String getIde() {
        return ide;
    }

    public String getIdeUid() {
        Long uid = (Long) getAPIObject().getAttribute(SystemAttributes.IDE_DM_UID);
        return uid.toString();
    }

    public SccProjectList getMemberList() {
        return SccProjectList.getProjectList(this);
    }

    @Override
    public APIObjectAdapter[] getMembers(final IProgressMonitor monitor) {
        DimensionsConnectionDetailsEx loc = getConnectionDetails();
        final SccBaselineContainer sccBl = this;
        final APIObjectAdapter[][] remoteProjects = new APIObjectAdapter[1][];
        try {
            final Session session = loc.openSession(monitor);

            session.run(new ISessionRunnable() {
                @Override
                public void run() throws DMException {
                    sccBl.getMemberList().fetch(monitor);
                    remoteProjects[0] = sccBl.getMemberList().getObjects();
                }
            }, monitor);
        } catch (DMException e1) {
            DMPlugin.log(e1.getStatus());
        }
        return remoteProjects[0];
    }

    @Override
    public boolean isQueryRemote() {
        return queryRemote;
    }

    @Override
    public void setQueryRemote(boolean queryRemote) {
        this.queryRemote = queryRemote;
    }

}

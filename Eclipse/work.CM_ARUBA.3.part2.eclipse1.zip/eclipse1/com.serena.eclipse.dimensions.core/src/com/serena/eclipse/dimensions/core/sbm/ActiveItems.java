/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2008 - 2020 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.core.sbm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import merant.adm.dimensions.cmds.AdmResult;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.DimensionsConnectionException;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.IDMRequest;
import com.serena.dmclient.api.RequestListDetails;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.WorkingIDMRequestList;
import com.serena.eclipse.dimensions.core.APIOperation;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.ISessionRunnable;
import com.serena.eclipse.dimensions.core.Session;
import com.serena.eclipse.dimensions.core.util.Utils;

class ActiveItems extends SBMContainer implements ISBMActiveItemsHolder {
    static final long serialVersionUID = 1797365515265060446L;

    public static String MY_WORKING_LIST = "MY_WORKING"; //$NON-NLS-1$

    DimensionsConnectionDetailsEx connection = null;
    private WorkingIDMRequestList workingList = null;
    private List activatedRequests = null;

    public ActiveItems(DimensionsConnectionDetailsEx connection) {
        super(connection.getSBMConnection(), SBMManager.getActiveItemsUrl(connection), null);
        this.connection = connection;
    }

    @Override
    public int getType() {
        return ACTIVE_ITEMS;
    }

    @Override
    protected String getMembersUrl() {
        return null; // no members to fetch from the server
    }

    @Override
    public List getMembers() throws SBMException {
        if (activatedRequests == null) {
            try {
                loadActiveRequests(null);
            } catch (DMException e) {
                throw new SBMException(e.getStatus());
            }
        }
        return Collections.unmodifiableList(activatedRequests);
    }

    @Override
    public void refresh(IProgressMonitor monitor) throws SBMException {
        try {
            activatedRequests = null;
            loadActiveRequests(monitor);
        } catch (DMException e) {
            throw new SBMException(e.getStatus());
        }
    }

    @Override
    public String getDisplayUrl() {
        // no server context - just use sbm home
        return getConnection().getDisplayUrl();
    }

    @Override
    public SBMProperty[] getColumns() throws SBMException {
        ArrayList allProperties = new ArrayList();
        List requests = getMembers();
        if (requests == null) {
            return new SBMProperty[0];
        }

        for (Iterator iter = requests.iterator(); iter.hasNext();) {
            Object element = iter.next();
            if (element instanceof ISBMRequest) {
                ISBMRequest req = (ISBMRequest) element;
                SBMProperty[] properties = req.getProperties();
                for (int k = 0; k < properties.length; k++) {
                    if (!allProperties.contains(properties[k])) {
                        allProperties.add(properties[k]);
                    }
                }
            }
        }
        return (SBMProperty[]) allProperties.toArray(new SBMProperty[allProperties.size()]);
    }

    @Override
    public ISBMRequest findRequest(String id) throws SBMException {
        if (id == null) {
            return null;
        }
        List requests = getMembers();
        if (requests == null) {
            return null;
        }
        for (Iterator iter = requests.iterator(); iter.hasNext();) {
            Object element = iter.next();
            if (element instanceof ISBMRequest) {
                ISBMRequest req = (ISBMRequest) element;
                if (id.equalsIgnoreCase(req.getID())) {
                    return req;
                }
            }
        }
        return null;
    }

    public void removeFromActiveRequests(final ISBMRequest[] items) throws DMException {
        if (workingList == null) {
            workingList = getWorkingList(connection, null);
        }
        if (workingList != null) {
            final Session session = connection.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    List idm_requests = new ArrayList();
                    for (int i = 0; i < items.length; i++) {
                        ISBMRequest request = items[i];
                        IDMRequest idm_request = session.getObjectFactory().findIDMRequestBySpec(request.getID(),
                                request.getItemID(), request.getUrl(), request.getTitle(), request.getSourceUUID());
                        if (idm_request != null) {
                            idm_requests.add(idm_request);
                        }
                    }
                    DimensionsResult res = null;
                    try {
                        // TODO should remove the entire ActiveItems class, it doesn't seem needed any more
                        res = workingList.removeIDMRequests(idm_requests, connection.getSbmToolUID());
                    } catch (DimensionsConnectionException ex) {
                        workingList = getWorkingList(connection, null); // get workingList for up-to-date connection
                        res = workingList.removeIDMRequests(idm_requests, connection.getSbmToolUID());
                    }
                    if (res != null) {
                        AdmResult admRes = res.getAdmResult();
                        if (admRes != null) {
                            Object obj = admRes.getUserData();
                            if (obj instanceof List) {
                                removeRequestsWithMatchedIds(items, (List) obj);
                                getManager().fireEvent(ActiveItems.this, SBMEvent.STRUCTURE_CHANGE);
                            }
                        }
                    }
                }

            }, null);
        }
    }

    public void addToActiveRequests(final ISBMRequest[] items) throws DMException {
        if (workingList == null) {
            workingList = getWorkingList(connection, null);
        }
        if (workingList != null) {
            final Session session = connection.openSession(null);
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    List idm_requests = new ArrayList();
                    for (int i = 0; i < items.length; i++) {
                        ISBMRequest request = items[i];
                        IDMRequest idm_request = session.getObjectFactory().findIDMRequestBySpec(request.getID(),
                                request.getItemID(), request.getUrl(), request.getTitle(), request.getSourceUUID());
                        if (idm_request != null) {
                            idm_requests.add(idm_request);
                        }
                    }
                    DimensionsResult res = null;
                    try {
                        res = workingList.addIDMRequests(idm_requests, connection.getSbmToolUID());
                    } catch (DimensionsConnectionException ex) {
                        workingList = getWorkingList(connection, null); // get workingList for up-to-date connection
                        res = workingList.addIDMRequests(idm_requests, connection.getSbmToolUID());
                    }
                    if (res != null) {
                        AdmResult admRes = res.getAdmResult();
                        if (admRes != null) {
                            Object obj = admRes.getUserData();
                            if (obj instanceof List) {
                                addRequestsWithMatchedIds(items, (List) obj);
                                getManager().fireEvent(ActiveItems.this, SBMEvent.STRUCTURE_CHANGE);
                            }
                        }
                    }
                }

            }, null);

        }
    }

    private void addRequestsWithMatchedIds(ISBMRequest[] items, List ids) {
        if (activatedRequests == null || ids == null) {
            return;
        }
        for (int i = 0; i < items.length; i++) {
            ISBMRequest request = items[i];
            if (ids.contains(request.getID())) {
                activatedRequests.add(request);
            }
        }
    }

    private void removeRequestsWithMatchedIds(ISBMRequest[] items, List ids) {
        if (activatedRequests == null || ids == null) {
            return;
        }
        for (int i = 0; i < items.length; i++) {
            ISBMRequest request = items[i];
            if (ids.contains(request.getID())) {
                if (activatedRequests.contains(request)) {
                    activatedRequests.remove(request);
                }
            }
        }
    }

    private void loadActiveRequests(IProgressMonitor monitor) throws DMException {
        if (workingList == null) {
            workingList = getWorkingList(connection, monitor);
        }
        if (workingList != null) {
            boolean reloadFromWebServices = false;
            if (activatedRequests == null) {
                activatedRequests = new ArrayList();
                reloadFromWebServices = true;
            }
            List idm_requests = readIDMRequests(connection, monitor);
            if (idm_requests != null) {
                activatedRequests.clear();
                for (Iterator iter = idm_requests.iterator(); iter.hasNext();) {
                    IDMRequest idm_request = (IDMRequest) iter.next();
                    Map values = new HashMap();
                    values.put(SBMClientHelper.DEFAULT_IDM_REQUEST_PROPERTIES[0], idm_request.getName());
                    values.put(SBMClientHelper.DEFAULT_IDM_REQUEST_PROPERTIES[1], idm_request.getTitle());
                    activatedRequests.add(SBMHelper.getRequest(getConnection(), idm_request.getName(), idm_request.getID(),
                            idm_request.getItemUrl(), idm_request.getTitle(), idm_request.getReportUUID(),
                            SBMClientHelper.DEFAULT_IDM_REQUEST_PROPERTIES, values, this));

                }
            }
            if (reloadFromWebServices && setConnection(monitor)) {
                try {
                    SBMClientHelper helper = new SBMClientHelper(getConnection());
                    helper.refreshRequests(activatedRequests, this);
                } catch (Exception ex) {
                    throw new DMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0,
                            "Encountered error while refreshing requests", ex));
                }
            }
        }
    }

    private List readIDMRequests(DimensionsConnectionDetailsEx con, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask("Looking up for favorite requests...", IProgressMonitor.UNKNOWN);
        try {
            final Session session = con.openSession(Utils.subMonitorFor(monitor, 10));
            final List[] listHolder = new List[1];
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    try {
                        listHolder[0] = workingList.getIDMRequests();
                    } catch (DimensionsConnectionException ex) {
                        workingList = getWorkingList(connection, null); // get workingList for up-to-date connection
                        listHolder[0] = workingList.getIDMRequests();
                    }
                }

            }, monitor);

            return listHolder[0];
        } finally {
            monitor.done();
        }
    }

    private boolean setConnection(IProgressMonitor pm) {
        if (connection == null) {
            return false;
        }
        if (!connection.isSessionOpen()) {
            try {
                connection.openSession(pm);
            } catch (DMException pe) {
                DMPlugin.log(pe.getStatus());
                return false;
            }
        }
        if (connection.isSessionOpen()) {
            ISBMConnection sbmc = getConnection();
            if (sbmc == null) {
                return false;
            }
            if (!sbmc.isAuthenticated()) {
                Utils.monitorFor(pm).setTaskName("Connecting to " + sbmc.getUrl());
                try {
                    if (!sbmc.authenticate(true, pm)) {
                        return false;
                    }
                } catch (SBMException e) {
                    DMPlugin.log(e.getStatus());
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    private WorkingIDMRequestList getWorkingList(DimensionsConnectionDetailsEx con, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask("Looking up for favorite requests...", IProgressMonitor.UNKNOWN);
        try {
            final Session session = con.openSession(Utils.subMonitorFor(monitor, 10));
            final WorkingIDMRequestList[] listHolder = new WorkingIDMRequestList[1];
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    listHolder[0] = lookupWorkingList(session.getObjectFactory());
                }

            }, monitor);

            if (listHolder[0] == null) {
                // create
                session.run(new APIOperation("Creating favorite requests list") {
                    @Override
                    protected DimensionsResult doRun() throws Exception {
                        return session.getObjectFactory().createWorkingIDMRequestList(new RequestListDetails(MY_WORKING_LIST));
                    }
                }, monitor);

                // lookup again
                session.run(new ISessionRunnable() {
                    @Override
                    public void run() throws Exception {
                        listHolder[0] = lookupWorkingList(session.getObjectFactory());
                    }

                }, monitor);
            }

            if (listHolder[0] == null) {
                throw new DMException(IStatus.ERROR, 0, "Cannot obtain favorite requests list", null);
            }

            return listHolder[0];
        } finally {
            monitor.done();
        }
    }

    private WorkingIDMRequestList lookupWorkingList(DimensionsObjectFactory factory) {
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_ID, MY_WORKING_LIST, Filter.Criterion.EQUALS));
        List cLists = factory.getCurrentUser().getWorkingIDMRequestLists(filter);
        return cLists.isEmpty() ? null : (WorkingIDMRequestList) cLists.get(0);
    }

}
/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Interprets web-page XML payload.
 *
 * @author V.Grishchenko
 */
abstract class XMLPayloadManager extends SBMManager {

    // These are used in constructing the XML document for the associate request.
    private static final String ASSOCIATIONS_TAG = "associations";//$NON-NLS-1$
    private static final String INTEGRATION_ATTR_NAME = "integration";//$NON-NLS-1$
    // TT defines no specific value for DM so use generic
    private static final String INTEGRATION_ATTR_VAL = "Generic (SourceBridge)"; //$NON-NLS-1$
    private static final String ASSOCIATION_TAG = "association";//$NON-NLS-1$
    private static final String INDEX_ATTR_NAME = "index";//$NON-NLS-1$
    private static final String TTITEMS_TAG = "ttitems";//$NON-NLS-1$
    private static final String ITEM_TAG = "item";//$NON-NLS-1$
    private static final String TABLE_ATTR_NAME = "tbl";//$NON-NLS-1$
    private static final String RECORD_ATTR_NAME = "rec";//$NON-NLS-1$
    private static final String FILES_TAG = "files";//$NON-NLS-1$
    private static final String FILE_TAG = "file";//$NON-NLS-1$
    private static final String COMMENT_TAG = "comment";//$NON-NLS-1$
    private static final String ACTION_ATTR_NAME = "action";//$NON-NLS-1$
    private static final String SERVER_ATTR_NAME = "server";//$NON-NLS-1$
    private static final String ASSET_ATTR_NAME = "asset";//$NON-NLS-1$
    private static final String NAME_ATTR_NAME = "name";//$NON-NLS-1$
    private static final String REVISION_IN_ATTR_NAME = "revin";//$NON-NLS-1$
    private static final String REVISION_OUT_ATTR_NAME = "revout";//$NON-NLS-1$
    private static final String TAG = "tag";//$NON-NLS-1$
    private static final String TAG_LIST = "taglist";//$NON-NLS-1$
    private static final String TYPE_ATTR_NAME = "type";//$NON-NLS-1$
    private static final String FORMAT_ATTR_NAME = "format";//$NON-NLS-1$
    private static final String DESCR_ATTR_NAME = "descr";//$NON-NLS-1$
    private static final String LABEL_ATTR_NAME = "label";//$NON-NLS-1$
    private static final String LABEL_FORMAT_ATTR_NAME = "$id";//$NON-NLS-1$

    static interface InputStreamHelper {
        InputStream getInputStream(String url, IProgressMonitor monitor) throws SBMException;
    }

    /**
     * @param connection
     */
    public XMLPayloadManager(DimensionsConnectionDetailsEx con) {
        super(con);
    }

    protected abstract InputStreamHelper getContainerMembersHelper();

    protected abstract InputStreamHelper getAssociateHelper(String associateRequest);

    @Override
    public void associate(AssociateInput input, IProgressMonitor monitor) throws SBMException {
        String associateRequest = createAssociateRequest(input);
        AssociateHanlder handler = new AssociateHanlder(getConnection());
        processXMLFromUrl(getConnection().getUrl(), getAssociateHelper(associateRequest), handler, monitor);
    }

    @Override
    protected List fetchContainerMembers(ISBMContainer container, IProgressMonitor monitor) throws SBMException {
        ArrayList result = new ArrayList();
        CompositeHandler handler = new CompositeHandler(getConnection(), container);
        processXMLFromUrl(((SBMContainer) container).getMembersUrl(), getContainerMembersHelper(), handler, monitor);
        result.addAll(handler.getReports());
        result.addAll(handler.getRequests());
        return result;
    }

    private void processXMLFromUrl(String url, InputStreamHelper helper, SBMContentHandler handler, IProgressMonitor monitor)
            throws SBMException {

        monitor = Utils.monitorFor(monitor);
        boolean debug = DMPlugin.getDefault().isSBMDebugEnabled();
        int attempts = 0;
        boolean doAttempt = true;
        while (doAttempt) {
            InputStream in = null;
            try {
                in = helper.getInputStream(url, monitor);

                SAXParserFactory factory = SAXParserFactory.newInstance();
                SAXParser parser = factory.newSAXParser();
                InputSource inputSource = getInputSource(in);
                parser.parse(inputSource, handler);

                // Handle the return code, if any.
                int retCode = handler.getTTReturnCode();
                if (retCode != SBMStatus.TEAMTRACK_OK) {
                    if (debug) {
                        System.out.println("[XMLPayloadManager] returnCode=" + retCode);
                    }
                    IStatus errorStatus = new SBMStatus(retCode, null);
                    if (retCode == SBMStatus.INVALID_USER) {
                        if (debug) {
                            System.out.println("[XMLPayloadManager] received invalid user result code in xml"); //$NON-NLS-1$
                        }

                        if (!monitor.isCanceled()) {
                            if (attempts < MAX_LOGIN_ATTEMPTS && !isAuthenticating()) { // do not retry when testing login params or
                                                                                        // exceeded allowed number
                                if (debug) {
                                    System.out.println("[XMLPayloadManager] about to attempt to obtain login credentials."); //$NON-NLS-1$
                                }
                                IStatus promptStatus = promptForCredentials(createChallengeDetails(), errorStatus);
                                if (promptStatus.isOK()) {
                                    if (debug) {
                                        String username = getConnection().getDetails().getUser();
                                        String password = getConnection().getDetails().getPassword();
                                        if (password == null) {
                                            password = Utils.EMPTY_STRING;
                                        }
                                        String domain = getConnection().getDetails().getDomain();
                                        if (domain == null) {
                                            domain = Utils.EMPTY_STRING;
                                        }
                                        System.out.println("[XMLPayloadManager] username=" + username
                                                + "; password=" + password.length() + "chars" + "; domain=" + domain); //$NON-NLS-1$
                                    }
                                    attempts++;
                                    handler.recycle();
                                    continue;
                                }
                                errorStatus = promptStatus;
                            } else {
                                errorStatus = new SBMStatus(IStatus.ERROR, DMPlugin.ID, SBMStatus.INVALID_USER,
                                        "Authentication failed. Maximum number of login attempts exceeded.", null);
                            }
                        } else {
                            errorStatus = new SBMStatus(IStatus.CANCEL, DMPlugin.ID, SBMStatus.INVALID_USER,
                                    "Authentication failed. Operation was cancelled by user", null);
                        }
                        getConnection().getDetails().setPassword(null); // auth failed - clear password
                        if (debug) {
                            System.out.println("[XMLPayloadManager] authentication failed " + errorStatus); //$NON-NLS-1$
                        }
                    }
                    throw new SBMException(errorStatus);
                }
                doAttempt = false;
            } catch (IOException e) {
                throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while parsing XML", e));
            } catch (ParserConfigurationException e) {
                throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while parsing XML", e));
            } catch (SAXException e) {
                throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while parsing XML", e));
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ignore) {
                    }
                }
            }
            // attempts++;
        }
        setAuthenticated(true); // if we got here it means authentication succeeded
    }

    /**
     * This method answers <code>true</code> if there is no password previously set.
     *
     * @return <code>true</code> if should prompt for login credentials before hitting the server
     */
    protected boolean shouldPromptPreemptive() {
        return getConnection().getDetails().getPassword() == null;
    }

    /**
     * Construct the parser inputSource from the input stream. The input stream
     * is undecoded bytes that must be UTF-8 decoded prior to being sent to the
     * XML parser.
     *
     * @param inStream
     *            The raw byte stream
     * @return inputSource The parser input
     */
    protected InputSource getInputSource(InputStream inStream) throws IOException {
        InputSource _inSource = new InputSource(inStream);
        _inSource.setEncoding("UTF-8"); //$NON-NLS-1$
        return _inSource;
    }

    private ChallengeDetails createChallengeDetails() {
        ChallengeDetails result = new ChallengeDetails(ChallengeDetails.USERNAME | ChallengeDetails.PASSWORD,
                getConnection().getDetails().getWebUrl(), 0, ChallengeDetails.SERVER, null, "XML"); //$NON-NLS-1$
        result.username = getConnection().getDetails().getUser();
        return result;
    }

    private Element createAssociationElement(Document xmlDoc, int idx, String comment, SBMItemId[] items, ActionDetails[] actions) {
        // Create the containing "index" element and add it to the root
        Element assocElement = xmlDoc.createElement(ASSOCIATION_TAG);
        assocElement.setAttribute(INDEX_ATTR_NAME, String.valueOf(idx));
        assocElement.setAttribute(SERVER_ATTR_NAME, getConnection().getConnectionDetails().getServer());

        // Create the TeamTrack issues element, and add it to the index element.
        // All issue items are contained within this element.
        Element itemsElement = xmlDoc.createElement(TTITEMS_TAG);
        assocElement.appendChild(itemsElement);

        // Add all of the TeamTrack issues.
        for (int i = 0; i < items.length; i++) {
            Element issueElement = xmlDoc.createElement(ITEM_TAG);
            issueElement.setAttribute(TABLE_ATTR_NAME, items[i].getTableIdAsString());
            issueElement.setAttribute(RECORD_ATTR_NAME, items[i].getRecordIdAsString());
            itemsElement.appendChild(issueElement);
        }

        // Create and append the Files element. All checked-in files
        // are contained within this element.
        Element filesElement = xmlDoc.createElement(FILES_TAG);
        assocElement.appendChild(filesElement);

        // use global comment, if provided
        boolean globalComment = !Utils.isNullEmpty(comment);
        if (globalComment) {
            Element commentElement = xmlDoc.createElement(COMMENT_TAG);
            commentElement.appendChild(xmlDoc.createTextNode(comment));
            filesElement.appendChild(commentElement);
        }

        // Next, add all of the files that were checked in.
        for (int i = 0; i < actions.length; i++) {
            Element fileElement = xmlDoc.createElement(FILE_TAG);
            fileElement.setAttribute(ACTION_ATTR_NAME, actions[i].getAction());
            fileElement.setAttribute(ASSET_ATTR_NAME, String.valueOf(actions[i].getAssetId()));
            fileElement.setAttribute(NAME_ATTR_NAME, actions[i].getPath());
            if (!Utils.isNullEmpty(actions[i].getPrevRevision())) {
                fileElement.setAttribute(REVISION_OUT_ATTR_NAME, actions[i].getPrevRevision());
            }
            if (!Utils.isNullEmpty(actions[i].getNewRevision())) {
                fileElement.setAttribute(REVISION_IN_ATTR_NAME, actions[i].getNewRevision());
            }

            // create comment element unless using one comment for all actions
            if (!globalComment && !Utils.isNullEmpty(actions[i].getComment())) {
                Element commentElement = xmlDoc.createElement(COMMENT_TAG);
                commentElement.appendChild(xmlDoc.createTextNode(actions[i].getComment()));
                fileElement.appendChild(commentElement);
            }

            // Add this new file element to the files node
            filesElement.appendChild(fileElement);
        }

        return assocElement;
    }

    private String createAssociateRequest(AssociateInput input) throws SBMException {
        // sort into "associate" buckets, each bucket contains actions to be associated with the same set of sbm items
        HashMap actionsByItems = new HashMap();
        ActionDetails[] allActions = input.getActions();
        for (int i = 0; i < allActions.length; i++) {
            HashSet itemSet = new HashSet(allActions[i].getItemIds());
            List actions = (List) actionsByItems.get(itemSet);
            if (actions == null) {
                actions = new ArrayList();
                actionsByItems.put(itemSet, actions);
            }
            actions.add(allActions[i]);
        }

        String retVal = null;
        try {
            DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder domBuilder = domFactory.newDocumentBuilder();

            // Next, create the document.
            Document xmlDoc = domBuilder.newDocument();

            // Create the Root element
            Element rootElement = xmlDoc.createElement(ASSOCIATIONS_TAG);
            rootElement.setAttribute(INTEGRATION_ATTR_NAME, INTEGRATION_ATTR_VAL);
            xmlDoc.appendChild(rootElement);

            int idx = 1;
            for (Iterator iter = actionsByItems.entrySet().iterator(); iter.hasNext();) {
                Map.Entry entry = (Map.Entry) iter.next();
                HashSet items = (HashSet) entry.getKey();
                List actions = (List) entry.getValue();
                Element assocElement = createAssociationElement(xmlDoc, idx, input.getComment(),
                        (SBMItemId[]) items.toArray(new SBMItemId[items.size()]),
                        (ActionDetails[]) actions.toArray(new ActionDetails[actions.size()]));
                rootElement.appendChild(assocElement);
                idx++;
            }

            // The document has been constructed; convert it to a String.
            TransformerFactory tranFactory = TransformerFactory.newInstance();
            Transformer transformer = tranFactory.newTransformer();

            Source src = new DOMSource(xmlDoc);
            StringWriter writer = new StringWriter();
            Result dest = new StreamResult(writer);
            transformer.transform(src, dest);
            String fullDoc = writer.toString();

            // We want to return the XML without the prolog, i.e. "<?xml version="1.0" encoding="UTF-8" ?>"
            retVal = fullDoc.substring(fullDoc.indexOf("<" + ASSOCIATIONS_TAG));//$NON-NLS-1$

        } catch (DOMException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Error creating XML request for Associate", e));
        } catch (TransformerConfigurationException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Error creating XML request for Associate", e));
        } catch (FactoryConfigurationError e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Error creating XML request for Associate", e));
        } catch (ParserConfigurationException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Error creating XML request for Associate", e));
        } catch (TransformerFactoryConfigurationError e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Error creating XML request for Associate", e));
        } catch (TransformerException e) {
            throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Error creating XML request for Associate", e));
        }

        return retVal;
    }

}

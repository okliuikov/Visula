package com.serena.eclipse.dimensions.core.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.serena.dmfile.StringPath;

/**
 * Splits string by comma, space or space and comma in different combinations.
 */
public class SpaceCommaStringSplitter {

    public enum ResultCase {
        UPPER,
        LOWER,
        UNMODIFIED
    }

    /**
     * Possible delimiters: space, comma or space and comma in different combinations.
     */
    private static final Pattern PATTERN = Pattern.compile("\\s*([^,\\s]+)(\\s*,\\s*|\\s+|$)");

    private static final Comparator<CharSequence> DEFAULT_COMPARATOR = new Comparator<CharSequence>() {

        @Override
        public int compare(CharSequence o1, CharSequence o2) {
            return o1.toString().compareTo(o2.toString());
        }
    };

    private SpaceCommaStringSplitter() {
    }

    /**
     * @param string to split
     * @param resultCase case of strings in the result set
     * @return unordered collection of trimmed strings that were converted to {@link ResultCase}
     */
    public static Collection<String> split(String string, ResultCase resultCase) {
        List<String> result = new ArrayList<String>();
        if (StringPath.isNullorEmpty(string)) {
            return result;
        }

        split(string, result, resultCase);

        return result;
    }

    /**
     *
     * @param string to split
     * @param resultCase case of strings in the result set
     * @param comparator if null uses lexicographical comparison
     * @return ordered collection of unique trimmed strings that were converted to {@link ResultCase}
     */
    public static Collection<String> splitUnique(String string, ResultCase resultCase, Comparator<CharSequence> comparator) {
        if (comparator == null) {
            comparator = DEFAULT_COMPARATOR;
        }

        Set<String> result = new TreeSet<String>(comparator);
        if (StringPath.isNullorEmpty(string)) {
            return result;
        }

        split(string, result, resultCase);

        return result;
    }

    private static void split(String string, Collection<String> result, ResultCase resultCase) {
        Matcher mathcer = PATTERN.matcher(string.trim());
        while (mathcer.find()) {
            String group = mathcer.group(1).trim();
            if (!StringPath.isNullorEmpty(group)) {
                if (resultCase == ResultCase.UPPER) {
                    group = group.toUpperCase();
                } else if (resultCase == ResultCase.LOWER) {
                    group = group.toLowerCase();
                }
                result.add(group);
            }
        }
    }

}

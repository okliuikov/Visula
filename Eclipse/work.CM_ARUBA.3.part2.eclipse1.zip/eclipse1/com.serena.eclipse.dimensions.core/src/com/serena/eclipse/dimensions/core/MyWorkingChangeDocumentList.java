/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.WorkingCMRequestList;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author S. Korneychuk
 */
public class MyWorkingChangeDocumentList extends ChangeDocumentList {
    public static String MY_WORKING_LIST = "MY_WORKING"; //$NON-NLS-1$

    private String listName;
    private String qualifier;
    private QualifiedName listKey;

    MyWorkingChangeDocumentList(DimensionsConnectionDetailsEx con, WorkingCMRequestList list, int type) {
        super(con, type);
        Assert.isLegal(type == WORKING_CM_ISSUES);
        this.listName = MY_WORKING_LIST; // first approach we have just one list
        this.listKey = new QualifiedName(MyWorkingChangeDocumentList.class.getName(), listName);
        cacheList(list);
    }

    @Override
    protected List doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final List[] result = new List[1];

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    WorkingCMRequestList list = getWorkingCMRequestList(session);
                    result[0] = list != null ? list.getRequests() : Collections.EMPTY_LIST;
                }

            }, pm);

            return result[0];
        } finally {
            pm.done();
        }
    }

    @Override
    public String getQualifier() {
        return qualifier;
    }

    /**
     * Adds change document to this list.
     *
     * @param changeDocs
     *            a list of <code>ChangeDocumentAdapter</code>(s)
     * @throws DMException
     */
    public void addChangeDocuments(List changeDocs, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        try {
            monitor.beginTask(null, 100);
            final Session session = getConnectionDetails().openSession(Utils.subMonitorFor(monitor, 10));
            final List apiList = new ArrayList(changeDocs.size());
            APIObjectAdapter[] adapters = new ChangeDocumentAdapter[changeDocs.size()];

            for (int i = 0; i < changeDocs.size(); i++) {
                Request changeDocument = ((ChangeDocumentAdapter) changeDocs.get(i)).getChangeDocument();
                apiList.add(changeDocument);
                // need to create a new adapter so that the original keeps its list
                adapters[i] = session.adapt(changeDocument);
            }

            session.run(new APIOperation(NLS.bind(Messages.requestList_add, listName)) {

                @Override
                protected DimensionsResult doRun() throws Exception {
                    WorkingCMRequestList list = getWorkingCMRequestList(session);
                    return list != null ? list.addRequests(apiList) : new DimensionsResult(NLS.bind(Messages.requestList_notFound,
                            listName));
                }

            }, monitor);

            monitor.worked(45);
            // add to local cache and notify listeners
            addObjects(adapters);
            update(Utils.subMonitorFor(monitor, 45)); // make sure attributes are cached
        } finally {
            monitor.done();
        }
    }

    public void removeChangeDocuments(final List changeDocs) throws DMException {
        final ChangeDocumentAdapter[] apiObjectList = new ChangeDocumentAdapter[changeDocs.size()];
        final Session session = getConnectionDetails().openSession(null);

        session.run(new APIOperation(NLS.bind(Messages.requestList_remove, listName)) {

            @Override
            public DimensionsResult doRun() throws Exception {
                List apiList = new ArrayList();
                for (int i = 0; i < changeDocs.size(); i++) {
                    ChangeDocumentAdapter changeDocument = (ChangeDocumentAdapter) changeDocs.get(i);
                    apiObjectList[i] = changeDocument;
                    apiList.add(changeDocument.getAPIObject());
                }
                WorkingCMRequestList list = getWorkingCMRequestList(session);
                return list != null ? list.removeRequests(apiList) : new DimensionsResult(NLS.bind(Messages.requestList_notFound,
                        listName));
            }

        }, new NullProgressMonitor());

        removeObjects(apiObjectList);
    }

    private WorkingCMRequestList getWorkingCMRequestList(Session session) throws DMException {
        WorkingCMRequestList result = getCachedList();
        if (result != null) {
            return result;
        }
        // old handle was likely purged due to a disconnect - obtain a new copy
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_ID, listName, Filter.Criterion.EQUALS));
        List lists = session.getObjectFactory().getCurrentUser().getWorkingCMRequestLists(filter);
        if (lists.isEmpty()) {
            return null;
        }
        result = (WorkingCMRequestList) lists.get(0);
        cacheList(result);
        return result;
    }

    private void cacheList(WorkingCMRequestList list) {
        getConnectionDetails().setSessionProperty(listKey, list);
    }

    private WorkingCMRequestList getCachedList() {
        return (WorkingCMRequestList) getConnectionDetails().getSessionProperty(listKey);
    }

}

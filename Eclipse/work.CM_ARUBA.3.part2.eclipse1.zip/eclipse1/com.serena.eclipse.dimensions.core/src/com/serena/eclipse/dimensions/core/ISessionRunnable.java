/*
 * @ISessionRunnable.java, created on May 19, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

/**
 * <P>
 * Represents a task that can be by a Dimensions session, typically the run method should contain calls to dmclient API.
 *
 * @author V.Grishchenko
 * @see com.serena.eclipse.dimensions.core.Session#run(ISessionRunnable)
 * @see com.serena.eclipse.dimensions.core.IConsoleOperation
 * @see com.serena.eclipse.dimensions.core.ConsoleOperation
 * @see com.serena.eclipse.dimensions.core.APIOperation
 */
public interface ISessionRunnable {
    /**
     * <p>
     * Runs the runnable.
     * <p>
     * If this method creates new threads they should not call <code>Session.run(ISessionRunnable task)</code> as this will lead to
     * deadlocks. See javadoc for <code>Session.run(ISessionRunnable task)</code> for more information.
     *
     * @throws Exception
     * @see Session#run(ISessionRunnable)
     */
    void run() throws Exception;
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IStatus;

/**
 * @author V.Grishchenko
 */
public interface IDMConsoleListener {
    /**
     * @return <code>true</code> if <code>operationStarted</code> has been
     *         called but not one of the <code>operationCompleted</code>
     */
    boolean isOperaionStarted();

    /**
     * Notifies the console that operation started
     * @param message
     */
    void operationStarted(String message);

    /**
     * Outputs status to the console.
     * @param status
     * @param e
     */
    void operationCompleted(IStatus status, Exception e);

    /**
     * Outputs message to the console.
     * @param message
     */
    void printMessage(String message);

    /**
     * Outputs error to the console.
     * @param error
     */
    void printError(String error);
}

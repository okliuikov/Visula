/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ResourceBundle;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

/**
 * Base class, provides access to execution status and message that are to
 * be printed to console.
 *
 * @author V.Grishchenko
 */
public abstract class ConsoleOperation implements IConsoleOperation {
    private String message;
    protected IStatus status = Status.OK_STATUS;

    public ConsoleOperation(String message) {
        this.message = message;
    }

    public ConsoleOperation(ResourceBundle bundle) {
        String key = getClass().getName();
        int lastDot = key.lastIndexOf('.');
        if (lastDot != -1) {
            key = key.substring(lastDot + 1);
        }
        try {
            this.message = bundle.getString(key);
        } catch (Exception e) {
            this.message = key;
        }
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public IStatus getStatus() {
        return status;
    }

}

package com.serena.eclipse.dimensions.core.sbm;

import java.text.DateFormat;

public interface ISBMReportsResult {
    int getTotalCount();

    ISBMReport[] getData();

    DateFormat getDateFormat();
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

/**
 * <p>
 * Encapsulates object status information and implements equals() and hashCode() so that it can be used where these methods are
 * necessary.
 *
 * @author V.Grishchenko
 */
public class StatusReference {
    private TypeReference type;
    private String status;

    /**
     * @param type
     * @param status may be null
     */
    public StatusReference(TypeReference type, String status) {
        this.type = type;
        this.status = status;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof StatusReference) {
            StatusReference otherRef = (StatusReference) obj;
            if (type.equals(otherRef.type)) {
                return (status == otherRef.status) || (status != null && status.equals(otherRef.status));
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (status == null ? 0 : status.hashCode()) ^ type.hashCode();
    }

    public DimensionsConnectionDetailsEx getConnection() {
        return type.getConnection();
    }

    /**
     * @return Returns the type.
     */
    public TypeReference getType() {
        return type;
    }

    /**
     * @return Returns the status.
     */
    public String getStatus() {
        return status;
    }

}

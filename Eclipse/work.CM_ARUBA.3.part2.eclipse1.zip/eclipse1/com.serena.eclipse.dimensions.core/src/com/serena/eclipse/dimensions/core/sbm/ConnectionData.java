/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.resources.ISaveContext;
import org.eclipse.core.resources.ISaveParticipant;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author V.Grishchenko
 */
public class ConnectionData implements ISaveParticipant {
    private static final String STATE_FILE = "sbmstate.dat"; //$NON-NLS-1$
    private static final int STATE_FILE_VERSION_1 = 1;
    private static final int STATE_FILE_VERSION_CURRENT = STATE_FILE_VERSION_1;
    private static final ConnectionData instance = new ConnectionData();

    private Map connectionData;// = new HashMap(); //connection -> Data

    public static final ConnectionData getInstance() {
        return instance;
    }

    private ConnectionData() {
        restore(); // restore the state
        try {
            ResourcesPlugin.getWorkspace().addSaveParticipant(DMPlugin.getDefault(), this);
        } catch (CoreException e) {
            DMPlugin.log(e.getStatus());
        }
    }

    synchronized Map getMemberMap(ISBMConnection connection) {
        Data data = ((Data) connectionData.get(connection.getUrl()));
        if (data == null) {
            data = new Data();
            connectionData.put(connection.getUrl(), data);
        }
        return data.members;
    }

    @Override
    public void doneSaving(ISaveContext context) {
    }

    @Override
    public void prepareToSave(ISaveContext context) throws CoreException {
    }

    @Override
    public void rollback(ISaveContext context) {
    }

    @Override
    public void saving(ISaveContext context) throws CoreException {
        File stateFile = getStateFile();
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(stateFile)));
            out.writeInt(STATE_FILE_VERSION_CURRENT);
            out.writeObject(connectionData);
        } catch (IOException e) {
            throw new CoreException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, Messages.connectionDataSaving_error, e));
        } finally {
            if (out != null) {
                try {
                    out.flush();
                    out.close();
                } catch (IOException ignore) {
                }
            }
        }
    }

    private File getStateFile() {
        return DMPlugin.getDefault().getStateLocation().append(STATE_FILE).toFile();
    }

    private void restore() {
        File stateFile = getStateFile();
        if (stateFile.isFile()) {
            ObjectInputStream in = null;
            try {
                in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(stateFile)));
                in.readInt();
                connectionData = (Map) in.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ignore) {
                    }
                }
            }
        }
        if (connectionData == null) {
            connectionData = new HashMap();
        }

    }

}

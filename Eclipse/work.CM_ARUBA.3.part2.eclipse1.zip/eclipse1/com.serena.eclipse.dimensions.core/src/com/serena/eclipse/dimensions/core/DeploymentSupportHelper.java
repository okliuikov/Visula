package com.serena.eclipse.dimensions.core;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author kberezovchuk
 *
 */
public class DeploymentSupportHelper {
    private static final String REDIRECT_HTML_TEMPLATE = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">"
            + "<!-- saved from url=(0014)about:internet -->"
            + "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\" />"
            + "<title></title>"
            + "<script type=\"text/javascript\">function doLogin() {document.logInForm.submit();}</script></head>"
            + "<body onload=\"doLogin()\">" + "<form name=\"logInForm\" method=\"POST\" action=\"\">" +
            "</form></body></html>";

    private static final String DEPLOYMENT_PAGE_TITLE = "Dimensions Deployment";

    private static final String USER_ID_PARAM = "USER_ID";
    private static final String PASSWORD_PARAM = "PASSWORD";
    private static final String ENC_PWD_PARAM = "ENC_PASSWORD";
    private static final String DB_NAME_PARAM = "DB_NAME";
    private static final String DB_CONN_PARAM = "DB_CONN";
    private static final String DM_HOST_PARAM = "DM_HOST";

    private static final String JSP_PARAM = "jsp";
    private static final String CMD_PARAM = "command";
    private static final String OBJECT_ID_PARAM = "object_id";
    private static final String SSO_TOKEN_PARAM = "ALFSSOAuthNToken";
    private static final String SSO_CMD_PARAM = "ALFSSOGatekeeperCommand";

    public static final String ROOT_PATH = "ROOT_PATH";
    public static final String PROJECT_PATH = "PROJECT_PATH";
    public static final String PROJECT_STAGE_PATH = "PROJECT_STAGE_PATH";
    public static final String PROJECT_STAGE_AREA_PATH = "PROJECT_STAGE_AREA_PATH";

    private DimensionsConnectionDetailsEx conn;
    private String objectIdValue;
    private String webClientURL;

    public DeploymentSupportHelper(DimensionsConnectionDetailsEx con, String[] ids, String pathType) {
        if (con != null) {
            conn = con;
            webClientURL = conn.getWebBaseURL() + (conn.getWebBaseURL().endsWith("/") ? "dimensions/" : "/dimensions/");
        }
        objectIdValue = createObjectIdStr(ids, pathType);
    }

    /**
     * Creates redirect HTML file in temporary location
     * @return File to open in browser
     */
    public File getRedirectToDeployFile() {
        if (conn == null) {
            return null;
        }
        Map htmlFormParameters = new HashMap<String, String>();
        htmlFormParameters.put(USER_ID_PARAM, conn.getUsername());
        htmlFormParameters.put(PASSWORD_PARAM, PrivateCredentials.encryptPassword(conn.getUsername(), conn.getPassword()));
        htmlFormParameters.put(ENC_PWD_PARAM, "true");
        htmlFormParameters.put(DM_HOST_PARAM, conn.getServer());
        htmlFormParameters.put(DB_NAME_PARAM, conn.getDbName());
        htmlFormParameters.put(DB_CONN_PARAM, conn.getDbConn());

        htmlFormParameters.put(JSP_PARAM, "api");
        htmlFormParameters.put(CMD_PARAM, "deploy_management");
        htmlFormParameters.put(OBJECT_ID_PARAM, objectIdValue);

        String htmlFormParamStr = null;
        if (conn.getSSOToken() != null) {
            byte[] b64Bytes = Base64.encodeBase64(conn.getSSOToken().getBytes());
            try {
                String ssoTokenEncoded = new String(b64Bytes, "UTF-8");
                htmlFormParamStr = "<textarea style=\"display:none\" name=\"" + SSO_TOKEN_PARAM + "\">" + ssoTokenEncoded
                        + "</textarea>";
                htmlFormParameters.put(SSO_CMD_PARAM, "CreateSSOSession");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        String htmlContents = createRedirectHTML(DEPLOYMENT_PAGE_TITLE, getDeploymentPageUrl(), htmlFormParameters,
                htmlFormParamStr);
        File redirectHTMLFile = null;
        OutputStream fos = null;
        try {
            redirectHTMLFile = File.createTempFile("depl", null);
            redirectHTMLFile.deleteOnExit();

            fos = new FileOutputStream(redirectHTMLFile);
            fos.write(htmlContents.getBytes("UTF-8"));
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            try {
                fos.close();
            } catch (Exception ex) { // Swallow it
            }
            try {
                redirectHTMLFile.delete();
            } catch (Exception ex1) { // Swallow it
            }
        } finally {
            try {
                fos.close();
            } catch (Exception e1) { // Swallow it
            }
        }
        return redirectHTMLFile;
    }

    /**
     * Creates redirect HTML contents from the template
     *
     * @param title displayed as HTML page title
     * @param urlStr action URL
     * @param parameters hidden parameters to submit
     * @return HTML file contents
     */
    private static String createRedirectHTML(String title, String urlStr, Map<String, String> parameters, String htmlFormParamStr) {
        StringBuffer buf = new StringBuffer(REDIRECT_HTML_TEMPLATE);
        if (title != null) {
            title.replace("<", "&lt;");
            title.replace(">", "&gt;");
            buf.insert(buf.indexOf("<title>") + 7, title);
        }
        if (urlStr != null) {
            urlStr.replace("\"", "&quot;");
            buf.insert(buf.indexOf("action=\"") + 8, urlStr);
        }

        if (parameters != null) {
            for (Iterator<String> iter = parameters.keySet().iterator(); iter.hasNext();) {
                String name = iter.next();
                String value = parameters.get(name);
                if (value != null) {
                    value.replace("\"", "&quot;");
                    StringBuffer inputTag = new StringBuffer("<input type=\"hidden\" name=\"").append(name)
                            .append("\" value=\"")
                            .append(value)
                            .append("\" />");
                    buf.insert(buf.indexOf("</form>"), inputTag);
                }
            }
        }
        if (htmlFormParamStr != null) {
            buf.insert(buf.indexOf("</form>"), htmlFormParamStr); // Warning: no check of htmlFormParamStr in there
        }
        return buf.toString();
    }

    private String createObjectIdStr(String[] ids, String pathType) {
        if (ids == null || ids.length == 0) {
            return "|ROOT|";
        }

        if (PROJECT_PATH.equals(pathType) && ids.length > 0) {
            return ids[0] + "|ROOT|";
        } else if (PROJECT_STAGE_PATH.equals(pathType) && ids.length > 1) {
            return ids[0] + "|ROOT|" + ids[1] + "|Stage|";
        } else if (PROJECT_STAGE_AREA_PATH.equals(pathType) && ids.length > 2) {
            return ids[0] + "|ROOT|" + ids[1] + "|Stage|" + ids[2] + "|Area|";
        }
        return "|ROOT|";
    }

    public String getDeploymentPageUrl() {
        return webClientURL;
    }
}

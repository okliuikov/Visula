/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public class SBMHelper {
    static final String TT_CREDENTIAL = "ttAuthInfo=";//$NON-NLS-1$
    static final String TT_START_URL = "tmtrack/";//$NON-NLS-1$
    static final String TT_START_DLL_URL = TT_START_URL + "tmtrack.dll?";//$NON-NLS-1$
    static final String TT_HOME_PAGE = "stdpage&template=wrapper&NoExitBtn";//$NON-NLS-1$

    private SBMHelper() {
        // no instances allowed
    }

    public static ISBMConnection getConnection(SBMConnectionDetails details) {
        return getConnection(details, null);
    }

    public static ISBMConnection getConnection(SBMConnectionDetails details, DimensionsConnectionDetailsEx dmConn) {
        return new SBMConnection(details, dmConn);
    }

    public static ISBMRequest getRequest(ISBMConnection c, String id, String itemId, String url, String title, String sourceUUID,
            SBMProperty[] properties, Map values, ISBMContainer parent) {
        SBMRequest request = new SBMRequest(c, id, itemId, url, title, sourceUUID, parent == null ? c : parent);
        request.setProperties(properties == null ? new SBMProperty[0] : properties);
        request.setPropertyValues(values);
        return request;
    }

    public static ISBMReport getReport(ISBMConnection c, String url, String UUID, String title, String author, String createDate,
            ISBMContainer parent) {
        SBMReport report = new SBMReport(c, url, parent == null ? c : parent);
        report.setReportUUID(UUID);
        report.setAuthor(author);
        report.setCreateDate(createDate);
        report.setTitle(title);
        return report;
    }

    /**
     * Construct a string that contains the authentication credentials for
     * connecting to the TeamTrack server. The string is encoded in base-64
     * before being returned.
     *
     * The string is of the form "ttAuthInfo=name:password". After encoding
     * an example is "ttAuthInfo=am9lOg==".
     *
     * @param encodeAsURL If true, the string will be URL Encoded.
     *
     * @return The credentials string.
     */
    public static String getCredentials(String username, String password, boolean encodeAsURL) {
        String encodedStr = basicEncode(username, password);
        // If this string will be passed as part of a URL, we need to
        // encode it to handle special characters like "+".
        if (encodeAsURL) {
            encodedStr = urlEncode(encodedStr);
        }
        return TT_CREDENTIAL + encodedStr;
    }

    /**
     * Returns base64(username:password) suitiable for use during basic http authentication.
     *
     * @param username
     * @param password
     * @return base64(username:password)
     */
    public static String basicEncode(String username, String password) {
        String encodedStr = new String();
        if (password == null) {
            password = Utils.EMPTY_STRING;
        }
        String credentials = username + ":" + password;//$NON-NLS-1$

        // Encode the credentials string into bytes using UTF-8, then encode to base64.
        try {
            byte[] credBytes = credentials.getBytes("UTF-8");
            byte[] b64Bytes = Base64.encodeBase64(credBytes);
            encodedStr = new String(b64Bytes, "US-ASCII"); //$NON-NLS-1$
        } catch (UnsupportedEncodingException e) {
            // shouldn't happen as Java supports UTF-8 and US-ASCII, but log anyways
            DMPlugin.log(new Status(IStatus.ERROR, DMPlugin.ID, 0, "Unsupported encoding", e));
        }
        return encodedStr;
    }

    /**
     * Constructs a URL for viewing TT home page using connection url and login credentials.
     *
     * @param connectionUrl
     * @param username
     * @param password
     * @return
     */
    public static String getHomePageUrl(String webUrl, String username, String password) {
        return webUrl + TT_HOME_PAGE + "&" + getCredentials(username, password, true);
    }

    public static String getAbsoluteUrl(String connectionUrl, String relativeUrl) {
        try {
            URL url = new URL(connectionUrl);
            return url.getProtocol() + "://" + url.getHost() + (url.getPort() > 0 ? ":" + url.getPort() : "") + "/" + TT_START_URL
                    + relativeUrl;
        } catch (Exception ex) {
            ex.printStackTrace();
            if (connectionUrl.charAt(connectionUrl.length() - 1) != '?') {
                connectionUrl += '?';
            }
            return connectionUrl + TT_HOME_PAGE;
        }
    }

    static ISBMManager getSBMManager(DimensionsConnectionDetailsEx connection) {
        ISBMConnection sbmConn = connection.getSBMConnection();
        String url = sbmConn.getDetails().getSoapUrl();
        if (url.length() > 4 && url.substring(0, 4).equalsIgnoreCase("http")) { //$NON-NLS-1$
            return new WSPendingItemsManager(connection);
        }
        throw new RuntimeException("Unsupported protocol: " + url);
    }

    /**
     * URL-encodes the string using UTF-8.
     * @param s
     * @return application/x-www-form-urlencoded input
     */
    public static String urlEncode(String s) {
        try {
            return URLEncoder.encode(Utils.getString(s), "UTF-8"); //$NON-NLS-1$
        } catch (UnsupportedEncodingException e) {
            DMPlugin.log(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "UTF-8 should be supported", e)); //$NON-NLS-1$
        }
        return s;
    }

}

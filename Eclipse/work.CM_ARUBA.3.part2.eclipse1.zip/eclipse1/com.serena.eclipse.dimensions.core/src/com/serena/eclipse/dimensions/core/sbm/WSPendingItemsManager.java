/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.sbm.ws.clientapi.AEWebservicesFaultFault;
import com.serena.eclipse.sbm.ws.clientapi.xsd.AEWebservicesFault;

/**
 * Fetch pending items using SBM web service call
 *
 * @author S. Korniychuk
 */
class WSPendingItemsManager extends SBMManager {

	private static final boolean PROMPT_SBM_LOGIN_INFO = false;

	public WSPendingItemsManager(DimensionsConnectionDetailsEx con) {
		super(con);
	}

	@Override
	protected List fetchContainerMembers(ISBMContainer container,
			IProgressMonitor monitor) throws SBMException {
		ArrayList result = new ArrayList();
		ISBMConnection con = getConnection();
		if (con == null) {
			return result;
		}
		boolean authenticated = con.isAuthenticated();
		if (!authenticated) {
			authenticated = con.authenticate(true, monitor);
		}
		if (!authenticated) {
			return result;
		}

		SBMClientHelper helper = null;
		DateFormat df = SBMClientHelper.DF_FROM_LOCAL;
		try {
			helper = new SBMClientHelper(con);
			df = new SimpleDateFormat(); // helper.getUserDateTimeFormat();
			setDateFormatForContainer(container, df);
		} catch (Exception ex) {
			throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0,
					"Encountered error while returning user date format", ex));
		}

		if (container instanceof ISBMReport) {
			try {
				ISBMTableDataProvider data = helper.runReport(
						((ISBMReport) container).getReportUUID(), container);
				if (data != null) {
					result.addAll(Arrays.asList(data.getRequests()));
				}
			} catch (SBMException e) {
				// throw this through, preserving message/status
				throw e;
			} catch (Exception ex) {
				throw new SBMException(new SBMStatus(IStatus.ERROR, DMPlugin.ID, 0, "Encountered error while running report", ex));
			}
		} else if (container instanceof IDEFolder) {
			if (reportsProvider != null) {
				reportsProvider.setUserDateFormat(getDateFormatForContainer(
						container, true));
				ISBMReport[] selectedReports = reportsProvider
						.getSelectedReports(getConnection());
				try {
					helper.refreshReports(selectedReports, df);
				} catch (SBMException e) {
					// throw this through, preserving message/status
					throw e;
				} catch (Exception ex) {
					throw new SBMException(new SBMStatus(IStatus.ERROR,
							DMPlugin.ID, 0,
							"Encountered error while refresh reports", ex));
				}

				reportsProvider.saveSelectedReports(selectedReports);
				result.addAll(Arrays.asList(selectedReports));
			}
		} else if (container instanceof ActiveItems) {
			((ActiveItems) container).refresh(monitor);
			List activeItems = container.getMembers();
			if (activeItems != null) {
				result.addAll(activeItems);
			}
		}

		return result;
	}

	/**
	 * This method answers <code>true</code> if there is no password previously
	 * set.
	 *
	 * @return <code>true</code> if should prompt for login credentials before
	 *         hitting the server
	 */
	protected boolean shouldPromptPreemptive() {
		return getConnection().getDetails().getPassword() == null;
	}

	@Override
	public void associate(AssociateInput input, IProgressMonitor monitor)
			throws SBMException {
	}

	private ChallengeDetails createChallengeDetails() {
		ChallengeDetails result = new ChallengeDetails(
				ChallengeDetails.USERNAME | ChallengeDetails.PASSWORD,
				getConnection().getDetails().getSoapUrl(), 0,
				ChallengeDetails.SERVER, null, "XML"); //$NON-NLS-1$
		result.username = getConnection().getDetails().getUser();
		return result;
	}

	@Override
	public synchronized boolean authenticate(boolean allowPrompt,
			IProgressMonitor monitor) throws SBMException {
		return true;
	}

	@Override
	public DateFormat getDateFormatForContainer(ISBMContainer container) {
		DateFormat dateFormat = super.getDateFormatForContainer(container);
		if (dateFormat == null) {
			try {
				SBMClientHelper helper = new SBMClientHelper(getConnection());
				dateFormat = helper.getUserDateTimeFormat();
				setDateFormatForContainer(container, dateFormat);
			} catch (Exception ex) {
				DMPlugin.log(new SBMStatus(
						IStatus.ERROR,
						DMPlugin.ID,
						0,
						"Encountered error while returning user date format", ex)); //$NON-NLS-1$
			}
		}
		return dateFormat;
	}

	@Override
	public DateFormat getDateFormatForContainer(ISBMContainer container,
			boolean refresh) {
		DateFormat dateFormat = null;
		if (refresh
				|| (dateFormat = super.getDateFormatForContainer(container)) == null) {
			try {
				SBMClientHelper helper = new SBMClientHelper(getConnection());
				dateFormat = new SimpleDateFormat();// helper.getUserDateTimeFormat();
				setDateFormatForContainer(container, dateFormat);
			} catch (Exception ex) {
				DMPlugin.log(new SBMStatus(
						IStatus.ERROR,
						DMPlugin.ID,
						0,
						"Encountered error while returning user date format", ex)); //$NON-NLS-1$
			}
		}
		return dateFormat;
	}

}

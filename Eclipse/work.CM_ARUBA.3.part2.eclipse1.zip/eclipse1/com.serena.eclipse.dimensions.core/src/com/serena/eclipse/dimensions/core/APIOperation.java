/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ResourceBundle;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.dmclient.api.DimensionsResult;

/**
 * @author V.Grishchenko
 */
public abstract class APIOperation extends ConsoleOperation {

    public APIOperation(String message) {
        super(message);
    }

    public APIOperation(ResourceBundle bundle) {
        super(bundle);
    }

    @Override
    public void run() throws Exception {
        DimensionsResult dimensionsResult = doRun();
        status = new Status(IStatus.OK, getPluginId(), 0, dimensionsResult.getMessage(), null);
    }

    protected String getPluginId() {
        return DMPlugin.ID;
    }

    protected abstract DimensionsResult doRun() throws Exception;

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * @author V.Grishchenko
 */
public class AssociateHanlder extends SBMContentHandler {

    private List descriptions = new ArrayList();
    private List labels = new ArrayList();

    /**
     * @param connection
     */
    public AssociateHanlder(ISBMConnection connection) {
        super(connection);
    }

    @Override
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
        String elementName = getElementName(localName, qName);
        if (elementName.equals(TAG_TAG)) { // "TAG"
            String key = atts.getValue(TAG_TYPE_ID_ATTR);
            String value = atts.getValue(TAG_VALUE_ID_ATTR);
            if (DESCR_ATTR_NAME.equals(key)) {
                descriptions.add(value);
            }
            if (LABEL_ATTR_NAME.equals(key)) {
                labels.add(value);
            }
        } else if (elementName.equals(RETURN_CODE_TAG)) { // "returnCode"
            m_TTReturnCode = atts.getValue(RETURN_CODE_ID_ATTR);
        }

        // Empty the buffer
        if (m_buffer.length() > 0) {
            m_buffer.setLength(0);
        }
    }

    public List getDescriptions() {
        return descriptions;
    }

    public List getLabels() {
        return labels;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import com.serena.dmclient.api.IDMReportColumnType;

/**
 * @author V.Grishchenko
 */
class SBMReport extends SBMContainer implements ISBMReport {
    static final long serialVersionUID = -342846368514988347L;

    private String access;
    private String author;
    private String createDate;
    private String lastExecDate;
    private String lastModifiedDate;
    private String lastModifiedUser;
    private String title;
    private String type;
    private String xmlUrl;

    private String UUID;

    public SBMReport(ISBMConnection connection, String url, ISBMContainer parent) {
        super(connection, url, parent);
        SBMProperty[] properties = new SBMProperty[] { new SBMProperty(FIELD_REPORT_TITLE), new SBMProperty(FIELD_REPORT_AUTHOR),
                new SBMProperty(FIELD_REPORT_CREATEDATE, IDMReportColumnType.DATETIME) };
        setProperties(properties);
    }

    @Override
    public String getProperty(SBMProperty col) {
        if (col == null) {
            return "";
        }
        if (FIELD_REPORT_TITLE.equals(col.getId())) {
            return title;
        }
        if (FIELD_REPORT_AUTHOR.equals(col.getId())) {
            return author;
        }
        if (FIELD_REPORT_CREATEDATE.equals(col.getId())) {
            return createDate;
        }
        return "";
    }

    @Override
    public int getType() {
        return REPORT;
    }

    @Override
    public String getAccess() {
        return access;
    }

    void setAccess(String access) {
        this.access = access;
    }

    @Override
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    @Override
    public String getLastExecDate() {
        return lastExecDate;
    }

    void setLastExecDate(String lastExecDate) {
        this.lastExecDate = lastExecDate;
    }

    @Override
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @Override
    public String getLastModifiedUser() {
        return lastModifiedUser;
    }

    void setLastModifiedUser(String lastModifiedUser) {
        this.lastModifiedUser = lastModifiedUser;
    }

    @Override
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String getReportType() {
        return type;
    }

    void setReportType(String type) {
        this.type = type;
    }

    @Override
    public String getXMLUrl() {
        return xmlUrl;
    }

    protected void setXmlUrl(String xmlUrl) {
        this.xmlUrl = getAbsoluteURL(xmlUrl);
    }

    @Override
    protected String getMembersUrl() {
        return getXMLUrl() + HTTPManager.TT_REPORTS_STYLESHEET + HTTPManager.TT_RETURN_ALL_ITEMS; // Report node was selected.
    }

    @Override
    public String toString() {
        return "[REPORT] title=\"" + title + "\"; url=\"" + getUrl() + "\"";
    }

    @Override
    public String getReportUUID() {
        return UUID;
    }

    public void setReportUUID(String UUID) {
        this.UUID = UUID;
    }

    @Override
    public boolean isContainer() {
        return false;
    }

}

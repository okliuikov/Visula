/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.SystemRelationship;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author V.Grishchenko
 */
class DimensionsIDEProjectGroupsList extends WorksetList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = DimensionsIDEProjectGroupsList.class.getName();

    /**
     * Creates List of Projects DimensionsIDEProject Instances
     *
     * @param con
     * @param includeOnlyStreams
     *            - List will include only Streams
     * @param includeOnlyProjects
     *            - List will include only Projects
     *            If both includeOnlyStreams and includeOnlyProjects are false then projects and streams will be included in the
     *            list.
     */
    public DimensionsIDEProjectGroupsList(DimensionsConnectionDetailsEx con, boolean includeOnlyStreams, boolean includeOnlyProjects) {
        // @formatter:off
        super(con, includeOnlyStreams ? IDE_STREAM_GROUPS :
            includeOnlyProjects ? IDE_PROJECT_GROUPS : IDE_PROJECT_AND_STREAM_GROUPS);
        // @formatter:on
        this.includeOnlyStreams = includeOnlyStreams;
        this.includeOnlyProjects = includeOnlyProjects;
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List<Project> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);

            final Unit<List<Project>> holder = new Unit<List<Project>>();
            EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
    	    final EclipseProjectsFetcher<Project> listsEclipse = listFactory.createEclipseProjectsFetcher();
            final String includeClosedFilter = getIncludeClosedFilter();
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {


                    List<Project> plists = listsEclipse.getGroupProjects(session.getConnectionDetails().getMaxRecentCount(),
                            includeClosedFilter);
                    holder.setValue(plists);
                }
            }, pm);
            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject workset) {
        return true;
    }

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject object) {
        Project workset = (Project) object;
        String wstag = (String) workset.getAttribute(SystemAttributes.IDE_TAG);
        String wspname = (String) workset.getAttribute(SystemAttributes.IDE_PROJECT_NAME);
        return new DimensionsIDEProjectGroup(workset, getConnectionDetails(), wstag, wspname);
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        Assert.isLegal(objectDetails instanceof DimensionsIDEProjectGroupDetails);
        DimensionsIDEProjectGroupDetails worksetDetails = (DimensionsIDEProjectGroupDetails) objectDetails;
        monitor.beginTask(Messages.objectCreate_task, 50 + worksetDetails.getMembers().size());
        try {
            WorksetCreationResult result = super.createIdeObject(session, worksetDetails, IDMConstants.ECLIPSE_PROJECT_GROUP_TAG,
                    IDMConstants.DURULES_GROUP_ID, true, null, false, Utils.subMonitorFor(monitor, 50));

            Project createdWorkset = result.workset;

            for (Iterator<APIObjectAdapter> contiter = worksetDetails.getMembers().iterator(); contiter.hasNext();) {
                final APIObjectAdapter apiObj = contiter.next();
                String spec = (String) apiObj.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
                monitor.subTask(spec);
                DMPlugin.getDefault().getConsole().printMessage("Adding group member: " + spec);//$NON-NLS-1$
                String pName = null;
                if (!(apiObj instanceof SccProjectContainerWorkset)) {
                    apiObj.getAPIObject().queryAttribute(SystemAttributes.IDE_PROJECT_NAME);
                    pName = (String) apiObj.getAPIObject().getAttribute(SystemAttributes.IDE_PROJECT_NAME);
                }
                final String relLoc = pName == null ? null : pName;

                DimensionsResult addResult = null;
                if (apiObj instanceof WorksetAdapter) {
                    addResult = createdWorkset.addChildProject(SystemRelationship.USAGE, (Project) apiObj.getAPIObject(), relLoc,
                            null);
                } else if (apiObj instanceof BaselineAdapter) {
                    addResult = createdWorkset.addChildBaseline(SystemRelationship.USAGE, (Baseline) apiObj.getAPIObject(), relLoc,
                            null);
                }
                if (addResult != null) {
                    DMPlugin.getDefault().getConsole().printMessage(addResult.getMessage());
                }
                monitor.worked(1);
            }
            return result;
        } finally {
            monitor.done();
        }
    }

}

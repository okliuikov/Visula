/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.sbm.XMLPayloadManager.InputStreamHelper;
import com.serena.eclipse.dimensions.core.util.TempFileInputStream;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
public abstract class HTTPManager extends XMLPayloadManager implements InputStreamHelper {
    public static final String USER_AGENT = "Mozilla/5.0"; //$NON-NLS-1$

    public static final String TT_USERNAME = "&ttAuthUID=";//$NON-NLS-1$
    public static final String TT_PASSWORD = "&ttAuthPWD=";//$NON-NLS-1$
    public static final String TT_REPORTS = "?IDEPage&template=xml/idefolder";//$NON-NLS-1$
    public static final String TT_IDE_STYLESHEET = "&Stylesheet=xsl/IDEFolder.xsl";//$NON-NLS-1$
    public static final String TT_REPORTS_STYLESHEET = "&Stylesheet=xsl/IDERptListing.xsl";//$NON-NLS-1$
    public static final String TT_ASSOCIATE = "?IDEPage&Template=xml/sccaction&Stylesheet=xsl/IDESCCAction.xsl&SCCAction=";//$NON-NLS-1$
    public static final String TT_ASSOCIATE_STYLESHEET = "&Stylesheet=xsl/IDESCCAction.xsl";//$NON-NLS-1$
    public static final String TT_ASSOCIATIONS = "?ReportPage&hasruntimeparams=1&template=xml/report&reportid=-46&f4=";//$NON-NLS-1$
    public static final String TT_RETURN_ALL_ITEMS = "&recno=-1";//$NON-NLS-1$

    class PostHelper implements InputStreamHelper {
        String requestBody;
        String page;

        PostHelper(String requestBody, String page) {
            this.requestBody = requestBody;
            this.page = page;
        }

        @Override
        public InputStream getInputStream(String url, IProgressMonitor monitor) throws SBMException {
            if (page != null) {
                url = url + "?" + page;
            }
            String credentials = getCredentials(true);
            if (credentials != null) {
                url = url + "&" + credentials; //$NON-NLS-1$
            }
            return getPOSTInputStream(url, requestBody, monitor);
        }
    }

    public HTTPManager(DimensionsConnectionDetailsEx con) {
        super(con);
    }

    protected abstract InputStream getGETInputStream(String url, IProgressMonitor monitor) throws SBMException;

    protected abstract InputStream getPOSTInputStream(String url, String body, IProgressMonitor monitor) throws SBMException;

    @Override
    public InputStream getInputStream(String url, IProgressMonitor monitor) throws SBMException {
        String credentials = getCredentials(true);
        if (credentials != null) {
            url = url + "&" + credentials; //$NON-NLS-1$
        }
        return getGETInputStream(url, monitor);
    }

    /**
     * Construct a string that contains the authentication credentials for
     * connecting to the TeamTrack server. The string is encoded in base-64
     * before being returned.
     *
     * The string is of the form "ttAuthInfo=name:password". After encoding
     * an example is "ttAuthInfo=am9lOg==".
     *
     * @param encodeAsURL
     *            If true, the string will be URL Encoded.
     *
     * @return The credentials string.
     */
    protected String getCredentials(boolean encodeAsURL) {
        String user = getConnection().getDetails().getUser();
        if (Utils.isNullEmpty(user)) {
            return null;
        }
        return SBMHelper.getCredentials(user, getConnection().getDetails().getPassword(), encodeAsURL);
    }

    protected InputStream asTempFileStream(InputStream in) throws IOException {
        File tempFile = File.createTempFile("sbm", null); //$NON-NLS-1$
        FileOutputStream tempFileOut = null;
        try {
            tempFileOut = new FileOutputStream(tempFile);
            copyStream(in, tempFileOut, -1);
        } finally {
            if (tempFileOut != null) {
                try {
                    tempFileOut.flush();
                    tempFileOut.close();
                } catch (IOException e) {
                }
            }
        }
        return new TempFileInputStream(tempFile);
    }

    /*
     * Copies bytes from the supplied input stream to the output stream using
     * buffer of the specified size.
     * @param from the stream to copy bytes from
     * @param to the stream to copy bytes to
     * @param bufSize desired buffer size, if less than 0 a default size of 10k is used
     * @throws IOException
     */
    protected void copyStream(InputStream from, OutputStream to, int bufSize) throws IOException {
        byte[] buf = new byte[bufSize < 0 ? 10 * 1024 : bufSize];
        int bytesRead;
        while ((bytesRead = from.read(buf)) != -1) {
            to.write(buf, 0, bytesRead);
        }
    }

    static ChallengeDetails createChallengeDetails(String host, int port, int hostKind, String realm, String scheme,
            String username, String domain) {
        int fields = ChallengeDetails.USERNAME | ChallengeDetails.PASSWORD;
        boolean ntlm = "ntlm".equalsIgnoreCase(scheme); //$NON-NLS-1$
        if (ntlm) {
            fields |= ChallengeDetails.DOMAIN;
        }
        ChallengeDetails cd = new ChallengeDetails(fields, host, port, hostKind, realm, scheme);
        cd.username = username;
        if (ntlm) {
            cd.domain = domain;
        }
        return cd;
    }

    @Override
    protected InputStreamHelper getContainerMembersHelper() {
        return this;
    }

    @Override
    protected InputStreamHelper getAssociateHelper(String associateRequest) {
        return new PostHelper("Template=xml/sccaction&Stylesheet=xsl/IDESCCAction.xsl&SCCAction="
                + SBMHelper.urlEncode(associateRequest), "IDEPage");
    }

}

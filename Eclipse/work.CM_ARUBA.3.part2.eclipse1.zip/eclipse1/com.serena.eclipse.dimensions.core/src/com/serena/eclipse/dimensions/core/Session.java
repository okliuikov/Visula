/*
 * @Session.java, created on Apr 13, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ILock;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsConnection;
import com.serena.dmclient.api.DimensionsConnectionException;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.RequestList;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Application-level session with a Dimensions server. Handles connection
 * recovery, wraps any exceptions thrown by the API to Eclipse DM Exception,
 * provides convenience methods to obtain Eclipse adapters for the API
 * classes.
 *
 * @author V.Grishchenko
 */
public class Session {
    /**
     * Status code for connection expiration. When such condition is detected
     * a session is put into invalid state.
     * @see DimensionsConnection#STATE_EXPIRED
     */
    public static final int SESSION_EXPIRED = 1000;

    private final ILock lock = Job.getJobManager().newLock();
    private DimensionsConnectionDetailsEx loc;
    private DimensionsConnection connection;
    private boolean destroyed;
    private boolean dariusSessionLoggedOut;
    private PLCDMaintainOperation maintainPLCDOperaion;

    /*
     * Note: As we now know when connection failed (DimensionsConnectionException)
     * retry is no longer necessary.
     */
    private void run(ISessionRunnable apiTask, boolean retry) throws DMException {
        ensureValid();
        int attempt = 0;
        boolean success = false;
        IDMConsoleListener console = DMPlugin.getDefault().getConsole();
        do {
            attempt++;
            if (apiTask instanceof IConsoleOperation && attempt == 1) {
                console.operationStarted(((IConsoleOperation) apiTask).getMessage());
            }
            try {
                if (dariusSessionLoggedOut) {
                    IStatus result = new Status(IStatus.ERROR, DMPlugin.ID, Messages.session_dariusSessionLoggedOut);
                    DMException dariusSessionLoggedOutException = new DMException(result);
                    getConnectionDetails().destroySession();
                    throw dariusSessionLoggedOutException;
                }
                apiTask.run();
                success = true;
                if (apiTask instanceof IConsoleOperation) {
                    console.operationCompleted(((IConsoleOperation) apiTask).getStatus(), null);
                }
            } catch (DimensionsConnectionException e) {
                if (attempt > 1) { // do not attempt to reconnect more than once
                    operationFailed(apiTask, e);
                    throw wrap(e);
                }
                if (Utils.isNullEmpty(e.getMessage())) {
                    console.printMessage(NLS.bind(Messages.session_reconnectNoDetails, loc.getConnName()));
                } else {
                    console.printMessage(NLS.bind(Messages.session_reconnect, loc.getConnName(), e.getMessage()));
                }
                try {
                    // try to reconnect
                    // TODO: AB Set back the appropriate workset
                    if (connection != null && connection.getConnectionState(true) == DimensionsConnection.STATE_CONNECTED) {
                        console.printMessage(NLS.bind(Messages.session_reconnectSucceeded, loc.getConnName()));
                    } else {
                        console.printMessage(Messages.session_reconnectFailedNoDetails);
                        operationFailed(apiTask, e);
                        throw wrap(e);
                    }
                } catch (Exception e1) {
                    // log 1st exception so it is not lost and send the new one up
                    DMPlugin.log(wrap(e).getStatus());
                    if (Utils.isNullEmpty(e1.getMessage())) {
                        console.printMessage(Messages.session_reconnectFailedNoDetails);
                    } else {
                        console.printMessage(NLS.bind(Messages.session_reconnectFailed, e1.getMessage()));
                    }
                    operationFailed(apiTask, e);

                    // DEF192407 light fix: when connection lost, darius BaseSession
                    // object logged out, attributes are erased, but object still
                    // available for connections which leads to NullPointerExceptions.
                    // TODO: make changes in darius for correct handling of logged out
                    // BaseSession objects
                    Throwable throwable = e1.getCause();
                    if (throwable != null
                            && (throwable instanceof DimensionsConnectionException || throwable.getCause() instanceof SocketException)) {
                        this.dariusSessionLoggedOut = true;
                        IStatus result = new Status(IStatus.ERROR, DMPlugin.ID, Messages.session_dariusSessionLoggedOut);
                        DMException dariusSessionLoggedOutException = new DMException(result);
                        getConnectionDetails().destroySession();
                        throw dariusSessionLoggedOutException;
                    }
                    throw wrap(e1);
                }
            } catch (OperationCanceledException cancel) {
                operationFailed(apiTask, cancel);
                throw cancel; // send cancellations up as is
            } catch (Exception e) {
                operationFailed(apiTask, e);
                throw wrap(e);
            }
        } while (!success);
    }

    private void operationFailed(ISessionRunnable task, Exception e) {
        if (task instanceof IConsoleOperation && DMPlugin.getDefault().getConsole().isOperaionStarted()) {
            if (e instanceof CoreException) {
                DMPlugin.getDefault().getConsole().operationCompleted(((CoreException) e).getStatus(), null);
            } else {
                DMPlugin.getDefault().getConsole().operationCompleted(null, e);
            }
        }
    }

    /**
     * <p>
     * Handles the details of reviving the underlying connection and converts runtime exceptions raised by dmclient to
     * <code>DMException</code> and sends the up to the caller.
     *
     * <p>
     * If the supplied task implements <code>IConsoleOperation</code> and the task fails during execution this method will notify
     * the console that the operation was completed with error so that the task need not to catch/rethrow dmclient exceptions for
     * the purpose of finalizing the operation in console.
     *
     * <p>
     * If this method is called on another thread while another runnable is executing it will block until the first one completes.
     * This is to serialize access to the Java API as it is not completely thread-safe, in particular bulk operator queries will
     * fail if run by parallel threads against a MSSQL database. Because api task execution is sycnrhonized a session runnable
     * should not create any threads that call <code>Session.run()</code> in their turn as this will lead to a deadlock.
     *
     * @param apiTask
     * @throws DMException
     * @see IConsoleOperation
     * @deprecated use <code>run(ISessionRunnable apiTask, IProgressMonitor monitor)</code>
     */
    @Deprecated
    public void run(ISessionRunnable apiTask) throws DMException {
        try {
            lock.acquire();
            run(apiTask, true);
        } finally {
            lock.release();
        }
    }

    /**
     * This version of run will not run the specified task if it is cancelled
     * prior to a lock can be acquired for this session.
     *
     * @param apiTask
     *            task to run
     * @param monitor
     *            monitor to poll for cancellations or <code>null</code>, no progerss will be
     *            posted to this monitor
     * @throws DMException
     */
    public void run(ISessionRunnable apiTask, IProgressMonitor monitor) throws DMException /* , InterruptedException */{
        boolean acquired = false;
        try {
            while (!acquired) {
                Utils.checkCanceled(monitor);
                acquired = lock.acquire(100);
            }
            run(apiTask, true);
        } catch (InterruptedException e) {
            // TODO need to propagate up?
        } finally {
            if (acquired) {
                lock.release();
            }
        }
    }

    /**
     * <p>
     * Callers that need to ensure that no other tasks are being run inside this session prior to calling
     * <code>run(ISessionRunnable apiTask)</code> may obtain and attempt to acquire a lock.
     *
     * <p>
     * Cancellation example:
     *
     * <pre>
     * ISessionRunnable task = .. //create a task
     * IProgressMonitor monitor = .. //obtain a monitor
     * Session session = .. //obtain session
     * ILock lock = session.getLock();
     * boolean acquired = false;
     * try {
     *     while(!acquired &amp;&amp; !monitor.isCanceled())
     *         acquired = lock.acquire(100);
     *     if (acquired &amp;&amp; !monitor.isCanceled())
     *         session.run(task);
     * } catch (InterruptedException e) {
     *     //handle interrupt
     * } finally {
     *     if (acquired)
     *         lock.release();
     * }
     * </pre>
     *
     * @return this session's lock
     */
    public ILock getLock() {
        return lock;
    }

    /**
     * @return object factory
     * @throws DMException if session is invalid
     */
    public DimensionsObjectFactory getObjectFactory() throws DMException {
        return getConnection().getObjectFactory();
    }

    /**
     * @return underlying connection
     * @throws DMException if session is invalid
     */
    public DimensionsConnection getUnderlyingConnection() throws DMException {
        return getConnection();
    }

    /**
     * @return Eclipse adapter for the API object
     */
    public APIObjectAdapter adapt(DimensionsObject dmObject) {
        if (dmObject instanceof Request) {
            return new ChangeDocumentAdapter((Request) dmObject, loc);
        }
        if (dmObject instanceof Project) {
            return new WorksetAdapter((Project) dmObject, loc);
        }
        if (dmObject instanceof Baseline) {
            return new BaselineAdapter((Baseline) dmObject, loc);
        }
        if (dmObject instanceof ItemRevision) {
            return new ItemRevisionAdapter((ItemRevision) dmObject, loc);
        }
        if (dmObject instanceof RequestList) {
            return new RequestListAdapter((RequestList) dmObject, loc);
        }
        return null;
    }

    /**
     * @return a List for Eclipse adapters for a list of API objects
     */
    public List<APIObjectAdapter> adapt(List<DimensionsObject> dmObjectList) {
        if (dmObjectList.isEmpty()) {
            return Collections.emptyList();
        }
        List<APIObjectAdapter> adapted = new ArrayList<APIObjectAdapter>(dmObjectList.size());
        for (Iterator<DimensionsObject> iter = dmObjectList.iterator(); iter.hasNext();) {
            adapted.add(adapt(iter.next()));
        }
        return adapted;
    }

    public boolean isValid() {
        return !destroyed;
    }

    public DimensionsConnectionDetailsEx getConnectionDetails() {
        return loc;
    }

    private DMException wrap(Exception exception) {
        if (exception instanceof CoreException) {
            return DMException.asDMException((CoreException) exception);
        }
        String msg = null;
        Throwable cause = exception;
        while (Utils.isNullEmpty(msg) && cause != null) {
            msg = cause.getMessage();
            cause = cause.getCause();
        }
        if (Utils.isNullEmpty(msg)) {
            msg = Messages.error_noDetails;
        }

        return new DMException(msg, exception);
    }

    Session(DimensionsConnectionDetailsEx loc) {
        Assert.isNotNull(loc, "null location!"); //$NON-NLS-1$
        this.loc = loc;
    }

    void open(IUserAuthenticator auth) throws DMException {
        open(loc.openConnection(auth));
    }

    void open(DimensionsConnection connection) {
        assert connection != null;
        this.connection = connection;

        if (maintainPLCDOperaion == null) {
            this.maintainPLCDOperaion = new PLCDMaintainOperation(Messages.maintainPLCD_JobName, connection);
            maintainPLCDOperaion.schedule();
        }
    }

    private void ensureValid() throws DMException {
        getConnection();
    }

    DimensionsConnection getConnection() throws DMException {
        if (connection == null) {
            if (destroyed) {
                throw new DMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, "Invalid session", null));
            }
            open((IUserAuthenticator) null);
        }
        return connection;
    }

    void destroy() {
        if (connection != null) {
            connection.close();
            connection = null;
        }
        destroyed = true;

        if (maintainPLCDOperaion != null) {
            maintainPLCDOperaion.stop();
            maintainPLCDOperaion.cancel();
        }
    }

    public static class PLCDMaintainOperation extends RepeatingJob {

        DimensionsConnection connection;
        static long repeatDelay = TimeUnit.MINUTES.toMillis(30);

        public PLCDMaintainOperation(String name, DimensionsConnection connection) {
            super(name, repeatDelay);
            this.connection = connection;
            setSystem(true);
        }

        @Override
        IStatus doRun(IProgressMonitor monitor) {
            if (connection.isPLCDEnabled() && !monitor.isCanceled()) {
                boolean done = connection.maintainPLCDSize(false);
                if (done) {
                    return new Status(IStatus.OK, DMPlugin.ID, Messages.maintainPLCD_executionSuccess);
                }
            }
            return new Status(IStatus.INFO, DMPlugin.ID, Messages.maintainPLCD_executionSkipped);
        }

    }

}

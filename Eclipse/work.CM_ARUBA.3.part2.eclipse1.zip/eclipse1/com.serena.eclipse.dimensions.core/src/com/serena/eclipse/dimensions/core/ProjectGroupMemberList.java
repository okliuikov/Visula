/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Contents of a project group that may include projects and baselines.
 * @author V.Grishchenko
 */
public class ProjectGroupMemberList extends DimensionsObjectList {
    // connection -> {project workset , member workset etc}

    private static ISessionListener sessList = new ISessionListener() {

        @Override
        public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
            lists.remove(loc);
        }

        @Override
        public void sessionCreated(DimensionsConnectionDetailsEx loc) {
        }
    };

    private static Map<DimensionsConnectionDetailsEx, List<DimensionsObjectList>> lists = new ConnectionListsHashMap<DimensionsConnectionDetailsEx, List<DimensionsObjectList>>();

    private DimensionsIDEProjectGroup group;

    public static ProjectGroupMemberList getMemberList(DimensionsIDEProjectGroup group) {
        String qualifier = (String) group.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
        boolean includeOnlyProjects = false;// Include only Streams in the list
        boolean includeOnlyStreams = false;// Include only Projects in the list
        DimensionsObjectList dol = group.getObjectList();
        if (dol != null && dol instanceof DimensionsIDEProjectGroupsList) {
            if (((DimensionsIDEProjectGroupsList) dol).isIncludeOnlyProjects()) {
                includeOnlyProjects = true;
                includeOnlyStreams = false;
            } else if (((DimensionsIDEProjectGroupsList) dol).isIncludeOnlyStreams()) {
                includeOnlyProjects = false;
                includeOnlyStreams = true;
            }
        }

        // @formatter:off
        ProjectGroupMemberList myList = lookupList(
                group.getConnectionDetails(),
                includeOnlyStreams ? WorksetList.IDE_PROJECT_GROUP_MEMBER_STREAM :
                    includeOnlyProjects ? WorksetList.IDE_PROJECT_GROUP_MEMBER_WORKSET : 0,
                qualifier);
        // @formatter:on

        if (myList == null) {
            myList = new ProjectGroupMemberList(group.getConnectionDetails(), group, includeOnlyStreams, includeOnlyProjects);
            registerList(myList);
        }
        return myList;
    }

    private static void registerList(ProjectGroupMemberList list) {
        List<DimensionsObjectList> conLists = lists.get(list.getConnectionDetails());
        if (conLists == null) {
            conLists = new ArrayList<DimensionsObjectList>(4);
            lists.put(list.getConnectionDetails(), conLists);
        }
        conLists.add(list);
    }

    private static ProjectGroupMemberList lookupList(DimensionsConnectionDetailsEx con, int listType, String qualifier) {
        List<DimensionsObjectList> conLists = lists.get(con);
        if (conLists == null) {
            return null;
        }

        for (Iterator<DimensionsObjectList> iter = conLists.iterator(); iter.hasNext();) {
            ProjectGroupMemberList aList = (ProjectGroupMemberList) iter.next();
            if (aList.getType() == listType
                    && ((qualifier == aList.getQualifier()) || (qualifier != null && qualifier.equals(aList.getQualifier())))) {
                DimensionsObjectList.replaceEqualConnectionInstances(con, aList);
                return aList;
            }
        }
        return null;
    }

    /**
     * @param con
     * @param includeOnlyStreams
     *            - List will include only Streams
     * @param includeOnlyProjects
     *            - List will include only Projects
     *            If both includeOnlyStreams and includeOnlyProjects are false then projects and streams will be included in the
     *            list.
     * @param type
     */
    public ProjectGroupMemberList(DimensionsConnectionDetailsEx con, DimensionsIDEProjectGroup group, boolean includeOnlyStreams,
            boolean includeOnlyProjects) {
        super(con, includeOnlyStreams ? WorksetList.IDE_PROJECT_GROUP_MEMBER_STREAM : includeOnlyProjects
                ? WorksetList.IDE_PROJECT_GROUP_MEMBER_WORKSET : 0);
        Assert.isNotNull(group);
        this.group = group;
        DimensionsConnectionDetailsEx.addSessionListener(sessList);
    }

    /**
     * @return Returns the group.
     */
    public DimensionsIDEProjectGroup getGroup() {
        return group;
    }

    @Override
    public String getQualifier() {
        return group.getObjectSpec();
    }

    @Override
    protected List doFetch(Session session, final IProgressMonitor pm) throws DMException {
        final ArrayList result = new ArrayList();
        try {
            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    pm.beginTask(null, 2);

                    Filter wsf = new Filter();
                    wsf.criteria().add(new Filter.Criterion(FilterOptions.USAGE_RELATIONSHIP, Boolean.TRUE, 0));
                    DimensionsObjectList dol = group.getObjectList();
                    if (dol != null && dol instanceof DimensionsIDEProjectGroupsList) {
                        if (((DimensionsIDEProjectGroupsList) dol).isIncludeOnlyProjects()) {
                            wsf.criteria().add(new Filter.Criterion(SystemAttributes.WSET_IS_STREAM, "Y", Filter.Criterion.NOT));
                        } else if (((DimensionsIDEProjectGroupsList) dol).isIncludeOnlyStreams()) {
                            wsf.criteria().add(new Filter.Criterion(SystemAttributes.WSET_IS_STREAM, "Y", Filter.Criterion.EQUALS));
                        }
                    }
                    group.getWorkset().flushRelatedObjects(Project.class, true);
                    List usageWs = group.getWorkset().getChildProjects(wsf);
                    group.getWorkset().flushRelatedObjects(Project.class, true);
                    pm.worked(1);

                    Filter blf = new Filter();
                    blf.criteria().add(new Filter.Criterion(FilterOptions.USAGE_RELATIONSHIP, Boolean.TRUE, 0));
                    group.getWorkset().flushRelatedObjects(Baseline.class, true);
                    List usageBl = group.getWorkset().getChildBaselines(blf);
                    group.getWorkset().flushRelatedObjects(Baseline.class, true);
                    pm.worked(1);

                    usageWs.addAll(usageBl);
                    for (Iterator contit = usageWs.iterator(); contit.hasNext();) {
                        result.add(((DimensionsRelatedObject) contit.next()).getObject());
                    }
                }

            }, pm);
        } finally {
            pm.done();
        }
        return result;
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        throw new UnsupportedOperationException("unsupported operation");
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.PROJECT_GROUP_MEMBER;
    }

    @Override
    protected String getUniqueId(DimensionsArObject object) {
        return object.getName();
    }

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        APIObjectAdapter adapter = super.adapt(session, dimensionsObject);
        adapter.setParentAdapter(group);
        return adapter;
    }

}

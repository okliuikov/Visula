/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author V.Grishchenko
 */
public class ItemRevisionAdapter extends APIObjectAdapter {

    public ItemRevisionAdapter(ItemRevision itemRevision, DimensionsConnectionDetailsEx loc) {
        super(itemRevision, loc);
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.ITEM;
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    /**
     * @return adapter item revision object
     */
    public ItemRevision getItemRevision() {
        return (ItemRevision) getAPIObject();
    }

    @Override
    protected APIObjectAdapter doGetCopy(DimensionsObjectFactory factory) throws Exception {
        // resolve parent object
        DimensionsArObject parent = ((ItemRevision) getAPIObject()).getProject();
        if (parent == null) {
            parent = ((ItemRevision) getAPIObject()).getBaseline();
            if (parent == null) {
                parent = factory.getGlobalProject();
            }
        }

        // lookup copy
        ItemRevision copy = null;
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, getObjectSpec(), Filter.Criterion.EQUALS));
        parent.flushRelatedObjects(ItemRevision.class, true);
        List rels = parent.getChildItems(filter);
        parent.flushRelatedObjects(ItemRevision.class, true);
        if (rels.size() > 0) {
            copy = (ItemRevision) ((DimensionsRelatedObject) rels.get(0)).getObject();
        }

        // check if found
        if (copy == null) {
            IStatus notFoundStatus = new Status(IStatus.ERROR, DMPlugin.ID, 0, NLS.bind(Messages.itemrevision_notfound,
                    getObjectSpec()), null);
            throw new DMException(notFoundStatus);
        }

        return new ItemRevisionAdapter(copy, getConnectionDetails());
    }
}

/*
 * @WorksetAdapter.java, created on Sep 15, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Adapter for Dimensions change documents.
 *
 * @author V.Grishchenko - B Stephenson for Baselines
 */
public class BaselineAdapter extends VersionManagementProject implements IDeletable {

    /**
     * Creates a new workset adapter. Simply calls super class
     * constructor with the supplied arguments.
     *
     * @param apiObject
     * @param connectionDetails
     * @see APIObjectAdapter#APIObjectAdapter(DimensionsLcObject, DimensionsConnectionDetailsEx)
     */
    public BaselineAdapter(Baseline toAdapt, DimensionsConnectionDetailsEx loc) {
        super(toAdapt, loc);
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    @Override
    public Baseline getAPIObject() {
        return (Baseline) super.getAPIObject();
    }

    @Override
    public String getObjectSpec() {
        return getAPIObject().getName();
    }

    /**
     * @return underlying Project
     */
    public Baseline getBaseline() {
        return getAPIObject();
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.BASELINE;
    }

    @Override
    public BaselineList getBaselineList() {
        BaselineList ret = null;
        DimensionsObjectList list = getObjectList();
        if (list instanceof BaselineList) {
            ret = (BaselineList) getObjectList();
        }
        if (ret == null) {
            ret = super.getBaselineList(); // defaults to all
        }
        return ret;
    }

    @Override
    protected APIObjectAdapter doGetCopy(DimensionsObjectFactory factory) throws Exception {
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_SPEC, getObjectSpec(), Filter.Criterion.EQUALS));
        List baselines = factory.getBaselines(filter);
        if (baselines.isEmpty()) {
            IStatus notFoundStatus = new Status(IStatus.ERROR, DMPlugin.ID, 0,
                    NLS.bind(Messages.baseline_notfound, getObjectSpec()), null);
            throw new DMException(notFoundStatus);
        }
        Baseline copy = (Baseline) baselines.get(0);
        return new BaselineAdapter(copy, getConnectionDetails());
    }
}

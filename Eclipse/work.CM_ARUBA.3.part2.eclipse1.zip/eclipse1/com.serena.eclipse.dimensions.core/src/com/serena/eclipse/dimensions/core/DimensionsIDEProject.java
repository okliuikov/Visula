/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import com.serena.dmclient.api.Project;
import com.serena.eclipse.internal.core.IRemoteQueryAwareTreeElement;

/**
 * Class to represent Dimensions IDE projects - contained in DimensionsEclipseProjectList.
 *
 * @author bstephenson
 */
public class DimensionsIDEProject extends WorksetAdapter implements IRemoteQueryAwareTreeElement {
    private String ide;
    private String ideProjectName;
    private String ideUid; // should be a number
    private boolean queryRemote = true;

    public DimensionsIDEProject(Project projectWorkset, DimensionsConnectionDetailsEx loc, String ide, String ideProjectName,
            String ideUid) {
        super(projectWorkset, loc);
        this.ide = ide;
        this.ideProjectName = ideProjectName;
        this.ideUid = ideUid;
    }

    public DimensionsIDEProject(Project projectWorkset, DimensionsConnectionDetailsEx loc) {
        super(projectWorkset, loc);
    }

    public void setIde(String ide) {
        this.ide = ide;
    }

    public String getIde() {
        return ide;
    }

    public void setIdeUid(String ideUid) {
        this.ideUid = ideUid;
    }

    public String getIDEUid() {
        return ideUid;
    }

    public void setName(String ideProjectName) {
        this.ideProjectName = ideProjectName;
    }

    public String getName() {
        return ideProjectName;
    }

    boolean isGroup() {
        return false;
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public BaselineList getBaselineList() {
        return BaselineList.getIDEProjectBaselinesList(getConnectionDetails(), this);
    }


    public WorksetList getProjectList() {
        return WorksetList.getDimensionsIDEProjectWorksetList(getConnectionDetails(), this);
    }

    @Override
    protected boolean isEquivalent(IMappedObjectDetails details) {
        return String.valueOf(details.getMainUid()).equals(ideUid);
    }

    @Override
    public boolean isQueryRemote() {
        return queryRemote;
    }

    @Override
    public void setQueryRemote(boolean queryRemote) {
        this.queryRemote  = queryRemote;
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2007, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.text.DateFormat;
import java.util.Date;

/**
 * Connection specific date formatting and parsing.
 *
 * @author V.Grishchenko
 */
public interface IDateTimeHelper {

    /**
     * <p>
     * Parses a string-encoded date attribute value into <code>java.util.Date</code>, attempts to match several known patterns.
     *
     * <p>
     * Note that even pattern match is successful the correctness is not guaranteed. The only attribute guaranteed to yield a
     * correct result is <code>SystemAttributes.UTC_MODIFIED_DATE</code>, others will produce values that are off by the timezone
     * differences between the current system timezone and the server timezone for system attributes and other client timezone for
     * custom attributes. While incorrect such objects can still be mutually compared in most cases, such as when sorting by date.
     *
     * @param dateAttrValue
     *            string encoded date
     * @param attrNum
     *            attribute number
     * @return new date object if parsing was successful, otherwise returns <code>null</code>
     */
    Date getDate(String dateAttrValue, int attrNum);

    /**
     * @param date
     * @return currently "DD-MMM-YYYY HH24:MM:SS" formatted date in English
     */
    public String formatDatetime(Date date);

    /**
     * @param date
     * @return currently "DD-MMM-YYYY" formatted date in English
     */
    public String formatDate(Date date);

    /**
     * @return "DD-MMM-YYYY HH24:MM:SS" date format in English, the format
     *         object returned should not be cached by the caller as different
     *         objects will be returned by this method when called from
     *         different threads
     */
    public DateFormat getDefaultDatetimeFormat();

    /**
     * @return "DD-MMM-YYYY" date format in English, the format object returned
     *         should not be cached by the caller as different objects will be
     *         returned by this method when called from different threads
     */
    public DateFormat getDefaultDateFormat();

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.RequestList;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author V.Grishchenko
 */
public class ECustomChangeDocumentList extends ChangeDocumentList {

    public static String jobPrefix = "EJPK_"; //$NON-NLS-1$
    public static String ACTIVE_REQUESTS_LIST = "E_ACTIVATED"; //$NON-NLS-1$

    private String listName;
    private String qualifier;
    private QualifiedName listKey;

    ECustomChangeDocumentList(DimensionsConnectionDetailsEx con, RequestList customList, int type) {
        super(con, type);
        Assert.isLegal(type == JOB || type == CUSTOM || type == ACTIVE_ISSUES);
        this.listName = customList.getName();
        this.qualifier = getQualifier(customList, type);
        this.listKey = new QualifiedName(ECustomChangeDocumentList.class.getName(), listName);
        cacheList(customList);
    }

    @Override
    protected List doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final List[] result = new List[1];

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    RequestList customList = getRequestList(session);
                    result[0] = customList != null ? customList.getRequests() : Collections.EMPTY_LIST;
                }

            }, pm);

            return result[0];
        } finally {
            pm.done();
        }
    }

    @Override
    public String getQualifier() {
        return qualifier;
    }

    static String getQualifier(RequestList customList, int type) {
        String name = null;
        if (type == JOB) {
            name = customList.getName();
            name = name.replaceAll(jobPrefix, ""); //$NON-NLS-1$
        } else if (type == CUSTOM) {
            name = customList.getName();
        }
        return name;
    }

    public void delete(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.requestList_delete1, IProgressMonitor.UNKNOWN);
        monitor.subTask(getQualifier());
        try {
            final Session session = getConnectionDetails().openSession(Utils.subMonitorFor(monitor, 5));
            session.run(new APIOperation(NLS.bind(Messages.requestList_delete, getQualifier())) {

                @Override
                protected DimensionsResult doRun() throws Exception {
                    RequestList customList = getRequestList(session);
                    return customList != null ? customList.deleteCustomList() : new DimensionsResult(NLS.bind(
                            Messages.requestList_notFound, listName));
                }
            }, monitor);

            getConnectionDetails().setSessionProperty(listKey, null);
        } finally {
            monitor.done();
        }
    }

    /**
     * Adds change document to this list.
     *
     * @param changeDocs
     *            a list of <code>ChangeDocumentAdapter</code>(s)
     * @throws DMException
     */
    public void addChangeDocuments(List changeDocs, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        try {
            monitor.beginTask(null, 100);
            final Session session = getConnectionDetails().openSession(Utils.subMonitorFor(monitor, 10));
            final List apiList = new ArrayList(changeDocs.size());
            APIObjectAdapter[] adapters = new ChangeDocumentAdapter[changeDocs.size()];
            for (int i = 0; i < changeDocs.size(); i++) {
                Request changeDocument = ((ChangeDocumentAdapter) changeDocs.get(i)).getChangeDocument();
                apiList.add(changeDocument);
                // need to create a new adapter so that the original keeps its list
                adapters[i] = session.adapt(changeDocument);
            }
            session.run(new APIOperation(NLS.bind(Messages.requestList_add, listName)) {

                @Override
                protected DimensionsResult doRun() throws Exception {
                    RequestList customList = getRequestList(session);
                    return customList != null ? customList.addRequests(apiList) : new DimensionsResult(NLS.bind(
                            Messages.requestList_notFound, listName));
                }

            }, monitor);

            monitor.worked(45);
            // add to local cache and notify listeners
            addObjects(adapters);
            update(Utils.subMonitorFor(monitor, 45)); // make sure attributes are cached
        } finally {
            monitor.done();
        }
    }

    public void removeChangeDocuments(final List changeDocs) throws DMException {
        final ChangeDocumentAdapter[] apiObjectList = new ChangeDocumentAdapter[changeDocs.size()];
        final Session session = getConnectionDetails().openSession(null);
        session.run(new APIOperation(NLS.bind(Messages.requestList_remove, listName)) {

            @Override
            public DimensionsResult doRun() throws Exception {
                List apiList = new ArrayList();
                for (int i = 0; i < changeDocs.size(); i++) {
                    ChangeDocumentAdapter changeDocument = (ChangeDocumentAdapter) changeDocs.get(i);
                    apiObjectList[i] = changeDocument;
                    apiList.add(changeDocument.getAPIObject());
                }
                RequestList customList = getRequestList(session);
                return customList != null ? customList.removeRequests(apiList) : new DimensionsResult(NLS.bind(
                        Messages.requestList_notFound, listName));
            }

        }, new NullProgressMonitor());

        removeObjects(apiObjectList);
    }

    private RequestList getRequestList(Session session) throws DMException {
        RequestList result = getCachedList();
        if (result != null) {
            return result;
        }
        // old handle was likely purged due to a disconnect - obtain a new copy
        Filter filter = new Filter();
        filter.criteria().add(new Filter.Criterion(SystemAttributes.OBJECT_ID, listName, Filter.Criterion.EQUALS));
        List lists = session.getObjectFactory().getCurrentUser().getRequestLists(filter);
        if (lists.isEmpty()) {
            return null;
        }
        result = (RequestList) lists.get(0);
        cacheList(result);
        return result;
    }

    private void cacheList(RequestList customList) {
        getConnectionDetails().setSessionProperty(listKey, customList);
    }

    private RequestList getCachedList() {
        return (RequestList) getConnectionDetails().getSessionProperty(listKey);
    }

}

/*---------------------------------------------------------------------------------------------
 *  (c) Copyright 2005 - 2019 Micro Focus or one of its affiliates.

 *  The only warranties for products and services of Micro Focus and its affiliates and licensors
 *  ("Micro Focus") are as may be set forth in the express warranty statements accompanying such
 *  products and services. Nothing herein should be construed as constituting an additional warranty
 *  Micro Focus shall not be liable for technical or editorial errors or omissions contained herein.
 *  The information contained herein is subject to change without notice.

 *  Except as specifically indicated otherwise, this document contains confidential information and
 *  a valid license is required for possession, use or copying. If this work is provided to the
 *  U.S. Government, consistent with FAR 12.211 and 12.212, Commercial Computer Software, Computer
 *  Software Documentation, and Technical Data for Commercial Items are licensed to the U.S. Government
 *  under vendor's standard commercial license.
 *--------------------------------------------------------------------------------------------*/

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ILock;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.DimensionsConnection;
import com.serena.dmclient.api.DimensionsConnectionDetails;
import com.serena.dmclient.api.DimensionsConnectionManager;
import com.serena.dmclient.api.DimensionsDatabaseAdmin;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsRuntimeException;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.Part;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.PulseHelper;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.UIProfile;
import com.serena.dmclient.api.User;
import com.serena.dmclient.collections.FileFormats;
import com.serena.dmclient.collections.Products;
import com.serena.dmclient.collections.Types;
import com.serena.dmclient.collections.ValidSets;
import com.serena.dmclient.objects.AttributeDefinition;
import com.serena.dmclient.objects.DimensionsDatabaseOptions;
import com.serena.dmclient.objects.FileFormat;
import com.serena.dmclient.objects.FileFormatType;
import com.serena.dmclient.objects.Product;
import com.serena.dmclient.objects.RequestProvider;
import com.serena.dmclient.objects.Type;
import com.serena.dmclient.objects.TypeScope;
import com.serena.dmclient.objects.ValidSet;
import com.serena.dmclient.objects.ValidSetRowDetails;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.sbm.ISBMConnection;
import com.serena.eclipse.dimensions.core.sbm.SBMConnectionDetails;
import com.serena.eclipse.dimensions.core.sbm.SBMHelper;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;
import com.serena.eclipse.internal.core.IRemoteQueryAwareTreeElement;
import com.serena.eclipse.internal.core.IServiceViewSearchNode;

/**
 * Adds persistent connection properties. Provides access to a session.
 * Has internal cache of process model data such as attribute definitions.
 *
 * @author BStephenson,V.Grishchenko
 */
public class DimensionsConnectionDetailsEx extends DimensionsConnectionDetails implements IDimensionsServiceResource,
        ISchedulingRule, IServiceViewSearchNode, IRemoteQueryAwareTreeElement {

    private static final String ECLIPSE_CLIENT = "DMECLIPSE"; //$NON-NLS-1$
    private static final String CACHE_PATH_SEPARATOR = "/"; //$NON-NLS-1$
    private static final String CACHE_ROOT = "cache"; //$NON-NLS-1$
    private static final String PRODUCT_PATH = CACHE_ROOT + CACHE_PATH_SEPARATOR + "products"; //$NON-NLS-1$
    private static final String ACTIVE_USERS_PATH = CACHE_ROOT + CACHE_PATH_SEPARATOR + "users" + CACHE_PATH_SEPARATOR + "active"; //$NON-NLS-1$
    private static final String DOCS = "changedocs"; //$NON-NLS-1$
    private static final String ITEMS = "items"; //$NON-NLS-1$
    private static final String WORKSETS = "worksets"; //$NON-NLS-1$
    private static final String BASELINES = "baselines"; //$NON-NLS-1$
    private static final String PARTS = "parts"; //$NON-NLS-1$
    private static final String TYPES = "types"; //$NON-NLS-1$
    private static final String ATTRIBUTES = "attrs"; //$NON-NLS-1$
    private static final String ROLE_SECTIONS = "rolesections"; //$NON-NLS-1$
    private static final String FROM_STATE = "fromstate"; //$NON-NLS-1$
    private static final String TO_STATE = "tostate"; //$NON-NLS-1$
    private static final String FORMAT_IS_TEXT = CACHE_ROOT + CACHE_PATH_SEPARATOR + "format.is.text"; //$NON-NLS-1$

    private static final String IDE_MAP = "idemap"; //$NON-NLS-1$

    public static final String TYPE_REQUEST_PROVIDER_NONE = "NONE"; //$NON-NLS-1$
    public static final String TYPE_REQUEST_PROVIDER_IDM = "IDM"; //$NON-NLS-1$
    public static final String TYPE_REQUEST_PROVIDER_OCTANE = "OIDM"; //$NON-NLS-1$
    public static final String TYPE_REQUEST_PROVIDER_DM = "CM"; //$NON-NLS-1$

    private static final String KEY_WEB_URL = "GUI_URL"; //$NON-NLS-1$
    private static final String KEY_SOAP_URL = "SOAP_URL"; //$NON-NLS-1$
    private static final String KEY_SOLUTION = "SOLUTION"; //$NON-NLS-1$

    private static final String KEY_DM_WEB_URL = "DM_WEB_URL"; //$NON-NLS-1$

    public static final int SBM_AUTHMODE_NORMAL = 1;
    public static final int SBM_AUTHMODE_DM = 2;

    public static final int RECENT_MAXIMUM = 50;
    public static final int RECENT_MINIMUM = 0;

    private static List<ISessionListener> listeners = Collections.synchronizedList(new ArrayList<ISessionListener>());

    private Map<QualifiedName, Object> sessionProperties = Collections.synchronizedMap(new HashMap<QualifiedName, Object>());
    private final ILock changeDefaultProjectLock = Job.getJobManager().newLock();

    private Session session;
    private String connName;
    private boolean auto;
    private String typeString;
    private long lastLogin;
    private boolean offline;

    private UIProfile uiProfile;
    private String uiProfileName;
    private DateTimeHelper dateTimeHelper = new DateTimeHelper(null);

    private String sbmUsername;
    private String sbmDomain;
    private String sbmSoapUrl;
    private String sbmWebUrl;
    private String sbmSolution;
    private long sbmToolUID;
    private int sbmAuthMode = SBM_AUTHMODE_NORMAL;

    private String certificateId = null;
    private boolean isSmartCardLogin;
    private String certificateLabel = null;

    private String requestProviderType = TYPE_REQUEST_PROVIDER_NONE;
    private int databaseOptions = DimensionsDatabaseOptions.DBOPTIONS_BOTHPROJECTSTREAMS;

    private ISBMConnection sbmConnection;
    private String webBaseURL;
    private String pulseBaseURL;

    // R&F settings, connection stores this settings as it aware how to persist their state
    private int maxRecentCount = 10; // default
    private boolean favouritesExpanded = true; // expands by default;
    private boolean recentExpanded = true; // expands by default;

    private SearchStorage searchStorage = new SearchStorage(this);
    private boolean queryRemote = true;

    private static String getTypesPath(String product, String scope) {
        StringBuilder sb = new StringBuilder();
        sb.append(PRODUCT_PATH)
                .append(CACHE_PATH_SEPARATOR)
                .append(product)
                .append(CACHE_PATH_SEPARATOR)
                .append(scope)
                .append(CACHE_PATH_SEPARATOR)
                .append(TYPES);
        return sb.toString();
    }

    private static String getTypePath(String product, String typeName, String scope) {
        StringBuilder sb = new StringBuilder();
        sb.append(PRODUCT_PATH)
                .append(CACHE_PATH_SEPARATOR)
                .append(product)
                .append(CACHE_PATH_SEPARATOR)
                .append(scope)
                .append(CACHE_PATH_SEPARATOR)
                .append(TYPES)
                .append(CACHE_PATH_SEPARATOR)
                .append(typeName);
        return sb.toString();
    }

    private static String getAttributesPath(String product, String typeName, String scope, String roleSection, String fromState,
            String toState) {
        StringBuilder sb = new StringBuilder();
        sb.append(PRODUCT_PATH)
                .append(CACHE_PATH_SEPARATOR)
                .append(product)
                .append(CACHE_PATH_SEPARATOR)
                .append(scope)
                .append(CACHE_PATH_SEPARATOR)
                .append(TYPES)
                .append(CACHE_PATH_SEPARATOR)
                .append(typeName)
                .append(CACHE_PATH_SEPARATOR)
                .append(ATTRIBUTES)
                .append(CACHE_PATH_SEPARATOR)
                .append(ROLE_SECTIONS)
                .append(CACHE_PATH_SEPARATOR)
                .append(roleSection)
                .append(CACHE_PATH_SEPARATOR)
                .append(FROM_STATE)
                .append(CACHE_PATH_SEPARATOR)
                .append(fromState);

        if (toState != null) {
            sb.append(CACHE_PATH_SEPARATOR).append(TO_STATE).append(CACHE_PATH_SEPARATOR).append(toState);
        }

        return sb.toString();
    }

    private static String getPartsPath(String product) {
        return new StringBuilder().append(PRODUCT_PATH)
                .append(CACHE_PATH_SEPARATOR)
                .append(product)
                .append(CACHE_PATH_SEPARATOR)
                .append(PARTS)
                .toString();
    }

    private static QualifiedName getCacheKey(String path) {
        return new QualifiedName("com.serena.eclipse.dimensions.core", path); //$NON-NLS-1$
    }

    private static String getTypeScopeSegment(DimensionsLcObject object) {
        String scope = null;
        if (object instanceof Request) {
            scope = DOCS;
        } else if (object instanceof ItemRevision) {
            scope = ITEMS;
        } else if (object instanceof Project) {
            scope = WORKSETS;
        } else if (object instanceof Baseline) {
            scope = BASELINES;
        } else if (object instanceof Part) {
            scope = PARTS;
        } else {
            assert false; // TODO VG on Jan 16, 2006: other scopes?
        }
        return scope;
    }

    private static String getTypeScopeSegment(TypeScope typeScope) {
        String scope = null;
        if (typeScope == TypeScope.REQUEST) {
            scope = DOCS;
        } else if (typeScope == TypeScope.ITEM) {
            return ITEMS;
        } else if (typeScope == TypeScope.PROJECT) {
            return WORKSETS;
        } else if (typeScope == TypeScope.BASELINE) {
            return BASELINES;
        } else if (typeScope == TypeScope.DESIGN_PART) {
            return PARTS;
        } else {
            assert false; // TODO VG on Jan 31, 2006: other scopes
        }
        return scope;
    }

    public static void addSessionListener(ISessionListener listener) {
        listeners.add(listener);
    }

    public static void removeSessionListener(ISessionListener listener) {
        listeners.remove(listener);
    }

    private static void notifySessionListeners(boolean connect, DimensionsConnectionDetailsEx loc) {
        synchronized (listeners) { // block listener list modes
            for (Iterator<ISessionListener> iter = listeners.iterator(); iter.hasNext();) {
                ISessionListener listener = iter.next();
                if (connect) {
                    listener.sessionCreated(loc);
                } else {
                    listener.sessionDestroyed(loc);
                }
            }
        }
    }

    public DimensionsConnectionDetailsEx(String conname) {
        Assert.isNotNull(conname);
        this.connName = conname;
        setAppName(ECLIPSE_CLIENT);
        setPLCDEnabled(true);
    }

    public DimensionsConnectionDetailsEx(DimensionsConnectionDetails in, String conname, boolean auto, String typeString,
            long lastLogin, String certificateId, boolean isSmartCArdLogin, String certificateLabel) {
        this(conname);
        this.auto = auto;
        this.typeString = typeString;
        this.lastLogin = lastLogin;
        // set embedded connection details
        setUsername(in.getUsername());
        setPassword(in.getPassword());
        setServer(in.getServer());
        setDbName(in.getDbName());
        setDbConn(in.getDbConn());
        this.certificateId = certificateId;
        this.isSmartCardLogin = isSmartCArdLogin;
        this.certificateLabel = certificateLabel;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnectionDetails() {
        return this;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Object getAdapter(Class adapter) {
        return Platform.getAdapterManager().getAdapter(this, adapter);
    }

    @Override
    public String getServiceId() {
        return DMPlugin.SERVICE_ID;
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public boolean contains(ISchedulingRule rule) {
        return isConflicting(rule);
    }

    @Override
    public boolean isConflicting(ISchedulingRule rule) {
        return this == rule;
    }

    /**
     * <p>
     * Two connections are equal if their names are equal.
     * <p>
     * Note: this method overrides superclass implementation, this should not create any problems as it is guaranteed if 2
     * connections have the same name they will have identical underlying details.
     *
     * @see com.serena.dmclient.api.DimensionsConnectionDetails#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o instanceof DimensionsConnectionDetailsEx) {
            DimensionsConnectionDetailsEx otherDetails = (DimensionsConnectionDetailsEx) o;
            return connName.equals(otherDetails.connName);
        }

        return false;
    }

    @Override
    public int hashCode() {
        return connName.hashCode();
    }

    @Override
    public boolean isQueryRemote() {
        return queryRemote;
    }

    @Override
    public void setQueryRemote(boolean queryRemote) {
        this.queryRemote = queryRemote;
    }

    public synchronized ISBMConnection getSBMConnection() {
        if (sbmSoapUrl == null) {
            return null;
        }
        if (sbmConnection == null) {
            SBMConnectionDetails details;
            details = new SBMConnectionDetails(sbmSoapUrl, sbmWebUrl, sbmSolution, getUsername(), getPassword(), null,
                    getSSOToken());
            sbmConnection = SBMHelper.getConnection(details, this);
        }
        return sbmConnection;
    }

    /**
     * Opens session directly using this connection detail's info without
     * consulting authenticator.
     *
     * @param pm
     * @return
     * @throws DMException
     */
    public synchronized Session openSessionDirect(IProgressMonitor pm) throws DMException {
        pm = Utils.monitorFor(pm);
        try {
            pm.beginTask(Messages.session_connect, IProgressMonitor.UNKNOWN);
            if (session == null) {
                Session newSession = new Session(this);
                checkDefaults();
                DimensionsConnection c = DimensionsConnectionManager.getConnection(this);
                setSSOToken(c.getConnectionDetails().getSSOToken());
                readRequestProviderTypeAndDatabaseOptions(c);
                readWebBaseURL(c);
                this.lastLogin = System.currentTimeMillis();
                if (getIsSmartCardLogin()) {// Set user name that we received from SSO token
                    setUsername(c.getConnectionDetails().getUsername());
                }
                initUiProfile(c, DMPlugin.getDefault().getPluggedInAuthenticator());
                DMPlugin.getDefault().updateConnection(this);
                newSession.open(c);
                this.session = newSession;
                this.lastLogin = System.currentTimeMillis();
                DMPlugin.getDefault().updateConnection(this);
				getPulseBaseURLFromServer(c);
                setOffline(false);
                notifySessionListeners(true, this);
                getSearchObjectsStorage().refresh();
            }
        } catch (Throwable t) {
            String errMsg = t.getMessage();
            if (errMsg == null) {
                Throwable cause = t.getCause();
                if (cause != null) {
                    errMsg = cause.getMessage();
                }
            }
            if (errMsg == null) {
                errMsg = Utils.EMPTY_STRING;
            }
            IStatus loginErrorStatus = new Status(IStatus.ERROR, DMPlugin.ID, 0, errMsg, t);
            DMPlugin.getDefault().getLog().log(loginErrorStatus);
            throw new DMException(loginErrorStatus);
        } finally {
            pm.done();
        }
        return session;
    }

    public synchronized Session openSession(IProgressMonitor pm) throws DMException {
        return openSession(null, pm);
    }

    public synchronized Session openSession(IUserAuthenticator authenticator, IProgressMonitor pm) throws DMException {
        pm = Utils.monitorFor(pm);
        try {
            pm.beginTask(Messages.session_connect, IProgressMonitor.UNKNOWN);
            if (session == null) {
                Session newSession = new Session(this);
                newSession.open(authenticator);
                this.session = newSession;
                setOffline(false);
                notifySessionListeners(true, this);
                getSearchObjectsStorage().refresh();
            }
        } finally {
            pm.done();
        }
        return session;
    }

    public/* synchronized */boolean isSessionOpen() {
        return session != null;
    }

    public synchronized void destroySession() {
        if (session != null) {
            session.destroy();
            session = null;
            uiProfile = null;
            requestProviderType = TYPE_REQUEST_PROVIDER_NONE;
            sessionProperties.clear();
            notifySessionListeners(false, this);
            sbmConnection = null;
            sbmSoapUrl = null;
            sbmWebUrl = null;
            sbmSolution = null;
            sbmUsername = null;

            // should be last cleanup as we can be blocked on search storage
            // listener invokes destroy on search storage fetch threads so we can clear storage without delay on refresh completion
            searchStorage.clear();
        }
    }

    /**
     * @return Returns the connName.
     */
    public String getConnName() {
        return connName;
    }

    /**
     * @param lastLogin
     *            The last time a connection was successfully established
     *            with this connection details
     */
    public long lastConnectedOn() {
        return lastLogin;
    }

    /**
     * @return Returns the auto.
     */
    public boolean isAuto() {
        return auto;
    }

    /**
     * @param auto
     *            The auto to set.
     */
    public void setAuto(boolean auto) {
        this.auto = auto;
    }

    /**
     * @return last login time
     */
    public long getLastLogin() {
        return lastLogin;
    }

    /**
     * @param typeString
     *            The typeString to set.
     */
    public void setTypeString(String typeString) {
        this.typeString = typeString;
    }

    /**
     * @return Returns the typeString.
     */
    public String getTypeString() {
        return typeString;
    }

    public boolean isValid() {
        return connName != null;
    }

    public boolean isOffline() {
        return offline;
    }

    public void setOffline(boolean value) {
        if (value && isSessionOpen()) {
            destroySession();
        }
        this.offline = value;
    }

    public Object setSessionProperty(QualifiedName key, Object value) {
        Assert.isNotNull(key);
        Object oldValue;
        synchronized (sessionProperties) {
            if (value == null) {
                oldValue = sessionProperties.remove(key);
            } else {
                oldValue = sessionProperties.put(key, value);
            }
        }
        return oldValue;
    }

    public Object getSessionProperty(QualifiedName key) {
        Assert.isNotNull(key);
        return sessionProperties.get(key);
    }

    /**
     * Obtains the list of products for this connection from internal cache,
     * caching first if necessary.
     *
     * The cache is cleared when the underlying session is
     * destroyed.
     *
     * @return
     * @throws DMException
     */
    public List<Product> getProducts(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.progress_loadProducts, IProgressMonitor.UNKNOWN);
        try {
            QualifiedName key = getCacheKey(PRODUCT_PATH);
            @SuppressWarnings("unchecked")
            List<Product> products = (List<Product>) getSessionProperty(key);
            if (products == null) {
                final List<Product> dbProducts = new ArrayList<Product>();
                final Session session = openSession(null);

                session.run(new ISessionRunnable() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void run() throws Exception {
                        DimensionsObjectFactory dof = session.getObjectFactory();
                        dbProducts.addAll(dof.getBaseDatabase().getProducts());
                    }

                }, monitor);

                products = dbProducts;
                setSessionProperty(key, products);
            }
            return products;
        } finally {
            monitor.done();
        }
    }

    /**
     * Obtains the list of users for this connection from internal cache,
     * caching first if necessary.
     *
     * The cache is cleared when the underlying session is
     * destroyed.
     *
     * @return
     * @throws DMException
     */
    public List<User> getActiveUsers(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.progress_loadUsers, IProgressMonitor.UNKNOWN);
        try {
            QualifiedName key = getCacheKey(ACTIVE_USERS_PATH);
            @SuppressWarnings("unchecked")
            List<User> users = (List<User>) getSessionProperty(key);
            if (users == null) {
                final List<User> dbUsers = new ArrayList<User>();
                final Session session = openSession(null);

                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        DimensionsObjectFactory dof = session.getObjectFactory();
                        Filter filter = new Filter();
                        filter.criteria().add(new Filter.Criterion(SystemAttributes.USER_PRIVILEGE, IDMConstants.USER_PRIVILEGE_ACTIVE, Filter.Criterion.EQUALS));
                        dbUsers.addAll(dof.getBaseDatabase().getUsers(filter));
                        dof.getBulkOperator(dbUsers).queryAttribute(SystemAttributes.USER_FULL_NAME);
                    }

                }, monitor);

                users = dbUsers;
                setSessionProperty(key, users);
            }
            return users;
        } finally {
            monitor.done();
        }
    }
    
    /**
     * Attempts to obtain a product from internal cache, if no products
     * are cached they are cached first.
     *
     * @param product
     * @return
     * @throws DMException
     */
    public Product getProduct(String product, IProgressMonitor monitor) throws DMException {
        List<Product> products = getProducts(monitor);
        for (Iterator<Product> iter = products.iterator(); iter.hasNext();) {
            Product aProduct = iter.next();
            try {
                if (aProduct.getName().equals(product)) {
                    return aProduct;
                }
            } catch (Exception e) {
                String msg = e.getMessage();
                if (msg == null) {
                    msg = Messages.error_noDetails;
                }
                throw new DMException(msg, e);
            }
        }
        return null;
    }

    /**
     * Gets all design parts for the specified product from the internal cache,
     * caching them if necessary.
     *
     * @param productName
     * @return list of <code>Part</code>s.
     * @throws DMException
     */
    public List<Part> getParts(String productName, IProgressMonitor monitor) throws DMException {
        Assert.isNotNull(productName);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.progress_loadParts, IProgressMonitor.UNKNOWN);
        try {
            QualifiedName key = getCacheKey(getPartsPath(productName));
            @SuppressWarnings("unchecked")
            List<Part> partList = (List<Part>) getSessionProperty(key);
            if (partList == null) {
                final Product product = getProduct(productName, Utils.subMonitorFor(monitor, 5));
                if (product == null) {
                    throw new DMException(NLS.bind(Messages.error_productNotFound, productName), null);
                }
                final Unit<List<Part>> listHolder = new Unit<List<Part>>();

                session.run(new ISessionRunnable() {

                    @SuppressWarnings("unchecked")
                    @Override
                    public void run() throws Exception {
                        listHolder.setValue(product.getParts(null));
                    }

                }, monitor);

                partList = listHolder.getValue();
                setSessionProperty(key, partList);
            }
            return partList;
        } finally {
            monitor.done();
        }
    }

    public List<Type> getTypes(final DMTypeScope typeScope, final String productName, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.progress_loadTypes, IProgressMonitor.UNKNOWN);
        try {
            final String scopeSegment = getTypeScopeSegment(typeScope.getClientTypeScope());
            QualifiedName key = getCacheKey(getTypesPath(productName, scopeSegment));
            @SuppressWarnings("unchecked")
            List<Type> typeList = (List<Type>) getSessionProperty(key);
            if (typeList == null) {
                final Product product = getProduct(productName, Utils.subMonitorFor(monitor, 10));
                if (product == null) {
                    throw new DMException(NLS.bind(Messages.error_productNotFound, productName), null);
                }
                final List<Type> dbItemTypes = new ArrayList<Type>();

                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        Types types = product.getTypes(typeScope.getClientTypeScope());

                        for (Iterator<?> iter = types.iterator(); iter.hasNext();) {
                            String typeName = (String) iter.next();
                            if (IDMConstants.PERSONAL_TYPE_NAME.equals(typeName)) {
                                continue;
                            }
                            Type type = types.get(typeName);
                            dbItemTypes.add(type);
                            // cache individual type if not previously cached
                            QualifiedName typeKey = getCacheKey(getTypePath(productName, type.getName(), scopeSegment));
                            if (getSessionProperty(typeKey) == null) {
                                setSessionProperty(typeKey, type);
                            }
                        }
                    }

                }, monitor);

                typeList = dbItemTypes;
                setSessionProperty(key, typeList);
            }
            return typeList;
        } finally {
            monitor.done();
        }
    }

    public Type getType(DMTypeScope typeScope, String product, String type) throws DMException {
        openSession(null);
        QualifiedName key = getCacheKey(getTypePath(product, type, getTypeScopeSegment(typeScope.getClientTypeScope())));

        // see if individual type is already cached
        Type cachedType = (Type) getSessionProperty(key);
        if (cachedType != null) {
            return cachedType;
        }

        // get all types and try to match one by name
        List<Type> allTypes = getTypes(typeScope, product, new NullProgressMonitor()); // this also caches all types
        for (Iterator<Type> iterator = allTypes.iterator(); iterator.hasNext();) {
            Type aType = iterator.next();
            // TODO VG on Jan 31, 2006: use session runnable here?
            if (type.equals(aType.getName())) {
                return aType;
            }
        }
        return null;
    }

    public Type getType(final DimensionsLcObject typedObject, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.progress_loadType, IProgressMonitor.UNKNOWN);
        try {
            openSession(Utils.subMonitorFor(monitor, 10));
            final Type[] resultHolder = new Type[1];

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    Utils.queryAttributes(Collections.singletonList(typedObject), new int[] { SystemAttributes.PRODUCT_NAME,
                            SystemAttributes.TYPE_NAME }, session.getObjectFactory(), true);
                    String productName = (String) typedObject.getAttribute(SystemAttributes.PRODUCT_NAME);
                    String typeName = (String) typedObject.getAttribute(SystemAttributes.TYPE_NAME);
                    String scope = getTypeScopeSegment(typedObject);
                    if (scope != null) {
                        QualifiedName key = getCacheKey(getTypePath(productName, typeName, scope));
                        Type type = (Type) getSessionProperty(key);
                        if (type == null) {
                            type = typedObject.getType();
                            setSessionProperty(key, type);
                        }
                        resultHolder[0] = type;
                    }
                }

            }, monitor);

            return resultHolder[0];
        } finally {
            monitor.done();
        }
    }

    /**
     * Returns all attribute definitions for the supplied type from internal cache,
     * caching them first if necessary. The cache is cleared when the underlying
     * session is destroyed.
     *
     * @param type
     * @return
     * @throws DMException
     */
    public AttributeDefinition[] getAttributeDefinitions(final Type type, final String roleSection,
            final boolean queryValidSetAttrs, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(NLS.bind(Messages.progress_loadRoleAttributes, roleSection), IProgressMonitor.UNKNOWN);
        try {
            openSession(Utils.subMonitorFor(monitor, 5));
            final AttributeDefinition[][] resultHolder = new AttributeDefinition[1][];

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    String productName = type.getProduct().getName();
                    String typeName = type.getName();
                    List<AttributeDefinition> attributes = getAttributeDefinitionsInternal(type, productName, typeName, null, null,
                            roleSection);
                    if (attributes == null) {
                        resultHolder[0] = new AttributeDefinition[0];
                    } else {
                        resultHolder[0] = attributes.toArray(new AttributeDefinition[attributes.size()]);
                    }
                }

            }, monitor);

            return resultHolder[0];
        } finally {
            monitor.done();
        }
    }

    /**
     * Returns attribute definitions for the supplied object and transition from
     * internal cache, caching them first if necessary. The cache is cleared
     * when the underlying session is destroyed. System attributes PRODUCT_NAME,
     * TYPE_NAME, STATUS are queried if not available from the supplied object.
     *
     * @param object
     * @param roleSection
     * @param toState
     * @return
     * @throws DMException
     */
    public AttributeDefinition[] getAttributeDefinitions(final DimensionsLcObject object, final String roleSection,
            final String toState, IProgressMonitor monitor) throws DMException {
        final Type type = getType(object, monitor);
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(NLS.bind(Messages.progress_loadRoleAttributes, roleSection), IProgressMonitor.UNKNOWN);
        try {
            openSession(Utils.subMonitorFor(monitor, 5));
            final AttributeDefinition[][] resultHolder = new AttributeDefinition[1][];

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    final int[] attrsToQuery = new int[] { SystemAttributes.PRODUCT_NAME, SystemAttributes.TYPE_NAME,
                            SystemAttributes.STATUS };
                    Utils.queryAttributes(Collections.singletonList(object), attrsToQuery, session.getObjectFactory(), true);
                    String productName = (String) object.getAttribute(SystemAttributes.PRODUCT_NAME);
                    String typeName = (String) object.getAttribute(SystemAttributes.TYPE_NAME);
                    String fromState = (String) object.getAttribute(SystemAttributes.STATUS);
                    List<AttributeDefinition> attributes = getAttributeDefinitionsInternal(type, productName, typeName, fromState,
                            toState, roleSection);
                    if (attributes == null) {
                        resultHolder[0] = new AttributeDefinition[0];
                    } else {
                        resultHolder[0] = attributes.toArray(new AttributeDefinition[attributes.size()]);
                    }
                }

            }, monitor);

            return resultHolder[0];
        } finally {
            monitor.done();
        }
    }

    private List<AttributeDefinition> getAttributeDefinitionsInternal(Type type, String productName, String typeName,
            String fromState, String toState, String roleSection) {
        String scope = getTypeScopeSegment(type.getScope());
        QualifiedName key = getCacheKey(getAttributesPath(productName, typeName, scope, roleSection, fromState, toState));
        QualifiedName keyAll = getCacheKey(getAttributesPath(productName, typeName, scope, IDMConstants.ROLE_SECTION_ALL,
                fromState, toState));
        QualifiedName keyAllSections = getCacheKey(getAttributesPath(productName, typeName, scope,
                IDMConstants.ROLE_SECTION_ALL_SECTIONS, fromState, toState));
        @SuppressWarnings("unchecked")
        List<AttributeDefinition> attrList = (List<AttributeDefinition>) getSessionProperty(key);
        @SuppressWarnings("unchecked")
        List<AttributeDefinition> attrListAll = (List<AttributeDefinition>) getSessionProperty(keyAll);
        @SuppressWarnings("unchecked")
        List<AttributeDefinition> attrListAllSections = (List<AttributeDefinition>) getSessionProperty(keyAllSections);

        // Getting info from cache if presence. For $all role we trying to get info from $all_role_sections and vice versa.
        // For other roles we get attributes numbers for target role section and construct result list by reducing $all cache
        // to this numbers set
        if (roleSection.equals(IDMConstants.ROLE_SECTION_ALL)) {
            if (attrListAll == null && attrListAllSections != null) {
                setSessionProperty(keyAll, attrListAllSections);
                attrListAll = attrListAllSections;
            } else if (attrListAll == null) {
                attrListAll = getAttributeDefinitionsInternalQuery(type, fromState, toState, roleSection, null);
                setSessionProperty(keyAll, attrListAll);
                setSessionProperty(keyAllSections, attrListAll);
            }
            return attrListAll;
        } else if (roleSection.equals(IDMConstants.ROLE_SECTION_ALL_SECTIONS)) {
            if (attrListAllSections == null && attrListAll != null) {
                setSessionProperty(keyAllSections, attrListAll);
                attrListAllSections = attrListAll;
            } else if (attrListAllSections == null) {
                attrListAllSections = getAttributeDefinitionsInternalQuery(type, fromState, toState, roleSection, null);
                setSessionProperty(keyAllSections, attrListAllSections);
                setSessionProperty(keyAll, attrListAllSections);
            }
            return attrListAllSections;
        } else {
            if (attrList == null) {
                attrList = getAttributeDefinitionsInternalQuery(type, fromState, toState, roleSection, attrListAll);
                setSessionProperty(key, attrList);
            }
            return attrList;
        }
    }

    private List<AttributeDefinition> getAttributeDefinitionsInternalQuery(Type type, String fromState, String toState,
            String roleSection, List<AttributeDefinition> allAttrs) {
        List<AttributeDefinition> result = new ArrayList<AttributeDefinition>();
        if (allAttrs == null) {
            result.addAll(type.getAttributesForRoleSection(fromState, toState, roleSection, true, true, true));
        } else {
            Set<Integer> numsSet = type.getAttributesNumbers(roleSection, fromState);
            if (numsSet != null) {
                for (AttributeDefinition def : allAttrs) {
                    if (numsSet.contains(new Integer(def.getNumber()))) {
                        result.add(def);
                    }
                }
            }
        }
        return result;
    }

    private void checkDefaults() {
        if (getPassword() == null) {
            setPassword(Utils.EMPTY_STRING);
        }
    }

    // attempts to obtain a connection to dm server, if no explicit authenticator
    // is supplied uses a default one from the extension point
    DimensionsConnection openConnection(IUserAuthenticator auth) throws DMException {
        if (auth == null) {
            auth = DMPlugin.getDefault().getPluggedInAuthenticator();
        }
        if (auth == null) {
            throw new RuntimeException("authenticator unavailable"); //$NON-NLS-1$
        }
        String title = Messages.login_default_title;
        String message = Messages.login_default_message;
        IStatus loginErrorStatus = null;
        while (true) {
            setSSOToken(null);
            if (!auth.promptForConnectionDetails(this, title, message, loginErrorStatus) || isOffline()) {
                IStatus cancelStatus = new Status(IStatus.CANCEL, DMPlugin.ID, 0, Messages.connection_loginCanceled, null);
                setPassword(null);
                throw new DMException(cancelStatus);
            }
            try {
                checkDefaults();
                DimensionsConnection con = DimensionsConnectionManager.getConnection(this);
                setSSOToken(con.getConnectionDetails().getSSOToken());
                readRequestProviderTypeAndDatabaseOptions(con);
                readWebBaseURL(con);
                this.lastLogin = System.currentTimeMillis();
                // If a Smart Card connection created earlier ( and not connected on finishing creation ) is used to login then
                // set user name that we receive from SSO token.
                if (getIsSmartCardLogin() && (getUsername() == null)) {
                    setUsername(con.getConnectionDetails().getUsername());
                }
                initUiProfile(con, auth);
                DMPlugin.getDefault().updateConnection(this);
                getPulseBaseURLFromServer(con);
                return con;
            } catch (Throwable t) {
                String errMsg = t.getMessage();
                if (errMsg == null) {
                    Throwable cause = t.getCause();
                    if (cause != null) {
                        errMsg = cause.getMessage();
                    }
                }
                if (errMsg == null) {
                    errMsg = Utils.EMPTY_STRING;
                }
                loginErrorStatus = new Status(IStatus.ERROR, DMPlugin.ID, 0, errMsg, t);
                DMPlugin.getDefault().getLog().log(loginErrorStatus);
            }
        }
    }

    private void initUiProfile(DimensionsConnection con, IUserAuthenticator userAuthenticator) {
        UIProfile theProfile = null;

        @SuppressWarnings("unchecked")
        List<UIProfile> uiProfiles = con.getObjectFactory().getCurrentUser().getUIProfiles();

        if (uiProfiles.isEmpty()) {
            theProfile = null;
        } else if (uiProfiles.size() == 1) {
            theProfile = uiProfiles.get(0);
        } else {
            // more than 1 profile available - if one is previously selected use it
            // if available, otherwise prompt to select
            if (!Utils.isNullEmpty(uiProfileName)) {
                for (Iterator<UIProfile> iterator = uiProfiles.iterator(); iterator.hasNext();) {
                    UIProfile aProfile = iterator.next();
                    if (uiProfileName.equals(aProfile.getName())) {
                        theProfile = aProfile;
                        break;
                    }
                }
            }
            while (theProfile == null) { // insist on getting one from the authenticator
                theProfile = userAuthenticator.promptForProfile(Collections.unmodifiableList(uiProfiles));
            }
        }
        uiProfile = theProfile;
        uiProfileName = uiProfile == null ? null : uiProfile.getName();
    }

    /**
     * Obtains the Map of ide tags to name for this connection from internal cache,
     * caching first if necessary.
     *
     * The cache is cleared when the underlying session is
     * destroyed.
     *
     * @return
     * @throws DMException
     */
    public Map<String, String> getIdeMap() throws DMException {
        QualifiedName key = getCacheKey(IDE_MAP);
        @SuppressWarnings("unchecked")
        Map<String, String> ideMap = (Map<String, String>) getSessionProperty(key);

        if (ideMap == null) {
            final Map<String, String> newIdeMap = new HashMap<String, String>();
            final Session session = openSession(null);

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    // initialize the ide map
                    DimensionsObjectFactory factory = session.getObjectFactory();
                    Products products = factory.getBaseDatabaseAdmin().getProducts();
                    Product generic = products.get("$GENERIC"); //$NON-NLS-1$
                    ValidSets validSets = generic.getValidSets();
                    ValidSet ideValidSet = validSets.get("IDE_PROJECTS"); //$NON-NLS-1$

                    @SuppressWarnings("unchecked")
                    List<ValidSetRowDetails> vsv = ideValidSet.getValues();

                    for (Iterator<ValidSetRowDetails> idevsiter = vsv.iterator(); idevsiter.hasNext();) {
                        ValidSetRowDetails vsrd = idevsiter.next();
                        String col1 = vsrd.getColumnValue(0);
                        String col2 = vsrd.getColumnValue(1);
                        if (col2.startsWith("$")) {//$NON-NLS-1$
                            // only interested in new style - start with $
                            newIdeMap.put(col2, col1);
                        }
                    }
                }

            }, new NullProgressMonitor());

            ideMap = newIdeMap;
            setSessionProperty(key, newIdeMap);
        }
        return ideMap;
    }

    /**
     * @return Returns the ideMapping.
     * @throws DMException
     */
    public String getIdeMapping(String tag) throws DMException {
        if (tag.indexOf(';') >= 0) {
            return Messages.containers_IDEidentifier;
        }
        Map<String, String> ideMapping = getIdeMap();
        if (ideMapping != null) {
            return ideMapping.get(tag);
        }
        return null;
    }

    /**
     * @return the lock that default project changes be synchronized on
     */
    public ILock getChangeDefaultProjectLock() {
        return changeDefaultProjectLock;
    }

    /**
     * @return current ui profile or <code>null</code> for the <all features> profile
     * @throws DMException
     */
    public UIProfile getCurrentUiProfile() throws DMException {
        if (uiProfile == null && !Utils.isNullEmpty(uiProfileName)) {
            openSession(null); // this should set the profile
        }
        return uiProfile;
    }

    /**
     * Sets current UI profile.
     *
     * @param profile
     */
    public void setCurrentUiProfile(UIProfile profile) throws DMException {
        uiProfile = profile;
        uiProfileName = profile == null ? null : profile.getName();
        DMPlugin.getDefault().updateConnection(this);
    }

    public IDateTimeHelper getDateTimeHelper() {
        return dateTimeHelper;
    }

    /**
     * A connection can be configured with a server locale if a locale
     * that is different from local default or english is desired. In the
     * future this may be automatically set from the server data.
     *
     * @return server locale if set, otherwise returns <code>null</code>
     */
    public Locale getServerLocale() {
        return dateTimeHelper.getLocale();
    }

    /**
     * Sets server locale.
     *
     * @param serverLocale
     *            server locale to set, may be <code>null</code> which
     *            implies that system default should be used
     */
    public void setServerLocale(Locale serverLocale) throws DMException {
        dateTimeHelper.setLocale(serverLocale);
        DMPlugin.getDefault().updateConnection(this);
    }

    void setServerLocaleName(String localeName) {
        Locale serverLocale = Utils.isNullEmpty(localeName) ? null : Utils.parseLocale(localeName);
        dateTimeHelper.setLocale(serverLocale);
    }

    public String getSbmSoapUrl() {
        return sbmSoapUrl;
    }

    public void setSbmSoapUrl(String sbmSoapUrl) {
        this.sbmSoapUrl = sbmSoapUrl;
    }

    public String getSbmSolution() {
        return sbmSolution;
    }

    public void setSbmSolution(String sbmSolution) {
        this.sbmSolution = sbmSolution;
    }

    public String getSbmWebUrl() {
        return sbmWebUrl;
    }

    public void setSbmWebUrl(String sbmWebUrl) {
        if (sbmWebUrl != null && sbmWebUrl.indexOf("?") == -1) {
            sbmWebUrl = sbmWebUrl + "?";
        }
        this.sbmWebUrl = sbmWebUrl;
    }
    
    public String getPulseBaseURL() {
        return pulseBaseURL;
    }

    private void getPulseBaseURLFromServer(DimensionsConnection connection) {
        DimensionsObjectFactory dimensionsObjectFactory = connection.getObjectFactory();
        PulseHelper pulseHelper = dimensionsObjectFactory.getPulseHelper();
        try {
            pulseBaseURL = pulseHelper.getPulseBaseUrl();
        } catch (DimensionsRuntimeException e) {
            StringBuilder errorMessage = new StringBuilder();
            errorMessage.append("Cannot get Pulse base URL for CM connection \"");
            errorMessage.append(getConnName()).append("\".");
            DMPlugin.log(DMPlugin.getStatusFromExceptionChain(errorMessage.toString(), IStatus.ERROR, 0, e));
        }
    }

    public String getSBMUser() {
        return sbmUsername;
    }

    public void setSBMUser(String username) {
        this.sbmUsername = username;
    }

    public String getSBMDomain() {
        return sbmDomain;
    }

    public void setSBMDomain(String domain) {
        this.sbmDomain = domain;
    }

    public int getSBMAuthMode() {
        return sbmAuthMode;
    }

    public void setSbmAuthMode(int sbmAuthMode) {
        this.sbmAuthMode = sbmAuthMode;
    }

    public long getSbmToolUID() {
        return sbmToolUID;
    }

    /*
     * @return server locale name or <code>null</code> if invalid locale or not set
     */
    String getServerLocaleName() {
        Locale serverLocale = dateTimeHelper.getLocale();
        if (serverLocale == null) {
            return null;
        }
        String localeName = serverLocale.toString();
        if (localeName.length() == 0) {
            return null;
        }
        return localeName;
    }

    void setCurrentUiProfileName(String uiProfileName) {
        this.uiProfileName = uiProfileName;
    }

    String getCurrentUiProfileName() {
        return uiProfileName;
    }

    @SuppressWarnings("deprecation")
    private void readRequestProviderTypeAndDatabaseOptions(DimensionsConnection con) {
        if (con == null) {
            return;
        }
        RequestProvider provider = con.getObjectFactory().getRequestProvider(null);
        if (provider != null) {
            this.requestProviderType = provider.getShortName();
            if (TYPE_REQUEST_PROVIDER_IDM.equals(requestProviderType)) {
                setSbmSoapUrl(provider.getAttributeValue(KEY_SOAP_URL));
                setSbmWebUrl(provider.getAttributeValue(KEY_WEB_URL));
                setSbmSolution(provider.getAttributeValue(KEY_SOLUTION));
                sbmToolUID = provider.getUID(); // for internal use only
            }
        }
        databaseOptions = con.getObjectFactory().getBaseDatabaseAdmin().getDatabaseOptions().getProjectStreamOptions(true);
    }

    public String getRequestProviderType() {
        return requestProviderType;
    }
    
    public boolean isOctaneRequestProvider() {
        return TYPE_REQUEST_PROVIDER_OCTANE.equals(requestProviderType);
    }
    
    public boolean isSbmRequestProvider() {
        return TYPE_REQUEST_PROVIDER_IDM.equals(requestProviderType);
    }
    
    public boolean isIdmRequestProvider() {
        return !TYPE_REQUEST_PROVIDER_DM.equals(requestProviderType) && 
        !TYPE_REQUEST_PROVIDER_NONE.equals(requestProviderType);
    }

    private void readWebBaseURL(DimensionsConnection con) {
        if (con == null) {
            return;
        }
        webBaseURL = con.getObjectFactory().getServerSymbol(KEY_DM_WEB_URL);
    }

    public String getWebBaseURL() {
        return webBaseURL;
    }

    public boolean isOnlyStreamsActive() {
        return DimensionsDatabaseOptions.DBOPTIONS_STREAMSONLY == databaseOptions;
    }

    public boolean isOnlyProjectsActive() {
        return DimensionsDatabaseOptions.DBOPTIONS_PROJECTSONLY == databaseOptions;
    }

    public boolean isItemRevisionInTextFormat(final ItemRevision rev, IProgressMonitor monitor) throws DMException {
        String format = (String) rev.getAttribute(SystemAttributes.ITEM_FORMAT);
        if (format == null) {
            final Session session = openSession(monitor);

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    rev.queryAttribute(SystemAttributes.ITEM_FORMAT);
                }
            }, new NullProgressMonitor());

            format = (String) rev.getAttribute(SystemAttributes.ITEM_FORMAT);
        }
        if (format == null) {
            return false;
        }
        QualifiedName key = getCacheKey(FORMAT_IS_TEXT + CACHE_PATH_SEPARATOR + format);
        Boolean cachedFormatIsTextFlag = (Boolean) getSessionProperty(key);
        if (cachedFormatIsTextFlag == null) {
            final Session session = openSession(monitor);
            final String sFormat = format;
            final Boolean[] result = new Boolean[1];

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    DimensionsObjectFactory dof = session.getObjectFactory();
                    if (dof != null) {
                        DimensionsDatabaseAdmin dda = dof.getBaseDatabaseAdmin();
                        if (dda != null) {
                            FileFormats ffs = dda.getFileFormats();
                            if (ffs != null) {
                                FileFormat ff = ffs.get(sFormat);
                                if (ff != null) {
                                    result[0] = new Boolean(ff.getType() == FileFormatType.ASCII);
                                }
                            }
                        }
                    }
                }

            }, new NullProgressMonitor());

            cachedFormatIsTextFlag = result[0] != null ? result[0] : Boolean.FALSE;
            setSessionProperty(key, cachedFormatIsTextFlag);
        }
        return cachedFormatIsTextFlag.booleanValue();
    }

    public String getCertificateId() {
        return certificateId;
    }

    public void setCertificateId(String certificateId) {
        this.certificateId = certificateId;
    }

    public boolean getIsSmartCardLogin() {
        return isSmartCardLogin;
    }

    public void setIsSmartCardLogin(boolean isSmartCardLogin) {
        this.isSmartCardLogin = isSmartCardLogin;
    }

    public String getCertificateLabel() {
        return certificateLabel;
    }

    public void setCertificateLabel(String certificateLabel) {
        this.certificateLabel = certificateLabel;
    }

    public int getMaxRecentCount() {
        return maxRecentCount;
    }

    public void setMaxRecentCount(int maxRecentCount) {
        this.maxRecentCount = maxRecentCount;
        try {
            DMPlugin.getDefault().updateConnection(this);
        } catch (DMException e) {
            DMPlugin.log(e.getStatus());
        }
    }

    public boolean isFavouritesExpanded() {
        return favouritesExpanded;
    }

    public void setFavouritesExpanded(boolean expandState) {
        this.favouritesExpanded = expandState;
    }

    public boolean isRecentExpanded() {
        return recentExpanded;
    }

    public void setRecentExpanded(boolean expandState) {
        this.recentExpanded = expandState;
    }

    public SearchStorage getSearchObjectsStorage() {
        return searchStorage;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * @author V.Grishchenko
 */
class IDEFolder extends SBMContainer implements ISBMFolder {
    static final long serialVersionUID = -2351924209912690889L;

    public IDEFolder(DimensionsConnectionDetailsEx connection) {
        // fabricate a URL so it is different from connection
        super(connection.getSBMConnection(), connection.getConnName() + "/idefolder", connection.getSBMConnection()); //$NON-NLS-1$
    }

    @Override
    public int getType() {
        return FOLDER;
    }

    @Override
    public String getName() {
        return "IDE";
    }

    @Override
    public int getFolderType() {
        return IDE;
    }

    @Override
    public String getDisplayUrl() {
        return getConnection().getDisplayUrl();
    }

    @Override
    protected String getMembersUrl() {
        return getConnection().getUrl() + HTTPManager.TT_REPORTS + HTTPManager.TT_IDE_STYLESHEET + HTTPManager.TT_RETURN_ALL_ITEMS;
    }

    @Override
    public boolean isContainer() {
        return false;
    }

}

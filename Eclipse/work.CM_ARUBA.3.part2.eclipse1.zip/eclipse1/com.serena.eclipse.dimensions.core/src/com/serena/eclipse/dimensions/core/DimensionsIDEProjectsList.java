/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
class DimensionsIDEProjectsList extends WorksetList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = DimensionsIDEProjectsList.class.getName();

    /**
     * Creates List of Projects DimensionsIDEProject Instances
     *
     * @param con
     * @param includeOnlyStreams
     *            - List will include only Streams
     * @param includeOnlyProjects
     *            - List will include only Projects
     *            If both includeOnlyStreams and includeOnlyProjects are false then projects and streams will be included in the
     *            list.
     */
    public DimensionsIDEProjectsList(DimensionsConnectionDetailsEx con, boolean includeOnlyStreams, boolean includeOnlyProjects) {
        super(con, includeOnlyStreams ? IDE_STREAMS : includeOnlyProjects ? IDE_PROJECTS : IDE_PROJECTS_AND_STREAMS);
        this.includeOnlyStreams = includeOnlyStreams;
        this.includeOnlyProjects = includeOnlyProjects;
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List<Project> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final Unit<List<Project>> holder = new Unit<List<Project>>();
            EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
    	    final EclipseProjectsFetcher<Project> listsEclipse = listFactory.createEclipseProjectsFetcher();
            final String includeClosedFilter = getIncludeClosedFilter();
            session.run(new ISessionRunnable() {

                @SuppressWarnings("unchecked")
                @Override
                public void run() throws Exception {
                    List<Project> plists = listsEclipse.getSingleProjects(session.getConnectionDetails().getMaxRecentCount(),
                            includeClosedFilter);
                    holder.setValue(plists);
                }

            }, pm);
            return holder.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject doc) {
        return true;
    }

    @Override
    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        Project workset = (Project) dimensionsObject;
        String ideTag = (String) workset.getAttribute(SystemAttributes.IDE_TAG);
        String ideProjectName = (String) workset.getAttribute(SystemAttributes.IDE_PROJECT_NAME);
        Long ideUid = (Long) workset.getAttribute(SystemAttributes.IDE_DM_UID);

        if (ideTag == null)
            ideTag = "";

        if (ideProjectName == null)
            ideProjectName = "";

        if (ideUid == null)
            ideUid = new Long(-1);

        return new DimensionsIDEProject(workset, getConnectionDetails(), ideTag, ideProjectName, ideUid.toString());
    }

    @Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
        // not as a container
        return createIdeObject(session, (DimensionsIDEProjectDetails) objectDetails, IDMConstants.ECLIPSE_SINGLE_PROJECT_TAG,
                IDMConstants.DURULES_ID, true, null, false, monitor);
    }

    /**
     * Finds a workset adapter with specified objectSpec, search is performed
     * on cached objects, server is not contacted.
     *
     * @param objectSpec
     *            - object specification
     * @return workset adapter with specified objectSpec or <code>null</code> if none
     */
    @Override
    public WorksetAdapter findWorkset(String objectSpec) {
        Assert.isLegal(!Utils.isNullEmpty(objectSpec), "objectSpec required"); //$NON-NLS-1$
        APIObjectAdapter[] projects = getObjects();
        for (int i = 0; i < projects.length; i++) {
            DimensionsIDEProject project = (DimensionsIDEProject) projects[i];
            String projObjSpec = project.getObjectSpec();
            if (projObjSpec != null && projObjSpec.equals(objectSpec)) {
                return project;
            }
        }
        return null;
    }
}

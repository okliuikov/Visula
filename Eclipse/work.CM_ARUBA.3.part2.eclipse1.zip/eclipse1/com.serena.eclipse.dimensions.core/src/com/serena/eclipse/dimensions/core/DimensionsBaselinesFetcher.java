/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.core;

import java.util.List;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.SystemAttributes;

/**
 * Allows to fetch baselines using separate dimensions connection
 */
class DimensionsBaselinesFetcher extends DimensionsObjectFetcher<BaselineAdapter, Baseline> {

    public static final int[] BASELINE_ATTRIBUTES = BaselineList.DEFAULT_ATTRIBUTES;

    DimensionsBaselinesFetcher(DimensionsConnectionDetailsEx details) {
        super(details);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected List<Baseline> getObjects() {
        DimensionsObjectFactory factory = connection.getObjectFactory();
        return factory.getBaselines(null);
    }

    @Override
    protected void queryAttributes(List<Baseline> objects) {
        BulkOperator boper = connection.getObjectFactory().getBulkOperator(objects);
        boper.queryAttribute(BASELINE_ATTRIBUTES);
    }

    @Override
    protected BaselineAdapter adapt(Baseline object) {
        String ideTag = (String) object.getAttribute(SystemAttributes.IDE_TAG);

        BaselineAdapter adapter = null;
        if (ideTag != null) {
            adapter = new SccBaselineContainer(object, details, ideTag);
        } else {
            adapter = new BaselineAdapter(object, details);
        }

        return adapter;
    }

}
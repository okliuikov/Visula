/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Base class for all SAX content handlers.
 *
 * @author V.Grishchenko
 */
abstract class SBMContentHandler extends DefaultHandler implements ISBMTags {

    protected ISBMConnection connection;
    protected String m_TTReturnCode = "1";
    protected StringBuffer m_buffer = new StringBuffer();

    /**
     *
     */
    public SBMContentHandler(ISBMConnection connection) {
        this.connection = connection;
    }

    /**
     * Makes this handler ready for a new document.
     */
    public void recycle() {
        m_TTReturnCode = "1";
        m_buffer.setLength(0);
    }

    /**
     * Return the result code from the most recent TeamTrack operation. During
     * parsing of the XML that was returned from TeamTrack, the <return> element
     * was processed and its value is cached. This method converts the code to
     * an integer and returns it.
     *
     * If the XML did not contain a return code, or if parsing failed, 1 is
     * returned. We can't safely assume this means an error occurred, so we
     * return TeamTrack's success code of 1.
     *
     * @return The TeamTrack return code if one was one was contained in the
     *         XML, or 1.
     */
    public int getTTReturnCode() {
        int retVal = 1;

        try {
            retVal = Integer.parseInt(m_TTReturnCode);
        } catch (NumberFormatException e) {
        }

        return retVal;
    }

    /**
     * Return the name of the current XML element. If localName is not empty, it
     * is returned; otherwise qName is returned.
     *
     * @param namespaceURI
     * @param localName
     * @param qName
     * @return
     */
    protected String getElementName(String localName, String qName) {
        if (localName != null && localName.length() > 0) {
            return localName;
        }
        return qName;
    }

    @Override
    public void characters(char[] chars, int startIndex, int length) throws SAXException {
        m_buffer.append(chars, startIndex, length);
    }

}

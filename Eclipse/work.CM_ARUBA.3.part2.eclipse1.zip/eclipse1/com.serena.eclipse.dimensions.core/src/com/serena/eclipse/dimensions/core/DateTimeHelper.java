/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2007, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.serena.dmclient.api.DimensionsUtils;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.util.LocaleConfiguration;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Encapsulates the details of datetime conversion. The following strategy is
 * used to convert date-typed attribute values to java.util.Date objects:
 * - system attributes are parsed against known patterns first in helper's
 * locale then in English. Note that produced date objects are not guaranteed
 * to be correct because we don't know server timezone. One exception is
 * SystemAttributes.UTC_MODIFIED_DATE which is guaranteed to return correct
 * date.
 * - custom attributes are parsed against known patterns first in english
 * locale then in helper's locale.
 * @author V.Grishchenko
 */
class DateTimeHelper implements IDateTimeHelper {
    private static final AttributeDateFormat DEFAULT_DATETIME_FORMAT = new AttributeDateFormat(
            IDMConstants.DEFAULT_DATETIME_PATTERN, Locale.ENGLISH, null);
    private static final AttributeDateFormat DEFAULT_DATE_FORMAT = new AttributeDateFormat(IDMConstants.DEFAULT_DATE_PATTERN,
            Locale.ENGLISH, null);

    private Locale serverLocale;
    private String[] patterns;
    private AttributeDateFormat[] systemFormats; // current system timezone
    private AttributeDateFormat[] systemFormatsGMT; // gmt - for utc attributes
    private AttributeDateFormat[] customFormats;

    /**
     * @param locale default locale, may be <code>null</code> in which case
     *            system default locale is assumed
     */
    public DateTimeHelper(Locale locale) {
        this.serverLocale = locale;
    }

    @Override
    public String formatDatetime(Date date) {
        return DEFAULT_DATETIME_FORMAT.format(date);
    }

    @Override
    public String formatDate(Date date) {
        return DEFAULT_DATE_FORMAT.format(date);
    }

    @Override
    public Date getDate(String dateAttrValue, int attrNum) {
        Date result = null;
        if (!Utils.isNullEmpty(dateAttrValue)) {
            AttributeDateFormat[] supportedFormats = getDateFormats(attrNum);
            for (int i = 0; i < supportedFormats.length; i++) {
                result = supportedFormats[i].parse(dateAttrValue);
                if (result != null) {
                    break;
                }
            }
        }
        return result;
    }

    @Override
    public DateFormat getDefaultDatetimeFormat() {
        return DEFAULT_DATETIME_FORMAT.getDateFormat();
    }

    @Override
    public DateFormat getDefaultDateFormat() {
        return DEFAULT_DATE_FORMAT.getDateFormat();
    }

    // return user specified patterns or null if none
    String[] getPatterns() {
        return patterns;
    }

    // set user specified patterns, supply null to use defaults
    synchronized void setPatterns(String[] patterns) {
        // TODO VG on May 2, 2007: check if same as external and set to null if so,
        // ok for now as user-configurable patterns cannot be specified in the workbench
        this.patterns = patterns;
        systemFormats = systemFormatsGMT = customFormats = null;
    }

    // return user specified locale or null if none
    Locale getLocale() {
        return serverLocale;
    }

    // sets user specified locale
    synchronized void setLocale(Locale locale) {
        this.serverLocale = locale;
        systemFormats = systemFormatsGMT = customFormats = null;
    }

    private Locale internalGetLocale() {
        if (serverLocale == null) {
            return Locale.getDefault();
        }
        return serverLocale;
    }

    private String[] internalGetPatterns() {
        if (patterns == null) {
            return LocaleConfiguration.getInstance().getPatterns();
        }
        return patterns;
    }

    private AttributeDateFormat[] createFormats(Locale[] locales, String[] _patterns, TimeZone timeZone) {
        AttributeDateFormat[] formats = new AttributeDateFormat[locales.length * _patterns.length];
        int pos = 0;
        for (int i = 0; i < locales.length; i++) {
            Locale aLocale = locales[i];
            for (int j = 0; j < _patterns.length; j++) {
                String aPattern = _patterns[j];
                formats[pos] = new AttributeDateFormat(aPattern, aLocale, timeZone);
                pos++;
            }
        }
        return formats;
    }

    private synchronized AttributeDateFormat[] getSystemDateFormatsGMT() {
        if (systemFormatsGMT == null) {
            TimeZone gmtZone = TimeZone.getTimeZone("GMT"); //$NON-NLS-1$
            systemFormatsGMT = createFormats(new Locale[] { internalGetLocale(), Locale.ENGLISH }, internalGetPatterns(), gmtZone);
        }
        return systemFormatsGMT;
    }

    private synchronized AttributeDateFormat[] getSystemDateFormats() {
        if (systemFormats == null) {
            systemFormats = createFormats(new Locale[] { internalGetLocale(), Locale.ENGLISH }, internalGetPatterns(), null);
        }
        return systemFormats;
    }

    private synchronized AttributeDateFormat[] getCustomDateFormats() {
        if (customFormats == null) {
            customFormats = createFormats(new Locale[] { Locale.ENGLISH, internalGetLocale() }, internalGetPatterns(), null);
        }
        return customFormats;
    }

    private AttributeDateFormat[] getDateFormats(int attrNum) {
        if (isSystemAttribute(attrNum)) {
            if (attrNum == SystemAttributes.UTC_MODIFIED_DATE) {
                return getSystemDateFormatsGMT();
            }
            return getSystemDateFormats();
        }

        if (isCustomAttribute(attrNum)) {
            return getCustomDateFormats();
        }
        return new AttributeDateFormat[0];
    }

    private boolean isSystemAttribute(int att) {
        return DimensionsUtils.isSystemAttribute(att);
    }

    private boolean isCustomAttribute(int att) {
        return att > 0;
    }

    private static class AttributeDateFormat extends ThreadLocal {
        String pattern;
        Locale locale;
        TimeZone timeZone;

        AttributeDateFormat(String pattern, Locale locale, TimeZone timeZone) {
            this.pattern = pattern;
            this.locale = locale;
            this.timeZone = timeZone;
        }

        @Override
        protected Object initialValue() {
            SimpleDateFormat dateFormat = new SimpleDateFormat(pattern, locale);
            dateFormat.setLenient(false);
            if (timeZone != null) {
                dateFormat.setTimeZone(timeZone);
            }
            return dateFormat;
        }

        DateFormat getDateFormat() {
            return (DateFormat) get();
        }

        Date parse(String source) {
            if (source == null) {
                return null;
            }
            DateFormat myFormat = getDateFormat();
            ParsePosition ppos = new ParsePosition(0);
            Date date = myFormat.parse(source, ppos);
            if (date != null && ppos.getIndex() < source.length()) {
                date = null; // treat trailing chars as error
            }
            return date;
        }

        String format(Date date) {
            if (date == null) {
                return Utils.EMPTY_STRING;
            }
            return getDateFormat().format(date);
        }

        @Override
        public String toString() {
            StringBuffer buf = new StringBuffer(pattern).append(" - ").append(locale.toString());
            if (timeZone != null) {
                buf.append(" - ").append(timeZone.getID());
            }
            return buf.toString();
        }
    }

}

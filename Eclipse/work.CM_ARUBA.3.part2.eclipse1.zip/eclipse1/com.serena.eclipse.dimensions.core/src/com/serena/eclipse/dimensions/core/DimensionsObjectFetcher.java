/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */
package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.locks.ReentrantLock;

import org.eclipse.core.runtime.NullProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsConnection;
import com.serena.dmclient.api.DimensionsConnectionManager;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * Allows to fetch dimensions objects using separate dimensions connection
 */
abstract class DimensionsObjectFetcher<T extends APIObjectAdapter, E extends DimensionsArObject> implements
        Callable<FetchResult<T>>, ISessionListener {

    private ReentrantLock lock = new ReentrantLock();

    protected DimensionsConnectionDetailsEx details;
    protected DimensionsConnection connection;

    // session is used as a replacement for objects connection
    private Session session;

    DimensionsObjectFetcher(DimensionsConnectionDetailsEx details) {
        Assert.isNotNull(details);
        this.details = details;
    }

    protected abstract List<E> getObjects();

    protected abstract void queryAttributes(List<E> objects);

    protected abstract T adapt(E object);

    @Override
    public FetchResult<T> call() throws Exception {
        Map<String, T> objectsMap = new HashMap<String, T>();

        // Connection state locking allows to reduce blocking time for long running tasks.
        // Session destroy event is able to terminate execution.
        lock.lock();
        try {
            if (session == null) {
                // incorrect class usage, play safe and return empty result
                return new FetchResult<T>(Collections.<String, T>emptyMap());
            }
            this.connection = DimensionsConnectionManager.getConnection(details);
        } finally {
            lock.unlock();
        }

        List<E> objects = fetch();

        if (!createAdapters(objectsMap, objects)) {
            // smth is going wrong
            objectsMap.clear();
        }

        return new FetchResult<T>(objectsMap);
    }

    private List<E> fetch() {
        List<E> objects = new ArrayList<E>();
        try {
            objects = getObjects();
            queryAttributes(objects);
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
        return objects;
    }

    @Override
    public void sessionCreated(DimensionsConnectionDetailsEx loc) {
        lock.lock();
        try {
            if (!loc.isSessionOpen() || !loc.equals(details)) {
                return;
            }

            // get session there as it fresh and new
            this.session = loc.openSession(new NullProgressMonitor());
        } catch (DMException e) {
            // smth is going wrong, play safe
            if (connection != null) {
                connection.close();
            }
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
        lock.lock();
        try {
            if (!loc.equals(details)) {
                return;
            }

            // good place to interrupt current job (if running) as we close connection
            if (connection != null) {
                connection.close();
            }
            this.session = null;
        } finally {
            lock.unlock();
        }
    }

    private boolean createAdapters(Map<String, T> objectsMap, List<E> dimensionsObjects) {
        for (E object : dimensionsObjects) {
            if (Thread.currentThread().isInterrupted() || session == null || !session.isValid()) {
                return false;
            }

            // replace connection with active session
            try {
                object.setDimensionsConnection(session.getConnection());
            } catch (DMException e) {
                return false;
            }

            // get adapter
            T adapter = adapt(object);
            adapter.setStoredInSearchStorage(true);
            objectsMap.put(adapter.getObjectSpec(), adapter);

        }
        return true;
    }

}
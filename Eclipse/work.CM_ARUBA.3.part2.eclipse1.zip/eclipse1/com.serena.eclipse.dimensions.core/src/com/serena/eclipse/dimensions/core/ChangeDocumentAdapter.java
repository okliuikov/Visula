/*
 * @ChangeDocumentAdapter.java, created on Apr 13, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.Request;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Adapter for Dimensions change documents.
 *
 * @author V.Grishchenko
 */
public class ChangeDocumentAdapter extends APIObjectAdapter implements IDeletable {
    private boolean hasReviews = true;

    /**
     * Creates a new change document adapter. Simply calls super class
     * constructor with the supplied arguments.
     *
     * @param apiObject
     * @param connectionDetails
     * @see APIObjectAdapter#APIObjectAdapter(DimensionsLcObject, DimensionsConnectionDetailsEx)
     */
    public ChangeDocumentAdapter(Request chDoc, DimensionsConnectionDetailsEx loc) {
        super(chDoc, loc);
    }

    @Override
    public boolean isContainer() {
        return false;
    }
    
    public void setHasReviews(boolean hasReviews) {
        this.hasReviews = hasReviews;
    }

    public boolean hasReviews() {
        return hasReviews;
    }

    /**
     * @return underlying change document
     */
    public Request getChangeDocument() {
        return (Request) getAPIObject();
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.REQUEST;
    }

    @Override
    protected APIObjectAdapter doGetCopy(DimensionsObjectFactory factory) throws Exception {
        Request copy = factory.findRequest(getObjectSpec());
        if (copy == null) {
            IStatus notFoundStatus = new Status(IStatus.ERROR, DMPlugin.ID, 0,
                    NLS.bind(Messages.request_notfound, getObjectSpec()), null);
            throw new DMException(notFoundStatus);
        }
        return new ChangeDocumentAdapter(copy, getConnectionDetails());
    }

    /**
     * Checks if this Dimensions object (it's adapter) exists in the active request list
     */
    public boolean isActive() {
        try {
            MyWorkingChangeDocumentList activeRequests = ChangeDocumentList.getActiveRequestsList(getConnectionDetails(), null);
            if (activeRequests != null) {
                return activeRequests.contains(this);
            }
        } catch (DMException e) {
            e.printStackTrace();
        }
        return false;
    }

}

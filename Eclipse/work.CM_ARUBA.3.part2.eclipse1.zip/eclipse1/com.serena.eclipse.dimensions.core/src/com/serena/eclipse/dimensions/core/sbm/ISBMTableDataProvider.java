/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.List;

/**
 * @author S.Korniychuk
 */
public interface ISBMTableDataProvider {
    SBMProperty[] getColumns();

    ISBMValueHolder[] getRows();

    ISBMRequest[] getRequests();

    int getTotalCount();

    /**
     * Try to refresh requests in the givven list
     *
     * @param requests
     * @return list of requests that could not be found in the data holder
     */
    List refreshRequests(List requests);
}

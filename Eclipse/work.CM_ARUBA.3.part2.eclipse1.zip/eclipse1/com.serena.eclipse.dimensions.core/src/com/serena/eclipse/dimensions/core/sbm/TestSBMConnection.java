package com.serena.eclipse.dimensions.core.sbm;

import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;

/**
 * ONLY FOR TEST - SBMConnection access class
 * @author kberezovchuk
 */
public class TestSBMConnection extends SBMConnection {

    public TestSBMConnection(SBMConnectionDetails details, DimensionsConnectionDetailsEx dmConnection) {
        super(details, dmConnection);
    }

}

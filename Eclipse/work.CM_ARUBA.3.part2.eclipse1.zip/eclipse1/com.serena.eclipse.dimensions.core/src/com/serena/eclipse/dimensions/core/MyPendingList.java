/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.SystemAttributes;

/**
 * @author V.Grishchenko
 */
class MyPendingList extends ChangeDocumentList implements IDMConstants {
    private static final String LIST_SUBSCRIBER_ID = MyPendingList.class.getName();

    /**
     * Creates my pending list.
     *
     * @param type
     * @param con
     */
    public MyPendingList(DimensionsConnectionDetailsEx con) {
        this(con, false);
    }

    /**
     * Creates my pending or draft list.
     *
     * @param con
     * @param draft
     */
    public MyPendingList(DimensionsConnectionDetailsEx con, boolean draft) {
        super(con, draft ? DRAFT : MY_PENDING);
        attributeSubscribe(LIST_SUBSCRIBER_ID, new int[] { SystemAttributes.CM_PHASE });
    }

    @Override
    protected List doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final List[] result = new List[1];
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    result[0] = session.getObjectFactory().getCurrentUser().getPendingRequests();
                }
            }, pm);
            return result[0];
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject doc) {
        boolean held = HELD_PHASE.equals(doc.getAttribute(SystemAttributes.CM_PHASE));
        return isList(ChangeDocumentList.DRAFT) ? held : !held;
    }

}

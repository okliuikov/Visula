/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.util.List;

/**
 * SBM object that contain active items.
 *
 * @author S.Korniychuk
 */
public interface ISBMActiveItemsHolder extends ISBMObject {

    SBMProperty[] getColumns() throws SBMException;

    /**
     * @return cached member list, returns <code>null</code> if no members are
     *         cached
     */
    List getMembers() throws SBMException;

    ISBMRequest findRequest(String id) throws SBMException;

}

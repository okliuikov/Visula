/*
 * @IUserAuthenticator.java, created on Apr 13, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IStatus;

import com.serena.dmclient.api.UIProfile;
import com.serena.eclipse.dimensions.core.sbm.ChallengeDetails;
import com.serena.eclipse.dimensions.core.sbm.LoginCredentials;

/**
 * Obtains connection details for authentication purposes. Normally
 * authenticator is consulted before a connection is established or
 * re-established.
 *
 * @author V.Grishchenko
 */
public interface IUserAuthenticator {

    /**
     * Implementors are expected to:
     * <UL>
     * <LI>Display the supplied title and message.
     * <LI>Update the supplied server location with connection details.
     * <LI>If status is supplied present it in a user-friendly format since it contains additional details. A good implementation
     * would provide a visual indication for status severity as well as the status message.
     * <UL>
     *
     * @param loc server location for which to obtain location details
     * @param title prompt title that should be displayed to the user
     * @param message prompt message that should be displayed to the user
     * @param status additional status information, it may contain, for example, a reason for a previous authentication failure
     * @return <code>true</code> if prompt was successful, otherwise returns <code>false</code>
     */
    boolean promptForConnectionDetails(DimensionsConnectionDetailsEx loc, String title, String message, IStatus status);

    /**
     * Prompt to pick a profile. Called if multiple profiles are defined.
     *
     * @param uiProfiles the list of profiles to choose from
     * @return selected profile, must not be <code>null</code> otherwise this
     *         method will be called again
     */
    UIProfile promptForProfile(List uiProfiles);

    /**
     * @param challenge details about authentication challenge
     * @param status
     *            additional status information, it may contain, for example, a
     *            reason for a previous authentication failure
     * @return credentials or <code>null</code> if canceled
     */
    LoginCredentials promptForConnectionDetails(ChallengeDetails challenge, IStatus status);

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.internal.core.Messages;
import com.serena.eclipse.internal.core.IRemoteQueryAwareTreeElement;

/**
 *
 * @author bstephenson
 *
 */
public abstract class WorksetList extends DimensionsObjectList implements IRemoteQueryAwareTreeElement {
    /** list containing root IDE projects */
    public static final int IDE_PROJECTS = 1;
    /** list containing IDE project groups */
    public static final int IDE_PROJECT_GROUPS = 2;
    /** list containing all non-ide projects */
    public static final int OTHER_PROJECTS = 3;
    /** list containing root IDE streams */
    public static final int IDE_STREAMS = 8;
    /** list containing IDE Stream groups */
    public static final int IDE_STREAM_GROUPS = 9;
    /** list containing all non-ide Streams */
    public static final int OTHER_STREAMS = 10;
    /** list containing root IDE projects and streams */
    public static final int IDE_PROJECTS_AND_STREAMS = 12;
    /** list containing IDE project and stream groups */
    public static final int IDE_PROJECT_AND_STREAM_GROUPS = 13;
    /** list containing all non-ide projects and streams */
    public static final int OTHER_PROJECTS_AND_STREAMS = 14;
    /** list containing all(project and streams) members of an IDE project */
    public static final int IDE_PROJECT_MEMBER = 4;
    /** list containing Stream members of an IDE project */
    public static final int IDE_PROJECT_MEMBER_STREAM = 16;
    /** list containing Workset members of an IDE project */
    public static final int IDE_PROJECT_MEMBER_WORKSET = 17;
    /** list(Streams and Projects) containing members of an IDE project group */
    public static final int IDE_PROJECT_GROUP_MEMBER = 5; // TODO VG on Oct 2, 2006: needed?
    /** Stream members of an IDE project group */
    public static final int IDE_PROJECT_GROUP_MEMBER_STREAM = 18;
    /** Project members of an IDE project group */
    public static final int IDE_PROJECT_GROUP_MEMBER_WORKSET = 19;
    /** list containing containers for legacy projects */
    public static final int SCC_PROJECT_CONTAINERS = 6;
    /** list containing containers for legacy Streams */
    public static final int SCC_STREAM_CONTAINERS = 11;
    /** list containing containers for legacy Projects and Streams */
    public static final int SCC_PROJECT_AND_STREAM_CONTAINERS = 15;
    /** list containing members of an IDE Project container */
    public static final int SCC_PROJECT_CONTAINERS_MEMBER = 7;
    /** list containing only Stream members of an IDE Project container */
    public static final int SCC_PROJECT_CONTAINERS_STREAM_MEMBERS = 20;
    /** list containing only project members of an IDE Project container */
    public static final int SCC_PROJECT_CONTAINERS_WORKSET_MEMBERS = 21;

    /** list containing favourite IDE and non-IDE streams */
    public static final int FAVOURITE_STREAMS = 22;
    /** list containing favourite IDE and non-IDE projects */
    public static final int FAVOURITE_PROJECTS = 23;
    /** list containing favourite IDE and non-IDE streams and projects */
    public static final int FAVOURITE_PROJECTS_AND_STREAMS = 24;
    /** list containing recent IDE and non-IDE streams */
    public static final int RECENT_STREAMS = 25;
    /** list containing recent IDE and non-IDE projects */
    public static final int RECENT_PROJECTS = 26;
    /** list containing recent IDE and non-IDE streams and projects */
    public static final int RECENT_PROJECTS_AND_STREAMS = 27;

    public static final int UPGRADE_ECLIPSE_SCC_PROJECTS_LIST = 101;
    public static final int UPGRADE_ECLIPSE_PROJECT_CONTAINERS_LIST = 102;

    // @formatter:off
    public static final int[] DEFAULT_ATTRIBUTES = new int[] {
        SystemAttributes.OBJECT_ID,
        SystemAttributes.OBJECT_SPEC,
        SystemAttributes.DESCRIPTION,
        SystemAttributes.CREATION_DATE,
        SystemAttributes.WSET_IS_STREAM,
        SystemAttributes.WSET_MAINLINE_SPEC,
        SystemAttributes.IDE_TAG,
        SystemAttributes.IDE_PROJECT_NAME,
        SystemAttributes.IDE_DM_UID,
        SystemAttributes.IDE_INITIAL,
        SystemAttributes.STATUS,
        SystemAttributes.TYPE_NAME};
    // @formatter:on

    private static ISessionListener sessList = new ISessionListener() {

        @Override
        public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
            lists.remove(loc);
        }

        @Override
        public void sessionCreated(DimensionsConnectionDetailsEx loc) {
        }
    };

    // connection -> {project workset , member workset etc}
    private static Map<DimensionsConnectionDetailsEx, List<DimensionsObjectList>> lists = new ConnectionListsHashMap<DimensionsConnectionDetailsEx, List<DimensionsObjectList>>();

    protected boolean includeOnlyStreams;
    protected boolean includeOnlyProjects;
    private boolean queryRemote = true;

    public WorksetList(DimensionsConnectionDetailsEx con, int type) {
        super(con, type);
        DimensionsConnectionDetailsEx.addSessionListener(sessList);
    }

    public static WorksetList getOtherProjectsList(DimensionsConnectionDetailsEx con, boolean showOnlyStreams,
            boolean showOnlyProjects) {

        // @formatter:off
        WorksetList myList = lookupList(
                con,
                showOnlyStreams ? OTHER_STREAMS : showOnlyProjects ? OTHER_PROJECTS : OTHER_PROJECTS_AND_STREAMS,
                null);
        // @formatter:on

        if (myList == null) {
            myList = new OtherProjectsList(con, showOnlyStreams, showOnlyProjects);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    public static FavouriteProjectsList getFavouriteProjectsList(DimensionsConnectionDetailsEx con, boolean showOnlyStreams,
            boolean showOnlyProjects) {

        // @formatter:off
        WorksetList myList = lookupList(
                con,
                showOnlyStreams ? FAVOURITE_STREAMS : showOnlyProjects ? FAVOURITE_PROJECTS : FAVOURITE_PROJECTS_AND_STREAMS,
                null);
        // @formatter:on

        if (myList == null) {
            myList = new FavouriteProjectsList(con, showOnlyStreams, showOnlyProjects);
            registerList(myList);
        }
        return (FavouriteProjectsList) myList;
    }

    public static RecentProjectsList getRecentProjectsList(DimensionsConnectionDetailsEx con, boolean showOnlyStreams,
            boolean showOnlyProjects) {

        // @formatter:off
        WorksetList myList = lookupList(
                con,
                showOnlyStreams ? RECENT_STREAMS : showOnlyProjects ? RECENT_PROJECTS : RECENT_PROJECTS_AND_STREAMS,
                null);
        // @formatter:on

        if (myList == null) {
            myList = new RecentProjectsList(con, showOnlyStreams, showOnlyProjects);
            registerList(myList);
        }
        return (RecentProjectsList) myList;
    }

    public static WorksetList getDimensionsIDEProjectsList(DimensionsConnectionDetailsEx con, boolean showOnlyStreams,
            boolean showOnlyProjects) {

        // @formatter:off
        WorksetList myList = lookupList(
                con,
                showOnlyStreams ? IDE_STREAMS : showOnlyProjects ? IDE_PROJECTS : IDE_PROJECTS_AND_STREAMS,
                null);
        // @formatter:on

        if (myList == null) {
            myList = new DimensionsIDEProjectsList(con, showOnlyStreams, showOnlyProjects);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    public static WorksetList getDimensionsIDEProjectWorksetList(DimensionsConnectionDetailsEx con, DimensionsIDEProject project) {
        boolean includeOnlyProjects = false;
        boolean includeOnlyStreams = false;
        DimensionsObjectList dol = project.getObjectList();
        if (dol != null && dol instanceof DimensionsIDEProjectsList) {
            if (((DimensionsIDEProjectsList) dol).isIncludeOnlyProjects()) {
                includeOnlyProjects = true;
                includeOnlyStreams = false;
            } else if (((DimensionsIDEProjectsList) dol).isIncludeOnlyStreams()) {
                includeOnlyProjects = false;
                includeOnlyStreams = true;
            }
        }

        // @formatter:off
        WorksetList myList = lookupList(
                con,
                includeOnlyStreams ? IDE_PROJECT_MEMBER_STREAM : includeOnlyProjects ? IDE_PROJECT_MEMBER_WORKSET : IDE_PROJECT_MEMBER,
                (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC));
        // @formatter:on

        if (myList == null) {
            myList = new IDEProjectWorksetList(con, project, includeOnlyStreams, includeOnlyProjects);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    static void removeDimensionsIDEProjectWorksetList(WorksetAdapter project) {
        List<?> conLists = lists.get(project.getConnectionDetails());
        if (conLists == null) {
            return;
        }
        String qualifier = (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
        for (Iterator<?> iter = conLists.iterator(); iter.hasNext();) {
            WorksetList worksetList = (WorksetList) iter.next();
            // @formatter:off
            if ((IDE_PROJECT_MEMBER == worksetList.getType()
                    || IDE_PROJECT_MEMBER_STREAM == worksetList.getType()
                    || IDE_PROJECT_MEMBER_WORKSET == worksetList.getType())
                    && qualifier.equalsIgnoreCase(worksetList.getQualifier())) {
                iter.remove();
            }
            // @formatter:on
        }
    }

    public static WorksetList getDimensionsIDEProjectGroupsList(DimensionsConnectionDetailsEx con, boolean showOnlyStreams,
            boolean showOnlyProjects) {

        // @formatter:off
        WorksetList myList = lookupList(
                con,
                showOnlyStreams ? IDE_STREAM_GROUPS : showOnlyProjects ? IDE_PROJECT_GROUPS : IDE_PROJECT_AND_STREAM_GROUPS,
                null);
        // @formatter:on

        if (myList == null) {
            myList = new DimensionsIDEProjectGroupsList(con, showOnlyStreams, showOnlyProjects);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    public static WorksetList getSccProjectContainerList(DimensionsConnectionDetailsEx con, boolean showOnlyStreams,
            boolean showOnlyProjects) {

        // @formatter:off
        WorksetList containers = lookupList(
                con,
                showOnlyStreams ? SCC_STREAM_CONTAINERS : showOnlyProjects ? SCC_PROJECT_CONTAINERS : SCC_PROJECT_AND_STREAM_CONTAINERS,
                null);
        // @formatter:on

        if (containers == null) {
            containers = new SccProjectContainerList(con, showOnlyStreams, showOnlyProjects);
            containers.addListener(con.getSearchObjectsStorage());
            registerList(containers);
        }
        return containers;
    }

    public static WorksetList getSccProjectContainerMemberList(DimensionsConnectionDetailsEx con, SccProjectContainer project) {
        boolean includeOnlyProjects = false;// Include only Streams in the list
        boolean includeOnlyStreams = false;// Include only Projects in the list
        DimensionsObjectList objectList = project.getObjectList();
        if (objectList != null && objectList instanceof SccProjectContainerList) {
            if (((SccProjectContainerList) objectList).isIncludeOnlyProjects()) {
                includeOnlyProjects = true;
                includeOnlyStreams = false;
            } else if (((SccProjectContainerList) objectList).isIncludeOnlyStreams()) {
                includeOnlyProjects = false;
                includeOnlyStreams = true;
            }
        }

        // @formatter:off
        WorksetList myList = lookupList(
                con,
                includeOnlyStreams ? SCC_PROJECT_CONTAINERS_STREAM_MEMBERS :
                    includeOnlyProjects ? SCC_PROJECT_CONTAINERS_WORKSET_MEMBERS : SCC_PROJECT_CONTAINERS_MEMBER,
                (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC));
        // @formatter:on

        if (myList == null) {
            myList = new SccProjectContainerWorksetList(con, project, includeOnlyStreams, includeOnlyProjects);
            myList.addListener(con.getSearchObjectsStorage());
            registerList(myList);
        }
        return myList;
    }

    /**
     * @return currently known lists for the specified connection
     */
    public static List<DimensionsObjectList> getLists(DimensionsConnectionDetailsEx con) {
        List<DimensionsObjectList> conLists = lists.get(con);
        if (conLists == null) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(conLists);
    }

    protected static WorksetList lookupList(DimensionsConnectionDetailsEx con, int listType, String qualifier) {
        List<DimensionsObjectList> conLists = lists.get(con);
        if (conLists == null) {
            return null;
        }

        for (Iterator<DimensionsObjectList> iter = conLists.iterator(); iter.hasNext();) {
            WorksetList aList = (WorksetList) iter.next();
            if (aList.getType() == listType
                    && ((qualifier == aList.getQualifier()) || (qualifier != null && qualifier.equals(aList.getQualifier())))) {
                DimensionsObjectList.replaceEqualConnectionInstances(con, aList);
                return aList;
            }
        }
        return null;
    }

    protected static void registerList(WorksetList list) {
        List<DimensionsObjectList> conLists = lists.get(list.getConnectionDetails());
        if (conLists == null) {
            conLists = new ArrayList<DimensionsObjectList>(4);
            lists.put(list.getConnectionDetails(), conLists);
        }
        conLists.add(list);
    }

    @Override
    public DMTypeScope getTypeScope() {
        return DMTypeScope.PROJECT;
    }

    @Override
    protected String getUniqueId(DimensionsArObject object) {
        // use the object spec now (name)
        return object.getName();
    }

    protected WorksetCreationResult createIdeObject(Session session, DimensionsIDEProjectDetails worksetDetails, String ideTag,
            String durulesId, boolean initial, Long uid, boolean projectContainer, IProgressMonitor monitor) throws Exception {
        monitor.beginTask(Messages.objectCreate_task, 50);
        monitor.subTask(getTypeScope().getObjectId(worksetDetails));
        try {
            DimensionsResult result = session.getObjectFactory().createProject(worksetDetails);
            monitor.worked(10);
            Project createdWorkset = session.getObjectFactory().getProject(getTypeScope().getObjectId(worksetDetails));
            WorksetCreationResult worksetCreationResult = new WorksetCreationResult(result, createdWorkset);
            monitor.worked(10);
            assert createdWorkset != null;
            createdWorkset.queryAttribute(SystemAttributes.IDE_PROJECT_NAME);
            createdWorkset.queryAttribute(SystemAttributes.IDE_TAG);
            monitor.worked(10);
            // check if the newly created workset has the ide project value auto-populated,
            // if not then update it from our settings, this handles:
            // 1. build 4 server which does not yet propagate groups
            // 2. conversion from a non-IDE to IDE workset
            // 3. project groups
            // BKS 04/12/06 revise tests - no longer need to handle build 4 server
            // now server propagates information correctly
            if (worksetDetails.getBasedOnBaseline() == null && worksetDetails.getBasedOnProject() == null) {
                // not based on anything so a new workset
                createdWorkset.setIdeInfo(ideTag, worksetDetails.getProject(), createdWorkset, initial);
                monitor.worked(10);
                if (!projectContainer && initial) {
                    String part = worksetDetails.getPart();
                    if (part != null) {
                        int idx = part.indexOf(':');
                        if (idx != -1) {
                            // remove product prefix
                            part = part.substring(idx + 1);
                        }
                        idx = part.indexOf(';');
                        if (idx != -1) {
                            // remove PCS suffix
                            part = part.substring(0, idx);
                        }
                    }

                    session.getObjectFactory().copyDurules(durulesId, createdWorkset, part);
                }
                monitor.worked(10);
            } else {
                monitor.worked(20);
            }
            return worksetCreationResult;
        } finally {
            monitor.done();
        }
    }

    /**
     * Finds a workset adapter with specified objectSpec.
     *
     * @param objectSpec
     *            - object specification
     * @return null by default
     */
    public WorksetAdapter findWorkset(String objectSpec) {
        return null; // default implementation
    }

    public void setIncludeOnlyStreams(boolean showOnlyStreams) {
        this.includeOnlyStreams = showOnlyStreams;
    }

    public void setIncludeOnlyProjects(boolean showOnlyProjects) {
        this.includeOnlyProjects = showOnlyProjects;
    }

    public boolean isIncludeOnlyStreams() {
        return includeOnlyStreams;
    }

    public boolean isIncludeOnlyProjects() {
        return includeOnlyProjects;
    }

    @Override
    public boolean isQueryRemote() {
        return queryRemote;
    }

    @Override
    public void setQueryRemote(boolean queryRemote) {
        this.queryRemote = queryRemote;
    }

}

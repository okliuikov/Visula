/*
 * @DimensionsIDEProject.java, created on 30-Sep-2005
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;

import com.serena.dmclient.api.Baseline;
import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.SystemRelationship;
import com.serena.eclipse.internal.core.IRemoteQueryAwareTreeElement;

/**
 * Class to represent Dimensions IDE projects - contained in DimensionsEclipseProjectList.
 *
 * @author bstephenson
 *
 */
public class DimensionsIDEProjectGroup extends WorksetAdapter implements IWithAPIMembers, IRemoteQueryAwareTreeElement {
    private String ide;
    private String ideProjectName;
    private boolean queryRemote = true;

    public DimensionsIDEProjectGroup(Project groupWorkset, DimensionsConnectionDetailsEx loc, String ide, String ideProjectName) {
        super(groupWorkset, loc);
        this.ide = ide;
        this.ideProjectName = ideProjectName;
    }

    public DimensionsIDEProjectGroup(Project projectWorkset, DimensionsConnectionDetailsEx loc) {
        super(projectWorkset, loc);
    }

    public void setIde(String ide) {
        this.ide = ide;
    }

    public String getIde() {
        return ide;
    }

    public void setName(String IDEProjectName) {
        this.ideProjectName = IDEProjectName;
    }

    public String getName() {
        return ideProjectName;
    }

    boolean isGroup() {
        return true;
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public APIObjectAdapter[] getMembers(final IProgressMonitor monitor) {
        // for a group get the child worksets and baselines
        final APIObjectAdapter[][] remoteProjects = new APIObjectAdapter[1][];
        final DimensionsIDEProjectGroup ideProjectGroup = this;
        final DimensionsConnectionDetailsEx loc = ideProjectGroup.getConnectionDetails();
        try {
            final Session session = loc.openSession(monitor);
            session.run(new ISessionRunnable() {
                @Override
                public void run() {
                    Filter wsf = new Filter();
                    wsf.criteria().add(new Filter.Criterion(FilterOptions.USAGE_RELATIONSHIP, Boolean.TRUE, 0));

                    ideProjectGroup.getWorkset().flushRelatedObjects(Project.class, true);
                    List relatedWorksets = ideProjectGroup.getWorkset().getChildProjects(wsf);
                    ideProjectGroup.getWorkset().flushRelatedObjects(Project.class, true);

                    ideProjectGroup.getWorkset().flushRelatedObjects(Baseline.class, true);
                    List relatedBaselines = ideProjectGroup.getWorkset().getChildBaselines(wsf);
                    ideProjectGroup.getWorkset().flushRelatedObjects(Baseline.class, true);

                    List adapters = new ArrayList();
                    for (Iterator worksetsIterator = relatedWorksets.iterator(); worksetsIterator.hasNext();) {
                        Project project = (Project) ((DimensionsRelatedObject) worksetsIterator.next()).getObject();
                        project.queryAttribute(SystemAttributes.IDE_TAG);
                        String tag = (String) project.getAttribute(SystemAttributes.IDE_TAG);
                        if (tag != null && (tag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1)) {
                            SccProjectContainerWorkset sccWs = new SccProjectContainerWorkset(project, loc);
                            APIObjectAdapter[] containedScc = sccWs.getMembers(monitor);
                            for (int i = 0; i < containedScc.length; i++) {
                                adapters.add(containedScc[i]);
                            }
                        } else {
                            APIObjectAdapter a = session.adapt(project);
                            adapters.add(a);
                        }
                    }

                    for (Iterator baselineIterator = relatedBaselines.iterator(); baselineIterator.hasNext();) {
                        Baseline baseline = (Baseline) ((DimensionsRelatedObject) baselineIterator.next()).getObject();
                        baseline.queryAttribute(SystemAttributes.IDE_TAG);
                        String tag = (String) baseline.getAttribute(SystemAttributes.IDE_TAG);
                        if (tag != null && (tag.indexOf(IDMConstants.SCC_ECLIPSE_PROJECT_CONTAINER_TAG) != -1)) {
                            SccBaselineContainer sccBl = new SccBaselineContainer(baseline, loc);
                            APIObjectAdapter[] containedScc = sccBl.getMembers(monitor);
                            for (int i = 0; i < containedScc.length; i++) {
                                adapters.add(containedScc[i]);
                            }
                        } else {
                            APIObjectAdapter a = session.adapt(baseline);
                            adapters.add(a);
                        }
                    }
                    remoteProjects[0] = (APIObjectAdapter[]) adapters.toArray(new APIObjectAdapter[adapters.size()]);
                }
            }, monitor);
        } catch (DMException e1) {
            DMPlugin.log(e1.getStatus());
        }
        return remoteProjects[0];
    }

    /**
     * @return list of worksets/baselines in the group
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public List getGroupContents() {
        Filter wsf = new Filter();
        wsf.criteria().add(new Filter.Criterion(FilterOptions.USAGE_RELATIONSHIP, Boolean.TRUE, 0));
        getWorkset().flushRelatedObjects(Project.class, true);
        List usageWs = getWorkset().getChildProjects(wsf);
        getWorkset().flushRelatedObjects(Project.class, true);

        Filter blf = new Filter();
        blf.criteria().add(new Filter.Criterion(FilterOptions.USAGE_RELATIONSHIP, Boolean.TRUE, 0));
        getWorkset().flushRelatedObjects(Baseline.class, true);
        List usageBl = getWorkset().getChildBaselines(blf);
        getWorkset().flushRelatedObjects(Baseline.class, true);

        usageWs.addAll(usageBl);
        // create a list of the objects themselves
        List retList = new ArrayList();
        for (Iterator contit = usageWs.iterator(); contit.hasNext();) {
            retList.add(((DimensionsRelatedObject) contit.next()).getObject());
        }
        return retList;
    }

    @Override
    public BaselineList getBaselineList() {
        return BaselineList.getProjectGroupBaselinesList(getConnectionDetails(), this);
    }

    @SuppressWarnings({ "rawtypes" })
    public boolean groupContains(VersionManagementProject p) {
        List contents = getGroupContents();
        if (contents.contains(p.getAPIObject())) {
            return true;
        }
        return false;

    }

    // returns a compatible version management project e.g one with same uid
    // else null
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public VersionManagementProject[] groupContainsSameProject(final VersionManagementProject p) throws DMException {
        DimensionsConnectionDetailsEx con = getConnectionDetails();
        final List retList = new ArrayList();

        // get my UID
        final Long[] myUid = new Long[1];
        final Session s = con.openSession(null);
        s.run(new ISessionRunnable() {
            @Override
            public void run() {
                p.getAPIObject().queryAttribute(SystemAttributes.IDE_DM_UID);
                myUid[0] = (Long) p.getAPIObject().getAttribute(SystemAttributes.IDE_DM_UID);

            }
        }, new NullProgressMonitor());
        if (myUid[0] != null) {
            final List contents = getGroupContents();

            s.run(new ISessionRunnable() {
                @Override
                public void run() throws DMException {
                    // split lists
                    ArrayList projects = new ArrayList();
                    ArrayList baselines = new ArrayList();
                    for (Iterator iter = contents.iterator(); iter.hasNext();) {
                        Object o = iter.next();
                        if (o instanceof Project) {
                            projects.add(o);
                        } else {
                            baselines.add(o);
                        }
                    }

                    BulkOperator bop = s.getObjectFactory().getBulkOperator(projects);
                    bop.queryAttribute(SystemAttributes.IDE_DM_UID);
                    for (Iterator projiter = projects.iterator(); projiter.hasNext();) {
                        DimensionsArObject thisProject = (DimensionsArObject) projiter.next();
                        Long dmUid = (Long) thisProject.getAttribute(SystemAttributes.IDE_DM_UID);
                        if (dmUid != null) {
                            if (dmUid.equals(myUid[0])) {
                                // have a project with same uid
                                retList.add(s.adapt(thisProject));
                            }
                        }
                    }

                    BulkOperator bob = s.getObjectFactory().getBulkOperator(baselines);
                    bob.queryAttribute(SystemAttributes.IDE_DM_UID);
                    for (Iterator bliter = baselines.iterator(); bliter.hasNext();) {
                        DimensionsArObject thisProject = (DimensionsArObject) bliter.next();
                        Long dmUid = (Long) thisProject.getAttribute(SystemAttributes.IDE_DM_UID);
                        if (dmUid != null) {
                            if (dmUid.equals(myUid[0])) {
                                // have a baseline with same uid
                                retList.add(s.adapt(thisProject));
                            }
                        }
                    }
                }
            }, new NullProgressMonitor());
        }
        return (VersionManagementProject[]) retList.toArray(new VersionManagementProject[retList.size()]);
    }

    public DimensionsResult addMember(VersionManagementProject p, String relativeLocation, final String message) throws DMException {
        DimensionsConnectionDetailsEx con = getConnectionDetails();
        final Session s = con.openSession(null);

        final APIObjectAdapter apiObj = p;
        final DimensionsResult[] res = new DimensionsResult[1];
        final String relLoc = relativeLocation == null ? "." : relativeLocation;

        s.run(new ISessionRunnable() {
            @Override
            public void run() {
                // print
                if (message != null) {
                    String spec = (String) apiObj.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
                    DMPlugin.getDefault().getConsole().printMessage(message + " " + spec);
                }

                // TODO get the ide project name
                DimensionsResult addResult = null;
                if (apiObj instanceof WorksetAdapter) {
                    addResult = getAPIObject().addChildProject(SystemRelationship.USAGE,
                            (Project) apiObj.getAPIObject(), relLoc, null);
                } else if (apiObj instanceof BaselineAdapter) {
                    addResult = getAPIObject().addChildBaseline(SystemRelationship.USAGE,
                            (Baseline) apiObj.getAPIObject(), relLoc, null);
                }
                if (addResult != null) {
                    DMPlugin.getDefault().getConsole().printMessage(addResult.getMessage());
                    res[0] = addResult;
                }
            }
        }, new NullProgressMonitor());

        return res[0];
    }

    public DimensionsResult removeMember(VersionManagementAdapter p, final String message) throws DMException {
        DimensionsConnectionDetailsEx con = getConnectionDetails();
        final Session s = con.openSession(null);

        final DimensionsLcObject apiObj = (DimensionsLcObject) p.getAPIObject();
        final DimensionsResult[] res = new DimensionsResult[1];

        s.run(new ISessionRunnable() {
            @Override
            public void run() {
                // print
                if (message != null) {
                    String spec = (String) apiObj.getAttribute(SystemAttributes.OBJECT_SPEC);
                    DMPlugin.getDefault().getConsole().printMessage(message + " " + spec);
                }

                DimensionsResult remResult = null;
                if (apiObj instanceof Project) {
                    remResult = getAPIObject().removeChild(SystemRelationship.USAGE, apiObj);
                } else if (apiObj instanceof Baseline) {
                    remResult = getAPIObject().removeChild(SystemRelationship.USAGE, apiObj);
                }
                if (remResult != null) {
                    DMPlugin.getDefault().getConsole().printMessage(remResult.getMessage());
                    res[0] = remResult;
                }
            }
        }, new NullProgressMonitor());

        return res[0];
    }

    @Override
    protected boolean isEquivalent(IMappedObjectDetails details) {
        // assume true if at least one mapped from the same connection as cannot
        // efficiently determine if group members are mapped
        return true;
    }

    @Override
    public boolean isQueryRemote() {
        return queryRemote ;
    }

    @Override
    public void setQueryRemote(boolean queryRemote) {
        this.queryRemote = queryRemote;
    }

}

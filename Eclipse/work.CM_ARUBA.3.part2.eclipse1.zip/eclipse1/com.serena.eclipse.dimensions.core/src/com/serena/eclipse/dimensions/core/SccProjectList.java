/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;

import com.serena.dmclient.api.DeliverCommandDetails;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsRelatedObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.FilterOptions;
import com.serena.dmclient.api.ItemRevision;
import com.serena.dmclient.api.ItemRevisionDetails;
import com.serena.dmclient.api.Project;
import com.serena.dmclient.api.RepositoryFolder;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.api.UploadCommandDetails;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * @author V.Grishchenko
 */

public class SccProjectList extends DimensionsObjectList implements IDMConstants {
	/** legacy projects */
	public static final int PROJECT = 1;
	/** legacy baselines */
	public static final int BASELINE = 2;

	private static final String LIST_SUBSCRIBER_ID = SccProjectList.class.getName();

	final public static int IN_WORKAREA_ATTR = 1;
	final public static int IN_USERDIR_ATTR = 2;
	final public static int IN_OFFSET_ATTR = 3;

	private static ISessionListener sessList = new ISessionListener() {

		@Override
		public void sessionDestroyed(DimensionsConnectionDetailsEx loc) {
			lists.remove(loc);
		}

		@Override
		public void sessionCreated(DimensionsConnectionDetailsEx loc) {
		}
	};

	// connection -> {list 1, list2}
	private static Map<DimensionsConnectionDetailsEx, List<DimensionsObjectList>> lists = new ConnectionListsHashMap<DimensionsConnectionDetailsEx, List<DimensionsObjectList>>();

	private APIObjectAdapter container;

	protected static SccProjectList lookupList(DimensionsConnectionDetailsEx con, int listType, String qualifier) {
		List<DimensionsObjectList> conLists = lists.get(con);
		if (conLists == null) {
			return null;
		}

		for (Iterator<DimensionsObjectList> iter = conLists.iterator(); iter.hasNext();) {
			SccProjectList aList = (SccProjectList) iter.next();
            if (aList.getType() == listType
                    && ((qualifier == aList.getQualifier()) || (qualifier != null && qualifier.equals(aList.getQualifier())))) {
				DimensionsObjectList.replaceEqualConnectionInstances(con, aList);
				return aList;
			}
		}
		return null;
	}

	protected static void registerList(SccProjectList list) {
		List<DimensionsObjectList> conLists = lists.get(list.getConnectionDetails());
		if (conLists == null) {
			conLists = new ArrayList<DimensionsObjectList>(4);
			lists.put(list.getConnectionDetails(), conLists);
		}
		conLists.add(list);
	}

	private static int getType(APIObjectAdapter container) {
		return container.getTypeScope() == DMTypeScope.PROJECT ? PROJECT : BASELINE;
	}

	/**
	 * @param container
	 *            <code>SccProjectContainer</code> or
	 *            <code>SccBaselineContainer</code>
	 * @return
	 */
	public static SccProjectList getProjectList(APIObjectAdapter container) {
		Assert.isLegal(container instanceof SccProjectContainerWorkset || container instanceof SccBaselineContainer,
				"project or baseline container expected"); //$NON-NLS-1$
        SccProjectList list = lookupList(container.getConnectionDetails(), getType(container), container.getObjectSpec());
		if (list == null) {
			list = new SccProjectList(container);
			registerList(list);
		}
		return list;
	}

	/**
	 * @param container
	 */
	public SccProjectList(APIObjectAdapter container) {
		super(container.getConnectionDetails(), getType(container));
		Assert.isLegal(container instanceof SccProjectContainerWorkset || container instanceof SccBaselineContainer,
				"project or baseline container expected"); //$NON-NLS-1$
		this.container = container;
        attributeSubscribe(LIST_SUBSCRIBER_ID, new int[] { SystemAttributes.ITEMFILE_DIR, SystemAttributes.ITEMFILE_FILENAME });
		DimensionsConnectionDetailsEx.addSessionListener(sessList);
	}

	public APIObjectAdapter getContainer() {
		return container;
	}

	@Override
	public String getQualifier() {
		return container.getObjectSpec();
	}

	@Override
	protected List doFetch(final Session session, IProgressMonitor pm) throws DMException {
		final List[] resultHolder = new List[1];
		pm.beginTask(null, IProgressMonitor.UNKNOWN);
		try {
			session.run(new ISessionRunnable() {
				@Override
				public void run() throws Exception {
			        EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
				    final EclipseProjectsFetcher listsEclipse = listFactory.createEclipseProjectsFetcher();
					
					List markerRels = listsEclipse.getChildren(session.getConnectionDetails().getMaxRecentCount(), container.getAPIObject(), 
							container.getTypeScope().toString());
					container.getAPIObject().flushRelatedObjects(ItemRevision.class, true);

					resultHolder[0] = markerRels;
				}
			}, pm);
		} finally {
			pm.done();
		}

		return resultHolder[0];
	}

	@Override
	protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
		ItemRevision markerFile = (ItemRevision) dimensionsObject;
		SccProject adapter = new SccProject(markerFile, session.getConnectionDetails(), container);
		return adapter;
	}

	@Override
    protected DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails, IProgressMonitor monitor)
            throws Exception {
		Assert.isLegal(objectDetails instanceof ItemRevisionDetails);
		monitor.beginTask(Messages.objectCreate_task, IProgressMonitor.UNKNOWN);
		monitor.subTask(getTypeScope().getObjectId(objectDetails));
		DimensionsResult res = null;
		try {
			Project createIn = (Project) container.getAPIObject();
			ItemRevisionDetails det = (ItemRevisionDetails) objectDetails;
			createIn.queryAttribute(SystemAttributes.WSET_IS_STREAM);

			if (((Boolean) (createIn.getAttribute(SystemAttributes.WSET_IS_STREAM))).booleanValue()) {
				res = createIn.deliver(getDeliverCommandDetails(det));
			} else {
				res = createIn.upload(getUploadCommandDetails(det));
			}

            // here we are creating a SCC project marker so we need to copy the Durules
			String part = ((ItemRevisionDetails) objectDetails).getOwningPartSpecification();
			// part spec was set from wizard
			if (part != null) {
				int idx = part.indexOf(':');
				if (idx != -1) {
					// remove product prefix
					part = part.substring(idx + 1);
				}
				idx = part.indexOf(';');
				if (idx != -1) {
					// remove PCS suffix
					part = part.substring(0, idx);
				}
			}

            // need the item revision for uid of the new marker, lookup by id is unreliable, use path (DEF129453)
            String fullPath = det.getProjectFileName().replace('\\', '/'); // project file name should not be null
			String parentDir = Utils.EMPTY_STRING;
			String fileName = fullPath;
			int lastSepIdx = fullPath.lastIndexOf('/');
			if (lastSepIdx != -1 && lastSepIdx != 0) {
				parentDir = fullPath.substring(0, lastSepIdx + 1);
			}
			if (lastSepIdx != -1) {
				fileName = fullPath.substring(lastSepIdx + 1);
			}

			ItemRevision createdMarker = null;
			Filter filter = new Filter();
            filter.criteria().add(new Filter.Criterion(SystemAttributes.ITEMFILE_FILENAME, fileName, Filter.Criterion.EQUALS));
			filter.criteria().add(new Filter.Criterion(SystemAttributes.IS_LATEST_REVFV, Utils.EMPTY_STRING, 0));
            // SET PARANOIA HIGH - normally marker should not be created in a root folder
			if (parentDir.length() == 0) {
                // get the item from the root folder as Oracle does not distinguish between empty string and null
				RepositoryFolder root = createIn.getRootFolder();
				root.flushRelatedObjects(ItemRevision.class, true);
				List members = root.getLatestItemRevisions(filter);
				root.flushRelatedObjects(ItemRevision.class, true);
				if (!members.isEmpty()) {
					assert members.size() == 1;
					createdMarker = (ItemRevision) members.get(0);
				}
			} else {
				filter.criteria().add(new Filter.Criterion(FilterOptions.USAGE_RELATIONSHIP, Boolean.TRUE, 0));
                filter.criteria().add(new Filter.Criterion(SystemAttributes.ITEMFILE_DIR, parentDir, Filter.Criterion.EQUALS));
				createIn.flushRelatedObjects(ItemRevision.class, true);
				List relationships = createIn.getChildItems(filter);
				createIn.flushRelatedObjects(ItemRevision.class, true);
				if (!relationships.isEmpty()) {
					assert relationships.size() == 1;
					createdMarker = (ItemRevision) ((DimensionsRelatedObject) relationships.get(0)).getObject();
				}
			}
			// SET PARANOIA LOW
			assert createdMarker != null;
			if (createdMarker != null) {
				session.getObjectFactory().copyDurules(IDMConstants.SCC_DURULES_ID, createdMarker, part);
			}
			return res;
		} finally {
			monitor.done();
		}
	}

	private DeliverCommandDetails getDeliverCommandDetails(ItemRevisionDetails det) throws IOException {
		DeliverCommandDetails deliverDetails = new DeliverCommandDetails();

		// create the marker file in a temporary location on the disk
		File markerFile = getMarkerFile(det);
		createMarkerFileOnDisk(markerFile);
		List<File> filesToDeliver = new ArrayList<File>();
		filesToDeliver.add(markerFile);
		deliverDetails.setFilesToTransfer(filesToDeliver);
		deliverDetails.setItemType(IDMConstants.TYPE_PROJECT);
		deliverDetails.setRelatedRequests(det.getRelatedRequests());
		deliverDetails.setComment(det.getComment());
		deliverDetails.setEnableAdd(true);
		deliverDetails.setPart(det.getOwningPartSpecification());

		if (StringPath.isNullorEmpty((String) det.getAttribute(IN_WORKAREA_ATTR))) {
			deliverDetails.setRelativeLocation((String) det.getAttribute(IN_OFFSET_ATTR));
			deliverDetails.setUserDirectory((String) det.getAttribute(IN_USERDIR_ATTR));
		}

		if (!StringPath.isNullorEmpty((String) det.getAttribute(IN_WORKAREA_ATTR))) {
			deliverDetails.setUserDirectory((String) det.getAttribute(IN_WORKAREA_ATTR));
		}
		return deliverDetails;
	}

	private UploadCommandDetails getUploadCommandDetails(ItemRevisionDetails det) throws IOException {
		UploadCommandDetails uploadDetails = new UploadCommandDetails();

		// create the marker file in a temporary location on the disk
		File markerFile = getMarkerFile(det);
		createMarkerFileOnDisk(markerFile);
		List<File> filesToDeliver = new ArrayList<File>();
		filesToDeliver.add(markerFile);
		uploadDetails.setFilesToTransfer(filesToDeliver);
		uploadDetails.setItemType(IDMConstants.TYPE_PROJECT);
		uploadDetails.setRelatedRequests(det.getRelatedRequests());
		uploadDetails.setComment(det.getComment());
		uploadDetails.setPart(det.getOwningPartSpecification());

		if (StringPath.isNullorEmpty((String) det.getAttribute(IN_WORKAREA_ATTR))) {
			uploadDetails.setRelativeLocation((String) det.getAttribute(IN_OFFSET_ATTR));
			uploadDetails.setUserDirectory((String) det.getAttribute(IN_USERDIR_ATTR));
		}

		if (!StringPath.isNullorEmpty((String) det.getAttribute(IN_WORKAREA_ATTR))) {
			uploadDetails.setUserDirectory((String) det.getAttribute(IN_WORKAREA_ATTR));
		}
		return uploadDetails;
	}

	private File getMarkerFile(ItemRevisionDetails det) {
		String dir = (String) det.getAttribute(IN_USERDIR_ATTR);
		String fileName = new File(dir, new Path(det.getProjectFileName().trim()).lastSegment()).getAbsolutePath();
		File markerFile = new File(fileName);
		return markerFile;
	}

	private void createMarkerFileOnDisk(File markerFile) throws IOException {
		if (markerFile.exists()) {
			return;
		}

		if (!markerFile.getParentFile().exists()) {
			if (!markerFile.getParentFile().mkdirs()) {
				throw new IOException("Unable to create the necessary folder path for marker file on disk : "//$NON-NLS-1$
						+ markerFile.getParentFile().getAbsolutePath());
			}
		}

		// Create file as team-private resource and then hide it
        IFile eclFile = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(markerFile.getAbsolutePath()));
		try {
			eclFile.create(new ByteArrayInputStream(new byte[0]), IResource.TEAM_PRIVATE, null);
			ResourceAttributes resourceAttributes = eclFile.getResourceAttributes();
			if (resourceAttributes != null) {
				resourceAttributes.setHidden(true);
				eclFile.setResourceAttributes(resourceAttributes);
			}
		} catch (CoreException e) {
			throw new IOException("Unable to create the marker file on disk : " + markerFile.getAbsolutePath(), e);
		}
	}

	@Override
	protected String getUniqueId(DimensionsArObject object) {
		return object.getName();
	}

	@Override
	public DMTypeScope getTypeScope() {
		return DMTypeScope.ITEM;
	}

	/**
     * Finds a project with the specified offset, search is performed
     * on cached objects, server is not contacted.
	 *
	 * @param offset
	 * @return project with the specified offset or <code>null</code> if none
	 */
	public SccProject findProject(String offset) {
		return findProject(offset == null ? null : new Path(offset));
	}

	/**
     * Finds a project with the specified offset, search is performed
     * on cached objects, server is not contacted.
	 *
	 * @param offset
	 * @return project with the specified offset or <code>null</code> if none
	 */
	public SccProject findProject(IPath offset) {
		Assert.isLegal(offset != null && !offset.isEmpty(), "offset required"); //$NON-NLS-1$
		APIObjectAdapter[] myProjects = getObjects();
		for (int i = 0; i < myProjects.length; i++) {
			SccProject aProject = (SccProject) myProjects[i];
			String prjOffset = aProject.getOffset();
			if (prjOffset != null && offset.equals(new Path(prjOffset))) {
				return aProject;
			}
		}
		return null;
	}

}

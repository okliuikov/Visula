/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.dimensions.core.util.Assert;

/**
 * @author V.Grishchenko
 */
public class SccProjectContainerBaselinesList extends BaselineList implements IDMConstants {

    private static final String LIST_SUBSCRIBER_ID = SccProjectContainerBaselinesList.class.getName();

    private SccProjectContainer project;

    /**
     * Creates project baselines list
     *
     * @param con
     * @param draft
     *
     */
    public SccProjectContainerBaselinesList(DimensionsConnectionDetailsEx con, SccProjectContainer project) {
        super(con, PROJECT_BASELINES);
        Assert.isLegal(project != null);
        this.project = project;
        attributeSubscribe(LIST_SUBSCRIBER_ID, DEFAULT_ATTRIBUTES);
    }

    @Override
    protected List doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final List[] result = new List[1];

            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    Filter blf = new Filter();
                    blf.criteria().add(
                            new Filter.Criterion(SystemAttributes.IDE_DM_UID, new Long(project.getIdeUid()),
                                    Filter.Criterion.EQUALS));
                    if (DMPlugin.getDefault().isFilterClosedBaselines()) {
                        addNotClosedCriterion(blf);
                    }
                    result[0] = session.getObjectFactory().getBaselines(blf);
                }
            }, pm);

            return result[0];
        } finally {
            pm.done();
        }
    }

    @Override
    protected boolean accept(DimensionsArObject doc) {
        return true;
    }

    @Override
    public String getQualifier() {
        return (String) project.getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
    }
}

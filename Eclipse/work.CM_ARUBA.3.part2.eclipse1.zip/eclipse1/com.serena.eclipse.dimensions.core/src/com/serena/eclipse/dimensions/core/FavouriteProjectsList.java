/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2015, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsFavouriteObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.EclipseProjectsFetcher;
import com.serena.dmclient.api.EclipseProjectsFetcherFactory;
import com.serena.dmclient.api.ObjectListsQuery;
import com.serena.dmclient.api.ObjectListsQuery.WorksetType;
import com.serena.dmclient.api.ObjectListsQueryFactory;
import com.serena.dmclient.api.Project;
import com.serena.dmfile.dto.Unit;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;
import com.serena.eclipse.internal.core.IAutoExpandable;

public class FavouriteProjectsList extends FavouriteRecentProjectList implements IDMConstants, IAutoExpandable {

    private static final String LIST_SUBSCRIBER_ID = FavouriteProjectsList.class.getName();

    public FavouriteProjectsList(DimensionsConnectionDetailsEx con, boolean includeOnlyStreams, boolean includeOnlyProjects) {
        // @formatter:off
        super(con, includeOnlyStreams ? FAVOURITE_STREAMS :
            includeOnlyProjects ? FAVOURITE_PROJECTS : FAVOURITE_PROJECTS_AND_STREAMS);
        this.includeOnlyStreams = includeOnlyStreams;
        this.includeOnlyProjects = includeOnlyProjects;
        // @formatter:on
    }

    @Override
    protected String getSubscriberId() {
        return LIST_SUBSCRIBER_ID;
    }

    @Override
    public void fetch(IProgressMonitor pm, boolean prefetch) throws DMException { // list that allows prefetch mode
        super.fetch(pm, prefetch);
    }

    @Override
    protected List<Project> doFetch(final Session session, IProgressMonitor pm) throws DMException {
        try {
            pm.beginTask(null, IProgressMonitor.UNKNOWN);
            final Unit<List<Project>> unit = new Unit<List<Project>>();
            EclipseProjectsFetcherFactory listFactory = session.getObjectFactory().getEclipseProjectsFetcherFactory();
    	    final EclipseProjectsFetcher<Project> listsEclipse = listFactory.createEclipseProjectsFetcher();
            session.run(new ISessionRunnable() {

                @Override
                public void run() throws Exception {
                    
                    List<Project> favourites = listsEclipse.getFavourites(session.getConnectionDetails().getMaxRecentCount());
                    unit.setValue(favourites);
                }

            }, pm);
            return unit.getValue();
        } finally {
            pm.done();
        }
    }

    @Override
    protected void addObjects(APIObjectAdapter[] adapters) {
        List<APIObjectAdapter> added = new ArrayList<APIObjectAdapter>();
        synchronized (getObjectsMap()) { // lock map for updates
            for (int i = 0; i < adapters.length; i++) {
                APIObjectAdapter newObject = null;

                if (adapters[i] instanceof SccProjectContainerWorkset) {
                    // @formatter:off
                    newObject = new SccProjectContainerWorkset(
                            (Project) adapters[i].getAPIObject(),
                            adapters[i].getConnectionDetails(),
                            ((SccProjectContainerWorkset) adapters[i]).getIde());
                    // @formatter:on
                } else if (adapters[i] instanceof WorksetAdapter) {
                    newObject = new WorksetAdapter((Project) adapters[i].getAPIObject(), adapters[i].getConnectionDetails());
                } else {
                    throw new IllegalArgumentException();
                }

                String id = getUniqueId(newObject.getAPIObject());
                getObjectsMap().put(id, newObject);
                newObject.setObjectList(this);
                added.add(newObject);

                if (isPrefetched()) {
                    getPrefetchCache().add(newObject.getAPIObject());
                }

            }
        }

        if (!isPrefetched()) { // means not fetched by expand so nothing to notify
            fireObjectsAdded(added.toArray(new APIObjectAdapter[added.size()]));
        }
    }

    @Override
    protected void removeObjects(APIObjectAdapter[] adapters) {
        List<APIObjectAdapter> favouritesRemoved = new ArrayList<APIObjectAdapter>(adapters.length);
        synchronized (getObjectsMap()) {
            for (int i = 0; i < adapters.length; i++) {
                String id = getUniqueId(adapters[i].getAPIObject());
                APIObjectAdapter removedObject = getObjectsMap().remove(id);
                if (removedObject != null) {
                    favouritesRemoved.add(removedObject);
                }

                if (isPrefetched()) {
                    getPrefetchCache().remove(adapters[i].getAPIObject());
                }
            }
        }

        if (!isPrefetched()) { // means not fetched by expand so nothing to notify
            fireObjectsRemoved(favouritesRemoved.toArray(new APIObjectAdapter[favouritesRemoved.size()]));
        }
    }

    @Override
    protected void fireObjectsRemoved(APIObjectAdapter[] objects) {
        if (objects.length != 0) {
            fireEvent(new DimensionsListEvent(this, DimensionsListEvent.FAVOURITES_REMOVED, objects));
        }
    }

    public void addFavourites(final List<IFavouriteObject> objects, IProgressMonitor monitor) throws DMException {
        if (objects.isEmpty()) {
            return;
        }

        final List<APIObjectAdapter> apiAdapters = new ArrayList<APIObjectAdapter>(objects.size());
        final List<DimensionsFavouriteObject> apiObjects = new ArrayList<DimensionsFavouriteObject>(objects.size());

        boolean multiple = objects.size() > 1;

        monitor = Utils.monitorFor(monitor);
        try {
            // @formatter:off
            String task = multiple ?
                    Messages.objectAddToFavourites_consoleAddMultiple :
                    NLS.bind(
                            Messages.objectAddToFavourites_consoleAddSingle,
                            getTypeScope().getDisplayText().toLowerCase(),
                            ((APIObjectAdapter) objects.get(0)).getAPIObject().getName());
            // @formatter:on

            monitor.beginTask(task, IProgressMonitor.UNKNOWN);

            final Session session = getConnectionDetails().openSession(null);
            session.run(new APIOperation(task) {

                @Override
                protected DimensionsResult doRun() throws Exception {
                    for (IFavouriteObject object : objects) {
                        if (object instanceof APIObjectAdapter) {
                            APIObjectAdapter adapter = (APIObjectAdapter) object;
                            if (adapter.getAPIObject() instanceof DimensionsFavouriteObject) {
                                apiAdapters.add(adapter);
                                apiObjects.add((DimensionsFavouriteObject) adapter.getAPIObject());
                            }
                        }
                    }
                    ObjectListsQueryFactory queryFactory = session.getObjectFactory().getObjectListsQueryFactory();
                    ObjectListsQuery<Project> listsQuery = queryFactory.createProjectListsQuery(WorksetType.ALL);

                    listsQuery.setFavourite(apiObjects, true);
                    return new DimensionsResult(Messages.consoleOk);
                }
            }, monitor);

            addObjects(apiAdapters.toArray(new APIObjectAdapter[apiAdapters.size()]));
        } finally {
            monitor.done();
        }

    }

    public void removeFavourites(final List<IFavouriteObject> objects, IProgressMonitor monitor) throws DMException {
        if (objects.isEmpty()) {
            return;
        }

        final List<APIObjectAdapter> apiAdapters = new ArrayList<APIObjectAdapter>(objects.size());
        final List<DimensionsFavouriteObject> apiObjects = new ArrayList<DimensionsFavouriteObject>(objects.size());

        boolean multiple = objects.size() > 1;

        monitor = Utils.monitorFor(monitor);
        try {
            // @formatter:off
            String task = multiple ?
                    Messages.objectAddToFavourites_consoleRemoveMultiple :
                    NLS.bind(
                            Messages.objectAddToFavourites_consoleRemoveSingle,
                            getTypeScope().getDisplayText().toLowerCase(),
                            ((APIObjectAdapter) objects.get(0)).getAPIObject().getName());
            // @formatter:on

            monitor.beginTask(task, IProgressMonitor.UNKNOWN);

            final Session session = getConnectionDetails().openSession(null);
            session.run(new APIOperation(task) {

                @Override
                protected DimensionsResult doRun() throws Exception {
                    for (IFavouriteObject object : objects) {
                        if (object instanceof APIObjectAdapter) {
                            APIObjectAdapter adapter = (APIObjectAdapter) object;
                            if (adapter.getAPIObject() instanceof DimensionsFavouriteObject) {
                                apiAdapters.add(adapter);
                                apiObjects.add((DimensionsFavouriteObject) adapter.getAPIObject());
                            }
                        }
                    }
                    ObjectListsQueryFactory queryFactory = session.getObjectFactory().getObjectListsQueryFactory();
                    ObjectListsQuery<Project> listsQuery = queryFactory.createProjectListsQuery(WorksetType.ALL);

                    listsQuery.setFavourite(apiObjects, false);
                    return new DimensionsResult(Messages.consoleOk);

                }
            }, monitor);

            removeObjects(apiAdapters.toArray(new APIObjectAdapter[apiAdapters.size()]));
        } finally {
            monitor.done();
        }
    }

    @Override
    public boolean shouldExpands() {
        DimensionsConnectionDetailsEx connectionDetails = getConnectionDetails();
        return connectionDetails.isFavouritesExpanded();
    }

    @Override
    public void expanded() {
        DimensionsConnectionDetailsEx connectionDetails = getConnectionDetails();
        connectionDetails.setFavouritesExpanded(true);
    }

    @Override
    public void collapsed() {
        DimensionsConnectionDetailsEx connectionDetails = getConnectionDetails();
        connectionDetails.setFavouritesExpanded(false);
    }

}

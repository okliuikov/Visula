/*
 * @Utils.java, created on Apr 13, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core.util;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.zip.CRC32;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.osgi.framework.Bundle;
import org.osgi.framework.Constants;

import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsUtils;
import com.serena.dmclient.objects.Product;
import com.serena.dmfile.StringPath;
import com.serena.eclipse.dimensions.core.DMException;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IDMConstants;
import com.serena.eclipse.dimensions.internal.core.InfiniteSubProgressMonitor;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * Provides various utility methods that can be used across all plugins.
 *
 * @author V.Grishchenko
 */
public class Utils {
    /** object array with no elements */
    public static final Object[] ZERO_LENGTH_OBJECT_ARRAY = new Object[] {};
    /** string array with no elements */
    public static final String[] ZERO_LENGTH_STRING_ARRAY = new String[] {};
    /** "" */
    public static final String EMPTY_STRING = ""; //$NON-NLS-1$
    /** integer with maximum allowed value */
    public static final Integer MIN_VALUE_INTEGER = new Integer(Integer.MIN_VALUE);
    /** negative infinity valued Double */
    public static final Double NEGATIVE_INFINITY_DOUBLE = new Double(Double.NEGATIVE_INFINITY);
    /** positive infinity valued Double */
    public static final Double POSITIVE_INFINITY_DOUBLE = new Double(Double.POSITIVE_INFINITY);

    // Note: '_' is not a valid first char for an encoding name:
    public static final String DEFAULT_ENCODING_NAME = "_DEFAULT"; //$NON-NLS-1$

    /*
     * no instances allowed
     */
    private Utils() {
    }

    /**
     * @return <code>true</code> if the supplied string is <code>null</code> or empty, otherwise returns <code>false</code>
     */
    public static boolean isNullEmpty(String s) {
        return s == null || s.length() == 0;
    }

    /**
     * Attempts to lookup a string by the supplied key from the supplied bundle
     * and convert it to an int. If it fails returns supplied default.
     *
     * @param bundle
     * @param key
     * @param dfltValue
     *            default value
     * @return integer value of the String stored in bundle or supplied default
     *         value if not found or cannot be parsed into an int
     */
    public static int getInteger(ResourceBundle bundle, String key, int dfltValue) {
        if (bundle != null) {
            try {
                String s = bundle.getString(key);
                if (s != null) {
                    return Integer.parseInt(s);
                }
            } catch (NumberFormatException x) {
            } catch (MissingResourceException x) {
            }
        }
        return dfltValue;
    }

    /**
     * Attempts to parse the supplied string to an int in decimal radix, if
     * this fails returns the supplied default value.
     *
     * @param s
     *            string to parse
     * @param dfltValue
     *            integer value to return in case parsing fails
     * @return integer value for s or <code>dfltValue</code>
     */
    public static int parseInt(String s, int dfltValue) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
        }
        return dfltValue;
    }

    /**
     * Immediately throws a <code>OperationCanceledException</code>.
     *
     * @see OperationCanceledException
     */
    public static void cancelOperation() {
        throw new OperationCanceledException();
    }

    /* progress monitor helpers */

    /**
     * If the supplied monitor is not <code>null</code> and is canceled
     * calls <code>cancelOperation()</code>, otherwise does nothing.
     *
     * @param monitor
     *            progress monitor to poll for cancellation, can be <code>null</code>
     * @see Utils#cancelOperation()
     */
    public static void checkCanceled(IProgressMonitor monitor) {
        if (monitor != null && monitor.isCanceled()) {
            throw new OperationCanceledException();
        }
    }

    /**
     * @return a new instance of <code>NullProgressMonitor</code> if the
     *         supplied monitor is <code>null</code>, otherwise just returns the
     *         passed in monitor object
     * @see NullProgressMonitor
     */
    public static IProgressMonitor monitorFor(IProgressMonitor monitor) {
        if (monitor == null) {
            return new NullProgressMonitor();
        }
        return monitor;
    }

    /**
     * Produces a new sub-monitor for the given amount of ticks from a parent
     * monitor.
     *
     * @param monitor
     *            parent monitor
     * @param ticks
     *            the number of work ticks allocated from the
     *            parent monitor
     * @return <code>NullProgressMonitor</code> if <code>monitor</code> is <code>null</code>, <code>monitor</code> if it is a
     *         <code>NullProgressMonitor</code>, otherwise returns a new <code>SubProgressMonitor</code> for the number of ticks
     *         specified
     * @see SubProgressMonitor
     */
    public static IProgressMonitor subMonitorFor(IProgressMonitor monitor, int ticks) {
        return subMonitorFor(monitor, ticks, 0);
    }

    /**
     * Produces a new sub-monitor for the given amount of ticks from a parent
     * monitor.
     *
     * @param monitor
     *            parent monitor
     * @param ticks
     *            the number of work ticks allocated from the
     *            parent monitor
     * @param style
     *            one of the styles defined in <code>SubProgressMonitor</code>
     * @return <code>NullProgressMonitor</code> if <code>monitor</code> is <code>null</code>, <code>monitor</code> if it is a
     *         <code>NullProgressMonitor</code>, otherwise returns a new <code>SubProgressMonitor</code> for the number of ticks
     *         specified
     * @see SubProgressMonitor
     * @see SubProgressMonitor#PREPEND_MAIN_LABEL_TO_SUBTASK
     * @see SubProgressMonitor#SUPPRESS_SUBTASK_LABEL
     */
    public static IProgressMonitor subMonitorFor(IProgressMonitor monitor, int ticks, int style) {
        if (monitor == null) {
            return new NullProgressMonitor();
        }
        if (monitor instanceof NullProgressMonitor) {
            return monitor;
        }
        return new SubProgressMonitor(monitor, ticks, style);
    }

    public static IProgressMonitor infiniteSubMonitorFor(IProgressMonitor monitor, int ticks) {
        if (monitor == null) {
            return new NullProgressMonitor();
        }
        if (monitor instanceof NullProgressMonitor) {
            return monitor;
        }
        return new InfiniteSubProgressMonitor(monitor, ticks);
    }

    /**
     * Convenience method, same as:
     * <p>
     * <code>getServiceInfo(exception.getStatus(), detectedIn)</code>
     */
    public static MultiStatus getServiceInfo(CoreException exception, Bundle detectedIn) {
        return getServiceInfo(exception.getStatus(), detectedIn);
    }

    /**
     * Same as <code>getServiceInfo(errorStatus, null, detectedIn)</code>
     */
    public static MultiStatus getServiceInfo(IStatus errorStatus, Bundle detectedIn) {
        return getServiceInfo(errorStatus, null, detectedIn);
    }

    /**
     * Returns the plugin's product vital data. The plugin data comes from the
     * values from the main section of the bundle's Manifest file. This method
     * method creates a Status object for the provider name,
     * plug-in name, plug-in id, and version for the plugin that generated the
     * specified error. Each Status object is added to the MultiStatus object.
     * If optional bundle data about plugin that detected the original error
     * condition is specified it is also added to the returned multistatus.
     *
     * @param detectedIn
     *            bundle that detected the original error or <code>null</code>
     * @param errorStatus
     *            status for which service info to be generated
     * @param message
     *            multistatus message or <code>null</code> to use supplied status's message
     * @return multistatus containing individual statuses for the plugin that
     *         generated the original error and the plugin that detected this error
     *         condition if specified
     */
    public static MultiStatus getServiceInfo(IStatus errorStatus, String message, Bundle detectedIn) {
        Assert.isNotNull(errorStatus);

        Bundle bundle = Platform.getBundle(errorStatus.getPlugin());
        String symbolicName = bundle != null ? bundle.getSymbolicName() : errorStatus.getPlugin();
        String bundleName = getHeaderValue(Constants.BUNDLE_NAME, bundle);
        String bundleVendor = getHeaderValue(Constants.BUNDLE_VENDOR, bundle);
        String bundleVersion = getHeaderValue(Constants.BUNDLE_VERSION, bundle);
        MultiStatus vitalInfoStatus = new MultiStatus(symbolicName, errorStatus.getSeverity(),
                message == null ? errorStatus.getMessage() : message, errorStatus.getException());
        if (errorStatus.getChildren().length > 0) {
            vitalInfoStatus.addAll(errorStatus);
            // add separator before service info for better readability
            vitalInfoStatus
                    .add(createStatus(symbolicName, errorStatus.getSeverity(), "---------------------------------------------")); //$NON-NLS-1$
        }
        // Put the information into their own status containers because this
        // forces new lines in the details section of the ErrorDialog
        // Origination in Header
        if (detectedIn != null) {
            vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_originatedIn));
        }
        // Vendor name
        vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_vendorName + " " + bundleVendor)); //$NON-NLS-1$
        // Plug-in name (user friendly name)
        vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_pluginName + " " + bundleName)); //$NON-NLS-1$
        // Plug-in ID
        vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_pluginID + " " + symbolicName)); //$NON-NLS-1$
        // Version
        vitalInfoStatus
                .add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_pluginVersion + " " + bundleVersion)); //$NON-NLS-1$
        if (errorStatus.getException() != null) {
            vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(),
                    Messages.log_exception + " " + errorStatus.getException().getClass().getName())); //$NON-NLS-1$
            StackTraceElement[] stackTrace = errorStatus.getException().getStackTrace();
            if (stackTrace != null && stackTrace.length > 0) {
                // Class declaring the method where exception is thrown
                String raisedInClass = stackTrace[0].getClassName();
                if (raisedInClass != null) {
                    vitalInfoStatus
                            .add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_class + " " + raisedInClass)); //$NON-NLS-1$
                }
                // Method where exception is thrown
                String raisedInMethod = stackTrace[0].getMethodName();
                if (raisedInMethod != null) {
                    vitalInfoStatus
                            .add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_method + " " + raisedInMethod)); //$NON-NLS-1$
                }
            }
        }

        if (detectedIn != null) {
            String symbolicNameD = detectedIn.getSymbolicName();
            String bundleNameD = getHeaderValue(Constants.BUNDLE_NAME, detectedIn);
            String bundleVendorD = getHeaderValue(Constants.BUNDLE_VENDOR, detectedIn);
            String bundleVersionD = getHeaderValue(Constants.BUNDLE_VERSION, detectedIn);

            // Detection header
            vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_detectedIn));
            vitalInfoStatus
                    .add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_vendorName + " " + bundleVendorD)); //$NON-NLS-1$
            // Plug-in name (user friendly name)
            vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_pluginName + " " + bundleNameD)); //$NON-NLS-1$
            // Plug-in ID
            vitalInfoStatus.add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_pluginID + " " + symbolicNameD)); //$NON-NLS-1$
            // Version
            vitalInfoStatus
                    .add(createStatus(symbolicName, errorStatus.getSeverity(), Messages.log_pluginVersion + " " + bundleVersionD)); //$NON-NLS-1$
        }

        return vitalInfoStatus;
    }

    /**
     * Tests if all elements of set are in ofSet
     */
    public static boolean isSubSet(int[] set, int[] ofSet) {
        if (set.length == 0) {
            return true; // empty set is always a subset
        }

        int[] _ofSet = new int[ofSet.length];
        System.arraycopy(ofSet, 0, _ofSet, 0, ofSet.length);
        Arrays.sort(_ofSet);

        for (int i = 0; i < set.length; i++) {
            if (Arrays.binarySearch(_ofSet, set[i]) < 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return 32 bit digest as hex with leading zeroes
     */
    public static String getDigest32(String s) {
        assert s != null;
        byte[] bytes = new byte[s.length() * 2];
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int byteIdx1 = i * 2;
            int byteIdx2 = byteIdx1 + 1;
            bytes[byteIdx1] = (byte) (0xff & (c >> 8));
            bytes[byteIdx2] = (byte) (0xff & c);
        }
        CRC32 crc32 = new CRC32();
        crc32.update(bytes);
        String hex = Long.toHexString(0x100000000L | crc32.getValue()).substring(1);
        return hex.toUpperCase();
    }

    private static String getHeaderValue(String header, Bundle bundle) {
        return bundle == null ? Messages.log_unknownValue : String.valueOf(bundle.getHeaders().get(header));
    }

    public static IStatus createStatus(String id, int severity, String msg) {
        return new Status(severity, id, IStatus.OK, msg, null);
    }

    public static IStatus createStatus(String id, int severity, String msg, Throwable t) {
        return new Status(severity, id, IStatus.OK, msg, t);
    }

    /**
     * <p>
     * Queries attributes using <code>BulkOperator</code>.
     * <p>
     * <b>Note</b>: this method will propagate unchecked exceptions raised by the API to the caller. Wrap a call to this into
     * <code>ISessionRunnable</code> as needed.
     *
     * @param objects
     *            objects to query attributes for
     * @param attrs
     *            attributes tp query
     * @param factory
     * @param onlyUncached
     *            if <code>true</code> will query only those attributes
     *            which have not been cached locally.
     */
    public static void queryAttributes(DimensionsArObject[] objects, int[] attrs, DimensionsObjectFactory factory,
            boolean onlyUncached) {
        Assert.isNotNull(objects);
        queryAttributes(Arrays.asList(objects), attrs, factory, onlyUncached);
    }

    public static void queryAttributes(List<? extends DimensionsArObject> objects, int[] attrs, DimensionsObjectFactory factory,
            boolean onlyUncached) {
        Assert.isNotNull(objects);
        Assert.isNotNull(attrs);
        if (objects.isEmpty() || attrs.length == 0) {
            return;
        }
        BulkOperator bulkOperator = factory.getBulkOperator(objects);
        if (onlyUncached) {
            bulkOperator.setMode(BulkOperator.MODE_QUERYONLYUNCACHED);
        }
        bulkOperator.queryAttribute(attrs);
    }

    /**
     * <p>
     * Queries attributes for object array, non-bulk version.
     * <p>
     * <b>Note</b>: this method will propagate unchecked exceptions raised by the API to the caller. Wrap a call to this into
     * <code>ISessionRunnable</code> as needed.
     *
     * @param objects
     *            object array to query attributes for
     * @param attrs
     *            attributes to query
     */
    public static void queryAttributes(DimensionsArObject[] objects, int[] attrs) {
        Assert.isNotNull(objects);
        Assert.isNotNull(attrs);
        if (objects.length == 0 || attrs.length == 0) {
            return;
        }
        for (int i = 0; i < objects.length; i++) {
            DimensionsArObject obj = objects[i];
            List<Integer> attrsToQueryList = new ArrayList<Integer>();
            for (int j = 0; j < attrs.length; j++) {
                if (obj.getAttribute(attrs[j]) == null) {
                    attrsToQueryList.add(new Integer(attrs[j]));
                }
            }

            Iterator<Integer> iter = attrsToQueryList.iterator();
            int[] attrsToQuery = new int[attrsToQueryList.size()];
            int k = 0;
            while (iter.hasNext()) {
                Integer attr = iter.next();
                attrsToQuery[k++] = attr.intValue();
            }
            objects[i].queryAttribute(attrsToQuery);
        }
    }

    /**
     * @return empty string if the parameter is <code>null</code>, otherwise
     *         returns the parameter
     */
    public static String getString(String s) {
        if (s == null) {
            return EMPTY_STRING;
        }
        return s;
    }

    public static boolean isSystemAttribute(int att) {
        return DimensionsUtils.isSystemAttribute(att);
    }

    public static boolean isUserAttribute(int att) {
        return att > 0;
    }

    /**
     * @param beautify
     *            if <code>true</code> inserts spaces after commas
     * @return values as comma separated values string
     */
    public static String toCsvString(Object[] values, boolean beautify) {
        if (values.length == 0) {
            return EMPTY_STRING;
        }
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                buffer.append(',');
                if (beautify) {
                    buffer.append(' ');
                }
            }
            buffer.append(values[i]);
        }
        return buffer.toString();
    }

    /**
     *
     * @param in
     *            CSV list to process
     * @return values from input CSV as a List of Strings
     *         quotes in csv are removed
     */
    public static List<String> fromCsvToList(String in) {
        List<String> ret = Collections.emptyList();
        if (in != null) {
            ret = new ArrayList<String>();
            String[] splitIt = in.split(","); // NON-NLS-1$ //$NON-NLS-1$
            for (String s : splitIt) {
                s = s.replaceAll("\"", Utils.EMPTY_STRING); // NON-NLS-1$ //$NON-NLS-1$
                s = s.trim();
                if (s.length() > 0) {
                    ret.add(s);
                }
            }
        }
        return ret;
    }

    /**
     * Decodes a hex-encoded string into a byte array.
     *
     * @param val
     *            hex-encoded string
     * @throws NumberFormatException
     *             if a non-hex character is encountered
     */
    public static byte[] hexDecode(String val) {
        Assert.isLegal(val != null && val.length() % 2 == 0);
        int len = val.length() / 2;
        byte[] ret = new byte[len];
        for (int i = 0; i < len; ++i) {
            char d1 = val.charAt(i * 2);
            char d2 = val.charAt(i * 2 + 1);
            int h1 = Character.digit(d1, 16);
            int h2 = Character.digit(d2, 16);
            if (h1 < 0) {
                throw new NumberFormatException(String.valueOf(h1));
            }
            if (h2 < 0) {
                throw new NumberFormatException(String.valueOf(h2));
            }
            int by = 16 * h1 + h2;
            ret[i] = (byte) by;
        }
        return ret;
    }

    /**
     * Encodes the supplied byte array into a hex string.
     *
     * @param val
     *            must not be <code>null</code>
     * @param isUpper
     *            controls if returned chars will be in upper case
     * @return hex-encoded string
     */
    public static String hexEncode(byte[] val, boolean isUpper) {
        Assert.isNotNull(val);
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < val.length; ++i) {
            int by = val[i] & 0xFF; // unsigned
            char d1 = Character.forDigit(by / 16, 16);
            char d2 = Character.forDigit(by % 16, 16);
            if (isUpper) {
                d1 = Character.toUpperCase(d1);
                d2 = Character.toUpperCase(d2);
            }
            sb.append(d1);
            sb.append(d2);
        }
        return sb.toString();
    }

    /**
     * Creates an instance of an UTF8 InputStreamReader
     */
    public static InputStreamReader createUTF8EncodingReader(InputStream is) {
        InputStreamReader in = null;
        try {
            in = new InputStreamReader(is, "UTF-8"); //$NON-NLS-1$
        } catch (UnsupportedEncodingException e) {
            in = new InputStreamReader(is);
        }
        return in;
    }

    /**
     * Creates an UTF8 instance of an OutputStreamWriter.
     */
    public static OutputStreamWriter createUTF8EncodingWriter(OutputStream os) {
        OutputStreamWriter out = null;
        try {
            out = new OutputStreamWriter(os, "UTF-8"); //$NON-NLS-1$
        } catch (UnsupportedEncodingException e) {
            out = new OutputStreamWriter(os);
        }
        return out;
    }

    /**
     * Utility method parse a string into an <code>java.util.Locale</code> object the format of the string should be consistent
     * with
     * the output of <code>java.util.Locale</code>'s <code>toString()</code> method. Same
     * as calling parseLocale <code>(localeString, '_')</code>.
     *
     * @param localeString
     *            The input string to parse
     * @return a Locale object
     * @see Locale#toString()
     */
    public static Locale parseLocale(String localeString) {
        return parseLocale(localeString, '_');
    }

    /**
     * Utility method parse a string into an <code>java.util.Locale</code> object the format of the string should be consistent
     * with
     * the output of <code>java.util.Locale</code>'s <code>toString()</code> method,
     * although the separator can be character other than underscore.
     *
     * @param localeString
     *            The input string to parse
     * @param sep
     *            separator character
     * @return a Locale object
     * @see Locale#toString()
     */
    public static Locale parseLocale(String localeString, char sep) {
        if (isNullEmpty(localeString)) {
            throw new NullPointerException("locale string is null or empty"); //$NON-NLS-1$
        }
        String l = EMPTY_STRING, c = EMPTY_STRING, v = EMPTY_STRING;
        int idx1 = -1, idx2 = -1; // have at most 2 separators
        idx1 = localeString.indexOf(sep);
        if (idx1 != -1) {
            idx2 = localeString.indexOf(sep, idx1 + 1);
        }
        if (idx1 == -1) { // the whole string is just language
            l = localeString;
        } else if (idx1 == 0) { // leading sep means no language
            if (idx2 == -1) { // counry only
                c = localeString.substring(1);
            } else { // country, variant
                c = localeString.substring(1, idx2);
                v = localeString.substring(idx2 + 1);
            }
        } else { // have language
            if (idx2 == -1) { // language, country
                l = localeString.substring(0, idx1);
                c = localeString.substring(idx1 + 1);
            } else { // language, [country], variant
                l = localeString.substring(0, idx1);
                c = localeString.substring(idx1 + 1, idx2);
                v = localeString.substring(idx2 + 1);
            }
        }
        return new Locale(l, c, v);
    }

    /**
     * Checks if 2 strings are equal, 2 null strings are considered to be equal.
     *
     * @param s1
     * @param s2
     * @return <code>true</code> if strings are equal or both are <code>null</code>
     */
    public static boolean stringsEqual(String s1, String s2) {
        return stringsEqual(s1, s2, false);
    }

    /**
     * Checks if 2 strings are equal, 2 null strings are considered to be equal.
     *
     * @param s1
     * @param s2
     * @param ignoreCase
     *            if <code>true</code> compares strings ignoring case
     * @return <code>true</code> if strings are equal or both are <code>null</code>
     */
    public static boolean stringsEqual(String s1, String s2, boolean ignoreCase) {
        if (s1 == s2) {
            return true;
        }
        if (s1 != null) {
            return ignoreCase ? s1.equalsIgnoreCase(s2) : s1.equals(s2);
        }
        return false;
    }

    public static boolean compareAttributes(int[] attributes, DimensionsArObject obj1, DimensionsArObject obj2) {
        for (int i = 0; i < attributes.length; i++) {
            Object val1 = obj1.getAttribute(attributes[i]);
            Object val2 = obj2.getAttribute(attributes[i]);
            if (val1 == val2 || (val1 != null && val1.equals(val2))) {
                continue;
            }
            return false;
        }
        return true;
    }

    public static void deleteFileWithDelay(File fileToDelete) {
        com.serena.eclipse.core.util.Utils.deleteFileWithDelay(fileToDelete);
    }

    public static List<String> stringToList(String children) {
        if (StringPath.isNullorEmpty(children)) {
            return new ArrayList<String>();
        }

        String[] split = children.split(","); //$NON-NLS-1$
        return new ArrayList<String>(Arrays.asList(split));
    }

    public static String listToString(List<String> listIn, boolean quote) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (int i = 0; i < listIn.size(); i++) {
            if (!first) {
                sb.append(","); //$NON-NLS-1$
            } else {
                first = false;
            }
            if (quote) {
                sb.append("\""); //$NON-NLS-1$
            }
            sb.append(listIn.get(i));
            if (quote) {
                sb.append("\""); //$NON-NLS-1$
            }
        }
        return sb.toString();
    }
    
    public static List<String> getProductNames(DimensionsConnectionDetailsEx connection) throws DMException {
        List<Product> products = connection.getProducts(null);
        List<String> productNames = new ArrayList<String>(products.size());
        for (Product product : products) {
            if (!IDMConstants.TEMPLATE_PRODUCT.equals(product.getName())) {
                productNames.add(product.getName());
            }
        }
        return productNames;
    }
    
    public static String wrapForSearch (String input) {
        return (input.startsWith("*")?"":"%") + input.replace("*", "%") + (input.endsWith("*")?"":"%");
    }
}

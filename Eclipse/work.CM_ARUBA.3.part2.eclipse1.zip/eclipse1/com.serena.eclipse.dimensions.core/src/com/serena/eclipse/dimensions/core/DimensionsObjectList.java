/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2005, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.PlatformObject;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.BulkOperator;
import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Filter;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.dmclient.objects.DimensionsObject;
import com.serena.dmclient.objects.DimensionsObjectDetails;
import com.serena.eclipse.core.IServiceResource;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * <p>
 * List containing objects that provides notifications for changes. Intended to be used as a data model part in MVC setup.
 *
 * <p>
 * Note: this class is not fully thread safe, currently it only protects the internal object collection and serializes calls to
 * fetch() and update(). Use proper external synchronization when applicable or
 * <code>com.serena.eclipse.dimensions.core.ObjectListSchedulingRule</code> for serializing access to object list when using jobs.
 *
 * @author V.Grishchenko
 */
public abstract class DimensionsObjectList extends PlatformObject implements IServiceResource, ISchedulingRule,
        IDimensionsServiceResource {

    // @formatter:off
    private static final int[] DEFAULT_ATTS = new int[] {
        SystemAttributes.OBJECT_ID,
        SystemAttributes.OBJECT_SPEC };
    // @formatter:on

    static {
        Arrays.sort(DEFAULT_ATTS);
    }

    private DimensionsConnectionDetailsEx con;
    private List<IDimensionsObjectListListener> listeners = new ArrayList<IDimensionsObjectListListener>();
    private Map<String, APIObjectAdapter> objects = new LinkedHashMap<String, APIObjectAdapter>(); // spec -> api adapter
    private int type;

    private final List<? super DimensionsArObject> prefetchCache = Collections.synchronizedList(new ArrayList<DimensionsObject>());
    private boolean prefetched = false;

    private Map<String, int[]> subMap = new HashMap<String, int[]>();
    private int[] subAttrs = new int[0];

    public DimensionsObjectList(DimensionsConnectionDetailsEx con, int type) {
        this.con = con;
        this.type = type;
    }

    /**
     * @return list type scope
     */
    public abstract DMTypeScope getTypeScope();

    /**
     * Loads appropriate objects from the connection, pm is guaranteed to be non-null
     */
    protected abstract List<? extends DimensionsArObject> doFetch(Session session, IProgressMonitor pm) throws DMException;

    /**
     * Called from APIOperation
     */
    protected abstract DimensionsResult doCreateObject(Session session, DimensionsObjectDetails objectDetails,
            IProgressMonitor monitor) throws Exception;

    protected abstract String getUniqueId(DimensionsArObject object);

    @Override
    public String getServiceId() {
        return DMPlugin.SERVICE_ID;
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    /**
     * Adds a list listener. Does nothing if supplied listener is
     * already registered.
     *
     * @param listener
     */
    public void addListener(IDimensionsObjectListListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    /**
     * Removes a list listener.
     *
     * @param listener
     */
    public void removeListener(IDimensionsObjectListListener listener) {
        listeners.remove(listener);
    }

    public int getType() {
        return type;
    }

    /**
     * @return additional list qualifier
     */
    public String getQualifier() {
        return null;
    }

    /**
     * Answers if this list contains the specified object or object adapter that wraps specified object
     *
     * @param object APIObjectAdapter for precise match or DimensionsArObject to check have it already been cached
     * @return <code>true</code> if this list contains the specified object,
     *         returns <code>false</code> otherwise
     */
    public boolean contains(Object object) {
        if (!(object instanceof APIObjectAdapter) && !(object instanceof DimensionsArObject)) {
            return false;
        }
        Object key;
        if (object instanceof APIObjectAdapter) {
            APIObjectAdapter adapter = (APIObjectAdapter) object;
            key = getUniqueId(adapter.getAPIObject());
        } else {
            key = getUniqueId((DimensionsArObject) object);
        }

        synchronized (objects) {
            return objects.containsKey(key);
        }
    }

    public APIObjectAdapter[] getObjects() {
        synchronized (objects) {
            APIObjectAdapter[] result = new APIObjectAdapter[objects.size()];
            int cnt = 0;
            for (Iterator<APIObjectAdapter> iter = objects.values().iterator(); iter.hasNext();) {
                result[cnt++] = iter.next();
            }
            return result;
        }
    }

    protected Map<String, APIObjectAdapter> getObjectsMap() {
        return objects;
    }

    /**
     * @return <code>true</code> if list is empty, returns <code>false</code> otherwise
     */
    public boolean isEmpty() {
        synchronized (objects) {
            return objects.isEmpty();
        }
    }

    /**
     * 
     * @return String used as input parameter for DRS to filter closed baselines, streams and projects. The filter is used to
     *         specify which closed objects should be included in DRS result. There is zero or more of the letters p (for project),
     *         s (for stream), b (for baseline) and w (for both project and stream). If the string is not empty, then closed objects
     *         of the class or classes specified will be returned. By default, no closed objects will be returned.
     */
    protected String getIncludeClosedFilter() {
        String includeClosedFilter = "";
        if (!DMPlugin.getDefault().isFilterClosedProjects()) {
            includeClosedFilter = "w";
        }
        if (!DMPlugin.getDefault().isFilterClosedBaselines()) {
            includeClosedFilter += "b";
        }
        return includeClosedFilter;
    }

    @Override
    public DimensionsConnectionDetailsEx getConnectionDetails() {
        return con;
    }

    protected void setConnectionDetails(DimensionsConnectionDetailsEx con) {
        this.con = con;
    }

    public synchronized int[] getAllSubscribedAttributes() {
        if (subAttrs.length == 0) {
            return subAttrs;
        }
        return subAttrs.clone();
    }

    public synchronized int[] getSubscribedAttributes(String subscriberId) {
        int[] result = subMap.get(subscriberId);
        if (result == null) {
            return null;
        }
        if (result.length == 0) {
            return result;
        }
        return result.clone();
    }

    public synchronized void attributeSubscribe(String subscriberId, int[] attrs) {
        subMap.put(subscriberId, attrs);
        cacheSubscribedSet();
    }

    public synchronized void attributeUnsubscribe(String subscriberId) {
        subMap.remove(subscriberId);
        cacheSubscribedSet();
    }

    private void cacheSubscribedSet() {
        Set<Integer> set = new HashSet<Integer>();
        for (Iterator<int[]> iterator = subMap.values().iterator(); iterator.hasNext();) {
            int[] subscription = iterator.next();
            for (int i = 0; i < subscription.length; i++) {
                set.add(new Integer(subscription[i]));
            }
        }
        subAttrs = new int[set.size()];
        int cnt = 0;
        for (Iterator<Integer> iter = set.iterator(); iter.hasNext();) {
            Integer attNum = iter.next();
            subAttrs[cnt++] = attNum.intValue();
        }
    }

    /**
     * Fetch objects to lists cache and propagate update statuses.
     * @param pm monitor
     * @throws DMException
     */
    public void fetch(IProgressMonitor pm) throws DMException {
        fetch(pm, false);
    }

    /**
     * Fetch objects to lists cache and propagate update statuses.
     * @param pm monitor
     * @param prefetch
     *            <ul>
     *            <li>true - updates only internal object cache without propagation of update events</li>
     *            <li>false - if list was prefetched propagates statuses from cached objects otherwise queries new data from server</li>
     *            </ul>
     * @throws DMException
     */
    protected void fetch(IProgressMonitor pm, boolean prefetch) throws DMException {
        pm = Utils.monitorFor(pm);
        try {
            if (pm.isCanceled()) {
                throw new DMException(IStatus.CANCEL, 0, "", null); //$NON-NLS-1$
            }
            pm.beginTask(Messages.progress_loadObjList, 100); // 20 - session, 30 - basic fetch, 50 - attrs

            // ensure we have the session
            IProgressMonitor sMonitor = Utils.subMonitorFor(pm, 20);
            final Session session = con.openSession(sMonitor);
            sMonitor.done();

            pm.subTask(Messages.progress_loadObjListIds);

            // get list
            IProgressMonitor fetchMonitor = Utils.subMonitorFor(pm, 30);
            final List<?> fetchedObjects = queryAPIObjects(session, fetchMonitor, prefetch);
            fetchMonitor.done();

            // load additional attributes
            final int[] attributes = getAllSubscribedAttributes();
            if (attributes != null && !isSubSet(attributes, getDefaultAttributes())) {
                pm.subTask(Messages.progress_loadObjListAttrs);

                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        List<?> toQueryObjects = fetchedObjects;
                        if (!fetchedObjects.isEmpty()) {
                            bulkQuery(session, attributes, toQueryObjects);
                        }
                    }

                }, pm);
            }

            pm.worked(50);

            // sort out deltas
            List<APIObjectAdapter> added = new ArrayList<APIObjectAdapter>();
            List<APIObjectAdapter> removed = new ArrayList<APIObjectAdapter>();
            List<APIObjectAdapter> changed = new ArrayList<APIObjectAdapter>();

            Set<String> fetchedIds = new HashSet<String>();

            synchronized (objects) { // lock objects for update
                if (prefetch) {
                    // each prefetch drops objects cache
                    objects.clear();
                }

                for (int i = 0; i < fetchedObjects.size(); i++) {
                    DimensionsArObject obj = (DimensionsArObject) fetchedObjects.get(i);
                    if (!accept(obj)) {
                        continue;
                    }

                    String id = getUniqueId(obj);

                    APIObjectAdapter adapter = null;
                    if (prefetch) {
                        adapter = adapt(session, obj);
                        adapter.setObjectList(this);
                        objects.put(id, adapter);
                    } else {
                        fetchedIds.add(id);
                        if (objects.containsKey(id)) {
                            adapter = objects.get(id);

                            if (isPrefetched()) {
                                // prefetched set of objects doesn't maintain update statuses
                                added.add(adapter);
                            } else {
                                // check if really changed - not checking default attrs,
                                // assume they are invariants - should work for now
                                if (!Utils.compareAttributes(attributes, adapter.getAPIObject(), obj)) {
                                    changed.add(adapter);
                                }
                            }
                            adapter.setAPIObject(obj); // just in case replace underlying object
                        } else {
                            adapter = adapt(session, obj);
                            adapter.setObjectList(this);
                            added.add(adapter);
                            objects.put(id, adapter);
                        }
                    }
                    adapter.setListIndex(i);
                }

                if (!prefetch) {
                    fetchedObjects.clear(); // ensure fetched object list was cleared as it could be prefetched
                    setPrefetched(false); // ensure that any subsequent call to fetch drops prefetched status

                    for (Iterator<Entry<String, APIObjectAdapter>> iterator = objects.entrySet().iterator(); iterator.hasNext();) {
                        Entry<String, APIObjectAdapter> entry = iterator.next();
                        if (!fetchedIds.contains(entry.getKey())) {
                            iterator.remove();
                            removed.add(entry.getValue());
                        }
                    }
                }
            }

            // notify listeners
            if (!removed.isEmpty()) {
                fireObjectsRemoved(removed.toArray(new APIObjectAdapter[removed.size()]));
            }
            if (!changed.isEmpty()) {
                fireObjectsChanged(changed.toArray(new APIObjectAdapter[changed.size()]));
            }
            if (!added.isEmpty()) {
                fireObjectsAdded(added.toArray(new APIObjectAdapter[added.size()]));
            }
        } finally {
            pm.done();
        }
    }

    private List<?> queryAPIObjects(final Session session, IProgressMonitor fetchMonitor, boolean prefetch) throws DMException {
        synchronized (prefetchCache) {
            if (isPrefetched() && !prefetch) {
                return prefetchCache;
            } else if (prefetch) {
                prefetchCache.clear();
                prefetchCache.addAll(doFetch(session, fetchMonitor));
                setPrefetched(true);
                return prefetchCache;
            } else {
                return doFetch(session, fetchMonitor);
            }
        }
    }

    protected boolean accept(DimensionsArObject doc) {
        return true;
    }

    protected APIObjectAdapter adapt(Session session, DimensionsObject dimensionsObject) {
        return session.adapt(dimensionsObject);
    }

    public void update(IProgressMonitor pm) throws DMException {
        Collection<APIObjectAdapter> values = objects.values();
        update(values.toArray(new APIObjectAdapter[values.size()]), false, pm);
    }

    /**
     * Updates the subscribed attributes for the specified objects,
     * objects that are not contained by this list are excluded from update.
     *
     * @param objectsToUpdate
     * @param forceNotify
     *            <code>true</code> to force change notifications even if none detected
     * @param pm
     * @throws DMException
     */
    synchronized void update(APIObjectAdapter[] objectsToUpdate, boolean forceNotify, IProgressMonitor pm) throws DMException {
        pm = Utils.monitorFor(pm);
        try {
            final List<DimensionsArObject> list = new ArrayList<DimensionsArObject>();
            final List<APIObjectAdapter> change = new ArrayList<APIObjectAdapter>();
            for (int i = 0; i < objectsToUpdate.length; i++) {
                APIObjectAdapter anObject = objectsToUpdate[i];
                String id = getUniqueId(anObject.getAPIObject());
                APIObjectAdapter myObject = objects.get(id);

                if (myObject != null) {
                    list.add(myObject.getAPIObject());
                    change.add(myObject);
                }
            }
            pm.beginTask(null, 100);
            if (!list.isEmpty()) {
                final Session session = con.openSession(Utils.subMonitorFor(pm, 15));

                session.run(new ISessionRunnable() {

                    @Override
                    public void run() throws Exception {
                        int[] attrs = getAllSubscribedAttributes();
                        bulkQuery(session, attrs, list);
                    }

                }, pm);

                pm.worked(80);
                fireObjectsChanged(change.toArray(new APIObjectAdapter[change.size()]));
            }
        } finally {
            pm.done();
        }
    }

    @Override
    public boolean contains(ISchedulingRule rule) {
        return isConflicting(rule);
    }

    @Override
    public boolean isConflicting(ISchedulingRule rule) {
        return this == rule;
    }

    /**
     * Creates a new object in the system and refreshes itself.
     *
     * @param project
     * @param objectDetails
     * @return
     * @throws DMException
     */
    public void createObject(final DimensionsObjectDetails objectDetails, IProgressMonitor monitor) throws DMException {
        Assert.isLegal(objectDetails != null);
        monitor = Utils.monitorFor(monitor);
        String console = NLS.bind(Messages.objectCreate_console, getTypeScope().getDisplayText().toLowerCase(),
                getTypeScope().getObjectId(objectDetails));
        monitor.beginTask(null, 101);
        monitor.worked(1);
        final IProgressMonitor createMonitor = Utils.subMonitorFor(monitor, 50, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK);
        try {
            final Session session = con.openSession(null);

            session.run(new APIOperation(console) {

                @Override
                protected DimensionsResult doRun() throws Exception {
                    return doCreateObject(session, objectDetails, createMonitor);
                }

            }, createMonitor);

            fetch(Utils.subMonitorFor(monitor, 50, SubProgressMonitor.PREPEND_MAIN_LABEL_TO_SUBTASK));
        } finally {
            monitor.done();
        }
    }

    /**
     * Optimization - the list will not bulk-query subscribed attributes
     * if they are already cached in doFetch(), this method returns attributes
     * cached in doFetch() - subclasses may need to override. This method
     * returns {SystemAttributes.OBJECT_ID, SystemAttributes.OBJECT_SPEC}
     *
     * @return attributes loaded by doFetch() in acceding order
     */
    protected int[] getDefaultAttributes() {
        return DEFAULT_ATTS;
    }

    protected static void replaceEqualConnectionInstances(DimensionsConnectionDetailsEx newCon, DimensionsObjectList list) {
        DimensionsConnectionDetailsEx oldCon = list.getConnectionDetails();

        if (oldCon.equals(newCon) && (oldCon != newCon)) {
            list.setConnectionDetails(newCon);
        }
    }

    protected void fireEvent(DimensionsListEvent e) {
        for (Iterator<IDimensionsObjectListListener> iter = listeners.iterator(); iter.hasNext();) {
            IDimensionsObjectListListener listListener = iter.next();
            listListener.listChanged(e);
        }
    }

    protected void fireObjectsAdded(APIObjectAdapter[] objects) {
        if (objects.length != 0) {
            fireEvent(new DimensionsListEvent(this, DimensionsListEvent.OBJECTS_ADDED, objects));
        }
    }

    protected void fireObjectsRemoved(APIObjectAdapter[] objects) {
        if (objects.length != 0) {
            fireEvent(new DimensionsListEvent(this, DimensionsListEvent.OBJECTS_REMOVED, objects));
        }
    }

    protected void fireObjectsChanged(APIObjectAdapter[] objects) {
        if (objects.length != 0) {
            fireEvent(new DimensionsListEvent(this, DimensionsListEvent.OBJECTS_CHANGED, objects));
        }
    }

    protected void removeObjects(APIObjectAdapter[] adapters) {
        List<APIObjectAdapter> actuallyRemoved = new ArrayList<APIObjectAdapter>(adapters.length);
        for (int i = 0; i < adapters.length; i++) {
            String id = getUniqueId(adapters[i].getAPIObject());
            APIObjectAdapter removedObject = objects.remove(id);
            if (removedObject != null) {
                actuallyRemoved.add(removedObject);
            }

        }
        fireObjectsRemoved(actuallyRemoved.toArray(new APIObjectAdapter[actuallyRemoved.size()]));
    }

    protected void addObjects(APIObjectAdapter[] adapters) {
        List<APIObjectAdapter> added = new ArrayList<APIObjectAdapter>();
        List<APIObjectAdapter> changed = new ArrayList<APIObjectAdapter>();
        synchronized (objects) { // lock map for updates
            for (int i = 0; i < adapters.length; i++) {
                String id = getUniqueId(adapters[i].getAPIObject());
                APIObjectAdapter oldEntry = objects.get(id);
                if (oldEntry != null) {
                    DimensionsArObject newObject = adapters[i].getAPIObject();
                    DimensionsArObject oldObject = oldEntry.getAPIObject();
                    if (!Utils.compareAttributes(getAllSubscribedAttributes(), newObject, oldObject)) {
                        oldEntry.setAPIObject(newObject);
                        changed.add(oldEntry);
                    }
                } else {
                    objects.put(id, adapters[i]);
                    adapters[i].setObjectList(this);
                    added.add(adapters[i]);
                }

            }
        }
        fireObjectsChanged(changed.toArray(new APIObjectAdapter[changed.size()]));
        fireObjectsAdded(added.toArray(new APIObjectAdapter[added.size()]));
    }

    // finds if all elements of set are in ofSet, ofSet must be sorted as by Arrays.sort()
    private static boolean isSubSet(int[] set, int[] ofSet) {
        if (set.length == 0) {
            return true; // empty set is always a subset
        }

        if (set.length > ofSet.length) {
            return false;
        }

        for (int i = 0; i < set.length; i++) {
            if (Arrays.binarySearch(ofSet, set[i]) < 0) {
                return false;
            }
        }
        return true;
    }

    private void bulkQuery(final Session session, final int[] attributes, List<?> toQueryObjects) throws DMException {
        BulkOperator boper = session.getObjectFactory().getBulkOperator(toQueryObjects);
        boper.queryAttribute(attributes);
    }

    /**
     * @param wantedType
     * @return <code>true</code> if this list is of the wanted type
     */
    public boolean isList(int wantedType) {
        return this.type == wantedType;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj instanceof DimensionsObjectList) {
            DimensionsObjectList otherList = (DimensionsObjectList) obj;
            if (getConnectionDetails().equals(otherList.getConnectionDetails())) {
                if (getTypeScope().equals(otherList.getTypeScope()) && type == otherList.getType()) {
                    // @formatter:off
                    return getQualifier() == null ? otherList.getQualifier() == null :
                        getQualifier().equals(otherList.getQualifier());
                    // @formatter:on

                }
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hc = getConnectionDetails().hashCode() ^ getTypeScope().hashCode() ^ getType();
        if (getQualifier() != null) {
            hc ^= getQualifier().hashCode();
        }
        return hc;
    }

    @SuppressWarnings("unchecked")
    protected void addNotClosedCriterion(Filter filter) {
        // @formatter:off
        filter.criteria().add(
                new Filter.Criterion(
                        SystemAttributes.CM_PHASE,
                        IDMConstants.CLOSED_PHASE,
                        Filter.Criterion.NOT | Filter.Criterion.EQUALS));
        // @formatter:on
    }

    protected boolean isPrefetched() {
        return prefetched;
    }

    protected void setPrefetched(boolean prefetched) {
        this.prefetched = prefetched;
    }

    public List<? super DimensionsArObject> getPrefetchCache() {
        return prefetchCache;
    }

}

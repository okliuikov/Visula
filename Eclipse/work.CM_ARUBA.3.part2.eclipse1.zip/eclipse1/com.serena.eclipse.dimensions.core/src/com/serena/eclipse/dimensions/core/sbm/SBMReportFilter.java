package com.serena.eclipse.dimensions.core.sbm;

import java.util.Calendar;

import com.serena.eclipse.sbm.ws.clientapi.xsd.ReportCategory;
import com.serena.eclipse.sbm.ws.clientapi.xsd.ReportType;
import com.serena.eclipse.sbm.ws.clientapi.xsd.ReportsFilter;

public class SBMReportFilter {

    public static final int REPORT_LEVEL_ALL = 0; // All reports
    public static final int REPORT_LEVEL_MY = 1; // My reports
    public static final int REPORT_LEVEL_BI = 2; // Built-in reports
    public static final int REPORT_LEVEL_QL = 3; // QuickLinks reports

    private int reportLevel = REPORT_LEVEL_ALL;
    private String nameMask;
    private String author;
    private Calendar createDateFrom;
    private Calendar createDateTo;

    public SBMReportFilter() {
        super();
    }

    public SBMReportFilter(int reportLevel, String nameMask, String author, Calendar createDateFrom, Calendar createDateTo) {
        super();
        setNameMask(nameMask);
        setReportLevel(reportLevel);
        setAuthor(author);
        setCreateDateFrom(createDateFrom);
        setCreateDateTo(createDateTo);
    }

    public void setNameMask(String nameMask) {
        if (nameMask != null && nameMask.trim().length() < 1) {
            this.nameMask = null;
        } else {
            this.nameMask = nameMask;
        }
    }

    public void setReportLevel(int reportLevel) {
        if (reportLevel < REPORT_LEVEL_ALL || reportLevel > REPORT_LEVEL_QL) {
            this.reportLevel = REPORT_LEVEL_ALL;
        } else {
            this.reportLevel = reportLevel;
        }
    }

    public void setAuthor(String author) {
        if (author != null && author.trim().length() < 1) {
            this.author = null;
        } else {
            this.author = author;
        }
    }

    public void setCreateDateFrom(Calendar createDateFrom) {
        this.createDateFrom = createDateFrom;
    }

    public void setCreateDateTo(Calendar createDateTo) {
        this.createDateTo = createDateTo;
    }

    ReportsFilter prepareReportFilter(String solutionName) {
        ReportsFilter result = new ReportsFilter();
        result.setReportType(ReportType.LISTING);
        if (solutionName != null) {
            result.setSolutionName(solutionName);
        }
        ReportCategory cat = ReportCategory.ALL;
        switch (getReportLevel()) {
        case REPORT_LEVEL_MY:
            cat = ReportCategory.MY;
            break;
        case REPORT_LEVEL_BI:
            cat = ReportCategory.BUILTIN;
            break;
        case REPORT_LEVEL_QL:
            cat = ReportCategory.QUICKLINKS;
            break;
        }
        result.setReportCategory(cat);

        if (getNameMask() != null) {
            result.setReportName(getNameMask());
        }
        if (getAuthor() != null) {
            result.setAuthorID(getAuthor());
        }
        if (getCreateDateFrom() != null) {
            result.setCreatedDateFrom(getCreateDateFrom());
        }
        if (getCreateDateTo() != null) {
            result.setCreatedDateTo(getCreateDateTo());
        }
        return result;
    }

    public String getNameMask() {
        return nameMask;
    }

    public int getReportLevel() {
        return reportLevel;
    }

    public String getAuthor() {
        return author;
    }

    public Calendar getCreateDateFrom() {
        return createDateFrom;
    }

    public Calendar getCreateDateTo() {
        return createDateTo;
    }

    /*
     * If reportLevel property is the only and set to REPORT_LEVEL_ALL - return false,
     * otherwise return true
     */
    public boolean isSet() {
        if (getReportLevel() == REPORT_LEVEL_ALL && getNameMask() == null && getAuthor() == null && getCreateDateFrom() == null
                && getCreateDateTo() == null) {
            return false;
        }
        return true;
    }
}

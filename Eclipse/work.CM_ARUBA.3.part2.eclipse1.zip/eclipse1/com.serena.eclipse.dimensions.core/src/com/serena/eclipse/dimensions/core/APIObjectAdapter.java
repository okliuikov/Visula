/*
 * @APIObjectAdapter.java, created on Apr 13, 2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */

package com.serena.eclipse.dimensions.core;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.PlatformObject;
import org.eclipse.osgi.util.NLS;

import com.serena.dmclient.api.DimensionsArObject;
import com.serena.dmclient.api.DimensionsLcObject;
import com.serena.dmclient.api.DimensionsObjectFactory;
import com.serena.dmclient.api.DimensionsResult;
import com.serena.dmclient.api.Request;
import com.serena.dmclient.api.SystemAttributes;
import com.serena.eclipse.core.IServiceResource;
import com.serena.eclipse.dimensions.core.util.Assert;
import com.serena.eclipse.dimensions.core.util.Utils;
import com.serena.eclipse.dimensions.internal.core.Messages;

/**
 * <P>
 * A simple wrapper that adapts a Dimensions API object to Eclipse-specific interfaces. Each adapter wraps an actual API object and
 * its corresponding connection server location.
 *
 * <P>
 * Methods <code>hashCode()</code> and <code>equals()</code> are implemented based on connection and the API object.
 *
 * @author V.Grishchenko
 */
public abstract class APIObjectAdapter extends PlatformObject implements IServiceResource, IDimensionsServiceResource {

    private DimensionsArObject apiObject;
    private DimensionsConnectionDetailsEx connection;
    private DimensionsObjectList objectList;
    private APIObjectAdapter parentAdapter; // used for children of projects/groups

    private int listIndex = -1; // if greater -1 means possible position of element in viewer
    private boolean storedInSearchStorage;

    /**
     * Creates a new API object adapter.
     *
     * @param apiObject
     *            adaptee, cannot be <code>null</code>
     * @param connectionDetails
     *            connection information for adaptee, cannot be <code>null</code>
     */
    public APIObjectAdapter(DimensionsArObject apiObject, DimensionsConnectionDetailsEx connection) {
        this.apiObject = apiObject;
        this.connection = connection;
    }

    protected abstract APIObjectAdapter doGetCopy(DimensionsObjectFactory factory) throws Exception;

    public String getObjectSpec() {
        return (String) getAPIObject().getAttribute(SystemAttributes.OBJECT_SPEC);
    }

    /**
     * @return underlying API object
     */
    public DimensionsArObject getAPIObject() {
        return apiObject;
    }

    protected void setAPIObject(DimensionsArObject apiObject) {
        Assert.isNotNull(apiObject);
        this.apiObject = apiObject;
    }

    /**
     * @return underlying connection details
     */
    @Override
    public DimensionsConnectionDetailsEx getConnectionDetails() {
        return connection;
    }

    @Override
    public String getServiceId() {
        return DMPlugin.SERVICE_ID;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj instanceof APIObjectAdapter) {
            APIObjectAdapter otherAdapter = (APIObjectAdapter) obj;
            if (apiObject.equals(otherAdapter.getAPIObject())) {
                return objectList == null ? otherAdapter.objectList == null : objectList.equals(otherAdapter.objectList);
            }
        }

        return false;
    }

    @Override
    public int hashCode() {
        int hc = apiObject.hashCode();
        if (objectList != null) {
            hc ^= objectList.hashCode();
        }
        return hc;
    }

    /**
     * @return the type scope for this adapter
     */
    public abstract DMTypeScope getTypeScope();

    /**
     * @return object list that this object belongs to if known, returns <code>null</code> otherwise
     */
    public DimensionsObjectList getObjectList() {
        return objectList;
    }

    void setObjectList(DimensionsObjectList objectList) {
        this.objectList = objectList;
    }

    /**
     * @return the parent adapter
     */
    public APIObjectAdapter getParentAdapter() {
        return parentAdapter;
    }

    /**
     * @param parentAdapter
     *            sets the parent adapter for this adapter, used for children of IDE projects
     *            and groups
     *
     */
    public void setParentAdapter(APIObjectAdapter parentAdapter) {
        this.parentAdapter = parentAdapter;
    }

    public void delete(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        try {
            String task = Messages.objectDelete_task;
            String subtask = (String) apiObject.getAttribute(SystemAttributes.OBJECT_SPEC);
            String console = NLS.bind(Messages.objectDelete_console, getTypeScope().getDisplayText().toLowerCase(), subtask);
            monitor.beginTask(task, IProgressMonitor.UNKNOWN);
            monitor.subTask(subtask);
            connection.openSession(null).run(new APIOperation(console) {
                @Override
                protected DimensionsResult doRun() throws Exception {
                    return apiObject.delete();
                }
            }, monitor);
            if (getObjectList() != null) {
                getObjectList().removeObjects(new APIObjectAdapter[] { this });
            }

            // FIXME: DEF266809 - find more appropriate list for object as we can lost creation notification
            if (isStoredInSearchStorage()) {
                getConnectionDetails().getSearchObjectsStorage().listChanged(
                        new DimensionsListEvent(this, DimensionsListEvent.OBJECTS_REMOVED, new APIObjectAdapter[] { this }));
            }
        } finally {
            monitor.done();
        }
    }

    public APIObjectAdapter getCopy(IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(NLS.bind(Messages.objectGetCopy_task, getTypeScope().getDisplayText(), getObjectSpec()), 100);
        final APIObjectAdapter[] resultHolder = new APIObjectAdapter[1];
        final Session session = getConnectionDetails().openSession(Utils.subMonitorFor(monitor, 50));
        try {
            session.run(new ISessionRunnable() {
                @Override
                public void run() throws Exception {
                    resultHolder[0] = doGetCopy(session.getObjectFactory());
                    resultHolder[0].setObjectList(getObjectList());
                    resultHolder[0].setParentAdapter(getParentAdapter());
                }
            }, monitor);
        } finally {
            monitor.done();
        }
        return resultHolder[0];
    }

    /**
     * Updates the specified attributes on the underlying object. Associated list,
     * if any, will broadcast appropriate events.
     *
     * @param attrs
     *            attributes to update
     * @param password
     * @param monitor
     * @throws DMException
     */
    public void updateAttributes(final int[] attrs, final String password, IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.objectUpdateAttrs_task, 30);
        try {
            Session session = connection.openSession(Utils.subMonitorFor(monitor, 10));
            session.run(
                    new APIOperation(NLS.bind(Messages.objectUpdateAttrs_console, getTypeScope().getDisplayText(), getObjectSpec())) {
                        @Override
                        public DimensionsResult doRun() throws Exception {
                            try {
                                if (!Utils.isNullEmpty(password)) {
                                    apiObject.setAttribute(SystemAttributes.AUTHORIZATION_POINT_INFO, password);
                                }
                                if (apiObject instanceof Request) {
                                    ((Request) apiObject).setRequestMustSendProject(true);
                                }
                                apiObject.updateAttribute(attrs);
                            } finally {
                                apiObject.setAttribute(SystemAttributes.AUTHORIZATION_POINT_INFO, null);
                            }
                            return new DimensionsResult(Messages.objectUpdateAttrs_ok);
                        }
                    }, monitor);
            monitor.worked(10);
            if (objectList != null) {
                objectList.update(new APIObjectAdapter[] { this }, true, Utils.subMonitorFor(monitor, 10));
            }

            // FIXME: DEF266809 - find more appropriate list for object as we can lost creation notification
            if (isStoredInSearchStorage()) {
                getConnectionDetails().getSearchObjectsStorage().listChanged(
                        new DimensionsListEvent(this, DimensionsListEvent.OBJECTS_CHANGED, new APIObjectAdapter[] { this }));
            }
        } finally {
            monitor.done();
        }
    }

    /**
     * Actions the underlying object to the specified state. This will
     * refresh the associated object list, if any.
     *
     * @param state
     *            state to action the object to
     * @param attrNums
     *            attributes to update as a part of actioning
     * @param password
     * @param monitor
     * @throws DMException
     */
    public void actionTo(final String state, final int[] attrNums, final String comment, final String password,
            IProgressMonitor monitor) throws DMException {
        monitor = Utils.monitorFor(monitor);
        monitor.beginTask(Messages.objectAction_task, 40);
        IDimensionsObjectListListener listener = null;
        try {
            Session session = connection.openSession(Utils.subMonitorFor(monitor, 10)); // 10
            String[] bindings = new String[] { getTypeScope().getDisplayText(), getObjectSpec(), state };
            session.run(new APIOperation(NLS.bind(Messages.objectAction_console, bindings)) { // )
                        @Override
                        protected DimensionsResult doRun() throws Exception {
                            try {
                                if (!Utils.isNullEmpty(password)) {
                                    apiObject.setAttribute(SystemAttributes.AUTHORIZATION_POINT_INFO, password);
                                }
                                if (apiObject instanceof Request) {
                                    ((Request) apiObject).setRequestMustSendProject(true);
                                }
                                return ((DimensionsLcObject) apiObject).actionTo(state, attrNums, comment);
                            } finally {
                                apiObject.setAttribute(SystemAttributes.AUTHORIZATION_POINT_INFO, null);
                            }
                        }
                    }, monitor);
            monitor.worked(10); // 20
            if (objectList != null) {
                final boolean[] needUpdate = new boolean[] { true };
                // no need to force events if change is sent out by fetch
                listener = new IDimensionsObjectListListener() {
                    @Override
                    public void listChanged(DimensionsListEvent e) {
                        for (int i = 0; i < e.changes.length; i++) {
                            if (e.changes[i].equals(APIObjectAdapter.this)) {
                                needUpdate[0] = false;
                                break;
                            }
                        }
                    }
                };
                objectList.addListener(listener);
                objectList.fetch(Utils.subMonitorFor(monitor, 10)); // 30
                objectList.removeListener(listener);
                listener = null;
                if (needUpdate[0]) {
                    objectList.update(new APIObjectAdapter[] { this }, true, Utils.subMonitorFor(monitor, 10)); // 40
                }
            }

            // FIXME: DEF266809 - find more appropriate list for object as we can lost creation notification
            if (isStoredInSearchStorage()) {
                getConnectionDetails().getSearchObjectsStorage().listChanged(
                        new DimensionsListEvent(null, DimensionsListEvent.OBJECTS_CHANGED, new APIObjectAdapter[] { this }));
            }
        } finally {
            if (objectList != null && listener != null) {
                objectList.removeListener(listener);
            }
            monitor.done();
        }
    }

    /**
     * Returns string representation of this object in format "scope spec"
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return getTypeScope().getDisplayText(getObjectSpec());
    }

    public int getListIndex() {
        return listIndex;
    }

    public void setListIndex(int listIndex) {
        this.listIndex = listIndex;
    }

    public void setStoredInSearchStorage(boolean storedInSearchStorage) {
        this.storedInSearchStorage = storedInSearchStorage;
    }

    public boolean isStoredInSearchStorage() {
        return storedInSearchStorage;
    }

}

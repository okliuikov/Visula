/*
 * DmSettings.java, created on 10-May-2005
 * Copyright SERENA Software,Inc. 1998-2005. All Rights Reserved.
 * This computer software is Licensed Material belonging to Serena Software.
 * It is considered a trade secret and not to be used or divulged by parties
 * who have not received written authorization from Serena Software.
 */
package com.serena.eclipse.dimensions.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Manages a Dimensions connection settings file.
 * The original dimensions.rc files looked like this:
 *
 * <pre>
 *     &lt;?xml version="1.0" encoding="UTF-8" standalone="no" ?>
 *     &lt;DimensionsConnections>
 *      &lt;conname id="loc">
 *       &lt;user>bryan&lt;/user>
 *       &lt;dmdb>pvcs&lt;/dmdb>
 *       &lt;dsn>devpvcs&lt;/dsn>
 *       &lt;host>stal-dev-sun7&lt;/host>
 *       &lt;root>/pvcs/serena/changeman/dimensions/9.1/&lt;/root>
 *       &lt;auto>yes&lt;/auto>
 *       &lt;dflt>no&lt;/dflt>
 *      &lt;/conname>
 *     &lt;/DimensionsConnections>
 * </pre>
 *
 * The new style looks like this:
 *
 * <pre>
 *     &lt;?xml version="1.0" encoding="utf-8" ?>
 *     &lt;ConnectionSettings xmlns="http://schemas.serena.com/2005/04/dimensions"
 *         version="10.0" default="dmsys@local">
 *      &lt;connection id="dmsys@local">
 *       &lt;param name="user" value="dmsys" />
 *       &lt;param name="dmdb" value="intermediate" />
 *       &lt;param name="dsn" value="dim90" />
 *       &lt;param name="host" value="uk-dev-sjr" />
 *       &lt;param name="auto" value="no" />
 *       &lt;param name="typestring" value="..." />
 *       &lt;param name="lastlogin" value="..." />
 *       &lt;param name="workset1" value=�PAYROLL:WS_DEV_WIN� />
 *       &lt;param name="workset2" value=�PAYROLL:WS_INITIAL� />
 *      &lt;/connection>
 *     &lt;/ConnectionSettings>
 * </pre>
 *
 * The client settings store file is similar:
 *
 * <pre>
 *     &lt;?xml version="1.0" encoding="utf-8" ?>
 *     &lt;ClientSettings xmlns="http://schemas.serena.com/2005/04/dimensions" version="x.y">
 *      &lt;client type="clienttype">
 *       &lt;group name="groupname">
 *        &lt;param name="name" value="value" />
 *        &lt;param name="name" value="value" />
 *        ...
 *       &lt;/group>
 *       &lt;group name="groupname">
 *        ...
 *       &lt;/group>
 *      &lt;/client>
 *      &lt;client type="clienttype">
 *       &lt;group name="groupname">
 *        &lt;param name="name" value="value" />
 *       &lt;/group>
 *      &lt;/client>
 *     &lt;/ClientSettings>
 * </pre>
 */
public class DmSettings {

    // Values used in the old .dimensions.rc file...
    private static String DMRC_CONN_TAG = "DimensionsConnections"; //$NON-NLS-1$
    private static String DMRC_CONNAME_TAG = "conname"; //$NON-NLS-1$
    private static String DMRC_USERNAME_TAG = "user"; //$NON-NLS-1$
    private static String DMRC_PCMSDB_TAG = "dmdb"; //$NON-NLS-1$
    private static String DMRC_TWOTASK_TAG = "dsn"; //$NON-NLS-1$
    private static String DMRC_HOST_TAG = "host"; //$NON-NLS-1$
    private static String DMRC_PCMSROOT_TAG = "root"; //$NON-NLS-1$
    private static String DMRC_AUTOLOGIN_TAG = "auto"; //$NON-NLS-1$
    private static String DMRC_DFLT_TAG = "dflt"; //$NON-NLS-1$
    // new file
    private static String DMCON_CONN_TAG = "ConnectionSettings"; //$NON-NLS-1$
    private static String DMCON_CONNECTION_TAG = "connection"; //$NON-NLS-1$
    private static String DMCON_PARAM_TAG = "param"; //$NON-NLS-1$
    private static String DMCON_CONNAME_ATTR = "id"; //$NON-NLS-1$
    private static String DMCON_NAME_ATTR = "name"; //$NON-NLS-1$
    private static String DMCON_VALUE_ATTR = "value"; //$NON-NLS-1$

    private static String DMCON_USERNAME_PNAME = "user"; //$NON-NLS-1$
    private static String DMCON_DMDB_PNAME = "dmdb"; //$NON-NLS-1$
    private static String DMCON_DSN_PNAME = "dsn"; //$NON-NLS-1$
    private static String DMCON_HOST_PNAME = "host"; //$NON-NLS-1$
    private static String DMCON_CERTIFICATE_ID_PNAME = "certificateId"; //$NON-NLS-1$
    private static String DMCON_ISSMARTCARDLOGIN_PNAME = "isSmartCardLogin"; //$NON-NLS-1$
    private static String DMCON_CERTIFICATE_LABEL_PNAME = "certificateLabel"; //$NON-NLS-1$

    private static String DMCON_AUTOLOGIN_PNAME = "auto"; //$NON-NLS-1$
    private static String DMCON_TYPESTRING_PNAME = "typestring"; //$NON-NLS-1$
    private static String DMCON_LASTLOGIN_PNAME = "lastlogin"; //$NON-NLS-1$
    private static String DMCON_DFLT_ATTR = "default"; //$NON-NLS-1$
    private static String DMCON_VERSION_ATTR = "version"; //$NON-NLS-1$

    private static DmSettings _theSettings; // for singleton

    // existing file
    private static String DM_RCFILE = ".dimensions.rc"; //$NON-NLS-1$
    // new files
    private static String DM_CONFILE = "ConnectionSettings.xml"; //$NON-NLS-1$

    private String dfltConnection;
    private String SettingsVersion;

    private Map knownConnections;

    Document rcDocument; // original .rc file parsed
    Document connectionDocument; // new connection definition document

    private boolean connectionsInitialized = false;
    private Throwable connectionsError = null;

    private int rcDfltConnection;

    public static class DmSettingsException extends Exception {
        public DmSettingsException(Throwable t) {
            super(t);
        }

    }

    public static class ConnectionDefinition {
        private String definitionName;
        private String user;
        private String dmDb;
        private String dsn;
        private String host;
        private boolean auto;
        private String lastLogin; // compatibility with C api
        private String typeString;
        private String certificateId;
        private boolean isSmartCardLogin;
        private String certificateLabel;

        public String getCertificateLabel() {
            return certificateLabel;
        }

        public void setCertificateLabel(String certificateLabel) {
            this.certificateLabel = certificateLabel;
        }

        public String getCertificateId() {
            return certificateId;
        }

        public void setCertificateId(String certificate) {
            this.certificateId = certificate;
        }

        public boolean getIsSmartCardLogin() {
            return isSmartCardLogin;
        }

        public void setIsSmartCardLogin(boolean isSmartCardLogin) {
            this.isSmartCardLogin = isSmartCardLogin;
        }

        public ConnectionDefinition() {
        }

        /**
         * @return Returns the auto.
         */
        public boolean isAuto() {
            return auto;
        }

        /**
         * @param auto
         *            The auto to set.
         */
        public void setAuto(boolean auto) {
            this.auto = auto;
        }

        /**
         * @return Returns the definitionName.
         */
        public String getDefinitionName() {
            return definitionName;
        }

        /**
         * @param definitionName
         *            The definitionName to set.
         */
        public void setDefinitionName(String definitionName) {
            this.definitionName = definitionName;
        }

        /**
         * @return Returns the dmDb.
         */
        public String getDmDb() {
            return dmDb;
        }

        /**
         * @param dmDb
         *            The dmDb to set.
         */
        public void setDmDb(String dmDb) {
            this.dmDb = dmDb;
        }

        /**
         * @return Returns the dsn.
         */
        public String getDsn() {
            return dsn;
        }

        /**
         * @param dsn
         *            The dsn to set.
         */
        public void setDsn(String dsn) {
            this.dsn = dsn;
        }

        /**
         * @return Returns the host.
         */
        public String getHost() {
            return host;
        }

        /**
         * @param host
         *            The host to set.
         */
        public void setHost(String host) {
            this.host = host;
        }

        /**
         * @return Returns the lastLogin.
         */
        public String getLastLogin() {
            return lastLogin;
        }

        /**
         * @param lastLogin
         *            The lastLogin to set.
         */
        public void setLastLogin(String lastLogin) {
            this.lastLogin = lastLogin;
        }

        /**
         * @return Returns the typeString.
         */
        public String getTypeString() {
            return typeString;
        }

        /**
         * @param typeString
         *            The typeString to set.
         */
        public void setTypeString(String typeString) {
            this.typeString = typeString;
        }

        /**
         * @return Returns the user.
         */
        public String getUser() {
            return user;
        }

        /**
         * @param user
         *            The user to set.
         */
        public void setUser(String user) {
            this.user = user;
        }
    }

    // internal class so we can refer to the matching dom node
    private static class InternalConnectionDefinition {
        private ConnectionDefinition definition;
        private Properties extraInformation; // name=value
        private Node domNode;

        public InternalConnectionDefinition() {
            extraInformation = new Properties();

        }

        /**
         * @return Returns the domNode.
         */
        public Node getDomNode() {
            return domNode;
        }

        /**
         * @param domNode
         *            The domNode to set.
         */
        public void setDomNode(Node domNode) {
            this.domNode = domNode;
        }

        /**
         * @return Returns the theSettings.
         */
        public ConnectionDefinition getDefinition() {
            return definition;
        }

        /**
         * @param theSettings
         *            The theSettings to set.
         */
        public void setDefinition(ConnectionDefinition theDefinition) {
            this.definition = theDefinition;
        }

        public String getExtraInformation(String key) {
            return extraInformation.getProperty(key);
        }

        public void setExtraInformation(String key, String value) {
            if (key == null) {
                return;
            }
            if (value == null) {
                extraInformation.remove(key);
            } else {
                extraInformation.setProperty(key, value);
            }
        }

        public Properties getExtraProperties() {
            return extraInformation;
        }
    }

    // helper class
    private static class SettingsFileUtil {
        private static final boolean test = false;
        private static final String TEST_SUFFIX = "_test"; //$NON-NLS-1$
        private static final String VERSION_SUFFIX = "10.1"; //$NON-NLS-1$
        private static final String UNIX_SUFFIX = ".Serena/Dimensions/" + VERSION_SUFFIX;
        private static final String WIN32_SUFFIX = "Application Data\\Serena\\Dimensions\\" + VERSION_SUFFIX;

        private SettingsFileUtil() {
            // Prevent instantiation.
        }

        private static String internalGetUserHomeName() {
            // May need to change this implementation to work in a managed application.
            String ret = System.getProperty("user.home");
            if (ret == null || ret.equals("")) {
                ret = ".";
            }
            return ret;
        }

        private static String getPreferencesFolderName() {
            String s = SettingsFileUtil.internalGetUserHomeName();
            StringBuffer sb = new StringBuffer(s);
            if (!s.endsWith(File.separator)) {
                sb.append(File.separatorChar);
            }
            // java guarantees that this = \ on windows and / on unix
            if (File.separatorChar == '\\') {
                sb.append(SettingsFileUtil.WIN32_SUFFIX);
            } else {
                sb.append(SettingsFileUtil.UNIX_SUFFIX);
                // add a separator
            }

            if (test) {
                sb.append(TEST_SUFFIX);
            }
            sb.append(File.separatorChar);

            return sb.toString();
        }

        public static File getPreferencesFolder() {
            return new File(SettingsFileUtil.getPreferencesFolderName());
        }

        public static boolean isUnix() {
            return File.separatorChar == '/';
        }

        public static String getVersionString() {
            return VERSION_SUFFIX;
        }

        public static File getUserHomeFolder() {
            String s = SettingsFileUtil.internalGetUserHomeName();
            StringBuffer sb = new StringBuffer(s);
            if (!s.endsWith(File.separator)) {
                sb.append(File.separatorChar);
            }
            return new File(sb.toString());
        }
    }

    /**
     * Static factory method to get single instance
     *
     * @return reference to the singleton
     *
     */
    public static DmSettings getInstance() {
        if (_theSettings == null) {
            _theSettings = new DmSettings();
        }

        return _theSettings;
    }

    /**
     * Private constructor
     */
    private DmSettings() {
    }

    // public methods to mimic the C API

    /**
     * gets an array of <code>ConnectionDefinitions</code>
     *
     * @return the array of <code>ConnectionDefinitions</code> or an empty array if
     *         no known connections
     */
    private InternalConnectionDefinition[] getInternalConArray() {
        Collection intConColl = knownConnections.values();
        return (InternalConnectionDefinition[]) intConColl.toArray(new InternalConnectionDefinition[intConColl.size()]);
    }

    private ConnectionDefinition[] getFromInternal(InternalConnectionDefinition[] in) {
        ConnectionDefinition[] theCons = new ConnectionDefinition[in.length];
        for (int x = 0, xl = theCons.length; x < xl; x++) {
            theCons[x] = in[x].getDefinition();
        }
        return theCons;
    }

    public ConnectionDefinition[] getConnectionDefinitions() {
        return getFromInternal(getInternalConArray());
    }

    public String[] getConnectiondefinitionIDs() {
        ConnectionDefinition[] theCons = getFromInternal(getInternalConArray());
        String[] definitionIDs = new String[theCons.length];
        for (int x = 0, xl = theCons.length; x < xl; x++) {
            definitionIDs[x] = new String(theCons[x].getDefinitionName());
        }
        return definitionIDs;

    }

    public ConnectionDefinition getConnectionDefinitionInfo(String definitionID) {
        InternalConnectionDefinition myDef = (InternalConnectionDefinition) knownConnections.get(definitionID);
        if (myDef != null) {
            return myDef.getDefinition();
        } else {
            return null;
        }
    }

    // do not need definition name and should be same as def.getDefinitionName()
    public boolean saveConnectionDefinitionInfo(ConnectionDefinition def) {
        boolean success = false;
        if (knownConnections.containsKey(def.getDefinitionName())) {
            InternalConnectionDefinition intDef = (InternalConnectionDefinition) knownConnections.get(def.getDefinitionName());
            intDef.setDefinition(def);
            // we have an existing definition
            // update with new data
            Node newNode = updateDomConnection(def.getDefinitionName(), intDef);
            if (newNode != null) {
                if (intDef != null) {
                    intDef.setDomNode(newNode);
                    success = true;
                }

            }
        } else {
            // we have a new definition
            InternalConnectionDefinition newDef = new InternalConnectionDefinition();
            newDef.setDefinition(def);
            Node newNode = addConnectionToDom(def.getDefinitionName(), newDef);
            if (newNode != null) {
                newDef.setDomNode(newNode);
                knownConnections.put(def.getDefinitionName(), newDef);
                success = true;

            }
        }
        if (success) {
            success = persistConnection();
        }

        return success;
    }

    public String GetDefaultConnection() {
        return dfltConnection;

    }

    public boolean setDefaultConnection(String definitionID) {
        if (!knownConnections.containsKey(definitionID)) {
            // default is not a known connection
            return false;
        }
        dfltConnection = new String(definitionID);
        // update the dom and persist
        Element root = connectionDocument.getDocumentElement();
        if (root != null && root.getNodeType() == Node.ELEMENT_NODE && root.getNodeName().equals(DMCON_CONN_TAG)) {
            root.setAttribute(DMCON_DFLT_ATTR, definitionID);
        }
        return persistConnection();

    }

    public String getConnectionExtraData(String definitionID, String key) {
        InternalConnectionDefinition myDef = (InternalConnectionDefinition) knownConnections.get(definitionID);
        if (myDef != null) {
            return myDef.getExtraInformation(key);
        } else {
            return null;
        }
    }

    public boolean setConnectionExtraData(String definitionID, String key, String value) {
        InternalConnectionDefinition myDef = (InternalConnectionDefinition) knownConnections.get(definitionID);
        if (myDef != null) {
            if (key == null) {
                return true;
            }
            myDef.setExtraInformation(key, value);
            Node n = updateDomConnection(definitionID, myDef);
            if (n != null) {
                myDef.setDomNode(n);
                return persistConnection();
            } else {
                return false;
            }

        } else {
            return false;
        }
    }

    public boolean deleteConnectionDefinition(String definitionID) {
        synchronized (connectionDocument) {
            InternalConnectionDefinition intDef = (InternalConnectionDefinition) knownConnections.get(definitionID);
            if (intDef != null) {
                Node conNode = intDef.getDomNode();
                Node pn = conNode.getParentNode();
                pn.removeChild(conNode);
                // now remove from the knownConnections list
                knownConnections.remove(definitionID);
                // remove default if deleting default connection
                if (definitionID.equals(dfltConnection)) {
                    dfltConnection = null;
                    // also remove from the default setting
                    Element root = connectionDocument.getDocumentElement();
                    if (root != null && root.getNodeType() == Node.ELEMENT_NODE && root.getNodeName().equals(DMCON_CONN_TAG)) {
                        root.setAttribute(DMCON_DFLT_ATTR, ""); //$NON-NLS-1$
                    }

                }
                persistConnection();
            }

        }

        return true;
    }

    private boolean persistConnection() {
        try {
            // we write out the Dom
            return writeXmlFile(connectionDocument, getPreferencesFolderFile(), DM_CONFILE);
        } catch (DmSettingsException e) {
            connectionsError = e.getCause();
            return false;
        }
    }

    public synchronized void getPreferencesFolderName() {
    }

    {
        connectionDocument = null;
        if (knownConnections != null) {
            knownConnections.clear();
        }

    }

    public synchronized void clearConnection() {
        connectionDocument = null;
        knownConnections.clear();
    }

    public synchronized boolean initializeConnections() {
        File dmConnFile = new File(SettingsFileUtil.getPreferencesFolderName(), DM_CONFILE);
        boolean success = true;
        if (SettingsFileUtil.isUnix() && needToMigrate()) {
            // process existing dimensions.rc file and write a new ConnectionSettings.xml
            // should not be called after initial load
            File dmRcfile = new File(SettingsFileUtil.getUserHomeFolder(), DM_RCFILE);
            try {
                rcDocument = loadXMLFile(dmRcfile);
            } catch (DmSettingsException e1) {
                return false;
            }
            // now parse and create a new connection Settings file
            // not currently done

        }
        // if file does not exist, then create blank one
        if (!dmConnFile.exists()) {
            setupConnnectionFile();
        }
        try {
            connectionDocument = loadXMLFile(dmConnFile);
        } catch (DmSettingsException e) {
            success = false;
            connectionDocument = null;
            connectionsError = e.getCause();
        }
        if (connectionDocument != null) {
            // successfully loaded file
            Element root = connectionDocument.getDocumentElement();
            success = processConnectionDocument(root);
        } else {
            success = false;
        }
        connectionsInitialized = success;
        return success;
    }

    // loads XML file into a Document object
    private synchronized Document loadXMLFile(File dmConfigFile) throws DmSettingsException {
        Document theDoc = null;
        FileChannel channel = null;
        FileLock lock = null;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(dmConfigFile);
            channel = fis.getChannel();
        } catch (FileNotFoundException e3) {
            throw new DmSettingsException(e3);
        }
        // Use the file channel to create a lock on the file.
        // This method blocks until it can retrieve the lock.

        try {
            lock = channel.lock(0L, Long.MAX_VALUE, true); // shared so will work
        }

        catch (IOException ioerr) {
            throw new DmSettingsException(ioerr);
        }
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            theDoc = builder.parse(fis);
        } catch (SAXParseException spe) {
            throw new DmSettingsException(spe);
        } catch (SAXException sxe) {
            throw new DmSettingsException(sxe);
        } catch (ParserConfigurationException pce) {
            // Parser with specified options can't be built
            throw new DmSettingsException(pce);
        } catch (IOException ioe) {
            throw new DmSettingsException(ioe);

        }

        finally {
            // releasing lock throws exception as does closing channel fixed with new shared lock
            // fails j2se1.5
            try {
                if (lock != null) {
                    lock.release();
                }
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException e) {
                // ignore exceptions throw new DmSettingsException(e);
            }
        }
        return theDoc;
    }

    private boolean needToMigrate() {
        File oldRc = new File(SettingsFileUtil.getUserHomeFolder(), DM_RCFILE);
        File newSettings = new File(SettingsFileUtil.getPreferencesFolder(), DM_CONFILE);

        if (oldRc.exists() && !newSettings.exists()) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * Process Document looking for Connection information
     *
     * @param root
     */
    private boolean processConnectionDocument(Node root) {
        // sanity checks
        if (root == null) {
            return false;
        }
        if (root.getNodeType() != Node.ELEMENT_NODE) {
            return false;
        }
        if (!root.getNodeName().equals(DMCON_CONN_TAG)) {
            return false;
        }
        NamedNodeMap rootattrs = root.getAttributes();
        if (rootattrs.getLength() == 0) {
            return false;
        } else {
            dfltConnection = rootattrs.getNamedItem(DMCON_DFLT_ATTR).getNodeValue();
            SettingsVersion = rootattrs.getNamedItem(DMCON_VERSION_ATTR).getNodeValue();
        }

        knownConnections = new HashMap();
        NodeList docChild = root.getChildNodes();
        boolean isOk = true;

        for (int c = 0; c < docChild.getLength(); c++) {
            Node cNode = docChild.item(c);
            if (cNode != null && cNode.getNodeType() == Node.ELEMENT_NODE && cNode.getNodeName().equals(DMCON_CONNECTION_TAG)) {
                isOk = processCon(cNode);
            }
        }
        return isOk;
    }

    /**
     * Implements a parsing of the new Structure
     *
     * @param node
     * @return success/failure
     */
    private boolean processCon(Node node) {
        InternalConnectionDefinition theInfo;
        ConnectionDefinition theDef;

        NamedNodeMap nn = node.getAttributes();
        if (nn.getLength() == 0) {
            // should have an id attribute
            // skip
            return false;
        } else {
            String conname = nn.getNamedItem(DMCON_CONNAME_ATTR).getNodeValue();
            if (conname == null || conname.equals("")) {
                return false;
            }
            // keep the name
            theInfo = new InternalConnectionDefinition();
            theDef = new ConnectionDefinition();
            theDef.setDefinitionName(conname);
            theInfo.setDefinition(theDef);
            theInfo.setDomNode(node);
        }
        // now process the children
        NodeList conChild = node.getChildNodes();
        try {
            for (int cc = 0; cc < conChild.getLength(); cc++) {
                Node curNode = conChild.item(cc);
                if (curNode.getNodeType() == Node.ELEMENT_NODE) {
                    // only interested in param elements
                    if (curNode.getNodeName().equals(DMCON_PARAM_TAG)) {
                        // is a param element - get the name / value
                        NamedNodeMap paramAttrs = curNode.getAttributes();
                        if (paramAttrs.getLength() == 0) {
                            // should have name/value attributes
                            // skip
                            continue;
                        }
                        String pname = paramAttrs.getNamedItem(DMCON_NAME_ATTR).getNodeValue();
                        String pvalue = paramAttrs.getNamedItem(DMCON_VALUE_ATTR).getNodeValue();
                        if (pvalue == null) {
                            pvalue = "";
                        }

                        if (pname.equals(DMCON_USERNAME_PNAME)) {
                            theDef.setUser(pvalue);
                        } else if (pname.equals(DMCON_HOST_PNAME)) {
                            theDef.setHost(pvalue);
                        } else if (pname.equals(DMCON_DMDB_PNAME)) {
                            theDef.setDmDb(pvalue);
                        } else if (pname.equals(DMCON_DSN_PNAME)) {
                            theDef.setDsn(pvalue);
                        } else if (pname.equals(DMCON_CERTIFICATE_ID_PNAME)) {
                            theDef.setCertificateId(pvalue);
                        } else if (pname.equals(DMCON_CERTIFICATE_LABEL_PNAME)) {
                            theDef.setCertificateLabel(pvalue);
                        } else if (pname.equals(DMCON_ISSMARTCARDLOGIN_PNAME)) {
                            theDef.setIsSmartCardLogin(pvalue.equals("true"));
                        } else if (pname.equals(DMCON_AUTOLOGIN_PNAME)) {
                            if (pvalue != null && pvalue.equalsIgnoreCase("yes")) {
                                theDef.setAuto(true);
                            } else {
                                theDef.setAuto(false);
                            }

                        } else if (pname.equals(DMCON_TYPESTRING_PNAME)) {
                            theDef.setTypeString(pvalue);
                        } else if (pname.equals(DMCON_LASTLOGIN_PNAME)) {
                            // lastlogin is ms since epoch as a persisted string representation of a long

                            theDef.setLastLogin(pvalue);
                        } else {
                            // not a known one
                            theInfo.setExtraInformation(pname, pvalue);
                        }
                    }
                }
            }
        } catch (DOMException e) {
            return false;
        }

        knownConnections.put(theDef.getDefinitionName(), theInfo);
        return true;
    }

    private boolean processRcCon(Node node, List rcConlist) {
        ConnectionDefinition theInfo;

        NamedNodeMap nn = node.getAttributes();
        if (nn.getLength() == 0) {
            // should have an attribute
            // skip
            return false;
        } else {
            String conname = nn.item(0).getNodeValue();
            if (conname == null || conname.equals("")) {
                return false;
            }
            // keep the name
            theInfo = new ConnectionDefinition();
            theInfo.setDefinitionName(conname);
        }
        // no process the children
        NodeList conChild = node.getChildNodes();
        for (int cc = 0; cc < conChild.getLength(); cc++) {
            Node curNode = conChild.item(cc);
            if (curNode.getNodeType() == Node.ELEMENT_NODE) {
                if (curNode.getNodeName().equals(DMRC_USERNAME_TAG)) {
                    // should have a value
                    Node firstChild = curNode.getFirstChild();
                    if (firstChild.getNodeType() == Node.TEXT_NODE) {
                        String User = firstChild.getNodeValue();
                        theInfo.setUser(User);
                    }
                } else if (curNode.getNodeName().equals(DMRC_PCMSDB_TAG)) {
                    Node firstChild = curNode.getFirstChild();
                    if (firstChild.getNodeType() == Node.TEXT_NODE) {
                        String db = firstChild.getNodeValue();
                        theInfo.setDmDb(db);
                    }
                } else if (curNode.getNodeName().equals(DMRC_TWOTASK_TAG)) {
                    Node firstChild = curNode.getFirstChild();
                    // could be empty then firstChild = null
                    if (firstChild != null && firstChild.getNodeType() == Node.TEXT_NODE) {

                        String tt = firstChild.getNodeValue();
                        theInfo.setDsn(tt);
                    }
                } else if (curNode.getNodeName().equals(DMRC_HOST_TAG)) {
                    Node firstChild = curNode.getFirstChild();
                    if (firstChild.getNodeType() == Node.TEXT_NODE) {
                        String hh = firstChild.getNodeValue();
                        theInfo.setHost(hh);
                    }
                } else if (curNode.getNodeName().equals(DMRC_PCMSROOT_TAG)) {
                    // could be empty
                    Node firstChild = curNode.getFirstChild();
                    if (firstChild != null && firstChild.getNodeType() == Node.TEXT_NODE) {
                        firstChild.getNodeValue();
                    }
                } else if (curNode.getNodeName().equals(DMRC_AUTOLOGIN_TAG)) {
                    Node firstChild = curNode.getFirstChild();
                    if (firstChild.getNodeType() == Node.TEXT_NODE) {
                        String auto = firstChild.getNodeValue();
                        if (auto.equals("yes")) //$NON-NLS-1$
                        {
                            theInfo.setAuto(true);
                        }
                    }
                } else if (curNode.getNodeName().equals(DMRC_DFLT_TAG)) {
                    Node firstChild = curNode.getFirstChild();
                    if (firstChild.getNodeType() == Node.TEXT_NODE) {
                        String dflt = firstChild.getNodeValue();
                        if (dflt.equals("yes")) //$NON-NLS-1$
                        {
                            rcDfltConnection = rcConlist.size();

                        }
                    }
                }
            }
        }
        rcConlist.add(theInfo);
        return true;
    }

    /**
     * Convenience method for a client to retrieve the user dependent settings
     * directory.
     *
     * @return result of <code>SettingsFileUtil.getPreferencesFolderName()</code>
     */
    public String getPreferencesFolder() {
        return SettingsFileUtil.getPreferencesFolderName();
    }

    public File getPreferencesFolderFile() {
        return new File(SettingsFileUtil.getPreferencesFolderName());
    }

    /**
     * @param definitionID
     * @param def
     * @return
     */
    private Node addConnectionToDom(String definitionID, InternalConnectionDefinition def) {
        // we will add a new connection node
        // sanity checks
        if (definitionID == null) {
            return null;
        }
        if (def.getDefinition().getDefinitionName() == null) {
            return null;
        }
        if (!definitionID.equals(def.getDefinition().getDefinitionName())) {
            // sanity check
            return null;
        }
        synchronized (connectionDocument) {

            Element root = connectionDocument.getDocumentElement();
            if (root != null && root.getNodeType() == Node.ELEMENT_NODE && root.getNodeName().equals(DMCON_CONN_TAG)) {
                // we know definition name is not null
                Element newConn = connectionDocument.createElement(DMCON_CONNECTION_TAG);
                newConn.setAttribute(DMCON_CONNAME_ATTR, definitionID);
                // now process the ConnectionDefinition
                if (def.getDefinition().getUser() != null) {
                    Element newUser = connectionDocument.createElement(DMCON_PARAM_TAG);
                    newUser.setAttribute(DMCON_NAME_ATTR, DMCON_USERNAME_PNAME);
                    newUser.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getUser());
                    newConn.appendChild(newUser);
                }
                if (def.getDefinition().getHost() != null) {
                    Element newHost = connectionDocument.createElement(DMCON_PARAM_TAG);
                    newHost.setAttribute(DMCON_NAME_ATTR, DMCON_HOST_PNAME);
                    newHost.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getHost());
                    newConn.appendChild(newHost);
                }
                if (def.getDefinition().getCertificateId() != null) {
                    Element certificateId = connectionDocument.createElement(DMCON_PARAM_TAG);
                    certificateId.setAttribute(DMCON_NAME_ATTR, DMCON_CERTIFICATE_ID_PNAME);
                    certificateId.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getCertificateId());
                    newConn.appendChild(certificateId);
                }
                if (def.getDefinition().getCertificateLabel() != null) {
                    Element certificateLabel = connectionDocument.createElement(DMCON_PARAM_TAG);
                    certificateLabel.setAttribute(DMCON_NAME_ATTR, DMCON_CERTIFICATE_LABEL_PNAME);
                    certificateLabel.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getCertificateLabel());
                    newConn.appendChild(certificateLabel);
                }
                if (def.getDefinition().getIsSmartCardLogin()) {
                    Element newHost = connectionDocument.createElement(DMCON_PARAM_TAG);
                    newHost.setAttribute(DMCON_NAME_ATTR, DMCON_ISSMARTCARDLOGIN_PNAME);
                    newHost.setAttribute(DMCON_VALUE_ATTR, Boolean.toString(def.getDefinition().getIsSmartCardLogin()));
                    newConn.appendChild(newHost);
                }
                if (def.getDefinition().getDmDb() != null) {
                    Element newDb = connectionDocument.createElement(DMCON_PARAM_TAG);
                    newDb.setAttribute(DMCON_NAME_ATTR, DMCON_DMDB_PNAME);
                    newDb.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getDmDb());
                    newConn.appendChild(newDb);
                }
                if (def.getDefinition().getDsn() != null) {
                    Element newDsn = connectionDocument.createElement(DMCON_PARAM_TAG);
                    newDsn.setAttribute(DMCON_NAME_ATTR, DMCON_DSN_PNAME);
                    newDsn.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getDsn());
                    newConn.appendChild(newDsn);
                }
                if (def.getDefinition().getLastLogin() != null) {
                    Element newLast = connectionDocument.createElement(DMCON_PARAM_TAG);
                    newLast.setAttribute(DMCON_NAME_ATTR, DMCON_LASTLOGIN_PNAME);
                    newLast.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getLastLogin());
                    newConn.appendChild(newLast);
                }
                Element newAuto = connectionDocument.createElement(DMCON_PARAM_TAG);
                newAuto.setAttribute(DMCON_NAME_ATTR, DMCON_AUTOLOGIN_PNAME);
                if (def.getDefinition().isAuto()) {
                    newAuto.setAttribute(DMCON_VALUE_ATTR, "yes"); //$NON-NLS-1$
                } else {
                    newAuto.setAttribute(DMCON_VALUE_ATTR, "no"); //$NON-NLS-1$
                }

                newConn.appendChild(newAuto);
                if (def.getDefinition().getTypeString() != null) {
                    Element newTs = connectionDocument.createElement(DMCON_PARAM_TAG);
                    newTs.setAttribute(DMCON_NAME_ATTR, DMCON_TYPESTRING_PNAME);
                    newTs.setAttribute(DMCON_VALUE_ATTR, def.getDefinition().getTypeString());
                    newConn.appendChild(newTs);
                }
                Properties p = def.getExtraProperties();
                if (p.size() > 0) {
                    // have some properties

                    for (Iterator propSetit = p.entrySet().iterator(); propSetit.hasNext();) {
                        Map.Entry mape = (Entry) propSetit.next();
                        Element newExtra = connectionDocument.createElement(DMCON_PARAM_TAG);
                        newExtra.setAttribute(DMCON_NAME_ATTR, (String) mape.getKey());
                        newExtra.setAttribute(DMCON_VALUE_ATTR, (String) mape.getValue());
                        newConn.appendChild(newExtra);

                    }
                }
                root.appendChild(newConn);
                return newConn;
            } else {
                return null;
            }
        }

    }

    private Node updateDomConnection(String definitionID, InternalConnectionDefinition def) {
        // we will delete the original connection
        // and then add from the definition
        synchronized (connectionDocument) {
            InternalConnectionDefinition intDef = (InternalConnectionDefinition) knownConnections.get(definitionID);
            if (intDef != null) {
                Node conNode = intDef.getDomNode();
                if (conNode != null) {
                    Node pn = conNode.getParentNode();
                    if (pn != null) {
                        pn.removeChild(conNode);
                        intDef.setDomNode(null);
                    }
                }
            }
            // now add from passed in defn
            return addConnectionToDom(definitionID, def);
        }

    }

    private boolean setupConnnectionFile() {
        Document d = generateBlankXMLDocument(DMCON_CONN_TAG);
        if (d != null) {
            Element e = d.getDocumentElement();
            if (e != null) {
                e.setAttribute(DMCON_VERSION_ATTR, SettingsFileUtil.getVersionString());
                e.setAttribute(DMCON_DFLT_ATTR, "");
                File prefDir = getPreferencesFolderFile();
                // make sure directories exist
                if (!prefDir.exists()) {
                    if (!prefDir.mkdirs()) {
                        return false;
                    }
                }
                try {
                    return writeXmlFile(d, getPreferencesFolderFile(), DM_CONFILE);
                } catch (DmSettingsException e1) {
                    return false;
                }
            }

        }
        return false;
    }

    private Document generateBlankXMLDocument(String rootElement) {
        // Create a new document to hold the results
        DocumentBuilder builder;
        Document doc = null;
        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            doc = builder.getDOMImplementation().createDocument(null, rootElement, null);
        } catch (ParserConfigurationException e) {
            return null;
        } catch (FactoryConfigurationError e) {
            return null;
        }
        return doc;
    }

    private synchronized boolean writeXmlFile(Document doc, File outDir, String outFileName) throws DmSettingsException {
        FileOutputStream fos = null;
        FileChannel channel = null;
        FileLock lock = null;
        try {
            // make sure directories exist
            if (!outDir.exists()) {
                if (!outDir.mkdirs()) {
                    return false;
                }
            }

            File outFile = new File(outDir, outFileName);
            try {
                fos = new FileOutputStream(outFile);
                channel = fos.getChannel();
            } catch (FileNotFoundException fnf) {
                throw new DmSettingsException(fnf);
            }
            // Use the file channel to create a lock on the file.
            // This method blocks until it can retrieve the lock.

            try {
                lock = channel.lock();
            } catch (IOException ioerr) {
                throw new DmSettingsException(ioerr);
            }
            // Prepare the DOM document for writing
            Source source = new DOMSource(doc);
            Result result = new StreamResult(fos);

            // Write the DOM document to the file
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            Properties p = new Properties();
            p.put(OutputKeys.INDENT, "yes"); //$NON-NLS-1$
            xformer.setOutputProperties(p);
            xformer.transform(source, result);
        } catch (TransformerConfigurationException e) {
            throw new DmSettingsException(e);
        } catch (TransformerException e) {
            throw new DmSettingsException(e);
        } finally {
            try {
                if (lock != null) {
                    lock.release();
                }
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e1) {
            }
        }

        return true;
    }

    /**
     * @return Returns the initialized status for the connections.
     */
    public boolean isConnectionsInitialized() {
        return connectionsInitialized;
    }

    /**
     * @return Returns the last error for the connections.
     */
    public Throwable connectionsLastException() {
        return connectionsError;
    }

    /**
     * @return Returns the connection file Timestamp.
     */
    public long getConnectionTimestamp() {
        File confile = new File(SettingsFileUtil.getPreferencesFolder(), DM_CONFILE);
        if (confile.exists()) {
            return confile.lastModified();
        } else {
            return 0L;
        }
    }
}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

/**
 * @author V.Grishchenko
 */
public class ChallengeDetails {
    public static final int USERNAME = 1;
    public static final int PASSWORD = 2;
    public static final int DOMAIN = 4;

    /** unknown requesting host kind */
    public static final int UNKNOWN = 0;
    /** host kind server - challenge is coming from a server */
    public static final int SERVER = 1;
    /** host kind proxy - challenge is coming from a proxy */
    public static final int PROXY = 2;

    /** required parameters */
    public final int request;
    /** authentication host */
    public final String host;
    /** the port of the authentication host */
    public final int port;
    /** host kind, */
    public final int hostKind;
    /** Authentication realm or <code>null</code> */
    public final String realm;
    /** Authentication scheme name */
    public final String scheme;

    /** suggested username */
    public String username;
    /** suggested domain */
    public String domain;

    // public String password;

    public ChallengeDetails(int request, String host, int port, int hostKind, String realm, String scheme) {
        this.request = request;
        this.host = host;
        this.port = port;
        this.hostKind = hostKind;
        this.realm = realm;
        this.scheme = scheme;
    }

}

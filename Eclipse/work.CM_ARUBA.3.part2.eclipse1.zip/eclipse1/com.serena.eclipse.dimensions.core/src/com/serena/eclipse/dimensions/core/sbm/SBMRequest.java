/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * @author V.Grishchenko
 */
class SBMRequest extends SBMObject implements ISBMRequest {
    static final long serialVersionUID = 6408943708931583928L;

    private static final String RECORD_ID_TEXT = "RecordId="; //$NON-NLS-1$
    private static final String TABLE_ID_TEXT = "TableId="; //$NON-NLS-1$
    private static final char SEPARATOR = '&';

    private String id;
    private String itemId;
    private String title;
    private String sourceUUID;

    SBMRequest(ISBMConnection connection, String id, String itemId, String url, String title, String sourceUUID,
            ISBMContainer parent) {
        super(connection, url, parent);
        this.id = id;
        this.itemId = itemId;
        this.title = title;
        this.sourceUUID = sourceUUID;
    }

    SBMRequest(ISBMConnection connection, String url, ISBMContainer parent) {
        super(connection, url, parent);
        parseIDsFromURL(url);
    }

    @Override
    public int getType() {
        return ITEM;
    }

    @Override
    public String getID() {
        if (Utils.isNullEmpty(id)) {
            id = getProperty(SBMClientHelper.PROPERTY_ITEM_ID);
        }
        return id;
    }

    @Override
    public boolean isActive() throws SBMException {
        return ((SBMManager) getConnection().getSBMManager()).isActive(getItemID());
    }

    @Override
    public boolean isContainer() {
        return false;
    }

    void setID(String id) {
        this.id = id;
    }

    @Override
    public String getItemID() {
        return itemId;
    }

    @Override
    void setUrl(String url) {
        super.setUrl(url);
    }

    @Override
    public String toString() {
        return "[REQUEST] id=\"" + id + "\"; url=\"" + getUrl() + "\"";
    }

    /*
     * This method is called from setURL(). It parses the URL and retrieves
     * the table ID and record ID for this issue, and stores them in our
     * member fields for easy retrieval later.
     * Note that these IDs are stored as Strings, not ints--this is for
     * convenience, as they aren't usable as numeric values; we always need
     * to convert them to Strings anyway when we stuff them into an XML document.
     */
    private void parseIDsFromURL(String url) {
        if (!Utils.isNullEmpty(url)) {
            String recodrdId = null, tableId = null;

            // Get the Record ID.
            int recordOffset = url.indexOf(RECORD_ID_TEXT);
            if (recordOffset != -1) {
                int valOffset = recordOffset + RECORD_ID_TEXT.length();
                recodrdId = getIDFromOffset(url, valOffset);
            }

            // Get the Table ID.
            int tableOffset = url.indexOf(TABLE_ID_TEXT);
            if (tableOffset != -1) {
                int valOffset = tableOffset + TABLE_ID_TEXT.length();
                tableId = getIDFromOffset(url, valOffset);
            }

            this.itemId = SBMItemId.parseItemId(tableId, recodrdId);
            // this.id = itemId.toString();
        }
    }

    /*
     * Beginning from the specified offset in url, return the substring that
     * follows, until either the separator '&' or the end of the URL string is
     * reached.
     * This is specifically used for finding the numeric values of the record
     * and table IDs.
     */
    private String getIDFromOffset(String url, int offset) {
        StringBuffer buf = new StringBuffer();
        int curOffset = offset;
        while ((curOffset < url.length()) && (url.charAt(curOffset) != SEPARATOR)) {
            buf.append(url.charAt(curOffset++));
        }
        return buf.toString();
    }

    @Override
    public String getSourceUUID() {
        return sourceUUID;
    }

    @Override
    public String getTitle() {
        if (Utils.isNullEmpty(title)) {
            title = getProperty(SBMClientHelper.PROPERTY_TITLE);
        }
        return title;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof ISBMRequest) {
            ISBMRequest otherObject = (ISBMRequest) obj;
            return Utils.stringsEqual(id, otherObject.getID());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

}

/*
 * -----------------------------------------------------------------------------
 * Copyright (C) 2008, Serena Software Europe, Ltd. All rights reserved.
 * No part of this software may be reproduced, stored, or transmitted, in any
 * form or by any means, without the prior permission in writing of Serena
 * Software Europe, Ltd and Serena Software, Inc.
 * -----------------------------------------------------------------------------
 * MODULE SPECIFICATION
 * %PID%
 * Description:
 * %PD%
 * %PCMS_HEADER_SUBSTITUTION_END%
 * -----------------------------------------------------------------------------
 */

package com.serena.eclipse.dimensions.core.sbm;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.auth.AuthScheme;
import org.apache.commons.httpclient.auth.CredentialsNotAvailableException;
import org.apache.commons.httpclient.auth.CredentialsProvider;
import org.apache.commons.httpclient.auth.NTLMScheme;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.serena.eclipse.dimensions.core.DMPlugin;
import com.serena.eclipse.dimensions.core.DimensionsConnectionDetailsEx;
import com.serena.eclipse.dimensions.core.IUserAuthenticator;
import com.serena.eclipse.dimensions.core.util.Utils;

/**
 * Uses Apache's HttpClient library.
 *
 * @author V.Grishchenko
 */
public class ApacheHttpClientManager extends HTTPManager {

    private class CredentialsProviderAdapter implements CredentialsProvider {
        private int authAttempt = 0;

        @Override
        public Credentials getCredentials(AuthScheme scheme, String host, int port, boolean proxy)
                throws CredentialsNotAvailableException {
            if (scheme == null) {
                throw new CredentialsNotAvailableException("No authentication scheme provided");
            }

            authAttempt++;

            if (authAttempt > 3) {
                throw new CredentialsNotAvailableException("Max number of login attempts exceeded");
            }

            // see if have authenticator
            IUserAuthenticator userAuthenticator = DMPlugin.getDefault().getPluggedInAuthenticator();
            if (userAuthenticator == null) {
                throw new CredentialsNotAvailableException("User authenticator is unavailable");
            }

            getConnection().getDetails();
            boolean ntlm = scheme instanceof NTLMScheme;
            int reqdCredentials = ChallengeDetails.USERNAME | ChallengeDetails.PASSWORD;
            if (ntlm) {
                reqdCredentials |= ChallengeDetails.DOMAIN;
            }
            new ChallengeDetails(reqdCredentials, host, port, proxy ? ChallengeDetails.PROXY : ChallengeDetails.SERVER,
                    scheme.getRealm(), scheme.getSchemeName());

            throw new CredentialsNotAvailableException("Login cancelled by user");
        }

    }

    public ApacheHttpClientManager(DimensionsConnectionDetailsEx connection) {
        super(connection);
    }

    @Override
    protected InputStream getGETInputStream(String url, IProgressMonitor monitor) throws SBMException {
        monitor = Utils.monitorFor(monitor);
        HttpClient client = new HttpClient();
        //String urlStr = request + "&" + getCredentials(true); //$NON-NLS-1$
        GetMethod method = new GetMethod(url);
        method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler(3, false));
        String userAgent = "Mozilla/5.0";//$NON-NLS-1$
        method.getParams().setParameter(HttpMethodParams.USER_AGENT, userAgent);
        method.setFollowRedirects(true);
        method.getParams().setParameter(CredentialsProvider.PROVIDER, new CredentialsProviderAdapter());
        method.setDoAuthentication(true);
        try {
            int respCode = client.executeMethod(method);
            if (respCode == HttpStatus.SC_OK) {
                return asTempFileStream(method.getResponseBodyAsStream());// new ByteArrayInputStream(method.getResponseBody());
            }
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, "Non-OK HTTP STATUS " + respCode, null));
        } catch (IOException e) {
            throw new SBMException(new Status(IStatus.ERROR, DMPlugin.ID, 0, "Error executing HTTP request", e));
        } finally {
            method.releaseConnection();
        }
    }

    @Override
    protected InputStream getPOSTInputStream(String url, String body, IProgressMonitor monitor) throws SBMException {
        return null;
    }

    @Override
    protected InputStreamHelper getAssociateHelper(String associateRequest) {
        return null;
    }

}

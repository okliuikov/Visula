package com.microfocus.common.plugin.rest;

import com.microfocus.common.plugin.request.Request;
import org.junit.Assert;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class JsonRequestParserTest {
    JsonRequestParser parser = new DmJsonRequestParser();

    @Test
    public void readJsonTest() {
        String jsonAnswer = "{\"requests\":[{\"uid\":51629680,\"name\":\"DMPROD_ECR_61804\",\"type\":\"ECR\"," +
                "\"title\":\"[IntelliJ] Rich request picker UI\",\"status\":\"ASSIGNED\"},{\"uid\":51629343," +
                "\"name\":\"DMPROD_ECR_61798\",\"type\":\"ECR\",\"title\":\"[IntelliJ] Picking a request during commit\"," +
                "\"status\":\"CODE & UNIT TEST\"}]}";
        InputStream targetStream = new ByteArrayInputStream(jsonAnswer.getBytes());
        ArrayList<Request> requests = parser.readJson(targetStream);
        Assert.assertEquals(2, requests.size());
        Assert.assertEquals("DMPROD_ECR_61798", requests.get(1).getName());
    }

    @Test
    public void readNofFullJsonTest() {
        String jsonAnswer = "{\"requests\":[{\"uid\":51629680,\"name\":\"DMPROD_ECR_61804\",\"type\":\"ECR\"," +
                "\"title\":\"[IntelliJ] Rich request picker UI\"},{\"uid\":51629343," +
                "\"name\":\"DMPROD_ECR_61798\",\"title\":\"[IntelliJ] Picking a request during commit\"," +
                "\"status\":\"CODE & UNIT TEST\"}]}";
        InputStream targetStream = new ByteArrayInputStream(jsonAnswer.getBytes());
        ArrayList<Request> requests = parser.readJson(targetStream);
        Assert.assertEquals(2, requests.size());
        Assert.assertEquals("DMPROD_ECR_61798", requests.get(1).getName());
    }

    @Test
    public void readWrongNameJsonTest() {
        String jsonAnswer = "{\"requests\":[{\"uid\":51629680,\"name\":\"DMPROD_ECR_61804\",\"type\":\"ECR\"," +
                "\"title\":\"[IntelliJ] Rich request picker UI\",\"statuses\":\"ASSIGNED\"},{\"uid\":51629343," +
                "\"name\":\"DMPROD_ECR_61798\",\"type1\":\"ECR\",\"title\":\"[IntelliJ] Picking a request during commit\"," +
                "\"status\":\"CODE & UNIT TEST\"}]}";
        InputStream targetStream = new ByteArrayInputStream(jsonAnswer.getBytes());
        ArrayList<Request> requests = parser.readJson(targetStream);
        Assert.assertEquals(2, requests.size());
        Assert.assertEquals("DMPROD_ECR_61798", requests.get(1).getName());
    }

}
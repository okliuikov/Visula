package com.microfocus.common.plugin.request;

import java.util.HashMap;

public class RequestConstants {
    public enum Mode {
        USER_INBOX
    }

    public static final String UID_FIELD = "uid";
    public static final String NAME_FIELD = "name";
    public static final String TYPE_FIELD = "type";
    public static final String TITLE_FIELD = "title";
    public static final String STATUS_FIELD = "status";

    public static final String USER_INBOX_URL_PATH = "/dmrestservices/users/{username}/requests";

    public static final String LOADING_MESSAGE = "<Loading...>";
    public static final String FAILED_INBOX_MESSAGE = "<Failed to read inbox requests>";
    public static final String FAILED_LOGIN_INBOX_MESSAGE = "<Could not login to Dimensions server>";
    public static final String EMPTY_INBOX_MESSAGE = "<Request inbox is empty>";

    public static final HashMap<Mode, String> URL_PATHES = new HashMap<Mode, String>() {{
        put(Mode.USER_INBOX, USER_INBOX_URL_PATH);
    }};
}

package com.microfocus.common.plugin.request;

public class Request {

    private Long uid;
    private String name;
    private String type;
    private String title;
    private String status;

    public Request(Long uid) {
        this.uid = uid;
        this.name = "";
        this.title = "";
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public Long getUid() {
        return uid;
    }

    public String getStatus() {
        return status;
    }

    public String getType() {
        return type;
    }

    public String getTitle() {
        return title;
    }

    public String toFullString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Request: \n");
        stringBuilder.append("\tuid = ").append(uid).append("\n");
        stringBuilder.append("\tname = ").append(name).append("\n");
        stringBuilder.append("\ttype = ").append(type).append("\n");
        stringBuilder.append("\ttitle = ").append(title).append("\n");
        stringBuilder.append("\tstatus = ").append(status);
        return stringBuilder.toString();
    }

    @Override
    public String toString() {
        String out = name + " " + title;
        if(out.length() > 46){
            return (name + " " + title).substring(0,46);
        }
        return out;
    }

}

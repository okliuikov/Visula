package com.microfocus.common.plugin.rest;

import com.google.gson.stream.JsonReader;
import com.microfocus.common.plugin.request.Request;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static com.microfocus.common.plugin.request.RequestConstants.*;


public class DmJsonRequestParser implements JsonRequestParser {
    public ArrayList<Request> readJson(InputStream inputStream) {
        ArrayList<Request> requests = null;
        JsonReader reader = new JsonReader(new InputStreamReader(inputStream));
        try {
            if (reader.hasNext()) {
                reader.beginObject();
                if (reader.nextName().equals("requests")) {
                    requests = readRequestList(reader);
                }
                reader.endObject();
            }
        } catch (IOException e) {

        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return requests;
    }

    public ArrayList<Request> readRequestList(JsonReader reader) throws IOException {
        ArrayList<Request> requests = new ArrayList<>();
        reader.beginArray();
        while (reader.hasNext()) {
            requests.add(readRequest(reader));
        }
        reader.endArray();
        return requests;
    }

    public Request readRequest(JsonReader reader) throws IOException {
        Request request;
        reader.beginObject();
        if (reader.nextName().equals(UID_FIELD)) {
            request = new Request(reader.nextLong());
            while (reader.hasNext()) {
                switch (reader.nextName()) {
                    case NAME_FIELD:
                        request.setName(reader.nextString());
                        break;
                    case TYPE_FIELD:
                        request.setType(reader.nextString());
                        break;
                    case TITLE_FIELD:
                        request.setTitle(reader.nextString());
                        break;
                    case STATUS_FIELD:
                        request.setStatus(reader.nextString());
                        break;
                    default:
                        reader.skipValue();
                        break;
                }
            }
        } else {
            return null;
        }
        reader.endObject();
        return request;
    }

}

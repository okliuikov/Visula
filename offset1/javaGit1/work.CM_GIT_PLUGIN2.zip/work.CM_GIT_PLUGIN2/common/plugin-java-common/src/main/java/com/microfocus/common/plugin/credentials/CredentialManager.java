package com.microfocus.common.plugin.credentials;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * @author Rakovets Yurii
 * class for handle with credential
 * http://orl-dev-cm64prd:8080/pulse/scm.html#/suites/68787/products/68789/streams/22452582/browse?path=%2FVisualStudio%2FDimensions.RestApi%2FRequests.cs&tab=content
 */

public class CredentialManager {
    public Credential getCredential(String host) {
        final String param = "protocol=%s\nhost=%s\nquit=true\n\n";
        final String userParam = "username=";
        final String passParam = "password=";
        String username = "";
        String password = "";

        ProcessBuilder pb = new ProcessBuilder("git", "credential", "fill");
        try {
            Process p = pb.start();
            OutputStreamWriter osw = new OutputStreamWriter(p.getOutputStream());
            osw.write(String.format(param, "dimensions", host));
            osw.close();

            new Thread(() -> {
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                    String s;
                    while ((s = br.readLine()) != null) {
                        // git sends "Logon failed" to stderr if user presses Cancel
                        // then it waits for username and password from stdin
                        // we don't want to this to happen
                        if (!s.contains("told us to quit")) {
                            System.out.print(s);
                            System.out.print("\n");
                        } else {
                            p.destroyForcibly();
                            break;
                        }
                    }
                } catch (IOException ignored) {
                }
            }).start();

            if (p.waitFor() == 0) {
                BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String s;
                while ((s = input.readLine()) != null) {
                    if (s.startsWith(userParam)) {
                        username = s.substring(userParam.length());
                    }
                    if (s.startsWith(passParam)) {
                        password = s.substring(passParam.length());
                    }
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        return new Credential(username, password);
    }
}

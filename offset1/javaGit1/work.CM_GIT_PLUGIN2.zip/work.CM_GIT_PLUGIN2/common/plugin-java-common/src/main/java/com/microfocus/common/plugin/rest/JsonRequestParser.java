package com.microfocus.common.plugin.rest;

import com.microfocus.common.plugin.request.Request;

import java.io.InputStream;
import java.util.ArrayList;

public interface JsonRequestParser {
    ArrayList<Request> readJson(InputStream inputStream);
}

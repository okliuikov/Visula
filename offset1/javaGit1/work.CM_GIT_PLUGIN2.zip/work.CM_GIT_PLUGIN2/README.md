Git Client Plugins
------------------------
This repository contains sources for Dimensions CM Git Client plugins for IntelliJ IDEA, Visual Studio, VS Code and Eclipse.

See appropriate readme files for more details.

Build and Deployment
------------------------
To build all sources in Release configuration and  copy output to *out* dir, run:

    buildAll
    collectAll

License
------------------------
� Copyright 2019 Micro Focus or one of its affiliates.

See license.txt for complete license text.
﻿using System;
using Autofac;

namespace Dimensions.Containers
{
    public class ServiceContainer
    {
        private static IContainer _instance;
        private static ContainerBuilder _builder;

        public static IContainer Instance
        {
            get
            {
                if (_instance == null)
                {
                    if (_builder == null)
                        throw new InvalidOperationException("Service container is not initialized");
                    _instance = _builder.Build();
                }
                return _instance;
            }
        }

        public static bool IsInitialized => _builder != null;

        public static void Initialize(ContainerBuilder builder)
        {
            if (_builder != null)
                throw new InvalidOperationException("Attempt to overwrite container registration");
            _builder = builder;
        }
    }
}

# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

## [0.2.1]
### Added 
 - Request picker control with search
 - Use Git Credential Manager for storing and retreiving user credentials
### Fixed 
 - Incorrect credentials won't be re-used for querying Dimensions requests

## [0.2] - 2019-03-20
### Added
 - Check Dimensions Plugin in the Connect page

## [0.1] - 2019-03-06
### Added
 - Saving entered credentials in the Local Computer storage
 - Reading credentials from Windows Credential Manager
 - Radio buttons to change between inbox/all requests
 - Login dialog
 - Using Dimensions REST to get list of inbox requests
 - Requests section visible only for repositories cloned from Dimensions
 - Requests combo shows request id, title and status
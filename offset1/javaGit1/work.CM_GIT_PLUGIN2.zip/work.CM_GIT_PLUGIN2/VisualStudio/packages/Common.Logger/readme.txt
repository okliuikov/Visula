Dimensions loggin interface.
This version of the binary built 2019-03-07 from CM_OSPREY code as Release - Any CPU.
Dependencies:
 - log4net 1.2.10

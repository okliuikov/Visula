nuget.exe 4.9.3
See: https://www.nuget.org/downloads
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using Autofac.Extras.Moq;
using Dimensions.Containers;

namespace GitClientTests
{
    public class TestBase
    {
        public void InitContainer()
        {
            ContainerBuilder builder = new ContainerBuilder();
            InitContainer(builder);
        }

        public static void InitContainer(ContainerBuilder builder)
        {
            ServiceContainer.Initialize(builder);
        }
        protected static AutoMock Mocks => _mocks;
        private static readonly AutoMock _mocks = AutoMock.GetLoose();
    }
}

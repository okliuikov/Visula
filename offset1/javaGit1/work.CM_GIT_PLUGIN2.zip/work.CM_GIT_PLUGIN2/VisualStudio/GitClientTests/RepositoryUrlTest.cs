﻿using Autofac;
using GitClient;
using GitClient.Model;
using GitClient.Services;
using GitClient.ViewModel;
using Microsoft.VisualStudio.TeamFoundation.Git.Extensibility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Serena.Common.Util.Logger;
using System;
using System.Collections.Generic;
using System.Threading;

namespace GitClientTests
{
    [TestClass]
    public class RepositoryUrlTest : TestBase
    {
        [ClassInitialize]
        public static void Init(TestContext context)
        {
            var credential = Mocks.Mock<ICredentialManager>();
            var dialogService = Mocks.Mock<IDialogService>();
            var logger = Mocks.Mock<ISimpleLogger>();
            var requestStorage = Mocks.Mock<IRequestStorage>();
            var gitService = Mocks.Mock<IGitService>();
            var requestsLoader = Mocks.Mock<IRequestsLoader>();
            _builder.RegisterInstance(dialogService.Object).As<IDialogService>();
            _builder.RegisterInstance(logger.Object).As<ISimpleLogger>();
            _builder.RegisterInstance(requestStorage.Object).As<IRequestStorage>();
            _builder.RegisterInstance(Mocks.Mock<IServiceProvider>().Object).As<IServiceProvider>();
            _builder.RegisterInstance(credential.Object).As<ICredentialManager>();
            _builder.RegisterInstance(gitService.Object).As<IGitService>();
            _builder.RegisterType<RequestPickerViewModel>().AsSelf();
            _builder.RegisterType<RequestItemsLoader>().AsSelf();
            _builder.RegisterInstance(requestsLoader.Object).As<IRequestsLoader>();
            InitContainer(_builder);
        }

        [TestMethod]
        public void TestDimensionsUrl()
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());
            string dimRepoUrl = "dimensions://pol2k16/cm_typical@dim14/qlarius/java_brancha_str/";
            var repositories = new List<GitRepositoryInfo>()
            {
                new GitRepositoryInfo { RepositoryPath = dimRepoUrl }
            };

            var gitExt = Mocks.Mock<IGitExt>();
            gitExt.Setup(x => x.ActiveRepositories).Returns(repositories);
            var gitService = Mocks.Mock<IGitService>();
            gitService.Setup(x => x.GetRemoteUrl(null, "origin")).Returns(dimRepoUrl);

            Mocks.Mock<IServiceProvider>().Setup(x => x.GetService(typeof(IGitExt))).Returns(gitExt.Object);
            Mocks.Mock<IServiceProvider>().Setup(x => x.GetService(typeof(IGitService))).Returns(gitService.Object);

            RequestsSection requests = new RequestsSection();
            requests.Initialize(Mocks.Mock<IServiceProvider>().Object, null);
            Assert.IsTrue(requests.IsVisible);
            Mocks.Mock<IServiceProvider>().Verify();
        }

        [TestMethod]
        public void TestGitUrl()
        {
            string url = "https://github.com/github/VisualStudio.git";
            var repositories = new List<GitRepositoryInfo>()
            {
                new GitRepositoryInfo { RepositoryPath = url }
            };

            var gitExt = Mocks.Mock<IGitExt>();
            gitExt.Setup(x => x.ActiveRepositories).Returns(repositories);
            var gitService = Mocks.Mock<IGitService>();
            gitService.Setup(x => x.GetRemoteUrl(null, "origin")).Returns(url);

            Mocks.Mock<IServiceProvider>().Setup(x => x.GetService(typeof(IGitExt))).Returns(gitExt.Object);
            Mocks.Mock<IServiceProvider>().Setup(x => x.GetService(typeof(IGitService))).Returns(gitService.Object);

            RequestsSection requests = new RequestsSection();
            requests.Initialize(Mocks.Mock<IServiceProvider>().Object, null);
            Assert.IsFalse(requests.IsVisible);
            Mocks.Mock<IServiceProvider>().Verify();
        }
        static ContainerBuilder _builder = new ContainerBuilder();
    }
}

﻿using Microsoft.VisualStudio.TeamFoundation.Git.Extensibility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitClientTests
{
    class GitRepositoryInfo : IGitRepositoryInfo
    {
        public string RepositoryPath { get; set; }

        public IGitBranchInfo CurrentBranch => null;
    }
}

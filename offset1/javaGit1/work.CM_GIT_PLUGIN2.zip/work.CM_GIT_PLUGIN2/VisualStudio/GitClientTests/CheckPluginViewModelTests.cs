﻿using Dimensions.Model;
using GitClient.ViewModel;
using Microsoft.TeamFoundation.Controls;
using Microsoft.TeamFoundation.MVVM;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Serena.Common.Util.Logger;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace GitClientTests
{
    [TestClass]
    public class CheckPluginViewModelTests : TestBase
    {
        private const string GitHubUrl = "https://github.com/github/VisualStudio.git";
        private const string DimRepoUrl = "dimensions://pol2k16/cm_typical@dim14/qlarius/java_brancha_str/";
        private Guid owner = Guid.NewGuid();
        private Mock<ISimpleLogger> logger = new Mock<ISimpleLogger>();
        private Mock<ITeamExplorer> teamExplorer = new Mock<ITeamExplorer>();
        private Mock<IDimensionsGitPluginChecker> checker = new Mock<IDimensionsGitPluginChecker>();

        [TestMethod]
        public void TestCheckPluginForGitUrl()
        {
            teamExplorer.Setup(x => x.IsNotificationVisible(owner)).Returns(false);
            teamExplorer.Setup(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
                null, owner));
            checker.Setup(x => x.Exists());
            var checkPlugin = new CheckPluginViewModel(teamExplorer.Object, checker.Object, logger.Object)
            {
                OwnerId = owner
            };
            checkPlugin.HandledCheckPluginFor(GitHubUrl);
            checker.Verify(m => m.Exists(), Times.Never);
            teamExplorer.Verify(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
              null, owner), Times.Never);
        }

        [TestMethod]

        public void TestCheckNonExistingPluginForValidDimensionsUrl()
        {
            teamExplorer.Setup(x => x.IsNotificationVisible(owner)).Returns(false);
            var openLinkCommand = new RelayCommand(() => { });
            teamExplorer.Setup(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
                openLinkCommand, owner));
            checker.Setup(x => x.Exists()).Returns(false);
            var checkPlugin = new CheckPluginViewModel(teamExplorer.Object, checker.Object, logger.Object)
            {
                OwnerId = owner,
                OpenLinkCommand = openLinkCommand
            };
            checkPlugin.HandledCheckPluginFor(DimRepoUrl);
            teamExplorer.Verify(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
                openLinkCommand, owner));
            checker.Verify(m => m.Exists());
        }

        [TestMethod]
        public void TestCheckNonExistingPluginForValidDimensionsUrlWithArg()
        {
            teamExplorer.Setup(x => x.IsNotificationVisible(owner)).Returns(false);
            var openLinkCommand = new RelayCommand(() => { });
            teamExplorer.Setup(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
                openLinkCommand, owner));
            checker.Setup(x => x.Exists()).Returns(false);
            var checkPlugin = new CheckPluginViewModel(teamExplorer.Object, checker.Object, logger.Object)
            {
                OwnerId = owner,
                OpenLinkCommand = openLinkCommand
            };
            var handled = checkPlugin.HandledCheckPluginFor(DimRepoUrl);
            teamExplorer.Verify(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
                openLinkCommand, owner));
            checker.Verify(m => m.Exists());
            Assert.IsTrue(handled);
        }


        [TestMethod]
        public void TestCheckExistingPluginForValidDimensionsUrl()
        {
            teamExplorer.Setup(x => x.IsNotificationVisible(owner)).Returns(true);
            teamExplorer.Setup(m => m.HideNotification(owner));
            checker.Setup(x => x.Exists()).Returns(true);
            var checkPlugin = new CheckPluginViewModel(teamExplorer.Object, checker.Object, logger.Object)
            {
                OwnerId = owner
            };
            checkPlugin.HandledCheckPluginFor(DimRepoUrl);
            teamExplorer.Verify(m => m.HideNotification(owner));
            checker.Verify(m => m.Exists());
        }

        [TestMethod]
        public async Task TestCheckNonExistingPluginAsync()
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());
            teamExplorer.Setup(x => x.IsNotificationVisible(owner)).Returns(false);
            var page = new Mock<ITeamExplorerPage>();
            page.Setup(m => m.PageContent).Returns(new Object());
            teamExplorer.Setup(x => x.CurrentPage).Returns(page.Object);
            var openLinkCommand = new RelayCommand(() => { });
            teamExplorer.Setup(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
                openLinkCommand, owner));
            checker.Setup(x => x.Exists()).Returns(false);
            var checkPlugin = new CheckPluginViewModel(teamExplorer.Object, checker.Object, logger.Object)
            {
                OwnerId = owner,
                OpenLinkCommand = openLinkCommand
            };
            checkPlugin.CheckPlugin();
            await Task.Delay(5);
            teamExplorer.Verify(m => m.ShowNotification(It.IsAny<string>(), It.IsAny<NotificationType>(), It.IsAny<NotificationFlags>(),
                openLinkCommand, owner));
            checker.Verify(m => m.Exists());
        }

        [TestMethod]
        public async Task TestCheckExistingPluginAsync()
        {
            SynchronizationContext.SetSynchronizationContext(new SynchronizationContext());
            teamExplorer.Setup(x => x.IsNotificationVisible(owner)).Returns(true);
            var page = new Mock<ITeamExplorerPage>();
            page.Setup(m => m.PageContent).Returns(new object());
            teamExplorer.Setup(x => x.CurrentPage).Returns(page.Object);
            teamExplorer.Setup(m => m.HideNotification(owner));
            checker.Setup(x => x.Exists()).Returns(true);
            var checkPlugin = new CheckPluginViewModel(teamExplorer.Object, checker.Object, logger.Object)
            {
                OwnerId = owner
            };
            checkPlugin.CheckPlugin();
            await Task.Delay(5);
            teamExplorer.Verify(m => m.HideNotification(owner));
            checker.Verify(m => m.Exists());
        }
    }
}

# Dependencies

|Module      | Version   | License | License Link |
|------------|-----------|---------|--------------|
|Autofac     | 4.8.1     | MIT   | https://github.com/autofac/Autofac/blob/develop/LICENSE        |
|log4net     | 1.2.10    | MIT   | https://github.com/eamodio/vscode-gitlens/blob/master/LICENSE  |
|LibGit2Sharp| 0.25.2    | MIT   | https://github.com/libgit2/libgit2sharp/blob/master/LICENSE.md |
|LibGit2Sharp.NativeBinaries | 1.0.235 | GPL + Linking exception| https://raw.githubusercontent.com/libgit2/libgit2/master/COPYING |
|Font FontAwensome| 4.3.0 2015| SIL OFL 1.1 | https://fontawesome.com/license/free |
|Caliburn.Micro.Core| 3.1.0 | MIT| https://raw.githubusercontent.com/Caliburn-Micro/Caliburn.Micro/master/License.txt
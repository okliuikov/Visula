Dimensions CM Git Client Plugin
=========================

The purpose of the project is to let users working with Git in their favorite IDE store source code on Dimensions server.

The current solution implements Visual Studio Team Explorer extension to let user pick Dimensions request on commit.

Automated Installation
-------------------------

1. Run Dimensions Git Client.exe.
2. Follow VSIX installer instructions to install Visual Studio extension.
3. Edit remote helper configuration file, set SCM_JRE_HOME variable to your JRE or JDK 8 location.

Manual Installation
-------------------------

*First install Dimensions Remote Helper:*

1.	Make sure you have Visual Studio 2017 installed
2.	Make sure you have a JRE or JDK 8 installed
3.	Create the folder "C:\Program Files (x86)\Micro Focus\Git"
4.	Copy the git-remote-scm.jar into that new folder
5.	Find your Git libexec folder, this seems to be c:\Program Files (x86)\Microsoft Visual Studio\2017\Professional\Common7\IDE\CommonExtensions\Microsoft\TeamFoundation\Team Explorer\Git\mingw32\libexec\git-core\, 
    one way to find it is to search for 'git-remote-https' and it should be in your libexec\git-core folder.
6.	Copy the git-remote-dimensions shell script into the libexec\git-core folder
7.	Edit the git-remote-dimensions shell script:
a.	Make sure GIT_CONNECTOR_HOME is set to where you copied the JAR file to (e.g. C:\Program Files\Micro Focus\Git)
b.	Make sure SCM_JRE_HOME is set to your Java 8 JRE/JDK home

*Then install VSIX package into Visual Studio*

Double-click DimensionsGitClient.vsix to install Visual Studio extension.

Usage
----------------
You should be able to clone source code from Dimensions server using "Team Explorer - Connect".

Dimensions server URL of a Git repo should look like : dimensions://mycmserver/cmdatabase@dsn/product/stream/folder

If Dimensions Git client isn't installed, after invoking clone operation from Dimensions server you will see warning notification about it with download link.

For example:

Using Visual Studio go to **Team > Manage Connections...**

Under **Local Git Repositories** press **Clone** and paste repository URL

	dimensions://stl-ta-vcw8-08/cm_typical@dim12/qlarius/mainline_vs_str

Now press **Clone** button to clone source code from Dimensions server to your local folder.

Open solution from a cloned repository, make some changes. In Solution Explorer right-click, press **Commit**.

Troubleshooting
----------------

**Problem:** Clone fails with a message: 
*Error encountered while cloning the remote repository: Git failed with a fatal error.*

**Cause:** Remote helper not installed or throws an error.

**Solution:** Check remote helper logs; check if remote helper components are installed; check if Java 8 is installed; set Java home dir in the remote helper config file.

**Problem:** Cannot find Visual Studio extension

**Solution:** Go to **Tools > Extensions and Updates...** Look for *Dimensions CM Git Client*.

Remote Helper logs locaton:

	C:\Users\\[username]\AppData\Roaming\Borland\StarTeam

Credential Manager
-------------------------
Credentials that user enters to access Git in Visual Studio are saved in a secure storage managed by Windows.
This storage can be accessed via Credential Manager (Control Panel > User Accounts > Credential Manager).
For example, after cloning source code from Dimensions credentials will be stored as

    git:dimensions://[server]:[port]

Git client will use stored credentials that match current repository.

See [How the Git Credential Managers works](https://github.com/Microsoft/Git-Credential-Manager-for-Windows/wiki/How-the-Git-Credential-Managers-works)
for more details.

Build and Unit Tests
-------------------------
To build sources and run unit tests execute build.bat [Release|Debug]. For example:

    build Release

or just

    build

This will run build and unit tests in command line. 
Unit tests are developed using MSTest framework. Test results may be found in TestResults\VsTestResults.trx.

Deployment
-------------------------
Deployable artifact for this plugin is GitClient.VSIX\bin\Release\Dimensions.GitClient.vsix

Contributors
-------------------------
Aleksey Yushko (mailto:aleksey.yushko@microfocus.com)

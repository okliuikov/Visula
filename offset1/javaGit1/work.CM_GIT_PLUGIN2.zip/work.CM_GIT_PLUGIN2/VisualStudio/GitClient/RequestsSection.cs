﻿using Autofac;
using Dimensions.Common.Extensions;
using Dimensions.Containers;
using Dimensions.Utility;
using GitClient.Services;
using GitClient.UI;
using GitClient.ViewModel;
using Microsoft.TeamFoundation.Controls;
using Microsoft.TeamFoundation.Git.Controls.Extensibility;
using Microsoft.VisualStudio.TeamFoundation.Git.Extensibility;
using Serena.Common.Util.Logger;
using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;
using System.Windows.Controls;

namespace GitClient
{
    [TeamExplorerSection(DimensionsChangesSectionId, TeamExplorerPageIds.GitChanges, 5)]

    public class RequestsSection : SectionBase
    {
        public const string DimensionsChangesSectionId = "FA445107-0A99-4969-BB1F-A4C3BA6C4276";
        public override string Title => "Dimensions Requests";

        private UserControl _view;
        private IServiceProvider _serviceProvider;
        private ISimpleLogger _logger;

        [ImportingConstructor]
        public RequestsSection()
        {
        }

        public override void Initialize(object sender, SectionInitializeEventArgs e)
        {
            InitializeContainer(e.ServiceProvider);
            Initialize(e.ServiceProvider, e.Context);
        }
        
        public void Initialize(IServiceProvider serviceProvider, object context)
        {
            _serviceProvider = serviceProvider;
            _logger = ServiceContainer.Instance.Resolve<ISimpleLogger>();
            var viewModel = (RequestPickerViewModel)context;
            if (viewModel == null)
            {
                viewModel = ServiceContainer.Instance.Resolve<RequestPickerViewModel>();
                viewModel.RequestItemsLoader.ErrorMessageHandler += OnErrorMessage;
            }
            try
            {
                var repositoryUri = GetRepoUrl();
                viewModel.RequestItemsLoader.RepositoryUri = repositoryUri;
                IsVisible = DimensionsGitHelper.IsDimensionsUrl(repositoryUri.AbsoluteUri);
            }
            catch(UriFormatException)
            {
                _logger.Error("Could not determine repository URL. Dimensions Requests section will be hidden.");
            }
            if (IsVisible)
            {
                viewModel.Initialize();
                viewModel.PropertyChanged += OnRequestPropertyChanged;
                _view = new RequestsView() { DataContext = viewModel };
                SectionContent = _view;
            }
        }


        private void OnRequestPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(RequestPickerViewModel.SelectedRequest))
            {
                RequestPickerViewModel vm = sender as RequestPickerViewModel;
                var pageChanges = _serviceProvider.GetService<IChangesExt>();
                if (pageChanges != null)
                {
                    RequestFormatter message = new RequestFormatter(pageChanges.CommitMessage);
                    var selectedRequest = vm.SelectedRequest?.Id ?? string.Empty;
                    message.AppendRequest(selectedRequest);
                    SetComment(pageChanges, message.ToString());
                }
            }
        }

        protected void SetComment(IChangesExt pageChanges, string message)
        {
            var field = pageChanges.GetFieldValue<object>("m_gitPendingChangesModel");
            field?.SetPropertyValue("Comment", message);
        }

        private Uri GetRepoUrl()
        {
            var gitExt = _serviceProvider.GetService<IGitExt>();
            string path = gitExt.ActiveRepositories.FirstOrDefault()?.RepositoryPath;
            if (path == null)
                return null;
            var gitService = _serviceProvider.GetService<IGitService>();            
            var repository = gitService.GetRepository(path);
            string url = gitService.GetRemoteUrl(repository);
            if (url == null)
                throw new UriFormatException("Could not read repository url.");
            string user = gitService.GetUserName(repository);
            UriBuilder builder = new UriBuilder(url);
            if (!String.IsNullOrWhiteSpace(user) && !user.Contains(' '))
            {
                builder.UserName = user.ToLower();
            }
            else
            {
                _logger.Info(String.IsNullOrWhiteSpace(user) ? "Could not determine Dimensions user name." :
                    "User name does not correspond to a valid Dimensions user. Skipping.");
            }
            return builder.Uri;
        }

        public override void SaveContext(object sender, SectionSaveContextEventArgs e)
        {
            var viewModel = _view.DataContext as RequestPickerViewModel;
            viewModel.RequestItemsLoader.ErrorMessageHandler -= OnErrorMessage;
            viewModel.PropertyChanged -= OnRequestPropertyChanged;
            e.Context = viewModel;
        }

        public override void Loaded(object sender, SectionLoadedEventArgs e)
        {
        }

        public override void Refresh()
        {
            if (IsVisible)
            {
                var viewModel = _view.DataContext as RequestPickerViewModel;
                viewModel.Initialize();
            }
        }

        private void OnErrorMessage(object sender, ErrorMessageArgs e)
        {
            ShowWarning(e.Exception, e.Message);
        }

        private void ShowWarning(Exception ex, string message)
        {
            var teamExplorer = _serviceProvider.GetService<ITeamExplorer>();
            if (teamExplorer != null)
            {
                teamExplorer.ShowNotification(message, NotificationType.Warning, NotificationFlags.None,
                    null, new Guid(DimensionsChangesSectionId));
            }
            _logger.Warn(ex);
        }

        public override void Cancel()
        {
        }

        public override void Dispose()
        {
        }

        public override object GetExtensibilityService(Type serviceType)
        {
            if (serviceType == typeof(IGitService))
                return new GitService();
            return null;
        }
    }
}

﻿using Microsoft.TeamFoundation.Controls;
using System;
using System.ComponentModel.Composition;
using GitClient.ViewModel;
using Autofac;
using Dimensions.Containers;
using Microsoft.VisualStudio.Shell.Interop;

namespace GitClient
{
    [TeamExplorerSection(DimensionsConnectSectionId, TeamExplorerPageIds.Connect, 11)]
    class DimensionsConnectSection : SectionBase
    {
        public const string DimensionsConnectSectionId = "B0339FFF-6F00-4947-8146-F8B14A3931F6";
        public override string Title => "Dimensions CM";
        private DimensionCloneValidatorViewModel _cloneValidator;

        [ImportingConstructor]
        DimensionsConnectSection()
        {
        }
        public override void Cancel()
        {
        }

        public override void Dispose()
        {
        }

        public override object GetExtensibilityService(Type serviceType)
        {
            return null;
        }

        public override void Initialize(object sender, SectionInitializeEventArgs e)
        {
            InitializeContainer(e.ServiceProvider);
            Initialize(e.ServiceProvider, e.Context);
        }

        private void Initialize(IServiceProvider serviceProvider, object context)
        {
            _cloneValidator = (DimensionCloneValidatorViewModel)context;
            if (_cloneValidator == null)
            {
                _cloneValidator = ServiceContainer.Instance.Resolve<DimensionCloneValidatorViewModel>();
                _cloneValidator.OwnerId = new Guid(DimensionsConnectSectionId);
            }
            
        }

        public override void Loaded(object sender, SectionLoadedEventArgs e)
        {
            _cloneValidator.Initialize();
        }

        public override void Refresh()
        {
        }

        public override void SaveContext(object sender, SectionSaveContextEventArgs e)
        {
            e.Context = _cloneValidator;
        }
    }
}

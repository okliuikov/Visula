﻿using Autofac;
using Dimensions.Containers;
using Dimensions.Model;
using GitClient.Model;
using GitClient.Services;
using GitClient.ViewModel;
using Microsoft.TeamFoundation.Controls;
using Serena.Common.Util.Logger;
using Serena.Logger;
using System;

namespace GitClient
{
    public abstract class SectionBase : PropertyChangedAware, ITeamExplorerSection
    {
        protected void InitializeContainer(IServiceProvider serviceProvider)
        {
            if (ServiceContainer.IsInitialized)
                return;
            ContainerBuilder builder = new ContainerBuilder();
            builder.RegisterType<DialogService>().As<IDialogService>();
            builder.RegisterType<SimpleLogger>().As<ISimpleLogger>();
            builder.RegisterType<RequestStorage>().As<IRequestStorage>();
            builder.RegisterType<CredentialManager>().AsSelf().As<ICredentialManager>();
            builder.RegisterType<DimensionCloneValidatorViewModel>().AsSelf();
            builder.RegisterType<DimensionsGitPluginChecker>().As<IDimensionsGitPluginChecker>();
            builder.RegisterInstance(serviceProvider).As<IServiceProvider>().ExternallyOwned();
            builder.RegisterType<GitService>().As<IGitService>();
            builder.RegisterType<RequestsLoader>().As<IRequestsLoader>();
            builder.RegisterType<RequestItemsLoader>().AsSelf();
            builder.RegisterType<RequestPickerViewModel>().AsSelf();
            ServiceContainer.Initialize(builder);
        }

        public abstract string Title { get; }
        public object SectionContent { get; set; }
        public bool IsVisible
        {
            get => _isVisible;

            set
            {
                _isVisible = value;
                OnPropertyChanged(nameof(IsVisible));
            }
        }
        public bool IsExpanded { get; set; } = true;
        public bool IsBusy { get; set; } = false;

        public abstract void Cancel();
        public abstract void Dispose();
        public abstract object GetExtensibilityService(Type serviceType);
        public abstract void Initialize(object sender, SectionInitializeEventArgs e);
        public abstract void Loaded(object sender, SectionLoadedEventArgs e);
        public abstract void Refresh();
        public abstract void SaveContext(object sender, SectionSaveContextEventArgs e);
        private bool _isVisible = false;
    }
}

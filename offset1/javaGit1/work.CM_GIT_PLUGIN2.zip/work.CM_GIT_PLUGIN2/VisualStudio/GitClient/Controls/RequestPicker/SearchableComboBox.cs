﻿using GitClient.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;

namespace GitClient.Controls.RequestPicker
{
    /// <summary>
    /// ATTENTION!!! In ItemTemplateSelector's DataTamplates don't use the controls, which can capture
    /// a mouse(like button etc). Because they can intercept a "mouse" capture from Popup and "break" the control's behaviour.
    /// </summary>
    [ContentProperty("ItemsSource")]
    [TemplatePart(Name = "PART_Container", Type = typeof(Grid)),
    TemplatePart(Name = "PART_Popup", Type = typeof(Popup)),
    TemplatePart(Name = "PART_Expander", Type = typeof(Button)),
    TemplatePart(Name = "PART_ListBox", Type = typeof(ListBox)),
    TemplatePart(Name = "PART_TextBox", Type = typeof(TextBox))]

    public class SearchableComboBox : ItemsControl, IPickerControl
    {
        //Maximal possible height of Popup
        //This value is very important for VisibleItemsMaxCount
        public readonly static double PopupMaxHeight = 1500;
        public event EventHandler<bool> IsExpandedChanged;
        public event EventHandler<KeyArgs> CommonPreviewKeyDown;
        public event EventHandler SearchTextChanged;
        public event EventHandler<ClickOnItemEventArgs> ClickOnItemEvent;
        public event EventHandler<UpdateItemsArgs> UpdateItems;
        public event EventHandler<SearchableComboBoxMode> ModeChanged;

        public SearchableComboBox()
            : base()
        {
            _keyHandlers.Add(Key.Home, KeyHomeHandler);
            _keyHandlers.Add(Key.End, KeyEndHandler);
            _keyHandlers.Add(Key.System, KeyAltHandler);
            _keyHandlers.Add(Key.Up, KeyUpHandler);
            _keyHandlers.Add(Key.Down, KeyDownHandler);
            _keyHandlers.Add(Key.Escape, KeyEscHandler);
            _keyHandlers.Add(Key.Tab, KeyTabHandler);
            _keyHandlers.Add(Key.Enter, KeyEnterHandler);
            _keyHandlers.Add(Key.PageUp, KeyPageUpHandler);
            _keyHandlers.Add(Key.PageDown, KeyPageDownHandler);
            DataContextChanged += SearchableComboBoxDataContextChanged;
        }

        private static void SearchableComboBoxDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (!(sender is SearchableComboBox searchableComboBox))
                return;
            if (e.OldValue is IPickerControlOwner oldValue)
                oldValue.PickerControl = null;
            if (e.NewValue is IPickerControlOwner newValue)
                newValue.PickerControl = searchableComboBox;
        }

        public bool IsOn
        {
            get { return _isOn; }
            set
            {
                _isOn = value;
                if (!value)
                    IsExpanded = false;

            }
        }
        public bool IsExpanded
        {
            get { return _isExpanded; }
            set
            {
                _isExpanded = value;
                _popup.IsOpen = IsExpanded;
                IsExpandedChanged?.Invoke(this, IsExpanded);
            }
        }

        static SearchableComboBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(SearchableComboBox), new FrameworkPropertyMetadata(typeof(SearchableComboBox)));
        }

        public static readonly DependencyProperty SearchTextBoxWatermarkProperty = DependencyProperty.Register("SearchTextBoxWatermark", typeof(string), typeof(SearchableComboBox));

        public static readonly DependencyProperty WorkModeProperty = DependencyProperty.Register("WorkMode", typeof(SearchableComboBoxMode), typeof(SearchableComboBox), new PropertyMetadata(SearchableComboBoxMode.Normal));

        public static readonly DependencyProperty SearchTextProperty = DependencyProperty.Register("SearchText", typeof(string), typeof(SearchableComboBox), new FrameworkPropertyMetadata(null));

        public static readonly DependencyProperty VisibleItemsMaxCountProperty = DependencyProperty.Register("VisibleItemsMaxCount", typeof(int), typeof(SearchableComboBox), new PropertyMetadata(12));


        public int VisibleItemsMaxCount
        {
            get { return (int)GetValue(VisibleItemsMaxCountProperty); }
            set { SetValue(VisibleItemsMaxCountProperty, value); }
        }

        public string SearchTextBoxWatermark
        {
            get { return (string)GetValue(SearchTextBoxWatermarkProperty); }
            set { SetValue(SearchTextBoxWatermarkProperty, value); }
        }

        public string SearchText
        {
            get { return (string)GetValue(SearchTextProperty); }
            set { SetValue(SearchTextProperty, value); }
        }

        public SearchableComboBoxMode WorkMode { get; set; }

        internal void RaiseClickOnItemEvent(RoutedEventArgs routedEventArgs, object selectedItem)
        {
            var eventArgs = new ClickOnItemEventArgs(routedEventArgs, selectedItem);
            ClickOnItemEvent?.Invoke(this, eventArgs);

            if (eventArgs.IsClosingPopup)
                IsExpanded = false;

            _textBox.Focus();
            if (eventArgs.IsSelectAllSearchText)
                _textBox.SelectAll();
        }

        internal void ExpanderClick()
        {
            if (!IsOn)
                return;
            _textBox.SelectAll();
            _textBox.Focus();
            OnModeChanged(SearchableComboBoxMode.Normal);
            if (!IsExpanded)
                OnUpdateVisualItems();
            else
                IsExpanded = false;
        }

        private void ExpanderClick(object sender, RoutedEventArgs e)
        {
            ExpanderClick();
        }

        private void OnModeChanged(SearchableComboBoxMode mode)
        {
            ModeChanged?.Invoke(this, mode);
            WorkMode = mode;
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            _expander = EnforceInstance<Button>("PART_Expander");
            _listBox = EnforceInstance<ListBox>("PART_ListBox");
            _popup = EnforceInstance<Popup>("PART_Popup");
            _textBox = EnforceInstance<TextBox>("PART_TextBox");
            InitializeVisualElementsContainer();
        }

        protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            _setKeyboardFocus = true;
            Keyboard.Focus(_textBox);
            base.OnGotKeyboardFocus(e);
        }

        protected override void OnLostKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            base.OnLostKeyboardFocus(e);
            if (!MouseInsideControl())
                IsExpanded = false;
        }

        private bool MouseInsideControl()
        {
            var mouseInsideControl = VisualTreeHelperEx.GetParentEx<ListBox>(Mouse.DirectlyOver) == _listBox;
            mouseInsideControl = mouseInsideControl || VisualTreeHelperEx.GetParentEx<SearchableComboBox>(Mouse.DirectlyOver) == this;
            return mouseInsideControl;
        }

        protected override void OnLostFocus(RoutedEventArgs e)
        {
            if (_setKeyboardFocus)
            {
                _setKeyboardFocus = false;
                e.Handled = true;
                return;
            }

            base.OnLostFocus(e);
        }


        //Get element from name. If it exist then element instance return, if not, new will be created
        T EnforceInstance<T>(string partName) where T : FrameworkElement, new()
        {
            T element = GetTemplateChild(partName) as T ?? new T();
            return element;
        }

        private void IsVisibleChangedEventHandler(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (IsExpanded && !((bool)e.NewValue))
                IsExpanded = false;
        }

        private void InitializeVisualElementsContainer()
        {
            _textBox.TextChanged += TextBoxTextChanged;
            _textBox.PreviewKeyDown += OnCommonPreviewKeyDown;
            _expander.Click += ExpanderClick;
            _popup.Opened += PopupOpened;
            _popup.Closed += PopupClosed;
            WorkMode = SearchableComboBoxMode.Normal;
            _listBox.PreviewMouseLeftButtonUp += ListBoxPreviewMouseLeftButtonUp;
            _listBox.ItemContainerGenerator.StatusChanged += ListBoxGeneratorStatusChanged;
            IsVisibleChanged += IsVisibleChangedEventHandler;
            IsOn = true;
            SizeChanged += OnSizeChanged;
        }

        private void OnSizeChanged(object sender, EventArgs e)
        {
            IsExpanded = false;
        }

        private void ListBoxGeneratorStatusChanged(object sender, EventArgs e)
        {
            if (_listBox.ItemContainerGenerator.Status != GeneratorStatus.ContainersGenerated)
                return;

            if (_virtualStackPanel == null)
                return;

            var newListBoxItems = _virtualStackPanel.Children.OfType<ListBoxItem>();
            foreach (var removingListBoxItem in _visibleListboxItems)
                removingListBoxItem.MouseEnter -= ListBoxItemMouseEnter;

            _visibleListboxItems.Clear();
            _visibleListboxItems.AddRange(newListBoxItems);

            foreach (var addingListBoxItem in _visibleListboxItems)
                addingListBoxItem.MouseEnter += ListBoxItemMouseEnter;
        }

        private void ListBoxItemMouseEnter(object sender, MouseEventArgs e)
        {
            if (_isSyncwithIsMouseOver)
            {
                var listBoxItem = sender as ListBoxItem;
                if (listBoxItem != null)
                {
                    listBoxItem.IsSelected = true;
                    _textBox.Focus();
                }
            }
        }

        private void ListBoxPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Released)
                return;
            var listBoxHasUiElement = VisualTreeHelperEx.GetParentEx<ListBox>(Mouse.DirectlyOver) == _listBox;
            var source = e.OriginalSource;
            var listBoxItem = VisualTreeHelperEx.GetParentEx<ListBoxItem>(source);

            if (listBoxHasUiElement && listBoxItem != null)
            {
                var viewModel = listBoxItem.DataContext;

                RaiseClickOnItemEvent(e, viewModel);
                e.Handled = true;
            }
        }

        #region Common KeyHandler

        private static bool IsElementVisibleInContainer(FrameworkElement element, FrameworkElement container)
        {
            if (!element.IsVisible)
                return false;

            Rect bounds = element.TransformToAncestor(container).
                TransformBounds(new Rect(0.0, 0.0, element.ActualWidth, element.ActualHeight));
            var rect = new Rect(0.0, 0.0, container.ActualWidth, container.ActualHeight);
            return rect.Contains(bounds.TopLeft) || rect.Contains(bounds.BottomRight);
        }

        private IEnumerable<ListBoxItem> GetVisibleListBoxItems()
        {
            if (_virtualStackPanel == null)
                return new List<ListBoxItem>();

            var virtualPanelChildren = _virtualStackPanel.Children.OfType<ListBoxItem>();
            var items = virtualPanelChildren.
                Select(it => new { listboxItem = it, visibility = IsElementVisibleInContainer(it, _listBox) }).
                SkipWhile(it => !it.visibility).TakeWhile(it => it.visibility).Select(it => it.listboxItem);
            return items;
        }

        private IEnumerable<object> GetVisibleViewModels()
        {
            return GetVisibleListBoxItems().Select(it => it.DataContext);
        }

        private void KeyPageDownHandler(KeyEventArgs e)
        {
            _isSyncwithIsMouseOver = false;
            _lastFixedMousePosition = Mouse.GetPosition(this);

            var visibleItems = GetVisibleViewModels().ToList();
            var count = visibleItems.Count;
            var lastVisibleItem = visibleItems.LastOrDefault();
            if (lastVisibleItem != null)
            {
                var ind = Items.IndexOf(lastVisibleItem);
                var nextItemInd = ind + count;
                if (nextItemInd >= Items.Count)
                    nextItemInd = Items.Count - 1;

                _listBox.SelectedIndex = nextItemInd;
                _listBox.ScrollIntoView(_listBox.SelectedItem);
                e.Handled = true;
            }
        }

        private void KeyPageUpHandler(KeyEventArgs e)
        {
            _isSyncwithIsMouseOver = false;
            _lastFixedMousePosition = Mouse.GetPosition(this);

            var visibleItems = GetVisibleViewModels().ToList();
            var count = visibleItems.Count;
            var firstVisibleItem = visibleItems.FirstOrDefault();
            if (firstVisibleItem != null)
            {
                var ind = Items.IndexOf(firstVisibleItem);
                var nextItemInd = ind - count;
                if (nextItemInd < 0)
                    nextItemInd = 0;
                _listBox.SelectedIndex = nextItemInd;
                _listBox.ScrollIntoView(_listBox.SelectedItem);

                e.Handled = true;
            }
        }

        private ScrollViewer ItemsScrollViewer
        {
            get
            {
                if (!IsExpanded)
                    return null;

                if (_virtualStackPanel != null)
                    return _virtualStackPanel.ScrollOwner;

                var scrollViewer = VisualTreeHelperEx.GetChildren<ScrollViewer>(_listBox).FirstOrDefault();
                return scrollViewer;
            }
        }
        #region KeyHandlers
        private void KeyEndHandler(KeyEventArgs e)
        {
            if (_listBox.HasItems && IsExpanded)
            {
                var index = _listBox.Items.Count - 1;
                _listBox.ScrollIntoView(_listBox.Items[index]);
                _listBox.SelectedIndex = index;
                e.Handled = true;
            }
        }

        private void KeyHomeHandler(KeyEventArgs e)
        {
            if (_listBox.HasItems && IsExpanded)
            {
                _listBox.ScrollIntoView(_listBox.Items[0]);
                _listBox.SelectedIndex = 0;
                e.Handled = true;
            }
        }
        private void KeyAltHandler(KeyEventArgs e)
        {
            if ((Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)) && Keyboard.IsKeyDown(Key.Down))
            {
                ExpanderClick();
                e.Handled = true;
            }
        }

        private void KeyUpHandler(KeyEventArgs e)
        {
            if (_listBox.HasItems && IsExpanded && _listBox.SelectedIndex > 0)
            {
                _isSyncwithIsMouseOver = false;
                MoveSelectedIndexWithScrooll(-1);
                e.Handled = true;
            }
        }

        private void MoveSelectedIndexWithScrooll(int dIndex)
        {
            var index = _listBox.SelectedIndex + dIndex;
            var item = _listBox.ItemContainerGenerator.ContainerFromIndex(index) as ListBoxItem;
            if (item != null)
            {
                _listBox.SelectedIndex = index;
                item.BringIntoView();
            }
        }

        private void KeyDownHandler(KeyEventArgs e)
        {
            if (!IsExpanded)
            {
                OnModeChanged(SearchableComboBoxMode.Normal);
                OnUpdateVisualItems();
                _listBox.SelectedIndex = 0;
                e.Handled = true;
                return;
            }

            if (_listBox.HasItems && _listBox.SelectedIndex < _listBox.Items.Count - 1)
            {
               _isSyncwithIsMouseOver = false;
                _lastFixedMousePosition = Mouse.GetPosition(this);

                MoveSelectedIndexWithScrooll(+1);
                e.Handled = true;
            }
        }


        private void KeyEnterHandler(KeyEventArgs e)
        {
            e.Handled = true;
            if (_listBox.HasItems && IsExpanded && _listBox.SelectedItem != null)
            {
                RaiseClickOnItemEvent(e, _listBox.SelectedItem);
                return;
            }

            _textBox.SelectAll();
            _textBox.Focus();
        }

        private void MoveFocusFromElement(UIElement keyboardFocus, FocusNavigationDirection direction)
        {
            TraversalRequest traversalRequest1 = new TraversalRequest(direction);
            keyboardFocus.MoveFocus(traversalRequest1);
        }

        private void KeyTabHandler(KeyEventArgs e)
        {
            if (IsExpanded)
            {
                IsExpanded = false;
                e.Handled = true;
                return;
            }

            if (Keyboard.IsKeyDown(Key.RightShift) || Keyboard.IsKeyDown(Key.LeftShift))
            {
                TraversalRequest traversalRequest1 = new TraversalRequest(FocusNavigationDirection.Previous);
                this.MoveFocus(traversalRequest1);

                e.Handled = true;
            }
        }

        private void KeyEscHandler(KeyEventArgs e)
        {
            if (IsExpanded)
            {
                IsExpanded = false;
                e.Handled = true;
            }
        }
        #endregion KeyHandlers
        private void OnCommonPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (!IsOn)
                return;

            var keyEventArgs = new KeyArgs(e);
            CommonPreviewKeyDown?.Invoke(this, keyEventArgs);

            if (keyEventArgs.Handled)
            {
                _isSyncwithIsMouseOver = false;
                _lastFixedMousePosition = Mouse.GetPosition(this);
                e.Handled = true;
                return;
            }

            Action<KeyEventArgs> keyHandler = null;
            if (_keyHandlers.TryGetValue(e.Key, out keyHandler))
                keyHandler(e);
        }
        #endregion Common KeyHandler

        private void TextBoxTextChanged(object sender, TextChangedEventArgs e)
        {
            if (!IsOn)
                return;

            SearchTextChanged?.Invoke(this, new EventArgs());

            var newWorkMode = string.IsNullOrEmpty(_textBox.Text) ? SearchableComboBoxMode.Normal : SearchableComboBoxMode.Search;
            OnModeChanged(newWorkMode);
            OnUpdateVisualItems();
            if (_listBox.HasItems && IsExpanded)
                _listBox.SelectedIndex = 0;
        }

        private void OnUpdateVisualItems()
        {
            var ev = UpdateItems;
            var ar = new UpdateItemsArgs();
            ev?.Invoke(this, ar);

            if (ar.ShowItems)
                IsExpanded = true;
            else
            {
                if (IsExpanded)
                    IsExpanded = false;
            }
        }
        private void PopupClosed(object sender, EventArgs e)
        {
            Mouse.RemoveMouseMoveHandler(this, ListBoxItemsMouseMoveHandler);
            var view = FocusManager.GetFocusScope(this) as Window;

            if (view != null)
            {
                view.PreviewMouseDown -= FocusScopePreviewMouseDownHandler;
                view.LocationChanged -= WindowMoved;
                view.Deactivated -= WindowMoved;
            }
            var scrollViewer = ItemsScrollViewer;
            if (scrollViewer != null)
                scrollViewer.LayoutUpdated -= ScrollViewerLayoutUpdated;
            _isSyncwithIsMouseOver = true;
        }

        public bool CanOpen {
            get
            {
                var view = FocusManager.GetFocusScope(this) as Window;
                return view?.IsActive == true;
            }
        }

        private void PopupOpened(object sender, EventArgs e)
        {
            _lastFixedMousePosition = null;
            var scrollViewer = ItemsScrollViewer;
            if (scrollViewer != null)
            {
                _virtualStackPanel = _virtualStackPanel ?? VisualTreeHelperEx.GetFirstOrDefaultChildren<VirtualizingStackPanel>(scrollViewer);

                scrollViewer.ScrollToTop();
                if (_heightCalculationInfo.IsChanged(VisibleItemsMaxCount))
                {
                    _listBox.MaxHeight = PopupMaxHeight;
                    scrollViewer.LayoutUpdated += ScrollViewerLayoutUpdated;
                }
            }
            var view = FocusManager.GetFocusScope(this) as Window;
            Mouse.AddMouseMoveHandler(this, ListBoxItemsMouseMoveHandler);
            view.PreviewMouseDown += FocusScopePreviewMouseDownHandler;
            view.LocationChanged += WindowMoved; ;
            view.Deactivated += WindowMoved;
        }

       

        private void WindowMoved(object sender, EventArgs e)
        {
            IsExpanded = false;
        }

        private void ScrollViewerLayoutUpdated(object sender, EventArgs e)
        {
            var visibleListBoxItems = GetVisibleListBoxItems().ToList();

            if (visibleListBoxItems.Count > VisibleItemsMaxCount)
            {
                var height = visibleListBoxItems.Take(VisibleItemsMaxCount).Sum(it => it.ActualHeight);
                _heightCalculationInfo = new HeightCalculationInfo(VisibleItemsMaxCount);
                _listBox.MaxHeight = height;

                var scrollViewer = ItemsScrollViewer;
                if (scrollViewer != null)
                    scrollViewer.LayoutUpdated -= ScrollViewerLayoutUpdated;
            }
        }

        private void FocusScopePreviewMouseDownHandler(object sender, MouseEventArgs mouseButtonEventArgs)
        {
            if (!MouseInsideControl())
                IsExpanded = false;
        }

        private void ListBoxItemsMouseMoveHandler(object sender, MouseEventArgs mouseButtonEventArgs)
        {
            if (_lastFixedMousePosition != Mouse.GetPosition(this))
            {
                _isSyncwithIsMouseOver = true;
                _lastFixedMousePosition = null;
            }
        }

        private class HeightCalculationInfo
        {
            private HeightCalculationInfo(int visibleItemsMaxCount, int dpi)
            {
                _visibleItemsMaxCount = visibleItemsMaxCount;
                _dpi = dpi;
            }

            public HeightCalculationInfo(int visibleItemsMaxCount) :
                this(visibleItemsMaxCount, ScreenInfoHelper.GetDpiY())
            {
            }

            public bool IsChanged(int visibleItemsMaxCount)
            {
                return _visibleItemsMaxCount != visibleItemsMaxCount
                    || _dpi != ScreenInfoHelper.GetDpiY();
            }

            public static HeightCalculationInfo Invalid
            {
                get { return new HeightCalculationInfo(-1, -1); }
            }

            private int _dpi;
            private int _visibleItemsMaxCount;
        }

        private HeightCalculationInfo _heightCalculationInfo = HeightCalculationInfo.Invalid;
        private readonly Dictionary<Key, Action<KeyEventArgs>> _keyHandlers = new Dictionary<Key, Action<KeyEventArgs>>();
        private readonly List<ListBoxItem> _visibleListboxItems = new List<ListBoxItem>();
        private Point? _lastFixedMousePosition;
        private bool _isSyncwithIsMouseOver = true;
        private VirtualizingStackPanel _virtualStackPanel;
        private TextBox _textBox;
        private Button _expander;
        private ListBox _listBox;
        private Popup _popup;
        private bool _setKeyboardFocus = false;
        private bool _isOn;
        private bool _isExpanded;
    }
}

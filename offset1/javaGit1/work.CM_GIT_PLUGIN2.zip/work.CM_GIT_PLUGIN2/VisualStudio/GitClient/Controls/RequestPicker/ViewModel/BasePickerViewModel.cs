﻿using Caliburn.Micro;
using GitClient.Controls.RequestPicker;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace GitClient.Controls.ViewModel
{
    public interface IExpandableGroup<T> where T : SelectableItem
    {
        bool IsExpanded { get; set; }
        BindableCollection<T> SubItems { get; }
        List<SelectableItem> ToFlatList(string searchString = "");

        event EventHandler<bool> IsExpandedChanged;
    }

    public abstract class BasePickerViewModel<Parent, Children> : PropertyChangedAware
        where Children : SelectableItem
        where Parent : SelectableItem, IExpandableGroup<Children>
    {

        public SearchableComboBoxMode WorkMode { get; protected set; }
        public string SearchText { get; protected set; }

        protected void SetGroups(ObservableCollection<Parent> groups)
        {
            if (_groups != null && _groups.Any())
            {
                foreach (var gr in groups)
                {
                    gr.IsExpandedChanged -= GroupIsExpandedChanged;
                }
            }
            _groups = groups;

            if (_groups != null && _groups.Any())
            {
                foreach (var gr in groups)
                {
                    gr.IsExpandedChanged += GroupIsExpandedChanged;
                }
            }
        }

        abstract protected void GroupIsExpandedChanged(object sender, bool isExpanded);

        abstract protected List<SelectableItem> ParseSourceTreeToList();

        public void RefreshItems()
        {
            var newItems = ParseSourceTreeToList();
            Items.IsNotifying = false;
            Items.Clear();
            Items.AddRange(newItems);
            foreach (var it in Items.Where(it => it.IsSelected))
                it.IsSelected = false;
            Items.IsNotifying = true;
            Items.Refresh();
        }

        public BindableCollection<SelectableItem> Items { get; private set; } = new BindableCollection<SelectableItem>();

        protected ObservableCollection<Parent> _groups;
    }
}

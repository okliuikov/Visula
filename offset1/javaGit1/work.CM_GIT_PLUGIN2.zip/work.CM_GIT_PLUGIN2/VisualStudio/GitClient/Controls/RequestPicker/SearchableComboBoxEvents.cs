﻿using System.Windows;
using System.Windows.Input;

namespace GitClient.Controls.RequestPicker
{
    public class KeyArgs
    {
        public KeyArgs(KeyEventArgs args)
        {
            Handled = false;
            Key = args.Key;
            OriginalSource = args.OriginalSource;
        }
        public bool Handled { get; set; }
        public Key Key { get; private set; }
        public object OriginalSource { get; private set; }
    }
    public class UpdateItemsArgs
    {
        public bool ShowItems { get; set; }
    }
    public class ClickOnItemEventArgs
    {
        public ClickOnItemEventArgs(RoutedEventArgs routedEventArgs, object item)
        {
            Item = item;
            OriginalSource = routedEventArgs.OriginalSource;
            Source = routedEventArgs.Source;
            IsSelectAllSearchText = false;
            IsClosingPopup = true;
        }
        public object OriginalSource { get; private set; }
        public object Source { get; private set; }
        public object Item { get; private set; }
        public bool IsSelectAllSearchText { get; set; }
        public bool IsClosingPopup { get; set; }
    }
}

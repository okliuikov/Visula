﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitClient.Controls.RequestPicker
{
    public interface IPickerControl
    {
        event EventHandler<KeyArgs> CommonPreviewKeyDown;
        event EventHandler<ClickOnItemEventArgs> ClickOnItemEvent;
        event EventHandler SearchTextChanged;
        event EventHandler<SearchableComboBoxMode> ModeChanged;

        event EventHandler<UpdateItemsArgs> UpdateItems;
        string SearchText { get; set; }
        bool IsOn { get; set; }

        bool IsExpanded { get; set; }

        SearchableComboBoxMode WorkMode { get; set; }

        bool CanOpen { get; }
    }

    public enum SearchableComboBoxMode
    {
        Normal,
        Search
    }
}

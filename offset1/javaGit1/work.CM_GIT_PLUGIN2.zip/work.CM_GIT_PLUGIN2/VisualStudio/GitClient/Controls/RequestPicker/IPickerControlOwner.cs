﻿namespace GitClient.Controls.RequestPicker
{
    public interface IPickerControlOwner
    {
        IPickerControl PickerControl { get; set; }
    }
}

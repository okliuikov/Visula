﻿using System;
using Dimensions.Rest;
using GitClient.Controls.ViewModel;
using Serena.Common.Util.Logger;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using GitClient.Utility;

namespace GitClient.ViewModel
{
    public class RequestItemViewModel : SelectableItem
    {
        private RequestDetails _details;
        protected int _detailsLoadingPending = 1;
        private List<string> _filteringItems = new List<string>();
        private readonly RequestItem _request;
        private string _statusFormatted;
        private IRequestsDetailsLoader _loader;

        public RequestItemViewModel(RequestItem request, IRequestsDetailsLoader loader)
        {
            _request = request;
            _loader = loader;
        }

        public bool Contains(string text)
        {
            if (_filteringItems.Count <= 1)
            {
                if (!String.IsNullOrEmpty(Id))
                    _filteringItems.Add(Id.ToUpper());
                if (!String.IsNullOrEmpty(Status))
                    _filteringItems.Add(Status.ToUpper());
                if (!String.IsNullOrEmpty(Title))
                    _filteringItems.Add(Title.ToUpper());
                if (!String.IsNullOrEmpty(Type))
                    _filteringItems.Add(Type.ToUpper());
            }

            var upperText = text.ToUpper();
            return _filteringItems.Any(it => it.Contains(upperText));
        }

        public string Id => _request.Id ?? String.Empty;

        public string Status => _request.Status ?? String.Empty;

        public string StatusFormatted
        {
            get
            {
                if (string.IsNullOrEmpty(_statusFormatted))
                    _statusFormatted = RequestDisplayHelper.ToTitleCase(_request.Status);
                return _statusFormatted;
            }
        }

        public string Title => _request.Title ?? String.Empty;


        public string Type => _request.Type ?? String.Empty;


        public int Uid => _request.Uid;

        public string User
        {
            get
            {
                if (null == _details)
                    LoadRequestDetails();

                var user = _details?.Updated?.By;
                return String.IsNullOrEmpty(user) ? String.Empty : RequestDisplayHelper.ToTitleCase(user);
            }
        }

        public RequestDetails Details
        {
            get { return _details; ; }
            set
            {
                _details = value;
                OnPropertyChanged(nameof(User));
            }
        }

        private void LoadRequestDetails()
        {
            _loader.LoadRequestsDetailsFor(this);
        }

        public bool CanLoad => Interlocked.Exchange(ref _detailsLoadingPending, 0) == 1;

        public void ResetCanLoading()
        {
            Interlocked.Exchange(ref _detailsLoadingPending, 1);
        }

        public bool Loaded => _details != null;
    }
}

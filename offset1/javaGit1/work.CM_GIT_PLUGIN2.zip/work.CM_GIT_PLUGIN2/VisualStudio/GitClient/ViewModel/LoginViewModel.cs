﻿using Dimensions.Rest;
using System;
using GitClient.Model;
using System.Net;

namespace GitClient.ViewModel
{
    public class LoginViewModel : PropertyChangedAware
    {
        private string _server;
        private string _user;
        private INetworkCredential _credentialProvider;

        public LoginViewModel(INetworkCredential credentialProvider)
        {
            _credentialProvider = credentialProvider;
        }
        public string Server
        {
            get { return _server; }
            set
            {
                _server = value;
                OnPropertyChanged(nameof(Server));
            }
        }

        public string User
        {
            get { return _user; }
            set
            {
                _user = value;
                OnPropertyChanged(nameof(User));
            }
        }

        public NetworkCredential GetCredential()
        {
            return _credentialProvider.Credential;
        }
    }
}

﻿using Dimensions.Common.Extensions;
using Dimensions.Rest;
using GitClient.Model;
using Serena.Common.Util.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GitClient.ViewModel
{
    public interface IRequestsDetailsLoader
    {
        void LoadRequestsDetailsFor(RequestItemViewModel request);
    }

    public class ErrorMessageArgs
    {
        public ErrorMessageArgs(Exception exception, string message)
        {
            Exception = exception;
            Message = message;
        }

        public Exception Exception { get; private set; }

        public string Message { get; private set; }
    }

    public class RequestItemsLoader : IRequestsDetailsLoader
    {
        private IRequestsLoader _loader;
        private ISimpleLogger _logger;
        private ICredentialManager _credentialManager;
        public RequestItemsLoader(ICredentialManager credentialManager, IRequestsLoader loader, ISimpleLogger logger)
        {
            _loader = loader;
            _logger = logger;
            _credentialManager = credentialManager;
        }

        public Uri RepositoryUri { set; get; }

        public void Initialize()
        {
            _loader.Initialize();
        }

        public void LoadRequestDetailsFor(RequestPickerGroupViewModel group)
        {
            foreach (var it in group.SubItems.Where(it => !it.Loaded).ToList())
                LoadRequestsDetailsFor(it);
        }

        public event EventHandler<ErrorMessageArgs> ErrorMessageHandler;

        private void OnErrorMessage(Exception exception, string message)
        {
            ErrorMessageHandler?.Invoke(this, new ErrorMessageArgs(exception, message));
        }

        public void LoadRequestsFor(RequestPickerGroupViewModel group, Action callBack)
        {
            group.Loading = true;
            Task.Run(() => LoadRequestsAsync(group.Query)).
                ContinueWith(res =>
                {
                    group.Loading = false;
                    try
                    {
                        var requests = res.Result;
                        if (requests?.Any() == true)
                        {
                            group.SubItems.AddRange(requests);
                            group.Loaded = true;
                            callBack?.Invoke();
                        }
                    }
                    catch (AggregateException ex)
                    {
                        group.Loaded = false;
                        _logger.Warn(ex.InnerException);

                        if (!Handle(ex))
                            throw;

                        if (!(ex.InnerException is TaskCanceledException))
                        {
                            string message = ex.InnerException?.Message ?? ex.Message;
                            OnErrorMessage(ex, $"Failed to query Dimensions requests: {message}");
                        }
                    }
                },
               TaskScheduler.FromCurrentSynchronizationContext());
        }

        public bool Handle(AggregateException ex)
        {
            var exception = ex.InnerException;
            return (exception is TaskCanceledException) || (exception is RestException) || (exception is CredentialException) || (exception is UriFormatException);
        }

        public void LoadRequestsDetailsFor(RequestItemViewModel request)
        {
            if (request.CanLoad)
            {
                var cacheDetails = _loader.GetCachedRequestDetails(request.Id);
                if (cacheDetails != null)
                {
                    request.Details = cacheDetails;
                    return;
                }

                Task.Run(() => LoadRequestDetailsAsync(request.Id))
                        .ContinueWith(details =>
                        {
                            try
                            {
                                request.Details = details.Result;
                            }
                            catch (AggregateException ex)
                            {
                                _logger.Warn(ex.InnerException);
                                if (!Handle(ex))
                                    throw;

                            }
                        }, TaskScheduler.FromCurrentSynchronizationContext());
            }
        }


        private async Task<IEnumerable<RequestItemViewModel>> LoadRequestsAsync(RequestQuery query)
        {
            await _credentialManager.RefreshCredentialAsync(RepositoryUri);
            if (_credentialManager.Credential == null)
                return Enumerable.Empty<RequestItemViewModel>();

            try
            {
                var result = await _loader.LoadRequests(query, _credentialManager.Credential);
                try
                {
                    await _credentialManager.SaveCredentialAsync(RepositoryUri);
                }
                catch (CredentialException)
                { // do nothing
                }
                return result?.RequestItems?.Select(requestItem => new RequestItemViewModel(requestItem, this));
            }
            catch (UnauthorizedException)
            {
                try
                {
                    await _credentialManager.ClearCredentialAsync(RepositoryUri);
                }
                catch (CredentialException)
                { // do nothing
                }
                throw;
            }
        }

        private async Task<RequestDetails> LoadRequestDetailsAsync(string requestId)
        {
            await _credentialManager.RefreshCredentialAsync(RepositoryUri);
            if (_credentialManager.Credential == null)
                return null;

            try
            {
                var result = await _loader.LoadRequestDetails(requestId, _credentialManager.Credential);
                try
                {
                    await _credentialManager.SaveCredentialAsync(RepositoryUri);
                }
                catch (CredentialException)
                { // do nothing
                }
                return result;
            }
            catch (UnauthorizedException)
            {
                try
                {
                    await _credentialManager.ClearCredentialAsync(RepositoryUri);
                }
                catch (CredentialException)
                { // do nothing
                }
                throw;
            }
        }

    }
}

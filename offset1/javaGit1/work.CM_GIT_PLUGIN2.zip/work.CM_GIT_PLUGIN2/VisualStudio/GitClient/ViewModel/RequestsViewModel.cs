﻿using Dimensions.Rest;
using Dimensions.Common.Extensions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using GitClient.Model;
using GitClient.Services;
using System.Net;

namespace GitClient.ViewModel
{
    /// <summary>
    /// Represents the requests section
    /// </summary>
    public class RequestsViewModel : PropertyChangedAware
    {
        private string _request;
        private ObservableCollection<RequestItem> _requests = new ObservableCollection<RequestItem>();
        private RequestItem _selectedRequest;
        private bool _isInboxRequests = true;
        private bool _isAllRequests;
        private IGitService _gitService;
        private IRequestStorage _storage;
        private ICredentialManager _credentialManager;

        public RequestsViewModel(IGitService gitService, ICredentialManager credentialManager, IRequestStorage storage)
        {
            _gitService = gitService;
            _storage = storage;
            _credentialManager = credentialManager;
        }

        public async Task LoadRequests(Uri repositoryUri)
        {
            await _credentialManager.RefreshCredentialAsync(repositoryUri);
            if (_credentialManager.Credential != null)
            {
                try
                {
                    var source = new CancellationTokenSource();
                    var query = IsAllRequests ? RequestQuery.AllRequests : RequestQuery.InboxRequests;
                    Requests requests = await _storage.GetRequestsAsync(_credentialManager.Credential, source.Token, query);
                    Requests.Clear();
                    Requests.Add(RequestItem.Empty);
                    Requests.AddRange(requests.RequestItems);
                    await _credentialManager.SaveCredentialAsync(repositoryUri);
                }
                catch (UnauthorizedException)
                {
                    try
                    {
                        await _credentialManager.ClearCredentialAsync(repositoryUri);
                    }
                    catch (CredentialException)
                    { // do nothing
                    }
                    throw;
                }
            }
        }

        public string Request
        {
            get { return _request; }
            set
            {
                _request = value;
                OnPropertyChanged(nameof(Request));
            }
        }
        public ObservableCollection<RequestItem> Requests
        {
            get { return _requests; }
            set { _requests = value; }
        }

        public RequestItem SelectedRequest
        {
            get { return _selectedRequest; }
            set
            {
                _selectedRequest = value;
                OnPropertyChanged(nameof(SelectedRequest));
            }
        }
        public bool IsInboxRequests
        {
            get { return _isInboxRequests; }
            set
            {
                if (_isInboxRequests != value)
                {
                    _isInboxRequests = value;
                    OnPropertyChanged(nameof(IsInboxRequests));
                }
            }
        }

        public bool IsAllRequests
        {
            get { return _isAllRequests; }
            set
            {
                if (_isAllRequests != value)
                {
                    _isAllRequests = value;
                    OnPropertyChanged(nameof(IsAllRequests));
                }
            }
        }

    }
}

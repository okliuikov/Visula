﻿using GitClient.Controls.RequestPicker;
using GitClient.Controls.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Input;

namespace GitClient.ViewModel
{
    public class RequestPickerViewModel : BasePickerViewModel<RequestPickerGroupViewModel, RequestItemViewModel>,
        IPickerControlOwner
    {

        private RequestItemViewModel _selectedRequest;
        public RequestItemViewModel SelectedRequest
        {
            get { return _selectedRequest; }
            private set { _selectedRequest = value; OnPropertyChanged(nameof(SelectedRequest)); }
        }

        public IPickerControl PickerControl
        {
            get { return _pickerControl; }
            set
            {
                if (PickerControl != null)
                {
                    PickerControl.SearchTextChanged -= OnSearchTextChanged;
                    PickerControl.UpdateItems -= OnUpdateItemsHandler;
                    PickerControl.CommonPreviewKeyDown -= OnCommonPreviewKeyDown;
                    PickerControl.ClickOnItemEvent -= OnClickOnItemHandler;
                    PickerControl.ModeChanged -= OnModeChanged;
                    PickerControl.IsOn = false;
                }
                _pickerControl = value;
                if (PickerControl != null)
                {
                    PickerControl.UpdateItems += OnUpdateItemsHandler;
                    PickerControl.SearchTextChanged += OnSearchTextChanged;
                    PickerControl.CommonPreviewKeyDown += OnCommonPreviewKeyDown;
                    PickerControl.ClickOnItemEvent += OnClickOnItemHandler;
                    PickerControl.ModeChanged += OnModeChanged;
                    PickerControl.IsOn = true;
                }
            }
        }

        private void OnModeChanged(object sender, SearchableComboBoxMode mode)
        {
            WorkMode = mode;
        }

        private void OnUpdateItemsHandler(object sender, UpdateItemsArgs args)
        {
            RefreshItems();
            args.ShowItems = Items.Any();
        }

        public RequestItemsLoader RequestItemsLoader { get; private set; }

        public RequestPickerViewModel(RequestItemsLoader requestItemsLoader)
        {
            RequestItemsLoader = requestItemsLoader;
        }

        public void Initialize()
        {
            RequestItemsLoader.Initialize();
            _inboxGroup = RequestPickerGroupViewModel.InboxGroup;
            _allGroup = RequestPickerGroupViewModel.AllGroup;
            SetGroups(new ObservableCollection<RequestPickerGroupViewModel> { _inboxGroup, _allGroup });
            RefreshItems();
            RequestItemsLoader.LoadRequestsFor(_inboxGroup, () => RefreshItems());
        }

        protected override void GroupIsExpandedChanged(object sender, bool isExpanded)
        {
            var pickerGroup = sender as RequestPickerGroupViewModel;
            if (pickerGroup == null)
                return;

            if (pickerGroup.IsExpanded && !pickerGroup.Loaded && !pickerGroup.Loading)
                RequestItemsLoader.LoadRequestsFor(pickerGroup, () => RefreshItems());


            var index = Items.IndexOf(pickerGroup) + 1;

            if (!isExpanded)
            {
                var removingItems = Items.Skip(index).
                                  TakeWhile(it => !(it is RequestPickerGroupViewModel)).ToList();

                Items.RemoveRange(removingItems);
                return;
            }

            var addingItems = ParseSourceTreeToList().Skip(index).
                              TakeWhile(it => !(it is RequestPickerGroupViewModel)).ToList();
            Items.IsNotifying = false;

            foreach (var subItem in addingItems)
            {
                Items.Insert(index, subItem);
                index++;
            }

            Items.IsNotifying = true;
            Items.Refresh();
        }

        protected override List<SelectableItem> ParseSourceTreeToList()
        {
            var newItems = new List<SelectableItem>();
            if (WorkMode == SearchableComboBoxMode.Normal)
            {
                newItems.AddRange(_groups.SelectMany(it => it.ToFlatList("")));
            }
            else
            {
                newItems.AddRange(_allGroup.ToFlatList(SearchText));
            }
            return newItems;
        }

        #region Keyboard & mouse navigations
        private void OnSearchTextChanged(object sender, EventArgs args)
        {
            SearchText = PickerControl.SearchText;
            if (string.IsNullOrEmpty(SearchText))
                return;

            if (!_allGroup.Loaded && !_allGroup.Loading)
                RequestItemsLoader.LoadRequestsFor(_allGroup, ActionAfterLoadingAllGroup);
        }

        private void ActionAfterLoadingAllGroup()
        {
            if (PickerControl?.IsExpanded == true || !string.IsNullOrEmpty(SearchText))
            {
                RefreshItems();
                if (!string.IsNullOrEmpty(SearchText) && Items.Any() && PickerControl?.IsExpanded == false && PickerControl?.CanOpen == true)
                    PickerControl.IsExpanded = true;
            }
        }

        private void OnCommonPreviewKeyDown(object sender, KeyArgs keyArgs)
        {
            var wasPressedSpace = keyArgs.Key == Key.Space;

            var selectedItem = Items.FirstOrDefault(it => it.IsSelected);
            var requestItem = selectedItem as RequestItemViewModel;
            if (requestItem != null)
            {
                if (wasPressedSpace || keyArgs.Key == Key.Enter)
                {
                    SelectedRequest = requestItem;
                    keyArgs.Handled = true;
                }
                return;
            }


            var selectedGroup = selectedItem as RequestPickerGroupViewModel;
            if (selectedGroup == null)
                return;

            if (wasPressedSpace || keyArgs.Key == Key.Enter)
            {
                selectedGroup.IsSelected = true;
                selectedGroup.IsExpanded = !selectedGroup.IsExpanded;
                keyArgs.Handled = true;
                return;
            }

            if (keyArgs.Key == Key.Left && selectedGroup.IsExpanded)
            {
                selectedGroup.IsExpanded = false;
                keyArgs.Handled = true;
                return;
            }

            if (keyArgs.Key == Key.Right && !selectedGroup.IsExpanded)
            {
                selectedGroup.IsExpanded = true;
                keyArgs.Handled = true;
            }
        }
        #region OnClickOnItem

        private void OnClickOnItemHandler(object sender, ClickOnItemEventArgs args)
        {
            var baseItem = args.Item as SelectableItem;

            if (baseItem != null)
                OnClickOnItem((dynamic)baseItem, args);
            else
                Debug.Assert(baseItem == null, "SelectedItem==null!!");
        }

        private void OnClickOnItem(object selectedItem, ClickOnItemEventArgs args)
        {
            Debug.WriteLine("WARNING: New SelectedItem with type:", selectedItem.GetType());
        }

        private void OnClickOnItem(RequestItemViewModel selectedRequest, ClickOnItemEventArgs args)
        {

            SelectedRequest = selectedRequest;
        }

        private void OnClickOnItem(RequestPickerGroupViewModel selectedGroup, ClickOnItemEventArgs args)
        {
            selectedGroup.IsExpanded = !selectedGroup.IsExpanded;

            args.IsClosingPopup = false;
        }

        #endregion OnClickOnItem
        #endregion Keyboard & mouse navigations
        private RequestPickerGroupViewModel _inboxGroup;
        private RequestPickerGroupViewModel _allGroup;
        private IPickerControl _pickerControl;
    }
}

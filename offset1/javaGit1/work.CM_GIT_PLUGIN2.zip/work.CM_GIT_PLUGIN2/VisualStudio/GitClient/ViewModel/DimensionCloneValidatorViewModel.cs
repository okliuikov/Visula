﻿using Dimensions.Common.Extensions;
using Dimensions.Model;
using GitClient.Utility;
using Microsoft.TeamFoundation.Controls;
using Microsoft.TeamFoundation.Controls.WPF.TeamExplorer;
using Microsoft.TeamFoundation.MVVM;
using Serena.Common.Util.Logger;
using System;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace GitClient.ViewModel
{
    public class DimensionCloneValidatorViewModel
    {
        private CheckPluginViewModel _checkPlugin;
        private const string LocalGitRepositoriesSectionId = "EF6A7A99-F01F-4C91-AD31-183C1354DD97";
        private readonly static string[] UrlCloneMatchHintTextes = { "URL", "clone" };
        private readonly static string[] ClonePathMatchHintTextes = { "path", "cloned" };
        private readonly static string CloneButtonName = "clone";
        private Button _cloneButton;
        private TextBox _cloneUrlTextBox;
        private TextBox _clonePathTextBox;
        private ITeamExplorer _explorer;
        private ISimpleLogger _logger;

        public Guid OwnerId
        {
            get { return _checkPlugin.OwnerId; }
            set { _checkPlugin.OwnerId = value; }
        }

        public DimensionCloneValidatorViewModel(IServiceProvider serviceProvider, IDimensionsGitPluginChecker checker, ISimpleLogger logger)
        {
            _logger = logger;
            _explorer = serviceProvider.GetService<ITeamExplorer>();
            _checkPlugin = new CheckPluginViewModel(_explorer, checker, logger);
            _checkPlugin.OpenLinkCommand = new RelayCommand(OpenLink);
        }

        public void Initialize()
        {
            UnSubscribeCachedControls();
            ITeamExplorerPage explorerPage = _explorer.CurrentPage;
            var result = false;
            var section = explorerPage?.GetSection(new Guid(LocalGitRepositoriesSectionId)) as TeamExplorerSectionBase;
            if (section != null)
            {
                var view = section.View as FrameworkElement;
                if (view != null)
                {
                    view.Loaded += OnSectionViewLoaded;
                    result = true;
                }
            }
            if (!result)
                _checkPlugin.CheckPlugin();
        }

        private void OpenLink(object obj)
        {
            var url = obj as string;
            if (string.IsNullOrEmpty(url))
                return;
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                _logger.Warn($"Failed to open link {url}");
                _logger.Warn(ex);
            }
        }

        private void OnSectionViewLoaded(object sender, EventArgs e)
        {
            var control = sender as FrameworkElement;
            control.Loaded -= OnSectionViewLoaded;
            if (!PrepareForCloneTrack(control))
                _checkPlugin.CheckPlugin();
        }

        private bool PrepareForCloneTrack(FrameworkElement control)
        {
            _cloneButton = VisualTreeHelperEx.GetChildren<Button>(control).FirstOrDefault(i => i.Name.Contains(CloneButtonName));
            var textBoxes = VisualTreeHelperEx.GetChildren<TextBox>(control).Select(it =>
                       new
                       {
                           item = it,
                           hintText = (it.Parent as Microsoft.TeamFoundation.Controls.WPF.LabeledTextBox)?.HintText
                       })
                .Where(it => !string.IsNullOrEmpty(it.hintText)).ToList();
            _cloneUrlTextBox = textBoxes.FirstOrDefault(it => UrlCloneMatchHintTextes.All(i => it.hintText.Contains(i)))?.item;
            _clonePathTextBox = textBoxes.FirstOrDefault(it => ClonePathMatchHintTextes.All(i => it.hintText.Contains(i)))?.item;
            if (_cloneButton != null && _cloneUrlTextBox != null && _clonePathTextBox != null)
            {
                _cloneButton.PreviewMouseLeftButtonDown += OnPreviewMouseDown;
                _clonePathTextBox.PreviewKeyDown += OnPreviewKeyDown;
                _cloneUrlTextBox.PreviewKeyDown += OnPreviewKeyDown;
                _cloneUrlTextBox.TextChanged += OnCloneUrChanged;
                return true;
            }
            return false;
        }

        private void OnCloneUrChanged(object sender, EventArgs e)
        {
            if (_cloneButton.IsEnabled)
                _checkPlugin.HandledCheckPluginFor(_cloneUrlTextBox.Text);
        }

        private void OnPreviewKeyDown(object sender, RoutedEventArgs e)
        {
            if (_cloneButton.IsEnabled && Keyboard.IsKeyDown(Key.Enter) &&
                _checkPlugin.HandledCheckPluginFor(_cloneUrlTextBox.Text))
            {
                e.Handled = true;
            }
        }

        private void OnPreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_checkPlugin.HandledCheckPluginFor(_cloneUrlTextBox.Text))
            {
                e.Handled = true;
            }
        }

        private void UnSubscribeCachedControls()
        {
            if (_cloneButton != null)
            {
                _cloneButton.PreviewMouseLeftButtonDown -= OnPreviewKeyDown;
                _cloneButton = null;
            }
            if (_clonePathTextBox != null)
            {
                _clonePathTextBox.PreviewKeyDown -= OnPreviewKeyDown;
                _clonePathTextBox = null;
            }
            if (_cloneUrlTextBox != null)
            {
                _cloneUrlTextBox.TextChanged -= OnCloneUrChanged;
                _cloneUrlTextBox.PreviewKeyDown -= OnPreviewKeyDown;
                _cloneUrlTextBox = null;
            }
        }
    }
}

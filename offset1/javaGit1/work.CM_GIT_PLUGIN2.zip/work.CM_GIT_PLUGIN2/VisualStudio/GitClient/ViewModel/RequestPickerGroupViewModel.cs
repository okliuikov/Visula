﻿using Caliburn.Micro;
using GitClient.Controls.ViewModel;
using GitClient.Model;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace GitClient.ViewModel
{
    public class RequestPickerGroupViewModel : SelectableItem, IExpandableGroup<RequestItemViewModel>
    {

        public RequestQuery Query { get; private set; } 

        public bool Loading
        {
            get { return _isLoading; }
            set { _isLoading = value; OnPropertyChanged(nameof(Loading)); }
        }

        public bool Loaded { get; set; } = false;

        private void UpdateUnsortedFlatList()
        {
            _unsortedFlatList.Clear();
            _unsortedFlatList.Add(this);
            if (IsExpanded && SubItems.Any())
              _unsortedFlatList.AddRange(SubItems);
        }

        private void UpdateSortedFlatList(string sortedString)
        {
            IEnumerable<SelectableItem> items = string.IsNullOrEmpty(sortedString) ? SubItems :
                SubItems.Where(requestItem => requestItem.Contains(sortedString));
            _sortedFlatList = items.ToList();
        }

        public List<SelectableItem> ToFlatList(string searchString = "")
        {
            if (string.IsNullOrEmpty(searchString))
                return _unsortedFlatList;

            var res = new List<SelectableItem>();

             UpdateSortedFlatList(searchString);
             res.AddRange(_sortedFlatList);
            return res;
        }

        public BindableCollection<RequestItemViewModel> SubItems { get; private set; }
        = new BindableCollection<RequestItemViewModel>();

        public string Title 
        {
            get { return _title; }
            protected set { _title = value; OnPropertyChanged(nameof(Title)); }
        }

        public event EventHandler<bool> IsExpandedChanged;
        public bool IsExpanded
        {
            get { return _isExpanded; }
            set
            {
                var changed = _isExpanded != value;
                _isExpanded = value;
                UpdateUnsortedFlatList();
                OnPropertyChanged(nameof(IsExpanded));
                if (changed)
                {
                    var expandEvent = IsExpandedChanged;
                    if (expandEvent != null)
                        expandEvent(this, value);
                }
            }
        }

        private RequestPickerGroupViewModel()
        {
            SubItems.CollectionChanged += NotifyCollectionChangedEventHandler;
            UpdateUnsortedFlatList();
        }

        private void NotifyCollectionChangedEventHandler(object sender, NotifyCollectionChangedEventArgs e)
        {
            UpdateUnsortedFlatList();
        }

        public static RequestPickerGroupViewModel AllGroup
        {
            get
            {
                return new RequestPickerGroupViewModel() { Title = AllGroupTitle, Query = RequestQuery.AllRequests };
            }
        }


        public static RequestPickerGroupViewModel InboxGroup
        {
            get
            {
                return new RequestPickerGroupViewModel() { Title = InboxGroupTitle, Query = RequestQuery.InboxRequests, IsExpanded = true };
            }
        }

        private List<SelectableItem> _sortedFlatList = new List<SelectableItem>();
        private List<SelectableItem> _unsortedFlatList = new List<SelectableItem>() { };
        private static string AllGroupTitle = Resources.All;
        private static string InboxGroupTitle = Resources.Inbox;
        private string _title;

        private bool _isExpanded = false;
        private bool _isLoading = false;
    }
}

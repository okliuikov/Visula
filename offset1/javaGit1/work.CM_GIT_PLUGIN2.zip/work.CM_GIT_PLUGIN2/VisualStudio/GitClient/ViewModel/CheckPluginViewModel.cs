﻿using Dimensions.Model;
using Dimensions.Utility;
using Microsoft.TeamFoundation.Controls;
using Serena.Common.Util.Logger;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GitClient.ViewModel
{
    public class CheckPluginViewModel : PropertyChangedAware
    {
        private readonly string DimensionsGitPluginUrl = "https://github.com/yrakovets1/com.microfocus.dimension-git-win-installer/releases/latest";
        private ITeamExplorer _teamExplorer;
        private IDimensionsGitPluginChecker _checker;
        private ISimpleLogger _logger;

        public CheckPluginViewModel(ITeamExplorer teamExplorer, IDimensionsGitPluginChecker checker, ISimpleLogger logger)
        {
            _teamExplorer = teamExplorer;
            _checker = checker;
            _logger = logger;
        }

        public Guid OwnerId { get; set; }

        public ICommand OpenLinkCommand { get; set; }

        public void CheckPlugin()
        {
            var previousPage = _teamExplorer.CurrentPage;
            Task.Run(() => _checker.Exists()).
                 ContinueWith(check =>
                 {
                     try
                     {
                         if (ReferenceEquals(previousPage, _teamExplorer.CurrentPage))
                             RefreshNotification(check.Result);
                     }
                     catch (Exception ex)
                     {
                         _logger.Warn("Failed to refresh notification");
                         _logger.Warn(ex);
                     }
                 }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        public bool HandledCheckPluginFor(string cloneUrl)
        {
            if (DimensionsGitHelper.IsDimensionsUrl(cloneUrl))
            {
                var result = _checker.Exists();
                RefreshNotification(result);
                return !result;
            }
            return false;
        }

        private void RefreshNotification(bool pluginExist)
        {
            var visibleNotification = _teamExplorer.IsNotificationVisible(OwnerId);
            if (!pluginExist)
            {
                if (!visibleNotification)
                {
                    var message = string.Format(Resources.TheRequiredComponentDimensionsGitClientIsNotInstalled, DimensionsGitPluginUrl);
                    _teamExplorer.ShowNotification(message, NotificationType.Warning, NotificationFlags.None, OpenLinkCommand, OwnerId);
                }
            }
            else if (visibleNotification)
                _teamExplorer.HideNotification(OwnerId);
        }
    }
}

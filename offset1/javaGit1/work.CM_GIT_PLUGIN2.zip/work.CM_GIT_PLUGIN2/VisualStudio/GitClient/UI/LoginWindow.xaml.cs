﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using GitClient.Model;

namespace GitClient.UI
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window, INetworkCredential
    {
        private NetworkCredential _credential;
        public LoginWindow()
        {
            InitializeComponent();
        }

        public NetworkCredential Credential => _credential;

        private void OnLogin(object sender, RoutedEventArgs e)
        {
            _credential = new NetworkCredential(userBox.Text, passwordBox.SecurePassword, serverBox.Text);
            DialogResult = true;
            Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GitClient.UI
{
    /// <summary>
    /// Interaction logic for PushToDimensionsView.xaml
    /// </summary>
    public partial class PushToDimensionsView : UserControl
    {
        public PushToDimensionsView()
        {
            InitializeComponent();
        }

        private void OnConnect(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("You're about to connect to Dimensions.", "Dimensions");
        }

        private void OnPublish(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Adding solution to source control.", "Dimensions");
        }
    }
}

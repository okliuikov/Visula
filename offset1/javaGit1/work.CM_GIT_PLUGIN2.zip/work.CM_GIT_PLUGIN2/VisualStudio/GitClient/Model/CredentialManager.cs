﻿using System;
using System.Threading.Tasks;
using System.Net;
using Dimensions.Rest;
using System.Diagnostics;
using System.IO;

namespace GitClient.Model
{
    /// <summary>
    /// Defines operations with user credentials
    /// </summary>
    public interface ICredentialManager
    {
        RestCredential Credential { get; }

        Task ClearCredentialAsync(Uri repositoryUri);

        Task SaveCredentialAsync(Uri repositoryUri);

        Task RefreshCredentialAsync(Uri repositoryUri);
    }

    public class CredentialManager : ICredentialManager
    {
        private NetworkCredential _credentialHint;
        public RestCredential Credential { private set; get; }

        private IDialogService _dialogService;

        public CredentialManager(IDialogService dialogService)
        {
            _dialogService = dialogService;
            GitPath = GetGitPath();
        }

        private async Task<NetworkCredential> GetCredentialAsync(Uri uri, NetworkCredential hint = null)
        {
            if (uri == null)
                return null;

            CredentialStorage storage = new CredentialStorage(GitPath);
            var credential = await storage.LoadCredential(uri);
            if (credential == null)
            {
                credential = _dialogService.ShowLoginDialog(hint);
            }
            return credential;
        }

        public string GetGitPath()
        {
            var process = Process.GetCurrentProcess();
            string fullPath = process.MainModule.FileName;
            var path = Path.Combine(Path.GetDirectoryName(fullPath), @"CommonExtensions\Microsoft\TeamFoundation\Team Explorer\Git\cmd");
            return path;
        }

        public string GitPath
        {
            get; set;
        }
        
        public async Task ClearCredentialAsync(Uri repositoryUri)
        {
            _credentialHint = new NetworkCredential { UserName = Credential.UserName, Domain = Credential.Authority };
            Credential = null;
            CredentialStorage storage = new CredentialStorage(GitPath);
            await storage.RemoveCredential(repositoryUri, null);
        }

        public async Task SaveCredentialAsync(Uri repositoryUri)
        {
            if (Credential.Tag == null)
            {
                CredentialStorage storage = new CredentialStorage(GitPath);
                await storage.SaveCredential(repositoryUri, Credential.ToNetworkCredential());
                Credential.Tag = repositoryUri.OriginalString;
            }
        }

        public async Task RefreshCredentialAsync(Uri repositoryUri)
        {
            if (Credential == null)
            {
                _credentialHint = _credentialHint ?? new NetworkCredential() { Domain = repositoryUri.Host };
                Credential = new RestCredential(await GetCredentialAsync(repositoryUri, _credentialHint));
            }
        }
    }
}

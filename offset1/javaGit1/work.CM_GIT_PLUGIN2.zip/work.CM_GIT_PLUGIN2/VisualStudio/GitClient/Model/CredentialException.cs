﻿using System;

namespace GitClient.Model
{
    class CredentialException : Exception
    {
        public CredentialException()
        {
        }
        public CredentialException(string message) : base(message)
        {
        }
        public CredentialException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }

    class LoginCancelledException : CredentialException
    {
        public LoginCancelledException()
        {
        }
        public LoginCancelledException(string message) : base(message)
        {
        }
        public LoginCancelledException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}

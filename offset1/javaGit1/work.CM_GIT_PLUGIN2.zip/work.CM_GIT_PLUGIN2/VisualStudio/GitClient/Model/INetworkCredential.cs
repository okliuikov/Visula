﻿using System;
using System.Net;

namespace GitClient.Model
{
    /// <summary>
    /// Abstraction for getting user credential. <see cref="UI.LoginWindow"/>
    /// </summary>
    public interface INetworkCredential
    {
        NetworkCredential Credential { get; }
    }
}

﻿using Dimensions.Rest;
using Serena.Common.Util.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GitClient.Model
{
    public enum RequestQuery
    {
        None,
        InboxRequests,
        AllRequests
    }
    /// <summary>
    /// Defines interface for getting requests
    /// </summary>
    public interface IRequestStorage
    {
        Task<Requests> GetRequestsAsync(RestCredential credential, CancellationToken ct, RequestQuery query);
        Task<RequestDetails> GetRequestDetailsAsync(RestCredential credential, CancellationToken ct, string requestId);
    }

    class RequestStorage : IRequestStorage
    {
        ISimpleLogger _logger;
        public RequestStorage(ISimpleLogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public Task<Requests> GetRequestsAsync(RestCredential credential, CancellationToken ct, RequestQuery query)
        {
            RestManager manager = new RestManager(credential, _logger);
            var executor = query == RequestQuery.AllRequests ? manager.CreateAllRequestsExecutor(false) : manager.CreateInboxRequestsExecutor(false);
            return executor.ExecuteAsync<Requests>(ct);
        }

        public Task<RequestDetails> GetRequestDetailsAsync(RestCredential credential, CancellationToken ct, string requestId)
        {
            RestManager manager = new RestManager(credential, _logger);
            var executor = manager.CreateRequestDetailsExecutor(requestId);
            return executor.ExecuteAsync<RequestDetails>(ct);
        }
    }
}

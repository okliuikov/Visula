﻿using System.IO;

namespace Dimensions.Model
{
    public interface IDimensionsGitPluginChecker
    {
        bool Exists();
    }

    public class DimensionsGitPluginChecker : IDimensionsGitPluginChecker
    {
        private string dimensionsGitFileFullPath;

        private static readonly string[] dimensionsGitRelativeDirs = {"CommonExtensions","Microsoft",
            "TeamFoundation","Team Explorer","Git","mingw32","libexec","git-core" };

        private static readonly string dimensionsGitFileName = "git-remote-dimensions";
        public DimensionsGitPluginChecker()
        {
            var process = System.Diagnostics.Process.GetCurrentProcess();
            var executingFileNameLength = process.MainModule.ModuleName.Length;
            var executingFullPath = process.MainModule.FileName;
            string dimensionsGitRootPath = executingFullPath.Substring(0, executingFullPath.Length - executingFileNameLength);
            dimensionsGitFileFullPath = string.Concat(Path.Combine(dimensionsGitRootPath, Path.Combine(dimensionsGitRelativeDirs)), Path.DirectorySeparatorChar, dimensionsGitFileName);
        }

        public bool Exists() => File.Exists(dimensionsGitFileFullPath);
    }
}

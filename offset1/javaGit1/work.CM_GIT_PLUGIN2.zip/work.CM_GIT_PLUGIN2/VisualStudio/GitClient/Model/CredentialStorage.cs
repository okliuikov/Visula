﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace GitClient.Model
{
    /// <summary>
    /// Read, save and remove credentials from Git Credential Storage
    /// </summary>
    class CredentialStorage
    {
        private string _gitPath;

        public CredentialStorage(string gitPath)
        {
            _gitPath = gitPath;
        }

        public async Task<NetworkCredential> LoadCredential(Uri uri)
        {
            try
            {
                using (Process git = NewGitProcess("credential-manager fill"))
                {
                    git.Start();
                    var host = GetHostString(uri);
                    string input = $"protocol={uri.Scheme}\nhost={host}\n\n";
                    await git.StandardInput.WriteAsync(input);
                    var output = await git.StandardOutput.ReadToEndAsync();
                    if (git.StandardError.Peek() > -1)
                    {
                        var error = await git.StandardError.ReadToEndAsync();
                        if (error.Contains("Logon failed"))
                        {
                            if (!git.HasExited)
                                git.Kill();
                            throw new LoginCancelledException("Credential request was cancelled");
                        }
                    }
                    return ParseCredentials(output);
                }
            }
            catch (InvalidOperationException e)
            {
                throw new CredentialException("Could not read data from the Git Credential Storage", e);
            }
            catch (IOException e)
            {
                throw new CredentialException("Could not read credentials", e);
            }
            catch (Win32Exception e)
            {
                throw new CredentialException("Could not start Git process", e);
            }
        }

        public async Task SaveCredential(Uri uri, NetworkCredential credential)
        {
            try
            {
                using (Process git = NewGitProcess("credential-manager approve"))
                {
                    git.Start();
                    var host = GetHostString(uri);
                    string input = $"protocol ={uri.Scheme}\nhost ={host}\nusername={credential.UserName}\npassword={credential.Password}\n\n";
                    await git.StandardInput.WriteAsync(input);
                }
            }
            catch (InvalidOperationException e)
            {
                throw new CredentialException("Could not save data in the Git Credential Storage", e);
            }
            catch (IOException e)
            {
                throw new CredentialException("Could not save credentials", e);
            }
            catch (Win32Exception e)
            {
                throw new CredentialException("Could not start Git process", e);
            }
        }

        public async Task RemoveCredential(Uri uri, NetworkCredential credential = null)
        {
            try
            {
                using (Process git = NewGitProcess("credential-manager reject"))
                {
                    git.Start();
                    var host = GetHostString(uri);
                    string input = $"protocol={uri.Scheme}\nhost={host}\n";
                    if (credential != null)
                    {
                        if (!String.IsNullOrEmpty(credential.UserName))
                            input += $"username={credential.UserName}\n";
                        if (!String.IsNullOrEmpty(credential.Password))
                            input += $"password={credential.Password}\n";
                    }
                    input += "\n";
                    await git.StandardInput.WriteAsync(input);
                }
            }
            catch (InvalidOperationException e)
            {
                throw new CredentialException("Could not remove data from the Git Credential Storage", e);
            }
            catch (IOException e)
            {
                throw new CredentialException("Could not remove credentials", e);
            }
            catch (Win32Exception e)
            {
                throw new CredentialException("Could not start Git process", e);
            }
        }

        private Process NewGitProcess(string arguments)
        {
            var git = new Process();
            git.StartInfo.UseShellExecute = false;
            git.StartInfo.RedirectStandardInput = true;
            git.StartInfo.RedirectStandardOutput = true;
            git.StartInfo.RedirectStandardError = true;
            git.StartInfo.FileName = Path.Combine(_gitPath, "git.exe");
            git.StartInfo.CreateNoWindow = true;
            git.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            git.StartInfo.WorkingDirectory = _gitPath;
            git.StartInfo.Arguments = arguments;
            return git;
        }

        /*
        protocol=https
        host=github.com
        path=
        username=alex5891
        password=288e8b99c2738571ed4bfa552e50b19e671765e0
         */
        private NetworkCredential ParseCredentials(string data)
        {
            var credentials = data.Trim().Split('\n');
            if (credentials.Length > 4)
            {
                return new NetworkCredential()
                {
                    Domain = credentials[1].Substring("host=".Length),
                    UserName = credentials[3].Substring("username=".Length),
                    Password = credentials[4].Substring("password=".Length)
                };
            }
            throw new CredentialException("The credential returned from Git Credential Storage is invalid");
        }

        public string GetHostString(Uri uri)
        {
            if (uri.UserInfo != null)
                return $"{uri.UserInfo}@{uri.Authority}";
            return uri.Authority;
        }
    }
}

﻿using GitClient.UI;
using GitClient.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace GitClient.Model
{
    public interface IDialogService
    {
        NetworkCredential ShowLoginDialog(NetworkCredential hint = null);
    }

    public class DialogService : IDialogService
    {
        public NetworkCredential ShowLoginDialog(NetworkCredential hint = null)
        {
            var login = new LoginWindow();
            var loginVm = new LoginViewModel(login)
            {
                Server = hint?.Domain,
                User = hint?.UserName
            };
            login.DataContext = loginVm;
            var result = login.ShowDialog();
            if (result == true)
                return loginVm.GetCredential();
            else
                throw new LoginCancelledException("Credential request was cancelled");
        }
    }
}

﻿using Dimensions.Rest;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GitClient.Model
{
    public interface IRequestsLoader
    {
        void Initialize();
        Task<RequestDetails> LoadRequestDetails(string requestId, RestCredential credential);
        Task<Requests> LoadRequests(RequestQuery query, RestCredential credential);

        RequestDetails GetCachedRequestDetails(string requestId);
        void CancelRequestsLoading();
    }

    public class RequestsLoader : IRequestsLoader
    {
        private Dictionary<RequestQuery, CancellationTokenSource> _loadingRequestsSources = new Dictionary<RequestQuery, CancellationTokenSource>();
        private Dictionary<string, RequestDetails> _cachedDetails = new Dictionary<string, RequestDetails>();

        private IRequestStorage _storage;
        private CancellationTokenSource _loadingRequestsDetailsSource = new CancellationTokenSource();

        public RequestsLoader(IRequestStorage storage)
        {
            _storage = storage;
        }

        public void Initialize()
        {
            CancelRequestsLoading();
            CancelLoadingRequestsDetails();
        }


        private SemaphoreSlim _detailLoadingSlim = new SemaphoreSlim(1);


        public RequestDetails GetCachedRequestDetails(string requestId)
        {
            RequestDetails requestDetails;
            _cachedDetails.TryGetValue(requestId, out requestDetails);
            return requestDetails;
        }

        public async Task<RequestDetails> LoadRequestDetails(string requestId, RestCredential credential)
        {
            try
            {
                await _detailLoadingSlim.WaitAsync();
                var requestDetails = await _storage.GetRequestDetailsAsync(credential, _loadingRequestsDetailsSource.Token, requestId);
                if (requestDetails != null)
                    _cachedDetails[requestId] = requestDetails;
                return requestDetails;
            }
            finally
            {
                _detailLoadingSlim.Release();
            }

        }

        public void CancelRequestsLoading()
        {
            foreach (var source in _loadingRequestsSources.Values)
            {
                source.Cancel();
                source.Dispose();
            }
            _loadingRequestsSources.Clear();
        }

        public void CancelLoadingRequestsDetails()
        {
            var old = _loadingRequestsDetailsSource;
            _loadingRequestsDetailsSource = new CancellationTokenSource();
            old.Cancel();
            old.Dispose();
        }

        public async Task<Requests> LoadRequests(RequestQuery query, RestCredential credential)
        {
            if (query == RequestQuery.None)
                throw new ArgumentOutOfRangeException(nameof(query));


            CancellationTokenSource source;
            if (_loadingRequestsSources.TryGetValue(query, out source))
                source.Cancel();

            source = new CancellationTokenSource();
            _loadingRequestsSources[query] = source;
            Requests requests = await _storage.GetRequestsAsync(credential, source.Token, query);
            return requests;
        }
    }
}

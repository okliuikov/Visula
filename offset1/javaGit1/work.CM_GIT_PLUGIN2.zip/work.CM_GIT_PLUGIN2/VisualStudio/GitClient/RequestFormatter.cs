﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitClient
{
    public class RequestFormatter
    {
        private string _message;

        public RequestFormatter(string message)
        {
            _message = message;
        }
        public void AppendRequest(string request)
        {
            int iStart = _message.LastIndexOf('[');
            int iEnd = _message.LastIndexOf(']');
            if (iStart != -1 && iEnd > iStart)
            {
                _message = _message.Substring(0, _message.Length - 1 - (iEnd - iStart));
            }
            if (!String.IsNullOrEmpty(request))
            {
                StringBuilder builder = new StringBuilder(_message.TrimEnd());
                builder.AppendFormat("\n[{0}]", request);
                _message = builder.ToString();
            }
        }
        public override string ToString()
        {
            return _message;
        }
    }
}

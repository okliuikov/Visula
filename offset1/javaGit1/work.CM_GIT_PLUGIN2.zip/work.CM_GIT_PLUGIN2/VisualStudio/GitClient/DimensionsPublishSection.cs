﻿using System;
using System.ComponentModel.Composition;
using Microsoft.TeamFoundation.Controls;
using GitClient.UI;

namespace GitClient
{
    [TeamExplorerSection(DimensionsPublishSectionId, TeamExplorerPageIds.GitCommits, 11)]
    class DimensionsPublishSection : PropertyChangedAware, ITeamExplorerSection
    {
        public const string DimensionsPublishSectionId = "A7472B79-6358-47C3-9475-42BF69D98C13";

        public string Title => "Publish to Dimensions CM";

        public object SectionContent { get; set; }

        public bool IsVisible { get; set; } = false;
        public bool IsExpanded { get; set; } = true;

        public bool IsBusy { get; set; } = false;

        [ImportingConstructor]
        DimensionsPublishSection()
        {
        }

        public void Cancel()
        {
        }

        public void Dispose()
        {
        }

        public object GetExtensibilityService(Type serviceType)
        {
            return null;
        }

        public void Initialize(object sender, SectionInitializeEventArgs e)
        {
            //SectionContent = new PushToDimensionsView();
            //IsVisible = true;
            //OnPropertyChanged(nameof(IsVisible));
        }

        public void Loaded(object sender, SectionLoadedEventArgs e)
        {
        }

        public void Refresh()
        {
        }

        public void SaveContext(object sender, SectionSaveContextEventArgs e)
        {
        }
    }
}

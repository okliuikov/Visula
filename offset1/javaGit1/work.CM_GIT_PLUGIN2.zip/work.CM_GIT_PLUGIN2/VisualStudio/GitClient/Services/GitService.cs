﻿using LibGit2Sharp;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitClient.Services
{
    /// <summary>
    /// Libgit2 services for Git repository
    /// </summary>
    public interface IGitService
    {
        IRepository GetRepository(string path);
        string GetRemoteUrl(IRepository repo, string remote = "origin");
        string GetUserName(IRepository repo);
        string GetServerName(string remoteUrl);
        string GetServerName(IRepository repo);
    }

    [Export(typeof(IGitService))]
    public class GitService : IGitService
    {
        /// <summary>
        /// Probes for a git repository and if one is found, returns a <see cref="IRepository"/> instance for the
        /// repository.
        /// </summary>
        /// <remarks>
        /// The lookup checks to see if the specified <paramref name="path"/> is a repository. If it's not, it then
        /// walks up the parent directories until it either finds a repository, or reaches the root disk.
        /// </remarks>
        /// <param name="path">The path to start probing</param>
        /// <returns>An instance of <see cref="IRepositoryModel"/> or null</returns>
        public IRepository GetRepository(string path)
        {
            var repoPath = Repository.Discover(path);
            return repoPath == null ? null : new Repository(repoPath);
        }

        /// <summary>
        /// Returns a string representing the uri of a remote
        /// </summary>
        /// <param name="repo"></param>
        /// <param name="remote">The name of the remote to look for</param>
        /// <returns></returns>
        public string GetRemoteUrl(IRepository repo, string remote = "origin")
        {
            return repo?.Network.Remotes[remote]?.Url;
        }

        public string GetUserName(IRepository repo)
        {
            return repo?.Config.Get<string>("user.name")?.Value;
        }

        /// <summary>
        /// Returns the server name of a repository
        /// </summary>
        public string GetServerName(IRepository repo)
        {
            string url = GetRemoteUrl(repo);
            return GetServerName(url);
        }

        /// <summary>
        /// Returns the server name of a repository uri
        /// </summary>
        public string GetServerName(string remoteUrl)
        {
            if (String.IsNullOrEmpty(remoteUrl))
                return String.Empty;
            int sep = remoteUrl.LastIndexOf("://");
            string server = remoteUrl.Substring(sep + 3);
            return server.Split("/".ToCharArray()).FirstOrDefault();
        }
    }
}

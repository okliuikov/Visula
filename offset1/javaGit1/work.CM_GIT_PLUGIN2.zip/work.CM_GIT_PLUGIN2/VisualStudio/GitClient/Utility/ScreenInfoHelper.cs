﻿using Serena.Common.Util.Logger;
using Serena.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GitClient.Utility
{
    public static class ScreenInfoHelper
    {
        public const int DefaultDpiX = 96;
        public const int DefaultDpiY = 96;
        public static int GetDpix()
        {
            try
            {
                var dpiXProperty = typeof(SystemParameters).GetProperty("DpiX", BindingFlags.NonPublic | BindingFlags.Static);
                var dpiX = (int)dpiXProperty.GetValue(null, null);
                return dpiX;
            }
            catch (Exception ex)
            {
                if (ex is AmbiguousMatchException || ex is ArgumentException
                    || ex is TargetException || ex is TargetParameterCountException
                    || ex is MethodAccessException || ex is TargetInvocationException)
                {
                    _logger.Error(ex);
                    return DefaultDpiX;
                }
                throw;
            }
        }

        public static int GetDpiY()
        {
            try
            {
                var dpiYProperty = typeof(SystemParameters).GetProperty("Dpi", BindingFlags.NonPublic | BindingFlags.Static);
                var dpiY = (int)dpiYProperty.GetValue(null, null);
                return dpiY;
            }
            catch (Exception ex)
            {
                if (ex is AmbiguousMatchException || ex is ArgumentException
                    || ex is TargetException || ex is TargetParameterCountException
                    || ex is MethodAccessException || ex is TargetInvocationException)
                {
                    _logger.Error(ex);
                    return DefaultDpiY;
                }
                throw;
            }
        }
        private static readonly ISimpleLogger _logger = new SimpleLogger(typeof(ScreenInfoHelper));
    }
}

﻿namespace Dimensions.Utility
{
    public static class DimensionsGitHelper
    {
        public static bool IsDimensionsUrl(string repositoryUrl) => repositoryUrl != null && 
            repositoryUrl.StartsWith("dimensions://");
    }
}

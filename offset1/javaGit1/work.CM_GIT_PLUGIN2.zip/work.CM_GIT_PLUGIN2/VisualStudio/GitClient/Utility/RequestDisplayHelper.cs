﻿using System;
using System.Globalization;
using Serena.Common.Util;

namespace GitClient.Utility
{
    public static class RequestDisplayHelper
    {
        /// <summary>
        /// Converts string to user friendly format, e.g. UNDER WORK -> Under Work
        /// </summary>
        /// <param name="target">String to convert</param>
        /// <returns></returns>
        [global::System.Diagnostics.CodeAnalysis.SuppressMessageAttribute("Microsoft.Globalization", "CA1308: NormalizeStringsToUppercase")]
        public static string ToTitleCase(string target)
        {
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(target.ToLower(CultureInfo.InvariantCulture));
        }

        public static string GetDateFormatted(DateTime? date)
        {
            if (null == date)
                return String.Empty;

            return date.Value.GetTimeSpan();
        }

        public static string GetDateAsGeneralDateShortTime(DateTime? date)
        {
            if (null == date)
                return String.Empty;

            return date.Value.GetGeneralDateShortTime();
        }

        public static DateTime? ParseDateString(string dateString)
        {
            if (String.IsNullOrEmpty(dateString))
                return null;

            if (DateTime.TryParse(dateString, out DateTime dateTime))
                return dateTime;

            return null;
        }
    }
}

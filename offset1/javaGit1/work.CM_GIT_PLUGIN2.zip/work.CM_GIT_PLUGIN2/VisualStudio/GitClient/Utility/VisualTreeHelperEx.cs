﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;

namespace GitClient.Utility
{
    public static class VisualTreeHelperEx
    {
        public static IEnumerable<T> GetChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj == null)
                yield break;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
            {
                var child = VisualTreeHelper.GetChild(depObj, i);
                if (child is T)
                    yield return (T)child;
                var children = GetChildren<T>(child);
                foreach (var ch in children)
                    yield return ch;
            }
        }

        public static T GetFirstOrDefaultChildren<T>(object parent) where T : DependencyObject
        {
            var run = parent as Run;
            var dobj = (run == null) ? parent as DependencyObject : run.Parent;
            T child = null;
            if (dobj != null)
                child = (dobj as T) ??
                        GetChildren<T>(dobj).FirstOrDefault();
            return child;
        }

        internal static T GetParentEx<T>(object child) where T : DependencyObject
        {
            var run = child as Run;
            var dobj = (run == null) ? child as DependencyObject : run.Parent;
            T parent = null;
            if (dobj != null)
                parent = (dobj as T) ?? GetParent<T>(dobj);
            return parent;
        }

        public static T GetParent<T>(DependencyObject obj) where T : DependencyObject
        {
            var item = obj;
            while (true)
            {
                if (item == null)
                    return null;

                var parent = item as T;
                if (parent != null)
                    return parent;

                item = VisualTreeHelper.GetParent(item);
            }
        }
    }
}

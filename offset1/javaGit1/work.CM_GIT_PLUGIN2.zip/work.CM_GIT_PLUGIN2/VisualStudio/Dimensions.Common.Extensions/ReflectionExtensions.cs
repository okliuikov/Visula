﻿using System.Reflection;

namespace Dimensions.Common.Extensions
{
    public static class ReflectionExtensions
    {
        public static FieldInfo GetField(this object target, string name)
        {
            // Set the flags so that private and public fields from instances will be found
            var bindingFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            return target.GetType().GetField(name, bindingFlags);
        }
        public static T GetFieldValue<T>(this object target, string name)
        {
            // Set the flags so that private and public fields from instances will be found
            var bindingFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            var field = target.GetType().GetField(name, bindingFlags);
            return (T)field?.GetValue(target);
        }

        public static void SetFieldValue<T>(this object target, string name, object value)
        {
            // Set the flags so that private and public fields from instances will be found
            var bindingFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            var field = target.GetType().GetField(name, bindingFlags);
            field?.SetValue(target, value);
        }

        public static void SetPropertyValue(this object target, string name, object value)
        {
            // Set the flags so that private and public fields from instances will be found
            var bindingFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            var property = target.GetType().GetProperty(name, bindingFlags);
            property?.SetValue(target, value);
        }
    }
}

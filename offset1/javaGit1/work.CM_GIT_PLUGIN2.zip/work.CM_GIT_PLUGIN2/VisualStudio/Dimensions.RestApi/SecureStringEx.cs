﻿using Serena.Logger;
using Serena.Common.Util.Logger;
using System;
using System.Runtime.InteropServices;
using System.Security;

namespace Dimensions.Rest
{
    public static class SecureStringEx
    {
        public static string Decode(this SecureString securePassword)
        {
            if (null == securePassword)
                return string.Empty;

            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(securePassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            catch(Exception ex)
            {
                _logger.Warn(ex);
                if (ex is NotSupportedException)
                    return string.Empty;

                throw;
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        private static readonly ISimpleLogger _logger = new SimpleLogger(typeof(SecureStringEx));
    }

}

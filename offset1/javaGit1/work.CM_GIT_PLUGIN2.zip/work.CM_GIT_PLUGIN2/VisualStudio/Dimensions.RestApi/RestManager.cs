﻿using Serena.Common.Util.Logger;
using System;

namespace Dimensions.Rest
{
    /// <summary>
    /// Helper for executing Dimensions REST requests
    /// </summary>
    public class RestManager : BaseRestManager
    {
        public RestManager(RestCredential connectionParams, ISimpleLogger logger) : base(connectionParams, logger)
        {
        }

        public virtual HttpWebRequestExecutor CreateInboxRequestsExecutor(bool enableTracing)
        {
            if (String.IsNullOrEmpty(ConnectionDetails.UserName))
                throw new ArgumentException("User name is not specified");

            string restUrl = String.Format("/users/{0}/requests", ConnectionDetails.UserName);
            return CreateExecutor(restUrl, enableTracing);
        }

        public virtual HttpWebRequestExecutor CreateAllRequestsExecutor(bool enableTracing)
        {
            return CreateExecutor("/requests", enableTracing);
        }

        public virtual HttpWebRequestExecutor CreateRequestDetailsExecutor(string requestId)
        {
            if (String.IsNullOrEmpty(requestId))
                throw new ArgumentException("Request id not specified", nameof(requestId));

            string restUrl = String.Format("/requests/{0}", requestId);
            return CreateExecutor(restUrl);
        }
    }
}

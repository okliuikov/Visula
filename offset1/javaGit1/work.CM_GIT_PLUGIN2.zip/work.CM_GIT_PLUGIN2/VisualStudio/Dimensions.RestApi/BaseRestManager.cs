﻿using Serena.Common.Util.Logger;
using System;
using System.Net;
using System.Text;

namespace Dimensions.Rest
{
    /// <summary>
    /// Base class for executing web requests
    /// </summary>
    public class BaseRestManager
    {
        public RestCredential ConnectionDetails { get; protected set; }

        public static readonly string AuthorizationHeader = "Authorization";

        /// <exception cref="RestException"/><exception cref="ArgumentNullException"/>
        public BaseRestManager(RestCredential connectionParams, ISimpleLogger logger)
        {
            SetConnection(connectionParams);
            _logger = logger;
        }

        public Uri AppBaseUri { get; internal set; }
        public virtual HttpWebRequestExecutor CreateExecutor(string queryPath, bool enableTracing = false)
        {
            HttpWebRequestExecutor executor = new HttpWebRequestExecutor(AppBaseUri, queryPath, _logger);
            // possible to invoke WS without authentication headers if correct web.xml params are set on the server so Headers can be null
            if (ConnectionDetails.HasAuthorizationInfo)
                    executor.Headers[AuthorizationHeader] = ConnectionDetails.AuthorizationType + " " +
                                                 Convert.ToBase64String(Encoding.Default.GetBytes(ConnectionDetails.UserName + ":" + ConnectionDetails.SecurePassword.Decode()));
            executor.EnableTracing = enableTracing;
            return executor;
        }
        
        ///<exception cref = "RestException" />
        private void SetConnection(RestCredential connectionParams)
        {
            ConnectionDetails = connectionParams ?? throw new ArgumentNullException(nameof(connectionParams));
            ServicePointManager.DefaultConnectionLimit = 100;
            try
            {
                AppBaseUri = new Uri(String.Format("http://{0}:8080/dmrestservices", connectionParams.HostName.ToLower()));
            }
            catch (UriFormatException ex)
            {
                throw new RestException(Resources.ErrorInvalidHostname, ex);
            }
        }

        private readonly ISimpleLogger _logger;
    }
}

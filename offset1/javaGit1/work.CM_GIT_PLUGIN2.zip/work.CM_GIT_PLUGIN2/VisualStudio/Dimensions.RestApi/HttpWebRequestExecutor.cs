﻿using Serena.Common.Util.Logger;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Dimensions.Rest
{
    /// <summary>
    /// Dimensions web request executor
    /// <![CDATA[
    /// supported queries: 
    /// /products/QLARIUS/streams/VS_BRANCHA_STR/requests
    /// /requests/QLARIUS_CR_34
    /// /requests
    /// /users/DMSYS/requests]]>
    /// </summary>
    public class HttpWebRequestExecutor
    {
        public WebHeaderCollection Headers { get; }

        /// <param name="baseUrl">Base application URL string (e.g. http://host:[port]/app)</param>
        public HttpWebRequestExecutor(Uri baseUrl, string queryPath, ISimpleLogger logger)
        {
            _appBaseUrl = baseUrl;
            _queryPath = queryPath;
            _logger = logger;
            Headers = new WebHeaderCollection();
        }

        public bool EnableTracing { get; set; }

        public async Task<T> ExecuteAsync<T>(CancellationToken ct)
        {
            return await Task.Run(() => { return Execute<T>(ct); });
        }

        /// <summary>Executes a web request</summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        /// <exception cref="RestException"></exception>
        public T Execute<T>(CancellationToken ct)
        {
            Stopwatch watch = new Stopwatch();
            if (EnableTracing)
                watch.Start();

            string requestUriString = _appBaseUrl + _queryPath;

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestUriString);
                request.Method = WebRequestMethods.Http.Get;
                request.Headers = Headers;

                using (var response = GetResponse(request, ct))
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        if (response.StatusCode == HttpStatusCode.NoContent)
                            return default(T);
                        _logger.Warn(String.Format("Server response content type is: '{0}'", response.StatusCode.ToString()));
                        throw new RestException(response.StatusDescription);
                    }
                    using (Stream stream = response.GetResponseStream())
                    {
                        if (!response.ContentType.Contains("application/json"))
                        {
                            _logger.Warn(String.Format("Server response type is: '{0}'", response.ContentType));
                            throw new RestException(Resources.ServerResponseHasInvalidType);
                        }
                        if (EnableTracing)
                        {
                            _logger.Info("Request query with result of type '{0}' took {1}", typeof(T), watch.Elapsed);
                            watch.Restart();
                        }

                        ct.ThrowIfCancellationRequested();
                        T result = (T)((new DataContractJsonSerializer(typeof(T))).ReadObject(stream));

                        if (EnableTracing)
                            _logger.Info("Deserializing query response with result of type '{0}' took {1}", typeof(T), watch.Elapsed);
                        return result;
                    }
                }
            }
            catch (OperationCanceledException ex)
            {
                _logger.Info(ex.Message);
            }
            catch(WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    var response = ex.Response as HttpWebResponse;
                    if (response?.StatusCode == HttpStatusCode.Unauthorized)
                        throw new UnauthorizedException(ex.Message, ex);
                }
                throw new RestException(Resources.ErrorExecutingRequest, ex);
            }
            catch (Exception ex)
            {
                if (ex is SerializationException || ex is SecurityException
                    || ex is UriFormatException || ex is IOException)
                {
                    throw new RestException(Resources.ErrorExecutingRequest, ex);
                }
                throw;
            }
            return default(T);
        }

        /// <exception cref = "WebException" ></exception>
        private HttpWebResponse GetResponse(HttpWebRequest request, CancellationToken ct)
        {
            using (ct.Register(() => Task.Run(() => request.Abort()), useSynchronizationContext: true))
            {
                try
                {
                    return (HttpWebResponse)request.GetResponse();
                }
                catch (WebException)
                {
                    ct.ThrowIfCancellationRequested();
                    throw;
                }
            }
        }

        private readonly Uri _appBaseUrl;
        private readonly string _queryPath;
        private readonly ISimpleLogger _logger;
    }
}

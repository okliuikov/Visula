﻿using System;
using System.Linq;
using System.Net;
using System.Security;

namespace Dimensions.Rest
{
    /// <summary>
    /// User credential for executing web request
    /// </summary>
    public class RestCredential
    {
        public RestCredential()
        {
        }

        public RestCredential(string authority, string username)
        {
            Authority = authority;
            UserName = username;
        }

        public RestCredential(NetworkCredential credential)
        {
            Authority = credential.Domain;
            UserName = credential.UserName;
            try
            {
                SecurePassword = credential.SecurePassword;
            }
            catch (NotSupportedException)
            { // don't use if not supported
            }
        }

        /// <summary>
        /// Authority = [userinfo@]host[:port]
        /// </summary>
        public string Authority { get; set; }
        public string UserName { get; set; }
        public SecureString SecurePassword { get; set; }
        public string HostName
        {
            // TODO: omit userinfo
            get => Authority?.Split(':').FirstOrDefault();
        }
        public string AuthorizationType { get => "basic"; }
        public bool HasAuthorizationInfo
        {
            get => !String.IsNullOrEmpty(UserName) && (SecurePassword != null);
        }
        public NetworkCredential ToNetworkCredential()
        {
            return new NetworkCredential(UserName, SecurePassword, Authority);
        }
        public object Tag { get; set; }
    }

}

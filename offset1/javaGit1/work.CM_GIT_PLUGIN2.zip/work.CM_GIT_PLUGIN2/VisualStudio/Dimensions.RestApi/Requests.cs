﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Dimensions.Rest
{
    /// <summary>
    /// Request collection
    /// </summary>
    [DataContract]
    public class Requests : IEnumerable
    {
        public Requests()
        {
            RequestItems = new List<RequestItem>();
        }
        [DataMember(Name = "requests")]
        public ICollection<RequestItem> RequestItems { get; private set; }

        public IEnumerator GetEnumerator()
        {
            return RequestItems.GetEnumerator();
        }
    }

    /// <summary>
    /// Basic request information
    /// </summary>
    [DataContract]
    public class RequestItem
    {
        public readonly static RequestItem Empty = new RequestItem()
        {
            Uid = -1,
            Id = String.Empty
        };

        [DataMember(Name = "uid")]
        public int Uid { get; set; }
        [DataMember(Name = "name")]
        public string Id { get; set; }
        [DataMember(Name = "type")]
        public string Type { get; set; }
        [DataMember(Name = "title")]
        public string Title
        {
            get { return _title; }
            set
            {
                _title = String.IsNullOrWhiteSpace(value) ? Resources.NoTitle : value;
            }
        }
        [DataMember(Name = "status")]
        public string Status { get; set; }

        private string _title;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Dimensions.Rest
{
    /// <summary>
    /// Detailed request information
    /// </summary>
    [DataContract]
    public class RequestDetails : RequestItem
    {
        [DataMember(Name = "description")]
        public string Description { get; set; }
        [DataMember(Name = "number")]
        public string Number { get; set; }
        [DataMember(Name = "phase")]
        public string Phase { get; set; }
        [DataMember(Name = "product")]
        public string Product { get; set; }
        [DataMember(Name = "category")]
        public string Category { get; set; }
        [DataMember(Name = "lifecycle")]
        public string Lifecycle { get; set; }
        [DataMember(Name = "project")]
        public string Project { get; set; }
        [DataMember(Name = "created")]
        public TimeBy Created { get; set; }
        [DataMember(Name = "updated")]
        public virtual TimeBy Updated { get; set; }
        [DataMember(Name = "actioned")]
        public TimeBy Actioned { get; set; }
        [DataMember(Name = "nextStates")]
        public ICollection<string> NextStates { get; private set; }
        [DataMember(Name = "attributes")]
        public ICollection<AttributeItem> Attributes { get; private set; }
    }

    [DataContract]
    public class AttributeItem
    {
        [DataMember(Name = "name")]
        public string Name { get; set; }
        [DataMember(Name = "userPrompt")]
        public string UserPrompt { get; set; }
        [DataMember(Name = "dataType")]
        public string DataType { get; set; }
        [DataMember(Name = "type")]
        public string Type { get; set; }
        [DataMember(Name = "value")]
        public string Value { get; set; }
        [DataMember(Name = "multivalue")]
        public ICollection<string> MultiValue { get; private set; }
    }

    [DataContract]
    public class TimeBy
    {
        [DataMember(Name = "when")]
        public string When { get; set; }
        [DataMember(Name = "by")]
        public string By { get; set; }
    }
}

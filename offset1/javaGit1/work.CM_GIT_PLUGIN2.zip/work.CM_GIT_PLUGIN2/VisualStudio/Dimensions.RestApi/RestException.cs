﻿using System;
using System.Runtime.Serialization;

namespace Dimensions.Rest
{
    /// <summary>
    /// The exception that is thrown when a REST request fails
    /// </summary>
    [Serializable]
    public class RestException : Exception
    {
        public RestException()
        {
        }
        public RestException(string message)
            : base(message)
        {
        }
        public RestException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
        protected RestException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }

    /// <summary>
    /// Thrown when REST request fails with code 401
    /// </summary>
    [Serializable]
    public class UnauthorizedException : RestException
    {
        public UnauthorizedException()
        {
        }

        public UnauthorizedException(string message) : base(message)
        {
        }

        public UnauthorizedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UnauthorizedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}

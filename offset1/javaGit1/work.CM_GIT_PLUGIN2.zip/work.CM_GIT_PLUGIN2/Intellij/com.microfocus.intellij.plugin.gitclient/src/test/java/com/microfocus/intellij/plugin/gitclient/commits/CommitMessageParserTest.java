package com.microfocus.intellij.plugin.gitclient.commits;

import com.microfocus.intellij.plugin.gitclient.api.CommitFields;
import com.microfocus.intellij.plugin.gitclient.api.CommitMessageParser;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class CommitMessageParserTest {
    private static CommitMessageParser parserImpl;
    private static String endLine;

    @BeforeClass
    public static void setter() {
        parserImpl = new CommitMessageParserAppend();
        endLine = "\n";
    }

    @Test
    public void emptyCommitMessageTest() {
        String commitMessage = "";
        Map<CommitFields, String> parsed = parserImpl.parse(commitMessage);
        Assert.assertEquals(commitMessage, parserImpl.compound(parsed));
    }

    @Test
    public void simpleCommitMessageTest() {
        String commitMessage = "Simple commitTest";
        Map<CommitFields, String> parsed = parserImpl.parse(commitMessage);
        Assert.assertEquals(commitMessage, parserImpl.compound(parsed));
    }

    @Test
    public void encodingTest() {
        Map<CommitFields, String> map = new HashMap<CommitFields, String>() {{
            put(CommitFields.REQUEST_ID, "DEF12345");
            put(CommitFields.DESCRIPTION, "Some text what we did");
        }};
        String compounded = parserImpl.compound(map);
        Assert.assertEquals(map, parserImpl.parse(compounded));
    }

    @Test
    public void encodingWithEmptyRequestTest() {
        Map<CommitFields, String> map = new HashMap<CommitFields, String>() {{
            put(CommitFields.REQUEST_ID, "");
            put(CommitFields.DESCRIPTION, "Some text what we did");
        }};
        String compounded = parserImpl.compound(map);
        Assert.assertEquals(map, parserImpl.parse(compounded));
    }

    @Test
    public void encodingWithNonLiteralCharTest() {
        Map<CommitFields, String> map = new HashMap<CommitFields, String>() {{
            put(CommitFields.REQUEST_ID, "!@#$%^&*()");
            put(CommitFields.DESCRIPTION, "!@#$%^&*()Some text what we did!@#$%^&*()");
        }};
        String compounded = parserImpl.compound(map);
        Assert.assertEquals(map, parserImpl.parse(compounded));
    }

    @Test
    public void encodingWithBracketInDescCharTest() {
        Map<CommitFields, String> map = new HashMap<CommitFields, String>() {{
            put(CommitFields.REQUEST_ID, "DEF12345");
            put(CommitFields.DESCRIPTION, "Some [text] what we did during [request]");
        }};
        String compounded = parserImpl.compound(map);
        Assert.assertEquals(map, parserImpl.parse(compounded));
    }

    @Test
    public void encodingMultiLineCommentTest() {
        Map<CommitFields, String> map = new HashMap<CommitFields, String>() {{
            put(CommitFields.REQUEST_ID, "DEF12345");
            put(CommitFields.DESCRIPTION, "Some [text] " + endLine + " what we did during" + endLine + " [request]");
        }};
        String compounded = parserImpl.compound(map);
        Assert.assertEquals(map, parserImpl.parse(compounded));
    }

    @Test
    public void multiLineCommitTest() {
        String commitMessage = "Simple commitTest" + endLine + "Second line. " + endLine + endLine;
        Map<CommitFields, String> parsed = parserImpl.parse(commitMessage);
        Assert.assertEquals(commitMessage, parserImpl.compound(parsed));
    }

    @Test
    public void doubleRequestIdTest() {
        String commitMessage = "Simple commitTest" + endLine + " Second line. " + endLine + "[DEF123456]" + endLine + "[DEF123457]";
        Map<CommitFields, String> parsed = parserImpl.parse(commitMessage);
        Assert.assertEquals(commitMessage, parserImpl.compound(parsed));
    }

}

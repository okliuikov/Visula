package com.microfocus.intellij.plugin.gitclient.commits;

import com.microfocus.intellij.plugin.gitclient.api.CommitFields;
import com.microfocus.intellij.plugin.gitclient.api.CommitMessageParser;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CommitMessageParserAppend implements CommitMessageParser {
    String separator = "\n";

    @Override
    public Map<CommitFields, String> parse(String enteredMessage) {
        HashMap<CommitFields, String> result = new HashMap<>();

        //if last line like "[123FGH57]" then this is our format
        //then parse.

        List<String> lines = Arrays.stream(enteredMessage.split(separator)).filter(x -> !x.isEmpty()).collect(Collectors.toList());
        if (lines.size() == 0) {
            result.put(CommitFields.REQUEST_ID, "");
            result.put(CommitFields.DESCRIPTION, "");
        } else if (lines.get(lines.size() - 1).matches("^\\[.*\\]\\s*$")) {
            String lastLine = lines.get(lines.size() - 1);
            result.put(CommitFields.REQUEST_ID, lastLine.substring(1, lastLine.trim().length() - 1));
            String description = lines.stream().limit(lines.size() - 1).collect(Collectors.joining(separator));
            if (description.endsWith(separator)) {
                description = description.substring(0, description.length() - separator.length());
            }
            result.put(CommitFields.DESCRIPTION, description);
        } else {
            result.put(CommitFields.REQUEST_ID, "");
            result.put(CommitFields.DESCRIPTION, enteredMessage);
        }
        return result;
    }

    @Override
    public String compound(Map<CommitFields, String> fieldsStringMap) {
        StringBuilder builder = new StringBuilder();
        if (fieldsStringMap.containsKey(CommitFields.DESCRIPTION)) {
            builder.append(fieldsStringMap.get(CommitFields.DESCRIPTION));
        }
        if (fieldsStringMap.containsKey(CommitFields.REQUEST_ID) && !fieldsStringMap.get(CommitFields.REQUEST_ID).isEmpty()) {
            builder.append(separator).append("[").append(fieldsStringMap.get(CommitFields.REQUEST_ID)).append("]");
        }
        return builder.toString();
    }
}

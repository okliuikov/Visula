package com.microfocus.intellij.plugin.gitclient.settings;


import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import com.intellij.openapi.components.StoragePathMacros;
import com.intellij.openapi.project.Project;
import com.intellij.util.xmlb.XmlSerializerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@State(name = "DmProjectSettings", storages = {@Storage(StoragePathMacros.WORKSPACE_FILE)})
public class DmProjectSettings implements PersistentStateComponent<DmProjectSettings> {
    private String connectionName;
    private String server;
    private String dbName;
    private String dbConnection;
    private String requestRestLink;
    private String requestId;

    @Nullable
    public static DmProjectSettings getInstance(Project project) {
        return ServiceManager.getService(project, DmProjectSettings.class);
    }

    @Nullable
    @Override
    public DmProjectSettings getState() {
        return this;
    }

    @Override
    public void loadState(@NotNull DmProjectSettings state) {
        XmlSerializerUtil.copyBean(state, this);
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    public String getDbConnection() {
        return dbConnection;
    }

    public void setDbConnection(String dbConnection) {
        this.dbConnection = dbConnection;
    }

    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getRequestRestLink() {
        return requestRestLink;
    }

    public void setRequestRestLink(String requestRestLink) {
        this.requestRestLink = requestRestLink;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

}

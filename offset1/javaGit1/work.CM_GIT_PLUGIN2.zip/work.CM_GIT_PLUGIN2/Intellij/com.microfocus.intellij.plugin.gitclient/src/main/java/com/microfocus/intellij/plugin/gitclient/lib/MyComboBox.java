package com.microfocus.intellij.plugin.gitclient.lib;

import com.intellij.openapi.ui.ComboBox;

//addition inheritance level for creating handle
public class MyComboBox<T> extends ComboBox<T> {

}

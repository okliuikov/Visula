package com.microfocus.intellij.plugin.gitclient.lib;

import com.intellij.ide.DataManager;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.project.Project;

public class ContextHelper {
    public Project getProjectFromContext() {
        DataContext dataContext = DataManager.getInstance().getDataContext();
        return dataContext.getData(PlatformDataKeys.PROJECT);
    }
}

package com.microfocus.intellij.plugin.gitclient.requests;

import com.microfocus.common.plugin.credentials.Credential;
import com.microfocus.common.plugin.credentials.CredentialManager;
import com.microfocus.common.plugin.request.Request;
import com.microfocus.common.plugin.request.RequestConstants;
import com.microfocus.intellij.plugin.gitclient.lib.ContextHelper;
import com.microfocus.intellij.plugin.gitclient.repository.RepositoryHelper;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Rakovets Yurii
 * controller-level class
 * forms lists for loading time, eroor case, empry inbox case and usual inbox requests list
 */

public class RequestProvider {
    private RestHandler restHandler = new RestHandler();

    public ArrayList<Request> getLoadingRequests() {
        ArrayList<Request> list = new ArrayList<>();
        list.add(new Request(0L));
        Request loading = new Request(-1L);
        loading.setTitle(RequestConstants.LOADING_MESSAGE);
        list.add(loading);
        return list;
    }

    public ArrayList<Request> getErrorRequestList() {
        ArrayList<Request> list = new ArrayList<>();
        list.add(new Request(0L));
        Request loading = new Request(-2L);
        loading.setTitle(RequestConstants.FAILED_INBOX_MESSAGE);
        list.add(loading);
        return list;
    }

    public ArrayList<Request> getEmptyRequestList() {
        ArrayList<Request> list = new ArrayList<>();
        list.add(new Request(0L));
        Request loading = new Request(-3L);
        loading.setTitle(RequestConstants.EMPTY_INBOX_MESSAGE);
        list.add(loading);
        return list;
    }

    public ArrayList<Request> getFailedLoginRequestList() {
        ArrayList<Request> list = new ArrayList<>();
        list.add(new Request(0L));
        Request loading = new Request(-4L);
        loading.setTitle(RequestConstants.FAILED_LOGIN_INBOX_MESSAGE);
        list.add(loading);
        return list;
    }


    @NotNull
    public ArrayList<Request> getInboxRequests() {
        ArrayList<Request> requests = new ArrayList<>();

        String requestRestUrl = RepositoryHelper.getRequestRestUrl((new ContextHelper()).getProjectFromContext());
        if (requestRestUrl.isEmpty()) {
            return requests;
        }
        Request emptyRequest = new Request(0L);

        Credential credential = (new CredentialManager()).getCredential(requestRestUrl);
        if(credential.getUsername().isEmpty()){
            //if no credential
            requests = getFailedLoginRequestList();
            return requests;
        }
        ArrayList<Request> readRequests = null;
        try {
            readRequests = restHandler.getUserRequests(
                    RepositoryHelper.wrapServerToRequestLink(requestRestUrl),
                    credential.getUsername(), credential.getPassword());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (readRequests != null) {
            if (readRequests.size() != 0) {
                ArrayList<Request> requestsFromServer = new ArrayList<>();
                requestsFromServer.add(emptyRequest);
                requestsFromServer.addAll(readRequests);
                requests = requestsFromServer;
            } else {
                requests = getEmptyRequestList();
            }
        } else {
            requests = getErrorRequestList();
        }
        return requests;
    }

    public int getRequestIndexByName(String name, ArrayList<Request> requests) {
        for (int i = 1; i < requests.size(); i++) {
            if (requests.get(i).getName().equals(name)) {
                if (requests.get(i).getUid() > 0) {
                    return i;
                }
                return 0;
            }
        }
        return 0;
    }
}

package com.microfocus.intellij.plugin.gitclient.settings;


import com.intellij.openapi.options.SearchableConfigurable;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

public class DmConfigurable implements SearchableConfigurable {
    private DmSettingForm dmInstalledSettingForm = null;
    private DmProjectSettings dmProjectSettings;
    private Project project;

    public DmConfigurable(Project project) {
        this.project = project;
        this.dmProjectSettings = DmProjectSettings.getInstance(project);
    }

    @NotNull
    @Override
    public String getId() {
        return "com.microfocus.intellij.plugin.gitclient.settings.DmConfigurable";
    }

    @Nls(capitalization = Nls.Capitalization.Title)
    @Override
    public String getDisplayName() {
        return "Dimensions CM";
    }

    @Nullable
    @Override
    public JComponent createComponent() {
        dmInstalledSettingForm = new DmSettingForm(this.dmProjectSettings);
        dmInstalledSettingForm.setProject(project);
        return dmInstalledSettingForm.getRootPanel();
    }

    @Override
    public void disposeUIResources() {
        dmInstalledSettingForm.cancelChecker();
        dmInstalledSettingForm = null;
    }


    @Override
    public boolean isModified() {
        return dmInstalledSettingForm != null && dmInstalledSettingForm.isModified();
    }

    @Override
    public void apply() {
        this.dmProjectSettings.setConnectionName(dmInstalledSettingForm.getConnectionName());
        this.dmProjectSettings.setDbConnection(dmInstalledSettingForm.getDbConnection());
        this.dmProjectSettings.setDbName(dmInstalledSettingForm.getDbName());
        this.dmProjectSettings.setServer(dmInstalledSettingForm.getServer());
        this.dmProjectSettings.setRequestRestLink(dmInstalledSettingForm.getRequestRestLink());
    }

}

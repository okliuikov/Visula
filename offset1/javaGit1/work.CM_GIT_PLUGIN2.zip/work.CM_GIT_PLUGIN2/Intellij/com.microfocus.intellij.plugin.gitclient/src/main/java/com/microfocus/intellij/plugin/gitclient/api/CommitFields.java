package com.microfocus.intellij.plugin.gitclient.api;

public enum CommitFields {
    REQUEST_ID, DESCRIPTION
}

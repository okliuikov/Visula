package com.microfocus.intellij.plugin.gitclient.commits;

import com.intellij.openapi.project.Project;
import com.microfocus.common.plugin.request.Request;
import com.microfocus.intellij.plugin.gitclient.lib.MyComboBox;
import com.microfocus.intellij.plugin.gitclient.requests.RequestProvider;
import com.microfocus.intellij.plugin.gitclient.settings.DmProjectSettings;

import javax.swing.*;
import java.util.ArrayList;

public class CommitRequestForm {
    private JPanel mainPanel;
    private MyComboBox pickerBox;
    private Project project;

    private CommitRequestForm(Project project) {
        this.project = project;
    }

    static JPanel createPanel(Project project) {
        return (new CommitRequestForm(project)).getPanel();
    }

    private JPanel getPanel() {
        return mainPanel;
    }

    class LoadingInBackGround extends Thread {
        private MyComboBox<Request> pickerBox;

        public LoadingInBackGround(MyComboBox<Request> pickerBox) {
            super();
            this.pickerBox = pickerBox;
        }

        @Override
        public void run() {
            RequestProvider requestProvider = new RequestProvider();
            ArrayList<Request> requests = requestProvider.getInboxRequests();
            pickerBox.removeAllItems();
            for (Request request : requests) {
                pickerBox.addItem(request);
            }
            //store every changed value to project state
            //@see  https://www.jetbrains.org/intellij/sdk/docs/basics/persisting_state_of_components.html
            pickerBox.addActionListener(e -> {
                Request selected = (Request) ((MyComboBox) e.getSource()).getSelectedItem();
                if (selected != null) {
                    DmProjectSettings.getInstance(project).setRequestId(selected.getName());
                }
            });
            pickerBox.setSelectedIndex(requestProvider
                    .getRequestIndexByName(DmProjectSettings.getInstance(project).getRequestId(), requests));
        }
    }

    @SuppressWarnings("unchecked")
    private void createUIComponents() {
        ArrayList<Request> requests = (new RequestProvider()).getLoadingRequests();
        pickerBox = new MyComboBox<Request>();
        //pickerBox.
        for (Request request : requests) {
            pickerBox.addItem(request);
        }
        LoadingInBackGround loading = new LoadingInBackGround(pickerBox);
        // it doesn't work
        // TODO look for thread termination
        /*
        pickerBox.addAncestorListener(new AncestorListener() {
            @Override
            public void ancestorAdded(AncestorEvent event) {
            }

            @Override
            public void ancestorRemoved(AncestorEvent event) {
                loading.interrupt();
            }

            @Override
            public void ancestorMoved(AncestorEvent event) {
            }
        });
        */
        loading.start();
    }
}

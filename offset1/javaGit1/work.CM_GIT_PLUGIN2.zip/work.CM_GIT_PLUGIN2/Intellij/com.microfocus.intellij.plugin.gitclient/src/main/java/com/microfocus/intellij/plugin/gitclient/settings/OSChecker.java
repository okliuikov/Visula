package com.microfocus.intellij.plugin.gitclient.settings;

/*
 * @author Rakovets Yurii
 * @brief define current OS
 */

public class OSChecker {
    enum OSType {
        WINDOWS, MACOS, UNIX, UNKNOWN
    }

    public OSType getCurrentOS() {
        String osName = System.getProperty("os.name").toLowerCase();
        if (osName.contains("win")) {
            return OSType.WINDOWS;
        }
        if (osName.contains("mac")) {
            return OSType.MACOS;
        }
        if (osName.contains("nix") || osName.contains("nux") || osName.contains("aix")) {
            return OSType.UNIX;
        }
        return OSType.UNKNOWN;
    }

}

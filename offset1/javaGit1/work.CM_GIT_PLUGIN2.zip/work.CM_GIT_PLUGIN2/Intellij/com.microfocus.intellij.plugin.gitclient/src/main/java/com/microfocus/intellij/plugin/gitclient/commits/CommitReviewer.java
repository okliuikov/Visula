package com.microfocus.intellij.plugin.gitclient.commits;

import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.changes.LocalChangeList;
import com.intellij.openapi.vcs.changes.ui.CommitMessageProvider;
import com.microfocus.intellij.plugin.gitclient.api.CommitFields;
import com.microfocus.intellij.plugin.gitclient.api.CommitMessageParser;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

public class CommitReviewer implements CommitMessageProvider {
    @Nullable
    @Override
    public String getCommitMessage(LocalChangeList forChangelist, Project project) {
        if (forChangelist.getComment() == null)
            return "";
        String parsedDescription = "";
        try {
            CommitMessageParser impl = ServiceManager.getService(CommitMessageParser.class);
            Map<CommitFields, String> parsedMap = impl.parse(forChangelist.getComment());
            parsedDescription = parsedMap.get(CommitFields.DESCRIPTION);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return parsedDescription;
    }
}

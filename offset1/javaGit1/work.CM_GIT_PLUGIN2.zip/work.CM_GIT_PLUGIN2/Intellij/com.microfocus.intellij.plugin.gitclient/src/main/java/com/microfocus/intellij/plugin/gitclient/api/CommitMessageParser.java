package com.microfocus.intellij.plugin.gitclient.api;

import java.util.Map;

public interface CommitMessageParser {
    Map<CommitFields, String> parse(String enteredMessage);

    String compound(Map<CommitFields, String> fieldsStringMap);

}

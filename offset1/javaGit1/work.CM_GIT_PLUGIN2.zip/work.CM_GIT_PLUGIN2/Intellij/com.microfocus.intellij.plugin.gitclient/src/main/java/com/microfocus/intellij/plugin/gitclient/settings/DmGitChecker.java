package com.microfocus.intellij.plugin.gitclient.settings;

import git4idea.config.GitExecutableManager;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DmGitChecker {

    public boolean isDmClientInstalled() {
        if (getDmClientFilePath() != null) {
            return getDmClientFilePath().toFile().exists();
        }
        return false;
    }

    public Path getDmClientFilePath() {
        Path pathToGit = Paths.get(GitExecutableManager.getInstance().getPathToGit());
        switch (new OSChecker().getCurrentOS()){
            case WINDOWS:
                if (pathToGit != null && !pathToGit.toString().isEmpty()) {
                    return (new File(pathToGit.getParent().getParent()
                            + "\\mingw64\\libexec\\git-core\\" + "git-remote-dimensions")).toPath();
                }
                break;
            case UNIX:
            case MACOS:
                return (new File("/usr/lib/git-core/" + "git-remote-dimensions")).toPath();
        }
        return null;
    }
}

package com.microfocus.intellij.plugin.gitclient.requests;

import com.intellij.openapi.components.ServiceManager;
import com.microfocus.common.plugin.request.Request;
import com.microfocus.common.plugin.request.RequestConstants;
import com.microfocus.common.plugin.rest.JsonRequestParser;

import java.io.IOException;
import java.util.ArrayList;


public class RestHandler {

    public ArrayList<Request> getUserRequests(String url, String username, String password) throws IOException {
        JsonRequestParser parser = ServiceManager.getService(JsonRequestParser.class);
        RequestReader requestReader = ServiceManager.getService(RequestReader.class);
        return requestReader.getRequests(url, username, password, RequestConstants.Mode.USER_INBOX,
                parser);
    }

}
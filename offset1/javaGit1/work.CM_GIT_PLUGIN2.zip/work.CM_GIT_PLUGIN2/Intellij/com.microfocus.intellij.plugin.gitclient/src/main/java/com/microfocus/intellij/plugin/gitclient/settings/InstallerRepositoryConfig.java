package com.microfocus.intellij.plugin.gitclient.settings;

import java.util.HashMap;
import java.util.Map;

/*
 * @author Rakovets Yurii
 * class for storage link to Dimensions Git Client repository
 * @example String dmInstallerUrl = InstallerRepositoryConfig.repositoryHostLink
 *      + InstallerRepositoryConfig.installers.get(OSChecker.getCurrentOS())
 *      + InstallerRepositoryConfig.suffix;
 */

public class InstallerRepositoryConfig {
    static final String repositoryHostLink = "https://github.com/yrakovets1/";
    static final Map<OSChecker.OSType, String> installers = new HashMap<OSChecker.OSType, String>() {{
        put(OSChecker.OSType.WINDOWS, "com.microfocus.dimension-git-win-installer");
        put(OSChecker.OSType.MACOS, "com.microfocus.dimension-git-macos-installer");
        put(OSChecker.OSType.UNIX, "com.microfocus.dimension-git-linux-installer");
        put(OSChecker.OSType.UNKNOWN, "com.microfocus.dimension-git-win-installer");
    }};
    static final String suffix = "/releases/latest";
}

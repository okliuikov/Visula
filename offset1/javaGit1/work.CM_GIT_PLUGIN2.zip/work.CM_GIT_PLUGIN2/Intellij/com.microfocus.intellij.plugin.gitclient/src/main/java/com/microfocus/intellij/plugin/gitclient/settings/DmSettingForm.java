package com.microfocus.intellij.plugin.gitclient.settings;

import com.intellij.openapi.project.Project;
import com.intellij.ui.JBColor;
import com.microfocus.intellij.plugin.gitclient.lib.JHyperlinkLabel;
import git4idea.commands.Git;
import git4idea.commands.GitCommandResult;
import git4idea.config.GitExecutableManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

/*
 * @author Rakovets Yurii
 */

public class DmSettingForm {
    private JPanel mainPanel;
    private JTextField connectionNameTextField;
    private JTextField serverTextField;
    private JTextField dbNameTextField;
    private JTextField dbConnectionTextField;
    private JTextField requestRestLinkField;
    private JButton testButton;
    private JLabel installedDimensionsLabel;
    private JHyperlinkLabel hl;
    private JPanel notInstalledDmPanel;
    private JLabel addMoreConnectionsLabel;
    private String myConnectionName;
    private String myServer;
    private String myDbName;
    private String myDbConnection;
    private String myUser;
    private MyTask myTask;

    private Color defaultColor;
    private Font defaultFont;
    private Project project;


    DmSettingForm(DmProjectSettings settings) {
        // $$$setupUI$$$ will be executed here (inserted automatically)
        testButton.addActionListener(e -> {
            String url = "dimensions://" + getServer() + "/" + getDbConnection() + "@" + getDbName() + "/qlarius/java_brancha_prj";

            GitCommandResult result = Git.getInstance().lsRemote(project, new File("."), url); //"dimensions://stl-ta-vcw8-08/cm_typical@dim12/qlarius/java_brancha_prj");
            if (result.success()) {
                JOptionPane.showMessageDialog(null, "Connecion test successed!");
            } else {
                JOptionPane.showMessageDialog(null, "Error!");
            }
        });
        myConnectionName = settings.getConnectionName();
        myServer = settings.getServer();
        myDbName = settings.getDbName();
        myDbConnection = settings.getDbConnection();
        myUser = settings.getRequestRestLink();

        connectionNameTextField.setText(myConnectionName);
        serverTextField.setText(myServer);
        dbNameTextField.setText(myDbName);
        dbConnectionTextField.setText(myDbConnection);
        requestRestLinkField.setText(myUser);

        defaultColor = installedDimensionsLabel.getForeground();
        defaultFont = installedDimensionsLabel.getFont();

        if ((new DmGitChecker()).isDmClientInstalled()) {
            setInstalledUI();
        } else {
            setNotInstalledUI();
        }
        addMoreConnectionsLabel.setForeground(JBColor.BLUE);
    }

    JComponent getRootPanel() {
        return mainPanel;
    }

    boolean isModified() {
        return !connectionNameTextField.getText().equals(myConnectionName)
                || !serverTextField.getText().equals(myServer)
                || !dbNameTextField.getText().equals(myDbName)
                || !dbConnectionTextField.getText().equals(myDbConnection)
                || !requestRestLinkField.getText().equals(myUser);
    }

    String getConnectionName() {
        return connectionNameTextField.getText();
    }

    String getDbConnection() {
        return dbConnectionTextField.getText();
    }

    String getDbName() {
        return dbNameTextField.getText();
    }

    String getServer() {
        return serverTextField.getText();
    }

    String getRequestRestLink() {
        return requestRestLinkField.getText();
    }

    private void createUIComponents() {
        hl = new JHyperlinkLabel("");
    }

    public void setNotInstalledUI() {
        Path pathToGit = Paths.get(GitExecutableManager.getInstance().getPathToGit());
        installedDimensionsLabel.setForeground(JBColor.RED);
        installedDimensionsLabel.setFont(new Font(null, Font.BOLD, 12));
        if (pathToGit != null && !pathToGit.toString().isEmpty()) {
            String s = "The required component Dimensions Git Client is not installed.";

            String dmInstallerUrl = InstallerRepositoryConfig.repositoryHostLink
                    + InstallerRepositoryConfig.installers.get(new OSChecker().getCurrentOS())
                    + InstallerRepositoryConfig.suffix;

            hl.setUrl(dmInstallerUrl);
            hl.setText("Download");
            installedDimensionsLabel.setText(s);
        } else {
            installedDimensionsLabel.setText("The required components Git and Dimensions Git Client are not installed.");
        }
        myTask = new MyTask();
        myTask.start();
    }

    public void cancelChecker() {
        if (myTask != null && myTask.isAlive()) {
            myTask.interrupt();
        }
    }

    public void setProject(Project project) {
        this.project = project;
    }

    class MyTask extends Thread {
        @Override
        public void run() {
            while (true) {
                if ((new DmGitChecker()).isDmClientInstalled()) {
                    setInstalledUI();
                    break;
                }
                try {
                    this.join(2000);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }
    }

    private void setInstalledUI() {
        hl.setUrl("");
        hl.setText("");
        installedDimensionsLabel.setText("Dimensions Git Client is installed at: " + GitExecutableManager.getInstance().getPathToGit());
        installedDimensionsLabel.setForeground(defaultColor);
        installedDimensionsLabel.setFont(defaultFont);
    }

}

package com.microfocus.intellij.plugin.gitclient.lib;

/*
 * @see http://www.java2s.com/Tutorial/Java/0240__Swing/HyperlinkLabel.htm
 */

import com.intellij.ui.JBColor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class JHyperlinkLabel extends JLabel {
    private Color underlineColor = null;
    private String url = null;

    public JHyperlinkLabel(String label) {
        super(label);

        setForeground(JBColor.BLUE);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        addMouseListener(new HyperlinkLabelMouseAdapter());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(underlineColor == null ? getForeground() : underlineColor);

        Insets insets = getInsets();

        int left = insets.left;
        if (getIcon() != null)
            left += getIcon().getIconWidth() + getIconTextGap();

        g.drawLine(left, getHeight() - 1 - insets.bottom, (int) getPreferredSize().getWidth() - insets.right, getHeight() - 1 - insets.bottom);
    }

    public class HyperlinkLabelMouseAdapter extends MouseAdapter {
        @Override
        public void mouseClicked(MouseEvent e) {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                try {
                    Desktop.getDesktop().browse(new URI(getUrl()));
                } catch (IOException | URISyntaxException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    public Color getUnderlineColor() {
        return underlineColor;
    }

    public void setUnderlineColor(Color underlineColor) {
        this.underlineColor = underlineColor;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        if (this.url != null) {
            return this.url;
        }
        return this.getText();
    }
}
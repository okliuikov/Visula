package com.microfocus.intellij.plugin.gitclient.repository;

import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Rakovets Yurii
 * class contains method for getting dimendions server from remote links
 */

public class RepositoryHelper {
    @NotNull
    public static String getRequestRestUrl(Project project) {
        try {
            Map<String, String> remotes = getRemotes(project);
            if (remotes.containsKey("origin") && remotes.get("origin").startsWith("dimensions:")) {
                return parseServerName(remotes.get("origin"));
            }
            Optional<Map.Entry<String, String>> dmRemote = remotes.entrySet()
                    .stream()
                    .filter(x -> x.getValue().startsWith("dimensions:"))
                    .findFirst();
            if (dmRemote.isPresent()) {
                return parseServerName(dmRemote.get().getValue());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String wrapServerToRequestLink(String server) {
        return "http://" + server + ":8080";
    }

    private static String parseServerName(String dimensionFullUrl) {
        return Arrays.stream(dimensionFullUrl.split("/"))
                .filter(x -> !x.isEmpty())
                .collect(Collectors.toList())
                .get(1);
    }

    @NotNull
    private static Map<String, String> getRemotes(Project project) throws IOException {
        Map<String, String> map = new HashMap<>();
        String dir = project.getBasePath();
        File gitConfigFile = new File(dir + "/.git/config");
        if (!gitConfigFile.exists()) {
            return map;
        }
        FileReader fileReader = new FileReader(gitConfigFile);

        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line;
        String remoteBlock = "";
        // don't use git4idea classes according to bad performance
        while ((line = bufferedReader.readLine()) != null) {
            // tag = "[remote"; tag.length()
            if (line.startsWith("[remote")) {
                // e.g. [remote "origin"] => origin
                remoteBlock = line.substring(9, line.length() - 2);
            } else if (line.startsWith("[")) {
                remoteBlock = "";
            }
            if (line.startsWith("\turl = ") && !remoteBlock.isEmpty()) {
                map.put(remoteBlock, line.substring(7));
            }
        }

        bufferedReader.close();
        return map;
    }
}

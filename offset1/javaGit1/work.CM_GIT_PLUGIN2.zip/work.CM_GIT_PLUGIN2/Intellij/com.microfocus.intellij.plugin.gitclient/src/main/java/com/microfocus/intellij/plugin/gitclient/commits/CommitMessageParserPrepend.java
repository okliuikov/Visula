package com.microfocus.intellij.plugin.gitclient.commits;

import com.microfocus.intellij.plugin.gitclient.api.CommitFields;
import com.microfocus.intellij.plugin.gitclient.api.CommitMessageParser;

import java.util.HashMap;
import java.util.Map;

public class CommitMessageParserPrepend implements CommitMessageParser {
    private static String endLine = "\n";

    public Map<CommitFields, String> parse(String enteredMessage) {
        HashMap<CommitFields, String> result = new HashMap<>();

        // only parse when in ours format like "[123FGH57]" then this is our format
        if (!enteredMessage.isEmpty() && enteredMessage.split(endLine)[0].matches("^\\[.*\\]\\s*$")) {

            String firstLine = enteredMessage.split(endLine)[0];
            result.put(CommitFields.REQUEST_ID, firstLine.substring(1, firstLine.trim().length() - 1));
            result.put(CommitFields.DESCRIPTION, enteredMessage.substring(firstLine.length() + 1));
        } else {
            result.put(CommitFields.REQUEST_ID, "");
            result.put(CommitFields.DESCRIPTION, enteredMessage);
        }
        return result;
    }

    public String compound(Map<CommitFields, String> fieldsStringMap) {
        StringBuilder builder = new StringBuilder();
        if (fieldsStringMap.containsKey(CommitFields.REQUEST_ID) && !fieldsStringMap.get(CommitFields.REQUEST_ID).isEmpty()) {
            builder.append("[").append(fieldsStringMap.get(CommitFields.REQUEST_ID)).append("]").append(endLine);
        }
        if (fieldsStringMap.containsKey(CommitFields.DESCRIPTION)) {
            builder.append(fieldsStringMap.get(CommitFields.DESCRIPTION));
        }
        return builder.toString();
    }
}

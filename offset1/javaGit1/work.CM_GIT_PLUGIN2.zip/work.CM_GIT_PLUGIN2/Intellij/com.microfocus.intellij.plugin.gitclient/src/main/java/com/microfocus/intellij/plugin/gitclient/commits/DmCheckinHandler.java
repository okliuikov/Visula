package com.microfocus.intellij.plugin.gitclient.commits;

import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.ui.Splitter;
import com.intellij.openapi.ui.VerticalFlowLayout;
import com.intellij.openapi.vcs.CheckinProjectPanel;
import com.intellij.openapi.vcs.changes.LocalChangeList;
import com.intellij.openapi.vcs.changes.ui.EditChangelistSupport;
import com.intellij.openapi.vcs.checkin.CheckinHandler;
import com.intellij.openapi.vcs.ui.CommitMessage;
import com.intellij.ui.EditorTextField;
import com.intellij.util.Consumer;
import com.microfocus.intellij.plugin.gitclient.api.CommitFields;
import com.microfocus.intellij.plugin.gitclient.api.CommitMessageParser;
import com.microfocus.intellij.plugin.gitclient.lib.ContextHelper;
import com.microfocus.intellij.plugin.gitclient.repository.RepositoryHelper;
import com.microfocus.intellij.plugin.gitclient.settings.DmProjectSettings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Field;
import java.util.HashMap;

/* Handler for Commit Window
 * CheckinHandler allows to perform action before commit
 * EditChangelistSupport allows to extend UI at commit window
 */
public class DmCheckinHandler extends CheckinHandler implements EditChangelistSupport {
    private static CheckinProjectPanel panel;
    private static JPanel requestPanel;

    DmCheckinHandler() {
    }

    @Override
    public void installSearch(EditorTextField name, EditorTextField comment) {
        String requestRestUrl = RepositoryHelper.getRequestRestUrl((new ContextHelper()).getProjectFromContext());
        if (!requestRestUrl.isEmpty()) {
            injectPanel();
        }
    }

    private void injectPanel() {
        Splitter splitter = null;
        if (panel.getComponent() instanceof Splitter) {
            splitter = (Splitter) panel.getComponent();
        } else {
            try {
                Field mySplitter = panel.getClass().getDeclaredField("mySplitter");
                mySplitter.setAccessible(true);
                splitter = (Splitter) mySplitter.get(panel);
            } catch (ReflectiveOperationException e) {
                e.printStackTrace();
            }
        }
        if (splitter != null) {
            CommitMessage commitMessage = (CommitMessage) splitter.getSecondComponent();
            JPanel panel = new JPanel();
            panel.setLayout(new VerticalFlowLayout(true, true));
            requestPanel = CommitRequestForm.createPanel(DmCheckinHandler.panel.getProject());
            panel.add(requestPanel);
            Component commitTextField = commitMessage.getComponent(0);
            panel.add(commitTextField);
            commitMessage.add(panel, 0);
        }
    }

    @Override
    public ReturnResult beforeCheckin() {
        String requestId = DmProjectSettings.getInstance(panel.getProject()).getRequestId();
        if (requestId == null || requestId.isEmpty()) {
            return ReturnResult.COMMIT;
        }
        panel.setCommitMessage(processCommitMessage(panel.getCommitMessage(), requestId));
        return ReturnResult.COMMIT;
    }

    private String processCommitMessage(String commitText, String requestId) {
        try {
            CommitMessageParser impl = ServiceManager.getService(CommitMessageParser.class);
            String purified = impl.parse(commitText).get(CommitFields.DESCRIPTION);
            return impl.compound(new HashMap<CommitFields, String>() {{
                put(CommitFields.REQUEST_ID, requestId);
                put(CommitFields.DESCRIPTION, purified);
            }});
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return "";
    }

    @Override
    public Consumer<LocalChangeList> addControls(JPanel bottomPanel, @Nullable LocalChangeList initial) {
        return null;
    }

    @Override
    public void changelistCreated(LocalChangeList changeList) {

    }

    void setPanel(@NotNull CheckinProjectPanel panel) {
        DmCheckinHandler.panel = panel;
    }
}

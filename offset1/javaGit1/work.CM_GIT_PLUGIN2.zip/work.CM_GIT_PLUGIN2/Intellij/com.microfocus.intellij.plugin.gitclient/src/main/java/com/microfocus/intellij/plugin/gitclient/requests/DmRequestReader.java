package com.microfocus.intellij.plugin.gitclient.requests;

import com.microfocus.common.plugin.request.Request;
import com.microfocus.common.plugin.request.RequestConstants;
import com.microfocus.common.plugin.rest.JsonRequestParser;
import org.apache.commons.codec.binary.Base64;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DmRequestReader implements RequestReader {
    @Override
    public ArrayList<Request> getRequests(String url, String username, String password, RequestConstants.Mode mode,
                                          JsonRequestParser jsonRequestParser) throws IOException {

        URL linkUrl = new URL(url + RequestConstants.URL_PATHES.get(mode).replace("{username}", username));
        HttpURLConnection con = (HttpURLConnection) linkUrl.openConnection();
        con.setRequestProperty("Authorization", "basic " +
                new String(Base64.encodeBase64((username + ":" + password).getBytes())));

        ArrayList<Request> requests;

        try {
            requests = jsonRequestParser.readJson(con.getInputStream());
        } finally {
            con.disconnect();
        }

        return requests;
    }
}

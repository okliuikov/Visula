package com.microfocus.intellij.plugin.gitclient.requests;

import com.microfocus.common.plugin.request.Request;
import com.microfocus.common.plugin.request.RequestConstants;
import com.microfocus.common.plugin.rest.JsonRequestParser;

import java.io.IOException;
import java.util.ArrayList;

public interface RequestReader {
    ArrayList<Request> getRequests(String url, String username, String password, RequestConstants.Mode mode,
                                   JsonRequestParser jsonRequestParser) throws IOException;
}

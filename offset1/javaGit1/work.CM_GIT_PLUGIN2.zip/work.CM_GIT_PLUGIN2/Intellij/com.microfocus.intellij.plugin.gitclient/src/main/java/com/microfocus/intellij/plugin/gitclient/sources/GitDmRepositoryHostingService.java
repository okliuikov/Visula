package com.microfocus.intellij.plugin.gitclient.sources;

import com.intellij.dvcs.hosting.RepositoryListLoader;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import git4idea.remote.GitRepositoryHostingService;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class GitDmRepositoryHostingService extends GitRepositoryHostingService {
    private RepositoryListLoader repositoryListLoader = new RepositoryListLoader() {
        @Override
        public boolean isEnabled() {
            return true;
        }

        @Override
        public List<String> getAvailableRepositories(@NotNull ProgressIndicator progressIndicator) {
            return Arrays.asList("dimensions://stl-ta-vcw8-08/cm_typical@dim12/qlarius/java_brancha_str", "dimensions://stl-ta-vcw8-08/cm_typical@dim12/qlarius/java_brancha_prj", "dimensions://stl-ta-vcw8-07/cm_typical@dim12/qlarius/mainline_java_str", "dimensions://stl-ta-vcw8-07/cm_typical@dim12/qlarius/mainline_java_prj", "dimensions://stl-ta-vcw8-07/cm_typical@dim12/qlarius/mainline_vs_prj", "dimensions://stl-ta-vcw8-07/cm_typical@dim12/qlarius/vs_brancha_str");
        }

        @Override
        public Result getAvailableRepositoriesFromMultipleSources(@NotNull ProgressIndicator progressIndicator) {
            return new Result(getAvailableRepositories(progressIndicator), Collections.emptyList());
        }
    };

    @Override
    @NotNull
    public String getServiceDisplayName() {
        return "Dimensions";
    }

    public RepositoryListLoader getRepositoryListLoader(@NotNull Project project) {
        return repositoryListLoader;
    }

}

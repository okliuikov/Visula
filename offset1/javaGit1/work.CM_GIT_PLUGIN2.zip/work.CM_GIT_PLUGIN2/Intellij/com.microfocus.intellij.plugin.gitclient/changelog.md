# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3] - 2019-03-19
### Added
- Possibility to select related request from list got from dimensions request server
- Reading server links from remotes
- Storing username and password at credential services and reading it

## [0.2] - 2019-03-10
### Added
- Dimensions Git Client detecting.

### Fixed
- Request ID behaviour

## [0.1] - 2019-01-16
### Added
- Request ID field and record it to commit message
- Stored links for selection at clone dialog
- Setting page

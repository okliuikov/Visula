# Dimensions CM plugin

Supports Dimensions Git Client (DGC) integration. DGC is an implementation for dimensions:// remote protocol to allow Git work with Dimensions repositories.

## Version 
0.3.1

## Intellij version compatible 
180.0 - 191.*

## Building 

Building plugin needs installed **JDK**.
If it isn't, download and install JDK and set *%JAVA_HOME%* system variable to installed path.   
You can see instruction here: [jdk-instruction]

Open project in Intellij. You need Gradle plugin installed and active (it is so by default). Open Gradle panel [Main menu]-View/[Tool Windows]/Gradle. At the Gradle panel at left part of screen select Tasks/build/build and run. 

Or:

Open Command Line at project directory and type "gradlew build".

Or:

Run **build.bat** at level up directory. 


Built ZIP-file will be at build\distribution\com.microfocus.intellij.plugin.gitclient-*{version}*.zip

## Plugin installation

Open Intellij Settings. Plugin section. Click gearwheel-pic, select Install from disc. At file selection dialog pick com.microfocus.intellij.plugin.gitclient-*{version}*.zip file.


**Note!**
First building needs libraries downloading to local maven repository, so it can get a long time.

[jdk-instruction]: https://docs.oracle.com/cd/E19182-01/820-7851/inst_cli_jdk_javahome_t/
# Dimensions CM extension

Use [Dimensions CM](https://www.microfocus.com/en-us/products/dimensions-cm/overview) source control keeping Git manner.

## Requirements

- Git Client 
- Dimensions CM Git Client

## Release Notes

Users appreciate release notes as you update your extension.

### 1.0.0

Initial release of Dimensions CM Extension



-----------------------------------------------------------------------------------------------------------
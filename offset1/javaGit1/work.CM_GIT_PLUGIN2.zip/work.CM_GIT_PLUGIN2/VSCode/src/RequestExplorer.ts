import * as vscode from 'vscode';
import { Request } from "./services/Requests";
import { getGitScm } from './git/GitScm';
import { RequestModel } from './RequestModel';
/**
 * Request node
 */
export interface RequestNode {
	label?: string;
	request?: Request;
}
/**
 * class RequestTreeDataProvider
 */
export class RequestTreeDataProvider implements vscode.TreeDataProvider<RequestNode>, vscode.Disposable {
	private _onDidChangeTreeData: vscode.EventEmitter<any> = new vscode.EventEmitter<any>();
	readonly onDidChangeTreeData: vscode.Event<any> = this._onDidChangeTreeData.event;

	constructor(private readonly model: RequestModel) { }
	
	public async copyRequest(node: RequestNode) {		
		const git = getGitScm();
		let repo = git.getRepository();
		if (repo && node.request) {
			let addingRequest = `[${node.request.name}]`;
			let comment = repo.inputBox.value;
			
			if (comment.indexOf(addingRequest) >= 0) {
				return;
			}

			if (comment.length > 0 && !comment.endsWith('\n')) {
				comment += '\n';
			}
			comment += addingRequest;
			repo.inputBox.value = comment;

		}
	}

	public setDefaultRequest() {
		let strRequests = new Array<vscode.QuickPickItem>();
		this.model.loadUserRequests().then((userRequests) => {
			
			userRequests.forEach(element => {				
				strRequests.push({label: `${element.name} ${element.title}`, description :element.status});
			});
			vscode.window.showQuickPick(strRequests, {placeHolder : 'Select a default request'}).then((item) => {
				if (item) {
					let pickedItem = item as vscode.QuickPickItem;
					let spacePos = pickedItem.label.indexOf(' ');
					if (spacePos <= 0) {
						return;
					}
					let strRequest = pickedItem.label.substr(0, spacePos);
					if (!strRequest) {
						return;
					}
					for (let element of userRequests) {
					 	if (element.name === strRequest) {
					 		this.model.setRequest(element);
					 		this.refresh();
							break;
						}
					}
				}
			});
		 }).catch((reason) => {
			 vscode.window.showWarningMessage(reason as string);
		 });
	 }
	
	public refresh(): any {
		this._onDidChangeTreeData.fire();
	}


	public getTreeItem(node: RequestNode): vscode.TreeItem {
		return {
			label: (node.request) ? `[${node.request.name}] ${node.request.title}` : node.label,
			collapsibleState: vscode.TreeItemCollapsibleState.None
		};
	}

	public getChildren(element?: RequestNode): RequestNode[] | Thenable<RequestNode[]> {
		let requestNodes = new  Array<RequestNode>();
		this.model.Requests.then((reqs) => {
			if (reqs.length > 0) {
				reqs.forEach(req => {
					requestNodes.push({request: req});
				});
			}
			else {
				requestNodes.push({label: "<Select default request>"});
			}
		});
		return requestNodes;
	}
    
    public dispose() {
        // TODO: dispose me     
    }
}
/**
 * class RequestExplorer
 * A widget class provides the UI for managing default request
 */
export class RequestExplorer implements vscode.Disposable {
    private _disposables: vscode.Disposable[] = [];
	constructor(context: vscode.ExtensionContext) {
		/* Please note that login information is hardcoded only for this example purpose and recommended not to do it in general. */
		const recModel = new RequestModel('stl-ta-vcw12-8', 'dmsys', 'dmsys_test');
        const treeDataProvider = new RequestTreeDataProvider(recModel);
        this._disposables.push(recModel, treeDataProvider);
		

		context.subscriptions.push(vscode.window.createTreeView('dimensionsRequest', { treeDataProvider }));

	    context.subscriptions.push(vscode.commands.registerCommand('dimensionsRequest.SetDefaultRequest', () => treeDataProvider.setDefaultRequest()));
	    context.subscriptions.push(vscode.commands.registerCommand('dimensionsRequest.CopyRequest', (node: RequestNode) => treeDataProvider.copyRequest(node)));
    }
    public dispose() {
        this._disposables.forEach(d => d.dispose());
        this._disposables = [];
    }
}
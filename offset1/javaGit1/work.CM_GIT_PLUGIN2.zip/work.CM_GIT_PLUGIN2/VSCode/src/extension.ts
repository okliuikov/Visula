// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';
import { CmGitClient } from './git/CmGitClient';
import { RequestExplorer } from './RequestExplorer';
import { getGitScm } from './git/GitScm';

// this method is called when your extension is activated
// your extension is activated the very first time the command is executed
export async function activate(context: vscode.ExtensionContext) {

	// Use the console to output diagnostic information (console.log) and errors (console.error)
	// This line of code will only be executed once when your extension is activated
		console.log('Extension "Dimensions Git Client" is now active!');

		try {
			await CmGitClient.initialize();

			if (!CmGitClient.installed()) {
				CmGitClient.notifyNotInstalled();
			}
			const git = getGitScm();
			await git.initialize();
            let re = new RequestExplorer(context);
            context.subscriptions.push(re);
		}
		catch (ex) {			
			await vscode.window.showErrorMessage(ex.message);
		}
}

// this method is called when your extension is deactivated
export function deactivate() {}

 
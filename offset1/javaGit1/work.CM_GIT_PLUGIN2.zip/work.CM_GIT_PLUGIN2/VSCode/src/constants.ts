'use strict';

export const extensionId = 'dimensionscm';

'use strict';
import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { findGitPath, GitLocation } from './locator';

let gitInfo: GitLocation;
let gitRoot: string;
let cmGitInstalled: boolean = false;

export class CmGitClient {

    static async initialize() {
        // Try to use the same git as the built-in vscode git extension
        let gitPath = vscode.workspace.getConfiguration('git').get<string>('path');
        await CmGitClient.setOrFindGitPath(gitPath);

        if (gitRoot) {
            
            let cmGitMarker = path.join(gitRoot, 'mingw64', 'libexec', 'git-core', 'git-remote-dimensions');
            try {
                if (fs.statSync(cmGitMarker)) {
                    cmGitInstalled = true;
                    console.log(`Dimensions CM Git client found: ${cmGitMarker}.`);
                }
            }
            catch(err)
            {
                console.warn(`Dimensions CM Git client not found under '${gitRoot}' installation.`);
            }
        }
    }

    static async setOrFindGitPath(gitPath?: string): Promise<void> {
        gitInfo = await findGitPath(gitPath);
        if (gitInfo) {
            gitRoot = path.join(gitInfo.path, '..', '..');
        }
        console.log(
             `Git found: ${gitInfo.version} @ ${gitInfo.path === 'git' ? 'PATH' : gitInfo.path}.`
         );
    }

    static installed(): boolean {
        return cmGitInstalled;
    }

    static getGitRoot(): string {
        return gitRoot;
    }

    static getInstallUrl(): string | undefined {
        switch (process.platform)
        {
             case 'win32' :
                 return 'https://github.com/yrakovets1/com.microfocus.dimension-git-win-installer/releases/latest';
             case 'darwin': //mac
                return 'https://github.com/yrakovets1/com.microfocus.dimension-git-macos-installer/releases/latest';
            case 'linux':
                return 'https://github.com/yrakovets1/com.microfocus.dimension-git-linux-installer/releases/latest';
        }
        return undefined;
    }

    static async notifyNotInstalled() {
        let instUrl = CmGitClient.getInstallUrl();
        let logMsg = 'The required component Dimensions Git Client is not installed.';
        if (instUrl) {
            let result = await vscode.window.showWarningMessage(logMsg, 'Download');
            if (result === 'Download') {
                vscode.commands.executeCommand('vscode.open', vscode.Uri.parse(instUrl));
            }
         }
         else {
             vscode.window.showWarningMessage(logMsg);
        }
    }
}

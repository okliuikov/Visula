import * as vscode from 'vscode';
import { GitExtension, API, Repository } from './git.d';

/**
 * Git API wrapper class.
 * Usage:
 *  const git = getGitScm();
    let success = await git.initialize();
	if (success)
        console.log(git.path);
 */
export class GitScm {
    private _git: vscode.Extension<GitExtension> | undefined;
    private _api: API | undefined;
    private static GIT_EXTENSION_ID : string = 'vscode.git';
    private _gitEnabledEvent = new vscode.EventEmitter<GitScm>();
    /**
     * Subscribe to this event to receive notification when the plugin is enabled.
     * Example:
     * 	git.onGitEnabled(git => {console.log(git.path);});
     */
    public readonly onGitEnabled : vscode.Event<GitScm> = this._gitEnabledEvent.event;
    constructor() {
        this._git = vscode.extensions.getExtension<GitExtension>(GitScm.GIT_EXTENSION_ID);
        if (this._git === null) {
            throw Error(`Extension ${GitScm.GIT_EXTENSION_ID} not installed`);
        }
    }
    public async initialize(): Promise<boolean> {
        let extension = await this.getExtension();
        if (extension !== null) {
            if (extension.enabled) {
                this._api = extension.getAPI(1);
            }
            extension.onDidChangeEnablement(this.onEnabledDisabled, this);
            return extension.enabled;
        }
        return false;   // something went wrong
    }
    public isActive(): boolean {
        return this._git!.isActive;
    }

    public get path(): string {
        return this._api!.git.path;
    }

    public get api(): API {
        if (this._api === null) {
            throw new Error(`Git API not initialized`);
        }
        return this._api!;
    }

    public getRepository() : Repository | null {
        if (this.api.repositories.length > 0) {
            return this.api.repositories[0];
        }
        return null;
    }

    public getRemoteUrl(repository: Repository): string | null {
        if (repository !== null && repository.state.remotes.length > 0) {
            const url = repository.state.remotes[0].fetchUrl;
            if (url) {
                return url;
            }
        }
        return null;
    }
    
    private getExtension():Thenable<GitExtension>  {
        return this._git!.activate();
    }

    private onEnabledDisabled(enabled: boolean) {
        if (enabled) {
            this._api = this._git!.exports.getAPI(1);
            this._gitEnabledEvent.fire(this);
        }
        // as of code 1.31.1 the event is not fired for disabling the extension
    }
}

const git = new GitScm();

export function getGitScm(): GitScm {
	return git;
}
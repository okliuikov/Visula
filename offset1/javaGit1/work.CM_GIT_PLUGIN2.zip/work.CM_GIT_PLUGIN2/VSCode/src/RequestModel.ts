import * as vscode from 'vscode';
import {Request} from "./services/Requests";
import {RequestReader} from './services/RequestReader';
import { extensionId } from './constants';

/**
 * class RequestModel
 * Obtains request from the remote cm server
 * Save/Loads request in settings
 */
export class RequestModel implements vscode.Disposable {
	setRequest(request: Request | undefined) {
		this.requests.length = 0;
		if (request) {
			this.requests.push(request);
            vscode.workspace.getConfiguration().update(`${extensionId}.DefaultRequest`, 
                request, vscode.ConfigurationTarget.Workspace);
		}
	}

	requests: Array<Request> = new Array<Request>();
	private reader?: RequestReader;

	constructor(readonly host: string, private user: string, private password: string) {
		this.reader = new RequestReader(host);
		let savedRequest = vscode.workspace.getConfiguration(`${extensionId}`).get<Request>('DefaultRequest');
		if (savedRequest && savedRequest.uid > 0) {
			this.requests.push(savedRequest);
		}
	}

	public get Requests(): Promise<Request[]> {
		return new Promise((resolve, _) => {
			return resolve( this.requests);
		});
	}

	public loadUserRequests(): Promise< Array<Request> > {
		return new Promise((resolve, reject) => {
			if (this.reader) {
				try {
					let secret: string = Buffer.from(`${this.user}:${this.password}`).toString('base64');
					this.reader.inboxRequests(this.user, secret).then((requests) => {
						resolve(requests.requests);
					});
				}
				catch(er) {
					reject(er);
				}
			}
		});
	}
    public dispose() {
        // TODO: dispose me        
    }
}
/**
 * Types used in requests REST service
 */
export interface Request {
    uid: number;
    name: string;
    type: string;
    title: string;
    status: string;
}
export interface RequestCollection {
    requests: Array<Request>;
}

import { RequestCollection } from './Requests';
import { RestExecutor } from './RestExecutor';

export interface IRequestReader {
    inboxRequests(user: string, secret: string) : Promise<RequestCollection>;
    allRequests(secret: string) : Promise<RequestCollection>;
}

/**
 * Read Dimensions requests using REST services. Supports basic authentication.
 * Supports http protocol.
    Example: 
    let requestReader = new RequestReader('stl-ta-vcw8-08');
    let secret: string = Buffer.from('<user>:<password>').toString('base64');
	let requests = await requestReader.inboxRequests('<user>', secret);
 */
export class RequestReader implements IRequestReader {
    private _host: string;
    constructor(host: string) {
        this._host = host;
    }
    /** 
     * Read  inbox requests
     * @param secret Basic authentication i.e. 'user:password' encoded in base64 to compute an Authorization header.
     */
    public inboxRequests(user: string, secret: string) : Promise<RequestCollection> {
        let options = {
            host : this._host,
            port : 8080,
            path : `/dmrestservices/users/${user}/requests`,
            headers: {
                'Authorization' : 'basic' + ' ' + secret
            }
        };
        let executor = new RestExecutor<RequestCollection>();
        return executor.Execute(options);
    }
    /**
     * Read all requests
     */
    public allRequests(secret: string) : Promise<RequestCollection> {
        let options = {
            host : this._host,
            port : 8080,
            path : '/dmrestservices/requests',
            headers: {
                'Authorization' : 'basic' + ' ' + secret
            }
        };
        let executor = new RestExecutor<RequestCollection>();
        return executor.Execute(options);
    }
}
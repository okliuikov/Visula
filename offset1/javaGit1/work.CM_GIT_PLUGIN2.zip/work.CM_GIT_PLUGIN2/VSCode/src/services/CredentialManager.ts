import * as cp from 'child_process';
import { Repository } from '../git/git';

/**
 * Loads credential from Git Credential Storage. 
 * See https://git-scm.com/docs/git-credential for more details.
 * Example:
 *  const manager = new CredentialManager('c:\\program files\\git\\bin');
	let cr =  await manager.getCredential('dimensions://stl-ta-vcw8-08');
	console.log(cr.name, cr.password);
 */
export class CredentialManager {
    private _gitLocation: string;
    constructor(gitLocation: string) {
        this._gitLocation = gitLocation;
    }
    /**
     * Load credentials from Git Credential Storage. User may be promted for credentials.
     * @param url Host URL, e.g. https://github.com
     */
    public getCredential(url:string): Promise<UserCredential> {
        return new Promise<UserCredential>((resolve, reject) => {
            const options = {
                cwd : this._gitLocation
            };

            let output = '';
            const cred = cp.spawn('git', ['credential', 'fill'], options);
            if (!cred.pid) {
                reject(new Error('Failed to access Git Credential Storage'));
            }
            const fillstring = 'url=' + url + '\n\n';
            cred.stdin.write(fillstring);
            cred.stdin.end();            
            
            cred.stdout.on('data', (data) => {
                output = String(data);
            });
            cred.stderr.on('data', (data)=>{
                // Git sends 'Logon failed' to stderr if user cancels login prompt
                // it then waits for user to terminate the script
                cred.kill();
            });
            cred.on('exit', () => {
                const cr = this.parseCredentials(output);
                resolve(cr);
            });
            cred.on('error', ()=>{
                reject(new Error(`Couldn't read credentials from the Git Credential Storage`));
            });            
        });
    }
    /**
     * Save credentials in the Git Credential Storage.
     * See https://git-scm.com/book/en/v2/Git-Tools-Credential-Storage for more details.
     */
    public saveCredential(url:string, credential: UserCredential): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            const options = {
                cwd : this._gitLocation
            };

            const cred = cp.spawn('git', ['credential', 'approve'], options);
            if (!cred.pid) {
                reject(new Error('Failed to access Git Credential Storage'));
            }
            const approvestring = 'url=' + url + '\nusername=' + credential.name + '\npassword=' + credential.password + '\n\n';
            cred.stdin.write(approvestring);
            cred.stdin.end();

            cred.stderr.on('data', (data) => {
                let output = String(data);
                console.log(output);
            });
            cred.on('exit', () => {
                resolve();
            });
            cred.on('error', ()=> {
                reject(new Error(`Couldn't save credentials using the Git Credential Storage`));
            });            
        });
    }
    /**
     * Remove the credentials from the Git Credential Storage. No error is given when credentials do not exits.
     */
    public removeCredential(url:string, credential: UserCredential | null = null): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            const options = {
                cwd : this._gitLocation
            };

            const cred = cp.spawn('git', ['credential', 'reject'], options);
            if (!cred.pid) {
                reject(new Error('Failed to access Git Credential Storage'));
            }
            let rejectstring = 'url=' + url + '\n';
            if (credential) {
                rejectstring += 'username=' + credential.name + '\npassword=' + credential.password + '\n';
            }
            rejectstring += '\n';
            
            cred.stdin.write(rejectstring);
            cred.stdin.end();

            cred.stderr.on('data', (data) => {
                let output = String(data);
                console.log(output);
            });
            cred.on('exit', () => {
                resolve();
            });
            cred.on('error', ()=> {
                reject(new Error(`Couldn't remove credentials from the Git Credential Storage`));
            });            
        });
    }
    /**
     * Returns true if Git Credential Manager is enabled for a given repository.
     * @param repository Git repository
     */
    public async isCredentialManagerEnabled(repository: Repository): Promise<boolean> {
        try {
            const value = await repository.getConfig('credential.helper');
            return value !== null && value.length > 0;
        }
        catch(e) {
            return false;
        }
    }

    private parseCredentials(data: string): UserCredential {
        let cr: UserCredential = {
            name: '',
            password: ''
        };
        const credentials = data.trim().split('\n');
        if (credentials !== null && credentials.length > 4) {
            cr.name = credentials[3].substring('username='.length);
            cr.password = credentials[4].substring('password='.length);
        }
        
        return cr;
    }
}

export interface UserCredential {
    name: string;
    password: string;
}

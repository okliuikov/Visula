import * as http from 'http';
export class RestExecutor<T> {
    /**
     * Execute GET request
     * @param options See http.request(options) https://nodejs.org/api/http.html#http_http_request_options_callback
     */
    public Execute(options: Object) : Promise<T> {
        return new Promise<T>((resolve, reject) => {
            http.get(options, (resp) => {
                let rawData: string = '';
                if(resp.statusCode !== 200) {
                    reject(new Error (`Failed to run a request to remote server. Responce code: ${resp.statusCode}`));
                }
                resp.on('data', (chunk) => {
                    rawData += chunk;
                });
                resp.on('end', () => {
                    try {
                        let requests = JSON.parse(rawData) as T;
                        resolve(requests);
                    }
                    catch(e)
                    {
                        reject(new Error ('Failed to parse server JSON'));
                    }
                });
            }).on('error', (err)=> {
                reject(err);
            });
        });
    }
}
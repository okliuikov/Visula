# Change Log

## [Unreleased]
- Extension detects a Git installation.
Checks the Git installation is extended by CM Git Client.
If the CM Git Client installation not found proposes to download it.

- Extension has a tree control on the scm panel. Loads user's Dimensions CM requests from remote server.
Selects a Dimensions CM request and store it in workspace options. Ability to use the add the request to commit message.

# Dependencies

| Module        | Version | License | License Link |
|---------------|---------|---------|--------------|
| slf4j-api         | 1.7.25  | MIT | https://www.slf4j.org/license.html |
| logback-core      | 1.2.3   | EPL v1.0, LGPL 2.1| https://logback.qos.ch/license.html |
| logback-classic   | 1.2.3   | EPL v1.0, LGPL 2.1| https://logback.qos.ch/license.html |
| logback-access      | 1.2.3   | EPL v1.0, LGPL 2.1| https://logback.qos.ch/license.html |


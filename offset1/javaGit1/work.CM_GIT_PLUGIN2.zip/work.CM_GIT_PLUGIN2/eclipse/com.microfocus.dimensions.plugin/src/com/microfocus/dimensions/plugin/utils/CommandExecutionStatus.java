package com.microfocus.dimensions.plugin.utils;

/**
 * This class is used to represent the execution status of the operation.
 *
 */
public class CommandExecutionStatus {

	private boolean isExecutionPassed = false;
	private String outputMessage = "";
	private String errorMessage = "";

	/**
	 * Default constructor.
	 */
	public CommandExecutionStatus() {
		// Default constructor
	}

	/**
	 * Parameterized constructor.
	 *
	 * @param isExecutionPassed
	 *            - boolean value represents the execution is passed or not.
	 * @param message
	 *            - the execution status message, must not be null
	 */
	public CommandExecutionStatus(boolean isExecutionPassed, String outputMessage, String errorMessage) {
		this.isExecutionPassed = isExecutionPassed;
		this.outputMessage = outputMessage;
		this.errorMessage = errorMessage;
	}
	
	public static CommandExecutionStatus error(String errorMessage) {
		return new CommandExecutionStatus(false, "", errorMessage); 
	}
	
	public static CommandExecutionStatus passed(String outputMessage) {
		return new CommandExecutionStatus(true, outputMessage, ""); 
	}

	/**
	 * This method is used to return a boolean value represents the execution is
	 * passed or not.
	 *
	 * @return TRUE/FALSE
	 */
	public boolean isExecutionPassed() {
		return isExecutionPassed;
	}

	/**
	 * To set the execution is passed or not.
	 *
	 * @param isExecutionPassed
	 *            - TRUE/FALSE
	 */
	public void setExecutionPassed(boolean isExecutionPassed) {
		this.isExecutionPassed = isExecutionPassed;
	}

	public String getOutputMessage() {
		return outputMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	
	/**
	 * This method is used to return the execution status message.
	 *
	 * @return the message
	 */
	public String getArrgregateMessage() {
//		return message;

		if (!StringUtils.isNullEmpty(outputMessage)) {
			if(!StringUtils.isNullEmpty(errorMessage)) {
				return outputMessage + "\n" + errorMessage;
			}
			return outputMessage;
		}
		return errorMessage;
	}

	/**
	 * To set the execution status message.
	 *
	 * @param message
	 *            - execution status message.
	 */
	public void setError(String message) {
		isExecutionPassed = false;
		errorMessage = message;
	}

}

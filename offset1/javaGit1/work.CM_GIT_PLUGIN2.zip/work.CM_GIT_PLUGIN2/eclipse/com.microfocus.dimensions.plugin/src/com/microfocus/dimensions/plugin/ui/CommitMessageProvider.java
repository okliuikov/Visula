package com.microfocus.dimensions.plugin.ui;

import org.eclipse.egit.ui.ICommitMessageProvider;
import org.eclipse.core.resources.IResource;
import org.eclipse.egit.ui.internal.staging.StagingView;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.ActionContributionItem;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.PlatformUI;
import java.lang.Character;
import java.lang.reflect.Field;
import org.eclipse.ui.forms.widgets.Section;

@SuppressWarnings("restriction")
public class CommitMessageProvider implements ICommitMessageProvider {

	@Override
	public String getMessage(IResource[] resources) {
		// Field f = obj.getClass().getDeclaredField("stuffIWant");
		// //NoSuchFieldException
		// f.setAccessible(true);
		// Hashtable iWantThis = (Hashtable) f.get(obj); //IllegalAccessException

		// addMainStagingViewToolbarItem();
		StagingView view = (StagingView) PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.findView(StagingView.VIEW_ID);
		try {
			Field field = view.getClass().getDeclaredField("commitMessageSection");
			field.setAccessible(true);
			Object commitMessageSectionObj = field.get(view);
			if (commitMessageSectionObj instanceof Section) {
				Section commitMessageSection = (Section) commitMessageSectionObj;
				Control control = commitMessageSection.getTextClient();
				if (control instanceof Composite) {
					for (Control child : ((Composite) control).getChildren()) {
						if (child instanceof ToolBar) {
							ToolBar bar = (ToolBar) child;
							final ToolItem openToolItem = new ToolItem(bar, SWT.PUSH);
							// openToolItem.setImage(openIcon);
							openToolItem.setText("Dim Req");
							openToolItem.setToolTipText("Open Dimensions Requests");
							bar.update();
						}
					}
				}
			}

		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // NoSuchFieldException
		catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "This is a dummy message from dimensions git plugin\n";
	}

	private void addMainStagingViewToolbarItem() {
		try {
			StagingView view = (StagingView) PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
					.findView(StagingView.VIEW_ID);
			IActionBars actionBars = view.getViewSite().getActionBars();
			IToolBarManager toolbar = actionBars.getToolBarManager();
			Boolean found = false;
			for (IContributionItem item : toolbar.getItems()) {
				if (item instanceof ActionContributionItem) {
					ActionContributionItem contributionItem = (ActionContributionItem) item;
					if (contributionItem.getAction().getText() == "Dim Test") {
						found = true;
						break;
					}
				}
			}
			if (!found) {
				ActionContributionItem item = new ActionContributionItem(new Action("Show Dimensions Requests"){
					@Override
					public void run() {
						char a = 'a';
						Character b = a;
						//b.is
//						StashCreateUI stashCreateUI = new StashCreateUI(repository);
//						Shell shell = PlatformUI.getWorkbench()
//								.getActiveWorkbenchWindow().getShell();
//						stashCreateUI.createStash(shell);
						
						// TODO open requests panel
					}

					@Override
					public boolean isEnabled() {
						return true;
					}
				});
				toolbar.add(item);
				actionBars.updateActionBars();
			}
			// view.resetCommitMessageComponent();
		} catch (Exception ex) {

		}
	}
}

package com.microfocus.dimensions.plugin.ui;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.core.runtime.IPath;
import org.eclipse.egit.ui.internal.provisional.wizards.GitRepositoryInfo;
import org.eclipse.egit.ui.internal.provisional.wizards.IRepositorySearchResult;
import org.eclipse.egit.ui.internal.provisional.wizards.NoRepositoryInfoException;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.jgit.transport.URIish;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.microfocus.dimensions.plugin.jgit.services.CloneUriHolder;
import com.microfocus.dimensions.plugin.utils.GitUtils;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;
import com.microfocus.dimensions.plugin.utils.PlatformUtils;

@SuppressWarnings("restriction")
public class DimensionsRepositoryBrowsePage extends WizardPage implements IRepositorySearchResult {

    private Label urlLabel;
    private Link downloadDimensionsGitClientLink;
    private Text urlText;
    private List<IPath> gitExecFolderPaths = null;
    private boolean dimensionsGitClientInstalled = false;
    private Timer gitCheckTimer;

    public DimensionsRepositoryBrowsePage() {
        super(DimensionsRepositoryBrowsePage.class.getName());
        setTitle("Source Dimensions Repository");
    }

    @Override
    public void createControl(Composite composite) {

        LoggerHelper.debug("Inside createControl..", DimensionsRepositoryBrowsePage.class);

        Composite topLevel = new Composite(composite, SWT.NONE);
        GridLayout gridLayout = new GridLayout();
        gridLayout.numColumns = 2;
        topLevel.setLayout(gridLayout);

        urlLabel = new Label(topLevel, SWT.RIGHT);
        urlLabel.setText("Clone URL:");

        urlText = new Text(topLevel, SWT.FILL | SWT.BORDER);
        GridData gridData = new GridData(GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL);
        urlText.setLayoutData(gridData);
        urlText.addModifyListener(listener -> {
            getWizard().getContainer().updateButtons();
        });

        gridData = new GridData();
        gridData.horizontalSpan = 2;
        gridData.widthHint = 360;
        gridData.horizontalAlignment = GridData.FILL;
        gridData.grabExcessHorizontalSpace = true;

        StyledText styledTextWidget = new StyledText(topLevel, SWT.NONE);
        styledTextWidget.setText("For example: dimensions://stl-ta-vcw12-8/cm_typical@dim12/qlarius/java_brancha_str");
        styledTextWidget.setLayoutData(gridData);
        styledTextWidget.setBackground(topLevel.getBackground());
        styledTextWidget.setEditable(false);
        styledTextWidget.setCaret(null);

        downloadDimensionsGitClientLink = new Link(topLevel, SWT.NONE);
        downloadDimensionsGitClientLink.setLayoutData(gridData);
        downloadDimensionsGitClientLink.setText("<a>Download Dimensions CM Git Client</a>");
        downloadDimensionsGitClientLink.setVisible(false);

        downloadDimensionsGitClientLink.addSelectionListener(new SelectionAdapter() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                try {
                    PlatformUI.getWorkbench().getBrowserSupport().getExternalBrowser()
                            .openURL(new URL(getDimensionsGitClientDowloadURL()));
                } catch (PartInitException ex) {
                    LoggerHelper.error("Error navigating to Dimensions Git Client download page",
                            DimensionsRepositoryBrowsePage.class, ex);
                } catch (MalformedURLException ex) {
                    LoggerHelper.error("Error navigating to Dimensions Git Client download page",
                            DimensionsRepositoryBrowsePage.class, ex);
                }
            }

        });

        topLevel.pack();
        setControl(topLevel);
        checkPage();

        gitCheckTimer = new Timer();
        gitCheckTimer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                if (urlText.isDisposed() || dimensionsGitClientInstalled) {
                    gitCheckTimer.cancel();
                    return;
                }
                if (gitExecFolderPaths == null) {
                    gitExecFolderPaths = GitUtils.getGitExecFolderPaths();
                    // do git folders check once
                    if (gitExecFolderPaths == null) {
                        gitExecFolderPaths = new ArrayList<IPath>();
                    }
                }
                urlText.getDisplay().asyncExec(new Runnable() {
                    @Override
                    public void run() {
                        checkPage();
                    }

                });
            }
        }, 0, 3000);
    }

    @Override
    public GitRepositoryInfo getGitRepositoryInfo() throws NoRepositoryInfoException {
        String serverUrl = "";
        if (urlText != null) {
            serverUrl = urlText.getText();
        }
        LoggerHelper.debug("The entered Dimensions server url is : " + serverUrl, DimensionsRepositoryBrowsePage.class);
        try {
            CloneUriHolder.setLastKnownUri(new URIish(serverUrl));
        } catch (URISyntaxException e) {
            LoggerHelper.error("Cannot setup last known clone url", DimensionsRepositoryBrowsePage.class, e);
        }
        return new GitRepositoryInfo(serverUrl);
    }

    @Override
    public boolean canFlipToNextPage() {
        return dimensionsGitClientInstalledOrInProgress() && !urlText.getText().isEmpty();
    }
    
    private String getDimensionsGitClientDowloadURL() {
        String osMarker = "win";
        if (PlatformUtils.isMac()) {
            osMarker = "macos";
        } else if (PlatformUtils.isUnix() || PlatformUtils.isSolaris()) {
            osMarker = "linux";
        }
        return String.format("https://github.com/yrakovets1/com.microfocus.dimension-git-%s-installer/releases/latest/",
                osMarker);
    }

    private boolean dimensionsGitClientInstalledOrInProgress() {
        if (gitExecFolderPaths == null) {
            return true;
        }
        return !gitExecFolderPaths.isEmpty() && GitUtils.isDimensionsGitClientInstalled(gitExecFolderPaths);
    }

    private void checkPage() {
        if (dimensionsGitClientInstalledOrInProgress()) {
            // it can possibly be a long operation, be rather optimistic in such case
            // but don't allow moving to the next page
            setPageComplete(gitExecFolderPaths == null);
            downloadDimensionsGitClientLink.setVisible(false);
            setErrorMessage(null);
            setMessage("Enter the location of the source repository.");
            urlText.setEnabled(true);
        } else {
            setMessage(null);
            setErrorMessage("The required component Dimensions CM Git Client is not installed.");
            setPageComplete(false);
            downloadDimensionsGitClientLink.setVisible(true);
            urlText.setEnabled(false);
        }
    }
}

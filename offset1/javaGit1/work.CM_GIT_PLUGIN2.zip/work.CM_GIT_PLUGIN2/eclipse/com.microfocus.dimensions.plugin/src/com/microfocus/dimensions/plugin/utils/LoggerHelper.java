package com.microfocus.dimensions.plugin.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microfocus.dimensions.plugin.Activator;

/**
 * Helper class for logging mechanism.
 */
public class LoggerHelper {

	/**
	 * This method is used for debug logging.
	 * 
	 * @param message
	 *            - message to be logged
	 * @param loggerClass
	 *            - the class reference for the log to be appended.
	 */
	public static void debug(String message, Class<?> loggerClass) {
		if (Activator.isLoggingEnabled()) {
			Logger logger = LoggerFactory.getLogger(loggerClass);
			logger.debug(message);
		}
	}

	/**
	 * This method is used for info logging.
	 * 
	 * @param message
	 *            - message to be logged
	 * @param loggerClass
	 *            - the class reference for the log to be appended.
	 */
	public static void info(String message, Class<?> loggerClass) {
		if (Activator.isLoggingEnabled()) {
			Logger logger = LoggerFactory.getLogger(loggerClass);
			logger.info(message);
		}
	}

	/**
	 * This method is used for error logging.
	 * 
	 * @param message
	 *            - message to be logged
	 * @param loggerClass
	 *            - the class reference for the log to be appended.
	 * @param object
	 *            - the error trace which provides more information.
	 */
	public static void error(String message, Class<?> loggerClass, Object object) {
		if (Activator.isLoggingEnabled()) {
			Logger logger = LoggerFactory.getLogger(loggerClass);
			logger.error(message, object);
		}
	}

	/**
	 * This method is used for error logging.
	 * 
	 * @param message
	 *            - message to be logged
	 * @param loggerClass
	 *            - the class reference for the log to be appended.
	 */
	public static void error(String message, Class<?> loggerClass) {
		if (Activator.isLoggingEnabled()) {
			Logger logger = LoggerFactory.getLogger(loggerClass);
			logger.error(message);
		}
	}

	/**
	 * This method is used for warn logging.
	 * 
	 * @param message
	 *            - message to be logged
	 * @param loggerClass
	 *            - the class reference for the log to be appended.
	 */
	public static void warn(String message, Class<?> loggerClass) {
		if (Activator.isLoggingEnabled()) {
			Logger logger = LoggerFactory.getLogger(loggerClass);
			logger.warn(message);
		}
	}
}

package com.microfocus.dimensions.plugin.utils;

/**
 * This class is used to represent the platform related informations.
 *
 */
public class PlatformUtils {

	private static String OS_NAME = System.getProperty("os.name").toLowerCase();
	private static String WINDOWS_COMMAND_TO_BE_APPENDED = "cmd /C ";
	private static String UNIX_COMMAND_TO_BE_APPENDED = "";
	private static String MAC_COMMAND_TO_BE_APPENDED = "";
	
	/**
	 * This method used to provide the prefix command depends on the underlying
	 * platform.
	 *
	 * @return - prefix command depends on the existing OS.
	 */
	public static String getPrefixCommand() {
		String commandToBeAppended = "";
		if (isWindows()) {
			LoggerHelper.info("This is Windows OS", PlatformUtils.class);
			commandToBeAppended = WINDOWS_COMMAND_TO_BE_APPENDED;
		} else if (isMac()) {
			LoggerHelper.info("This is Mac OS", PlatformUtils.class);
			commandToBeAppended = MAC_COMMAND_TO_BE_APPENDED;
		} else if (isUnix()) {
			LoggerHelper.info("This is Unix or Linux OS", PlatformUtils.class);
			commandToBeAppended = UNIX_COMMAND_TO_BE_APPENDED;
		} else if (isSolaris()) {
			LoggerHelper.error("This is Solaris OS. Not supported..!!!", PlatformUtils.class);
		} else {
			LoggerHelper.error("Your OS is not supported..!!!", PlatformUtils.class);
		}

		return commandToBeAppended;
	}

	/**
	 * This method is used to inform the underlying OS is WINDOWS.
	 *
	 * @return - TRUE/FALSE
	 */
	public static boolean isWindows() {
		return (OS_NAME.indexOf("win") >= 0);
	}

	/**
	 * This method is used to inform the underlying OS is MAC.
	 *
	 * @return - TRUE/FALSE
	 */
	public static boolean isMac() {
		return (OS_NAME.indexOf("mac") >= 0);
	}

	/**
	 * This method is used to inform the underlying OS is UNIX.
	 *
	 * @return - TRUE/FALSE
	 */
	public static boolean isUnix() {
		return (OS_NAME.indexOf("nix") >= 0 || OS_NAME.indexOf("nux") >= 0 || OS_NAME.indexOf("aix") > 0);
	}

	/**
	 * This method is used to inform the underlying OS is SOLARIS.
	 *
	 * @return - TRUE/FALSE
	 */
	public static boolean isSolaris() {
		return (OS_NAME.indexOf("sunos") >= 0);
	}
}

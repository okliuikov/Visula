package com.microfocus.dimensions.plugin.jgit.operations;

import com.microfocus.dimensions.plugin.utils.CommandExecutionStatus;

/**
 * This interface represents the operation related to Dimensions & Git operations.
 *
 */
public interface IOperation {

	/**
	 * This method is used to execute the corresponding git operation.
	 *
	 * @return CommandExecutionStatus instance to show the execution status.
	 */
	public CommandExecutionStatus run();
}

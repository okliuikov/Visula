package com.microfocus.dimensions.plugin.jgit.connections;

import java.io.OutputStream;
import java.util.Collection;
import java.util.Map;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.errors.TransportException;
import org.eclipse.jgit.lib.ProgressMonitor;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.transport.PushConnection;
import org.eclipse.jgit.transport.RemoteRefUpdate;

import com.microfocus.dimensions.plugin.jgit.services.DimensionsLsRemoteCommand;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;

/**
 * This class is used to lists known refs from the Dimensions and sends objects
 * to the Dimensions.
 *
 */
public class DimensionsPushConnection implements PushConnection {

	private DimensionsLsRemoteCommand lsRemoteCommand;

    /**
     * Parameterized constructor
     *
     * @param repository
     *            - the repository instance, must not be null
     */
    public DimensionsPushConnection(Repository repository) {
        lsRemoteCommand = new DimensionsLsRemoteCommand(repository);
    }

	@Override
	public Map<String, Ref> getRefsMap() {
		Map<String, Ref> refmap = lsRemoteCommand.getRefmap();
		if (refmap.isEmpty()) {
			try {
				lsRemoteCommand.call();
			} catch (GitAPIException e) {
				LoggerHelper.error("Got exception in getRefsMap..!!!", DimensionsPushConnection.class, e);
			}
			refmap = lsRemoteCommand.getRefmap();
		}
		return refmap;
	}

	@Override
	public Collection<Ref> getRefs() {
		Collection<Ref> refs = null;
		Map<String, Ref> refmap = lsRemoteCommand.getRefmap();
		if (refmap.isEmpty()) {
			try {
				refs = lsRemoteCommand.call();
			} catch (GitAPIException e) {
				LoggerHelper.error("Got exception in getRefs..!!!", DimensionsPushConnection.class, e);
			}
		} else {
			refs = refmap.values();
		}
		return refs;
	}

	@Override
	public Ref getRef(String name) {
		return getRefsMap().get(name);
	}

	@Override
	public void close() {
	}

	@Override
	public String getMessages() {
		return "";
	}

	@Override
	public String getPeerUserAgent() {
		return "";
	}

	@Override
	public void push(ProgressMonitor monitor, Map<String, RemoteRefUpdate> refUpdates) throws TransportException {
	}

	@Override
	public void push(ProgressMonitor monitor, Map<String, RemoteRefUpdate> refUpdates, OutputStream out)
			throws TransportException {
	}

}
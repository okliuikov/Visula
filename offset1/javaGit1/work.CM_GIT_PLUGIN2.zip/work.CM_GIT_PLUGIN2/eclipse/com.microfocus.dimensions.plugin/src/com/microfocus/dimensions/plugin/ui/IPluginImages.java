package com.microfocus.dimensions.plugin.ui;

public interface IPluginImages {
    String ICON_PATH = "icons/"; //$NON-NLS-1$

    String DIMENSIONS = "dimensions16.png"; //$NON-NLS-1$

}


package com.microfocus.dimensions.plugin.jgit.services;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jgit.errors.NotSupportedException;
import org.eclipse.jgit.errors.TransportException;
import org.eclipse.jgit.lib.AnyObjectId;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ProgressMonitor;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.RefDatabase;
import org.eclipse.jgit.lib.RefUpdate;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.transport.FetchConnection;
import org.eclipse.jgit.transport.FetchResult;
import org.eclipse.jgit.transport.OperationResult;
import org.eclipse.jgit.transport.PushConnection;
import org.eclipse.jgit.transport.PushResult;
import org.eclipse.jgit.transport.RefSpec;
import org.eclipse.jgit.transport.RemoteConfig;
import org.eclipse.jgit.transport.RemoteRefUpdate;
import org.eclipse.jgit.transport.RemoteRefUpdate.Status;
import org.eclipse.jgit.transport.TrackingRefUpdate;
import org.eclipse.jgit.transport.Transport;
import org.eclipse.jgit.transport.TransportProtocol;
import org.eclipse.jgit.transport.URIish;
import org.eclipse.jgit.util.FileUtils;

import com.microfocus.dimensions.plugin.jgit.connections.DimensionsFetchConnection;
import com.microfocus.dimensions.plugin.jgit.connections.DimensionsPushConnection;
import com.microfocus.dimensions.plugin.jgit.operations.DimensionsCloneOperation;
import com.microfocus.dimensions.plugin.jgit.operations.DimensionsFetchOperation;
import com.microfocus.dimensions.plugin.jgit.operations.DimensionsPushOperation;
import com.microfocus.dimensions.plugin.utils.CommandExecutionStatus;
import com.microfocus.dimensions.plugin.utils.GitUtils;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;

/**
 * Connects Git and Dimensions repositories together and copies objects between
 * them.
 *
 * A transport can be used for either fetching (copying objects into the
 * caller's repository from the Dimensions repository) or pushing (copying
 * objects into the Dimensions repository from the caller's repository).
 *
 */
public class DimensionsTransport extends Transport {
	public static final String SCHEME = "dimensions"; //$NON-NLS-1$
	private Repository repository = null;
	private URIish uri = null;
	private List<RefSpec> refSpecs = new ArrayList<>();

	/**
	 * The parameterized constructor
	 *
	 * @param repository
	 *            - the repository instance, must not be null
	 * @param localUri
	 *            - the URIish instance, must not be null
	 * @throws NotSupportedException
	 */
	public DimensionsTransport(Repository repository, URIish localUri) throws NotSupportedException {
		super(repository, localUri);
		this.repository = repository;
		uri = localUri;
	}

	/**
	 * The parameterized constructor
	 *
	 * @param localUri
	 *            - the URIish instance, must not be null
	 * @throws NotSupportedException
	 */
	public DimensionsTransport(final URIish uri) throws NotSupportedException {
		super(uri);
	}

	/**
	 * The Transport protocol to support Dimensions repository.
	 */
	public static final TransportProtocol PROTOCOL_DIMENSIONS = new TransportProtocol() {
		@Override
		public String getName() {
			// similar setting in plugin.xml overcomes this one
			return "Dimensions CM"; //$NON-NLS-1$
		}

		@Override
		public Set<String> getSchemes() {
			return Collections.singleton(SCHEME);
		}

		@Override
		public Set<URIishField> getRequiredFields() {
			return Collections.unmodifiableSet(EnumSet.of(URIishField.PATH));
		}

		@Override
		public Set<URIishField> getOptionalFields() {
			return Collections.unmodifiableSet(
					EnumSet.of(URIishField.HOST, URIishField.PORT, URIishField.USER, URIishField.PASS));
		}

		@Override
		public Transport open(URIish uri, Repository repository, String remoteName) throws NotSupportedException {
			return new DimensionsTransport(repository, uri);
		}

		@Override
		public Transport open(URIish uri) throws NotSupportedException {
			return new DimensionsTransport(uri);
		}

		@Override
		public boolean canHandle(URIish uri) {
			String scheme = uri.getScheme();
			if (scheme != null && scheme.equals(SCHEME)) {
				return true;
			}
			return false;
		};

		@Override
		public boolean canHandle(URIish uri, Repository local, String remoteName) {
			String scheme = uri.getScheme();
			if (scheme != null && scheme.equals(SCHEME)) {
				return true;
			}
			return false;
		};
	};

	@Override
	public void applyConfig(RemoteConfig cfg) {
		List<RefSpec> fetchRefSpecs = cfg.getFetchRefSpecs();
		List<RefSpec> toFetchCustom = new ArrayList<>();
		for (RefSpec refSpec : fetchRefSpecs) {
			String destination = refSpec.getDestination();
			destination = destination.contains("remotes") ? destination.replaceAll("remotes", SCHEME) : destination;
			LoggerHelper.debug("The refSpec destination is : " + destination, DimensionsTransport.class);
			refSpec = refSpec.setDestination(destination);
			toFetchCustom.add(refSpec);
		}
		cfg.setFetchRefSpecs(toFetchCustom);
		refSpecs = Collections.unmodifiableList(toFetchCustom);
		super.applyConfig(cfg);
	}

	@Override
	public FetchConnection openFetch() throws NotSupportedException, TransportException {
		return new DimensionsFetchConnection(repository);
	}

	@Override
	public PushConnection openPush() throws NotSupportedException, TransportException {
		return new DimensionsPushConnection(repository);
	}

	@Override
	public PushResult push(ProgressMonitor monitor, Collection<RemoteRefUpdate> toPush)
			throws NotSupportedException, TransportException {
		return push(monitor, toPush, null);
	}

	@Override
	public PushResult push(ProgressMonitor monitor, Collection<RemoteRefUpdate> toPush, OutputStream out)
			throws NotSupportedException, TransportException {
		LoggerHelper.debug("Inside Push method...", DimensionsTransport.class);
		PushConnection pushConnection = openPush();
		Map<String, Ref> refsMap = pushConnection.getRefsMap();

		String remoteBranchName = "";
		String localBranchName = "";
		boolean isForceUpdate = false;
		Map<String, RemoteRefUpdate> toPushMap = new HashMap<>();
		for (final RemoteRefUpdate rru : toPush) {
			toPushMap.put(rru.getRemoteName(), rru);
			remoteBranchName = getBranchName(rru.getRemoteName());
			localBranchName = getBranchName(rru.getSrcRef());
			isForceUpdate = rru.isForceUpdate();
		}

		PushResult pushResult = new PushResult();
		CommandExecutionStatus executionStatus = pushOperation(remoteBranchName, localBranchName, isForceUpdate);
		updatePushResultValues(refsMap, executionStatus, toPushMap, pushResult);
		return pushResult;
	}

	/**
	 * This method is used to update the custom push result values to provide the
	 * proper results to EGit.
	 *
	 */
	private void updatePushResultValues(Map<String, Ref> refsMap, CommandExecutionStatus executionStatus,
			Map<String, RemoteRefUpdate> toPushMap, PushResult pushResult) throws TransportException {
		Status statusValue = Status.OK;
		String message = executionStatus.getArrgregateMessage();
		if (!executionStatus.isExecutionPassed()) {
			statusValue = Status.REJECTED_REMOTE_CHANGED;
		} else if (message.contains("up-to-date")) {
			statusValue = Status.UP_TO_DATE;
		}

		try {
			setFieldValues(PushResult.class, "remoteUpdates", pushResult, toPushMap);
			setFieldValues(OperationResult.class, "advertisedRefs", pushResult, refsMap);
			setFieldValues(OperationResult.class, "uri", pushResult, uri);
			setFieldValues(OperationResult.class, "messageBuffer", pushResult, new StringBuilder(message));

			SortedMap<String, TrackingRefUpdate> updates = new TreeMap<>();
			for (final RemoteRefUpdate rru : toPushMap.values()) {
				setFieldValues(RemoteRefUpdate.class, "status", rru, statusValue);
				TrackingRefUpdate trackingRefUpdate = rru.getTrackingRefUpdate();
				setFieldValues(TrackingRefUpdate.class, "result", trackingRefUpdate, RefUpdate.Result.FORCED);
				updates.put(trackingRefUpdate.getLocalName(), trackingRefUpdate);
			}

			setFinalStaticValues(OperationResult.class, "updates", pushResult, updates);
		} catch (Exception e) {
			throw new TransportException(
					"Dimensions : Got exception while setting values for PushResult...!!! " + e.getMessage());
		}
	}

	/**
	 * This method is used to get the branch name from the provided remote name
	 * path.
	 *
	 */
	private String getBranchName(String remoteName) {
		String branchName = "";
		if (remoteName != null) {
			Path path = Paths.get(remoteName);
			branchName = path.subpath(path.getNameCount() - 1, path.getNameCount()).toString();
		}
		return branchName;
	}

	/**
	 * This method is used to perform the push operation by calling internal
	 * methods.
	 *
	 */
	private CommandExecutionStatus pushOperation(String remoteBranchName, String localBranchName, boolean isForceUpdate)
			throws TransportException {
		
		if (repository == null) {
		    return CommandExecutionStatus.error("There is no valid repository provided.");
		}
		DimensionsPushOperation pushOperation = new DimensionsPushOperation(repository);
		pushOperation.setLocalBranchName(localBranchName);
		pushOperation.setRemoteBranchName(remoteBranchName);
		pushOperation.setDryRun(this.isDryRun());
		pushOperation.setForceUpdate(isForceUpdate);
		CommandExecutionStatus status = pushOperation.run();
		return status;
	}

	@Override
	public FetchResult fetch(ProgressMonitor monitor, Collection<RefSpec> toFetch)
			throws NotSupportedException, TransportException {
		FetchResult fetchResult = null;
		LoggerHelper.debug("Inside fetch method...", DimensionsTransport.class);
		CommandExecutionStatus status = new CommandExecutionStatus();
		try {
			if (repository != null) {
			    status = performOperation();
			} else {
				status.setError("Dimensions Fetch/Clone is failed. The provided repository is null...");
				LoggerHelper.error(status.getErrorMessage(),
						DimensionsTransport.class);
			}
			fetchResult = getFetchResult(status);

		} catch (TransportException e) {
			throw e;
		} catch (Exception e) {
			String message = "Dimensions: Got exception while setting values for FetchResult...";
			LoggerHelper.error(message,
					DimensionsTransport.class, e);
			throw new TransportException(message + "\n" + e.getMessage());
		}

		return fetchResult;
	}

	/**
	 * This method is used to perform the git(clone/fetch) operations.
	 */
    private CommandExecutionStatus performOperation() throws IOException {
        File localRepositoryRoot = GitUtils.getRepositoryRootPath(repository).toFile();

        CommandExecutionStatus status;
        // If the files are more than 2 then it is a pull/fetch operation
        File[] listFiles = localRepositoryRoot.listFiles();
        if (listFiles != null && listFiles.length >= 2) {
            DimensionsFetchOperation fetchOperation = new DimensionsFetchOperation(repository);
            status = fetchOperation.run();

        } else // Otherwise it is a Clone operation
        {
            // Remove the Git repository directory which is created by EGit
            if (listFiles != null) {
                FileUtils.delete(localRepositoryRoot, FileUtils.RECURSIVE);
            }
            DimensionsCloneOperation cloneOperation = new DimensionsCloneOperation(uri, repository);
            status = cloneOperation.run();
        }
        return status;
    }

	/**
	 * This method is used to get the updated custom fetch result.
	 *
	 */
	private FetchResult getFetchResult(CommandExecutionStatus executionStatus) throws TransportException, Exception {
		FetchResult fetchResult;
		FetchConnection fetchConnection = openFetch();
		Class<?> clazz = FetchResult.class;
		Constructor<?> constructor = clazz.getDeclaredConstructor();
		constructor.setAccessible(true);
		fetchResult = (FetchResult) constructor.newInstance();

		if (!executionStatus.isExecutionPassed()) {
			throw new TransportException(executionStatus.getArrgregateMessage());
		}

		setFieldValues(OperationResult.class, "advertisedRefs", fetchResult, fetchConnection.getRefsMap());
		String message = executionStatus.getArrgregateMessage();
		SortedMap<String, TrackingRefUpdate> updates = new TreeMap<>();

		if (!StringUtils.isEmpty(message)) {
			updateTrackingRefUpdateMap(fetchResult, fetchConnection, message, updates);
		}
		setFinalStaticValues(OperationResult.class, "updates", fetchResult, updates);
		return fetchResult;
	}

	/**
	 * This method is used to update the TrackingRefUpdateMap.
	 *
	 */
	private void updateTrackingRefUpdateMap(FetchResult fetchResult, FetchConnection fetchConnection, String message,
			SortedMap<String, TrackingRefUpdate> updates) throws IOException, NoSuchMethodException,
			InstantiationException, IllegalAccessException, InvocationTargetException, Exception {
		Class<?> clazz;
		Constructor<?> constructor;
		Collection<Ref> refs = fetchConnection.getRefs();
		Map<String, Ref> localRefs = this.local.getRefDatabase().getRefs(RefDatabase.ALL);
		for (RefSpec refSpec : refSpecs) {
			for (Ref ref : refs) {
				Ref oldRef = localRefs.get(ref.getName());
				ObjectId oldId = oldRef != null && oldRef.getObjectId() != null ? oldRef.getObjectId()
						: ObjectId.zeroId();
				ObjectId newId = ref.getObjectId();
				if (!newId.equals(oldId)) {
					clazz = TrackingRefUpdate.class;
					Class<?>[] paramTypes = { boolean.class, String.class, String.class, AnyObjectId.class,
							AnyObjectId.class };
					Object[] paramValues = { refSpec.isForceUpdate(), refSpec.getSource(), refSpec.getDestination(),
							oldId, newId };
					constructor = clazz.getDeclaredConstructor(paramTypes);
					constructor.setAccessible(true);
					TrackingRefUpdate trackingRefUpdate = (TrackingRefUpdate) constructor.newInstance(paramValues);
					setFieldValues(TrackingRefUpdate.class, "result", trackingRefUpdate, RefUpdate.Result.FORCED);
					updates.put(trackingRefUpdate.getLocalName(), trackingRefUpdate);
				}
			}
		}
		setFieldValues(OperationResult.class, "messageBuffer", fetchResult, new StringBuilder(message));
	}

	/**
	 * This method is used to set the field values using the reflection api's.
	 *
	 */
	private void setFieldValues(Class<?> clazz, String fieldName, Object instance, Object valueToSet) throws Exception {
		Field field = clazz.getDeclaredField(fieldName);
		field.setAccessible(true);
		field.set(instance, valueToSet);
	}

	/**
	 * This method is used to set the static or final field values using the
	 * reflection api's.
	 *
	 */
	private void setFinalStaticValues(Class<?> clazz, String fieldName, Object instance, Object valueToSet)
			throws Exception {
		Field field = clazz.getDeclaredField(fieldName);
		field.setAccessible(true);
		// remove final modifier from field
		Field modifiersField = Field.class.getDeclaredField("modifiers");
		modifiersField.setAccessible(true);
		modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

		field.set(instance, valueToSet);
	}

	@Override
	public void close() {
	}
}

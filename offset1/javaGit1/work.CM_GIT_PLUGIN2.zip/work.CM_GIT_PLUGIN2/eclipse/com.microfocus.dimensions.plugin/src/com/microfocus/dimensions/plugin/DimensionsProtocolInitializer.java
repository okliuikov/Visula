package com.microfocus.dimensions.plugin;

import org.eclipse.jgit.transport.Transport;
import org.eclipse.ui.IStartup;

import com.microfocus.dimensions.plugin.jgit.services.DimensionsTransport;

/**
 * This class is used to register the Dimensions transport protocol when eclipse
 * loads with this plug-in.
 *
 */
public class DimensionsProtocolInitializer implements IStartup {
		
	
	@Override
	public void earlyStartup() {
		Transport.register(DimensionsTransport.PROTOCOL_DIMENSIONS);
	}

}

package com.microfocus.dimensions.plugin.ui;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.eclipse.jface.resource.ImageDescriptor;

import com.microfocus.dimensions.plugin.Activator;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;
import com.microfocus.dimensions.plugin.utils.StringUtils;

public class ImageDescriptors {
    private static final ImageDescriptors instance = new ImageDescriptors(IPluginImages.class);

    private HashMap<String, ImageDescriptor> descriptors = new HashMap<String, ImageDescriptor>();

    private ImageDescriptors(Class<?> images) {
        try {
            URL baseURL = Activator.getDefault().getBundle().getEntry(IPluginImages.ICON_PATH);
            Field[] fields = images.getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                Field aField = fields[i];
                if (aField.getType() == String.class && Modifier.isStatic(aField.getModifiers())) {
                    String id = (String) aField.get(null);
                    if (!StringUtils.isNullEmpty(id)) {
                        ImageDescriptor imDesc = createImageDescriptor(id, baseURL);
                        descriptors.put(id, imDesc);
                    }
                }
            }
        } catch (Throwable t) {
        	LoggerHelper.error("Error creating image descriptors", ImageDescriptors.class, t);
        }
    }

    private ImageDescriptor createImageDescriptor(String id, URL baseURL) throws MalformedURLException {
        URL url = new URL(baseURL, /* ICON_PATH + */id);
        return ImageDescriptor.createFromURL(url);
    }

    /**
     * Returns the image descriptor for the given image ID.
     * Returns <code>null</code> if there is no such image.
     */
    public ImageDescriptor getImageDescriptor(String id) {
        return (ImageDescriptor) descriptors.get(id);
    }

    public static ImageDescriptors getInstance() {
        return instance;
    }
}

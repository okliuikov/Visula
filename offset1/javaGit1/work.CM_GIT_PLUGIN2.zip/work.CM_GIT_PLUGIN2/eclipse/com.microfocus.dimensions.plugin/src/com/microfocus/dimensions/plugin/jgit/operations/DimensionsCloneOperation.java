package com.microfocus.dimensions.plugin.jgit.operations;

import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.transport.URIish;

import com.microfocus.dimensions.plugin.jgit.services.CloneUriHolder;
import com.microfocus.dimensions.plugin.utils.CommandExecutionStatus;
import com.microfocus.dimensions.plugin.utils.CommandLineHelper;
import com.microfocus.dimensions.plugin.utils.GitUtils;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;
import com.microfocus.dimensions.plugin.utils.PlatformUtils;

/**
 * This clone operation is responsible for cloning the remote Dimensions
 * repository to local.
 *
 */
public class DimensionsCloneOperation implements IOperation {

    private final URIish uri;
    private final Repository repository;
    private static String PROCESS_NAME = "Clone";

    /**
     * Parameterized constructor
     *
     * @param uri
     *            - the URIish instance, must not be null
     *
     * @param repository
     *            - the repository instance, must not be null
     *
     */
    public DimensionsCloneOperation(URIish uri, Repository repository) {
        this.uri = uri;
        this.repository = repository;
    }

    @Override
    public CommandExecutionStatus run() {
        LoggerHelper.debug("Inside DimensionsCloneOperation run method", DimensionsCloneOperation.class);
        CommandExecutionStatus status = new CommandExecutionStatus();

        if (uri != null && repository != null) {
            if (PlatformUtils.isWindows()) {
                String commandToBeExecuted = getCommandForWindows();
                status = CommandLineHelper.executeCommand(commandToBeExecuted, PROCESS_NAME);
            }
            else {
                String[] commandToBeExecuted = getCommandForNonWindows();
                status = CommandLineHelper.executeCommand(commandToBeExecuted, PROCESS_NAME);
            }

        } else {
            status.setError("Clone failed.. The provided uri/repository is null in DimensionsCloneOperation");
            LoggerHelper.error(status.getErrorMessage(), DimensionsCloneOperation.class);
        }
        return status;
    }

    private String getCommandForWindows() {
        String localRepositoryRoot = GitUtils.getRepositoryRootPathString(repository);

        return String.format("cmd /C git clone %s %s", CommandLineHelper.quote(getUriString()),
                CommandLineHelper.quote(localRepositoryRoot));
    }
    
    private String[] getCommandForNonWindows() {
        String[] params = { "git", "clone", getUriString(), GitUtils.getRepositoryRootPathString(repository) };
        return params;
    }
    
    private String getUriString() {
        URIish uriToUse = CloneUriHolder.getLastKnownUri();
        if (uriToUse == null || !uriToUse.toString().equals(uri.toString())) {
            uriToUse = uri;
        }
        CloneUriHolder.clear();
        return uriToUse.toPrivateString();
    }
}

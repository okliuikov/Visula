package com.microfocus.dimensions.plugin.jgit.connections;

import java.io.OutputStream;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.errors.TransportException;
import org.eclipse.jgit.internal.storage.file.PackLock;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ProgressMonitor;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.transport.FetchConnection;

import com.microfocus.dimensions.plugin.jgit.services.DimensionsLsRemoteCommand;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;

/**
 * This class is used to lists known refs from the Dimensions and copies objects
 * of selected refs.
 *
 */
@SuppressWarnings("restriction")
public class DimensionsFetchConnection implements FetchConnection {
	private DimensionsLsRemoteCommand lsRemoteCommand;

    /**
     * Parameterized constructor
     *
     * @param repository
     *            - the repository instance, must not be null
     */
    public DimensionsFetchConnection(Repository repository) {
        lsRemoteCommand = new DimensionsLsRemoteCommand(repository);
    }

	@Override
	public Map<String, Ref> getRefsMap() {
		Map<String, Ref> refmap = lsRemoteCommand.getRefmap();
		if (refmap.isEmpty()) {
			try {
				lsRemoteCommand.call();
			} catch (GitAPIException e) {
				LoggerHelper.error("Got exception in getRefsMap", DimensionsFetchConnection.class, e);
			}
			refmap = lsRemoteCommand.getRefmap();
		}
		return refmap;
	}

	@Override
	public Collection<Ref> getRefs() {
		Collection<Ref> refs = null;
		Map<String, Ref> refmap = lsRemoteCommand.getRefmap();
		if (refmap.isEmpty()) {
			try {
				refs = lsRemoteCommand.call();
			} catch (GitAPIException e) {
				LoggerHelper.error("Got exception in getRefs", DimensionsFetchConnection.class, e);
			}
		} else {
			refs = refmap.values();
		}
		return refs;
	}

	@Override
	public Ref getRef(String name) {
		return getRefsMap().get(name);
	}

	@Override
	public void close() {
	}

	@Override
	public String getMessages() {
		return null;
	}

	@Override
	public String getPeerUserAgent() {
		return null;
	}

	@Override
	public void fetch(ProgressMonitor monitor, Collection<Ref> want, Set<ObjectId> have) throws TransportException {
	}

	@Override
	public void fetch(ProgressMonitor monitor, Collection<Ref> want, Set<ObjectId> have, OutputStream out)
			throws TransportException {
	}

	@Override
	public boolean didFetchIncludeTags() {
		return false;
	}

	@Override
	public boolean didFetchTestConnectivity() {
		return true;
	}

	@Override
	public void setPackLockMessage(String message) {
	}

	@Override
	public Collection<PackLock> getPackLocks() {
		return Collections.<PackLock>emptyList();
	}
}
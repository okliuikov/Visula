package com.microfocus.dimensions.plugin.jgit.operations;

import org.eclipse.jgit.lib.Repository;

import com.microfocus.dimensions.plugin.utils.CommandExecutionStatus;
import com.microfocus.dimensions.plugin.utils.CommandLineHelper;
import com.microfocus.dimensions.plugin.utils.GitUtils;
import com.microfocus.dimensions.plugin.utils.PlatformUtils;

/**
 * This fetch operation is responsible for fetching the remote Dimensions
 * repository contents to local repository.
 *
 */
public class DimensionsFetchOperation implements IOperation {

    private final Repository repository;
    private static String COMMAND_TO_EXECUTE = PlatformUtils.getPrefixCommand() + "git fetch";
    public static String PROCESS_NAME = "Fetch";

    /**
     * Parameterized constructor
     *
     * @param repository
     *            - the repository instance, must not be null
     */
    public DimensionsFetchOperation(Repository repository) {
        this.repository = repository;
    }

    @Override
    public CommandExecutionStatus run() {
        String localRepositoryRootPath = GitUtils.getRepositoryRootPathString(repository);
        return CommandLineHelper.executeCommand(localRepositoryRootPath, COMMAND_TO_EXECUTE, PROCESS_NAME);
    }
}

package com.microfocus.dimensions.plugin.jgit.services;

import org.eclipse.jgit.transport.URIish;

public class CloneUriHolder {

    private static URIish uri;

    public static void setLastKnownUri(URIish instance) {
        uri = instance;
    }

    public static void clear() {
        setLastKnownUri(null);
    }
    
    public static URIish getLastKnownUri() {
        return uri;
    }
}

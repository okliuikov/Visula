package com.microfocus.dimensions.plugin;


import java.net.URL;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.slf4j.LoggerFactory;
import org.eclipse.jface.resource.ImageDescriptor;

import com.microfocus.dimensions.ide.eclipse.preferences.JgitPreferencePage;
import com.microfocus.dimensions.plugin.ui.ImageDescriptors;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;



/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "com.microfocus.dimensions.plugin"; //$NON-NLS-1$

	// The shared instance
	private static Activator plugin;
	
	private static Bundle bundle;

	/**
	 * The constructor
	 */
	public Activator() {
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.
	 * BundleContext)
	 */
	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		bundle = context.getBundle();
		configureLogbackInBundle(bundle);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	@Override
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}
	
    /**
     * Returns the image descriptor for the given image ID.
     * Returns <code>null</code> if there is no such image.
     */
    public ImageDescriptor getImageDescriptor(String id) {
        return ImageDescriptors.getInstance().getImageDescriptor(id);
    }

	/**
	 * This method is used to configure the logging if its enabled.
	 */
	private static void configureLogbackInBundle(Bundle bundle) throws Exception {
		
		if(isLoggingEnabled())
		{
			LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
			context.reset();

			JoranConfigurator jc = new JoranConfigurator();
			jc.setContext(context);

			String jGitLogPath = getLogDirectoryPath();
			LoggerHelper.debug("jGitLogPath is :" + jGitLogPath, Activator.class);

			// overriding the log directory property programmatically
			if(StringUtils.isNotEmpty(jGitLogPath))
			{
				context.putProperty("LOG_DIR", jGitLogPath);
			}
			// this assumes that the logback.xml file is in the root of the bundle.
			URL logbackConfigFileUrl = FileLocator.find(bundle, new Path("logback.xml"),null);
			jc.doConfigure(logbackConfigFileUrl.openStream());
		}
	}

	/**
	 * This method is used to configure the logging once it is enabled.
	 * @throws Exception
	 */
	public static void configureLogging() throws Exception
	{
		configureLogbackInBundle(bundle);
	}
	
	/**
	 * This method is used to get the log directory path.
	 * @return  the log directory path
	 */
	public static String getLogDirectoryPath() {
		return Activator.getDefault().getPreferenceStore().getString(JgitPreferencePage.JGIT_LOG_PATH);
	}

	/**
	 * This method is used to return the logging is enabled or not.
	 * @return - TRUE/FALSE
	 */
	public static boolean isLoggingEnabled()
	{
		return true;
	}

}

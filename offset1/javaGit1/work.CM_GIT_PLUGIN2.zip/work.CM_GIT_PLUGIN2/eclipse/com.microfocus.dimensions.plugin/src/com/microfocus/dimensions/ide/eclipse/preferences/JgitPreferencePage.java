/*
 * @@ COPYRIGHT NOTICES @@
 * Copyright (c) 2019 Micro Focus or one of its affiliates.
 * All Rights Reserved
 */
package com.microfocus.dimensions.ide.eclipse.preferences;

import java.io.File;
import java.nio.file.Files;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.microfocus.dimensions.plugin.Activator;
import com.microfocus.dimensions.plugin.utils.LoggerHelper;

/**
 * This class represents a preference page that is contributed to the
 * Preferences dialog.  By subclassing <samp>FieldEditorPreferencePage</samp>,
 * it uses the field support built into JFace that allows the plugin to create
 * a page that is small and knows how to save, restore and apply itself.
 * <p>
 * This page is used to modify preferences only.  They are stored in the
 * preference store that belongs to the main plug-in class.  That way,
 * preferences can be accessed directly via the preference store.
 */
public class JgitPreferencePage extends PreferencePage implements IWorkbenchPreferencePage {

	////////////////////////////////////////////////////////////////////
	//
	// Class static fields
	//
	////////////////////////////////////////////////////////////////////

	/**
	 *  Variable for setting git log path .
	 */
	public static final String JGIT_LOG_PATH = "jgit.log.path"; 

	/**
	 * Variable for setting enable logging files.
	 */
	public static final String ENABLE_LOGGING = "jgit.log.enabling"; 
	
	private static final String JGIT_LOG_DIRECTORY ="Log file directory";
	
	private static final String MESSAGE_PAGE_DESCRIPTION = "Use these settings to specify the directory of the Dimensions JGit and Git client log files.";

	private static final String MESSAGE_DIRECTORY_PATH_INVALID = "Invalid Directory path or no permission to create directory.";

	private static final String MESSAGE_INVALID_DIRECTORY_WRITE_PERMISSION = "Directory doesn't have write permission.";

	private static final String MESSAGE_DIRECTORY_PATH_IS_EMPTY = "Directory path is empty. Please provide a valid path.";

	
	private static String USER_HOME_DIRECTORY = System.getProperty("user.home");

	private Text jgitLogPathText;

	private String jgitLogPath;

	private Button browseButton;

	private Button enableLogging;

	private boolean isLoggingEnabled;

	/**
	 * Default Constructor
	 */
	public JgitPreferencePage () {
		initializeDefaults(true);
	}

	public void init(IWorkbench workbench) { }

	protected Control createContents(Composite parent) {
		loadPreferenceValues();
		Composite composite = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		layout.makeColumnsEqualWidth = false;
		layout.numColumns = 1;


		composite.setLayout(layout);
		new Label(composite, SWT.NULL).setText(MESSAGE_PAGE_DESCRIPTION);

		//-----------------------------------------------------------------------------------

		Composite compositeLogging = new Composite(composite, SWT.NULL);
		compositeLogging.setLayout(layout);

		enableLogging = new Button(compositeLogging, SWT.CHECK | SWT.LEFT); 
		enableLogging.setText("Enable Logging");
		enableLogging.setFont(parent.getFont()); 
		enableLogging.addSelectionListener(new SelectionAdapter() { 
			public void widgetSelected(SelectionEvent e) { 

				if (enableLogging.getSelection())
				{
					isLoggingEnabled = true;
				}
				else
				{
					isLoggingEnabled = false;
					setErrorMessage(null);
				}
				
				if(isLoggingEnabled && StringUtils.isEmpty(jgitLogPath))
				{
					jgitLogPath = USER_HOME_DIRECTORY;
					jgitLogPathText.setText(jgitLogPath);
				}
				
				jgitLogPathText.setEnabled(isLoggingEnabled);
				browseButton.setEnabled(isLoggingEnabled);
			}});


		if(isLoggingEnabled)
		{
			enableLogging.setSelection(isLoggingEnabled);
		}

		GridData gridData = new GridData();
		gridData.horizontalAlignment = GridData.FILL;
		gridData.grabExcessHorizontalSpace = true;

		Composite compositeDimensions = new Composite(composite, SWT.NONE);
		GridLayout compositGridLayout = new GridLayout();
		compositGridLayout.numColumns = 4;
		compositeDimensions.setLayout(compositGridLayout);
		GridData compositeGridData = new GridData(GridData.FILL_HORIZONTAL);
		compositeDimensions.setLayoutData(compositeGridData);


		Label textLabel = new Label(compositeDimensions, SWT.NONE);
		textLabel.setText(JGIT_LOG_DIRECTORY);

		jgitLogPathText = new Text(compositeDimensions, SWT.BORDER);
		jgitLogPathText.setLayoutData(gridData);
		jgitLogPathText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent event) {
				setErrorMessage(null);
			}
		});
		jgitLogPathText.setEnabled(isLoggingEnabled);
		browseButton = new Button(compositeDimensions, SWT.PUSH);
		browseButton.setText("Browse");
		browseButton.addMouseListener(new FileBrowserMouseListener(composite.getShell()));
		browseButton.setEnabled(isLoggingEnabled);

		if(StringUtils.isEmpty(jgitLogPath))
		{
			jgitLogPath = USER_HOME_DIRECTORY;
		}
		jgitLogPathText.setText(jgitLogPath);

		return composite;
	}


	/**
	 * Performs the Restore Defaults processing.
	 * Sets the fields to there default values.
	 */
	protected void performDefaults() {
		initializeDefaults(false);
		super.performDefaults();
	}

	/**
	 * Initialize default preference values
	 * @param firstTime - true if need initialize at first time false otherwise.
	 */
	private void initializeDefaults(boolean firstTime) {
		IPreferenceStore store = getPreferenceStore();

		if (firstTime) {
			store.setDefault(JGIT_LOG_PATH, USER_HOME_DIRECTORY);
			store.setDefault(ENABLE_LOGGING,false);
		} 
		else { 
			jgitLogPathText.setText(store.getDefaultString(JGIT_LOG_PATH));
			enableLogging.setSelection(store.getDefaultBoolean(ENABLE_LOGGING));
			jgitLogPath = USER_HOME_DIRECTORY;
			isLoggingEnabled = false;
			
			store.setValue(JGIT_LOG_PATH, USER_HOME_DIRECTORY);
			store.setValue(ENABLE_LOGGING, isLoggingEnabled);
			jgitLogPathText.setEnabled(isLoggingEnabled);
			browseButton.setEnabled(isLoggingEnabled);
			
			LoggerHelper.debug("Restore log path variable :" + store.getString(JGIT_LOG_PATH), JgitPreferencePage.class);
			LoggerHelper.debug("Restore log path : " + jgitLogPath, JgitPreferencePage.class);
			LoggerHelper.debug("Restore Enable logging : " + isLoggingEnabled, JgitPreferencePage.class);
		}
	}


	/**
	 * Load Dimensions preference values
	 */
	private void loadPreferenceValues() {
		IPreferenceStore store = getPreferenceStore();
		jgitLogPath = store.getString(JGIT_LOG_PATH);
		LoggerHelper.debug("JGIT_LOG_PATH loaded value : " + jgitLogPath, JgitPreferencePage.class);
		isLoggingEnabled = store.getBoolean(ENABLE_LOGGING);
		LoggerHelper.debug("ENABLE_LOGGING loaded value : " + isLoggingEnabled, JgitPreferencePage.class);
	}

	/**
	 * Get Dimensions plugin preference store
	 * @return preference store
	 */
	protected IPreferenceStore doGetPreferenceStore() {
		return Activator.getDefault().getPreferenceStore();
	}

	/**
	 * Performs the OK processing.  Also performed when the Apply button has
	 * been pressed and the <em>performApply</em> methods is not implemented.
	 * <br>
	 * This method validates the field values in the page.
	 */
	public boolean performOk() {

		isLoggingEnabled = enableLogging.getSelection();
		if(isLoggingEnabled)
		{
			jgitLogPath = jgitLogPathText.getText();
			boolean status = validateDirectory(jgitLogPath);
			if (status) { // The status of the page is valid - save the value.
				savePreferences(true);
				// Return the status
			}
			return status;
		}else
		{
			savePreferences(false);
		}
		return true;
	}

	/**
	 * Save Dimensions preference values
	 */
	private void savePreferences(boolean isStoreLogPath) {
		IPreferenceStore store = getPreferenceStore();
		if(isStoreLogPath)
		{
			store.setValue(JGIT_LOG_PATH, jgitLogPath);
			LoggerHelper.debug("JGIT_LOG_PATH set value : " + jgitLogPath, JgitPreferencePage.class);
		}
		store.setValue(ENABLE_LOGGING, isLoggingEnabled);
		LoggerHelper.debug("ENABLE_LOGGING set value : " + isLoggingEnabled, JgitPreferencePage.class);
		
		if(isLoggingEnabled)
		{
			try {
				Activator.configureLogging();
			} catch (Exception e) {
				LoggerHelper.error("Error while configuring logging ", JgitPreferencePage.class, e);
			}
		}
	}


	/**
	 * Validates the value in the log path.
	 * The <em>setErrorMessage</em> is used to display the error
	 * text to the user.
	 *
	 * @return Returns true when the field value is valid.
	 */
	private boolean validateDirectory(String path) {
		boolean validStatus = true;

		if (!path.isEmpty()) {
			File dir = new File(path);
			LoggerHelper.debug("Log directory path is : " + path, JgitPreferencePage.class);
			LoggerHelper.debug("Is dir? : " + dir.isDirectory(), JgitPreferencePage.class);
			LoggerHelper.debug("Is exists? : " + dir.exists(), JgitPreferencePage.class);

			if (!dir.exists()) {
				dir.mkdir();
			}

			if (!dir.exists()) { // An error was detecting testing the Dimensions command
				setErrorMessage(MESSAGE_DIRECTORY_PATH_INVALID);
				validStatus = false;
			} else {
				if (!Files.isWritable(dir.toPath())) {
					setErrorMessage(MESSAGE_INVALID_DIRECTORY_WRITE_PERMISSION);
					validStatus = false;
				} else {
					jgitLogPath = path;
				}
			} 
		}else
		{
			setErrorMessage(MESSAGE_DIRECTORY_PATH_IS_EMPTY);
			validStatus = false;
		}
		// Return the status
		return validStatus;
	}


	public class FileBrowserMouseListener implements MouseListener {

		private Shell shell;

		public FileBrowserMouseListener(Shell shell) {
			this.shell = shell;
		}

		public void mouseUp(MouseEvent event) {
			String selected = openFileDialog();
			jgitLogPathText.setText(selected);
		}

		public void mouseDown(MouseEvent arg0) { }
		public void mouseDoubleClick(MouseEvent arg0) { }


		private String openFileDialog() {
			DirectoryDialog dirDialog = new DirectoryDialog(shell, SWT.SAVE);

			dirDialog.setText("Browse For Directory");
			String selected = dirDialog.open();
			return selected;
		}
	}



} // End of JgitPreferencePage

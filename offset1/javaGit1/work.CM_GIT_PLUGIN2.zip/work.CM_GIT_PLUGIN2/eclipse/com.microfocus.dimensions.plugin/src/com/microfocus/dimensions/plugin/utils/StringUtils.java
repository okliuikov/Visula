package com.microfocus.dimensions.plugin.utils;

public class StringUtils {
	/**
     * @return <code>true</code> if the supplied string is <code>null</code> or empty, otherwise returns <code>false</code>
     */
    public static boolean isNullEmpty(String s) {
        return s == null || s.isEmpty();
    }

	public static String removeLineBreaks(String text) {
		if (isNullEmpty(text)) {
			return text;
		}
		return text.replace("\n", "").replace("\r", "");
	}
}

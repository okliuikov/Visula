/**
 * @@ COPYRIGHT NOTICES @@
 * Copyright (c) 2019 Micro Focus or one of its affiliates.
 * All Rights Reserved
 */
package com.microfocus.dimensions.common;

/**
 * This class defines the common constants and utility methods available to all
 * Java API applications.
 */
public class Constants {
	
    /**
     * The git client environment variable for enabling log
     */
    public static String GIT_CLIENT_ENVIRONMENT_VARIABLE = "DIMENSIONS_GIT_LOGFILE";
    
    /**
     * The git client log file name
     */
    public static String GIT_CLIENT_LOG_FILENAME = "DimensionsEclipse_GitClient_Log.log";
}

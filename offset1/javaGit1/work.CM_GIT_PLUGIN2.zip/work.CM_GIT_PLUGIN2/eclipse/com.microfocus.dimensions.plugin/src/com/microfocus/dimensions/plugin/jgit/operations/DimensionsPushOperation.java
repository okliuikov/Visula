package com.microfocus.dimensions.plugin.jgit.operations;

import java.util.ArrayList;

import org.eclipse.jgit.lib.Repository;

import com.microfocus.dimensions.plugin.utils.CommandExecutionStatus;
import com.microfocus.dimensions.plugin.utils.CommandLineHelper;
import com.microfocus.dimensions.plugin.utils.PlatformUtils;

/**
 * This push operation is responsible for pushing the local repository contents
 * to remote Dimensions repository.
 *
 */
public class DimensionsPushOperation implements IOperation {

	private final Repository repository;
	private String remoteBranchName = "master";
	private String localBranchName = "master";
	private boolean isDryRun = false;
	private boolean isForceUpdate = false;
	private static String PROCESS_NAME = "Push";
	private static String PUSH_COMMAND = "git push -u origin ";
	private static String SOURCE_AND_TARGET_BRANCHES = "%s:%s "; 
	private static String DRY_RUN_COMMAND = "--dry-run ";
	private static String FORCE_COMMAND = "--force";

	/**
	 * Parameterized constructor
	 *
	 * @param repository
	 *            - the repository instance, must not be null
	 */
	public DimensionsPushOperation(Repository repository) {
		this.repository = repository;
	}

	@Override
    public CommandExecutionStatus run() {
        if (PlatformUtils.isWindows()) {
            String commandToBeExecuted = PlatformUtils.getPrefixCommand() + PUSH_COMMAND; 
            commandToBeExecuted += String.format(SOURCE_AND_TARGET_BRANCHES, localBranchName, remoteBranchName);
            if (isDryRun()) {
                commandToBeExecuted += DRY_RUN_COMMAND;
            }

            if (isForceUpdate()) {
                commandToBeExecuted += FORCE_COMMAND;
            }
            return CommandLineHelper.executeCommand(repository.getDirectory().getAbsolutePath(), commandToBeExecuted,
                    PROCESS_NAME);
        } else {
            return CommandLineHelper.executeCommand(repository.getDirectory().getAbsolutePath(),
                    getCommandParts(), PROCESS_NAME);
        }
    }

	public String getRemoteBranchName() {
		return remoteBranchName;
	}

	public void setRemoteBranchName(String remoteBranchName) {
		this.remoteBranchName = remoteBranchName;
	}

	public String getLocalBranchName() {
		return localBranchName;
	}

	public void setLocalBranchName(String localBranchName) {
		this.localBranchName = localBranchName;
	}

	public boolean isDryRun() {
		return isDryRun;
	}

	public void setDryRun(boolean isDryRun) {
		this.isDryRun = isDryRun;
	}

	public boolean isForceUpdate() {
		return isForceUpdate;
	}

	public void setForceUpdate(boolean isForceUpdate) {
		this.isForceUpdate = isForceUpdate;
	}
	
    private String[] getCommandParts() {
        ArrayList<String> commandParts = new ArrayList<String>();
        for (String part : PUSH_COMMAND.trim().split(" ")) {
            commandParts.add(part);
        }
        commandParts.add(String.format(SOURCE_AND_TARGET_BRANCHES.trim(), localBranchName, remoteBranchName));
        if (isDryRun()) {
            commandParts.add(DRY_RUN_COMMAND.trim());
        }

        if (isForceUpdate()) {
            commandParts.add(FORCE_COMMAND);
        }
        return commandParts.toArray(new String[commandParts.size()]);
    }

}

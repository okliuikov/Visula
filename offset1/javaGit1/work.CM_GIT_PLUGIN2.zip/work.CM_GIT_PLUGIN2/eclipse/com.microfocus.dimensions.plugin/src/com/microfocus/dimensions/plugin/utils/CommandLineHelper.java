package com.microfocus.dimensions.plugin.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Semaphore;
import java.util.Set;

import com.microfocus.dimensions.common.Constants;
import com.microfocus.dimensions.plugin.Activator;

/**
 * This helper class is responsible executing the command line operations.
 *
 */
public class CommandLineHelper {

    /**
     * This method is used to execute the command using runtime process, provided
     * the file path, process name and the command to be executed.
     *
     * @param filePath
     *            - the file path where the command to be executed, must not be null
     * @param commandToExecute
     *            - the command to be executed , must not be null
     * @param processName
     *            - the process name, must not be null
     * @return CommandExecutionStatus - the status of the execution
     */
    public static CommandExecutionStatus executeCommand(String filePath, String commandToExecute, String processName) {
        // TODO it seems on windows we also can execute a command using array of strings. If so, do refactoring later.
        CommandExecutionStatus status = null;
        try {
            String[] environmentVariables = getEnvironmentVariables();
            LoggerHelper.debug("The command to be executed is : " + commandToExecute, CommandLineHelper.class);
            Process process = Runtime.getRuntime().exec(commandToExecute, environmentVariables, new File(filePath));
            status = execute(processName, process);
        } catch (Exception e) {
            LoggerHelper.error("Got exception in executeCommand : ", CommandLineHelper.class, e);
            status = CommandExecutionStatus.error(e.getMessage());
        }

        return status;
    }

    /**
     * This method is used to execute the command using runtime process, provided
     * the file path, process name and the command to be executed.
     *
     * @param filePath
     *            - the file path where the command to be executed, must not be null
     * @param commandToExecute
     *            - the command array to be executed , must not be null
     * @param processName
     *            - the process name, must not be null
     * @return CommandExecutionStatus - the status of the execution
     */
    public static CommandExecutionStatus executeCommand(String filePath, String[] commandToExecute,
            String processName) {
        CommandExecutionStatus status = null;
        try {
            String[] environmentVariables = getEnvironmentVariables();
            LoggerHelper.debug("The command to be executed is : " + Arrays.toString(commandToExecute),
                    CommandLineHelper.class);
            Process process = Runtime.getRuntime().exec(commandToExecute, environmentVariables, new File(filePath));
            status = execute(processName, process);
        } catch (Exception e) {
            LoggerHelper.error("Got exception in executeCommand : ", CommandLineHelper.class, e);
            status = CommandExecutionStatus.error(e.getMessage());
        }
        return status;
    }

    /**
     * This method is used to execute the command using runtime process, provided
     * the command, process name to be executed.
     *
     * @param commandToExecute
     *            - the command to be executed , must not be null
     * @param processName
     *            - the process name, must not be null
     * @return CommandExecutionStatus - the status of the execution
     */
    public static CommandExecutionStatus executeCommand(String commandToExecute, String processName) {
        CommandExecutionStatus status = null;
        try {
            String[] environmentVariables = getEnvironmentVariables();
            LoggerHelper.debug("The command to be executed is : " + commandToExecute, CommandLineHelper.class);
            Process process = Runtime.getRuntime().exec(commandToExecute, environmentVariables);
            status = execute(processName, process);
        } catch (Exception e) {
            LoggerHelper.error("Got exception in executeCommand : ", CommandLineHelper.class, e);
            status = CommandExecutionStatus.error(e.getMessage());
        }

        return status;
    }

    /**
     * This method is used to execute the command using runtime process, provided
     * the file path, process name and the command to be executed.
     *
     * @param filePath
     *            - the file path where the command to be executed, must not be null
     * @param commandToExecute
     *            - the command array to be executed , must not be null
     * @param processName
     *            - the process name, must not be null
     * @return CommandExecutionStatus - the status of the execution
     */
    public static CommandExecutionStatus executeCommand(String[] commandToExecute, String processName) {
        CommandExecutionStatus status = null;
        try {
            String[] environmentVariables = getEnvironmentVariables();
            LoggerHelper.debug("The command to be executed is : " + Arrays.toString(commandToExecute),
                    CommandLineHelper.class);
            Process process = Runtime.getRuntime().exec(commandToExecute, environmentVariables);
            status = execute(processName, process);
        } catch (Exception e) {
            LoggerHelper.error("Got exception in executeCommand : ", CommandLineHelper.class, e);
            status = CommandExecutionStatus.error(e.getMessage());
        }

        return status;
    }

    /** Quotes a given object's string representation. */
    public static String quote(Object value) {
        return String.format("\"%s\"", value);
    }
    
    /**
     * This method is used to execute the process.
     */
    private static CommandExecutionStatus execute(String processName, Process process)
            throws IOException, InterruptedException {
        ProcessOutputMessageConsumer processOutputMessageConsumer = new CommandLineHelper().new ProcessOutputMessageConsumer(
                process);
        processOutputMessageConsumer.start();
        ProcessErrorMessageConsumer processErrorMessageConsumer = new CommandLineHelper().new ProcessErrorMessageConsumer(
                process);
        processErrorMessageConsumer.start();
        return getUpdatedStatus(processName, process, processOutputMessageConsumer, processErrorMessageConsumer);
    }

    /**
     * This method is used to get the environment variables..
     */
    private static String[] getEnvironmentVariables() {
        Map<String, String> envMap = new HashMap<>(System.getenv());

        if (Activator.isLoggingEnabled()) {
            String logDirectoryPath = Activator.getLogDirectoryPath() + File.separator
                    + Constants.GIT_CLIENT_LOG_FILENAME;
            envMap.put(Constants.GIT_CLIENT_ENVIRONMENT_VARIABLE, logDirectoryPath);
        }
        Set<Entry<String, String>> entrySet = envMap.entrySet();

        String[] environmentVariables = new String[entrySet.size()];
        int count = 0;
        for (Entry<String, String> entry : entrySet) {
            environmentVariables[count++] = String.format("%s=%s", entry.getKey(), entry.getValue());
        }

        return environmentVariables;
    }

    /**
     * This method is used to get the updated status message after command
     * execution.
     */
    private static CommandExecutionStatus getUpdatedStatus(String processName, Process process,
            ProcessOutputMessageConsumer processOutputMessageConsumer,
            ProcessErrorMessageConsumer processErrorMessageConsumer) throws IOException, InterruptedException {
        CommandExecutionStatus status;
        String outputMessage = processOutputMessageConsumer.getOutputMessage();
        String errorMessage = processErrorMessageConsumer.getErrorMessage();
        int waitFor = process.waitFor();
        LoggerHelper.debug(processName + " process termination value : " + waitFor, CommandLineHelper.class);

        status = new CommandExecutionStatus(waitFor == 0 ? true : false, outputMessage, errorMessage);

        if (status.isExecutionPassed()) {
            LoggerHelper.info(String.format("The '%s' operation is done successfully.", processName),
                    CommandLineHelper.class);
            LoggerHelper.info(status.getArrgregateMessage(), CommandLineHelper.class);
        } else {
            LoggerHelper.error(String.format("The '%s' operation is failed.", processName), CommandLineHelper.class);
            LoggerHelper.error(status.getArrgregateMessage(), CommandLineHelper.class);
        }
        return status;
    }

    /**
     * This class is used to get the output message from the process.
     */
    private class ProcessOutputMessageConsumer extends Thread {
        private Semaphore outputSemaphoreNew;
        private String outputMessageNew;
        private Process process;

        public ProcessOutputMessageConsumer(Process process) {
            try {
                this.process = process;
                outputSemaphoreNew = new Semaphore(1);
                outputSemaphoreNew.acquire();
            } catch (InterruptedException e) {
                LoggerHelper.error("Exception while acquiring lock in output message consumer thread..",
                        CommandLineHelper.class, e);
            }
        }

        @Override
        public void run() {
            try {
                StringBuffer readBuffer = new StringBuffer();
                BufferedReader isr = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String buff = new String();
                while ((buff = isr.readLine()) != null) {
                    readBuffer.append(buff + "\n");
                    System.out.println(buff);
                }
                outputMessageNew = readBuffer.toString();
                outputSemaphoreNew.release();
            } catch (IOException e) {
                LoggerHelper.error("Exception while running output message consumer thread..",
                        CommandLineHelper.class, e);
            }
        }

        /**
         * This method is used to get the output message from the process.
         */
        private String getOutputMessage() {
            try {
                outputSemaphoreNew.acquire();
            } catch (InterruptedException e) {
                LoggerHelper.error("Exception while acquiring lock in get output message consumer thread..",
                        CommandLineHelper.class, e);
            }
            String value = outputMessageNew;
            outputSemaphoreNew.release();
            return value;
        }
    }

    /**
     * This class is used to get the error message from the process.
     */
    private class ProcessErrorMessageConsumer extends Thread {
        private Semaphore errorSemaphoreNew;
        private String errorMessageNew;
        private Process process;

        public ProcessErrorMessageConsumer(Process process) {
            try {
                this.process = process;
                errorSemaphoreNew = new Semaphore(1);
                errorSemaphoreNew.acquire();
            } catch (InterruptedException e) {
                LoggerHelper.error("Exception while acquiring lock in error message consumer thread..",
                        CommandLineHelper.class, e);
            }
        }

        @Override
        public void run() {
            try {
                StringBuffer readBuffer = new StringBuffer();
                BufferedReader isr = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                String buff = new String();
                while ((buff = isr.readLine()) != null) {
                    readBuffer.append(buff);
                }
                errorMessageNew = readBuffer.toString();
                errorSemaphoreNew.release();
            } catch (IOException e) {
                LoggerHelper.error("Exception while running error message consumer thread..",
                        CommandLineHelper.class, e);
            }
        }

        /**
         * This method is used to get the error message from the process.
         */
        private String getErrorMessage() {
            try {
                errorSemaphoreNew.acquire();
            } catch (InterruptedException e) {
                LoggerHelper.error("Exception while acquiring lock in get error message consumer thread..",
                        CommandLineHelper.class, e);
            }
            String value = errorMessageNew;
            errorSemaphoreNew.release();
            return value;
        }
    }
}

package com.microfocus.dimensions.plugin.utils;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jgit.lib.Repository;

public class GitUtils {

    public static boolean isDimensionsGitClientInstalled() {
        return isDimensionsGitClientInstalled(getGitExecFolderPaths());
    }

    public static boolean isDimensionsGitClientInstalled(List<IPath> gitExecFolderPaths) {
        if (gitExecFolderPaths == null) {
            return false;
        }
        for (IPath path : gitExecFolderPaths) {
            if (path != null && path.append("git-remote-dimensions").toFile().exists()) {
                return true;
            }
        }
        return false;
    }

    public static List<IPath> getGitExecFolderPaths() {
        CommandExecutionStatus commandStatus = CommandLineHelper.executeCommand("git --exec-path", "find git executable");
        ArrayList<IPath> folders = null;
        if (commandStatus.isExecutionPassed()) {
            // on unix the command actually reports two different folders at once,
            // report all of them for further processing
            String[] pathCandidates = commandStatus.getOutputMessage().split("\\r?\\n");
            folders = new ArrayList<IPath>(pathCandidates.length);
            for (String folderPath : pathCandidates) {
                folders.add(new Path(folderPath));
            }
        }
        return folders;
    }

    /**
     * Calculates root folder for a given local repository.
     * @param repository
     * @return Path object
     */
    public static java.nio.file.Path getRepositoryRootPath(Repository repository) {
        return repository.getDirectory().toPath().getParent();
    }

    /**
     * Calculates root folder for a given local repository.
     * @param repository
     * @return String representation of the path object
     */
    public static String getRepositoryRootPathString(Repository repository) {
        return getRepositoryRootPath(repository).toString();
    }

}

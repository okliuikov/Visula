package com.microfocus.dimensions.plugin.jgit.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.jgit.api.TransportCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.BranchConfig;
import org.eclipse.jgit.lib.Constants;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectIdRef;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.lib.StoredConfig;

import com.microfocus.dimensions.plugin.utils.LoggerHelper;
import com.microfocus.dimensions.plugin.utils.StringUtils;

/**
 * This class is used to lists refs from the Dimensions repository.
 *
 */
public class DimensionsLsRemoteCommand extends TransportCommand<DimensionsLsRemoteCommand, Collection<Ref>> {
	private Repository repository;
	private Map<String, Ref> refmap = new HashMap<>();

	/**
	 * Parameterized constructor
	 *
	 * @param repository
	 *            - the repository instance, must not be null
	 *
	 * @param processName
	 *            - the process name, must not be null
	 *
	 */
	public DimensionsLsRemoteCommand(Repository repository) {
		super(repository);
		this.repository = repository;
		refmap = new HashMap<>();
	}

	@Override
    public Collection<Ref> call() throws GitAPIException {
        LoggerHelper.debug("Inside DimensionsLsRemoteCommand.call method", DimensionsLsRemoteCommand.class);

        updateRefs();

        return refmap.values();
    }

	/**
	 * This method is used to update the refs for fetch and push operation
	 */
	private void updateRefs() {

		ObjectId refObjectId = ObjectId.zeroId();
		String localRefPath = Constants.R_HEADS + Constants.MASTER;
		String refPathToReport = localRefPath;
		if (repository != null) {
			try {
				// get current checked out branch
				localRefPath = repository.getFullBranch();
			} catch (IOException e) {
				LoggerHelper.error("Error reading current branch from the local repository",
						DimensionsLsRemoteCommand.class, e);
			}
			// switch to master branch again
			if (StringUtils.isNullEmpty(localRefPath)) {
				localRefPath = Constants.R_HEADS + Constants.MASTER;
			}

			// local ref name may differ from corresponding remote ref name
			// to resolve correct remote ref name and path we'll check git's config file
			// for example: remote is 'brancha1', local is
			// 'brancha1_myName' (its path is '\refs\heads\brancha1_myName')
			// but caller expects that we report '\refs\heads\brancha1'
			refPathToReport = getMergeBranchPath(localRefPath);
			String dimensionsRemoteRefPath = "refs/dimensions/origin/heads/"
					+ Repository.shortenRefName(refPathToReport);

			File remoteRefFile = new File(getAppendedFilePath(dimensionsRemoteRefPath));
			if (remoteRefFile.exists()) {
				refObjectId = ObjectId.fromString(getObjectId(remoteRefFile));
			} else {
				String localRefFilePath = getAppendedFilePath(localRefPath);
				File localRefFile = new File(localRefFilePath);
				if (localRefFile.exists()) {
					refObjectId = ObjectId.fromString(getObjectId(localRefFile));
				}
			}
		}
		refmap.put(refPathToReport, new ObjectIdRef.Unpeeled(Ref.Storage.NEW, refPathToReport, refObjectId));
	}
    
    private String getMergeBranchPath(String localBranchPath) {
        if (StringUtils.isNullEmpty(localBranchPath)) {
            return ""; //$NON-NLS-1$
        }
        String branchName = Repository.shortenRefName(localBranchPath);
        StoredConfig config = repository.getConfig();
        BranchConfig branchConfig = new BranchConfig(config, branchName);
        String merge = branchConfig.getMerge();
        if (!branchConfig.isRemoteLocal() && merge != null && merge.startsWith(Constants.R_HEADS)) {
            return merge;
        } 
        return localBranchPath;
    }
    
	/**
	 * This method is used to get the path to be appended at the end of the
	 * repository directory.
	 */
	private String getAppendedFilePath(String pathToAppend) {
		return repository.getDirectory().getAbsolutePath() + File.separator + pathToAppend;
	}

	/**
	 * This method is used to get the object id.
	 */
	private String getObjectId(File refFile) {
		LoggerHelper.debug("The ref file is : " + refFile.getAbsolutePath(), DimensionsLsRemoteCommand.class);
		String objectIdValue = "";
		try (BufferedReader reader = new BufferedReader(new FileReader(refFile))) {
			objectIdValue = reader.readLine();
			LoggerHelper.debug("objectIdValue from ref file : " + objectIdValue, DimensionsLsRemoteCommand.class);
		} catch (IOException e) {
			LoggerHelper.error("Got exception while getting object id ", DimensionsLsRemoteCommand.class, e);
		}
		return objectIdValue;
	}

	/**
	 * This method is used to get the refmap.
	 */
	public Map<String, Ref> getRefmap() {
		return refmap;
	}

}

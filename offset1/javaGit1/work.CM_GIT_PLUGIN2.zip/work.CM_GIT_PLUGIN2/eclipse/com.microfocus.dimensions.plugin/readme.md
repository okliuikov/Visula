Eclipse Git Client Plugin
--------------------------
This plugin allows using standard Eclipse Git integration to clone sources from Dimensions CM.

Build
--------------------------
TBD - requirements

Run build.bat

Installation
--------------------------
TBD - supported Eclipse versions

Start Eclipse<br>
Help > Install New Software...<br>
Add... > Archive... > Select EclipePlugin.zip > OK<br>
Check Dimensions CM Git Client plugin > Next

Usage
--------------------------
Open *Git Repositories* panel<br>
Press *Clone a Git repository* toolbar button<br>
Select *Dimensions CM* repository source

Troubleshooting
--------------------------
TBD - how to find logs